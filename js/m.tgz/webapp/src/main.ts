import './assets/main.css'

import { client } from '@/api/client.gen'
import { PiniaColada } from '@pinia/colada'
import { createPinia } from 'pinia'
import ui from '@nuxt/ui/vue-plugin'
import { createApp } from 'vue'
import App from './app/App.vue'
import router from './app/router'
import { useAuthStore } from '@/shared/stores/auth'
import { installSessionCache } from '@/shared/stores/sessionCache'

const app = createApp(App)

// Configure client defaults
client.setConfig({
  credentials: 'include',
  throwOnError: true,
})

let authRefresh: Promise<void> | undefined

function refreshPermissions() {
  if (authRefresh) return authRefresh
  authRefresh = (async () => {
    const auth = useAuthStore()
    await auth.checkAuth()
    const route = router.currentRoute.value
    if (!auth.isAuthenticated.value) {
      if (route.path !== '/login') await router.replace('/login')
      return
    }
    const { requiredPermission, requiredAnyPermission } = route.meta
    if (
      (requiredPermission && !auth.hasPermission(requiredPermission)) ||
      (requiredAnyPermission && !requiredAnyPermission.some((p) => auth.hasPermission(p)))
    ) {
      await router.replace('/forbidden')
    }
  })().finally(() => {
    authRefresh = undefined
  })
  return authRefresh
}

// Khi fe nhận dc header thay đổi quyền, thực hiện refresh permissions (không reload trang)
client.interceptors.response.use((response) => {
  if (response.headers.get('X-Permissions-Changed') === 'true' || response.status === 401) {
    // Do not await: refreshing auth makes requests through this same interceptor.
    void refreshPermissions()
  }
  return response
})

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && useAuthStore().isAuthenticated.value) {
    void refreshPermissions()
  }
})

app.use(createPinia())
app.use(PiniaColada, {
  queryOptions: {
    refetchOnWindowFocus: false,
  },
})
// Đăng ký xử lý cache trước khi router khởi tạo các màn hình.
app.runWithContext(() => installSessionCache(() => useAuthStore().isAuthenticated.value))

app.use(router)
app.use(ui)
app.mount('#app')
