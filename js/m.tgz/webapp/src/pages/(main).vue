<script setup lang="ts">
import AppNavbar from '@/app/AppNavbar.vue'
import { ROUTE_PATH } from '@/app/router/path'
import { useNotificationReadTracking } from '@/features/notification/composables/useNotifications'
import { useAuthStore } from '@/shared/stores/auth'
import { computed, onBeforeMount } from 'vue'
import { RouterView, useRouter } from 'vue-router'

const router = useRouter()
const authStore = useAuthStore()
useNotificationReadTracking()

const isInitialized = computed(() => authStore.isInitialized?.value ?? true)
const isAuthenticated = computed(() => authStore.isAuthenticated?.value ?? false)

onBeforeMount(async () => {
  if (authStore.isInitialized && !authStore.isInitialized.value && authStore.checkAuth) {
    await authStore.checkAuth()
  }
  if (!isAuthenticated.value) {
    await router.push(ROUTE_PATH.LOGIN)
  }
})
</script>

<template>
  <div class="flex h-dvh flex-col bg-muted">
    <template v-if="isInitialized">
      <AppNavbar />

      <UMain class="min-h-0 flex-1 overflow-auto">
        <UContainer class="max-w-none p-4 sm:p-6 md:p-8">
          <RouterView />
        </UContainer>
      </UMain>
    </template>
    <div v-else class="flex h-full items-center justify-center">
      <UIcon name="i-lucide-loader-2" class="size-8 animate-spin text-primary" />
    </div>
  </div>
</template>
