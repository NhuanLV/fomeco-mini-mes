<script setup lang="ts">
import { useRouter } from 'vue-router'

const router = useRouter()
</script>

<template>
  <div class="flex min-h-screen flex-col items-center justify-center gap-4">
    <span class="text-6xl font-bold text-toned">403</span>
    <p class="text-xl text-default">Bạn không có quyền truy cập trang này.</p>
    <div class="flex gap-2">
      <UButton label="Quay lại" color="neutral" icon="i-lucide-arrow-left" @click="router.back()" />
      <UButton label="Về trang chủ" @click="router.push('/')" />
    </div>
  </div>
</template>
