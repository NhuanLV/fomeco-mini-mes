<script setup lang="ts">
import DashboardFilterBar from '@/features/dashboard/components/DashboardFilterBar.vue'
import DashboardOverviewCards from '@/features/dashboard/components/DashboardOverviewCards.vue'
import DashboardProductionProgressChart from '@/features/dashboard/components/DashboardProductionProgressChart.vue'
import DashboardFactorySection from '@/features/dashboard/components/DashboardFactorySection.vue'
import DashboardTeamTable from '@/features/dashboard/components/DashboardTeamTable.vue'
import DashboardBuyerOrderTable from '@/features/dashboard/components/DashboardBuyerOrderTable.vue'
import DashboardProductionOrderTable from '@/features/dashboard/components/DashboardProductionOrderTable.vue'
import DashboardPendingActions from '@/features/dashboard/components/DashboardPendingActions.vue'
import DashboardWfxErrors from '@/features/dashboard/components/DashboardWfxErrors.vue'
import { useDashboardFilter } from '@/features/dashboard/composables/useDashboardFilter'

const { warehouseId } = useDashboardFilter()
</script>

<template>
  <div class="dashboard-shell flex flex-col gap-5 p-4 sm:p-6">
    <div class="flex items-center gap-3">
      <UIcon name="i-lucide-layout-dashboard" class="size-8 shrink-0 text-primary sm:size-8.5" />
      <div>
        <h1 class="text-2xl leading-tight font-bold tracking-tight text-highlighted">Dashboard</h1>
        <p class="text-sm font-medium text-toned">Tổng quan sản xuất</p>
      </div>
    </div>

    <!-- Section 1: Filter Bar -->
    <DashboardFilterBar />

    <!-- Section 2: 4 Overview Cards -->
    <DashboardOverviewCards v-if="!warehouseId" />

    <!-- Section 3: Trend Chart (Full-width 100%, Dual-line, 2 Tabs) -->
    <DashboardProductionProgressChart v-if="!warehouseId" />

    <!-- Section 4: Hàng Xí nghiệp (50% Bảng Tiến độ + 50% Biểu đồ tròn Phân bổ) -->
    <DashboardFactorySection v-if="!warehouseId" />

    <!-- Section 5: Bảng Tiến độ theo Tổ (Full-width 100%) -->
    <DashboardTeamTable v-if="!warehouseId" />

    <!-- Section 6: Bảng Tiến độ theo Đơn hàng (Full-width 100%) -->
    <DashboardBuyerOrderTable v-if="!warehouseId" />

    <!-- Section 7: Bảng Tiến độ theo LSX / LCĐ (Full-width 100%, 2 Tabs) -->
    <DashboardProductionOrderTable v-if="!warehouseId" />

    <!-- Section 8: Khối Việc Cần Làm To-do (Full-width 100%, 2 Tabs) -->
    <DashboardPendingActions />

    <!-- Section 9: Khối Giám Sát Lỗi Đồng Bộ ERP WFX (Full-width 100%) -->
    <DashboardWfxErrors v-if="!warehouseId" />
  </div>
</template>
