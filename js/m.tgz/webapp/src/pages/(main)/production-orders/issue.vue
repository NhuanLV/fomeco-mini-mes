<script setup lang="ts">
import AllocationTeamResolutionDialog from '@/features/production/components/AllocationTeamResolutionDialog.vue'
import ProductionOrderActionBar from '@/features/production/components/ProductionOrderActionBar.vue'
import ProductionOrderExcelUpload from '@/features/production/components/ProductionOrderExcelUpload.vue'
import ProductionOrderReviewStep from '@/features/production/components/ProductionOrderReviewStep.vue'
import ProductionOrderSetupForm from '@/features/production/components/ProductionOrderSetupForm.vue'
import PurchaseOrderAllocationStep from '@/features/production/components/PurchaseOrderAllocationStep.vue'
import PurchaseOrderSelectionList from '@/features/production/components/PurchaseOrderSelectionList.vue'
import { useProductionOrderIssuance } from '@/features/production/production-order-issuance/useProductionOrderIssuance'

definePage({ meta: { requiredPermission: 'ISSUE_PRODUCTION_ORDER' } })

const {
  store,
  loading,
  boLocked,
  breadcrumbHome,
  breadcrumbItems,
  togglePO,
  toggleAllFiltered,
  stepValue,
  onSubmitSuccess,
  importExcelFile,
  downloadTemplate,
  showTeamResolutionDialog,
  pendingTeamResolutionRows,
  teamResolutionOptionsByRowKey,
  hasIncompleteTeamResolutions,
  updatePendingTeamResolution,
  closeTeamResolutionDialog,
  confirmTeamResolutions,
} = useProductionOrderIssuance()
</script>

<template>
  <div class="flex flex-col gap-4 pb-16">
    <div class="flex w-full items-center justify-between">
      <UBreadcrumb :items="[breadcrumbHome, ...breadcrumbItems]" class="bg-transparent!" />
      <div class="flex items-center gap-2">
        <UButton
          v-if="
            store.isCurrentStep('2') &&
            store.selectedRoutingIndex !== null &&
            store.selectedFactoryIds.length > 0
          "
          label="Tải mẫu Excel"
          color="neutral"
          variant="outline"
          icon="i-lucide-download"
          @click="downloadTemplate"
        />
        <UButton
          v-if="store.isCurrentStep('3')"
          label="Xuất LSX"
          color="success"
          variant="outline"
          icon="i-lucide-download"
          @click="downloadTemplate"
        />
        <UButton
          v-if="store.isCurrentStep('2')"
          label="Phát toàn bộ"
          color="info"
          variant="outline"
          icon="i-lucide-square-check"
          @click="store.quickFillAll"
        />
        <ProductionOrderExcelUpload
          v-if="store.isCurrentStep('2')"
          label="Nhập từ Excel"
          @select-file="importExcelFile"
        />
      </div>
    </div>

    <div v-if="loading && store.factories.length === 0" class="flex justify-center py-16">
      <UIcon name="i-lucide-loader-circle" class="animate-spin text-4xl text-primary" />
    </div>

    <template v-else>
      <div class="w-full">
        <div v-show="stepValue === '1'">
          <ProductionOrderSetupForm :bo-locked="boLocked" />
          <div v-if="store.buyerOrder" class="mt-4">
            <PurchaseOrderSelectionList
              :pos="store.buyerOrder.purchaseOrders"
              :all-sizes="store.allSizes"
              :style-color-order="store.buyerOrder.styleColorOrder"
              :selected-p-o-ids="store.selectedPOIds"
              quantity-field="remainingQuantity"
              show-type-tabs
              @toggle-p-o="togglePO"
              @toggle-all="toggleAllFiltered"
            />
          </div>
        </div>

        <div v-show="stepValue === '2'">
          <PurchaseOrderAllocationStep :on-import-excel="importExcelFile" />
        </div>

        <div v-show="stepValue === '3'">
          <ProductionOrderReviewStep />
        </div>
      </div>
    </template>
  </div>

  <ProductionOrderActionBar @submit-success="onSubmitSuccess" />
  <AllocationTeamResolutionDialog
    :visible="showTeamResolutionDialog"
    :rows="pendingTeamResolutionRows"
    :options-by-row-key="teamResolutionOptionsByRowKey"
    :disabled-confirm="hasIncompleteTeamResolutions"
    @update-selection="updatePendingTeamResolution"
    @close="closeTeamResolutionDialog"
    @confirm="confirmTeamResolutions"
  />
</template>
