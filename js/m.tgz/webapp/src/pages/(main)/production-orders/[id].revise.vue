<script setup lang="ts">
import { reviseAllocation } from '@/api'
import {
  getBuyerOrderDetailQuery,
  getProductionOrderDetailQuery,
  getProductionOrderHistoryQueryKey,
} from '@/api/@pinia/colada.gen'
import { ROUTE_PATH } from '@/app/router/path'
import ProductionOrderAllocationRevisionStep from '@/features/production/allocation-revision/ProductionOrderAllocationRevisionStep.vue'
import ProductionOrderExcelUpload from '@/features/production/components/ProductionOrderExcelUpload.vue'
import ProductionOrderCancelledAlert from '@/features/production/components/ProductionOrderCancelledAlert.vue'
import { useAllocationRevisionDraft } from '@/features/production/allocation-revision/useAllocationRevisionDraft'
import { wfxSyncErrorMessage } from '@/features/production/composables/useOrderSubmit'
import {
  exportRevisionAllocation,
  importRevisionAllocation,
} from '@/features/production/allocation-revision/revisionAllocationExcel'
import { useQuery, useQueryCache } from '@pinia/colada'
import { useEventListener } from '@vueuse/core'
import { computed, onBeforeUnmount, shallowRef } from 'vue'
import { onBeforeRouteLeave, useRoute, useRouter } from 'vue-router'
import { clearLoading, showError, showLoading, showSuccess } from '@/shared/utils/toast'

// Dot syntax keeps /:id/revise independent from the [id].vue detail route.
definePage({ meta: { requiredPermission: 'ISSUE_PRODUCTION_ORDER' } })

const route = useRoute()
const router = useRouter()
const queryCache = useQueryCache()
const id = route.params.id as string
const step = shallowRef('2')
const reason = shallowRef('')
const submitting = shallowRef(false)
const syncError = shallowRef('')
const allowLeave = shallowRef(false)

const { data: order, refetch: refetchOrder } = useQuery(() =>
  getProductionOrderDetailQuery({ path: { id } }),
)
const { data: buyerOrder } = useQuery(() => ({
  ...getBuyerOrderDetailQuery({ path: { id: order.value?.buyerOrderId ?? '' } }),
  enabled: !!order.value?.buyerOrderId,
}))

const draft = useAllocationRevisionDraft({
  visible: () => true,
  order: () => order.value!,
  buyerOrder: () => buyerOrder.value,
})

const breadcrumbHome = { icon: 'i-lucide-house', to: ROUTE_PATH.DASHBOARD }
const breadcrumbItems = computed(() => [
  {
    label: 'Lệnh sản xuất',
    icon: 'i-lucide-clipboard-list',
    to: ROUTE_PATH.PRODUCTION_ORDERS,
  },
  {
    label: order.value?.code ?? '...',
    icon: 'i-lucide-clipboard-pen',
    to: ROUTE_PATH.PRODUCTION_ORDER_DETAIL.replace(':id', id),
  },
  { label: 'Điều chỉnh phân bổ', icon: 'i-lucide-sliders-horizontal' },
])

function goToStep3() {
  if (draft.validationMessages.value.length > 0) {
    showError('Vui lòng xử lý các ràng buộc phân bổ trước khi preview')
    return
  }
  step.value = '3'
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

function backToStep2() {
  step.value = '2'
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

function exportExcel() {
  if (!order.value) return
  exportRevisionAllocation({
    orderCode: order.value.code,
    rowsByOperation: draft.draftRowsByOp.value,
    sizes: draft.allSizes.value,
  })
}

async function importExcel(file: File) {
  try {
    draft.replaceDraft(
      await importRevisionAllocation({
        file,
        currentRowsByOperation: draft.draftRowsByOp.value,
        modes: draft.modes.value,
        sizes: draft.allSizes.value,
      }),
    )
    showSuccess('Đã thay draft bằng snapshot từ Excel')
  } catch (error: unknown) {
    showError(
      `Không thể nhập Excel: ${error instanceof Error ? error.message : 'File không hợp lệ'}`,
    )
  }
}

async function save() {
  if (order.value?.status === 'CANCELLED') return
  const isDirty = draft.isDirty.value
  if (isDirty && !reason.value.trim()) {
    showError('Vui lòng nhập lý do điều chỉnh')
    return
  }
  const payload = draft.createPayload()
  if (!payload || !order.value) return

  submitting.value = true
  syncError.value = ''
  if (isDirty) {
    showLoading('Đang cập nhật FPO/FPPO trên WFX...', 'Đang lưu thay đổi', 'fppo-sync')
  }
  try {
    await reviseAllocation({
      path: { id },
      body: {
        buyerOrderId: order.value.buyerOrderId,
        reason: reason.value.trim(),
        teamAssignments: payload.teamAssignments,
      },
    })
    if (!isDirty) {
      showSuccess('Phân bổ không có thay đổi')
    }
    await queryCache.invalidateQueries({ key: getProductionOrderHistoryQueryKey({ path: { id } }) })
    await refetchOrder()
    allowLeave.value = true
    await router.push(ROUTE_PATH.PRODUCTION_ORDER_DETAIL.replace(':id', id))
  } catch (error: unknown) {
    syncError.value = wfxSyncErrorMessage(error)
  } finally {
    clearLoading('fppo-sync')
    submitting.value = false
  }
}

onBeforeUnmount(() => {
  clearLoading('fppo-sync')
})

function confirmDiscard() {
  return (
    !draft.isDirty.value || window.confirm('Bạn có thay đổi chưa lưu. Bạn có chắc muốn rời trang?')
  )
}

onBeforeRouteLeave(() => allowLeave.value || confirmDiscard())
useEventListener(window, 'beforeunload', (event) => {
  if (!draft.isDirty.value || allowLeave.value) return
  event.preventDefault()
  event.returnValue = ''
})
</script>

<template>
  <div class="flex flex-col gap-4 pb-16">
    <div class="flex items-center justify-between gap-3">
      <UBreadcrumb :items="[breadcrumbHome, ...breadcrumbItems]" class="bg-transparent!" />
      <div v-if="step === '2' && order?.status !== 'CANCELLED'" class="flex items-center gap-2">
        <UButton
          label="Xuất Excel"
          color="neutral"
          variant="outline"
          icon="i-lucide-download"
          @click="exportExcel"
        />
        <UButton
          label="Phát toàn bộ"
          color="info"
          variant="outline"
          icon="i-lucide-square-check"
          @click="draft.quickFillAll"
        />
        <ProductionOrderExcelUpload @select-file="importExcel" />
      </div>
    </div>

    <ProductionOrderCancelledAlert v-if="order?.status === 'CANCELLED'" />
    <div v-else-if="!order || !buyerOrder" class="flex flex-col gap-4">
      <USkeleton height="5rem" border-radius="8px" />
      <USkeleton height="24rem" border-radius="8px" />
    </div>

    <div v-else class="w-full">
      <div v-show="step === '2'">
        <ProductionOrderAllocationRevisionStep
          :draft-rows-by-op="draft.draftRowsByOp.value"
          :active-tab="draft.activeTab.value"
          :assignments-by-operation="draft.assignmentsByOperation.value"
          :all-sizes="draft.allSizes.value"
          :modes="draft.modes.value"
          :validation-messages="draft.validationMessages.value"
          :warning-messages="draft.overAllocatedMessages.value"
          @update:active-tab="draft.activeTab.value = $event"
          @update-row="draft.updateRowData"
          @split-row="draft.splitRow"
          @delete-row="draft.deleteRow"
        />
      </div>

      <div v-show="step === '3'">
        <div class="flex flex-col gap-6">
          <ProductionOrderAllocationRevisionStep
            :draft-rows-by-op="draft.draftRowsByOp.value"
            :active-tab="draft.activeTab.value"
            :assignments-by-operation="draft.assignmentsByOperation.value"
            :all-sizes="draft.allSizes.value"
            :modes="draft.modes.value"
            :validation-messages="draft.validationMessages.value"
            :warning-messages="draft.overAllocatedMessages.value"
            readonly
            @update:active-tab="draft.activeTab.value = $event"
            @update-row="draft.updateRowData"
            @split-row="draft.splitRow"
            @delete-row="draft.deleteRow"
          />

          <div class="flex flex-col gap-2">
            <label for="revisionReason" class="text-sm font-semibold text-default">
              Lý do điều chỉnh
              <span v-if="draft.isDirty.value" class="text-red-500">*</span>
            </label>
            <UTextarea
              id="revisionReason"
              v-model="reason"
              :rows="3"
              autoresize
              placeholder="Nhập lý do điều chỉnh phân bổ..."
            />
          </div>
        </div>
      </div>
    </div>
  </div>

  <div
    v-if="order && buyerOrder && order.status !== 'CANCELLED'"
    class="fixed right-0 bottom-0 left-0 z-10 border-t border-surface-200 bg-surface-0 px-4 py-3 shadow-lg"
  >
    <UAlert
      v-if="syncError"
      role="alert"
      color="error"
      icon="i-lucide-triangle-alert"
      :description="syncError"
      class="mb-3"
    />
    <div class="flex items-center justify-between gap-3">
      <UButton
        color="neutral"
        variant="ghost"
        size="sm"
        icon="i-lucide-arrow-left"
        :label="step === '3' ? 'Sửa lại' : 'Hủy'"
        @click="
          step === '3'
            ? backToStep2()
            : router.push(ROUTE_PATH.PRODUCTION_ORDER_DETAIL.replace(':id', id))
        "
      />
      <UButton
        v-if="step === '2'"
        icon="i-lucide-eye"
        label="Preview"
        size="sm"
        :disabled="draft.validationMessages.value.length > 0"
        @click="goToStep3"
      />
      <UButton
        v-else
        icon="i-lucide-save"
        :label="syncError ? 'Thử lại và Lưu' : 'Lưu thay đổi'"
        size="sm"
        raised
        :loading="submitting"
        :disabled="draft.isDirty.value && !reason.trim()"
        @click="save"
      />
    </div>
  </div>
</template>
