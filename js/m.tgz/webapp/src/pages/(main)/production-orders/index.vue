<script setup lang="ts">
import type { ProductionOrderFilterOptionsVm, UnitVm } from '@/api'
import {
  getProductionOrderFilterOptionsQuery,
  getProductionOrdersQuery,
  getTreeQuery,
} from '@/api/@pinia/colada.gen'
import PurchaseOrderDataTable from '@/features/production/components/PurchaseOrderDataTable.vue'
import { getStatusLabel } from '@/features/production/helpers/productionOrder'
import ColumnMultiSelectFilter from '@/shared/components/ColumnMultiSelectFilter.vue'
import type { SelectOption } from '@/shared/types'
import { useQuery } from '@pinia/colada'
import dayjs from 'dayjs'
import AppTreeSelect from '@/shared/components/AppTreeSelect.vue'
import { computed, ref, watch } from 'vue'

definePage({ meta: { requiredPermission: 'VIEW_PRODUCTION_ORDER' } })

// ── Org tree for the unit filter ─────────────────────────────────────────────
const { data: treeResult } = useQuery(getTreeQuery())

type UnitTreeNode = { key: string; label: string; data: UnitVm; children: UnitTreeNode[] }

const buildTreeNodes = (unit: UnitVm): UnitTreeNode => ({
  key: unit.id,
  label: unit.name,
  data: unit,
  children: unit.children?.map(buildTreeNodes) ?? [],
})

const unitNodes = computed<UnitTreeNode[]>(() => {
  const treeData = treeResult.value
  if (!treeData) return []
  const trees = Array.isArray(treeData) ? treeData : [treeData]
  return trees.map((tree) => buildTreeNodes(tree as UnitVm))
})

// ── Filter state ──────────────────────────────────────────────────────────────
const selectedUnit = ref<Record<string, boolean> | null>(null)
const unitId = computed(() => {
  const keys = Object.keys(selectedUnit.value ?? {})
  return keys.length > 0 ? keys[0] : undefined
})

// ── Pagination state ──────────────────────────────────────────────────────────────
const currentPage = ref(0)
const pageSize = ref(10)

// ── Column filter state ───────────────────────────────────────────────────────────
const styleFilter = ref<string[]>([])
const boWfxIdFilter = ref<string[]>([])
const productionOrderIdFilter = ref<string[]>([])
const factoryIdFilter = ref<string[]>([])
const firstSkuFilter = ref<string[]>([])
const statusFilter = ref<string[]>([])
const poFilter = ref<string[]>([])
const sewingTeamIdsFilter = ref<string[]>([])
const deliveryDateRange = ref<Date[] | null>(null)
const syncDateRange = ref<Date[] | null>(null)
const productDateRange = ref<Date[] | null>(null)
const createdAtRange = ref<Date[] | null>(null)

// ── Production orders query ──────────────
const { data, isLoading: loading } = useQuery(() =>
  getProductionOrdersQuery({
    query: {
      unitId: unitId.value,
      styleName: styleFilter.value.length > 0 ? styleFilter.value : undefined,
      boCode: boWfxIdFilter.value.length > 0 ? boWfxIdFilter.value : undefined,
      productionOrderId:
        productionOrderIdFilter.value.length > 0 ? productionOrderIdFilter.value : undefined,
      factoryId: factoryIdFilter.value.length > 0 ? factoryIdFilter.value : undefined,
      firstSku: firstSkuFilter.value.length > 0 ? firstSkuFilter.value : undefined,
      status: statusFilter.value.length > 0 ? statusFilter.value : undefined,
      poCode: poFilter.value.length > 0 ? poFilter.value : undefined,
      sewingTeamIds: sewingTeamIdsFilter.value.length > 0 ? sewingTeamIdsFilter.value : undefined,
      deliveryDateFrom:
        deliveryDateRange.value?.[0] && deliveryDateRange.value?.[1]
          ? dayjs(deliveryDateRange.value[0]).format('YYYY-MM-DD')
          : undefined,
      deliveryDateTo:
        deliveryDateRange.value?.[0] && deliveryDateRange.value?.[1]
          ? dayjs(deliveryDateRange.value[1]).format('YYYY-MM-DD')
          : undefined,
      syncDateFrom:
        syncDateRange.value?.[0] && syncDateRange.value?.[1]
          ? dayjs(syncDateRange.value[0]).format('YYYY-MM-DD')
          : undefined,
      syncDateTo:
        syncDateRange.value?.[0] && syncDateRange.value?.[1]
          ? dayjs(syncDateRange.value[1]).format('YYYY-MM-DD')
          : undefined,
      productDateFrom:
        productDateRange.value?.[0] && productDateRange.value?.[1]
          ? dayjs(productDateRange.value[0]).format('YYYY-MM-DD')
          : undefined,
      productDateTo:
        productDateRange.value?.[0] && productDateRange.value?.[1]
          ? dayjs(productDateRange.value[1]).format('YYYY-MM-DD')
          : undefined,
      createdAtFrom:
        createdAtRange.value?.[0] && createdAtRange.value?.[1]
          ? dayjs(createdAtRange.value[0]).format('YYYY-MM-DD')
          : undefined,
      createdAtTo:
        createdAtRange.value?.[0] && createdAtRange.value?.[1]
          ? dayjs(createdAtRange.value[1]).format('YYYY-MM-DD')
          : undefined,
      page: currentPage.value,
      size: pageSize.value,
      sort: [],
    },
  }),
)

const { data: filterOptionsResponse } = useQuery(getProductionOrderFilterOptionsQuery())

const orders = computed(() => data.value?.content ?? [])
const totalRecords = computed(() => data.value?.page?.totalElements ?? 0)
const filterOptions = computed<ProductionOrderFilterOptionsVm>(
  () =>
    filterOptionsResponse.value ?? {
      boWfxIds: [],
      productionOrderCodes: [],
      styles: [],
      factories: [],
      firstSkus: [],
      statuses: [],
      poCodes: [],
      sewingTeams: [],
    },
)

// ── Filter options ──────────────────────────────────────────────────────
const styleOptions = computed<SelectOption[]>(() =>
  filterOptions.value.styles.map((style) => ({ label: style, value: style })),
)

const boWfxIdOptions = computed<SelectOption[]>(() =>
  filterOptions.value.boWfxIds.map((id) => ({ label: id, value: id })),
)

const statusOptions = computed<SelectOption[]>(() =>
  filterOptions.value.statuses.map((status) => ({
    label: getStatusLabel(status),
    value: status,
  })),
)

const productionOrderOptions = computed<SelectOption[]>(() =>
  filterOptions.value.productionOrderCodes.map((code) => ({ label: code, value: code })),
)

const factoryOptions = computed<SelectOption[]>(() =>
  filterOptions.value.factories.map((factory) => ({
    label: factory.unitPath || factory.name,
    value: factory.id,
  })),
)

const firstSkuOptions = computed<SelectOption[]>(() =>
  filterOptions.value.firstSkus.map((firstSku) => ({ label: firstSku, value: firstSku })),
)

const poOptions = computed<SelectOption[]>(() => {
  return filterOptions.value.poCodes.map((po) => ({ label: po, value: po }))
})

const sewingTeamOptions = computed<SelectOption[]>(() =>
  filterOptions.value.sewingTeams.map((team) => ({ label: team.name, value: team.id })),
)

watch(
  [
    unitId,
    styleFilter,
    boWfxIdFilter,
    productionOrderIdFilter,
    factoryIdFilter,
    firstSkuFilter,
    statusFilter,
    poFilter,
    sewingTeamIdsFilter,
    deliveryDateRange,
    syncDateRange,
    productDateRange,
    createdAtRange,
  ],
  () => {
    currentPage.value = 0
  },
  { deep: true },
)

// ── Handlers ────────────────────────────────────────────────────────────
function onPageChange(event: { page: number; rows: number }) {
  currentPage.value = event.page
  pageSize.value = event.rows
}

function handleFilterChange(field: string, value: Date[] | null) {
  if (field === 'syncDate') syncDateRange.value = value as Date[] | null
  if (field === 'productDate') productDateRange.value = value as Date[] | null
  if (field === 'createdAt') createdAtRange.value = value as Date[] | null
  if (field === 'deliveryDate') deliveryDateRange.value = value as Date[] | null
}
</script>

<template>
  <div class="flex flex-col gap-4">
    <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
      <UBreadcrumb
        :items="[
          { icon: 'i-lucide-house' },
          ...[{ label: 'Lệnh sản xuất', icon: 'i-lucide-clipboard-list' }],
        ]"
        class="bg-transparent!"
      />
      <div class="flex flex-col gap-3 sm:items-end">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center">
          <AppTreeSelect
            v-model="selectedUnit"
            :options="unitNodes"
            placeholder="Tất cả đơn vị"
            class="w-full sm:w-72"
          />
          <ColumnMultiSelectFilter
            v-model="poFilter"
            :items="poOptions"
            placeholder="PO"
            class="w-full sm:w-72"
          />
        </div>
      </div>
    </div>

    <!-- Orders table -->
    <UCard>
      <template #default>
        <PurchaseOrderDataTable
          :orders="orders"
          :loading="loading"
          :total-records="totalRecords"
          :current-page="currentPage"
          :page-size="pageSize"
          :style-options="styleOptions"
          :bo-wfx-id-options="boWfxIdOptions"
          :production-order-options="productionOrderOptions"
          :factory-options="factoryOptions"
          :first-sku-options="firstSkuOptions"
          :status-options="statusOptions"
          :sewing-team-options="sewingTeamOptions"
          v-model:style-filter="styleFilter"
          v-model:bo-wfx-id-filter="boWfxIdFilter"
          v-model:production-order-id-filter="productionOrderIdFilter"
          v-model:factory-id-filter="factoryIdFilter"
          v-model:first-sku-filter="firstSkuFilter"
          v-model:status-filter="statusFilter"
          v-model:sewing-team-ids-filter="sewingTeamIdsFilter"
          v-model:delivery-date-range="deliveryDateRange"
          v-model:sync-date-range="syncDateRange"
          v-model:product-date-range="productDateRange"
          v-model:created-at-range="createdAtRange"
          @filter-change="handleFilterChange"
          @page="onPageChange"
        />
      </template>
    </UCard>
  </div>
</template>
