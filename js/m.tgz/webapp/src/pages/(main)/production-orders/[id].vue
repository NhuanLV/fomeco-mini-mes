<script setup lang="ts">
import { fmtQty } from '@/shared/utils/fmtQty'
import { formatDate } from '@/shared/utils/date'
import { formatFactoryHierarchy } from '@/shared/utils/orgUnit'
import { handleRowNavigation, handleTableAuxClick } from '@/shared/utils/navigation'
import type { TeamAssignmentVm } from '@/api'
import ProductionOrderHistoryTable from '@/features/production/components/ProductionOrderHistoryTable.vue'
import ProductionOrderCancellation from '@/features/production/components/ProductionOrderCancellation.vue'
import ProductionOrderCancelledAlert from '@/features/production/components/ProductionOrderCancelledAlert.vue'
import { useIntervalFn } from '@vueuse/core'
import {
  getProductionOrderHistoryQuery,
  getBuyerOrderDetailQuery,
  getProductionOrderDetailQuery,
} from '@/api/@pinia/colada.gen'
import { ROUTE_PATH } from '@/app/router/path'
import {
  getProductionOrderNumber,
  getProductionOrderStyleName,
} from '@/features/production/helpers/productionOrder'
import {
  hasNeedsAdjustment,
  needsAllocationRevision,
  needsAdjustment,
} from '@/features/production/helpers/reconciliation'
import { exportProductionOrderToExcel } from '@/features/production/helpers/productionOrderExporter'
import { useQuery, useQueryCache } from '@pinia/colada'
import type { TableColumn, TableRow } from '@nuxt/ui'
import dayjs from 'dayjs'
import { computed, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/shared/stores/auth'

definePage({ meta: { requiredAnyPermission: ['VIEW_PRODUCTION_ORDER', 'ISSUE_PRODUCTION_ORDER'] } })

const router = useRouter()
const queryCache = useQueryCache()

const route = useRoute()
const id = route.params.id as string

const {
  data: order,
  isLoading: loading,
  refetch: refetchOrder,
} = useQuery(() => getProductionOrderDetailQuery({ path: { id } }))

const {
  data: history,
  isLoading: historyLoading,
  error: historyError,
  refetch: refetchHistory,
} = useQuery(() => ({
  ...getProductionOrderHistoryQuery({ path: { id } }),
  enabled: !!order.value,
}))

async function refreshCancellation() {
  const previousStatus = order.value?.status
  await Promise.all([refetchOrder(), refetchHistory()])
  if (order.value?.status === 'CANCELLED' && previousStatus !== 'CANCELLED') {
    await Promise.all(
      ['getBuyerOrderDetail', 'getBuyerOrders', 'getProductionOrders', 'getMyAssignments'].map(
        (_id) => queryCache.invalidateQueries({ key: [{ _id }] }),
      ),
    )
  }
}
useIntervalFn(() => {
  if (history.value?.some((row) => row.action === 'CANCEL' && row.syncStatus === 'PENDING'))
    void refreshCancellation()
}, 2000)

function totalQty(ta: TeamAssignmentVm) {
  return ta.allocations.reduce((sum, a) => sum + a.quantity, 0)
}

function completionRate(ta: TeamAssignmentVm) {
  const total = totalQty(ta)
  return total > 0 ? Math.round((ta.totalReported / total) * 100) : 0
}

function statusSeverity(status: string) {
  if (status === 'COMPLETED') return 'success'
  if (status === 'IN_PROGRESS') return 'info'
  return 'neutral'
}

function statusLabel(status: string) {
  if (status === 'CANCELLED') return 'Đã hủy'
  if (status === 'COMPLETED') return 'Hoàn thành'
  if (status === 'IN_PROGRESS') return 'Đang thực hiện'
  return status
}

const referenceAssignment = computed(() => order.value?.teamAssignments[0])

const uniqueColors = computed(() => {
  if (!referenceAssignment.value) return []
  return [...new Set(referenceAssignment.value.allocations.map((a) => a.color))]
})

const uniqueSizes = computed(() => {
  if (!referenceAssignment.value) return []
  return [...new Set(referenceAssignment.value.allocations.map((a) => a.size))]
})

const breadcrumbHome = { icon: 'i-lucide-house', to: ROUTE_PATH.DASHBOARD }
const breadcrumbItems = computed(() => [
  {
    label: 'Lệnh sản xuất',
    icon: 'i-lucide-clipboard-list',
    to: ROUTE_PATH.PRODUCTION_ORDERS,
  },
  { label: order.value?.code ?? '...', icon: 'i-lucide-clipboard-pen' },
])

const { data: buyerOrder } = useQuery(() => ({
  ...getBuyerOrderDetailQuery({ path: { id: order.value?.buyerOrderId ?? '' } }),
  enabled: !!order.value?.buyerOrderId,
}))

const handleExport = async () => {
  if (order.value) {
    await exportProductionOrderToExcel(order.value, buyerOrder.value)
  }
}

const { hasPermission } = useAuthStore()

const showOnlyNeedsAdjustment = ref(route.query.reconciliation === 'needs-adjustment')

const displayedTeamAssignments = computed(() => {
  const assignments = order.value?.teamAssignments ?? []
  if (!showOnlyNeedsAdjustment.value || !hasNeedsAdjustment(order.value)) return assignments
  return assignments.filter(needsAdjustment)
})
const columns: TableColumn<TeamAssignmentVm>[] = [
  {
    accessorKey: 'operation',
    header: 'Công đoạn',
    meta: { class: { th: 'min-w-32', td: 'min-w-32' } },
  },
  {
    id: 'team',
    header: 'Tổ',
    meta: { class: { th: 'min-w-48', td: 'min-w-48' } },
  },
  {
    id: 'assignedQuantity',
    header: 'Sản lượng giao',
    meta: { class: { th: 'min-w-28 text-center', td: 'min-w-28 text-center' } },
  },
  {
    id: 'plannedStartDate',
    header: 'Dự kiến bắt đầu',
    meta: { class: { th: 'min-w-32 text-center', td: 'min-w-32 text-center' } },
  },
  {
    id: 'plannedEndDate',
    header: 'Dự kiến hoàn thành',
    meta: { class: { th: 'min-w-32 text-center', td: 'min-w-32 text-center' } },
  },
  {
    accessorKey: 'totalReported',
    header: 'Hoàn thành',
    meta: { class: { th: 'min-w-28 text-center', td: 'min-w-28 text-center' } },
  },
  {
    id: 'progress',
    header: 'Tiến độ',
    meta: { class: { th: 'min-w-32', td: 'min-w-32' } },
  },
]

function assignmentRowClass(assignment: TeamAssignmentVm) {
  return needsAdjustment(assignment) ? 'bg-red-50!' : ''
}

function selectAssignment(event: Event, row: TableRow<TeamAssignmentVm>) {
  handleRowNavigation(event, router, {
    path: ROUTE_PATH.TEAM_ASSIGNMENT_DETAIL.replace(':id', row.original.id),
    query: { from: 'production-order' },
  })
}

function handleAuxClick(event: MouseEvent) {
  handleTableAuxClick(event, router, displayedTeamAssignments.value, (row) => ({
    path: ROUTE_PATH.TEAM_ASSIGNMENT_DETAIL.replace(':id', row.id),
    query: { from: 'production-order' },
  }))
}
</script>

<template>
  <!-- Loading skeletons -->
  <div v-if="loading" class="flex flex-col gap-4">
    <USkeleton height="5rem" border-radius="8px" />
    <USkeleton height="5rem" border-radius="8px" />
    <USkeleton height="20rem" border-radius="8px" />
  </div>

  <div v-else-if="order" class="flex flex-col gap-4">
    <ProductionOrderCancellation :order="order" :history="history" @refresh="refreshCancellation">
      <template #actions="{ canCancel, disabled, open }">
        <div class="flex items-center justify-between">
          <UBreadcrumb :items="[breadcrumbHome, ...breadcrumbItems]" class="bg-transparent!" />
          <div class="flex items-center gap-2">
            <UButton
              v-if="canCancel"
              label="Hủy LSX"
              icon="i-lucide-trash-2"
              color="error"
              size="md"
              class="shrink-0"
              :disabled="disabled"
              @click="open"
            />
            <UButton
              v-if="order.status !== 'CANCELLED' && hasPermission('ISSUE_PRODUCTION_ORDER')"
              label="Điều chỉnh phân bổ"
              icon="i-lucide-pencil"
              color="warning"
              size="md"
              class="shrink-0"
              :to="ROUTE_PATH.PRODUCTION_ORDER_REVISE.replace(':id', id)"
            />
            <UButton
              label="Xuất LSX"
              icon="i-lucide-file-spreadsheet"
              color="success"
              size="md"
              class="shrink-0"
              @click="handleExport"
            />
          </div>
        </div>
      </template>
    </ProductionOrderCancellation>
    <ProductionOrderCancelledAlert v-if="order.status === 'CANCELLED'" />

    <UCard>
      <template #default>
        <div
          class="grid grid-cols-2 gap-x-2 gap-y-4 sm:flex sm:flex-wrap sm:justify-between sm:gap-4"
        >
          <div class="min-w-0">
            <p class="text-[10px] font-medium text-toned uppercase">Trạng thái</p>
            <div class="mt-1 flex flex-wrap gap-2">
              <UBadge :label="statusLabel(order.status)" :color="statusSeverity(order.status)" />
              <UBadge
                v-if="needsAllocationRevision(order)"
                label="Cần chỉnh phân bổ"
                color="warning"
                icon="i-lucide-pencil"
              />
            </div>
          </div>
          <div class="min-w-0">
            <p class="text-[10px] font-medium text-toned uppercase">Mã hàng</p>
            <p class="truncate font-semibold text-highlighted sm:text-lg">
              {{ getProductionOrderStyleName(order.code) }}
            </p>
          </div>
          <div class="min-w-0">
            <p class="text-[10px] font-medium text-toned uppercase">Số lệnh</p>
            <p class="font-semibold text-highlighted sm:text-lg">
              {{ getProductionOrderNumber(order.code) }}
            </p>
          </div>
          <div class="min-w-0">
            <p class="text-[10px] font-medium text-toned uppercase">Đơn hàng</p>
            <RouterLink
              v-if="order.buyerOrderId"
              :to="`/buyer-orders/${order.buyerOrderId}`"
              class="block truncate font-semibold text-highlighted hover:text-primary hover:underline sm:text-lg"
            >
              {{ order.boWfxId }}
            </RouterLink>
            <p v-else class="truncate font-semibold text-highlighted sm:text-lg">
              {{ order.boWfxId }}
            </p>
          </div>
          <div class="col-span-2 min-w-0 sm:col-span-1">
            <p class="text-[10px] font-medium text-toned uppercase">Xí nghiệp</p>
            <div class="mt-1 flex flex-wrap gap-1">
              <template v-if="order.factories && order.factories.length > 0">
                <UBadge
                  v-for="f in order.factories"
                  :key="f.id"
                  :label="f.unitPath || f.name"
                  color="neutral"
                  class="text-[10px]"
                />
              </template>
              <p v-else class="font-medium text-highlighted">---</p>
            </div>
          </div>
          <div class="min-w-0">
            <p class="text-[10px] font-medium text-toned uppercase">Công ty đảm nhiệm chính</p>
            <p class="truncate font-semibold text-highlighted sm:text-lg">
              {{ order.mainCompanyCode }}
            </p>
          </div>
          <div class="min-w-0">
            <p class="text-[10px] font-medium text-toned uppercase">Màu / Size</p>
            <p class="font-semibold text-highlighted">
              {{ uniqueColors.length }} màu × {{ uniqueSizes.length }} size
            </p>
          </div>
          <div class="min-w-0">
            <p class="text-[10px] font-medium text-toned uppercase">Ngày tạo</p>
            <p class="text-xs font-semibold text-highlighted sm:text-sm">
              {{ dayjs(order.createdAt).format('HH:mm, DD/MM/YYYY') }}
            </p>
          </div>
          <div class="min-w-0">
            <p class="text-[10px] font-medium text-toned uppercase">Số tổ</p>
            <p class="font-semibold text-highlighted">{{ order.teamAssignments.length }}</p>
          </div>
        </div>
      </template>
    </UCard>

    <UCard>
      <template #title>
        <div class="flex flex-wrap items-center gap-2">
          <UIcon name="i-lucide-users" class="text-primary" />
          <span class="font-semibold text-default">Phân công sản xuất</span>
          <UBadge
            v-if="hasNeedsAdjustment(order)"
            label="Cần điều chỉnh PO"
            color="error"
            icon="i-lucide-triangle-alert"
          />
          <UButton
            v-if="hasNeedsAdjustment(order)"
            :label="showOnlyNeedsAdjustment ? 'Hiển thị tất cả' : 'Chỉ phân công cần xử lý'"
            color="error"
            size="sm"
            variant="ghost"
            @click="showOnlyNeedsAdjustment = !showOnlyNeedsAdjustment"
          />
        </div>
      </template>
      <template #default>
        <UTable
          :data="displayedTeamAssignments"
          :columns="columns"
          :ui="{ tr: 'cursor-pointer', th: 'text-highlighted', td: 'text-default' }"
          @select="selectAssignment"
          @auxclick="handleAuxClick"
        >
          <template #operation-cell="{ row }">
            <RouterLink
              :to="{
                path: ROUTE_PATH.TEAM_ASSIGNMENT_DETAIL.replace(':id', row.original.id),
                query: { from: 'production-order' },
              }"
              class="font-medium hover:text-primary hover:underline"
              @click.stop
            >
              {{ row.original.operation }}
            </RouterLink>
          </template>

          <template #team-cell="{ row }">
            <div :class="['flex min-w-48 flex-col', assignmentRowClass(row.original)]">
              <RouterLink
                :to="{
                  path: ROUTE_PATH.TEAM_ASSIGNMENT_DETAIL.replace(':id', row.original.id),
                  query: { from: 'production-order' },
                }"
                class="font-medium hover:text-primary hover:underline"
                @click.stop
              >
                {{ row.original.teamName }}
              </RouterLink>
              <span class="text-[10px] text-toned">{{
                formatFactoryHierarchy(row.original.factoryName, row.original.companyName)
              }}</span>
              <span
                v-if="needsAdjustment(row.original)"
                class="mt-1 text-[10px] font-semibold text-red-600"
              >
                Cần phòng kế hoạch điều chỉnh PO
              </span>
            </div>
          </template>

          <template #assignedQuantity-cell="{ row }">
            {{ fmtQty(totalQty(row.original)) }}
          </template>

          <template #plannedStartDate-cell="{ row }">
            {{ formatDate(row.original.plannedStartDate) || '---' }}
          </template>

          <template #plannedEndDate-cell="{ row }">
            {{ formatDate(row.original.plannedEndDate) || '---' }}
          </template>

          <template #totalReported-cell="{ row }">
            {{ fmtQty(row.original.totalReported) }}
          </template>

          <template #progress-cell="{ row }">
            <div class="flex min-w-32 flex-col gap-1">
              <span class="text-[10px] font-bold">{{ completionRate(row.original) }}%</span>
              <UProgress :model-value="completionRate(row.original)" class="h-1.5!" />
            </div>
          </template>
        </UTable>
      </template>
    </UCard>
    <ProductionOrderHistoryTable
      :history="history"
      :loading="historyLoading"
      :error="!!historyError"
    />
  </div>
</template>
