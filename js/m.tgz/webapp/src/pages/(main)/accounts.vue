<script setup lang="ts">
import type { AccountVm, MembershipVm, UnitVm } from '@/api'
import { deleteAccountMutation, getAccountsQuery, getTreeQuery } from '@/api/@pinia/colada.gen'
import AccountViewDialog from '@/features/account/components/AccountViewDialog.vue'
import ChangePasswordDialog from '@/features/account/components/ChangePasswordDialog.vue'
import CreateAccountForm from '@/features/account/components/CreateAccountForm.vue'
import UpdateMemberInfoForm from '@/features/account/components/UpdateMemberInfoForm.vue'
import { ADMIN_ROLE_ID } from '@/features/account/helpers/iam'
import { useAuthStore } from '@/shared/stores/auth'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useMutation, useQuery } from '@pinia/colada'
import { useConfirm } from '@/shared/composables/useConfirm'
import type { TableColumn, TableRow } from '@nuxt/ui'
import { refDebounced } from '@vueuse/core'
import { computed, ref, watch } from 'vue'
import { useRouter } from 'vue-router'

definePage({ meta: { requiredPermission: 'MANAGE_ACCOUNT' } })

const confirm = useConfirm()
const { hasPermission, checkAuth } = useAuthStore()
const router = useRouter()

// Search & Pagination state
const search = ref('')
const searchDebounced = refDebounced(search, 300)
const page = ref(1)
const pageSize = ref(20)

watch(searchDebounced, () => {
  page.value = 1
})

watch(pageSize, () => {
  page.value = 1
})

// Unit filter state
const { data: treeData } = useQuery(getTreeQuery())

interface UnitOption {
  id: string
  name: string
  type: string
  path: string
}

function extractUnitOptions(units: UnitVm[], ancestors: UnitVm[] = []): UnitOption[] {
  const result: UnitOption[] = []

  for (const unit of units) {
    const relevantAncestors = ancestors.filter((a) => a.type !== 'CORPORATION')
    const pathParts = [unit.name, ...relevantAncestors.map((a) => a.name)]
    const path = pathParts.join(' — ')

    result.push({
      id: unit.id,
      name: unit.name,
      type: unit.type,
      path,
    })

    if (unit.children && unit.children.length > 0) {
      result.push(...extractUnitOptions(unit.children, [unit, ...ancestors]))
    }
  }

  return result
}

const allUnitOptions = computed<UnitOption[]>(() => {
  if (!treeData.value) return []
  const trees = Array.isArray(treeData.value) ? treeData.value : [treeData.value]
  return extractUnitOptions(trees as UnitVm[])
})

const isUnitFilterOpen = ref(false)
const selectedUnitId = ref<string | null>(null)
const unitSearch = ref('')

function matchesSearch(text: string, term: string) {
  const normText = text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
  const normTerm = term
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
  return text.toLowerCase().includes(term.toLowerCase()) || normText.includes(normTerm)
}

const filteredUnitOptions = computed(() => {
  const term = unitSearch.value.trim()
  if (!term) return allUnitOptions.value
  return allUnitOptions.value.filter((u) => matchesSearch(u.path, term))
})

const selectedUnit = computed(() => {
  if (!selectedUnitId.value) return null
  return allUnitOptions.value.find((u) => u.id === selectedUnitId.value) || null
})

const selectUnit = (id: string | null) => {
  selectedUnitId.value = id
  isUnitFilterOpen.value = false
  page.value = 1
}

// Queries
const { data, status, refetch } = useQuery(() => ({
  ...getAccountsQuery({
    query: {
      page: page.value - 1,
      size: pageSize.value,
      search: searchDebounced.value.trim() || undefined,
      unitId: selectedUnitId.value || undefined,
    },
  }),
}))

const isLoading = computed(() => status.value === 'pending')
const accounts = computed(() => data.value?.content ?? [])
const totalRecords = computed(() => data.value?.page?.totalElements ?? 0)

watch(totalRecords, (newTotal) => {
  const maxPage = Math.max(1, Math.ceil(newTotal / pageSize.value))
  if (page.value > maxPage) {
    page.value = maxPage
  }
})

// Mutations
const { mutateAsync: deleteMutate } = useMutation(deleteAccountMutation())

// Dialog Visibilities
const showCreateForm = ref(false)
const showUpdateMembershipForm = ref(false)
const showChangePasswordDialog = ref(false)
const showViewDialog = ref(false)

const selectedAccount = ref<AccountVm | null>(null)
const selectedMembership = ref<MembershipVm | null>(null)

type FlattenedAccount = AccountVm & {
  _membership: MembershipVm | null
  _groupStart: boolean
  _groupSize: number
  isAdmin: boolean
}

const groupedAccountCellMeta = {
  rowspan: {
    td: ({ row }) => (row.original._groupStart ? String(row.original._groupSize) : '1'),
  },
  class: {
    td: ({ row }) => (row.original._groupStart ? 'align-middle' : 'hidden'),
  },
} satisfies NonNullable<TableColumn<FlattenedAccount>['meta']>

const columns: TableColumn<FlattenedAccount>[] = [
  { accessorKey: 'name', header: 'Họ và tên', meta: groupedAccountCellMeta },
  { accessorKey: 'username', header: 'Tài khoản', meta: groupedAccountCellMeta },
  { id: 'membership', header: 'Đơn vị phân công' },
  { id: 'roles', header: 'Vai trò' },
  { id: 'actions', header: 'Thao tác' },
]

const flattenedAccounts = computed<FlattenedAccount[]>(() => {
  return [...accounts.value]
    .sort((left, right) => left.name.localeCompare(right.name, 'vi'))
    .flatMap((account): FlattenedAccount[] => {
      const isAdmin = account.memberships.some((m) => m.roles.some((r) => r.id === ADMIN_ROLE_ID))
      if (account.memberships.length === 0) {
        return [
          {
            ...account,
            _membership: null,
            _groupStart: true,
            _groupSize: 1,
            isAdmin,
          },
        ]
      }
      return account.memberships.map((m, index) => ({
        ...account,
        _membership: m,
        _groupStart: index === 0,
        _groupSize: account.memberships.length,
        isAdmin,
      }))
    })
})

const openNew = () => {
  showCreateForm.value = true
}

const openEditForm = (account: AccountVm) => {
  selectedAccount.value = account
  showUpdateMembershipForm.value = true
}

const openViewForm = (row: FlattenedAccount) => {
  selectedAccount.value = row
  selectedMembership.value = row._membership
  showViewDialog.value = true
}

const selectAccount = (_event: Event, row: TableRow<FlattenedAccount>) => openViewForm(row.original)

const openChangePassword = (account: AccountVm) => {
  selectedAccount.value = account
  showChangePasswordDialog.value = true
}

const confirmDeleteAccount = (account: AccountVm) => {
  confirm.require({
    message: `Bạn có chắc chắn muốn xóa tài khoản "${account.name}"?`,
    header: 'Xác nhận xóa tài khoản',
    icon: 'i-lucide-triangle-alert',
    acceptProps: { color: 'error' },
    accept: async () => {
      try {
        await deleteMutate({ path: { id: account.id } })
        showSuccess('Tài khoản đã được xóa')
        onAccountSaved()
      } catch (error: unknown) {
        showError((error as Error).message || 'Không thể xóa tài khoản')
      }
    },
  })
}

const onAdminTransferred = async () => {
  showSuccess('Đang cập nhật lại hệ thống...')
  await checkAuth()
  router.push('/')
}

const onAccountSaved = () => {
  refetch()
}

const getVisibleRoles = (membership: MembershipVm, limit = 2) => membership.roles.slice(0, limit)
const getHiddenRoleCount = (membership: MembershipVm, limit = 2) =>
  Math.max(membership.roles.length - limit, 0)

const getAvatarInitials = (name?: string | null) =>
  name?.trim().split(' ').pop()?.charAt(0).toUpperCase() || 'U'
</script>

<template>
  <div class="flex h-full flex-col gap-4">
    <div class="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
      <UBreadcrumb
        :items="[
          { icon: 'i-lucide-house' },
          ...[{ label: 'Quản lý Tài khoản', icon: 'i-lucide-users' }],
        ]"
        class="bg-transparent!"
      />
      <div class="flex w-full items-center gap-2 sm:w-auto">
        <UInput
          v-model="search"
          icon="i-lucide-search"
          placeholder="Tìm theo tên hoặc tài khoản..."
          class="w-full sm:w-64"
        />
        <UButton
          v-if="hasPermission('MANAGE_ACCOUNT')"
          @click="openNew"
          size="sm"
          icon="i-lucide-plus"
          label="Thêm mới"
          class="shrink-0"
        />
      </div>
    </div>

    <UCard>
      <template #default>
        <UTable
          :data="flattenedAccounts"
          :columns="columns"
          :loading="isLoading"
          class="text-xs sm:text-sm"
          :ui="{ tr: 'cursor-pointer' }"
          @select="selectAccount"
        >
          <template #name-cell="{ row }">
            <UUser
              :name="row.original.name"
              :description="row.original.isAdmin ? 'Super Admin' : undefined"
              :avatar="{
                src: row.original.avatar || undefined,
                text: getAvatarInitials(row.original.name),
              }"
            />
          </template>

          <template #username-cell="{ row }">
            <span class="font-mono text-xs text-toned">{{ row.original.username }}</span>
          </template>

          <template #membership-header>
            <UPopover
              v-model:open="isUnitFilterOpen"
              :content="{ align: 'start', side: 'bottom', sideOffset: 8 }"
              class="w-full"
            >
              <button
                type="button"
                class="group flex w-full cursor-pointer items-center justify-between gap-1.5 py-1 text-left select-none"
              >
                <div class="flex min-w-0 items-center gap-1.5">
                  <span
                    class="text-xs font-semibold transition-colors sm:text-sm"
                    :class="
                      selectedUnitId ? 'text-primary' : 'text-highlighted group-hover:text-primary'
                    "
                  >
                    Đơn vị phân công
                  </span>
                  <UBadge
                    v-if="selectedUnit"
                    size="xs"
                    color="primary"
                    variant="subtle"
                    class="max-w-36 truncate"
                    :title="selectedUnit.path"
                  >
                    {{ selectedUnit.name }}
                  </UBadge>
                </div>
                <div class="flex shrink-0 items-center gap-1">
                  <UIcon
                    v-if="selectedUnitId"
                    name="i-lucide-x"
                    class="h-3.5 w-3.5 text-muted transition-colors hover:text-error"
                    title="Bỏ lọc đơn vị"
                    @click.stop="selectUnit(null)"
                  />
                  <UIcon
                    name="i-lucide-filter"
                    class="h-4 w-4 transition-colors"
                    :class="
                      selectedUnitId ? 'text-primary' : 'group-hover:text-foreground text-muted'
                    "
                  />
                </div>
              </button>

              <template #content>
                <div class="flex w-80 flex-col gap-2 p-2.5 sm:w-96">
                  <UInput
                    v-model="unitSearch"
                    icon="i-lucide-search"
                    placeholder="Tìm kiếm đơn vị..."
                    size="sm"
                    autofocus
                  />

                  <div
                    class="flex max-h-64 flex-col gap-0.5 overflow-y-auto rounded-md border border-default p-1 text-xs sm:text-sm"
                  >
                    <button
                      type="button"
                      class="flex cursor-pointer items-center justify-between rounded px-2 py-1.5 text-left transition-colors hover:bg-elevated"
                      :class="
                        !selectedUnitId
                          ? 'bg-primary/10 font-semibold text-primary'
                          : 'text-foreground'
                      "
                      @click="selectUnit(null)"
                    >
                      <span>Tất cả đơn vị</span>
                      <UIcon
                        v-if="!selectedUnitId"
                        name="i-lucide-check"
                        class="h-4 w-4 shrink-0 text-primary"
                      />
                    </button>

                    <button
                      v-for="unit in filteredUnitOptions"
                      :key="unit.id"
                      type="button"
                      class="flex cursor-pointer items-center justify-between rounded px-2 py-1.5 text-left transition-colors hover:bg-elevated"
                      :class="
                        selectedUnitId === unit.id
                          ? 'bg-primary/10 font-semibold text-primary'
                          : 'text-foreground'
                      "
                      @click="selectUnit(unit.id)"
                    >
                      <span class="truncate" :title="unit.path">{{ unit.path }}</span>
                      <UIcon
                        v-if="selectedUnitId === unit.id"
                        name="i-lucide-check"
                        class="ms-2 h-4 w-4 shrink-0 text-primary"
                      />
                    </button>

                    <div
                      v-if="filteredUnitOptions.length === 0"
                      class="px-2 py-4 text-center text-xs text-toned"
                    >
                      Không tìm thấy đơn vị nào
                    </div>
                  </div>
                </div>
              </template>
            </UPopover>
          </template>

          <template #membership-cell="{ row }">
            <div v-if="row.original._membership" class="flex items-center gap-2">
              <UBadge
                :label="
                  [
                    row.original._membership.unitName,
                    row.original._membership.factoryName,
                    row.original._membership.companyName,
                  ]
                    .filter((v, i, a) => v && a.indexOf(v) === i)
                    .join(' — ')
                "
                color="neutral"
                class="text-xs font-semibold"
              />
            </div>
            <span v-else class="text-sm text-toned italic"> Chưa phân công </span>
          </template>

          <template #roles-cell="{ row }">
            <div v-if="row.original._membership" class="flex flex-wrap gap-1">
              <UBadge
                v-for="role in getVisibleRoles(row.original._membership)"
                :key="role.id"
                :label="role.name"
                color="info"
              />
              <UBadge
                v-if="getHiddenRoleCount(row.original._membership) > 0"
                :label="`+${getHiddenRoleCount(row.original._membership)}`"
                color="info"
              />
            </div>
          </template>

          <template #actions-cell="{ row }">
            <div class="flex items-center gap-1">
              <UButton
                v-if="hasPermission('MANAGE_ACCOUNT')"
                variant="ghost"
                color="info"
                size="sm"
                class="h-8 w-8"
                @click.stop="openChangePassword(row.original)"
                title="Đổi mật khẩu"
                icon="i-lucide-key-round"
              />
              <UButton
                v-if="hasPermission('MANAGE_ACCOUNT')"
                variant="ghost"
                color="neutral"
                size="sm"
                class="h-8 w-8"
                @click.stop="openEditForm(row.original)"
                title="Sửa thông tin tài khoản"
                icon="i-lucide-pencil"
              />
              <UButton
                v-if="hasPermission('MANAGE_ACCOUNT')"
                :disabled="row.original.isAdmin"
                variant="ghost"
                color="error"
                size="sm"
                class="h-8 w-8"
                @click.stop="confirmDeleteAccount(row.original)"
                :title="row.original.isAdmin ? 'Không thể xoá admin' : 'Xóa tài khoản'"
                icon="i-lucide-trash-2"
              />
            </div>
          </template>

          <template #empty> Không tìm thấy tài khoản nào. </template>
        </UTable>

        <div class="mt-4 flex flex-col items-center justify-between gap-3 sm:flex-row">
          <span class="text-xs text-toned sm:text-sm">
            Hiển thị {{ totalRecords > 0 ? (page - 1) * pageSize + 1 : 0 }} -
            {{ Math.min(page * pageSize, totalRecords) }} trong tổng số {{ totalRecords }} tài khoản
          </span>
          <div class="flex items-center gap-3">
            <UPagination v-model:page="page" :total="totalRecords" :items-per-page="pageSize" />
            <USelect
              v-model="pageSize"
              :items="[10, 20, 50, 100]"
              class="w-20"
              aria-label="Số dòng mỗi trang"
            />
          </div>
        </div>
      </template>
    </UCard>

    <!-- Dialog Forms -->
    <CreateAccountForm v-model:visible="showCreateForm" @created="onAccountSaved" />

    <UpdateMemberInfoForm
      v-if="selectedAccount"
      v-model:visible="showUpdateMembershipForm"
      :account="selectedAccount"
      @updated="onAccountSaved"
      @admin-transferred="onAdminTransferred"
    />

    <ChangePasswordDialog
      v-if="selectedAccount"
      v-model:visible="showChangePasswordDialog"
      :account="selectedAccount"
    />

    <AccountViewDialog
      v-model:visible="showViewDialog"
      :account="selectedAccount"
      :membership="selectedMembership"
    />
  </div>
</template>
