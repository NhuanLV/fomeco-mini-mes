<script setup lang="ts">
import ProductionOrderHistoryTable from '@/features/production/components/ProductionOrderHistoryTable.vue'
import ProductionOrderCancellation from '@/features/production/components/ProductionOrderCancellation.vue'
import ProductionOrderCancelledAlert from '@/features/production/components/ProductionOrderCancelledAlert.vue'
import { useIntervalFn } from '@vueuse/core'
import type { PermissionVm } from '@/api'
import {
  getProductionOrderDetailQuery,
  getProductionOrderHistoryQuery,
  getTeamAssignmentDetailQuery,
} from '@/api/@pinia/colada.gen'
import { ROUTE_PATH } from '@/app/router/path'
import CreateKanbanTab from '@/features/kanban/components/CreateKanban.vue'
import TeamAssignmentConsumptionTab from '@/features/production/team-assignment/components/TeamAssignmentConsumptionTab.vue'
import TeamAssignmentReportTab from '@/features/production/team-assignment/components/TeamAssignmentReportTab.vue'
import TeamAssignmentViewAllTab from '@/features/production/team-assignment/components/TeamAssignmentViewAllTab.vue'
import InventoryTab from '@/features/inventory/components/InventoryTab.vue'
import PoMetadataCard from '@/features/production/team-assignment/components/report/PoMetadataCard.vue'
import { useAuthStore } from '@/shared/stores/auth'
import { useQuery, useQueryCache } from '@pinia/colada'
import { computed, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

definePage({
  meta: {
    requiredAnyPermission: [
      'REPORT_PROGRESS',
      'UPDATE_COSTING',
      'VIEW_PRODUCTION_ORDER',
      'ISSUE_PRODUCTION_ORDER',
      'CREATE_KANBAN',
    ],
  },
})

const route = useRoute()
const queryCache = useQueryCache()
const id = computed(() => route.params.id as string)
const from = computed(() => route.query.from as string | undefined)

const { data: assignment, refetch: refetchAssignment } = useQuery(() =>
  getTeamAssignmentDetailQuery({ path: { id: id.value } }),
)

const { hasPermission } = useAuthStore()

const canLoadProductionOrderDetail = computed(
  () =>
    hasPermission('VIEW_PRODUCTION_ORDER') ||
    hasPermission('ISSUE_PRODUCTION_ORDER') ||
    hasPermission('UPDATE_COSTING') ||
    hasPermission('REPORT_PROGRESS'),
)

const { data: productionOrder, refetch: refetchOrder } = useQuery(() => ({
  ...getProductionOrderDetailQuery({
    path: { id: assignment.value?.productionOrderId ?? '' },
  }),
  enabled: !!assignment.value?.productionOrderId && canLoadProductionOrderDetail.value,
}))

const {
  data: productionHistory,
  isLoading: historyLoading,
  error: historyError,
  refetch: refetchHistory,
} = useQuery(() => ({
  ...getProductionOrderHistoryQuery({ path: { id: productionOrder.value?.id ?? '' } }),
  enabled: !!productionOrder.value?.id,
}))

async function refreshCancellation() {
  const previousStatus = productionOrder.value?.status
  await Promise.all([refetchOrder(), refetchHistory(), refetchAssignment()])
  if (productionOrder.value?.status === 'CANCELLED' && previousStatus !== 'CANCELLED') {
    await Promise.all(
      ['getBuyerOrderDetail', 'getBuyerOrders', 'getProductionOrders', 'getMyAssignments'].map(
        (_id) => queryCache.invalidateQueries({ key: [{ _id }] }),
      ),
    )
  }
}
useIntervalFn(() => {
  if (
    productionHistory.value?.some((row) => row.action === 'CANCEL' && row.syncStatus === 'PENDING')
  )
    void refreshCancellation()
}, 2000)

type Permission = PermissionVm['code']

const ALL_TABS = [
  {
    value: 'input-report',
    label: 'Vào chuyền',
    icon: 'i-lucide-circle-play',
    permissions: [
      'REPORT_PROGRESS',
      'VIEW_PRODUCTION_ORDER',
      'ISSUE_PRODUCTION_ORDER',
    ] as Permission[],
  },
  {
    value: 'output-report',
    label: 'Ra chuyền',
    icon: 'i-lucide-circle-stop',
    permissions: [
      'REPORT_PROGRESS',
      'VIEW_PRODUCTION_ORDER',
      'ISSUE_PRODUCTION_ORDER',
    ] as Permission[],
  },
  {
    value: 'consumption',
    label: 'Định mức',
    icon: 'i-lucide-calculator',
    permissions: [
      'REPORT_PROGRESS',
      'VIEW_PRODUCTION_ORDER',
      'ISSUE_PRODUCTION_ORDER',
    ] as Permission[],
  },
  {
    value: 'kanban',
    label: 'Kanban',
    icon: 'i-lucide-columns-3',
    permissions: ['CREATE_KANBAN'] as Permission[],
  },
  {
    value: 'inventory',
    label: 'Tồn kho',
    icon: 'i-lucide-warehouse',
    permissions: [
      'REPORT_PROGRESS',
      'VIEW_PRODUCTION_ORDER',
      'ISSUE_PRODUCTION_ORDER',
    ] as Permission[],
  },
  {
    value: 'view-all',
    label: 'Tổng quan tiến độ',
    icon: 'i-lucide-layers',
    permissions: [
      'REPORT_PROGRESS',
      'VIEW_PRODUCTION_ORDER',
      'ISSUE_PRODUCTION_ORDER',
    ] as Permission[],
  },
]

const TABS = computed(() =>
  ALL_TABS.filter((t) => {
    const hasRequiredPermission = t.permissions.some((p) => hasPermission(p))
    if (!hasRequiredPermission) return false

    if (t.value === 'consumption') {
      const canUpdateCosting = hasPermission('UPDATE_COSTING')
      const isCutting = assignment.value?.operation === 'CUT-1'
      return canUpdateCosting || isCutting
    }

    return true
  }),
)

const router = useRouter()

const VALID_TABS = [
  'input-report',
  'output-report',
  'consumption',
  'kanban',
  'inventory',
  'view-all',
]
const initialTab = (route.query.tab as string) || 'input-report'
const activeTab = ref(VALID_TABS.includes(initialTab) ? initialTab : 'input-report')
const isHistoryExpanded = ref(false)

watch(activeTab, (newTab) => {
  if (route.query.tab !== newTab) {
    void router.replace({ query: { ...route.query, tab: newTab } })
  }
})

watch(
  () => route.query.tab,
  (newTabQuery) => {
    const tabVal = newTabQuery as string
    if (VALID_TABS.includes(tabVal) && tabVal !== activeTab.value) {
      activeTab.value = tabVal
    }
  },
)

const breadcrumbHome = { icon: 'i-lucide-house', to: ROUTE_PATH.DASHBOARD }
const assignmentLabel = computed(() =>
  assignment.value
    ? `${assignment.value.operation} — ${assignment.value.teamName} — ${assignment.value.factoryName} — ${assignment.value.companyName}`
    : '...',
)
const breadcrumbItems = computed(() => {
  if (from.value === 'my-tasks') {
    return [
      {
        label: 'Lệnh công đoạn',
        icon: 'i-lucide-workflow',
        to: ROUTE_PATH.TEAM_ASSIGNMENTS,
      },
      { label: assignmentLabel.value, icon: 'i-lucide-users' },
    ]
  }
  return [
    {
      label: 'Lệnh sản xuất',
      icon: 'i-lucide-clipboard-list',
      to: ROUTE_PATH.PRODUCTION_ORDERS,
    },
    {
      label: productionOrder.value?.code ?? '...',
      icon: 'i-lucide-clipboard-pen',
      to: assignment.value
        ? ROUTE_PATH.PRODUCTION_ORDER_DETAIL.replace(':id', assignment.value.productionOrderId)
        : undefined,
    },
    { label: assignmentLabel.value, icon: 'i-lucide-users' },
  ]
})
</script>

<template>
  <div class="flex flex-col gap-4">
    <UBreadcrumb :items="[breadcrumbHome, ...breadcrumbItems]" class="bg-transparent!" />
    <ProductionOrderCancelledAlert v-if="assignment?.productionOrderStatus === 'CANCELLED'" />

    <UTabs v-model="activeTab" :items="TABS" :content="false" variant="link" />
    <div class="flex flex-col gap-6 pt-4">
      <PoMetadataCard
        v-if="productionOrder && activeTab !== 'view-all'"
        :po-detail="productionOrder"
      />

      <TeamAssignmentReportTab
        v-if="activeTab === 'input-report'"
        :id="id"
        type="INPUT"
        v-model:is-history-expanded="isHistoryExpanded"
      />
      <TeamAssignmentReportTab
        v-else-if="activeTab === 'output-report'"
        :id="id"
        type="OUTPUT"
        v-model:is-history-expanded="isHistoryExpanded"
      />
      <TeamAssignmentConsumptionTab v-else-if="activeTab === 'consumption'" :id="id" />
      <CreateKanbanTab v-else-if="activeTab === 'kanban'" :id="id" />
      <InventoryTab
        :read-only="assignment?.productionOrderStatus === 'CANCELLED'"
        v-else-if="activeTab === 'inventory'"
        :id="id"
        :style-color-order="assignment?.styleColorOrder"
        :style-size-order="assignment?.styleSizeOrder"
      />
      <div v-else-if="activeTab === 'view-all'" class="flex flex-col gap-6">
        <ProductionOrderCancellation
          v-if="productionOrder"
          :order="productionOrder"
          :history="productionHistory"
          @refresh="refreshCancellation"
        >
          <TeamAssignmentViewAllTab
            :production-order="productionOrder"
            :current-assignment="assignment"
            :current-assignment-id="id"
          />
          <ProductionOrderHistoryTable
            :history="productionHistory"
            :loading="historyLoading"
            :error="!!historyError"
          />
        </ProductionOrderCancellation>
      </div>
    </div>
  </div>
</template>
