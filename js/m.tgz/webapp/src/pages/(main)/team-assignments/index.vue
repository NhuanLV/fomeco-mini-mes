<script setup lang="ts">
import type { TeamAssignmentFilterOptionsVm, TeamAssignmentVm } from '@/api'
import { getTeamAssignmentFilterOptionsQuery } from '@/api/@pinia/colada.gen'
import { ROUTE_PATH } from '@/app/router/path'
import ColumnDateFilter from '@/features/production/components/ColumnDateFilter.vue'
import {
  getProductionOrderNumber,
  getProductionOrderStyleName,
} from '@/features/production/helpers/productionOrder'
import TeamAssignmentMatrixModal from '@/features/production/team-assignment/components/TeamAssignmentMatrixModal.vue'
import { useTeamAssignmentList } from '@/features/production/team-assignment/composables/useTeamAssignmentList'
import {
  getTeamAssignmentStatus,
  getTeamAssignmentStatusColor,
  getTeamAssignmentStatusLabel,
  TEAM_ASSIGNMENT_STATUS_OPTIONS,
} from '@/features/production/team-assignment/helpers/teamAssignmentStatus'
import ColumnMultiSelectFilter from '@/shared/components/ColumnMultiSelectFilter.vue'
import type { SelectOption } from '@/shared/types'
import { handleRowNavigation, handleTableAuxClick } from '@/shared/utils/navigation'
import type { TableColumn, TableRow } from '@nuxt/ui'
import { useQuery } from '@pinia/colada'
import dayjs from 'dayjs'
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'

definePage({ meta: { requiredPermission: 'REPORT_PROGRESS' } })

const router = useRouter()

const {
  page,
  pageSize,
  styleFilter,
  orderNumberFilter,
  boWfxIdFilter,
  teamFilter,
  statusFilter,
  productDateRange,
  syncDateRange,
  lastProgressUpdateRange,
  loading,
  assignments,
  totalRecords,
  fetchAssignments,
} = useTeamAssignmentList()

const columns: TableColumn<TeamAssignmentVm>[] = [
  { accessorKey: 'styleName', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'orderNumber', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'boWfxId', meta: { class: { th: 'p-0!' } } },
  { id: 'inputQty', header: 'SL vào chuyền' },
  { id: 'outputQty', header: 'SL ra chuyền' },
  { id: 'progress', header: 'Tiến độ' },
  { id: 'productDate' },
  { id: 'syncDate' },
  { id: 'sku', header: 'Màu/Cỡ' },
  { id: 'team', meta: { class: { th: 'p-0!' } } },
  { id: 'status', meta: { class: { th: 'p-0!' } } },
  { id: 'lastProgressUpdate' },
]

const paginationPage = computed({
  get: () => page.value + 1,
  set: (value: number) => {
    page.value = value - 1
  },
})

const { data: filterOptionsResponse } = useQuery(getTeamAssignmentFilterOptionsQuery())
const filterOptions = computed<TeamAssignmentFilterOptionsVm>(
  () =>
    filterOptionsResponse.value ?? {
      styles: [],
      orderNumbers: [],
      boCodes: [],
      teams: [],
      statuses: [],
    },
)

const styleOptions = computed<SelectOption[]>(() =>
  filterOptions.value.styles.map((label) => ({ label, value: label })),
)
const orderNumberOptions = computed<SelectOption[]>(() =>
  filterOptions.value.orderNumbers.map((label) => ({ label, value: label })),
)
const boWfxIdOptions = computed<SelectOption[]>(() =>
  filterOptions.value.boCodes.map((label) => ({ label, value: label })),
)
const teamOptions = computed<SelectOption[]>(() =>
  filterOptions.value.teams.map((team) => ({
    label: [team.name, team.factoryName, team.companyName].join(', '),
    value: team.id,
  })),
)

const statusOptions = computed<SelectOption[]>(() =>
  filterOptions.value.statuses.map((status) => {
    const opt = TEAM_ASSIGNMENT_STATUS_OPTIONS.find((option) => option.value === status)
    return {
      label: opt?.label ?? status,
      value: status,
    }
  }),
)

// --- Matrix Modal ---
const isMatrixModalOpen = ref(false)
const selectedAssignmentIdForMatrix = ref<string | null>(null)

function openMatrixModal(assignmentId: string) {
  selectedAssignmentIdForMatrix.value = assignmentId
  isMatrixModalOpen.value = true
}

function selectAssignment(event: Event, row: TableRow<TeamAssignmentVm>) {
  handleRowNavigation(event, router, {
    path: ROUTE_PATH.TEAM_ASSIGNMENT_DETAIL.replace(':id', row.original.id),
    query: { from: 'my-tasks' },
  })
}

function handleAuxClick(event: MouseEvent) {
  handleTableAuxClick(event, router, assignments.value, (row) => ({
    path: ROUTE_PATH.TEAM_ASSIGNMENT_DETAIL.replace(':id', row.id),
    query: { from: 'my-tasks' },
  }))
}

function getInputTotal(assignment: TeamAssignmentVm): number {
  return assignment.inputReportTotals?.reduce((sum, item) => sum + (item.completedQty || 0), 0) ?? 0
}

function getOutputTotal(assignment: TeamAssignmentVm): number {
  return (
    assignment.outputReportTotals?.reduce((sum, item) => sum + (item.completedQty || 0), 0) ??
    assignment.totalReported ??
    0
  )
}

function getAllocatedTotal(assignment: TeamAssignmentVm): number {
  return assignment.allocations?.reduce((sum, item) => sum + (item.quantity || 0), 0) ?? 0
}

function getProgressRatio(assignment: TeamAssignmentVm): string {
  const output = getOutputTotal(assignment)
  const allocated = getAllocatedTotal(assignment)
  return `${output.toLocaleString('vi-VN')} / ${allocated.toLocaleString('vi-VN')}`
}

function formatTeamName(assignment: TeamAssignmentVm): string {
  return [assignment.teamName, assignment.factoryName, assignment.companyName]
    .filter(Boolean)
    .join(', ')
}

function getAssignmentFirstSku(assignment: TeamAssignmentVm): string {
  if (assignment.metadata?.firstSku) {
    return assignment.metadata.firstSku
  }
  if (assignment.allocations && assignment.allocations.length > 0) {
    const first = assignment.allocations[0]
    const extraCount = assignment.allocations.length - 1
    const base = `${first.color}/${first.size}`
    return extraCount > 0 ? `${base} (+${extraCount})` : base
  }
  return '-'
}
</script>

<template>
  <div class="flex flex-col gap-4">
    <div class="flex items-center justify-between">
      <UBreadcrumb
        :items="[
          { icon: 'i-lucide-house' },
          ...[{ label: 'Lệnh công đoạn', icon: 'i-lucide-workflow' }],
        ]"
        class="bg-transparent!"
      />
      <UButton
        label="Tải lại"
        variant="ghost"
        @click="() => fetchAssignments()"
        :loading="loading"
        icon="i-lucide-refresh-cw"
      />
    </div>

    <UCard>
      <template #default>
        <UTable
          :data="assignments"
          :columns="columns"
          :loading="loading"
          :ui="{ tr: 'cursor-pointer' }"
          @select="selectAssignment"
          @auxclick="handleAuxClick"
        >
          <template #empty>
            <div
              class="rounded-lg border-2 border-dashed border-surface-200 bg-surface-50 p-12 text-center"
            >
              <UIcon name="i-lucide-inbox" class="mx-auto mb-4 size-12 text-toned" />
              <p class="text-toned">Hiện chưa có công việc nào được phân công cho tổ của bạn.</p>
            </div>
          </template>

          <!-- 1. Mã hàng -->
          <template #styleName-header>
            <ColumnMultiSelectFilter
              v-model="styleFilter"
              :items="styleOptions"
              placeholder="Mã hàng"
            />
          </template>
          <template #styleName-cell="{ row }">
            <RouterLink
              :to="{
                path: ROUTE_PATH.TEAM_ASSIGNMENT_DETAIL.replace(':id', row.original.id),
                query: { from: 'my-tasks' },
              }"
              class="font-medium hover:text-primary hover:underline"
              @click.stop
            >
              {{ getProductionOrderStyleName(row.original.code) }}
            </RouterLink>
          </template>

          <!-- 2. Số lệnh -->
          <template #orderNumber-header>
            <ColumnMultiSelectFilter
              v-model="orderNumberFilter"
              :items="orderNumberOptions"
              placeholder="Số lệnh"
            />
          </template>
          <template #orderNumber-cell="{ row }">
            <RouterLink
              :to="{
                path: ROUTE_PATH.TEAM_ASSIGNMENT_DETAIL.replace(':id', row.original.id),
                query: { from: 'my-tasks' },
              }"
              class="font-semibold hover:text-primary hover:underline"
              @click.stop
            >
              <code class="text-xs text-default">
                {{ getProductionOrderNumber(row.original.code) }}
              </code>
            </RouterLink>
          </template>

          <!-- 3. Đơn hàng -->
          <template #boWfxId-header>
            <ColumnMultiSelectFilter
              v-model="boWfxIdFilter"
              :items="boWfxIdOptions"
              placeholder="Đơn hàng"
            />
          </template>
          <template #boWfxId-cell="{ row }">
            <span v-if="row.original.boWfxId" class="font-mono text-sm">
              {{ row.original.boWfxId }}
            </span>
            <span v-else class="text-toned">-</span>
          </template>

          <!-- 4. SL vào chuyền -->
          <template #inputQty-cell="{ row }">
            <span class="font-mono font-medium">
              {{ getInputTotal(row.original).toLocaleString('vi-VN') }}
            </span>
          </template>

          <!-- 5. SL ra chuyền -->
          <template #outputQty-cell="{ row }">
            <span class="font-mono font-medium">
              {{ getOutputTotal(row.original).toLocaleString('vi-VN') }}
            </span>
          </template>

          <!-- 6. Tiến độ -->
          <template #progress-cell="{ row }">
            <span class="font-mono font-semibold">
              {{ getProgressRatio(row.original) }}
            </span>
          </template>

          <!-- 7. Ngày vào chuyền -->
          <template #productDate-header>
            <ColumnDateFilter v-model="productDateRange" label="Ngày vào chuyền" />
          </template>
          <template #productDate-cell="{ row }">
            <span v-if="row.original.metadata?.productDate">
              {{ dayjs(row.original.metadata.productDate).format('DD/MM/YYYY') }}
            </span>
            <span v-else class="text-toned">-</span>
          </template>

          <!-- 8. Ngày đồng bộ -->
          <template #syncDate-header>
            <ColumnDateFilter v-model="syncDateRange" label="Ngày đồng bộ" />
          </template>
          <template #syncDate-cell="{ row }">
            <span v-if="row.original.metadata?.syncDate">
              {{ dayjs(row.original.metadata.syncDate).format('DD/MM/YYYY') }}
            </span>
            <span v-else class="text-toned">-</span>
          </template>

          <!-- 9. Màu/ cỡ -->
          <template #sku-cell="{ row }">
            <div class="flex items-center gap-2" @click.stop>
              <span class="font-mono text-sm">
                {{ getAssignmentFirstSku(row.original) }}
              </span>
              <UButton
                icon="i-lucide-grid"
                size="xs"
                color="neutral"
                variant="ghost"
                title="Xem chi tiết ma trận Màu/Cỡ"
                @click="openMatrixModal(row.original.id)"
              />
            </div>
          </template>

          <!-- 10. Tổ -->
          <template #team-header>
            <ColumnMultiSelectFilter v-model="teamFilter" :items="teamOptions" placeholder="Tổ" />
          </template>
          <template #team-cell="{ row }">
            <span class="text-sm">
              {{ formatTeamName(row.original) }}
            </span>
          </template>

          <!-- 11. Trạng thái -->
          <template #status-header>
            <ColumnMultiSelectFilter
              v-model="statusFilter"
              :items="statusOptions"
              placeholder="Trạng thái"
            />
          </template>
          <template #status-cell="{ row }">
            <div class="flex flex-wrap gap-1">
              <UBadge
                :color="getTeamAssignmentStatusColor(getTeamAssignmentStatus(row.original))"
                variant="subtle"
                size="sm"
              >
                {{ getTeamAssignmentStatusLabel(getTeamAssignmentStatus(row.original)) }}
              </UBadge>
              <UBadge
                v-if="row.original.hasPendingMaterialSupplement"
                color="error"
                variant="subtle"
                size="sm"
              >
                Chờ bổ sung NPL
              </UBadge>
            </div>
          </template>

          <!-- 12. Ngày cập nhật -->
          <template #lastProgressUpdate-header>
            <ColumnDateFilter v-model="lastProgressUpdateRange" label="Ngày cập nhật" />
          </template>
          <template #lastProgressUpdate-cell="{ row }">
            <span v-if="row.original.lastReportUpdatedAt">
              {{ dayjs(row.original.lastReportUpdatedAt).format('HH:mm, DD/MM/YYYY') }}
            </span>
            <span v-else class="text-toned">-</span>
          </template>
        </UTable>

        <div class="mt-3 flex items-center justify-between gap-3">
          <USelect v-model="pageSize" :items="[1, 10, 20, 50]" class="w-20" />
          <UPagination
            v-model:page="paginationPage"
            :total="totalRecords"
            :items-per-page="pageSize"
          />
        </div>
      </template>
    </UCard>

    <TeamAssignmentMatrixModal
      v-model:open="isMatrixModalOpen"
      :assignment-id="selectedAssignmentIdForMatrix"
    />
  </div>
</template>
