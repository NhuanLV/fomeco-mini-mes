<script setup lang="ts">
import type { RoleVm } from '@/api'
import { deleteRoleMutation, getRolesQuery } from '@/api/@pinia/colada.gen'
import RoleForm from '@/features/role/components/RoleForm.vue'
import { useAuthStore } from '@/shared/stores/auth'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useMutation, useQuery } from '@pinia/colada'
import { useConfirm } from '@/shared/composables/useConfirm'
import type { TableColumn, TableRow } from '@nuxt/ui'
import { computed, ref } from 'vue'

definePage({
  meta: { requiredPermission: 'MANAGE_ACCOUNT' },
})

const confirm = useConfirm()
const { hasPermission } = useAuthStore()

// Queries
const { data, refetch } = useQuery(getRolesQuery())
const roles = computed(() =>
  [...(data.value ?? [])].sort((left, right) => left.name.localeCompare(right.name, 'vi')),
)
const columns: TableColumn<RoleVm>[] = [
  { accessorKey: 'name', header: 'Tên vai trò' },
  { accessorKey: 'description', header: 'Mô tả' },
  { id: 'permissions', header: 'Quyền hạn' },
  { id: 'actions', header: 'Thao tác' },
]

// Mutations
const { mutateAsync: deleteMutate } = useMutation(deleteRoleMutation())

// Form state
const showForm = ref(false)
const selectedRole = ref<RoleVm | null>(null)
const isViewOnly = ref(false)

const openNew = () => {
  selectedRole.value = null
  isViewOnly.value = false
  showForm.value = true
}

const editRole = (role: RoleVm) => {
  selectedRole.value = role
  isViewOnly.value = false
  showForm.value = true
}

const viewRole = (role: RoleVm) => {
  selectedRole.value = role
  isViewOnly.value = true
  showForm.value = true
}

const selectRole = (_event: Event, row: TableRow<RoleVm>) =>
  row.original.isSystem ? viewRole(row.original) : editRole(row.original)

const confirmDeleteRole = (role: RoleVm) => {
  confirm.require({
    message: `Bạn có chắc chắn muốn xóa vai trò "${role.name}"?`,
    header: 'Xác nhận xóa',
    rejectProps: { label: 'Hủy' },
    acceptProps: { label: 'Xóa', color: 'error' },
    accept: async () => {
      try {
        await deleteMutate({ path: { id: role.id } })
        showSuccess('Xóa vai trò thành công')
        refetch()
      } catch (e: unknown) {
        if (e instanceof Error) {
          showError(e.message)
        } else {
          showError('Xóa vai trò thất bại')
        }
      }
    },
  })
}

const onRoleSaved = () => {
  refetch()
}
</script>

<template>
  <div class="flex h-full flex-col gap-4">
    <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
      <UBreadcrumb
        :items="[
          { icon: 'i-lucide-house' },
          ...[{ label: 'Quản lý Vai trò', icon: 'i-lucide-shield-check' }],
        ]"
        class="bg-transparent! text-xs sm:text-sm"
      />
      <UButton
        v-if="hasPermission('MANAGE_ACCOUNT')"
        @click="openNew"
        size="sm"
        icon="i-lucide-plus"
        label="Thêm mới"
        class="w-full sm:w-auto"
      />
    </div>

    <UCard>
      <template #default>
        <UTable
          :data="roles"
          :columns="columns"
          class="text-xs sm:text-sm"
          :ui="{ tr: 'cursor-pointer' }"
          @select="selectRole"
        >
          <template #name-cell="{ row }">
            <div class="flex flex-col gap-1 sm:flex-row sm:items-center">
              <span class="font-medium">{{ row.original.name }}</span>
              <UBadge v-if="row.original.isSystem" label="Hệ thống" color="neutral" class="w-fit" />
            </div>
          </template>

          <template #description-cell="{ row }">
            <span class="leading-relaxed text-default">{{ row.original.description }}</span>
          </template>

          <template #permissions-cell="{ row }">
            <div class="flex flex-wrap gap-1">
              <UBadge
                v-for="perm in row.original.permissions.slice(0, 4)"
                :key="perm.code"
                :label="perm.displayName"
                color="info"
              />
              <UBadge
                v-if="row.original.permissions.length > 4"
                :label="`+${row.original.permissions.length - 4}`"
                color="info"
              />
              <span v-if="row.original.permissions.length === 0" class="text-xs text-toned italic">
                Không có quyền
              </span>
            </div>
          </template>

          <template #actions-cell="{ row }">
            <div class="flex gap-1">
              <template v-if="!row.original.isSystem">
                <UButton
                  variant="ghost"
                  size="sm"
                  color="neutral"
                  icon="i-lucide-pencil"
                  class="h-8 w-8 justify-center p-0"
                  @click.stop="editRole(row.original)"
                />
                <UButton
                  variant="ghost"
                  size="sm"
                  color="error"
                  icon="i-lucide-trash-2"
                  class="h-8 w-8 justify-center p-0"
                  @click.stop="confirmDeleteRole(row.original)"
                />
              </template>
              <UButton
                v-else
                variant="ghost"
                size="sm"
                color="neutral"
                icon="i-lucide-eye"
                class="h-8 w-8 justify-center p-0"
                @click.stop="viewRole(row.original)"
              />
            </div>
          </template>
        </UTable>
      </template>
    </UCard>

    <RoleForm
      v-model:visible="showForm"
      :role="selectedRole"
      :view-only="isViewOnly"
      @created="onRoleSaved"
      @updated="onRoleSaved"
    />

    <!-- Confirm Dialog -->
  </div>
</template>
