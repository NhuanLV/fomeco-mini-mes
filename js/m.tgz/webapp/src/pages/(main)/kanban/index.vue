<script setup lang="ts">
import { ROUTE_PATH } from '@/app/router/path'
import { useKanbanList } from '@/features/kanban/composables/useKanbanList'
import { getStatusLabel, getStatusSeverity } from '@/features/kanban/helpers/kanban'
import { getProductionOrderNumber } from '@/features/production/helpers/productionOrder'
import { useAuthStore } from '@/shared/stores/auth'
import type { TableColumn, TableRow } from '@nuxt/ui'
import { useRouter } from 'vue-router'
import dayjs from 'dayjs'
import { computed } from 'vue'
import { fmtQty } from '@/shared/utils/fmtQty'
import { handleRowNavigation, handleTableAuxClick } from '@/shared/utils/navigation'

const router = useRouter()
const { hasPermission } = useAuthStore()

const showCreatedTab = computed(() => hasPermission('CREATE_KANBAN'))
const showEvaluateTab = computed(
  () => hasPermission('EVALUATE_KANBAN') || hasPermission('EVALUATE_EXTRA_KANBAN'),
)
const showPrepareTab = computed(() => hasPermission('PREPARE_MATERIAL'))
const showIssueTab = computed(() => hasPermission('ISSUE_MATERIAL'))
const showCompletedTab = computed(
  () => showCreatedTab.value || showPrepareTab.value || showIssueTab.value,
)

const isWarehouseRole = computed(
  () => !showCreatedTab.value && (showPrepareTab.value || showIssueTab.value),
)

const showIssueProgressColumn = computed(
  () =>
    ['prepare', 'issue'].includes(activeTab.value) ||
    (activeTab.value === 'completed' && isWarehouseRole.value),
)
const showReceiveProgressColumn = computed(
  () =>
    ['created', 'pending_receive'].includes(activeTab.value) ||
    (activeTab.value === 'completed' && !isWarehouseRole.value),
)

const {
  activeTab,
  filters,
  kanbans,
  totalRecords,
  loading,
  handlePageChange,
  counters,
  filterOptions,
  planOptions,
  statusOptions,
  clearFilters,
} = useKanbanList(hasPermission)
type KanbanRow = (typeof kanbans.value)[number]

const columns = computed<TableColumn<KanbanRow>[]>(() => [
  { accessorKey: 'styleName', header: 'Mã hàng' },
  { accessorKey: 'productionOrderCode', header: 'Lệnh số' },
  { accessorKey: 'kanbanCode', header: 'Mã kanban' },
  { accessorKey: 'hasPlan', header: 'Loại' },
  { accessorKey: 'status', header: 'Trạng thái' },
  { accessorKey: 'createdAt', header: 'Ngày tạo' },
  { accessorKey: 'teamName', header: 'Tổ yêu cầu' },
  { accessorKey: 'createdByName', header: 'Người tạo' },
  ...(activeTab.value !== 'evaluate'
    ? [{ accessorKey: 'totalActualIssuedQty', header: 'SL thực xuất' }]
    : []),
  ...(showIssueProgressColumn.value ? [{ id: 'issueProgress', header: 'Tiến độ xuất hàng' }] : []),
  ...(showReceiveProgressColumn.value
    ? [
        { id: 'receiveProgress', header: 'Tiến độ nhận hàng' },
        { accessorKey: 'pendingReceiveCount', header: 'Số NPL chờ nhận' },
      ]
    : []),
])
const page = computed({
  get: () => filters.page + 1,
  set: (value: number) =>
    handlePageChange({ page: value - 1, rows: filters.size, first: 0, pageCount: 0 }),
})
const pageSize = computed({
  get: () => filters.size,
  set: (value: number) => handlePageChange({ page: 0, rows: value, first: 0, pageCount: 0 }),
})

const tabItems = computed(() =>
  [
    showCreatedTab.value && {
      label: `Đã tạo${counters.created ? ` (${counters.created})` : ''}`,
      value: 'created',
    },
    showEvaluateTab.value && {
      label: `Chờ phê duyệt${counters.evaluate ? ` (${counters.evaluate})` : ''}`,
      value: 'evaluate',
    },
    showPrepareTab.value && {
      label: `Cần chuẩn bị${counters.prepare ? ` (${counters.prepare})` : ''}`,
      value: 'prepare',
    },
    showIssueTab.value && {
      label: `Cần cấp phát${counters.issue ? ` (${counters.issue})` : ''}`,
      value: 'issue',
    },
    showCreatedTab.value && {
      label: `Chờ nhận${counters.pending_receive ? ` (${counters.pending_receive})` : ''}`,
      value: 'pending_receive',
    },
    showCompletedTab.value && {
      label: `Hoàn tất${counters.completed ? ` (${counters.completed})` : ''}`,
      value: 'completed',
    },
  ].filter((item): item is { label: string; value: string } => !!item),
)

function handleRowClick(event: Event, row: TableRow<KanbanRow>) {
  handleRowNavigation(event, router, ROUTE_PATH.KANBAN_DETAIL.replace(':id', row.original.id))
}

function handleAuxClick(event: MouseEvent) {
  handleTableAuxClick(event, router, kanbans.value, (row) =>
    ROUTE_PATH.KANBAN_DETAIL.replace(':id', row.id),
  )
}
</script>

<template>
  <div class="flex flex-col gap-4">
    <div class="flex items-center justify-between">
      <UBreadcrumb
        :items="[
          { icon: 'i-lucide-house', url: '/' },
          ...[{ label: 'Danh sách Kanban', icon: 'i-lucide-columns-3' }],
        ]"
        class="bg-transparent!"
      />
    </div>

    <UCard>
      <template #default>
        <UTabs v-model="activeTab" :items="tabItems" :content="false" variant="link" />

        <div class="mt-8 mb-4 flex flex-wrap items-end gap-4 px-2">
          <UFormField label="Mã hàng">
            <USelectMenu
              v-model="filters.styleName"
              multiple
              :items="filterOptions.styleNames"
              search-input
              class="w-48"
            />
          </UFormField>

          <UFormField label="Lệnh số">
            <USelectMenu
              v-model="filters.productionOrderCode"
              multiple
              :items="filterOptions.productionOrderCodes"
              search-input
              class="w-48"
            />
          </UFormField>

          <UFormField label="Mã kanban">
            <USelectMenu
              v-model="filters.kanbanCode"
              multiple
              :items="filterOptions.kanbanCodes"
              search-input
              class="w-48"
            />
          </UFormField>

          <UFormField label="Loại">
            <USelectMenu
              v-model="filters.hasPlan"
              multiple
              :items="planOptions"
              label-key="label"
              value-key="value"
              :search-input="false"
              class="w-48"
            />
          </UFormField>

          <UFormField v-if="activeTab !== 'evaluate'" label="Trạng thái">
            <USelectMenu
              v-model="filters.statuses"
              multiple
              :items="statusOptions"
              label-key="label"
              value-key="value"
              search-input
              class="w-56"
            />
          </UFormField>

          <UFormField label="Tổ yêu cầu">
            <USelectMenu
              v-model="filters.teamIds"
              multiple
              :items="filterOptions.teams"
              label-key="name"
              value-key="id"
              search-input
              class="w-72"
            />
          </UFormField>

          <UButton
            icon="i-lucide-filter-x"
            color="neutral"
            variant="outline"
            aria-label="Xóa bộ lọc"
            class="mb-0.5"
            @click="clearFilters"
          />
        </div>

        <UTable
          :data="kanbans"
          :columns="columns"
          :loading="loading"
          :ui="{ tr: 'cursor-pointer' }"
          @select="handleRowClick"
          @auxclick="handleAuxClick"
        >
          <template #styleName-cell="{ row }">
            <RouterLink
              :to="ROUTE_PATH.KANBAN_DETAIL.replace(':id', row.original.id)"
              class="font-medium hover:text-primary hover:underline"
              @click.stop
            >
              {{ row.original.styleName }}
            </RouterLink>
          </template>
          <template #productionOrderCode-cell="{ row }">
            <code class="text-xs text-default">
              {{ getProductionOrderNumber(row.original.productionOrderCode) }}
            </code>
          </template>
          <template #kanbanCode-cell="{ row }">
            <RouterLink
              :to="ROUTE_PATH.KANBAN_DETAIL.replace(':id', row.original.id)"
              class="font-mono text-sm font-semibold hover:text-primary hover:underline"
              @click.stop
            >
              {{ row.original.kanbanCode }}
            </RouterLink>
          </template>
          <template #hasPlan-cell="{ row }">
            <UBadge
              :label="row.original.hasPlan ? 'Trong định mức' : 'Ngoài định mức'"
              :color="row.original.hasPlan ? 'success' : 'warning'"
            />
          </template>
          <template #status-cell="{ row }">
            <UBadge
              :label="getStatusLabel(row.original.status)"
              :color="getStatusSeverity(row.original.status)"
            />
          </template>
          <template #createdAt-cell="{ row }">
            {{ dayjs(row.original.createdAt).format('DD/MM/YYYY HH:mm') }}
          </template>
          <template #totalActualIssuedQty-cell="{ row }">
            {{ fmtQty(row.original.totalActualIssuedQty) }}
          </template>
          <template #issueProgress-cell="{ row }">
            {{ fmtQty(row.original.totalActualIssuedQty) }} /
            {{ fmtQty(row.original.totalRequiredQty) }}
          </template>
          <template #receiveProgress-cell="{ row }">
            {{ fmtQty(row.original.totalReceivedQty) }} /
            {{ fmtQty(row.original.totalActualIssuedQty) }}
          </template>
          <template #pendingReceiveCount-cell="{ row }">
            {{ row.original.pendingReceiveCount > 0 ? row.original.pendingReceiveCount : '-' }}
          </template>
          <template #empty> Không tìm thấy Kanban nào. </template>
        </UTable>

        <div class="mt-3 flex items-center justify-center gap-3">
          <UPagination v-model:page="page" :total="totalRecords" :items-per-page="filters.size" />
          <USelect
            v-model="pageSize"
            :items="[2, 5, 10, 20, 50]"
            class="w-20"
            aria-label="Số dòng mỗi trang"
          />
        </div>
      </template>
    </UCard>
  </div>
</template>
