<script setup lang="ts">
import { ROUTE_PATH } from '@/app/router/path'
import KanbanDetailGrid from '@/features/kanban/components/KanbanDetailGrid.vue'
import KanbanGeneralInfo from '@/features/kanban/components/KanbanGeneralInfo.vue'
import KanbanHistoryTable from '@/features/kanban/components/KanbanHistoryTable.vue'
import KanbanPlanTable from '@/features/kanban/components/KanbanPlanTable.vue'
import KanbanRejectDialog from '@/features/kanban/components/KanbanRejectDialog.vue'
import KanbanCancelDialog from '@/features/kanban/components/KanbanCancelDialog.vue'
import { useKanbanFulfillment } from '@/features/kanban/fulfillment/useKanbanFulfillment'
import { kanbanItemKey } from '@/features/kanban/fulfillment/kanbanFulfillment'
import { getKanbanHistoryQuery, getKanbanQueryKey } from '@/api/@pinia/colada.gen'
import { useQuery, useQueryCache } from '@pinia/colada'
import { useIntervalFn } from '@vueuse/core'
import { computed, ref, watch } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const kanbanId = route.params.id as string

const {
  kanban,
  isLoading,
  flatItems,
  prepareInputs,
  supplierNotes,
  creatorNotes,
  selectedToIssue,
  selectedToReceive,
  reviseInputs,
  rejectDialogVisible,
  isReviseMode,
  isPreparing,
  isIssuing,
  isReceiving,
  isRevising,
  isApproving,
  isApprovingExtra,
  isRejecting,
  handlePrepare,
  handleIssue,
  handleReceive,
  handleRevise,
  handleApprove,
  handleReject,
  cancelDialogVisible,
  isCancelling,
  openCancelDialog,
  handleCancel,
} = useKanbanFulfillment(kanbanId)

const queryCache = useQueryCache()
const { data: history, refetch: refetchHistory } = useQuery(() =>
  getKanbanHistoryQuery({ path: { id: kanbanId } }),
)
const dismissedFailures = ref(new Set<string>())
const attempts = computed(() =>
  (history.value ?? []).flatMap((event) =>
    event.gdnAttempts.map((attempt) => ({
      event,
      attempt,
      key: `${event.supplierUnitId}-${event.occurredAt}-${attempt.materialType}`,
    })),
  ),
)
const hasPendingGdn = computed(() =>
  attempts.value.some(({ attempt }) => attempt.status === 'PENDING'),
)
const failedGdns = computed(() =>
  kanban.value?.status === 'CANCELLED'
    ? []
    : attempts.value.filter(
        ({ attempt, key }) => attempt.status === 'FAILED' && !dismissedFailures.value.has(key),
      ),
)
const blockedReceiveKeys = computed(
  () =>
    new Set(
      attempts.value
        .filter(({ attempt }) => attempt.status === 'PENDING' || attempt.status === 'FAILED')
        .flatMap(({ attempt, event }) =>
          attempt.items.map((item) =>
            kanbanItemKey({
              ...item,
              purchaseOrderId: item.poId ?? null,
              supplierId: event.supplierUnitId ?? '',
            }),
          ),
        ),
    ),
)
const { pause: pausePolling, resume: resumePolling } = useIntervalFn(
  () => void refetchHistory(),
  3000,
  { immediate: false },
)
watch(
  hasPendingGdn,
  (pending, wasPending) => {
    if (pending) resumePolling()
    else {
      pausePolling()
      if (wasPending) {
        void queryCache.invalidateQueries({ key: getKanbanQueryKey({ path: { id: kanbanId } }) })
      }
    }
  },
  { immediate: true },
)

function dismissFailure(key: string) {
  dismissedFailures.value = new Set([...dismissedFailures.value, key])
}

function supplierName(supplierUnitId?: string | null) {
  return (
    flatItems.value.find((item) => item.supplierId === supplierUnitId)?.supplierName ?? 'đơn vị cấp'
  )
}
</script>

<template>
  <div class="flex flex-col gap-6">
    <div class="flex items-center justify-between">
      <UBreadcrumb
        :items="[
          { icon: 'i-lucide-house', url: '/' },
          ...[
            {
              label: 'Danh sách Kanban',
              icon: 'i-lucide-columns-3',
              url: ROUTE_PATH.KANBAN,
            },
            { label: 'Chi tiết Kanban', icon: 'i-lucide-file-search' },
          ],
        ]"
        class="bg-transparent!"
      />
    </div>

    <div v-if="isLoading && !kanban" class="flex justify-center p-8">
      <UIcon name="i-lucide-loader-circle" class="animate-spin text-4xl text-primary" />
    </div>

    <template v-else-if="kanban">
      <UAlert
        v-for="failure in failedGdns"
        :key="failure.key"
        role="alert"
        color="error"
        icon="i-lucide-triangle-alert"
        close
        :title="`Chưa xác nhận nhận thành công ${failure.attempt.materialType} từ ${supplierName(failure.event.supplierUnitId)}`"
        :description="`Lỗi WFX GDN: ${failure.attempt.message || 'Không xác định'}. Vui lòng kiểm tra lịch sử bên dưới để thử lại.`"
        @update:open="(open: boolean) => !open && dismissFailure(failure.key)"
      />

      <div
        v-if="kanban.status === 'COMPLETED'"
        class="flex items-center gap-3 rounded-lg bg-green-50 px-4 py-3 text-green-800"
      >
        <UIcon name="i-lucide-circle-check" class="text-xl text-green-600" />
        <span class="font-medium">
          Kanban đã hoàn thành — tất cả vật tư / BTP đã được cấp phát và xác nhận.
        </span>
      </div>

      <KanbanGeneralInfo
        :kanban="kanban"
        :is-approving="isApproving || isApprovingExtra"
        :is-rejecting="isRejecting"
        :is-loading="isLoading"
        :is-cancelling="isCancelling"
        @approve="handleApprove"
        @reject="rejectDialogVisible = true"
        @cancel="openCancelDialog"
      />

      <KanbanPlanTable
        :plan="kanban.plan"
        :style-color-order="kanban.styleColorOrder"
        :style-size-order="kanban.styleSizeOrder"
      />

      <KanbanDetailGrid
        :items="flatItems"
        :team-id="kanban.teamId"
        :is-preparing="isPreparing"
        :is-issuing="isIssuing"
        :is-receiving="isReceiving"
        :is-revising="isRevising"
        :is-loading="isLoading"
        :revise-mode="isReviseMode"
        :kanban-status="kanban.status"
        :blocked-receive-keys="blockedReceiveKeys"
        :style-color-order="kanban.styleColorOrder"
        :style-size-order="kanban.styleSizeOrder"
        v-model:prepare-inputs="prepareInputs"
        v-model:supplier-notes="supplierNotes"
        v-model:creator-notes="creatorNotes"
        v-model:selected-to-issue="selectedToIssue"
        v-model:selected-to-receive="selectedToReceive"
        v-model:revise-inputs="reviseInputs"
        @prepare="handlePrepare"
        @issue="handleIssue"
        @receive="handleReceive"
        @revise="handleRevise"
      />

      <KanbanHistoryTable
        :kanban-id="kanbanId"
        :team-id="kanban.teamId"
        :read-only="kanban.status === 'CANCELLED'"
        :items="flatItems"
        :style-color-order="kanban.styleColorOrder"
        :style-size-order="kanban.styleSizeOrder"
      />
    </template>

    <div
      v-else
      class="flex flex-col items-center justify-center rounded-lg bg-white p-12 shadow-sm"
    >
      <UIcon name="i-lucide-circle-alert" class="mb-4 text-5xl text-red-500" />
      <h2 class="text-xl font-semibold text-highlighted">Không tìm thấy thông tin Kanban</h2>
      <p class="text-toned">Vui lòng kiểm tra lại đường dẫn hoặc quyền truy cập.</p>
    </div>

    <KanbanRejectDialog
      v-model:visible="rejectDialogVisible"
      :is-rejecting="isRejecting"
      @reject="handleReject"
    />
    <KanbanCancelDialog
      v-model:visible="cancelDialogVisible"
      :is-cancelling="isCancelling"
      @cancel="handleCancel"
    />
  </div>
</template>
