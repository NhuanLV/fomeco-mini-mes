<script setup lang="ts">
import { changeMyPasswordMutation, updateAccountAvatarMutation } from '@/api/@pinia/colada.gen'
import ProfileAvatarDialog from '@/features/profile/components/ProfileAvatarDialog.vue'
import ProfileMemberships from '@/features/profile/components/ProfileMemberships.vue'
import { useAuthStore } from '@/shared/stores/auth'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useMutation } from '@pinia/colada'
import { computed, ref } from 'vue'

const authStore = useAuthStore()
const currentUser = computed(() => authStore.currentUser.value)
const avatarDialogOpen = ref(false)
const { mutateAsync: updateAvatar, isLoading: isSavingAvatar } = useMutation(
  updateAccountAvatarMutation(),
)

async function saveAvatar(avatar: string) {
  const user = currentUser.value
  if (!user || isSavingAvatar.value) return
  try {
    await updateAvatar({ body: avatar })
    if (authStore.currentUser.value?.id === user.id) {
      authStore.currentUser.value.avatar = avatar || null
    }
    avatarDialogOpen.value = false
    showSuccess(avatar ? 'Đổi ảnh đại diện thành công' : 'Xóa ảnh đại diện thành công')
  } catch (error: unknown) {
    const err = error as { data?: { message?: string }; message?: string }
    showError(err.data?.message || err.message || 'Cập nhật ảnh đại diện thất bại')
  }
}

// Password Change State
const currentPassword = ref('')
const newPassword = ref('')
const confirmPassword = ref('')
const showCurrentPassword = ref(false)
const showNewPassword = ref(false)
const showConfirmPassword = ref(false)

const isPasswordFormValid = computed(() => {
  return (
    currentPassword.value.length > 0 &&
    newPassword.value.length >= 6 &&
    newPassword.value === confirmPassword.value &&
    newPassword.value !== currentPassword.value
  )
})

const { mutateAsync: changePasswordMutate, isLoading: isSaving } = useMutation(
  changeMyPasswordMutation(),
)

const resetPasswordForm = () => {
  currentPassword.value = ''
  newPassword.value = ''
  confirmPassword.value = ''
  showCurrentPassword.value = false
  showNewPassword.value = false
  showConfirmPassword.value = false
}

const handleSave = async () => {
  if (!isPasswordFormValid.value) return

  try {
    await changePasswordMutate({
      body: {
        currentPassword: currentPassword.value,
        newPassword: newPassword.value,
      },
    })
    showSuccess('Đổi mật khẩu thành công')
    resetPasswordForm()
  } catch (error: unknown) {
    const err = error as { data?: { message?: string }; message?: string }
    showError(err.data?.message || err.message || 'Đổi mật khẩu thất bại')
  }
}

const avatarInitials = computed(() => {
  return currentUser.value?.name?.trim().split(' ').pop()?.charAt(0).toUpperCase() || 'U'
})
</script>

<template>
  <div class="mx-auto max-w-4xl space-y-6">
    <UCard :ui="{ body: 'p-6 sm:p-8' }">
      <!-- Header -->
      <div class="border-b border-default pb-5">
        <h1 class="text-xl font-bold text-default sm:text-2xl">Hồ sơ cá nhân</h1>
      </div>

      <!-- Top Section: User Info on Left, Password Form on Right -->
      <div class="mt-6 flex flex-col gap-8 sm:flex-row sm:items-start sm:justify-between">
        <div class="min-w-0 space-y-4 sm:max-w-xs">
          <UUser
            size="3xl"
            :name="currentUser?.name"
            :description="currentUser?.username"
            :avatar="{ src: currentUser?.avatar || undefined, text: avatarInitials }"
          />
          <div class="flex flex-wrap gap-2">
            <UButton
              label="Đổi ảnh đại diện"
              icon="i-lucide-image-plus"
              variant="outline"
              size="sm"
              :disabled="!currentUser || isSavingAvatar"
              @click="avatarDialogOpen = true"
            />
            <UButton
              label="Xóa ảnh đại diện"
              icon="i-lucide-trash-2"
              color="error"
              variant="ghost"
              size="sm"
              :disabled="!currentUser?.avatar || isSavingAvatar"
              :loading="isSavingAvatar && !avatarDialogOpen"
              @click="saveAvatar('')"
            />
          </div>
        </div>

        <!-- Form Đổi mật khẩu bên cạnh UUser -->
        <div class="w-full max-w-md space-y-4">
          <h2 class="text-base font-semibold text-default">Đổi mật khẩu</h2>

          <!-- Mật khẩu hiện tại -->
          <div class="space-y-1.5">
            <label class="text-sm font-medium text-default">
              Mật khẩu hiện tại <span class="text-error-500">*</span>
            </label>
            <UInput
              v-model="currentPassword"
              :type="showCurrentPassword ? 'text' : 'password'"
              placeholder="Nhập mật khẩu hiện tại"
              icon="i-lucide-lock"
              class="w-full"
            >
              <template #trailing>
                <UButton
                  :icon="showCurrentPassword ? 'i-lucide-eye-off' : 'i-lucide-eye'"
                  color="neutral"
                  variant="ghost"
                  size="xs"
                  aria-label="Hiện/ẩn mật khẩu hiện tại"
                  @click="showCurrentPassword = !showCurrentPassword"
                />
              </template>
            </UInput>
          </div>

          <!-- Mật khẩu mới -->
          <div class="space-y-1.5">
            <label class="text-sm font-medium text-default">
              Mật khẩu mới <span class="text-error-500">*</span>
            </label>
            <UInput
              v-model="newPassword"
              :type="showNewPassword ? 'text' : 'password'"
              placeholder="Nhập mật khẩu mới (tối thiểu 6 ký tự)"
              icon="i-lucide-key"
              class="w-full"
            >
              <template #trailing>
                <UButton
                  :icon="showNewPassword ? 'i-lucide-eye-off' : 'i-lucide-eye'"
                  color="neutral"
                  variant="ghost"
                  size="xs"
                  aria-label="Hiện/ẩn mật khẩu mới"
                  @click="showNewPassword = !showNewPassword"
                />
              </template>
            </UInput>
            <span v-if="newPassword && newPassword.length < 6" class="text-xs text-error-500">
              Mật khẩu mới phải có ít nhất 6 ký tự
            </span>
            <span
              v-else-if="newPassword && currentPassword && newPassword === currentPassword"
              class="text-xs text-error-500"
            >
              Mật khẩu mới không được trùng với mật khẩu hiện tại
            </span>
          </div>

          <!-- Xác nhận mật khẩu mới -->
          <div class="space-y-1.5">
            <label class="text-sm font-medium text-default">
              Xác nhận mật khẩu mới <span class="text-error-500">*</span>
            </label>
            <UInput
              v-model="confirmPassword"
              :type="showConfirmPassword ? 'text' : 'password'"
              placeholder="Nhập lại mật khẩu mới"
              icon="i-lucide-key-round"
              class="w-full"
            >
              <template #trailing>
                <UButton
                  :icon="showConfirmPassword ? 'i-lucide-eye-off' : 'i-lucide-eye'"
                  color="neutral"
                  variant="ghost"
                  size="xs"
                  aria-label="Hiện/ẩn xác nhận mật khẩu"
                  @click="showConfirmPassword = !showConfirmPassword"
                />
              </template>
            </UInput>
            <span
              v-if="confirmPassword && newPassword !== confirmPassword"
              class="text-xs text-error-500"
            >
              Mật khẩu xác nhận không khớp
            </span>
          </div>
        </div>
      </div>

      <!-- Bottom Section: Đơn vị công tác, Vai trò & Quyền hạn -->
      <div class="mt-6 space-y-6 pt-6">
        <ProfileMemberships :memberships="currentUser?.memberships" />

        <!-- Nút lưu ở cuối -->
        <div class="flex justify-end border-t border-default pt-5">
          <UButton
            label="Lưu thay đổi"
            icon="i-lucide-check"
            color="primary"
            :loading="isSaving"
            :disabled="!isPasswordFormValid || isSaving"
            @click="handleSave"
          />
        </div>
      </div>
    </UCard>
    <ProfileAvatarDialog
      v-model:open="avatarDialogOpen"
      :saving="isSavingAvatar"
      @save="saveAvatar"
    />
  </div>
</template>
