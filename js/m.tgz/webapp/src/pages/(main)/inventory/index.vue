<script setup lang="ts">
import { ROUTE_PATH } from '@/app/router/path'
import type { InventoryListRow } from '@/features/inventory/inventory-request/inventoryRequest'
import { useAuthStore } from '@/shared/stores/auth'
import type { TableColumn, TableRow } from '@nuxt/ui'
import { useRoute, useRouter } from 'vue-router'
import dayjs from 'dayjs'
import { getProductionOrderNumber } from '@/features/production/helpers/productionOrder'
import { handleRowNavigation, handleTableAuxClick } from '@/shared/utils/navigation'
import { computed, shallowRef } from 'vue'
import {
  useInventoryRequestList,
  type InventoryRequestKind,
} from '@/features/inventory/inventory-request/useInventoryRequestList'

const router = useRouter()
const route = useRoute()
const { hasPermission, currentUser } = useAuthStore()

const requestKind = shallowRef<InventoryRequestKind>(
  (route.query.type as InventoryRequestKind) || 'return',
)

const requestKindOptions = [
  { label: 'Trả lại', value: 'return' },
  { label: 'Điều chuyển', value: 'transfer' },
]

const showReceiveTab = computed(() => {
  const unitType = requestKind.value === 'return' ? 'WAREHOUSE' : 'TEAM'
  return (
    currentUser.value?.memberships.some(
      (m) =>
        m.unitType === unitType &&
        m.roles.some((r) => r.permissions.some((p) => p.code === 'RECEIVE_REQUEST')),
    ) ?? false
  )
})

const {
  activeTab,
  filters,
  tableData,
  totalRecords,
  loading,
  handlePageChange,
  counters,
  filterOptions,
  statusOptions,
  clearFilters,
  isCreatedTab,
  isEvaluateTab,
  requestTypeLabel,
  requestTypeSeverity,
  requestIdForRow,
  getStatusLabel,
  getStatusSeverity,
} = useInventoryRequestList(hasPermission, showReceiveTab, requestKind)
const columns: TableColumn<InventoryListRow>[] = [
  { accessorKey: 'styleName', header: 'Mã hàng' },
  { accessorKey: 'productionOrderCode', header: 'Lệnh số' },
  { id: 'requestCode', header: 'Mã yêu cầu' },
  { accessorKey: 'requestType', header: 'Loại' },
  { accessorKey: 'status', header: 'Trạng thái' },
  { accessorKey: 'createdAt', header: 'Ngày tạo' },
  { accessorKey: 'sourceName', header: 'Tổ yêu cầu' },
  { accessorKey: 'createdByName', header: 'Người tạo' },
]
const page = computed({
  get: () => filters.page + 1,
  set: (value: number) =>
    handlePageChange({ page: value - 1, rows: filters.size, first: 0, pageCount: 0 }),
})

const tabItems = computed(() =>
  [
    hasPermission('CREATE_REQUEST') && {
      label: `Đã tạo${counters.value.created ? ` (${counters.value.created})` : ''}`,
      value: 'created',
    },
    hasPermission('EVALUATE_REQUEST') && {
      label: `Chờ phê duyệt${counters.value.evaluate ? ` (${counters.value.evaluate})` : ''}`,
      value: 'evaluate',
    },
    showReceiveTab.value && {
      label: `Nhận vật tư${counters.value.receive ? ` (${counters.value.receive})` : ''}`,
      value: 'receive',
    },
  ].filter((item): item is { label: string; value: string } => !!item),
)

function handleRowClick(event: Event, row: TableRow<InventoryListRow>) {
  const requestId = requestIdForRow(row.original)
  handleRowNavigation(event, router, {
    path: ROUTE_PATH.INVENTORY_DETAIL.replace(':id', requestId),
    query: { type: requestKind.value },
  })
}

function handleAuxClick(event: MouseEvent) {
  handleTableAuxClick(event, router, tableData.value, (row) => {
    const requestId = requestIdForRow(row)
    return {
      path: ROUTE_PATH.INVENTORY_DETAIL.replace(':id', requestId),
      query: { type: requestKind.value },
    }
  })
}

function getRequestCode(row: InventoryListRow) {
  if ('returnCode' in row) return row.returnCode
  if ('transferCode' in row) return row.transferCode
  return ''
}

function getRequestType(row: InventoryListRow) {
  return ('requestType' in row && row.requestType) || requestTypeLabel.value
}

function getSourceName(row: InventoryListRow) {
  if ('sourceName' in row && row.sourceName) return row.sourceName
  if ('teamAssignmentId' in row) return row.teamAssignmentId
  return 'N/A'
}
</script>

<template>
  <div class="flex flex-col gap-4">
    <div class="flex items-center justify-between">
      <UBreadcrumb
        :items="[
          { icon: 'i-lucide-house', url: '/' },
          ...[{ label: 'Trả lại / Điều chuyển', icon: 'i-lucide-arrow-right-left' }],
        ]"
        class="bg-transparent!"
      />
      <UTabs v-model="requestKind" :items="requestKindOptions" :content="false" variant="link" />
    </div>

    <UCard>
      <template #default>
        <UTabs v-model="activeTab" :items="tabItems" :content="false" variant="link" />

        <div class="mt-8 mb-4 flex flex-wrap items-end gap-4 px-2">
          <UFormField label="Mã hàng">
            <USelectMenu
              multiple
              id="styleName"
              v-model="filters.styleName"
              :items="filterOptions.styleNames"
              search-input
              class="w-48"
            />
          </UFormField>
          <UFormField label="Lệnh số">
            <USelectMenu
              multiple
              id="poCode"
              v-model="filters.productionOrderCode"
              :items="filterOptions.productionOrderCodes"
              search-input
              class="w-48"
            />
          </UFormField>
          <UFormField label="Mã yêu cầu">
            <USelectMenu
              multiple
              id="requestCode"
              v-model="filters.requestCode"
              :items="filterOptions.requestCodes"
              search-input
              class="w-48"
            />
          </UFormField>
          <UFormField v-if="activeTab !== 'evaluate'" label="Trạng thái">
            <USelectMenu
              multiple
              id="statuses"
              v-model="filters.statuses"
              :items="statusOptions"
              label-key="label"
              value-key="value"
              search-input
              class="w-56"
            />
          </UFormField>
          <UFormField label="Tổ yêu cầu">
            <USelectMenu
              multiple
              id="teamIds"
              v-model="filters.teamIds"
              :items="filterOptions.teams"
              label-key="name"
              value-key="id"
              search-input
              class="w-72"
            />
          </UFormField>
          <UButton
            icon="i-lucide-filter-x"
            color="neutral"
            variant="outline"
            class="mb-0.5"
            @click="clearFilters"
          />
        </div>

        <UTable
          :data="tableData"
          :columns="columns"
          :loading="loading"
          :ui="{ tr: 'cursor-pointer' }"
          @select="handleRowClick"
          @auxclick="handleAuxClick"
        >
          <template #styleName-cell="{ row }">
            <RouterLink
              :to="{
                path: ROUTE_PATH.INVENTORY_DETAIL.replace(':id', requestIdForRow(row.original)),
                query: { type: requestKind },
              }"
              class="font-medium hover:text-primary hover:underline"
              @click.stop
            >
              {{ row.original.styleName }}
            </RouterLink>
          </template>
          <template #productionOrderCode-cell="{ row }">
            {{ getProductionOrderNumber(row.original.productionOrderCode) }}
          </template>
          <template #requestCode-cell="{ row }">
            <RouterLink
              :to="{
                path: ROUTE_PATH.INVENTORY_DETAIL.replace(':id', requestIdForRow(row.original)),
                query: { type: requestKind },
              }"
              class="font-mono font-semibold hover:text-primary hover:underline"
              @click.stop
            >
              {{ getRequestCode(row.original) }}
            </RouterLink>
          </template>
          <template #requestType-cell="{ row }">
            <UBadge :label="getRequestType(row.original)" :color="requestTypeSeverity" />
          </template>
          <template #status-cell="{ row }">
            <UBadge
              v-if="isCreatedTab || isEvaluateTab"
              :label="getStatusLabel(row.original.status)"
              :color="getStatusSeverity(row.original.status)"
            />
            <UBadge
              v-else
              :label="row.original.status === 'ACTIVE' ? 'Đã duyệt / Chờ nhận' : 'Đã nhận'"
              :color="row.original.status === 'ACTIVE' ? 'info' : 'success'"
            />
          </template>
          <template #createdAt-cell="{ row }">
            {{
              row.original.createdAt ? dayjs(row.original.createdAt).format('DD/MM/YYYY HH:mm') : ''
            }}
          </template>
          <template #sourceName-cell="{ row }">
            {{ getSourceName(row.original) }}
          </template>

          <template #empty> Không có dữ liệu. </template>
        </UTable>

        <div class="mt-3 flex justify-end">
          <UPagination v-model:page="page" :total="totalRecords" :items-per-page="filters.size" />
        </div>
      </template>
    </UCard>
  </div>
</template>
