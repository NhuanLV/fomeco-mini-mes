<script setup lang="ts">
import { ROUTE_PATH } from '@/app/router/path'
import type { NormalizedInventoryRequestItem } from '@/features/inventory/inventory-request/inventoryRequest'
import { useAuthStore } from '@/shared/stores/auth'
import type { TableColumn } from '@nuxt/ui'
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import ReturnRequestHistoryTimeline from '@/features/inventory/components/ReturnRequestHistoryTimeline.vue'
import { useInventoryRequestDetail } from '@/features/inventory/inventory-request/useInventoryRequestDetail'
import { rejectComma } from '@/shared/utils/numberInput'
import { fmtQty } from '@/shared/utils/fmtQty'
import dayjs from 'dayjs'
import { makeArticleVariantComparator } from '@/shared/utils/orderedValues'

const route = useRoute()
const requestId = route.params.id as string
const { hasPermission } = useAuthStore()

const requestKind = computed(() => (route.query.type === 'transfer' ? 'transfer' : 'return'))

const {
  isTransferRequest,
  isLoading,
  normalizedData,
  isReviseMode,
  canApproveOrReject,
  canReceive,
  isApproving,
  isRejecting,
  isReceiving,
  isUpdating,
  showRejectDialog,
  rejectReason,
  reviseItems,
  handleApprove,
  handleReject,
  handleReceiveAction,
  handleUpdate,
  sourceName,
  requestTypeLabel,
  requestTypeSeverity,
  getStatusLabel,
  getStatusSeverity,
} = useInventoryRequestDetail({ requestId, requestKind, hasPermission })

const tableRows = computed(() =>
  [...(isReviseMode.value ? reviseItems.value : (normalizedData.value?.items ?? []))].sort(
    makeArticleVariantComparator(),
  ),
)
const columns = computed<TableColumn<NormalizedInventoryRequestItem>[]>(() => [
  { accessorKey: 'article', header: 'Vật tư' },
  { accessorKey: 'uom', header: 'ĐVT' },
  { accessorKey: 'color', header: 'Màu' },
  { accessorKey: 'size', header: 'Cỡ' },
  { accessorKey: 'quantity', header: 'Số lượng' },
  { accessorKey: 'targetName', header: 'Nơi nhận' },
  ...(isTransferRequest.value
    ? [{ accessorKey: 'targetProductionOrderCode', header: 'Lệnh công đoạn' }]
    : []),
])
</script>

<template>
  <div class="flex flex-col gap-6">
    <div class="flex items-center justify-between">
      <UBreadcrumb
        :items="[
          { icon: 'i-lucide-house', url: '/' },
          ...[
            {
              label: 'Trả lại / Điều chuyển',
              icon: 'i-lucide-arrow-right-left',
              url: ROUTE_PATH.INVENTORY,
            },
            { label: 'Chi tiết yêu cầu', icon: 'i-lucide-package-search' },
          ],
        ]"
        class="bg-transparent!"
      />
    </div>

    <div v-if="isLoading && !normalizedData" class="flex justify-center p-8">
      <UIcon name="i-lucide-loader-circle" class="animate-spin text-4xl text-primary" />
    </div>

    <template v-else-if="normalizedData">
      <UCard class="mb-6">
        <template #title>
          <div class="flex items-center justify-between">
            <span>Thông tin chung</span>
            <div class="flex gap-2 text-sm font-normal">
              <template v-if="canApproveOrReject">
                <UButton
                  label="Từ chối"
                  icon="i-lucide-x"
                  color="error"
                  variant="outline"
                  @click="showRejectDialog = true"
                  :disabled="isApproving"
                />
                <UButton
                  label="Phê duyệt"
                  icon="i-lucide-check"
                  color="success"
                  @click="handleApprove"
                  :loading="isApproving"
                />
              </template>
              <template v-if="canReceive">
                <UButton
                  label="Xác nhận"
                  icon="i-lucide-package-check"
                  @click="handleReceiveAction"
                  :loading="isReceiving"
                />
              </template>

              <template v-if="isReviseMode">
                <UButton
                  label="Cập nhật và Gửi lại"
                  icon="i-lucide-send"
                  color="primary"
                  @click="handleUpdate"
                  :loading="isUpdating"
                />
              </template>
            </div>
          </div>
        </template>
        <template #default>
          <div class="grid grid-cols-1 gap-6 md:grid-cols-4">
            <div class="flex flex-col gap-1">
              <span class="text-sm font-medium text-toned">Tổ yêu cầu</span>
              <span class="text-lg font-semibold text-highlighted">{{ sourceName }}</span>
            </div>
            <div class="flex flex-col gap-1">
              <span class="text-sm font-medium text-toned">Loại</span>
              <div>
                <UBadge :label="requestTypeLabel" :color="requestTypeSeverity" />
              </div>
            </div>
            <div class="flex flex-col gap-1">
              <span class="text-sm font-medium text-toned">Trạng thái</span>
              <div>
                <UBadge
                  :label="getStatusLabel(normalizedData.status)"
                  :color="getStatusSeverity(normalizedData.status)"
                />
              </div>
            </div>
            <div class="flex flex-col gap-1">
              <span class="text-sm font-medium text-toned">Người tạo</span>
              <span class="font-medium text-highlighted">
                {{ normalizedData.createdByName }}
                <span class="ml-1 text-sm text-toned">
                  ({{ dayjs(normalizedData.createdAt).format('DD/MM/YYYY HH:mm') }})
                </span>
              </span>
            </div>
          </div>
        </template>
      </UCard>

      <div class="rounded-lg bg-white p-6 shadow-sm">
        <div v-if="normalizedData.rejectReason" class="mb-6 rounded bg-surface-50 p-4">
          <p class="mb-1 font-medium">Lý do từ chối:</p>
          <p class="text-default">{{ normalizedData.rejectReason }}</p>
        </div>

        <h3 class="mb-4 text-lg font-semibold">Danh sách vật tư</h3>
        <UTable :data="tableRows" :columns="columns">
          <template #quantity-cell="{ row }">
            <UInput
              v-if="isReviseMode"
              v-model.number="row.original.quantity"
              type="text"
              inputmode="decimal"
              min="0"
              step="0.0001"
              class="w-24"
              @beforeinput="rejectComma"
            />
            <span v-else>{{ fmtQty(row.original.quantity) }}</span>
          </template>
        </UTable>
      </div>

      <ReturnRequestHistoryTimeline
        :request-id="requestId"
        :request-kind="requestKind"
        :request-type="requestTypeLabel"
      />

      <UModal v-model:open="showRejectDialog" title="Từ chối yêu cầu" class="sm:max-w-[30vw]">
        <template #body>
          <div class="flex flex-col gap-2">
            <label for="reason">Lý do từ chối</label>
            <UTextarea id="reason" v-model="rejectReason" :rows="4" autoresize />
          </div>
        </template>
        <template #footer>
          <UButton
            label="Hủy"
            icon="i-lucide-x"
            variant="ghost"
            @click="showRejectDialog = false"
          />
          <UButton
            label="Xác nhận"
            icon="i-lucide-check"
            color="error"
            @click="handleReject"
            :loading="isRejecting"
            :disabled="!rejectReason.trim()"
          />
        </template>
      </UModal>
    </template>

    <div
      v-else
      class="flex flex-col items-center justify-center rounded-lg bg-white p-12 shadow-sm"
    >
      <UIcon name="i-lucide-circle-alert" class="mb-4 text-5xl text-red-500" />
      <h2 class="text-xl font-semibold text-highlighted">Không tìm thấy yêu cầu</h2>
    </div>
  </div>
</template>
