import { flushPromises, mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { ref } from 'vue'
import ProfileAvatarDialog from '@/features/profile/components/ProfileAvatarDialog.vue'
import ProfilePage from '../profile.vue'

const mockCurrentUser = ref({
  id: 'user-001',
  name: 'Nguyễn Văn Test',
  username: 'test_user',
  avatar: null as string | null,
  memberships: [
    {
      unitId: 'unit-01',
      unitName: 'Tổ May 01',
      unitType: 'TEAM',
      factoryName: 'Xí nghiệp 1',
      companyName: 'Công ty May LGG',
      roles: [
        {
          id: 'role-01',
          name: 'Tổ trưởng',
          description: 'Quản lý chuyền may',
          permissionCount: 1,
          isSystem: false,
          permissions: [
            {
              code: 'REPORT_PROGRESS' as const,
              displayName: 'Báo cáo tiến độ',
              description: 'Tổ trưởng nhập sản lượng',
              groupCode: 'PROGRESS_REPORTING' as const,
              groupDisplayName: 'Tiến độ & báo cáo',
            },
          ],
        },
      ],
    },
  ],
})

vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({
    currentUser: mockCurrentUser,
    checkAuth: vi.fn(),
  }),
}))

const mutateAsync = vi.fn()
vi.mock('@/shared/utils/toast', () => ({ showError: vi.fn(), showSuccess: vi.fn() }))

vi.mock('@pinia/colada', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@pinia/colada')>()),
  useMutation: () => ({
    mutateAsync,
    isLoading: ref(false),
  }),
}))

describe('ProfilePage', () => {
  beforeEach(() => {
    mutateAsync.mockReset().mockResolvedValue(undefined)
    mockCurrentUser.value.avatar = null
  })

  it('saves the cropped data URL and updates the displayed avatar after success', async () => {
    const wrapper = mount(ProfilePage)
    await wrapper
      .findAll('button')
      .find((b) => b.text() === 'Đổi ảnh đại diện')!
      .trigger('click')
    const dialog = wrapper.findComponent(ProfileAvatarDialog)
    expect(dialog.props('open')).toBe(true)
    const avatar = 'data:image/webp;base64,dGVzdA=='
    dialog.vm.$emit('save', avatar)
    await flushPromises()
    expect(mutateAsync).toHaveBeenCalledWith({ body: avatar })
    expect(mockCurrentUser.value.avatar).toBe(avatar)
    expect(dialog.props('open')).toBe(false)
    wrapper.unmount()
  })

  it('sends an empty body to delete the avatar', async () => {
    mockCurrentUser.value.avatar = 'data:image/webp;base64,dGVzdA=='
    const wrapper = mount(ProfilePage)
    await wrapper
      .findAll('button')
      .find((b) => b.text() === 'Xóa ảnh đại diện')!
      .trigger('click')
    await flushPromises()
    expect(mutateAsync).toHaveBeenCalledWith({ body: '' })
    expect(mockCurrentUser.value.avatar).toBeNull()
    wrapper.unmount()
  })

  it('keeps the previous avatar and dialog open when saving fails', async () => {
    mockCurrentUser.value.avatar = 'previous-avatar'
    mutateAsync.mockRejectedValueOnce(new Error('Failed'))
    const wrapper = mount(ProfilePage)
    await wrapper
      .findAll('button')
      .find((b) => b.text() === 'Đổi ảnh đại diện')!
      .trigger('click')
    const dialog = wrapper.findComponent(ProfileAvatarDialog)
    dialog.vm.$emit('save', 'data:image/webp;base64,dGVzdA==')
    await flushPromises()
    expect(mockCurrentUser.value.avatar).toBe('previous-avatar')
    expect(dialog.props('open')).toBe(true)
    wrapper.unmount()
  })

  it('renders user profile info, username, inline password form, and units with collapsible roles', async () => {
    const wrapper = mount(ProfilePage)
    expect(wrapper.text()).toContain('Hồ sơ cá nhân')
    expect(wrapper.text()).toContain('test_user')
    expect(wrapper.text()).toContain('Tổ May 01')
    expect(wrapper.text()).toContain('Đổi mật khẩu')
    expect(wrapper.text()).toContain('Mật khẩu hiện tại')
    expect(wrapper.text()).toContain('Mật khẩu mới')
    expect(wrapper.text()).toContain('Xác nhận mật khẩu mới')
    expect(wrapper.text()).toContain('Lưu thay đổi')

    // Initially collapsed by default
    expect(wrapper.text()).not.toContain('Tổ trưởng')
    expect(wrapper.text()).not.toContain('Báo cáo tiến độ')

    // Click unit to expand roles and permissions
    const unitButton = wrapper.find('button[aria-expanded="false"]')
    expect(unitButton.exists()).toBe(true)
    await unitButton.trigger('click')

    // Roles and permissions should now be visible
    expect(wrapper.text()).toContain('Tổ trưởng')
    expect(wrapper.text()).toContain('Báo cáo tiến độ')

    // Click again to collapse
    await unitButton.trigger('click')
    expect(wrapper.text()).not.toContain('Tổ trưởng')
    expect(wrapper.text()).not.toContain('Báo cáo tiến độ')
  })

  it('validates password inputs before enabling save button', async () => {
    const wrapper = mount(ProfilePage)
    const saveButton = wrapper.findAll('button').find((b) => b.text().includes('Lưu thay đổi'))
    expect(saveButton?.attributes('disabled')).toBeDefined()

    const inputs = wrapper.findAll('input')
    expect(inputs.length).toBe(3)

    // Fill current password and new password
    await inputs[0].setValue('old_pass_123')
    await inputs[1].setValue('new_pass_456')
    await inputs[2].setValue('new_pass_456')

    expect(saveButton?.attributes('disabled')).toBeUndefined()
  })
})
