import { mount } from '@vue/test-utils'
import { ref } from 'vue'
import { describe, expect, it, vi } from 'vitest'
import AccountsPage from '../accounts.vue'

const accounts = [
  { id: 'z', name: 'Zed', username: 'zed', memberships: [] },
  {
    id: 'a',
    name: 'An',
    username: 'an',
    memberships: [
      {
        id: 'm1',
        unitName: 'Tổ 1',
        roles: [{ id: 'ffffffff-ffff-ffff-ffff-ffffffffffff', name: 'Admin' }],
      },
      { id: 'm2', unitName: 'Tổ 2', roles: [] },
    ],
  },
]

vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({
    hasPermission: () => true,
    checkAuth: vi.fn(),
  }),
}))

vi.mock('@/shared/composables/useConfirm', () => ({
  useConfirm: () => ({ require: vi.fn() }),
}))

vi.mock('@pinia/colada', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@pinia/colada')>()),
  useQuery: () => ({ data: ref({ content: accounts }), status: ref('success'), refetch: vi.fn() }),
  useMutation: () => ({ mutateAsync: vi.fn() }),
}))

vi.mock('vue-router', async (importOriginal) => ({
  ...(await importOriginal<typeof import('vue-router')>()),
  useRouter: () => ({ push: vi.fn() }),
}))

describe('accounts table', () => {
  it('sorts accounts by name and row-spans repeated account cells', () => {
    const wrapper = mount(AccountsPage)
    const table = wrapper.findComponent({ name: 'Table' })
    const rows = table.props('data')

    expect(rows.map((row: { name: string }) => row.name)).toEqual(['An', 'An', 'Zed'])
    expect(wrapper.find('tbody tr:first-child td:first-child').attributes('rowspan')).toBe('2')
  })

  it('renders UUser with Super Admin description only for admin accounts', () => {
    const wrapper = mount(AccountsPage)
    const userComponents = wrapper.findAllComponents({ name: 'User' })

    expect(userComponents.length).toBeGreaterThan(0)
    const adminUser = userComponents.find((c) => c.props('name') === 'An')
    const normalUser = userComponents.find((c) => c.props('name') === 'Zed')

    expect(adminUser?.props('description')).toBe('Super Admin')
    expect(normalUser?.props('description')).toBeUndefined()
  })
})
