<script setup lang="ts">
import type { BuyerOrderFilterOptionsVm } from '@/api'
import {
  getBuyerOrderFilterOptionsQuery,
  getBuyerOrdersQuery,
  syncFromWfxMutation,
} from '@/api/@pinia/colada.gen'
import BuyerOrderDataTable from '@/features/buyer-order/components/BuyerOrderDataTable.vue'
import BuyerOrderSearchBar from '@/features/buyer-order/components/BuyerOrderSearchBar.vue'
import { getStatusLabel } from '@/features/buyer-order/helpers/status'
import { useAuthStore } from '@/shared/stores/auth'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useMutation, useQuery } from '@pinia/colada'
import dayjs from 'dayjs'
import AppDatePicker from '@/shared/components/AppDatePicker.vue'
import type { TablePageEvent, TableSortEvent } from '@/shared/types/table'
import { computed, onMounted, ref, watch } from 'vue'

definePage({ meta: { requiredPermission: 'MANAGE_BUYER_ORDER' } })

const { hasPermission, currentUser } = useAuthStore()

interface BuyerOrderFilters {
  wfxId: string | null
  customer: string | null
  brand: string | null
  season: string | null
  style: string | null
  status: string | null
  search: string | null
  deliveryDateFrom: string | null
  deliveryDateTo: string | null
  sortField: string | null
  sortOrder: 'asc' | 'desc' | null
  page: number
  size: number
}

const filters = ref<BuyerOrderFilters>({
  wfxId: null,
  customer: null,
  brand: null,
  season: null,
  style: null,
  status: null,
  search: null,
  deliveryDateFrom: null,
  deliveryDateTo: null,
  sortField: 'id',
  sortOrder: 'desc',
  page: 0,
  size: 20,
})

const localSearch = ref('')
const dateRange = ref<Date[] | null>(null)
const syncModifiedFrom = ref<Date | null>(dayjs().toDate())

// Watcher for dateRange to update filters
watch(dateRange, (newRange) => {
  if (newRange && newRange.length === 2 && newRange[0] && newRange[1]) {
    filters.value.deliveryDateFrom = dayjs(newRange[0]).format('YYYY-MM-DD')
    filters.value.deliveryDateTo = dayjs(newRange[1]).format('YYYY-MM-DD')
  } else {
    filters.value.deliveryDateFrom = null
    filters.value.deliveryDateTo = null
  }
  filters.value.page = 0
})

// Queries
const {
  data: ordersResponse,
  isPending: ordersPending,
  refetch: refetchOrders,
} = useQuery(() => ({
  ...getBuyerOrdersQuery({
    query: {
      wfxId: filters.value.wfxId ?? undefined,
      customer: filters.value.customer ?? undefined,
      brand: filters.value.brand ?? undefined,
      season: filters.value.season ?? undefined,
      style: filters.value.style ?? undefined,
      status: filters.value.status ?? undefined,
      search: filters.value.search ?? undefined,
      deliveryDateFrom: filters.value.deliveryDateFrom ?? undefined,
      deliveryDateTo: filters.value.deliveryDateTo ?? undefined,

      page: filters.value.page,
      size: filters.value.size,
      sort: [`${filters.value.sortField},${filters.value.sortOrder}`],
    } as NonNullable<Parameters<typeof getBuyerOrdersQuery>[0]>['query'] & {
      deliveryDateFrom?: string
      deliveryDateTo?: string
    },
  }),
}))

const { data: filterOptionsResponse, refetch: refetchFilterOptions } = useQuery(
  getBuyerOrderFilterOptionsQuery(),
)

// Mutations
const { mutateAsync: syncMutate, isLoading: syncing } = useMutation(syncFromWfxMutation())

// State
const orders = computed(() => ordersResponse.value?.content ?? [])
const totalRecords = computed(() => ordersResponse.value?.page?.totalElements ?? 0)
const loading = computed(() => ordersPending.value)

const filterOptions = computed<BuyerOrderFilterOptionsVm>(
  () =>
    filterOptionsResponse.value ?? {
      wfxIds: [],
      customers: [],
      brands: [],
      seasons: [],
      styles: [],
      statuses: [],
    },
)

const handleFilterChange = (field: keyof BuyerOrderFilters, value: string | null) => {
  filters.value = {
    ...filters.value,
    [field]: value,
    page: 0,
  }
}

const handleClearAll = () => {
  localSearch.value = ''
  dateRange.value = null
  filters.value = {
    wfxId: null,
    customer: null,
    brand: null,
    season: null,
    style: null,
    status: null,
    search: null,
    deliveryDateFrom: null,
    deliveryDateTo: null,
    sortField: 'id',
    sortOrder: 'desc',
    page: 0,
    size: 20,
  }
}

const wfxIdOptions = computed(() =>
  filterOptions.value.wfxIds.map((id) => ({ label: id, value: id })),
)
const customerOptions = computed(() =>
  filterOptions.value.customers.map((c) => ({ label: c, value: c })),
)
const brandOptions = computed(() => filterOptions.value.brands.map((b) => ({ label: b, value: b })))
const seasonOptions = computed(() =>
  filterOptions.value.seasons.map((s) => ({ label: s, value: s })),
)
const styleOptions = computed(() => filterOptions.value.styles.map((s) => ({ label: s, value: s })))
const statusOptions = computed(() =>
  filterOptions.value.statuses.map((s) => ({ label: getStatusLabel(s), value: s })),
)

const handlePageChange = (event: TablePageEvent) => {
  filters.value.page = event.page
  filters.value.size = event.rows
}

const handleSortChange = (event: TableSortEvent) => {
  filters.value.sortField = (event.sortField as string) || 'id'
  filters.value.sortOrder = event.sortOrder === 1 ? 'asc' : 'desc'
  filters.value.page = 0
}

// Actions
async function syncFromErp() {
  try {
    await syncMutate({
      body: {
        modifiedFrom: syncModifiedFrom.value
          ? dayjs(syncModifiedFrom.value).format('YYYY-MM-DD')
          : null,
      },
    })
    await refetchOrders()
    await refetchFilterOptions()
    showSuccess('Đồng bộ dữ liệu thành công')
  } catch {
    showError('Đồng bộ dữ liệu thất bại')
  }
}

onMounted(() => {
  if (hasPermission('MANAGE_BUYER_ORDER')) {
    const today = dayjs().format('YYYY-MM-DD')
    const userId = currentUser.value?.id || 'unknown'
    const syncKey = `wfx_sync_${userId}`
    const lastSync = localStorage.getItem(syncKey)

    if (lastSync !== today) {
      void syncFromErp()
      localStorage.setItem(syncKey, today)
    }
  }
})
</script>

<template>
  <div class="flex flex-col gap-4">
    <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
      <UBreadcrumb
        :items="[
          { icon: 'i-lucide-house' },
          ...[{ label: 'Thông tin Đơn hàng', icon: 'i-lucide-clipboard-list' }],
        ]"
        class="bg-transparent!"
      />
      <div class="flex flex-wrap items-center justify-end gap-2 sm:flex-nowrap">
        <UButton
          color="neutral"
          variant="ghost"
          @click="handleClearAll"
          icon="i-lucide-circle-x"
          label="Xóa lọc"
        />
        <div v-if="hasPermission('MANAGE_BUYER_ORDER')" class="flex items-center gap-2">
          <UButton
            :loading="syncing"
            @click="syncFromErp"
            icon="i-lucide-refresh-cw"
            label="Đồng bộ WFX từ ngày: "
          />
          <AppDatePicker v-model="syncModifiedFrom" class="w-36" />
        </div>
      </div>
    </div>

    <BuyerOrderSearchBar
      v-model:search-query="localSearch"
      @search="handleFilterChange('search', localSearch)"
    />

    <UCard>
      <template #default>
        <BuyerOrderDataTable
          :orders="orders"
          :loading="loading"
          :total-records="totalRecords"
          :rows="filters.size"
          :first="filters.page * filters.size"
          :wfx-id-options="wfxIdOptions"
          :customer-options="customerOptions"
          :brand-options="brandOptions"
          :season-options="seasonOptions"
          :style-options="styleOptions"
          :status-options="statusOptions"
          v-model:wfx-id-filter="filters.wfxId"
          v-model:customer-filter="filters.customer"
          v-model:brand-filter="filters.brand"
          v-model:season-filter="filters.season"
          v-model:style-filter="filters.style"
          v-model:status-filter="filters.status"
          v-model:date-filter="dateRange"
          @filter-change="
            (field, value) => handleFilterChange(field as keyof BuyerOrderFilters, value)
          "
          @page-change="handlePageChange"
          @sort-change="handleSortChange"
        />
      </template>
    </UCard>
  </div>
</template>
