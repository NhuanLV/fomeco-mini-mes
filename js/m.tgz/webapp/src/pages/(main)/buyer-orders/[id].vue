<script setup lang="ts">
import type { PurchaseOrderVm } from '@/api'
import { useAuthStore } from '@/shared/stores/auth'
import { getBuyerOrderDetailQuery } from '@/api/@pinia/colada.gen'
import { ROUTE_PATH } from '@/app/router/path'
import BuyerOrderBomTable from '@/features/buyer-order/components/BuyerOrderBomTable.vue'
import BuyerOrderDetailHeader from '@/features/buyer-order/components/BuyerOrderDetailHeader.vue'
import BuyerOrderRoutingList from '@/features/buyer-order/components/BuyerOrderRoutingList.vue'
import BuyerOrderSummaryMatrix from '@/features/buyer-order/components/BuyerOrderSummaryMatrix.vue'
import { sortValuesByOrder } from '@/shared/utils/orderedValues'
import { fmtQty } from '@/shared/utils/fmtQty'
import PurchaseOrderSelectionList from '@/features/production/components/PurchaseOrderSelectionList.vue'
import type { TableColumn } from '@nuxt/ui'
import { useQuery } from '@pinia/colada'
import { useEventListener } from '@vueuse/core'
import { computed, nextTick, ref, watch } from 'vue'
import dayjs from 'dayjs'
import { onBeforeRouteLeave, useRoute, useRouter } from 'vue-router'

definePage({ meta: { requiredPermission: 'MANAGE_BUYER_ORDER' } })

const { hasPermission } = useAuthStore()
const route = useRoute()
const router = useRouter()
const id = computed(() => route.params.id as string)

// ─── Local state ─────────────────────────────────────────────────────────────
const selectedPOIds = ref<string[]>([])
const activeTab = ref(
  route.query.tab === 'bom' || route.query.tab === 'history' ? route.query.tab : 'orders',
)
const focusPOId = ref(typeof route.query.po === 'string' ? route.query.po : null)
const bomTable = ref<InstanceType<typeof BuyerOrderBomTable>>()

watch(activeTab, (newTab) => {
  if (route.query.tab !== newTab) {
    void router.replace({ query: { ...route.query, tab: newTab } })
  }
})

watch(
  () => route.query.tab,
  (newTabQuery) => {
    if (newTabQuery === 'bom' || newTabQuery === 'orders' || newTabQuery === 'history') {
      if (newTabQuery !== activeTab.value) {
        activeTab.value = newTabQuery
      }
    }
  },
)

const { data: currentOrder, isLoading: loading } = useQuery(() => ({
  ...getBuyerOrderDetailQuery({
    path: { id: id.value },
  }),
  enabled: !!id.value,
}))

watch(
  currentOrder,
  (order) => {
    if (order) {
      selectedPOIds.value = order.purchaseOrders.map((po) => po.id)
    }
  },
  { immediate: true },
)

const breadcrumbHome = { icon: 'i-lucide-house', to: ROUTE_PATH.DASHBOARD }
const breadcrumbItems = computed(() => [
  {
    label: 'Quản lý Đơn hàng',
    icon: 'i-lucide-clipboard-list',
    to: ROUTE_PATH.BUYER_ORDERS,
  },
  { label: currentOrder.value?.wfxId ?? '...', icon: 'i-lucide-shopping-bag' },
])

// ─── Derived state ────────────────────────────────────────────────────────────
const allSizes = computed(() => {
  if (!currentOrder.value) return []
  return sortValuesByOrder(
    currentOrder.value.purchaseOrders.flatMap((po) =>
      po.skuQuantities
        .map((sku) => sku.size)
        .filter((size): size is string => size !== null && size !== undefined)
        .map((size) => String(size).trim()),
    ),
    currentOrder.value.styleSizeOrder,
  )
})

const selectedPOs = computed((): PurchaseOrderVm[] => {
  if (!currentOrder.value) return []
  return currentOrder.value.purchaseOrders.filter((po) => selectedPOIds.value.includes(po.id))
})

type PurchaseOrderWithType = PurchaseOrderVm & {
  type?: 'REGULAR' | 'POSITIVE'
  createdBy?: { id: string; name: string } | null
  createdAt?: string | null
}

const positiveHistory = computed(() =>
  ((currentOrder.value?.purchaseOrders ?? []) as PurchaseOrderWithType[])
    .filter((po) => po.type === 'POSITIVE' && po.createdAt)
    .sort((a, b) => (b.createdAt ?? '').localeCompare(a.createdAt ?? '')),
)

const historyColumns: TableColumn<PurchaseOrderWithType>[] = [
  {
    accessorKey: 'createdAt',
    header: 'Thời gian',
    meta: { class: { th: 'whitespace-nowrap', td: 'whitespace-nowrap' } },
  },
  {
    accessorKey: 'code',
    header: 'Mã PO',
    meta: { class: { th: 'whitespace-nowrap', td: 'whitespace-nowrap' } },
  },
  {
    accessorKey: 'destination',
    header: 'Thị trường',
    meta: { class: { th: 'whitespace-nowrap', td: 'whitespace-nowrap' } },
  },
  {
    accessorKey: 'deliveryDate',
    header: 'Ngày giao',
    meta: { class: { th: 'whitespace-nowrap', td: 'whitespace-nowrap' } },
  },
  {
    accessorKey: 'totalQuantity',
    header: 'Tổng sản lượng',
    meta: { class: { th: 'whitespace-nowrap text-right', td: 'whitespace-nowrap text-right' } },
  },
  {
    id: 'createdBy',
    header: 'Người thực hiện',
    meta: { class: { th: 'whitespace-nowrap', td: 'whitespace-nowrap' } },
  },
]

const canAddPositivePO = computed(() => {
  const pos = currentOrder.value?.purchaseOrders ?? []
  const skus = pos.flatMap((po) => po.skuQuantities)
  return (
    hasPermission('CREATE_POSITIVE_PURCHASE_ORDER') &&
    pos.length > 0 &&
    skus.some((sku) => !!sku.color) &&
    skus.some((sku) => !!sku.size) &&
    pos.some((po) => !!po.destination)
  )
})

async function focusPO(poId: string) {
  focusPOId.value = poId
  activeTab.value = 'orders'
  await nextTick()
  document.getElementById(`po-${poId}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' })
}

watch(
  [currentOrder, () => route.query.po],
  async ([order, poId]) => {
    if (order && typeof poId === 'string' && order.purchaseOrders.some((po) => po.id === poId)) {
      await focusPO(poId)
    }
  },
  { immediate: true },
)

// ─── Selection handlers ───────────────────────────────────────────────────────
function handleTogglePO(id: string) {
  const idx = selectedPOIds.value.indexOf(id)
  if (idx >= 0) {
    selectedPOIds.value.splice(idx, 1)
  } else {
    selectedPOIds.value.push(id)
  }
}

function handleToggleAll(checked: boolean, filteredPOIds: string[]) {
  if (checked) {
    const toAdd = filteredPOIds.filter((id) => !selectedPOIds.value.includes(id))
    selectedPOIds.value.push(...toAdd)
  } else {
    selectedPOIds.value = selectedPOIds.value.filter((id) => !filteredPOIds.includes(id))
  }
}

function confirmDiscardBomChanges() {
  return bomTable.value?.confirmDiscardMaterialStateChanges() ?? true
}

onBeforeRouteLeave(confirmDiscardBomChanges)
useEventListener(window, 'beforeunload', (event) => {
  if (!bomTable.value?.hasUnsavedMaterialStateChanges) return
  event.preventDefault()
  event.returnValue = ''
})

// ─── Navigation ───────────────────────────────────────────────────────────────
</script>

<template>
  <!-- Loading State -->
  <div v-if="loading && !currentOrder" class="flex flex-col gap-4">
    <USkeleton height="5rem" border-radius="8px" />
    <USkeleton height="6rem" border-radius="8px" />
    <USkeleton height="12rem" border-radius="8px" />
    <USkeleton height="10rem" border-radius="8px" />
  </div>

  <!-- Error State -->
  <div v-else-if="!currentOrder" class="flex flex-col items-center justify-center gap-4 py-16">
    <UIcon name="i-lucide-circle-alert" class="size-16 text-toned" />
    <p class="text-lg text-toned">Không tìm thấy đơn hàng</p>
    <UButton label="Quay lại danh sách" :to="ROUTE_PATH.BUYER_ORDERS" />
  </div>

  <!-- Content -->
  <div v-else class="flex flex-col gap-4">
    <div class="flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
      <UBreadcrumb :items="[breadcrumbHome, ...breadcrumbItems]" class="bg-transparent!" />
      <div class="flex items-center justify-end gap-2">
        <UButton
          v-if="hasPermission('CREATE_POSITIVE_PURCHASE_ORDER')"
          :to="canAddPositivePO ? `/buyer-orders/${currentOrder.id}/add-positive-po` : undefined"
          icon="i-lucide-plus"
          label="Thêm PO hàng dương"
          color="success"
          variant="outline"
          class="bg-green-50 dark:bg-green-950/30"
          :disabled="!canAddPositivePO"
          :title="!canAddPositivePO ? 'BO chưa có đủ PO, màu/cỡ và thị trường' : undefined"
        />
        <UButton
          :to="{
            path: ROUTE_PATH.PRODUCTION_ORDER_ISSUE,
            query: { 'buyer-order': currentOrder.id },
          }"
          icon="i-lucide-file-plus-2"
          label="Tạo lệnh sản xuất"
          :disabled="currentOrder.needsAllocationRevision"
          :title="
            currentOrder.needsAllocationRevision
              ? 'BO đang vượt phân bổ; cần điều chỉnh các LSX trước'
              : undefined
          "
        />
      </div>
    </div>

    <BuyerOrderDetailHeader :order="currentOrder" />

    <UTabs
      v-model="activeTab"
      :items="[
        {
          label: 'Sản lượng',
          value: 'orders',
          icon: 'i-lucide-chart-no-axes-column-increasing',
        },
        { label: 'Định mức', value: 'bom', icon: 'i-lucide-calculator' },
        { label: 'Lịch sử', value: 'history', icon: 'i-lucide-history' },
      ]"
      :content="false"
      variant="link"
    />
    <div class="pt-4">
      <div v-if="activeTab === 'orders'" class="flex flex-col gap-4">
        <BuyerOrderSummaryMatrix
          :key="`summary-${id}-${allSizes.length}`"
          :selected-p-os="selectedPOs"
          :all-sizes="allSizes"
          :style-color-order="currentOrder.styleColorOrder"
        />
        <PurchaseOrderSelectionList
          :key="`selection-${id}-${allSizes.length}`"
          :pos="currentOrder.purchaseOrders"
          :all-sizes="allSizes"
          :style-color-order="currentOrder.styleColorOrder"
          :selected-p-o-ids="selectedPOIds"
          :focus-p-o-id="focusPOId"
          show-type-tabs
          @toggle-p-o="handleTogglePO"
          @toggle-all="handleToggleAll"
        >
          <template #po-actions="{ po }">
            <UButton
              v-if="po.type === 'POSITIVE' && hasPermission('CREATE_POSITIVE_PURCHASE_ORDER')"
              :to="{ path: `/buyer-orders/${id}/add-positive-po`, query: { po: po.id } }"
              label="Sửa PO"
              icon="i-lucide-pencil"
              variant="outline"
              @click.stop
            />
          </template>
        </PurchaseOrderSelectionList>
      </div>
      <div v-else-if="activeTab === 'bom'" class="flex flex-col gap-4">
        <BuyerOrderRoutingList :routings="currentOrder.routings" />
        <UCard>
          <template #default>
            <BuyerOrderBomTable
              ref="bomTable"
              :bo-id="currentOrder.id"
              :style-size-order="currentOrder.styleSizeOrder"
              :style-color-order="currentOrder.styleColorOrder"
            />
          </template>
        </UCard>
      </div>
      <UCard v-else>
        <template #title>
          <div class="flex items-center gap-2">
            <UIcon name="i-lucide-history" class="size-5 text-primary" />
            <span class="font-bold text-highlighted">Lịch sử thêm PO hàng dương</span>
          </div>
        </template>

        <UTable :data="positiveHistory" :columns="historyColumns" class="text-sm">
          <template #empty>
            <div class="flex flex-col items-center justify-center gap-2 py-8 text-center">
              <UIcon name="i-lucide-history" class="size-8 text-toned opacity-40" />
              <p class="text-sm text-toned">Chưa có thao tác thêm PO hàng dương nào.</p>
            </div>
          </template>

          <!-- Thời gian -->
          <template #createdAt-cell="{ row }">
            <span class="text-toned">
              {{ dayjs(row.original.createdAt).format('HH:mm, DD/MM/YYYY') }}
            </span>
          </template>

          <!-- Mã PO -->
          <template #code-cell="{ row }">
            <button
              type="button"
              class="cursor-pointer font-mono font-bold text-primary hover:underline"
              @click="focusPO(row.original.id)"
            >
              {{ row.original.code }}
            </button>
          </template>

          <!-- Thị trường -->
          <template #destination-cell="{ row }">
            <span class="text-default">{{ row.original.destination || '-' }}</span>
          </template>

          <!-- Ngày giao -->
          <template #deliveryDate-cell="{ row }">
            <span class="text-default">
              {{
                row.original.deliveryDate
                  ? dayjs(row.original.deliveryDate).format('DD/MM/YYYY')
                  : '-'
              }}
            </span>
          </template>

          <!-- Tổng sản lượng -->
          <template #totalQuantity-cell="{ row }">
            <span class="font-mono font-bold text-highlighted">
              {{ fmtQty(row.original.totalQuantity) }}
            </span>
          </template>

          <!-- Người thực hiện -->
          <template #createdBy-cell="{ row }">
            <span class="text-default">{{ row.original.createdBy?.name || '-' }}</span>
          </template>
        </UTable>
      </UCard>
    </div>
  </div>
</template>
