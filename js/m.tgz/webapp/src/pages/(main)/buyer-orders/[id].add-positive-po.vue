<script setup lang="ts">
import { client } from '@/api/client.gen'
import { getBuyerOrderDetailQuery } from '@/api/@pinia/colada.gen'
import { ROUTE_PATH } from '@/app/router/path'
import AppDatePicker from '@/shared/components/AppDatePicker.vue'
import ColorSizeMatrix from '@/shared/components/ColorSizeMatrix.vue'
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import MatrixColorCell from '@/shared/components/grid/MatrixColorCell.vue'
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import {
  matrixGridCell,
  type MatrixGridColumn,
  type MatrixGridEdit,
} from '@/shared/components/grid/matrixGrid'
import { fmtQty } from '@/shared/utils/fmtQty'
import { sortValuesByOrder } from '@/shared/utils/orderedValues'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useQuery, useQueryCache } from '@pinia/colada'
import { computed, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

definePage({ meta: { requiredPermission: 'CREATE_POSITIVE_PURCHASE_ORDER' } })

const route = useRoute()
const router = useRouter()
const queryCache = useQueryCache()
const boId = computed(() => route.params.id as string)
const editPoId = computed(() => (typeof route.query.po === 'string' ? route.query.po : null))
const isEditing = computed(() => editPoId.value !== null)
const pageTitle = computed(() => (isEditing.value ? 'Sửa PO hàng dương' : 'Thêm PO hàng dương'))
const { data: order, isLoading } = useQuery(() =>
  getBuyerOrderDetailQuery({ path: { id: boId.value } }),
)

const breadcrumbHome = { icon: 'i-lucide-house', to: ROUTE_PATH.DASHBOARD }
const breadcrumbItems = computed(() => [
  {
    label: 'Quản lý Đơn hàng',
    icon: 'i-lucide-clipboard-list',
    to: ROUTE_PATH.BUYER_ORDERS,
  },
  {
    label: order.value?.wfxId ?? '...',
    icon: 'i-lucide-shopping-bag',
    to: `/buyer-orders/${boId.value}`,
  },
  {
    label: pageTitle.value,
    icon: 'i-lucide-plus',
  },
])

const code = ref('')
const destination = ref('')
const deliveryDate = ref<Date | null>(null)
const quantities = ref<Record<string, Record<string, number>>>({})
const showPreviewModal = ref(false)
const saving = ref(false)
const modalErrorMessage = ref('')

const editingPo = computed(() =>
  order.value?.purchaseOrders.find((po) => po.id === editPoId.value && po.type === 'POSITIVE'),
)
watch(
  editingPo,
  (po) => {
    if (!po) return
    code.value = po.code
    destination.value = po.destination
    const [year, month, day] = po.deliveryDate.split('-').map(Number)
    deliveryDate.value = new Date(year!, month! - 1, day!)
    const next: Record<string, Record<string, number>> = {}
    for (const sku of po.skuQuantities) {
      next[sku.color] ??= {}
      next[sku.color]![sku.size] = sku.quantity
    }
    quantities.value = next
  },
  { immediate: true },
)

const skus = computed(() => order.value?.purchaseOrders.flatMap((po) => po.skuQuantities) ?? [])
const colors = computed(() =>
  sortValuesByOrder(
    skus.value.map((sku) => sku.color),
    order.value?.styleColorOrder ?? [],
  ),
)
const sizes = computed(() =>
  sortValuesByOrder(
    skus.value.map((sku) => sku.size),
    order.value?.styleSizeOrder ?? [],
  ),
)
const markets = computed(() =>
  [
    ...new Set(order.value?.purchaseOrders.map((po) => po.destination).filter(Boolean) ?? []),
  ].sort(),
)
const canAdd = computed(
  () =>
    !!order.value &&
    (!isEditing.value || !!editingPo.value) &&
    order.value.purchaseOrders.length > 0 &&
    colors.value.length > 0 &&
    sizes.value.length > 0 &&
    markets.value.length > 0,
)

const formattedDeliveryDate = computed(() => {
  if (!deliveryDate.value) return '-'
  const d = deliveryDate.value
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`
})

const gridTypes = {
  color: { cellTemplate: matrixGridCell(MatrixColorCell) },
  qty: { cellTemplate: matrixGridCell(MatrixQtyCell) },
}
const gridColumns = computed<MatrixGridColumn[]>(() => [
  { prop: 'color', name: 'Màu', pin: 'colPinStart', readonly: true, columnType: 'color' },
  ...sizes.value.map((size) => ({ prop: size, name: size, columnType: 'qty' })),
  {
    prop: 'total',
    name: 'Tổng',
    pin: 'colPinEnd',
    readonly: true,
    cellProperties: () => ({ class: 'font-mono font-bold text-primary' }),
    cellTemplate: (_h, { model }) => fmtQty(Number(model?.total ?? 0)),
  },
])
const gridRows = computed(() => {
  const rows = colors.value.map((color) => {
    const row: Record<string, unknown> = { color, rowKind: 'child' }
    let total = 0
    for (const size of sizes.value) {
      const qty = quantities.value[color]?.[size] ?? 0
      row[size] = qty || ''
      total += qty
    }
    row.total = total
    return row
  })
  const footer: Record<string, unknown> = { color: 'Tổng', rowKind: 'child', isTotalBySize: true }
  for (const size of sizes.value) {
    footer[size] = rows.reduce((sum, row) => sum + Number(row[size]), 0)
  }
  footer.total = rows.reduce((sum, row) => sum + Number(row.total), 0)
  return [...rows, footer]
})
const totalQuantity = computed(() => Number(gridRows.value.at(-1)?.total ?? 0))
const previewRows = computed(() =>
  colors.value.map((color) => ({
    color,
    data: Object.fromEntries(
      sizes.value.map((size) => [size, quantities.value[color]?.[size] ?? 0]),
    ),
  })),
)

function handleEdit(edits: MatrixGridEdit[]) {
  for (const edit of edits) {
    if (!sizes.value.includes(edit.prop)) continue
    const color = colors.value[edit.rowIndex]
    if (!color) continue
    const value = edit.value === null || edit.value === '' ? 0 : Number(edit.value)
    if (!Number.isSafeInteger(value) || value < 0 || value > 2147483647) {
      showError('Số lượng màu/cỡ phải là số nguyên không âm và không vượt giới hạn')
      quantities.value = { ...quantities.value }
      continue
    }
    quantities.value = {
      ...quantities.value,
      [color]: { ...quantities.value[color], [edit.prop]: value },
    }
  }
}

function showPreview() {
  if (!code.value.trim()) {
    showError('Vui lòng nhập Mã PO')
    return
  }
  if (!destination.value) {
    showError('Vui lòng chọn Thị trường')
    return
  }
  if (!deliveryDate.value) {
    showError('Vui lòng chọn Ngày giao')
    return
  }
  if (totalQuantity.value <= 0) {
    showError('Tổng sản lượng PO phải lớn hơn 0. Vui lòng nhập số lượng vào ma trận màu/cỡ.')
    return
  }
  if (totalQuantity.value > 2147483647) {
    showError('Tổng sản lượng PO vượt giới hạn')
    return
  }
  modalErrorMessage.value = ''
  showPreviewModal.value = true
}

async function save() {
  if (!canAdd.value || !deliveryDate.value || saving.value) return
  saving.value = true
  modalErrorMessage.value = ''
  try {
    const skuQuantities = colors.value.flatMap((color) =>
      sizes.value
        .filter((size) => (quantities.value[color]?.[size] ?? 0) > 0)
        .map((size) => ({ color, size, quantity: quantities.value[color]![size]! })),
    )
    let poId = editPoId.value
    if (poId) {
      await client.put({
        url: '/api/buyer-orders/{id}/positive-purchase-orders/{poId}',
        path: { id: boId.value, poId },
        body: { skuQuantities },
        throwOnError: true,
      })
    } else {
      const response = await client.post({
        url: '/api/buyer-orders/{id}/positive-purchase-orders',
        path: { id: boId.value },
        body: {
          code: code.value,
          destination: destination.value,
          deliveryDate: `${deliveryDate.value.getFullYear()}-${String(deliveryDate.value.getMonth() + 1).padStart(2, '0')}-${String(deliveryDate.value.getDate()).padStart(2, '0')}`,
          skuQuantities,
        },
        throwOnError: true,
      })
      poId = (response.data as { id: string }).id
    }
    await queryCache.invalidateQueries({
      predicate: ({ key }) =>
        [
          'getBuyerOrderDetail',
          'getBuyerOrders',
          'getProductionOrderDetail',
          'getProductionOrders',
        ].includes((key[0] as { _id?: string })?._id ?? ''),
    })
    showSuccess(isEditing.value ? 'Sửa PO hàng dương thành công' : 'Thêm PO hàng dương thành công')
    showPreviewModal.value = false
    await router.push({ path: `/buyer-orders/${boId.value}`, query: { tab: 'orders', po: poId } })
  } catch (error) {
    const apiError = error as { data?: { message?: string }; message?: string }
    modalErrorMessage.value =
      apiError.data?.message ??
      apiError.message ??
      `Không thể ${isEditing.value ? 'sửa' : 'thêm'} PO hàng dương`
    showError(modalErrorMessage.value)
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div class="flex flex-col gap-4">
    <!-- Top Bar -->
    <div class="flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
      <UBreadcrumb :items="[breadcrumbHome, ...breadcrumbItems]" class="bg-transparent!" />
      <div class="flex items-center justify-end gap-2">
        <UButton
          :to="`/buyer-orders/${boId}`"
          label="Quay lại đơn hàng"
          variant="outline"
          color="neutral"
          icon="i-lucide-arrow-left"
        />
      </div>
    </div>

    <!-- Loading State -->
    <div v-if="isLoading && !order" class="flex flex-col gap-4">
      <USkeleton class="h-24 rounded-lg" />
      <USkeleton class="h-32 rounded-lg" />
      <USkeleton class="h-80 rounded-lg" />
    </div>

    <!-- Alert Not Eligible -->
    <UAlert
      v-else-if="!canAdd"
      color="warning"
      :title="`Không thể ${isEditing ? 'sửa' : 'thêm'} PO hàng dương`"
      description="PO không hợp lệ hoặc BO chưa có đủ PO, màu/cỡ và thị trường làm dữ liệu nền."
    />

    <!-- Main Content -->
    <template v-else-if="order">
      <!-- 1. Form thông tin PO hàng dương -->
      <UCard>
        <template #title>
          <div class="flex items-center gap-2">
            <UIcon name="i-lucide-file-plus" class="text-xl text-primary" />
            <span class="font-bold text-highlighted">Thông tin PO hàng dương</span>
          </div>
        </template>

        <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <!-- Mã PO -->
          <div class="flex flex-col gap-1.5">
            <label class="text-sm font-semibold text-default">
              Mã PO <span v-if="!isEditing" class="text-error-500">*</span>
            </label>
            <UInput
              v-model="code"
              :disabled="isEditing"
              :variant="isEditing ? 'subtle' : 'outline'"
              class="w-full font-mono font-medium"
            />
          </div>

          <!-- Thị trường -->
          <div class="flex flex-col gap-1.5">
            <label class="text-sm font-semibold text-default">
              Thị trường <span v-if="!isEditing" class="text-error-500">*</span>
            </label>
            <USelect
              v-model="destination"
              :disabled="isEditing"
              :variant="isEditing ? 'subtle' : 'outline'"
              :items="markets"
              placeholder="Chọn thị trường"
              class="w-full"
            />
          </div>

          <!-- Ngày giao -->
          <div class="flex flex-col gap-1.5">
            <label class="text-sm font-semibold text-default">
              Ngày giao <span v-if="!isEditing" class="text-error-500">*</span>
            </label>
            <AppDatePicker
              v-model="deliveryDate"
              :disabled="isEditing"
              :variant="isEditing ? 'subtle' : 'outline'"
              placeholder="Chọn ngày giao"
              class="w-full"
            />
          </div>
        </div>
      </UCard>

      <!-- 2. Ma trận Màu / Cỡ -->
      <UCard>
        <template #title>
          <span class="font-bold text-highlighted">Ma trận Màu / Cỡ</span>
        </template>

        <BaseMatrixGrid
          :source="gridRows"
          :columns="gridColumns"
          :column-types="gridTypes"
          @afteredit="handleEdit"
        />

        <template #footer>
          <div class="flex flex-wrap items-center justify-between gap-4">
            <div class="flex items-center gap-2">
              <span class="text-sm font-medium text-toned">Tổng sản lượng PO:</span>
              <span class="font-mono text-lg font-bold text-primary">{{
                fmtQty(totalQuantity)
              }}</span>
            </div>
            <div class="flex items-center gap-2">
              <UButton
                label="Hủy"
                variant="outline"
                color="neutral"
                :to="`/buyer-orders/${boId}`"
              />
              <UButton label="Preview" icon="i-lucide-eye" color="primary" @click="showPreview" />
            </div>
          </div>
        </template>
      </UCard>

      <!-- Modal Preview -->
      <UModal
        v-model:open="showPreviewModal"
        title="Preview PO hàng dương"
        class="sm:max-w-[1000px] xl:max-w-[1200px]"
      >
        <template #body>
          <div class="flex flex-col gap-4 py-1">
            <!-- Tóm tắt thông tin PO -->
            <div
              class="grid grid-cols-2 gap-3 rounded-lg border border-surface-200 bg-surface-50 p-3.5 text-xs sm:grid-cols-4"
            >
              <div>
                <span class="block text-toned">Mã PO:</span>
                <span class="font-mono text-sm font-bold text-highlighted">{{ code }}</span>
              </div>
              <div>
                <span class="block text-toned">Thị trường:</span>
                <span class="text-sm font-semibold text-highlighted">{{ destination }}</span>
              </div>
              <div>
                <span class="block text-toned">Ngày giao:</span>
                <span class="text-sm font-semibold text-highlighted">{{
                  formattedDeliveryDate
                }}</span>
              </div>
              <div>
                <span class="block text-toned">Tổng sản lượng PO:</span>
                <span class="font-mono text-base font-bold text-primary">{{
                  fmtQty(totalQuantity)
                }}</span>
              </div>
            </div>

            <!-- Bảng màu/cỡ -->
            <ColorSizeMatrix :rows="previewRows" :all-sizes="sizes" />

            <!-- Thông báo lỗi (nếu có) -->
            <UAlert v-if="modalErrorMessage" color="error" :description="modalErrorMessage" />
          </div>
        </template>

        <template #footer>
          <div class="flex w-full items-center justify-between gap-2">
            <UButton
              label="Quay lại"
              variant="outline"
              color="neutral"
              icon="i-lucide-arrow-left"
              @click="showPreviewModal = false"
            />
            <UButton
              label="Lưu PO hàng dương"
              icon="i-lucide-save"
              color="primary"
              :loading="saving"
              @click="save"
            />
          </div>
        </template>
      </UModal>
    </template>
  </div>
</template>
