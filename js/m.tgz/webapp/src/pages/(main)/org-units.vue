<script setup lang="ts">
import {
  getOperationsQuery,
  getSuppliersQueryKey,
  getTreeQuery,
  syncMutation,
} from '@/api/@pinia/colada.gen'
import FactoryOperationTab from '@/features/org-unit/components/FactoryOperationTab.vue'
import CompanyForm from '@/features/org-unit/components/forms/CompanyForm.vue'
import CorporationForm from '@/features/org-unit/components/forms/CorporationForm.vue'
import FactoryForm from '@/features/org-unit/components/forms/FactoryForm.vue'
import TeamForm from '@/features/org-unit/components/forms/TeamForm.vue'
import WarehouseForm from '@/features/org-unit/components/forms/WarehouseForm.vue'
import OrgTree from '@/features/org-unit/components/OrgTree.vue'
import { useOrganization } from '@/features/org-unit/composables/useOrganization'
import { useOrgFormState } from '@/features/org-unit/composables/useOrgFormState'
import { useAuthStore } from '@/shared/stores/auth'
import { showError } from '@/shared/utils/toast'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import dayjs from 'dayjs'
import { computed, onMounted, ref, watch } from 'vue'

definePage({
  meta: { requiredPermission: 'MANAGE_ORG' },
})

const { hasPermission, currentUser } = useAuthStore()
const queryCache = useQueryCache()
const { mutateAsync: syncSuppliersMutate } = useMutation(syncMutation())

async function autoSyncSuppliers() {
  try {
    await syncSuppliersMutate({})
    await queryCache.invalidateQueries({ key: getSuppliersQueryKey() })
  } catch (err) {
    console.error('Tự động đồng bộ nhà cung cấp WFX thất bại', err)
  }
}

onMounted(() => {
  if (hasPermission('MANAGE_ORG')) {
    const today = dayjs().format('YYYY-MM-DD')
    const userId = currentUser.value?.id || 'unknown'
    const syncKey = `wfx_supplier_sync_${userId}`
    const lastSync = localStorage.getItem(syncKey)

    if (lastSync !== today) {
      void autoSyncSuppliers()
      localStorage.setItem(syncKey, today)
    }
  }
})

const activeTab = ref('units')
const tabs = [
  { label: 'Cơ cấu tổ chức', icon: 'i-lucide-network', value: 'units' },
  { label: 'Cấu hình công đoạn', icon: 'i-lucide-sliders', value: 'operations' },
]

const { treeData, expandedKeys, findNode } = useOrganization()

const { isPending: treePending, error: treeError } = useQuery(getTreeQuery())
const { isPending: opsPending } = useQuery(getOperationsQuery())

watch(treeError, (err) => {
  if (err) showError('Không thể tải dữ liệu')
})

const loading = computed(() => treePending.value || opsPending.value)

const {
  showCorporationForm,
  showCompanyForm,
  showFactoryForm,
  showTeamForm,
  showWarehouseForm,
  editingCorporationId,
  editingCompanyId,
  editingFactoryId,
  editingTeamId,
  editingWarehouseId,
  formParentCorporation,
  formParentCompany,
  formParentFactory,
  closeAllForms,
  openAddCorporation,
  openEditCorporation,
  openAddCompany,
  openEditCompany,
  openAddFactory,
  openEditFactory,
  openAddTeam,
  openEditTeam,
  openAddWarehouse,
  openEditWarehouse,
} = useOrgFormState(treeData, findNode)
</script>

<template>
  <div class="flex h-full flex-col gap-4">
    <div class="flex items-center justify-between">
      <UBreadcrumb
        class="bg-transparent!"
        :items="[
          { icon: 'i-lucide-house' },
          ...[{ label: 'Quản lý Đơn vị', icon: 'i-lucide-building-2' }],
        ]"
      />
    </div>

    <UCard>
      <template #default>
        <UTabs v-model="activeTab" :items="tabs" :content="false" variant="link" class="mb-4" />

        <div v-if="activeTab === 'units'">
          <div v-if="loading" class="flex flex-col gap-3">
            <USkeleton class="h-64 w-full" />
          </div>
          <OrgTree
            v-else
            :tree-data="treeData"
            v-model:expanded-keys="expandedKeys"
            @add-corporation="openAddCorporation"
            @edit-corporation="openEditCorporation"
            @add-company="openAddCompany"
            @edit-company="openEditCompany"
            @add-factory="openAddFactory"
            @edit-factory="openEditFactory"
            @add-team="openAddTeam"
            @edit-team="openEditTeam"
            @add-warehouse="openAddWarehouse"
            @edit-warehouse="openEditWarehouse"
          />
        </div>

        <div v-else-if="activeTab === 'operations'">
          <FactoryOperationTab />
        </div>
      </template>
    </UCard>

    <CorporationForm
      v-if="showCorporationForm"
      :key="editingCorporationId || 'add'"
      v-model:visible="showCorporationForm"
      :corporation-id="editingCorporationId"
      @saved="closeAllForms"
    />

    <CompanyForm
      v-if="showCompanyForm"
      :key="editingCompanyId || 'add'"
      v-model:visible="showCompanyForm"
      :company-id="editingCompanyId"
      :parent-corporation="formParentCorporation"
      @saved="closeAllForms"
    />

    <FactoryForm
      v-if="showFactoryForm"
      :key="editingFactoryId || 'add'"
      v-model:visible="showFactoryForm"
      :factory-id="editingFactoryId"
      :parent-company="formParentCompany"
      @saved="closeAllForms"
    />

    <TeamForm
      v-if="showTeamForm"
      :key="editingTeamId || 'add'"
      v-model:visible="showTeamForm"
      :team-id="editingTeamId"
      :parent-factory="formParentFactory"
      @saved="closeAllForms"
    />

    <WarehouseForm
      v-if="showWarehouseForm"
      :key="editingWarehouseId || 'add'"
      v-model:visible="showWarehouseForm"
      :warehouse-id="editingWarehouseId"
      :parent-company="formParentCompany"
      @saved="closeAllForms"
    />
  </div>
</template>
