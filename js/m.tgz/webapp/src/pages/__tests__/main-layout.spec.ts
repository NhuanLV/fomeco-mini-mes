import { shallowMount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'
import MainLayout from '../(main).vue'

const { useNotificationReadTracking } = vi.hoisted(() => ({
  useNotificationReadTracking: vi.fn(),
}))

vi.mock('@/features/notification/composables/useNotifications', async (importOriginal) => ({
  ...(await importOriginal<
    typeof import('@/features/notification/composables/useNotifications')
  >()),
  useNotificationReadTracking,
}))

vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({
    isAuthenticated: { value: true },
  }),
}))

vi.mock('vue-router', async (importOriginal) => ({
  ...(await importOriginal<typeof import('vue-router')>()),
  useRouter: () => ({ push: vi.fn() }),
}))

describe('main layout', () => {
  it('uses Nuxt UI main and container primitives', () => {
    const wrapper = shallowMount(MainLayout, {
      global: {
        stubs: {
          Main: { name: 'Main', template: '<main><slot /></main>' },
          Container: { name: 'Container', template: '<div><slot /></div>' },
        },
      },
    })

    expect(useNotificationReadTracking).toHaveBeenCalled()
    expect(wrapper.findComponent({ name: 'Main' }).exists()).toBe(true)
    expect(wrapper.findComponent({ name: 'Container' }).exists()).toBe(true)
  })
})
