<script setup lang="ts">
import { getSafeRedirect } from '@/app/router/redirect'
import Aura from '@/shared/components/Aura.vue'
import { useAuthStore } from '@/shared/stores/auth'
import type { AuthFormField, FormSubmitEvent } from '@nuxt/ui'
import { onBeforeMount, shallowRef } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import * as z from 'zod'

const route = useRoute()
const router = useRouter()
const loading = shallowRef(false)
const error = shallowRef('')
const { isInitialized, isAuthenticated, checkAuth } = useAuthStore()

const getTargetRoute = () => getSafeRedirect(route.query.redirect)

const fields: AuthFormField[] = [
  {
    name: 'username',
    type: 'text',
    label: 'Tài khoản',
    placeholder: 'Nhập tên đăng nhập...',
    required: true,
    autofocus: true,
    defaultValue: '',
  },
  {
    name: 'password',
    type: 'password',
    label: 'Mật khẩu',
    placeholder: 'Nhập mật khẩu...',
    required: true,
    defaultValue: '',
  },
]

const schema = z.object({
  username: z.string().min(1, 'Vui lòng nhập tên đăng nhập.'),
  password: z.string().min(1, 'Vui lòng nhập mật khẩu.'),
})

type Schema = z.output<typeof schema>

onBeforeMount(async () => {
  if (!isInitialized.value) {
    await checkAuth()
  }
  if (isAuthenticated.value) {
    await router.push(getTargetRoute())
  }
})

const handleLogin = async (event: FormSubmitEvent<Schema>) => {
  loading.value = true
  error.value = ''

  try {
    // Login uses form-urlencoded, not JSON
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        username: event.data.username,
        password: event.data.password,
      }),
    })

    if (response.ok) {
      await checkAuth()
      await router.push(getTargetRoute())
    } else {
      error.value = 'Tên đăng nhập hoặc mật khẩu không đúng.'
    }
  } catch {
    error.value = 'Không thể đăng nhập. Vui lòng kiểm tra kết nối và thử lại.'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="flex min-h-dvh items-center justify-center bg-muted px-4">
    <Aura class="w-full max-w-md text-primary">
      <UPageCard class="w-full">
        <UAuthForm
          :fields="fields"
          :schema="schema"
          :loading="loading"
          :submit="{ label: 'Đăng nhập', icon: 'i-lucide-log-in' }"
          icon="i-lucide-factory"
          title="LGG MES+"
          description="Vui lòng đăng nhập để sử dụng hệ thống"
          @submit="handleLogin"
        >
          <template #password-hint>
            <ULink to="#" class="text-xs font-medium text-primary">Quên mật khẩu?</ULink>
          </template>

          <template #validation>
            <UAlert v-if="error" color="error" icon="i-lucide-circle-alert" :description="error" />
          </template>
        </UAuthForm>
      </UPageCard>
    </Aura>
  </div>
</template>
