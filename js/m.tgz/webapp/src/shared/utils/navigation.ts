import type { Router, RouteLocationRaw } from 'vue-router'

/**
 * Handles navigation for row/card clicks across the application:
 * - Normal left-click: navigates in current tab via router.push
 * - Middle-click (button === 1) or Ctrl/Cmd + click: opens target page in a new tab via window.open
 */
export function handleRowNavigation(
  event: MouseEvent | KeyboardEvent | Event,
  router: Router,
  target: RouteLocationRaw,
) {
  const mouseEvent = event as MouseEvent
  const isMiddleClick = mouseEvent?.button === 1
  const isCtrlOrCmd = mouseEvent?.ctrlKey || mouseEvent?.metaKey

  if (isMiddleClick || isCtrlOrCmd) {
    if ('preventDefault' in event && typeof event.preventDefault === 'function') {
      event.preventDefault()
    }
    const href = router.resolve(target).href
    window.open(href, '_blank')
  } else {
    void router.push(target)
  }
}

/**
 * Handles auxclick (middle-click) on UTable container elements.
 */
export function handleTableAuxClick<T>(
  event: MouseEvent,
  router: Router,
  items: T[],
  getTarget: (item: T) => RouteLocationRaw | null | undefined,
) {
  if (event.button !== 1) return
  const targetEl = event.target as HTMLElement | null
  const tr = targetEl?.closest('tbody tr') as HTMLTableRowElement | null
  if (!tr || !tr.parentElement) return

  const rowIndex = Array.from(tr.parentElement.children).indexOf(tr)
  if (rowIndex >= 0 && rowIndex < items.length) {
    const item = items[rowIndex]
    const target = getTarget(item)
    if (target) {
      event.preventDefault()
      const href = router.resolve(target).href
      window.open(href, '_blank')
    }
  }
}
