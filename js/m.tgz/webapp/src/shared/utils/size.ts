/** Sorts sizes so numeric sizes appear after alphabetic (e.g. S, M, L before 36, 38, 40) */
export function compareSize(a: string, b: string): number {
  const aIsNum = /^\d+$/.test(a)
  const bIsNum = /^\d+$/.test(b)
  if (aIsNum && bIsNum) return parseInt(a) - parseInt(b)
  if (!aIsNum && !bIsNum) return a.localeCompare(b)
  return aIsNum ? 1 : -1
}
