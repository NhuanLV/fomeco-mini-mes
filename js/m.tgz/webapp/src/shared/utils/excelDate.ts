// Chuyển giá trị Excel -> YYYY-MM-DD
export function formatExcelDate(val: unknown): string | undefined {
  if (!val) return undefined
  if (val instanceof Date) {
    if (isNaN(val.getTime())) return undefined
    const y = val.getFullYear()
    const m = String(val.getMonth() + 1).padStart(2, '0')
    const d = String(val.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }

  if (typeof val === 'string') {
    const parts = val.trim().split('/')
    if (parts.length === 3) {
      const [day, month, year] = parts
      return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`
    }
  }

  const d = new Date(val as string | number)
  if (isNaN(d.getTime())) return String(val).trim()

  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

// Chuyển giá trị Excel => đối tượng Date của JS để lưu vào Store
export function parseToDate(val: unknown): Date | null {
  if (!val) return null
  if (val instanceof Date) return val
  if (typeof val === 'string') {
    const parts = val.trim().split('/')
    if (parts.length === 3) {
      const d = new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]))
      return isNaN(d.getTime()) ? null : d
    }
  }

  const d = new Date(val as string | number)
  return isNaN(d.getTime()) ? null : d
}

//Chuyển Date => DD/MM/YYYY (export excel)
export function formatJSDate(date: Date | null | undefined): string {
  if (!date) return ''
  const d = new Date(date)
  if (isNaN(d.getTime())) return ''
  const day = String(d.getDate()).padStart(2, '0')
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const year = d.getFullYear()
  return `${day}/${month}/${year}`
}
