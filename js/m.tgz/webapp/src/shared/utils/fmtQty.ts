import Big from 'big.js'

// Formats quantity values for display by rounding to 4 decimals,
// adding thousand separators by "," and handling empty/invalid inputs, replace with "-".

export function fmtQty(val: number | string | null | undefined): string {
  if (val == null || val === '') return '-'
  try {
    const b = new Big(val)
    const numStr = Number(b.toFixed(4)).toString()
    const parts = numStr.split('.')
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    return parts.join('.')
  } catch {
    return String(val)
  }
}
