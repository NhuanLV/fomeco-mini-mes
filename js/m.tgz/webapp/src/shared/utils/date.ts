/** Chuyển 'YYYY-MM-DD' → 'DD/MM/YYYY' */
export const formatDate = (dateStr: string | null | undefined) => {
  if (!dateStr || !dateStr.includes('-')) return dateStr || ''
  const [year, month, day] = dateStr.split('-')
  if (!year || !month || !day) return dateStr
  return `${day}/${month}/${year}`
}
