/**
 * Formats a team hierarchy into a unified readable string: "Tổ - Xí nghiệp - Công ty"
 */
export function formatTeamHierarchy(
  teamName?: string | null,
  factoryName?: string | null,
  companyName?: string | null,
  separator = ' - ',
): string {
  return [teamName, factoryName, companyName].filter(Boolean).join(separator)
}

/**
 * Formats a factory hierarchy into a readable string: "Xí nghiệp - Công ty"
 */
export function formatFactoryHierarchy(
  factoryName?: string | null,
  companyName?: string | null,
  separator = ' - ',
): string {
  return [factoryName, companyName].filter(Boolean).join(separator)
}
