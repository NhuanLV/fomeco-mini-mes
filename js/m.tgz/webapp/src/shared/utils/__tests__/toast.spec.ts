import {
  clearLoading,
  clearToastGroup,
  setToastInstance,
  showError,
  showLoading,
  showSuccess,
  showWarn,
} from '@/shared/utils/toast'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { shallowRef } from 'vue'

describe('toast utils', () => {
  const add = vi.fn()
  const remove = vi.fn()
  const toasts = shallowRef<Array<{ id: string | number }>>([])

  beforeEach(() => {
    vi.clearAllMocks()
    toasts.value = []
    setToastInstance({ add, remove, toasts })
  })

  it('shows and clears loading toast with matching group and options', () => {
    toasts.value = [{ id: 'loading' }]

    showLoading('Đang tạo FPO/FPPO...', 'Đang phát lệnh', 'fppo-sync')

    expect(add).toHaveBeenCalledWith(
      expect.objectContaining({
        id: 'fppo-sync',
        color: 'info',
        title: 'Đang phát lệnh',
        description: 'Đang tạo FPO/FPPO...',
        duration: 0,
        close: false,
        icon: 'i-lucide-loader-circle',
        ui: { icon: 'animate-spin' },
      }),
    )

    toasts.value = [{ id: 'fppo-sync' }]
    clearLoading('fppo-sync')

    expect(remove).toHaveBeenCalledWith('fppo-sync')
  })

  it('shows success, warning, error toasts with default life', () => {
    showSuccess('Done')
    expect(add).toHaveBeenLastCalledWith(
      expect.objectContaining({
        color: 'success',
        title: 'Thành công',
        description: 'Done',
        duration: 3000,
      }),
    )

    showWarn('Attention')
    expect(add).toHaveBeenLastCalledWith(
      expect.objectContaining({
        color: 'warning',
        title: 'Cảnh báo',
        description: 'Attention',
        duration: 3000,
      }),
    )

    showError('Failed')
    expect(add).toHaveBeenLastCalledWith(
      expect.objectContaining({
        color: 'error',
        title: 'Lỗi',
        description: 'Failed',
        duration: 3000,
      }),
    )
  })

  it('clears all toasts in a group', () => {
    toasts.value = [{ id: 'group-a' }, { id: 'group-b' }, { id: 'group-a' }]

    clearToastGroup('group-a')

    expect(remove).toHaveBeenCalledTimes(2)
    expect(remove).toHaveBeenCalledWith('group-a')
  })
})
