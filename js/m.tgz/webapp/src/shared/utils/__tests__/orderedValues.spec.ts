import { describe, expect, it } from 'vitest'
import { makeArticleVariantComparator, sortValuesByOrder } from '../orderedValues'

describe('view ordering', () => {
  it('uses API order first and alphabet for missing values without changing the input', () => {
    const values = ['XL', 'L', 'Z', 'M', 'S', 'A', 'S']
    expect(sortValuesByOrder(values, ['S', 'M', 'L', 'XL'])).toEqual([
      'S',
      'M',
      'L',
      'XL',
      'A',
      'Z',
    ])
    expect(sortValuesByOrder(values, [])).toEqual(['A', 'L', 'M', 'S', 'XL', 'Z'])
    expect(values[0]).toBe('XL')
  })

  it('orders articles alphabetically, BTP variants by API, and material variants alphabetically', () => {
    const rows = [
      { article: 'Vải', color: 'Red', size: 'S' },
      { article: 'Vải', color: 'Blue', size: 'M' },
      { article: 'BTP CUT-1', color: 'Blue', size: 'S' },
      { article: 'BTP CUT-1', color: 'Red', size: 'M' },
      { article: 'BTP CUT-1', color: 'Red', size: 'S' },
      { article: 'Chỉ', color: '', size: '' },
    ]
    expect([...rows].sort(makeArticleVariantComparator(['Red', 'Blue'], ['S', 'M']))).toEqual([
      rows[4],
      rows[3],
      rows[2],
      rows[5],
      rows[1],
      rows[0],
    ])
    expect(rows[0]!.article).toBe('Vải')
  })
})
