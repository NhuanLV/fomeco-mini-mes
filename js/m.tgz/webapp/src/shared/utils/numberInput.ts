/**
 * Intercepts beforeinput events on decimal inputs:
 * 1. Blocks typed comma (',') completely.
 * 2. Ensures only valid decimal numbers (digits and a single dot '.') can be typed.
 * 3. Prevents browser locale (e.g. vi-VN) from interfering with decimal dot input.
 */
export function rejectComma(event: Event) {
  const inputEvent = event as InputEvent
  const data = inputEvent.data
  if (!data) return

  // Block comma explicitly
  if (data.includes(',')) {
    inputEvent.preventDefault()
    return
  }

  // Validate inserted characters (allow digits and single dot)
  const target = inputEvent.target as HTMLInputElement
  if (target) {
    if (data === '.') {
      if (target.value.includes('.')) {
        const start = target.selectionStart ?? 0
        const end = target.selectionEnd ?? 0
        const selectedText = target.value.slice(start, end)
        if (!selectedText.includes('.')) {
          inputEvent.preventDefault()
        }
      }
    } else if (!/^\d+$/.test(data)) {
      inputEvent.preventDefault()
    }
  }
}
