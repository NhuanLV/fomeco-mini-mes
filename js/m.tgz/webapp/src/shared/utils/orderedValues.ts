export function makeOrderComparator(orderedValues: readonly string[]) {
  const indexMap = new Map(orderedValues.map((value, index) => [value, index]))
  return (left: string, right: string): number => {
    const li = indexMap.get(left)
    const ri = indexMap.get(right)
    if (li !== undefined && ri !== undefined) return li - ri
    if (li !== undefined) return -1
    if (ri !== undefined) return 1
    return left.localeCompare(right)
  }
}

export function sortValuesByOrder(
  values: Iterable<string>,
  orderedValues: readonly string[],
): string[] {
  return Array.from(new Set(values)).sort(makeOrderComparator(orderedValues))
}

export function makeArticleVariantComparator(
  colorOrder: readonly string[] = [],
  sizeOrder: readonly string[] = [],
) {
  const cmpColor = makeOrderComparator(colorOrder)
  const cmpSize = makeOrderComparator(sizeOrder)
  return (
    left: { article: string; color: string; size: string },
    right: { article: string; color: string; size: string },
  ) => {
    const article = left.article.localeCompare(right.article, 'vi')
    if (article) return article
    return left.article.startsWith('BTP ')
      ? cmpColor(left.color, right.color) || cmpSize(left.size, right.size)
      : left.color.localeCompare(right.color) || left.size.localeCompare(right.size)
  }
}
