import { fmtQty } from '@/shared/utils/fmtQty'

function hasCurrent(value: unknown): value is { current: unknown } {
  return typeof value === 'object' && value !== null && 'current' in value
}

function hasTotal(value: unknown): value is { limit: unknown } {
  return typeof value === 'object' && value !== null && 'limit' in value
}

export function getMatrixQtyDisplayValue(
  row: Record<string, unknown> | null | undefined,
  prop: string,
): string {
  const nullValue = '-'
  if (!row || row.rowKind === 'parent') return nullValue

  const cellValue = row[prop]
  const current = hasCurrent(cellValue) ? Number(cellValue.current) : Number(cellValue)

  let limit: number | null
  if (hasTotal(cellValue)) {
    limit =
      cellValue.limit === undefined || cellValue.limit === null ? null : Number(cellValue.limit)
  } else {
    const demandValue = row[`${prop}_demand`]
    limit = demandValue === undefined || demandValue === null ? null : Number(demandValue)
  }

  if (limit === null) {
    return current > 0 ? fmtQty(current) : nullValue
  }

  if (limit === 0 && current === 0) return nullValue
  return `${fmtQty(current)} / ${fmtQty(limit)}`
}
