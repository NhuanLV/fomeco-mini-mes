export const ROW_HEIGHT = 36
export const PINNED_COL_WIDTH = 80
export const MIN_SIZE_COL_WIDTH = 68
export const MAX_ROW = 8
