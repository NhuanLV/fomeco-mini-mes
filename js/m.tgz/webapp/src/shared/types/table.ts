export type TablePageEvent = {
  first: number
  rows: number
  page: number
  pageCount: number
}

export type TableSortEvent = TablePageEvent & {
  sortField?: string
  sortOrder?: 1 | -1 | 0
}

export type TableExpandedRows = Record<string, boolean>
