<script setup lang="ts">
const emit = defineEmits<{
  expandAll: []
  collapseAll: []
}>()
</script>

<template>
  <div class="flex items-center gap-2">
    <UButton
      label="Mở rộng"
      icon="i-lucide-expand"
      color="info"
      variant="outline"
      @click="emit('expandAll')"
    />
    <UButton
      label="Thu gọn"
      icon="i-lucide-shrink"
      color="info"
      variant="outline"
      @click="emit('collapseAll')"
    />
  </div>
</template>
