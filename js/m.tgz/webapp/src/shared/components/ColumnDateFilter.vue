<script setup lang="ts">
import AppDatePicker from '@/shared/components/AppDatePicker.vue'
import { useTemplateRef } from 'vue'

defineProps<{
  modelValue: Date[] | null
  label: string
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: Date[] | null): void
}>()

const datePicker = useTemplateRef<InstanceType<typeof AppDatePicker>>('datePicker')

function onUpdate(value: Date | Date[] | (Date | null)[] | null | undefined) {
  emit('update:modelValue', value as Date[] | null)
}

function showPicker() {
  datePicker.value?.show()
}
</script>

<template>
  <div class="flex w-full cursor-pointer items-center gap-1 px-4 py-3.5" @click="showPicker">
    <span class="font-semibold">{{ label }}</span>
    <AppDatePicker
      ref="datePicker"
      :model-value="modelValue"
      @update:model-value="onUpdate"
      selection-mode="range"
      input-class="hidden"
    >
      <template #inputicon>
        <UButton
          icon="i-lucide-calendar"
          variant="ghost"
          class="h-6! w-6! p-0!"
          :class="modelValue?.length ? 'text-primary!' : 'text-toned!'"
        />
      </template>
    </AppDatePicker>
  </div>
</template>
