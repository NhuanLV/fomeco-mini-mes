<script setup lang="ts">
import { useGridLayout, type GridColumn, type GridRow } from '@/shared/composables/useGridLayout'
import { ROW_HEIGHT } from '@/shared/utils/colorSizeMatrix'
import RevoGrid, { VGridVueTemplate } from '@revolist/vue3-datagrid'
import { computed } from 'vue'
import type { MatrixRow } from '../types'
import MatrixQtyCell from './grid/MatrixQtyCell.vue'
import MatrixColorCell from './grid/MatrixColorCell.vue'
import { matrixGridCell } from './grid/matrixGrid'

interface Props {
  rows: MatrixRow[]
  allSizes: string[]
}

const props = defineProps<Props>()

// Cell templates — created once outside reactive system
const SIZE_CELL = VGridVueTemplate(MatrixQtyCell)
const COLOR_CELL = matrixGridCell(MatrixColorCell)

// ─── Grid source ──────────────────────────────────────────────────────────────
const source = computed((): GridRow[] => {
  const result: GridRow[] = props.rows.map((row, index) => {
    const flat: GridRow = { id: row.id ?? `row-${index}`, color: row.color }
    let totalReported = 0
    let totalAssigned = 0
    let isObjectData = false

    for (const size of props.allSizes) {
      const v = row.data[size]
      flat[size] = v
      if (typeof v === 'object' && v !== null) {
        totalReported += v.current || 0
        totalAssigned += v.limit || 0
        isObjectData = true
      } else {
        totalReported += Number(v) || 0
      }
    }

    if (isObjectData) {
      flat.totalByColor = { current: totalReported, limit: totalAssigned }
    } else {
      flat.totalByColor = totalReported
    }
    return flat
  })

  if (props.rows.length === 0) return result

  let grandReported = 0
  let grandAssigned = 0
  let hasObjectData = false
  const sizeSums: Record<string, { current: number; limit: number } | number> = {}

  for (const size of props.allSizes) {
    let sizeReported = 0
    let sizeAssigned = 0
    let sizeIsObject = false

    for (const row of props.rows) {
      const v = row.data[size]
      if (typeof v === 'object' && v !== null) {
        sizeReported += v.current || 0
        sizeAssigned += v.limit || 0
        sizeIsObject = true
        hasObjectData = true
      } else {
        sizeReported += Number(v) || 0
      }
    }

    if (sizeIsObject) {
      sizeSums[size] = { current: sizeReported, limit: sizeAssigned }
      grandReported += sizeReported
      grandAssigned += sizeAssigned
    } else {
      sizeSums[size] = sizeReported
      grandReported += sizeReported
    }
  }

  const totalBySizeRow: GridRow = {
    id: 'total-by-size-row',
    color: 'Tổng',
    isTotalBySize: true,
    totalByColor: hasObjectData ? { current: grandReported, limit: grandAssigned } : grandReported,
    ...sizeSums,
  }

  result.push(totalBySizeRow)
  return result
})

// ─── Column definitions ───────────────────────────────────────────────────────
const columns = computed((): GridColumn[] => [
  {
    prop: 'color',
    name: 'Màu',
    pin: 'colPinStart',
    readonly: true,
    cellTemplate: COLOR_CELL,
  },
  ...props.allSizes.map((size): GridColumn => ({
    prop: size,
    name: size,
    readonly: true,
    cellTemplate: SIZE_CELL,
  })),
  {
    prop: 'totalByColor',
    name: 'Tổng',
    pin: 'colPinEnd',
    readonly: true,
    cellTemplate: SIZE_CELL,
  },
])

const { wrapperRef, gridColumns, tableHeight } = useGridLayout({
  rows: source,
  columns,
})
</script>

<template>
  <div ref="wrapperRef" :style="{ height: tableHeight + 'px' }" class="w-full overflow-x-auto">
    <RevoGrid
      class="min-h-full!"
      hide-attribution
      :source="source"
      :columns="gridColumns"
      :theme="'material'"
      :row-size="ROW_HEIGHT"
      stretch
      :readonly="true"
      resize
      range
    />
  </div>
</template>
