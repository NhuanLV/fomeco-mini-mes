<script setup lang="ts">
import type { BomLine } from '@/shared/components/bom/types'
import { fmtQty } from '@/shared/utils/fmtQty'
import type { TableColumn } from '@nuxt/ui'
import { computed } from 'vue'
import { makeOrderComparator } from '@/shared/utils/orderedValues'

const props = defineProps<{
  bomLine: BomLine | null
  isCutting?: boolean
  styleColorOrder?: string[]
  styleSizeOrder?: string[]
}>()

const visible = defineModel<boolean>('visible')

const title = computed(() => {
  if (!props.bomLine) return 'Chi tiết định mức'
  return `Định mức - ${props.bomLine.articleName}`
})
const sortedSizes = computed(() => {
  const cmp = makeOrderComparator(props.styleSizeOrder ?? [])
  return [...(props.bomLine?.sizes ?? [])].sort(
    (left, right) =>
      cmp(left.productSize, right.productSize) ||
      left.materialSize.localeCompare(right.materialSize),
  )
})
const sortedColors = computed(() => {
  const cmp = makeOrderComparator(props.styleColorOrder ?? [])
  return [...(props.bomLine?.colors ?? [])].sort(
    (left, right) =>
      cmp(left.productColor, right.productColor) ||
      left.materialColor.localeCompare(right.materialColor),
  )
})

type SizeRow = BomLine['sizes'][number]
type ColorRow = BomLine['colors'][number]
const sizeColumns: TableColumn<SizeRow>[] = [
  { accessorKey: 'productSize', header: 'Cỡ SP' },
  { accessorKey: 'materialSize', header: 'Cỡ NPL' },
  { accessorKey: 'consumption', header: 'Định mức' },
]
const colorColumns = computed<TableColumn<ColorRow>[]>(() => [
  { accessorKey: 'productColor', header: 'Màu SP' },
  { accessorKey: 'materialColor', header: 'Màu NPL' },
  ...(props.isCutting
    ? [
        { accessorKey: 'consumption', header: 'Định mức (Kỹ thuật)' },
        { accessorKey: 'cuttingConsumption', header: 'Định mức (Tổ cắt)' },
      ]
    : []),
])
</script>

<template>
  <UModal v-model:open="visible" :title="title" class="max-w-[90vw] sm:max-w-[800px]">
    <template #body>
      <div v-if="bomLine" class="flex flex-col gap-6 py-4">
        <!-- Size Table (Theo cỡ) -->
        <div>
          <h3 class="mb-3 flex items-center gap-2 text-lg font-semibold">
            <UIcon name="i-lucide-arrow-down-wide-narrow" class="text-primary" />
            Theo cỡ
          </h3>
          <UTable :data="sortedSizes" :columns="sizeColumns">
            <template #materialSize-cell="{ row }">
              {{ row.original.materialSize || '-' }}
            </template>
            <template #consumption-cell="{ row }">
              <span class="font-mono">{{ fmtQty(row.original.consumption ?? 0) }}</span>
            </template>
          </UTable>
        </div>

        <!-- Color Table (Theo màu) -->
        <div>
          <h3 class="mb-3 flex items-center gap-2 text-lg font-semibold">
            <UIcon name="i-lucide-palette" class="text-primary" />
            Theo màu
          </h3>
          <UTable :data="sortedColors" :columns="colorColumns">
            <template #materialColor-cell="{ row }">
              {{ row.original.materialColor || '-' }}
            </template>
            <template #consumption-cell="{ row }">
              <span class="font-mono">{{ fmtQty(row.original.consumption) }}</span>
            </template>
            <template #cuttingConsumption-cell="{ row }">
              <span class="font-mono">{{ fmtQty(row.original.cuttingConsumption) }}</span>
            </template>
          </UTable>
        </div>
      </div>
      <div v-else class="py-4 text-center text-toned">Không có dữ liệu định mức.</div>
    </template>
  </UModal>
</template>
