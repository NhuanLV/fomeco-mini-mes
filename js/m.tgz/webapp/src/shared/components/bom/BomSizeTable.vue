<script setup lang="ts">
import { rejectComma } from '@/shared/utils/numberInput'
import { fmtQty } from '@/shared/utils/fmtQty'
import type { TableColumn } from '@nuxt/ui'
import type { EditableSize, LineEditState } from './types'

const props = defineProps<{
  state: LineEditState
  uom: string
  canEdit: boolean
  readonly?: boolean
  isCutting?: boolean
}>()

const emit = defineEmits<{
  cellEdit: [data: EditableSize, newValue: number | null]
  applyFirst: []
}>()

type InputRef = { $el?: Element | null } | null

const inputRefs = new Map<string, InputRef>()
const columns: TableColumn<EditableSize>[] = [
  { accessorKey: 'productSize', header: 'Cỡ SP' },
  { accessorKey: 'materialSize', header: 'Cỡ NPL' },
  { accessorKey: 'consumption', header: 'Định mức' },
]

function getCellKey(size: EditableSize) {
  return `${size.productSize}:${size.materialSize}:consumption`
}

function setInputRef(size: EditableSize, instance: InputRef) {
  const key = getCellKey(size)
  if (instance) inputRefs.set(key, instance)
  else inputRefs.delete(key)
}

function focusNextInput(currentIndex: number) {
  if (currentIndex < 0 || currentIndex >= props.state.sizes.length - 1) return
  const nextSize = props.state.sizes[currentIndex + 1]
  const nextInputNumber = inputRefs.get(getCellKey(nextSize))
  const nextInput = nextInputNumber?.$el?.querySelector('input')
  if (!(nextInput instanceof HTMLInputElement)) return

  nextInput.focus()
  nextInput.select()
}
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex items-center justify-between">
        <span class="flex items-center gap-2">
          <UIcon name="i-lucide-arrow-down-wide-narrow" class="text-primary" />
          Theo cỡ
        </span>
        <div v-if="!readonly && canEdit" class="flex gap-1">
          <UButton
            icon="i-lucide-arrow-down"
            variant="ghost"
            size="md"
            color="info"
            :disabled="state.sizes.length < 2"
            title="Ghi đè tất cả dòng sau từ dòng đầu"
            aria-label="Ghi đè tất cả dòng sau từ dòng đầu"
            @click="emit('applyFirst')"
          />
        </div>
      </div>
    </template>
    <template #default>
      <p v-if="state.sizes.length === 0" class="py-2 text-center text-sm text-toned">
        Không phụ thuộc cỡ
      </p>
      <UTable v-else :data="state.sizes" :columns="columns" class="text-sm">
        <template #materialSize-cell="{ row }">
          {{ row.original.materialSize || '-' }}
        </template>
        <template #consumption-cell="{ row }">
          <div @click.stop>
            <UInputNumber
              v-if="!readonly && canEdit"
              :ref="(instance: unknown) => setInputRef(row.original, instance as InputRef)"
              :model-value="row.original.consumption"
              :model-modifiers="{ optional: true }"
              :increment="false"
              :decrement="false"
              :step="0.0001"
              :format-options="{ maximumFractionDigits: 4 }"
              locale="en-US"
              size="sm"
              @update:model-value="
                emit('cellEdit', row.original, (row.original.consumption = $event ?? null))
              "
              @beforeinput="rejectComma"
              @keyup.enter="focusNextInput(row.index)"
            />
            <span v-else class="font-mono font-semibold text-info">
              {{ fmtQty(row.original.consumption) }}
            </span>
          </div>
        </template>
      </UTable>
    </template>
  </UCard>
</template>
