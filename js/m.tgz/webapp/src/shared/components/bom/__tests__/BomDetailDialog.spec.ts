import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import { nextTick } from 'vue'
import BomDetailDialog from '../BomDetailDialog.vue'

describe('BomDetailDialog', () => {
  const sampleBomLine = {
    id: 'LINE-1',
    articleName: 'Vải chính',
    isRequired: true,
    uom: 'MTR',
    sizes: [
      { productSize: 'S', materialSize: 'S', consumption: 1.5 },
      { productSize: 'M', materialSize: 'M', consumption: 1.7 },
    ],
    colors: [
      {
        productColor: 'RED',
        materialColor: 'RED',
        consumption: 1.6,
        cuttingConsumption: 1.55,
      },
    ],
    destinationCodes: ['US'],
  }

  it('uses API order for the readonly size and color tables without changing the BOM', () => {
    const line = {
      ...sampleBomLine,
      sizes: [...sampleBomLine.sizes].reverse(),
      colors: ['Blue', 'Red'].map((productColor) => ({
        productColor,
        materialColor: '',
        consumption: 1,
        cuttingConsumption: 0,
      })),
    }
    const wrapper = mount(BomDetailDialog, {
      props: { visible: true, bomLine: line },
      attrs: { styleSizeOrder: ['S', 'M'], styleColorOrder: ['Red', 'Blue'] },
      global: { stubs: { Modal: { template: '<div><slot name="body" /></div>' }, Icon: true } },
    })
    const tables = wrapper.findAllComponents({ name: 'Table' })
    expect(tables[0]!.props('data').map((row: { productSize: string }) => row.productSize)).toEqual(
      ['S', 'M'],
    )
    expect(
      tables[1]!.props('data').map((row: { productColor: string }) => row.productColor),
    ).toEqual(['Red', 'Blue'])
    expect(line.colors[0]!.productColor).toBe('Blue')
    wrapper.unmount()
  })

  it('renders standard color table without cutting columns when isCutting is false', async () => {
    document.body.innerHTML = ''
    const wrapper = mount(BomDetailDialog, {
      props: {
        visible: true,
        bomLine: sampleBomLine,
        isCutting: false,
      },
      attachTo: document.body,
    })
    await nextTick()

    expect(document.body.textContent).toContain('Theo cỡ')
    expect(document.body.textContent).toContain('Theo màu')
    expect(document.body.textContent).toContain('1.5')
    expect(document.body.textContent).not.toContain('Định mức (Kỹ thuật)')
    expect(document.body.textContent).not.toContain('Định mức (Tổ cắt)')
    wrapper.unmount()
  })

  it('renders cutting consumption columns when isCutting is true', async () => {
    document.body.innerHTML = ''
    const wrapper = mount(BomDetailDialog, {
      props: {
        visible: true,
        bomLine: sampleBomLine,
        isCutting: true,
      },
      attachTo: document.body,
    })
    await nextTick()

    expect(document.body.textContent).toContain('Định mức (Kỹ thuật)')
    expect(document.body.textContent).toContain('Định mức (Tổ cắt)')
    expect(document.body.textContent).toContain('1.6')
    expect(document.body.textContent).toContain('1.55')
    wrapper.unmount()
  })
})
