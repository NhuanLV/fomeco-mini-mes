import { flushPromises, mount } from '@vue/test-utils'
import { expect, it } from 'vitest'
import { reactive } from 'vue'
import { createPinia } from 'pinia'
import { PiniaColada } from '@pinia/colada'
import TeamBomTable from '@/features/production/team-assignment/components/costing/TeamBomTable.vue'
import BomTableBase from '../BomTableBase.vue'
import ColumnMultiSelectFilter from '../../ColumnMultiSelectFilter.vue'
import ConsumptionComparisonCard from '@/features/production/team-assignment/components/costing/ConsumptionComparisonCard.vue'
import type { BomLine, LineEditState } from '../types'

it('orders readonly BOM details and combined filters by API while preserving edit drafts', async () => {
  const lines: BomLine[] = ['A', 'B'].map((id, index) => ({
    id,
    articleName: id,
    uom: 'M',
    isRequired: true,
    sizes: (index === 0 ? ['L'] : ['M', 'S']).map((productSize) => ({
      productSize,
      materialSize: '',
      consumption: 1,
    })),
    colors: (index === 0 ? ['Blue'] : ['Blue', 'Red']).map((productColor) => ({
      productColor,
      materialColor: '',
      consumption: 1,
      cuttingConsumption: 0,
    })),
    destinationCodes: [],
  }))
  const state: LineEditState = {
    sizes: lines[1]!.sizes,
    colors: lines[1]!.colors,
    originalSizes: '',
    originalColors: '',
    saving: false,
  }
  const wrapper = mount(BomTableBase, {
    props: {
      lines,
      expandedRows: { B: true },
      showBomEdit: true,
      canEdit: true,
      editStates: new Map([['B', state]]),
    },
    attrs: { styleSizeOrder: ['S', 'M', 'L'], styleColorOrder: ['Red', 'Blue'] },
    global: { stubs: { UIcon: true, BomColorTable: true, BomSizeTable: true } },
  })
  const optionLabels = (name: string) =>
    wrapper
      .findAllComponents(ColumnMultiSelectFilter)
      .find((filter) => filter.props('placeholder') === name)!
      .props('items')
      .map((item: { label: string }) => item.label)
  expect(optionLabels('Cỡ')).toEqual(['S', 'M', 'L'])
  expect(optionLabels('Màu sắc')).toEqual(['Red', 'Blue'])
  expect(
    wrapper
      .findComponent({ name: 'BomColorTable' })
      .props('state')
      .colors.map((row: { productColor: string }) => row.productColor),
  ).toEqual(['Red', 'Blue'])
  await wrapper.setProps({ editingBom: true })
  expect(state.colors.map((row) => row.productColor)).toEqual(['Blue', 'Red'])
  expect(
    wrapper
      .findComponent({ name: 'BomColorTable' })
      .props('state')
      .colors.map((row: { productColor: string }) => row.productColor),
  ).toEqual(['Red', 'Blue'])
  expect(optionLabels('Cỡ')).toEqual(['S', 'M', 'L'])
  expect(lines[1]!.colors[0]!.productColor).toBe('Blue')
  wrapper.unmount()
})

it('filters BOM rows without removing draft details and expands only visible rows', async () => {
  const lines: BomLine[] = ['A', 'B'].map((id) => ({
    id,
    articleName: id,
    uom: 'M',
    isRequired: true,
    sizes: [{ productSize: 'S', materialSize: '', consumption: 1 }],
    colors: [],
    destinationCodes: [],
  }))
  const state: LineEditState = {
    sizes: [{ productSize: 'S', materialSize: '', consumption: 9 }],
    colors: [],
    originalSizes: '',
    originalColors: '',
    saving: false,
  }
  const editStates = reactive(new Map([['A', state]]))
  const wrapper = mount(BomTableBase, {
    props: { lines, editStates, expandedRows: { A: true }, canEdit: true, editingBom: true },
    global: { stubs: { UIcon: true, BomColorTable: true, BomSizeTable: true } },
  })
  const nameFilter = () =>
    wrapper
      .findAllComponents(ColumnMultiSelectFilter)
      .find((filter) => filter.props('placeholder') === 'NPL')!
  nameFilter().vm.$emit('update:modelValue', [JSON.stringify('B')])
  await flushPromises()
  expect(
    wrapper
      .findComponent({ name: 'Table' })
      .props('data')
      .map((line: BomLine) => line.id),
  ).toEqual(['B'])
  expect(editStates.get('A')!.sizes[0]!.consumption).toBe(9)
  await wrapper
    .findAll('button')
    .find((button) => button.text() === 'Mở rộng')!
    .trigger('click')
  expect(wrapper.emitted('expandAll')!.at(-1)).toEqual([[lines[1]]])
  await wrapper
    .findAll('button')
    .find((button) => button.attributes('aria-label') === 'Xóa bộ lọc')!
    .trigger('click')
  await flushPromises()
  expect(wrapper.findComponent({ name: 'Table' }).props('data')).toHaveLength(2)
  expect(editStates.get('A')!.sizes[0]!.consumption).toBe(9)
  expect(nameFilter().props('items')).toHaveLength(2)
  wrapper.unmount()
})

it('filters comparison rows by material and color independently of BOM filters', async () => {
  const comparisons = ['Red', 'Blue'].map((materialColor) => ({
    articleName: 'A',
    articleCode: null,
    alternativeName: null,
    materialColor,
    uom: 'M',
    bySizeQty: 1,
    byColorQty: 2,
    byCutterQty: 3,
  }))
  const wrapper = mount(ConsumptionComparisonCard, {
    props: {
      comparisons,
      totalComparison: { bySizeQty: 2, byColorQty: 4, byCutterQty: 6 },
      comparisonUom: 'M',
    },
    global: { stubs: { UIcon: true } },
  })
  wrapper
    .findAllComponents(ColumnMultiSelectFilter)
    .find((filter) => filter.props('placeholder') === 'Màu')!
    .vm.$emit('update:modelValue', [JSON.stringify('Red')])
  await flushPromises()
  expect(wrapper.findComponent({ name: 'Table' }).props('data')).toEqual([comparisons[0]])
  await wrapper
    .findAll('button')
    .find((button) => button.attributes('aria-label') === 'Xóa bộ lọc')!
    .trigger('click')
  await flushPromises()
  expect(wrapper.findComponent({ name: 'Table' }).props('data')).toHaveLength(2)
  wrapper.unmount()
})

it('sorts comparison materials by Vietnamese name while preserving color order within a material', () => {
  const comparisons = ['Vải', 'Chỉ', 'Đệm', 'Chỉ'].map((articleName, index) => ({
    articleName,
    materialColor: String(index),
    uom: 'M',
    bySizeQty: 1,
    byColorQty: 1,
    byCutterQty: 1,
  }))
  const wrapper = mount(ConsumptionComparisonCard, {
    props: {
      comparisons,
      totalComparison: { bySizeQty: 4, byColorQty: 4, byCutterQty: 4 },
      comparisonUom: 'M',
    },
    global: { stubs: { UIcon: true } },
  })
  expect(wrapper.findComponent({ name: 'Table' }).props('data')).toEqual([
    comparisons[1],
    comparisons[3],
    comparisons[2],
    comparisons[0],
  ])
  expect(comparisons.map((row) => row.articleName)).toEqual(['Vải', 'Chỉ', 'Đệm', 'Chỉ'])
  wrapper.unmount()
})

it('filters expanded size/color details, keeps the draft, and uses meaningful options', async () => {
  const line: BomLine = {
    id: 'A',
    articleName: 'A',
    uom: 'M',
    isRequired: true,
    sizes: ['S', 'M'].map((productSize) => ({ productSize, materialSize: '', consumption: 1 })),
    colors: ['Red', 'Blue'].map((productColor) => ({
      productColor,
      materialColor: '',
      consumption: 1,
      cuttingConsumption: 0,
    })),
    destinationCodes: [],
  }
  const state: LineEditState = {
    sizes: line.sizes.map((size) => ({ ...size, consumption: 9 })),
    colors: line.colors.map((color) => ({ ...color, consumption: 8 })),
    originalSizes: '',
    originalColors: '',
    saving: false,
  }
  const wrapper = mount(BomTableBase, {
    props: {
      lines: [line],
      editStates: reactive(new Map([['A', state]])),
      expandedRows: { A: true },
      canEdit: true,
    },
    global: { stubs: { UIcon: true, BomSizeTable: true, BomColorTable: true } },
  })
  const filter = (name: string) =>
    wrapper
      .findAllComponents(ColumnMultiSelectFilter)
      .find((component) => component.props('placeholder') === name)!
  expect(
    filter('NPL bắt buộc')
      .props('items')
      .map((item: { label: string }) => item.label),
  ).toEqual(['Bắt buộc', 'Không bắt buộc'])
  expect(filter('Tên thay thế').props('items')).toEqual([])
  expect(
    filter('Cỡ')
      .props('items')
      .map((item: { label: string }) => item.label),
  ).toEqual(['S', 'M'])
  expect(
    filter('Màu sắc')
      .props('items')
      .map((item: { label: string }) => item.label),
  ).toEqual(['Red', 'Blue'])
  filter('Cỡ').vm.$emit('update:modelValue', [JSON.stringify('M')])
  filter('Màu sắc').vm.$emit('update:modelValue', [JSON.stringify('Blue')])
  await flushPromises()
  const sizes = wrapper.findComponent({ name: 'BomSizeTable' }).props('state').sizes
  const colors = wrapper.findComponent({ name: 'BomColorTable' }).props('state').colors
  expect(sizes.map((size: { productSize: string }) => size.productSize)).toEqual(['M'])
  expect(colors.map((color: { productColor: string }) => color.productColor)).toEqual(['Blue'])
  expect(sizes[0]).toBe(wrapper.props('editStates')!.get('A')!.sizes[1])
  expect(state.sizes).toHaveLength(2)
  expect(state.colors).toHaveLength(2)
  await wrapper.find('button[aria-label="Xóa bộ lọc"]').trigger('click')
  await flushPromises()
  expect(wrapper.findComponent({ name: 'BomSizeTable' }).props('state').sizes).toHaveLength(2)
  expect(wrapper.findComponent({ name: 'BomColorTable' }).props('state').colors).toHaveLength(2)
  wrapper.unmount()
})

it('preserves size order and unsaved drafts through individual and bulk collapse until cancel', async () => {
  const wrapper = mount(TeamBomTable, {
    props: {
      teamAssignmentId: 'TEAM-1',
      productionOrderId: 'PO-1',
      styleSizeOrder: ['S', 'M', 'L'],
      bomData: {
        teamAssignmentId: 'TEAM-1',
        lines: [
          {
            id: 'A',
            articleName: 'A',
            category: 'Vải',
            uom: 'M',
            isRequired: true,
            sizes: ['L', 'M', 'S'].map((productSize) => ({
              productSize,
              materialSize: '',
              consumption: 1,
            })),
            colors: [],
            cuttingColors: [],
            destinationCodes: [],
          },
        ],
      },
    },
    global: {
      plugins: [createPinia(), PiniaColada],
      stubs: { UIcon: true, BomSizeTable: true, BomColorTable: true },
    },
  })
  const sizeOptions = () =>
    wrapper
      .findAllComponents(ColumnMultiSelectFilter)
      .find((component) => component.props('placeholder') === 'Cỡ')!
      .props('items')
      .map((item: { label: string }) => item.label)
  expect(sizeOptions()).toEqual(['S', 'M', 'L'])
  const bomTable = wrapper.findComponent(BomTableBase)
  bomTable.vm.$emit('startBomEdit')
  await flushPromises()
  const draft = bomTable.props('editStates')!.get('A')!
  bomTable.vm.$emit('cellEditSize', 'A', draft.sizes[0], 9)
  await flushPromises()
  bomTable.vm.$emit('toggleExpand', bomTable.props('lines')[0])
  await flushPromises()
  expect(bomTable.props('editStates')!.get('A')).toBe(draft)
  expect(draft.sizes[0]!.consumption).toBe(9)
  bomTable.vm.$emit('toggleExpand', bomTable.props('lines')[0])
  await flushPromises()
  expect(bomTable.props('editStates')!.get('A')!.sizes[0]!.consumption).toBe(9)
  await wrapper
    .findAll('button')
    .find((button) => button.text() === 'Mở rộng')!
    .trigger('click')
  await flushPromises()
  expect(sizeOptions()).toEqual(['S', 'M', 'L'])
  expect(
    wrapper
      .findComponent({ name: 'BomSizeTable' })
      .props('state')
      .sizes.map((size: { productSize: string }) => size.productSize),
  ).toEqual(['S', 'M', 'L'])
  await wrapper
    .findAll('button')
    .find((button) => button.text() === 'Thu gọn')!
    .trigger('click')
  await flushPromises()
  expect(sizeOptions()).toEqual(['S', 'M', 'L'])
  expect(bomTable.props('editStates')!.get('A')).toBe(draft)
  await wrapper
    .findAll('button')
    .find((button) => button.text() === 'Mở rộng')!
    .trigger('click')
  await flushPromises()
  expect(wrapper.findComponent({ name: 'BomSizeTable' }).props('state').sizes[0].consumption).toBe(
    9,
  )
  bomTable.vm.$emit('cancelBomEdit')
  await flushPromises()
  expect(bomTable.props('editStates')!.size).toBe(0)
  wrapper.unmount()
})
