import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import BomColorTable from '../BomColorTable.vue'
import BomSizeTable from '../BomSizeTable.vue'

describe('BOM numeric inputs', () => {
  it('uses a spinner-free decimal input that rejects commas', async () => {
    const state = {
      sizes: [{ productSize: 'S', materialSize: 'S', consumption: 1 }],
      colors: [],
      originalSizes: '',
      originalColors: '',
      saving: false,
    }
    const wrapper = mount(BomSizeTable, {
      props: { state, uom: 'M', canEdit: true },
      global: { stubs: { UIcon: true } },
    })
    const input = wrapper.get('input[role="spinbutton"]')
    const comma = new InputEvent('beforeinput', { data: ',', cancelable: true })

    input.element.dispatchEvent(comma)

    expect(comma.defaultPrevented).toBe(true)
    expect(wrapper.find('[data-slot="increment"]').exists()).toBe(false)
    expect(wrapper.find('[data-slot="decrement"]').exists()).toBe(false)
    expect(wrapper.findAll('button')).toHaveLength(1)
    const fill = wrapper.get('button[aria-label="Ghi đè tất cả dòng sau từ dòng đầu"]')
    expect(fill.attributes('disabled')).toBeDefined()
    await wrapper.setProps({ state: { ...state, sizes: [...state.sizes, { ...state.sizes[0]! }] } })
    await fill.trigger('click')
    expect(wrapper.emitted('applyFirst')).toHaveLength(1)
    expect(wrapper.find('button[title="Hoàn tác"]').exists()).toBe(false)
  })

  it('restores null when a size consumption is cleared', async () => {
    const state = {
      sizes: [{ productSize: 'S', materialSize: 'S', consumption: 1 }],
      colors: [],
      originalSizes: '',
      originalColors: '',
      saving: false,
    }
    const wrapper = mount(BomSizeTable, {
      props: { state, uom: 'M', canEdit: true },
    })

    const input = wrapper.get('input[role="spinbutton"]')
    await input.setValue('')
    await input.trigger('blur')

    expect(state.sizes[0].consumption).toBeNull()
  })

  it('restores null when color consumptions are cleared', async () => {
    const state = {
      sizes: [],
      colors: [
        {
          productColor: 'Đỏ',
          materialColor: 'Đỏ',
          consumption: 1,
          cuttingConsumption: 2,
        },
      ],
      originalSizes: '',
      originalColors: '',
      saving: false,
    }
    const wrapper = mount(BomColorTable, {
      props: {
        state,
        uom: 'M',
        canEdit: true,
        canEditCutting: true,
        isCutting: true,
      },
    })

    expect(wrapper.findAll('button')).toHaveLength(1)
    const inputs = wrapper.findAll('input[role="spinbutton"]')
    await inputs[0].setValue('')
    await inputs[0].trigger('blur')
    await inputs[1].setValue('')
    await inputs[1].trigger('blur')

    expect(state.colors[0].consumption).toBeNull()
    expect(state.colors[0].cuttingConsumption).toBeNull()
  })

  it('commits each size value when Enter is used before blur', async () => {
    const state = {
      sizes: [
        { productSize: 'S', materialSize: 'S', consumption: 1 },
        { productSize: 'M', materialSize: 'M', consumption: 2 },
        { productSize: 'L', materialSize: 'L', consumption: 3 },
      ],
      colors: [],
      originalSizes: '',
      originalColors: '',
      saving: false,
    }
    const wrapper = mount(BomSizeTable, {
      attachTo: document.body,
      props: { state, uom: 'M', canEdit: true },
    })

    for (const [index, value] of ['10', '20'].entries()) {
      const input = wrapper.findAll('input[role="spinbutton"]')[index]
      if (!(input.element instanceof HTMLInputElement)) throw new Error('Expected input')
      input.element.focus()
      await input.setValue(value)
      await input.trigger('keyup.enter')
    }

    const lastInput = wrapper.findAll('input[role="spinbutton"]')[2]
    if (!(lastInput.element instanceof HTMLInputElement)) throw new Error('Expected input')
    lastInput.element.value = '30'
    await lastInput.trigger('input')
    await lastInput.trigger('blur')

    expect(state.sizes.map((size) => size.consumption)).toEqual([10, 20, 30])
    wrapper.unmount()
  })
})
