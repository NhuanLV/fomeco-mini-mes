import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import BomTableBase from '../BomTableBase.vue'

describe('BomTableBase material-state editing', () => {
  it('starts in view mode with edit button and badge', async () => {
    const wrapper = mount(BomTableBase, {
      props: {
        lines: [
          {
            id: 'MAT-1',
            articleName: 'MAT-1',
            isRequired: true,
            uom: 'M',
            sizes: [],
            colors: [],
            destinationCodes: [],
          },
        ],
        canEditMaterialState: true,
        editingMaterialState: false,
        hasMaterialStateChanges: false,
      },
    })

    const editBtn = wrapper.findAll('button').find((b) => b.text().includes('Chỉnh sửa'))
    expect(editBtn).toBeDefined()
    expect(wrapper.text()).toContain('Bắt buộc')

    await editBtn!.trigger('click')
    expect(wrapper.emitted('startMaterialStateEdit')).toHaveLength(1)
  })

  it('renders switch/checkbox and enables saving in edit mode', async () => {
    const wrapper = mount(BomTableBase, {
      props: {
        lines: [
          {
            id: 'MAT-1',
            articleName: 'MAT-1',
            isRequired: true,
            uom: 'M',
            sizes: [],
            colors: [],
            destinationCodes: [],
          },
        ],
        canEditMaterialState: true,
        editingMaterialState: true,
        hasMaterialStateChanges: true,
      },
    })

    const buttons = wrapper.findAll('button')
    const cancelBtn = buttons.find((b) => b.text().includes('Hủy'))
    const saveBtn = buttons.find((b) => b.text().includes('Lưu'))

    expect(cancelBtn).toBeDefined()
    expect(saveBtn).toBeDefined()
    expect(saveBtn!.attributes('disabled')).toBeUndefined()

    const checkbox = wrapper.find('input[type="checkbox"]')
    if (checkbox.exists()) {
      await checkbox.setValue(false)
      expect(wrapper.emitted('update:required')).toEqual([['MAT-1', false]])
    }

    const textInput = wrapper.find('input[type="text"]')
    if (textInput.exists()) {
      await textInput.setValue('Vải lót thay thế')
      expect(wrapper.emitted('update:altName')).toContainEqual(['MAT-1', 'Vải lót thay thế'])
    }
  })
})
