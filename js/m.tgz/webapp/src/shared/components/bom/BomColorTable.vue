<script setup lang="ts">
import { fmtQty } from '@/shared/utils/fmtQty'
import type { TableColumn } from '@nuxt/ui'
import { computed } from 'vue'
import { rejectComma } from '@/shared/utils/numberInput'
import type { EditableColor, LineEditState } from './types'

const props = defineProps<{
  state: LineEditState
  uom: string
  canEdit: boolean
  canEditCutting: boolean
  isCutting: boolean
  readonly?: boolean
}>()

const emit = defineEmits<{
  cellEdit: [
    data: EditableColor,
    field: 'consumption' | 'cuttingConsumption',
    newValue: number | null,
  ]
  applyFirst: []
}>()

type InputRef = { $el?: Element | null } | null

const inputRefs = new Map<string, InputRef>()
const columns = computed<TableColumn<EditableColor>[]>(() => [
  { accessorKey: 'productColor', header: 'Màu SP' },
  { accessorKey: 'materialColor', header: 'Màu NPL' },
  ...(props.canEdit || props.isCutting
    ? [{ accessorKey: 'consumption', header: props.isCutting ? 'Định mức (Kỹ thuật)' : 'Định mức' }]
    : []),
  ...(props.isCutting && props.canEditCutting
    ? [{ accessorKey: 'cuttingConsumption', header: 'Định mức (Tổ cắt)' }]
    : []),
])

function getCellKey(color: EditableColor, field: 'consumption' | 'cuttingConsumption') {
  return `${color.productColor}:${color.materialColor}:${field}`
}

function setInputRef(
  color: EditableColor,
  field: 'consumption' | 'cuttingConsumption',
  instance: InputRef,
) {
  const key = getCellKey(color, field)
  if (instance) inputRefs.set(key, instance)
  else inputRefs.delete(key)
}

function focusNextInput(currentIndex: number, field: 'consumption' | 'cuttingConsumption') {
  if (currentIndex < 0 || currentIndex >= props.state.colors.length - 1) return
  const nextColor = props.state.colors[currentIndex + 1]
  const nextInputNumber = inputRefs.get(getCellKey(nextColor, field))
  const nextInput = nextInputNumber?.$el?.querySelector('input')
  if (!(nextInput instanceof HTMLInputElement)) return

  nextInput.focus()
  nextInput.select()
}
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex items-center justify-between">
        <span class="flex items-center gap-2">
          <UIcon name="i-lucide-palette" class="text-primary" />
          Theo màu
        </span>
        <div v-if="!readonly && (canEdit || (canEditCutting && isCutting))" class="flex gap-1">
          <UButton
            icon="i-lucide-arrow-down"
            variant="ghost"
            size="md"
            color="success"
            :disabled="state.colors.length < 2"
            title="Ghi đè tất cả dòng sau từ dòng đầu"
            aria-label="Ghi đè tất cả dòng sau từ dòng đầu"
            @click="emit('applyFirst')"
          />
        </div>
      </div>
    </template>
    <template #default>
      <p v-if="state.colors.length === 0" class="py-2 text-center text-sm text-toned">
        Không phụ thuộc màu
      </p>
      <UTable v-else :data="state.colors" :columns="columns" class="text-sm">
        <template #productColor-cell="{ row }">
          <span class="font-medium">{{ row.original.productColor }}</span>
        </template>
        <template #materialColor-cell="{ row }">
          <span v-if="row.original.materialColor">{{ row.original.materialColor }}</span>
          <span v-else class="text-toned italic">-</span>
        </template>
        <template #consumption-cell="{ row }">
          <div @click.stop>
            <UInputNumber
              v-if="!readonly && canEdit"
              :ref="
                (instance: unknown) =>
                  setInputRef(row.original, 'consumption', instance as InputRef)
              "
              :model-value="row.original.consumption"
              :model-modifiers="{ optional: true }"
              :increment="false"
              :decrement="false"
              :step="0.0001"
              :format-options="{ maximumFractionDigits: 4 }"
              locale="en-US"
              size="sm"
              @update:model-value="
                emit(
                  'cellEdit',
                  row.original,
                  'consumption',
                  (row.original.consumption = $event ?? null),
                )
              "
              @beforeinput="rejectComma"
              @keyup.enter="focusNextInput(row.index, 'consumption')"
            />
            <span v-else class="font-mono font-semibold text-success">
              {{ fmtQty(row.original.consumption ?? 0) }}
            </span>
          </div>
        </template>
        <template #cuttingConsumption-cell="{ row }">
          <div @click.stop>
            <UInputNumber
              v-if="!readonly && canEditCutting"
              :ref="
                (instance: unknown) =>
                  setInputRef(row.original, 'cuttingConsumption', instance as InputRef)
              "
              :model-value="row.original.cuttingConsumption"
              :model-modifiers="{ optional: true }"
              :increment="false"
              :decrement="false"
              :step="0.0001"
              :format-options="{ maximumFractionDigits: 4 }"
              locale="en-US"
              size="sm"
              @update:model-value="
                emit(
                  'cellEdit',
                  row.original,
                  'cuttingConsumption',
                  (row.original.cuttingConsumption = $event ?? null),
                )
              "
              @beforeinput="rejectComma"
              @keyup.enter="focusNextInput(row.index, 'cuttingConsumption')"
            />
            <span v-else class="font-mono font-semibold text-success">
              {{ fmtQty(row.original.cuttingConsumption ?? 0) }}
            </span>
          </div>
        </template>
      </UTable>
    </template>
  </UCard>
</template>
