export interface EditableSize {
  productSize: string
  materialSize: string
  consumption: number | null
}

export interface EditableColor {
  productColor: string
  materialColor: string
  consumption: number | null
  cuttingConsumption: number | null
}

export interface LineEditState {
  sizes: EditableSize[]
  colors: EditableColor[]
  originalSizes: string
  originalColors: string
  saving: boolean
}

export interface BomLine {
  id: string
  articleName: string
  articleCode?: string | null
  alternativeName?: string | null
  isRequired: boolean
  uom: string
  category?: string
  sizes: EditableSize[]
  colors: EditableColor[]
  destinationCodes: string[]
  operations?: string[]
  lastUpdatedAt?: string | null
  lastUpdatedBy?: { name: string } | null
}
