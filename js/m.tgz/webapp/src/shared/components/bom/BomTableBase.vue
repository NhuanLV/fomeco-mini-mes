<script setup lang="ts">
import type { TableExpandedRows } from '@/shared/types/table'
import type { TableColumn, TableRow } from '@nuxt/ui'
import { computed } from 'vue'
import ColumnMultiSelectFilter from '@/shared/components/ColumnMultiSelectFilter.vue'
import { useColumnFilters } from '@/shared/composables/useColumnFilters'
import BomColorTable from './BomColorTable.vue'
import BomSizeTable from './BomSizeTable.vue'
import type { BomLine, EditableColor, EditableSize, LineEditState } from './types'
import ExpandCollapseButtons from '@/shared/components/ExpandCollapseButtons.vue'
import { makeOrderComparator } from '@/shared/utils/orderedValues'

const props = defineProps<{
  lines: BomLine[]
  loading?: boolean
  readonly?: boolean
  // Edit related props (optional, needed when readonly=false)
  editStates?: Map<string, LineEditState>
  canEdit?: boolean
  canEditColor?: boolean
  canEditCutting?: boolean
  isCutting?: boolean
  // Custom actions
  title?: string
  showReload?: boolean
  reloading?: boolean
  hasMaterialStateChanges?: boolean
  savingMaterialState?: boolean
  canEditMaterialState?: boolean
  editingMaterialState?: boolean
  editingBom?: boolean
  savingBom?: boolean
  showBomEdit?: boolean
  styleColorOrder?: string[]
  styleSizeOrder?: string[]
}>()

const emit = defineEmits<{
  toggleExpand: [row: BomLine]
  cellEditSize: [lineId: string, data: EditableSize, newValue: number | null]
  cellEditColor: [
    lineId: string,
    data: EditableColor,
    field: 'consumption' | 'cuttingConsumption',
    newValue: number | null,
  ]
  applyFirst: [lineId: string, field: 'sizes' | 'colors']
  reload: []
  expandAll: [lines: BomLine[]]
  collapseAll: []
  'update:altName': [lineId: string, newValue: string]
  'update:required': [lineId: string, isRequired: boolean]
  startMaterialStateEdit: []
  cancelMaterialStateEdit: []
  saveMaterialState: []
  startBomEdit: []
  cancelBomEdit: []
  saveBom: []
}>()

const expandedRowsModel = defineModel<TableExpandedRows>('expandedRows', {
  default: () => ({}),
})
const expandedRows = computed({
  get: () => expandedRowsModel.value,
  set: (value) => {
    expandedRowsModel.value = value
  },
})

const sortedLines = computed(() =>
  [...props.lines].sort(
    (left, right) =>
      left.articleName.localeCompare(right.articleName, 'vi') || left.id.localeCompare(right.id),
  ),
)
const filterColumns = {
  articleName: { label: 'NPL', values: (line: BomLine) => [line.articleName] },
  articleCode: { label: 'Mã NPL', values: (line: BomLine) => [line.articleCode] },
  alternativeName: {
    label: 'Tên thay thế',
    values: (line: BomLine) => [line.alternativeName],
    includeEmpty: false,
  },
  category: { label: 'Loại', values: (line: BomLine) => [line.category] },
  uom: { label: 'ĐVT', values: (line: BomLine) => [line.uom] },
  sizes: {
    label: 'Cỡ',
    values: (line: BomLine) => line.sizes.map((size) => size.productSize),
    preserveOrder: true,
    emptyLabel: 'Không phụ thuộc cỡ',
    unrestricted: true,
  },
  colors: {
    label: 'Màu sắc',
    values: (line: BomLine) => line.colors.map((color) => color.productColor),
    preserveOrder: true,
    emptyLabel: 'Tất cả màu',
    unrestricted: true,
  },
  operations: {
    label: 'Công đoạn',
    values: (line: BomLine) => line.operations ?? [],
    emptyLabel: 'Tất cả công đoạn',
    unrestricted: true,
  },
  destinations: {
    label: 'Thị trường',
    values: (line: BomLine) => line.destinationCodes,
    emptyLabel: 'Tất cả thị trường',
    unrestricted: true,
  },
  isRequired: {
    label: 'NPL bắt buộc',
    options: ['Bắt buộc', 'Không bắt buộc'],
    values: (line: BomLine) => [line.isRequired ? 'Bắt buộc' : 'Không bắt buộc'],
  },
}
const { filters, options, filteredRows, clearFilters } = useColumnFilters(
  () => sortedLines.value,
  filterColumns,
)
const cmpSize = computed(() => makeOrderComparator(props.styleSizeOrder ?? []))
const cmpColor = computed(() => makeOrderComparator(props.styleColorOrder ?? []))
const isViewing = computed(
  () =>
    props.readonly ||
    !(
      props.editingBom ||
      props.editingMaterialState ||
      (!props.showBomEdit && props.editStates?.size && (props.canEdit || props.canEditCutting))
    ),
)
const orderedOptions = computed<typeof options.value>(() => ({
  ...options.value,
  sizes: [...options.value.sizes!].sort((left, right) => cmpSize.value(left.label, right.label)),
  colors: [...options.value.colors!].sort((left, right) => cmpColor.value(left.label, right.label)),
}))
const columns = computed<TableColumn<BomLine>[]>(() => [
  { id: 'index', header: 'STT' },
  { accessorKey: 'articleName', header: 'NPL', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'articleCode', header: 'Mã NPL', meta: { class: { th: 'p-0!' } } },
  {
    accessorKey: 'alternativeName',
    header: 'Tên thay thế',
    meta: { class: { th: 'min-w-48 p-0!', td: 'min-w-48' } },
  },
  ...(sortedLines.value.some((line) => line.category)
    ? [{ accessorKey: 'category', header: 'Loại', meta: { class: { th: 'p-0!' } } }]
    : []),
  { accessorKey: 'uom', header: 'ĐVT', meta: { class: { th: 'p-0!' } } },
  { id: 'sizes', header: 'Cỡ', meta: { class: { th: 'p-0!' } } },
  { id: 'colors', header: 'Màu sắc', meta: { class: { th: 'p-0!' } } },
  ...(sortedLines.value.some((line) => line.operations !== undefined)
    ? [{ id: 'operations', header: 'Công đoạn', meta: { class: { th: 'p-0!' } } }]
    : []),
  { id: 'destinations', header: 'Thị trường', meta: { class: { th: 'p-0!' } } },
  { id: 'isRequired', header: 'NPL bắt buộc', meta: { class: { th: 'p-0!' } } },
])
const visibleFilterColumns = computed(() =>
  Object.entries(filterColumns).filter(([key]) =>
    columns.value.some(
      (column) => ('accessorKey' in column && column.accessorKey === key) || column.id === key,
    ),
  ),
)
const getLineRowId = (row: BomLine) => row.id

function updateAlternativeName(row: BomLine, value: string | number | null | undefined) {
  row.alternativeName = value == null ? null : String(value)
}

function handleRowClick(_event: Event, row: TableRow<BomLine>) {
  const data = row.original
  const key = data.id
  const current = { ...expandedRows.value }
  if (current[key]) {
    delete current[key]
  } else {
    current[key] = true
  }
  expandedRows.value = current

  emit('toggleExpand', data)
}

function expandAll() {
  expandedRows.value = Object.fromEntries(filteredRows.value.map((line) => [line.id, true]))
  emit('expandAll', filteredRows.value)
}

function collapseAll() {
  expandedRows.value = {}
  emit('collapseAll')
}

function toggleMaterialStateEdit() {
  if (props.editingMaterialState) {
    emit('cancelMaterialStateEdit')
  } else {
    emit('startMaterialStateEdit')
  }
}

function toggleBomEdit() {
  if (props.editingBom) emit('cancelBomEdit')
  else emit('startBomEdit')
}

const fmtDate = (iso?: string) => {
  if (!iso) return ''
  return new Date(iso).toLocaleString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

// Internal state mapping for readonly mode if editStates is not provided
function getVisibleState(line: BomLine): LineEditState {
  const state =
    (isViewing.value ? undefined : props.editStates?.get(line.id)) ?? getReadonlyState(line)
  return {
    ...state,
    sizes: [...state.sizes]
      .sort(
        (left, right) =>
          cmpSize.value(left.productSize, right.productSize) ||
          left.materialSize.localeCompare(right.materialSize, 'vi'),
      )
      .filter(
        (size) =>
          !filters.sizes!.length || filters.sizes!.includes(JSON.stringify(size.productSize)),
      ),
    colors: [...state.colors]
      .sort(
        (left, right) =>
          cmpColor.value(left.productColor, right.productColor) ||
          left.materialColor.localeCompare(right.materialColor, 'vi'),
      )
      .filter(
        (color) =>
          !filters.colors!.length || filters.colors!.includes(JSON.stringify(color.productColor)),
      ),
  }
}

function getReadonlyState(line: BomLine): LineEditState {
  return {
    sizes: line.sizes,
    colors: line.colors,
    originalSizes: '',
    originalColors: '',
    saving: false,
  }
}
</script>

<template>
  <div class="space-y-4">
    <div class="flex items-center gap-3 px-1 pb-2">
      <template v-if="title">
        <UIcon name="i-lucide-table" class="size-5 text-primary" />
        <span class="text-lg font-semibold">{{ title }}</span>
      </template>
      <div class="ml-auto flex items-center gap-2">
        <UButton
          icon="i-lucide-filter-x"
          aria-label="Xóa bộ lọc"
          title="Xóa bộ lọc"
          color="neutral"
          variant="ghost"
          :disabled="!Object.values(filters).some((values) => values.length)"
          @click="clearFilters"
        />
        <ExpandCollapseButtons @expand-all="expandAll" @collapse-all="collapseAll" />
        <template v-if="showBomEdit">
          <UButton
            :icon="editingBom ? 'i-lucide-x' : 'i-lucide-pencil'"
            :label="editingBom ? 'Hủy' : 'Chỉnh sửa'"
            variant="outline"
            @click="toggleBomEdit"
          />
          <UButton
            v-if="editingBom"
            icon="i-lucide-save"
            label="Lưu"
            color="primary"
            variant="solid"
            :loading="savingBom"
            @click="emit('saveBom')"
          />
        </template>
        <template v-if="!readonly && canEditMaterialState">
          <UButton
            :icon="editingMaterialState ? 'i-lucide-x' : 'i-lucide-pencil'"
            :label="editingMaterialState ? 'Hủy' : 'Chỉnh sửa'"
            variant="outline"
            @click="toggleMaterialStateEdit"
          />
          <UButton
            v-if="editingMaterialState"
            icon="i-lucide-save"
            label="Lưu"
            color="primary"
            variant="solid"
            :disabled="!hasMaterialStateChanges"
            :loading="savingMaterialState"
            @click="emit('saveMaterialState')"
          />
        </template>
        <UButton
          v-if="showReload"
          icon="i-lucide-refresh-cw"
          color="neutral"
          variant="ghost"
          aria-label="Làm mới"
          title="Làm mới"
          :loading="reloading"
          @click="emit('reload')"
        />
      </div>
    </div>

    <UTable
      :data="filteredRows"
      :columns="columns"
      :loading="loading"
      v-model:expanded="expandedRows"
      :get-row-id="getLineRowId"
      :ui="{ tr: 'cursor-pointer' }"
      @select="handleRowClick"
    >
      <template v-for="[key, column] in visibleFilterColumns" :key="key" #[`${key}-header`]>
        <ColumnMultiSelectFilter
          :model-value="filters[key]!"
          :items="orderedOptions[key]!"
          :disabled="!orderedOptions[key]!.length"
          :placeholder="column.label"
          :aria-label="`Lọc ${column.label.toLowerCase()}`"
          :search-placeholder="`Tìm ${column.label.toLowerCase()}...`"
          @update:model-value="filters[key] = $event"
        />
      </template>
      <template #empty>Không có NPL phù hợp.</template>
      <template #index-cell="{ row }">
        {{ row.index + 1 }}
      </template>

      <template #articleCode-cell="{ row }">
        {{ row.original.articleCode || '-' }}
      </template>

      <template #alternativeName-cell="{ row }">
        <div @click.stop class="min-w-44">
          <UInput
            v-if="!readonly && canEditMaterialState && editingMaterialState"
            :model-value="row.original.alternativeName ?? undefined"
            class="w-full"
            @update:model-value="updateAlternativeName(row.original, $event)"
            @change="emit('update:altName', row.original.id, row.original.alternativeName || '')"
          />
          <span
            v-else
            class="block w-full truncate"
            :title="row.original.alternativeName ?? undefined"
          >
            {{ row.original.alternativeName || '-' }}
          </span>
        </div>
      </template>

      <template #isRequired-cell="{ row }">
        <div @click.stop class="flex items-center">
          <UCheckbox
            v-if="!readonly && canEditMaterialState && editingMaterialState"
            :model-value="row.original.isRequired"
            @update:model-value="emit('update:required', row.original.id, $event === true)"
          />
          <UBadge
            v-else
            :label="row.original.isRequired !== false ? 'Bắt buộc' : 'Không bắt buộc'"
            :color="row.original.isRequired !== false ? 'neutral' : 'warning'"
            variant="subtle"
          />
        </div>
      </template>

      <template #sizes-cell="{ row }">
        <UBadge
          v-if="row.original.sizes?.length"
          :label="`${row.original.sizes.length} cỡ`"
          color="info"
        />
        <span v-else class="text-xs text-toned">-</span>
      </template>

      <template #colors-cell="{ row }">
        <UBadge
          v-if="row.original.colors?.length"
          :label="`${row.original.colors.length} màu`"
          color="success"
        />
        <UBadge v-else label="Tất cả màu" color="neutral" />
      </template>

      <template #operations-cell="{ row }">
        <div v-if="row.original.operations?.length" class="flex flex-wrap gap-1">
          <UBadge
            v-for="op in row.original.operations"
            :key="op"
            :label="op"
            color="info"
            class="text-xs"
          />
        </div>
        <UBadge v-else label="Tất cả" color="neutral" />
      </template>

      <template #destinations-cell="{ row }">
        <div v-if="row.original.destinationCodes?.length" class="flex flex-wrap gap-1">
          <UBadge
            v-for="code in row.original.destinationCodes"
            :key="code"
            :label="code"
            color="warning"
            class="text-xs"
          />
        </div>
        <UBadge v-else label="Tất cả" color="neutral" />
      </template>

      <!-- Expanded detail row -->
      <template #expanded="{ row }">
        <div class="grid grid-cols-1 gap-4 bg-surface-50 p-4 lg:grid-cols-2" @click.stop>
          <BomSizeTable
            :state="getVisibleState(row.original)"
            :uom="row.original.uom"
            :can-edit="!readonly && !!editStates && !!canEdit"
            :readonly="readonly || !editStates || (showBomEdit && !editingBom)"
            :is-cutting="isCutting"
            @cell-edit="(data, val) => emit('cellEditSize', row.original.id, data, val)"
            @apply-first="emit('applyFirst', row.original.id, 'sizes')"
          />
          <BomColorTable
            :state="getVisibleState(row.original)"
            :uom="row.original.uom"
            :can-edit="!readonly && !!editStates && !!(canEditColor ?? canEdit)"
            :can-edit-cutting="!readonly && !!editStates && !!canEditCutting"
            :is-cutting="!!isCutting"
            :readonly="readonly || !editStates || (showBomEdit && !editingBom)"
            @cell-edit="
              (data, field, val) => emit('cellEditColor', row.original.id, data, field, val)
            "
            @apply-first="emit('applyFirst', row.original.id, 'colors')"
          />
          <div
            v-if="row.original.lastUpdatedAt"
            class="col-span-full flex items-center gap-1 text-xs text-toned"
          >
            <UIcon name="i-lucide-clock" />
            Cập nhật lúc {{ fmtDate(row.original.lastUpdatedAt) }}
            <span v-if="row.original.lastUpdatedBy">
              bởi
              <span class="font-medium text-default">
                {{ row.original.lastUpdatedBy.name }}
              </span>
            </span>
          </div>
        </div>
      </template>
    </UTable>
  </div>
</template>
