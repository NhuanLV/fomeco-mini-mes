<script setup lang="ts">
import { CalendarDate, type DateValue } from '@internationalized/date'
import { computed, shallowRef } from 'vue'

type DateModel = Date | Date[] | (Date | null)[] | null | undefined
type DateRange = { start: DateValue | undefined; end: DateValue | undefined }
type CalendarModel = DateValue | DateRange | DateValue[] | null | undefined

const props = defineProps<{
  modelValue?: DateModel
  selectionMode?: 'single' | 'range'
  placeholder?: string
  disabled?: boolean
  variant?: 'outline' | 'subtle'
  inputClass?: string
  id?: string
  autofocus?: boolean
  minDate?: Date | null
  maxDate?: Date | null
  isDateDisabled?: (date: DateValue) => boolean
  isDateUnavailable?: (date: DateValue) => boolean
}>()

const emit = defineEmits<{
  'update:modelValue': [value: DateModel]
  'date-select': [value: Date | null]
  hide: []
}>()

const open = shallowRef(false)
const isRange = computed(() => props.selectionMode === 'range')

const toCalendarDate = (value: Date | null | undefined) =>
  value instanceof Date && !Number.isNaN(value.getTime())
    ? new CalendarDate(value.getFullYear(), value.getMonth() + 1, value.getDate())
    : undefined

const toDate = (value: DateValue | undefined) =>
  value ? new Date(value.year, value.month - 1, value.day) : null

const minCalendarDate = computed(() => toCalendarDate(props.minDate))
const maxCalendarDate = computed(() => toCalendarDate(props.maxDate))

const singleValue = computed(() =>
  toCalendarDate(Array.isArray(props.modelValue) ? undefined : props.modelValue),
)

const rangeValue = computed<DateRange | null>(() => {
  const values = Array.isArray(props.modelValue) ? props.modelValue : []
  const start = toCalendarDate(values[0])
  const end = toCalendarDate(values[1])
  return start || end ? { start, end } : null
})

const effectiveIsDateDisabled = computed(() => {
  if (props.isDateDisabled) return props.isDateDisabled
  if (!props.minDate) return undefined
  const min = props.minDate
  const minDay = new Date(min.getFullYear(), min.getMonth(), min.getDate()).getTime()
  return (date: DateValue) => {
    const d = new Date(date.year, date.month - 1, date.day).getTime()
    return d < minDay
  }
})

const calendarUi = {
  cellTrigger:
    'data-disabled:text-neutral-400 dark:data-disabled:text-neutral-600 data-disabled:opacity-40 data-disabled:cursor-not-allowed data-disabled:pointer-events-none data-unavailable:text-neutral-400 data-unavailable:opacity-40 data-unavailable:cursor-not-allowed data-unavailable:pointer-events-none',
}

function updateSingle(value: CalendarModel) {
  const date =
    value && !Array.isArray(value) && 'year' in value && !('start' in value) ? toDate(value) : null
  emit('update:modelValue', date)
}

function selectSingle(value: CalendarModel) {
  const date =
    value && !Array.isArray(value) && 'year' in value && !('start' in value) ? toDate(value) : null
  emit('update:modelValue', date)
  emit('date-select', date)
  open.value = false
}

function updateRange(value: DateRange | null | undefined) {
  emit(
    'update:modelValue',
    value?.start || value?.end ? [toDate(value.start), toDate(value.end)] : null,
  )
}

function finishRange(value: DateRange) {
  updateRange(value)
  open.value = false
}

function show() {
  if (!props.disabled) open.value = true
}

function updateOpen(value: boolean) {
  if (props.disabled) return
  const wasOpen = open.value
  open.value = value
  if (wasOpen && !value) emit('hide')
}

defineExpose({ show })
</script>

<template>
  <div class="flex items-center">
    <UPopover
      :open="open"
      :content="{ align: 'start', side: 'bottom', sideOffset: 4 }"
      :ui="{ content: 'p-2' }"
      @update:open="updateOpen"
    >
      <div class="flex w-full items-center gap-1">
        <UInputDate
          v-if="isRange"
          range
          :id
          :model-value="rangeValue"
          :disabled
          :variant
          :autofocus
          locale="vi-VN"
          :aria-label="placeholder"
          :class="['min-w-0 flex-1', inputClass]"
          @update:model-value="updateRange"
        />
        <UInputDate
          v-else
          :id
          :model-value="singleValue"
          :disabled
          :variant
          :autofocus
          locale="vi-VN"
          :aria-label="placeholder"
          :class="['min-w-0 flex-1', inputClass]"
          @update:model-value="updateSingle"
          @keydown.enter="selectSingle(singleValue)"
        />
        <slot name="inputicon">
          <UButton
            icon="i-lucide-calendar"
            color="neutral"
            variant="ghost"
            :disabled
            :aria-label="placeholder || 'Chọn ngày'"
          />
        </slot>
      </div>

      <template #content>
        <div @mousedown.stop @pointerdown.stop>
          <UCalendar
            v-if="isRange"
            range
            :model-value="rangeValue"
            :min-value="minCalendarDate"
            :max-value="maxCalendarDate"
            :is-date-disabled="effectiveIsDateDisabled"
            :is-date-unavailable="isDateUnavailable"
            :ui="calendarUi"
            locale="vi-VN"
            :disabled
            @update:model-value="updateRange"
            @update:valid-model-value="finishRange"
          />
          <UCalendar
            v-else
            :model-value="singleValue"
            :min-value="minCalendarDate"
            :max-value="maxCalendarDate"
            :is-date-disabled="effectiveIsDateDisabled"
            :is-date-unavailable="isDateUnavailable"
            :ui="calendarUi"
            locale="vi-VN"
            :disabled
            @update:model-value="selectSingle"
          />
        </div>
      </template>
    </UPopover>
  </div>
</template>
