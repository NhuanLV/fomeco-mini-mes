import type {
  AdditionalData,
  ColumnDataSchemaModel,
  ColumnRegular,
  ColumnTypes,
} from '@revolist/vue3-datagrid'
import { VGridVueEditor, VGridVueTemplate } from '@revolist/vue3-datagrid'
import type { Component } from 'vue'

export type MatrixGridRow = Record<string, unknown>
export type MatrixGridColumn = ColumnRegular & { extraWidth?: number }
export type MatrixGridColumnTypes = ColumnTypes
export type MatrixGridAdditionalData = AdditionalData
export type MatrixGridCellProps = ColumnDataSchemaModel

export interface MatrixGridEdit {
  rowIndex: number
  prop: string
  value: unknown
}

export interface MatrixGridBeforeEdit extends MatrixGridEdit {
  row?: MatrixGridRow
  preventDefault: () => void
}

export const matrixGridCell = (component: Component) => VGridVueTemplate(component)
export const matrixGridEditor = (component: Component) => VGridVueEditor(component)

export function normalizeMatrixGridEdits(detail: Record<string, unknown>): MatrixGridEdit[] {
  if (typeof detail.rowIndex === 'number' && typeof detail.prop === 'string') {
    return [{ rowIndex: detail.rowIndex, prop: detail.prop, value: detail.val }]
  }

  if (!detail.data || typeof detail.data !== 'object' || Array.isArray(detail.data)) return []

  return Object.entries(detail.data).flatMap(([rowIndex, values]) =>
    values && typeof values === 'object' && !Array.isArray(values)
      ? Object.entries(values).map(([prop, value]) => ({
          rowIndex: Number(rowIndex),
          prop,
          value,
        }))
      : [],
  )
}

export function normalizeMatrixGridBeforeEdit(event: {
  detail: Record<string, unknown>
  preventDefault: () => void
}): MatrixGridBeforeEdit {
  return {
    rowIndex: Number(event.detail.rowIndex),
    prop: String(event.detail.prop),
    value: event.detail.val,
    row: event.detail.model as MatrixGridRow | undefined,
    preventDefault: () => event.preventDefault(),
  }
}
