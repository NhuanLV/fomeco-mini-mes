import {
  normalizeMatrixGridBeforeEdit,
  normalizeMatrixGridEdits,
} from '@/shared/components/grid/matrixGrid'
import { describe, expect, it, vi } from 'vitest'

describe('matrixGrid adapter', () => {
  it('normalizes a single-cell edit', () => {
    expect(
      normalizeMatrixGridEdits({
        rowIndex: 2,
        prop: 'quantity',
        val: 12,
      }),
    ).toEqual([{ rowIndex: 2, prop: 'quantity', value: 12 }])
  })

  it('normalizes a range edit in stable row/property order', () => {
    expect(
      normalizeMatrixGridEdits({
        data: {
          0: { quantity: 2, note: 'A' },
          3: { quantity: 7 },
        },
      }),
    ).toEqual([
      { rowIndex: 0, prop: 'quantity', value: 2 },
      { rowIndex: 0, prop: 'note', value: 'A' },
      { rowIndex: 3, prop: 'quantity', value: 7 },
    ])
  })

  it('ignores unsupported edit payloads', () => {
    expect(normalizeMatrixGridEdits({})).toEqual([])
    expect(normalizeMatrixGridEdits({ data: null })).toEqual([])
  })

  it('normalizes before-edit data and delegates cancellation', () => {
    const preventDefault = vi.fn()
    const row = { id: 'row-1', quantity: 2 }
    const edit = normalizeMatrixGridBeforeEdit({
      detail: {
        rowIndex: 1,
        prop: 'quantity',
        val: 3,
        model: row,
      },
      preventDefault,
    })

    expect(edit).toMatchObject({
      rowIndex: 1,
      prop: 'quantity',
      value: 3,
      row,
    })
    edit.preventDefault()
    expect(preventDefault).toHaveBeenCalledOnce()
  })
})
