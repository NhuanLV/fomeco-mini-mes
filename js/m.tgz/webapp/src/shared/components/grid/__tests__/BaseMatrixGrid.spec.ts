import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import { mount } from '@vue/test-utils'
import { nextTick } from 'vue'
import { describe, expect, it, vi } from 'vitest'

vi.mock('@revolist/vue3-datagrid', () => ({
  default: {
    name: 'RevoGrid',
    inheritAttrs: false,
    emits: ['afteredit', 'beforeedit'],
    template: '<div data-testid="revo-grid" />',
  },
  VGridVueEditor: vi.fn((component) => component),
  VGridVueTemplate: vi.fn((component) => component),
}))

describe('BaseMatrixGrid', () => {
  it('emits normalized after edits instead of the vendor event', async () => {
    const wrapper = mountGrid()

    wrapper.findComponent({ name: 'RevoGrid' }).vm.$emit('afteredit', {
      detail: {
        data: {
          0: { quantity: 2 },
          1: { quantity: 3 },
        },
      },
    })
    await nextTick()

    expect(wrapper.emitted('afteredit')).toEqual([
      [
        [
          { rowIndex: 0, prop: 'quantity', value: 2 },
          { rowIndex: 1, prop: 'quantity', value: 3 },
        ],
      ],
    ])
  })

  it('emits cancellable normalized before edits', async () => {
    const wrapper = mountGrid()
    const preventDefault = vi.fn()

    wrapper.findComponent({ name: 'RevoGrid' }).vm.$emit('beforeedit', {
      detail: {
        rowIndex: 0,
        prop: 'quantity',
        val: 4,
        model: { id: 'row-1', quantity: 2 },
      },
      preventDefault,
    })
    await nextTick()

    const edit = wrapper.emitted('beforeedit')?.[0]?.[0] as {
      preventDefault: () => void
    }
    edit.preventDefault()
    expect(preventDefault).toHaveBeenCalledOnce()
  })
})

function mountGrid() {
  return mount(BaseMatrixGrid, {
    props: {
      source: [{ id: 'row-1', quantity: 2 }],
      columns: [{ prop: 'quantity', name: 'Số lượng' }],
    },
  })
}
