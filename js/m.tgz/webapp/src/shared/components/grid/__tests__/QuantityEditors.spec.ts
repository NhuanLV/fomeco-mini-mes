import KanbanQtyEditor from '@/features/kanban/components/create/KanbanQtyEditor.vue'
import KanbanPrepareEditor from '@/features/kanban/components/grid/KanbanPrepareEditor.vue'
import KanbanReviseQtyEditor from '@/features/kanban/components/grid/KanbanReviseQtyEditor.vue'
import MatrixQtyEditor from '@/shared/components/grid/MatrixQtyEditor.vue'
import { mount } from '@vue/test-utils'
import { afterEach, describe, expect, it, vi } from 'vitest'

describe('RevoGrid quantity editors', () => {
  afterEach(() => vi.useRealTimers())

  it.each([
    ['create Kanban', KanbanQtyEditor],
    ['prepare Kanban', KanbanPrepareEditor],
    ['revise Kanban', KanbanReviseQtyEditor],
    ['adjust PO', MatrixQtyEditor],
  ] as const)('keeps the opening digit and subsequent digits in %s', async (_name, editor) => {
    vi.useFakeTimers()
    const save = vi.fn()
    const wrapper = mount(editor, {
      props: { val: '1', save, close: vi.fn() },
      global: {
        stubs: {
          UInput: {
            props: ['modelValue'],
            emits: ['update:modelValue'],
            template:
              '<div><input :value="modelValue" @input="$emit(\'update:modelValue\', $event.target.value)" /></div>',
          },
        },
      },
    })

    const input = wrapper.get('input')
    expect(input.element.value).toBe('1')
    input.element.setSelectionRange(1, 1)
    await vi.runAllTimersAsync()
    input.element.setRangeText(
      '2',
      input.element.selectionStart!,
      input.element.selectionEnd!,
      'end',
    )
    await input.trigger('input')
    await input.trigger('keydown', { key: 'Enter' })
    expect(save).toHaveBeenCalledWith(12, true)
    wrapper.unmount()
  })
})
