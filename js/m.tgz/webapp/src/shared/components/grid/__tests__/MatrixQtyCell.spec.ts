import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'

describe('MatrixQtyCell', () => {
  const createProps = (prop: string, model: Record<string, unknown>): MatrixGridCellProps =>
    ({
      prop,
      model,
      rowIndex: 0,
      colIndex: 0,
    }) as unknown as MatrixGridCellProps

  it('renders "-" when row is parent row', () => {
    const wrapper = mount(MatrixQtyCell, {
      props: createProps('M', { rowKind: 'parent', M: { current: 10, limit: 20 } }),
    })
    expect(wrapper.text()).toBe('-')
    expect(wrapper.find('.absolute').exists()).toBe(false)
  })

  it('renders "-" when both current and limit are 0', () => {
    const wrapper = mount(MatrixQtyCell, {
      props: createProps('M', { M: { current: 0, limit: 0 } }),
    })
    expect(wrapper.text()).toBe('-')
    expect(wrapper.find('.absolute').exists()).toBe(false)
  })

  it('renders centered current and top-right limit when object has current and limit', () => {
    const wrapper = mount(MatrixQtyCell, {
      props: createProps('M', { M: { current: 50, limit: 100 } }),
    })
    const limitBadge = wrapper.find('.absolute')
    expect(limitBadge.exists()).toBe(true)
    expect(limitBadge.text()).toBe('100')
    expect(wrapper.text()).toContain('50')
  })

  it('renders green font when current equals limit (> 0)', () => {
    const wrapper = mount(MatrixQtyCell, {
      props: createProps('M', { M: { current: 100, limit: 100 } }),
    })
    expect(wrapper.find('.text-green-700').exists()).toBe(true)
    expect(wrapper.find('.absolute').text()).toBe('100')
  })

  it('renders red font when current exceeds limit', () => {
    const wrapper = mount(MatrixQtyCell, {
      props: createProps('M', { M: { current: 120, limit: 100 } }),
    })
    expect(wrapper.find('.text-red-600').exists()).toBe(true)
    expect(wrapper.find('.absolute').text()).toBe('100')
  })

  it('reads limit from [prop]_demand when not present in cell object', () => {
    const wrapper = mount(MatrixQtyCell, {
      props: createProps('L', { L: 30, L_demand: 80 }),
    })
    expect(wrapper.find('.absolute').text()).toBe('80')
    expect(wrapper.text()).toContain('30')
  })

  it('renders stockQty without limit badge', () => {
    const wrapper = mount(MatrixQtyCell, {
      props: createProps('stockQty', { stockQty: 500, stockQty_demand: 1000 }),
    })
    expect(wrapper.find('.absolute').exists()).toBe(false)
    expect(wrapper.text()).toBe('500')
  })

  it('renders "-" when limit is null and current is 0', () => {
    const wrapper = mount(MatrixQtyCell, {
      props: createProps('S', { S: 0 }),
    })
    expect(wrapper.text()).toBe('-')
    expect(wrapper.find('.absolute').exists()).toBe(false)
  })
})
