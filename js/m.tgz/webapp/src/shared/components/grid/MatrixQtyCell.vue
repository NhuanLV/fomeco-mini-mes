<script setup lang="ts">
import { fmtQty } from '@/shared/utils/fmtQty'
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { computed } from 'vue'

const props = defineProps<MatrixGridCellProps>()

// prop là tên cột (size hoặc extra field), model là dữ liệu hàng của RevoGrid.
const data = computed(() => props.model?.[props.prop as string])

const current = computed(() => {
  if (typeof data.value === 'object' && data.value !== null) {
    const val = Number((data.value as { current?: unknown }).current)
    return Number.isFinite(val) ? val : 0
  }
  if (typeof data.value === 'string') {
    const [currentPart] = data.value.split('/')
    const val = Number(currentPart?.replace(/,/g, '').trim())
    return Number.isFinite(val) ? val : 0
  }
  const val = Number(data.value)
  return Number.isFinite(val) ? val : 0
})

const limit = computed(() => {
  if (typeof data.value === 'object' && data.value !== null && 'limit' in data.value) {
    const lim = (data.value as { limit?: unknown }).limit
    return lim === undefined || lim === null ? null : Number(lim)
  }
  // Check for demand key (for AllocationSizeCell compatibility)
  const demandKey = `${String(props.prop)}_demand`
  const demandVal = props.model?.[demandKey]
  return demandVal === undefined || demandVal === null ? null : Number(demandVal)
})

const isParentRow = computed(() => !props.model || props.model.rowKind === 'parent')

const currentDisplay = computed(() => {
  if (isParentRow.value) return '-'

  if (String(props.prop) === 'stockQty') {
    return fmtQty(current.value)
  }

  if (
    String(props.prop) === 'requiredQty' &&
    props.model?.isEdited === true &&
    current.value === 0
  ) {
    return '0'
  }

  if (limit.value === null) {
    return current.value > 0 ? fmtQty(current.value) : '-'
  }

  if (limit.value === 0 && current.value === 0) {
    return '-'
  }

  return fmtQty(current.value)
})

const limitDisplay = computed(() => {
  if (isParentRow.value || String(props.prop) === 'stockQty') return null
  if (limit.value === null) return null
  if (limit.value === 0 && current.value === 0) return null
  return fmtQty(limit.value)
})

const colorClass = computed(() => {
  if (limit.value === null) return ''
  if (current.value > limit.value) return 'text-red-600 font-semibold'
  if (current.value === limit.value && current.value > 0) return 'text-green-700 font-semibold'
  return ''
})
</script>

<template>
  <div class="relative flex h-full w-full items-center justify-center px-1">
    <span
      v-if="limitDisplay"
      class="pointer-events-none absolute top-0.5 right-1 font-mono text-xs leading-none text-toned opacity-70 select-none"
    >
      {{ limitDisplay }}
    </span>
    <span :class="['font-mono font-semibold', colorClass || 'text-highlighted']">
      {{ currentDisplay }}
    </span>
  </div>
</template>
