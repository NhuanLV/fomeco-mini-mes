<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { rejectComma } from '@/shared/utils/numberInput'

const props = defineProps<{
  val: unknown
  model?: Record<string, unknown>
  save: (val: number | null, preventFocus?: boolean) => void
  close: (isCancel?: boolean) => void
}>()

const inputRef = ref<{ $el?: HTMLElement } | null>(null)
const isClosing = ref(false)

const initialValue = computed(() => {
  if (typeof props.val === 'object' && props.val !== null && 'current' in props.val) {
    return Number((props.val as { current: unknown }).current) || 0
  }
  return Number(props.val) || 0
})

const qtyValue = ref<number | null>(initialValue.value)

function handleSave(focusNext = false) {
  if (isClosing.value) return
  isClosing.value = true
  props.save(qtyValue.value, true)
  props.close(focusNext)
}

function handleCancel() {
  if (isClosing.value) return
  isClosing.value = true
  props.close(true)
}

function handleKeyDown(event: KeyboardEvent) {
  if (event.key === 'Enter') {
    event.preventDefault()
    event.stopPropagation()
    handleSave(true)
    return
  }

  if (event.key === 'Escape') {
    event.preventDefault()
    event.stopPropagation()
    handleCancel()
  }
}

onMounted(() => {
  if (props.model?.isTotalBySize) {
    props.close(true)
    return
  }
  setTimeout(() => {
    const input = (inputRef.value as unknown as { $el: HTMLElement } | null)?.$el?.querySelector(
      'input',
    )
    input?.focus()
  }, 50)
})
</script>

<template>
  <div class="flex h-full w-full items-center bg-white px-1">
    <UInput
      ref="inputRef"
      v-model.number="qtyValue"
      type="text"
      inputmode="numeric"
      autofocus
      class="h-8 w-full border-none bg-transparent shadow-none"
      min="0"
      step="1"
      @keydown="handleKeyDown"
      @blur="handleSave()"
      @beforeinput="rejectComma"
    />
  </div>
</template>
