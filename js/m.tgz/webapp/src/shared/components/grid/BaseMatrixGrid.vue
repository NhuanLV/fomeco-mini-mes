<script setup lang="ts">
import {
  normalizeMatrixGridBeforeEdit,
  normalizeMatrixGridEdits,
  type MatrixGridAdditionalData,
  type MatrixGridBeforeEdit,
  type MatrixGridColumn,
  type MatrixGridColumnTypes,
  type MatrixGridEdit,
  type MatrixGridRow,
} from '@/shared/components/grid/matrixGrid'
import { useGridLayout } from '@/shared/composables/useGridLayout'
import { ROW_HEIGHT } from '@/shared/utils/colorSizeMatrix'
import type { AfterEditEvent, BeforeEdit, RevoGridCustomEvent } from '@revolist/vue3-datagrid'
import RevoGrid from '@revolist/vue3-datagrid'
import { computed, toRef } from 'vue'

interface Props {
  source: MatrixGridRow[]
  columns: MatrixGridColumn[]
  columnTypes?: MatrixGridColumnTypes
  rowSize?: number
  theme?: string
  readonly?: boolean
  additionalData?: MatrixGridAdditionalData
  displayRows?: (rows: MatrixGridRow[]) => MatrixGridRow[]
}

const props = withDefaults(defineProps<Props>(), {
  rowSize: ROW_HEIGHT,
  theme: 'material',
  readonly: false,
  columnTypes: () => ({}),
  additionalData: () => ({}),
  displayRows: (rows: MatrixGridRow[]) => rows,
})

const emit = defineEmits<{
  afteredit: [edits: MatrixGridEdit[]]
  beforeedit: [edit: MatrixGridBeforeEdit]
}>()

const { wrapperRef, gridColumns, tableHeight } = useGridLayout({
  rows: toRef(props, 'source'),
  columns: toRef(props, 'columns'),
  displayRows: props.displayRows,
})

const revoGridProps = computed(() => ({
  source: props.source,
  columns: gridColumns.value,
  theme: props.theme,
  columnTypes: props.columnTypes,
  rowSize: props.rowSize,
  stretch: true,
  resize: true,
  range: true,
  hideAttribution: true,
  additionalData: props.additionalData,
}))

function handleAfterEdit(event: RevoGridCustomEvent<AfterEditEvent>) {
  emit('afteredit', normalizeMatrixGridEdits(event.detail as unknown as Record<string, unknown>))
}

function handleBeforeEdit(event: RevoGridCustomEvent<BeforeEdit>) {
  const detail = event.detail as unknown as Record<string, unknown>
  const model = (detail?.model ?? detail?.row) as Record<string, unknown> | undefined
  if (model?.isTotalBySize) {
    event.preventDefault()
  }
  emit(
    'beforeedit',
    normalizeMatrixGridBeforeEdit({
      detail,
      preventDefault: () => event.preventDefault(),
    }),
  )
}
</script>

<template>
  <div ref="wrapperRef" :style="{ height: tableHeight + 'px' }" class="w-full overflow-x-auto">
    <RevoGrid
      class="max-h-screen! min-h-full!"
      v-bind="revoGridProps"
      @afteredit="handleAfterEdit"
      @beforeedit="handleBeforeEdit"
    />
  </div>
</template>
