<script setup lang="ts">
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { computed } from 'vue'

const props = defineProps<MatrixGridCellProps>()

const isTotalRow = computed(() => Boolean(props.model?.isTotalBySize))
const colorText = computed(() => String(props.model?.color ?? ''))
</script>

<template>
  <div
    :class="[
      'flex h-full w-full items-center px-2',
      isTotalRow ? 'justify-end text-right font-bold text-default' : 'justify-start text-left',
    ]"
  >
    <span>{{ colorText }}</span>
  </div>
</template>
