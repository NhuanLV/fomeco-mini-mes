<script setup lang="ts">
import { onMounted, ref, useTemplateRef } from 'vue'

const props = defineProps<{
  value: string | null | undefined
  save: (val: string, preventFocus?: boolean) => void
  close: (isCancel?: boolean) => void
}>()

const noteValue = ref(props.value ?? '')
const inputRef = useTemplateRef<{ $el?: HTMLElement }>('inputRef')

function handleSave() {
  props.save(noteValue.value, true)
  props.close()
}

function handleCancel() {
  props.close(true)
}

function handleKeyDown(event: KeyboardEvent) {
  if (event.key === 'Escape') {
    event.stopPropagation()
    handleCancel()
  } else if (event.key === 'Enter' && event.ctrlKey) {
    event.preventDefault()
    event.stopPropagation()
    handleSave()
  } else if (event.key === 'Enter') {
    event.stopPropagation()
  }
}

onMounted(() => {
  setTimeout(() => {
    const el = inputRef.value as unknown as { $el?: HTMLElement }
    const textarea = el?.$el?.querySelector('textarea')
    textarea?.focus()
  }, 10)
})
</script>

<template>
  <div class="flex h-full w-full items-start bg-white px-1 py-1">
    <UTextarea
      ref="inputRef"
      v-model="noteValue"
      autoresize
      :rows="3"
      class="w-full resize-none border-none bg-transparent p-1 text-[13px] shadow-none focus:ring-0"
      placeholder="Nhập ghi chú..."
      @blur="handleSave"
      @keydown="handleKeyDown"
    />
  </div>
</template>
