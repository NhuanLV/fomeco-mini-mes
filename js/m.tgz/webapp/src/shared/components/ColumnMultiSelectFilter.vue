<script setup lang="ts">
import { computed } from 'vue'

export type SelectOption = {
  label: string
  value: string
}

const props = withDefaults(
  defineProps<{
    modelValue: string[]
    items: SelectOption[]
    placeholder: string
    searchPlaceholder?: string
  }>(),
  {
    searchPlaceholder: 'Tìm kiếm...',
  },
)

const emit = defineEmits<{
  (e: 'update:modelValue', value: string[]): void
}>()

const isFiltered = computed(() => props.modelValue && props.modelValue.length > 0)

const selectPt = {
  base: 'min-w-0! w-full! cursor-pointer px-4! py-3.5! border-0! bg-transparent! shadow-none! ring-0!',
  value: 'text-highlighted! p-0! pr-1! text-sm! font-semibold!',
  placeholder: 'text-highlighted! text-sm! font-semibold!',
  trailing: 'ms-2! pe-0!',
  content: 'w-72!',
  viewport: '[scrollbar-width:none] [&::-webkit-scrollbar]:hidden',
}

const selectPtActive = {
  base: 'min-w-0! w-full! cursor-pointer px-4! py-3.5! border-0! bg-transparent! shadow-none! ring-0!',
  value: 'text-primary! p-0! pr-1! text-sm! font-semibold!',
  placeholder: 'text-primary! text-sm! font-semibold!',
  trailing: 'ms-2! pe-0!',
  content: 'w-72!',
  viewport: '[scrollbar-width:none] [&::-webkit-scrollbar]:hidden',
}

function onChange(val: string[] | null) {
  emit('update:modelValue', val ?? [])
}
</script>

<template>
  <USelectMenu
    :model-value="modelValue"
    :items="items"
    label-key="label"
    value-key="value"
    multiple
    :placeholder="placeholder"
    :search-input="{ placeholder: searchPlaceholder || `Tìm ${placeholder.toLowerCase()}...` }"
    clear
    :ui="isFiltered ? selectPtActive : selectPt"
    @update:model-value="onChange"
  >
    <template #default>
      <span
        class="text-sm font-semibold"
        :class="isFiltered ? 'text-primary!' : 'text-highlighted!'"
      >
        {{ placeholder }}
        <template v-if="isFiltered"> ({{ modelValue.length }}) </template>
      </span>
    </template>
  </USelectMenu>
</template>
