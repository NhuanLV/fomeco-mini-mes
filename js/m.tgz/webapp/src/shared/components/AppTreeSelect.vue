<script setup lang="ts">
import { computed } from 'vue'

type TreeNode = {
  key: string
  label: string
  children?: TreeNode[]
}

const props = defineProps<{
  modelValue: Record<string, boolean> | null
  options: TreeNode[]
  placeholder?: string
  disabled?: boolean
}>()

const emit = defineEmits<{
  'update:modelValue': [value: Record<string, boolean> | null]
}>()

const items = computed(() => {
  const flattened: Array<{ label: string; value: string }> = []
  const visit = (nodes: TreeNode[], depth = 0) => {
    nodes.forEach((node) => {
      flattened.push({ label: `${'— '.repeat(depth)}${node.label}`, value: node.key })
      visit(node.children ?? [], depth + 1)
    })
  }
  visit(props.options)
  return flattened
})

const selectedKey = computed(() => Object.keys(props.modelValue ?? {})[0] ?? null)

function update(value: string | null) {
  emit('update:modelValue', value ? { [value]: true } : null)
}
</script>

<template>
  <USelectMenu
    :model-value="selectedKey"
    :items
    label-key="label"
    value-key="value"
    :placeholder
    :disabled
    clear
    @update:model-value="update"
  />
</template>
