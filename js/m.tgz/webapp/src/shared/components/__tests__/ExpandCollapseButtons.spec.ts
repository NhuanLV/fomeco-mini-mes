import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import ExpandCollapseButtons from '../ExpandCollapseButtons.vue'

describe('ExpandCollapseButtons', () => {
  it('renders expand and collapse buttons', () => {
    const wrapper = mount(ExpandCollapseButtons)

    expect(wrapper.text()).toContain('Mở rộng')
    expect(wrapper.text()).toContain('Thu gọn')
  })

  it('emits expandAll event when clicking expand button', async () => {
    const wrapper = mount(ExpandCollapseButtons)
    const buttons = wrapper.findAllComponents({ name: 'Button' })

    const expandBtn = buttons.find((b) => b.props('label') === 'Mở rộng')
    expect(expandBtn).toBeDefined()
    await expandBtn?.trigger('click')

    expect(wrapper.emitted('expandAll')).toBeTruthy()
  })

  it('emits collapseAll event when clicking collapse button', async () => {
    const wrapper = mount(ExpandCollapseButtons)
    const buttons = wrapper.findAllComponents({ name: 'Button' })

    const collapseBtn = buttons.find((b) => b.props('label') === 'Thu gọn')
    expect(collapseBtn).toBeDefined()
    await collapseBtn?.trigger('click')

    expect(wrapper.emitted('collapseAll')).toBeTruthy()
  })
})
