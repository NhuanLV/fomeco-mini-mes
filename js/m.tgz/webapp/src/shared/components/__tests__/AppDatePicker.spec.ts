import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import AppDatePicker from '../AppDatePicker.vue'

describe('AppDatePicker', () => {
  it('opens the themed popover instead of a hidden native date picker', async () => {
    const wrapper = mount(AppDatePicker, {
      props: { inputClass: 'hidden' },
    })
    const popover = wrapper.findComponent({ name: 'Popover' })

    expect(popover.props('open')).toBe(false)

    wrapper.vm.show()
    await wrapper.vm.$nextTick()

    expect(popover.props('open')).toBe(true)
  })

  it('keeps popover open on input date update and closes on calendar date select', async () => {
    const wrapper = mount(AppDatePicker, {
      props: { modelValue: new Date(2026, 7, 19) },
    })
    wrapper.vm.show()
    await wrapper.vm.$nextTick()

    const popover = wrapper.findComponent({ name: 'Popover' })
    expect(popover.props('open')).toBe(true)

    // Simulating input date update without closing
    const inputDate = wrapper.findComponent({ name: 'InputDate' })
    if (inputDate.exists()) {
      await inputDate.vm.$emit('update:modelValue', { year: 2026, month: 8, day: 20 })
      expect(wrapper.emitted('update:modelValue')).toBeDefined()
      expect(popover.props('open')).toBe(true)
    }

    // Simulating calendar date selection which should close
    const calendar = wrapper.findComponent({ name: 'Calendar' })
    if (calendar.exists()) {
      await calendar.vm.$emit('update:modelValue', { year: 2026, month: 8, day: 25 })
      expect(wrapper.emitted('date-select')).toBeDefined()
      expect(popover.props('open')).toBe(false)
    }
  })
})
