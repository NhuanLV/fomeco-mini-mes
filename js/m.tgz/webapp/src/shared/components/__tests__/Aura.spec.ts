import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import Aura from '../Aura.vue'

describe('Aura', () => {
  it('renders with default props (variant=dual)', () => {
    const wrapper = mount(Aura, {
      slots: {
        default: '<button>Click me</button>',
      },
    })

    expect(wrapper.classes()).toContain('aura')
    expect(wrapper.classes()).toContain('aura-dual')
    expect(wrapper.find('button').text()).toBe('Click me')
  })

  it('renders default variant without aura-dual class', () => {
    const wrapper = mount(Aura, {
      props: {
        variant: 'default',
      },
    })

    expect(wrapper.classes()).toContain('aura')
    expect(wrapper.classes()).not.toContain('aura-dual')
  })

  it('renders custom tag when as prop is provided', () => {
    const wrapper = mount(Aura, {
      props: {
        as: 'span',
      },
    })

    expect(wrapper.element.tagName.toLowerCase()).toBe('span')
  })

  it('does not apply aura classes when disabled', () => {
    const wrapper = mount(Aura, {
      props: {
        disabled: true,
      },
    })

    expect(wrapper.classes()).not.toContain('aura')
    expect(wrapper.classes()).not.toContain('aura-dual')
  })
})
