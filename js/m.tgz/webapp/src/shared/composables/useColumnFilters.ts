import { computed, reactive } from 'vue'

type FilterColumn<T> = {
  label: string
  values: (row: T) => (string | null | undefined)[]
  preserveOrder?: boolean
  options?: string[]
  includeEmpty?: boolean
  emptyLabel?: string
  unrestricted?: boolean
}

export function useColumnFilters<T>(rows: () => T[], columns: Record<string, FilterColumn<T>>) {
  const filters = reactive<Record<string, string[]>>(
    Object.fromEntries(Object.keys(columns).map((key) => [key, []])),
  )
  function values(row: T, column: FilterColumn<T>) {
    const result = column.values(row).map((value) => value ?? '')
    return result.length ? result : ['']
  }
  const options = computed(() =>
    Object.fromEntries(
      Object.entries(columns).map(([key, column]) => {
        const optionValues = [
          ...new Set(column.options ?? rows().flatMap((row) => values(row, column))),
        ].filter((value) => column.includeEmpty !== false || value.trim().length > 0)
        if (!column.preserveOrder) optionValues.sort((a, b) => a.localeCompare(b, 'vi'))
        return [
          key,
          optionValues.map((value) => ({
            label: value || column.emptyLabel || 'Chưa có giá trị',
            // SelectMenu reserves the empty string for clearing selection.
            value: JSON.stringify(value),
          })),
        ]
      }),
    ),
  )
  const filteredRows = computed(() =>
    rows().filter((row) =>
      Object.entries(columns).every(([key, column]) => {
        const selected = filters[key]!
        if (!selected.length) return true
        const actual = values(row, column)
        return (
          actual.some((value) => selected.includes(JSON.stringify(value))) ||
          (column.unrestricted && actual.includes(''))
        )
      }),
    ),
  )
  function clearFilters() {
    for (const key of Object.keys(filters)) filters[key] = []
  }
  return { filters, options, filteredRows, clearFilters }
}
