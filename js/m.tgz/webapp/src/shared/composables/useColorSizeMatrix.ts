import { computed, toValue, type MaybeRefOrGetter } from 'vue'
import type { MatrixData, MatrixRow } from '../types'

/**
 * Pure function to transform flat items into Color-Size matrix rows.
 */
export function transformToMatrix<T>(
  items: T[],
  allSizes: string[],
  options: {
    getColor: (item: T) => string
    getSize: (item: T) => string
    getQuantity: (item: T) => number | MatrixData
    /** Các trường bổ sung tùy chỉnh cho hàng (ví dụ: poCode, destination). */
    getExtra?: (item: T) => Partial<Omit<MatrixRow, 'color' | 'data'>>
    /** Optional key to group rows. Defaults to color. */
    groupBy?: (item: T) => string
  },
): MatrixRow[] {
  if (!items.length) return []

  const rowMap = new Map<string, MatrixRow>()
  const order: string[] = []

  items.forEach((item) => {
    const color = options.getColor(item)
    const groupKey = options.groupBy ? options.groupBy(item) : color

    if (!rowMap.has(groupKey)) {
      order.push(groupKey)
      const data: Record<string, number | MatrixData> = {}
      // Initialize with 0 or empty object based on first item's quantity type
      const firstQty = options.getQuantity(item)
      const defaultValue = typeof firstQty === 'object' ? { current: 0, limit: 0 } : 0

      allSizes.forEach((size) => {
        data[size] = JSON.parse(JSON.stringify(defaultValue))
      })

      rowMap.set(groupKey, {
        color,
        data,
        ...(options.getExtra ? options.getExtra(item) : {}),
      })
    }

    const row = rowMap.get(groupKey)!
    const size = options.getSize(item)
    const qty = options.getQuantity(item)

    if (typeof qty === 'object') {
      const current = row.data[size] as MatrixData
      if (current) {
        current.current += qty.current
        current.limit += qty.limit
      }
    } else {
      if (typeof row.data[size] === 'number') {
        ;(row.data[size] as number) += qty
      }
    }
  })

  return order.map((key) => rowMap.get(key)!)
}

/**
 * Composable for standard matrix transformation.
 */
export function useColorSizeMatrix<T>(
  items: MaybeRefOrGetter<T[]>,
  allSizes: MaybeRefOrGetter<string[]>,
  options: {
    getColor: (item: T) => string
    getSize: (item: T) => string
    getQuantity: (item: T) => number | MatrixData
    /** Các trường bổ sung tùy chỉnh cho hàng (ví dụ: poCode, destination). */
    getExtra?: (item: T) => Partial<Omit<MatrixRow, 'color' | 'data'>>
    groupBy?: (item: T) => string
  },
) {
  const matrixRows = computed(() => transformToMatrix(toValue(items), toValue(allSizes), options))

  return { matrixRows }
}
