import { expect, it } from 'vitest'
import { ref } from 'vue'
import { useColumnFilters } from '../useColumnFilters'

it('combines selections, keeps options and source rows, and includes unrestricted values', () => {
  const rows = ref([
    { name: 'A', colors: ['Red', 'Blue'], code: null },
    { name: 'B', colors: ['Blue'], code: 'B' },
    { name: 'C', colors: [], code: 'C' },
  ])
  const table = useColumnFilters(() => rows.value, {
    name: { label: 'NPL', values: (row) => [row.name] },
    colors: {
      label: 'Màu',
      values: (row) => row.colors,
      emptyLabel: 'Tất cả màu',
      unrestricted: true,
    },
    code: { label: 'Mã NPL', values: (row) => [row.code] },
  })
  expect(
    Object.values(table.options.value)
      .flat()
      .every((option) => option.value.length > 0),
  ).toBe(true)
  table.filters.name = ['A', 'B'].map((value) => JSON.stringify(value))
  table.filters.colors = [JSON.stringify('Red')]
  expect(table.filteredRows.value.map((row) => row.name)).toEqual(['A'])
  expect(table.filteredRows.value[0]).toBe(rows.value[0])
  expect(table.options.value.name).toHaveLength(3)
  table.filters.name = []
  expect(table.filteredRows.value.map((row) => row.name)).toEqual(['A', 'C'])
  table.filters.colors = [JSON.stringify('')]
  expect(table.filteredRows.value.map((row) => row.name)).toEqual(['C'])
  table.clearFilters()
  expect(table.filteredRows.value).toHaveLength(3)
  table.filters.code = [JSON.stringify('')]
  expect(table.filteredRows.value.map((row) => row.name)).toEqual(['A'])
  expect(table.options.value.code).toContainEqual({
    label: 'Chưa có giá trị',
    value: JSON.stringify(''),
  })
})
