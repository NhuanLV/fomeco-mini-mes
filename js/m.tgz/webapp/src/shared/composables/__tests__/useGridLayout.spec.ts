import { useGridLayout } from '@/shared/composables/useGridLayout'
import { MIN_SIZE_COL_WIDTH } from '@/shared/utils/colorSizeMatrix'
import { describe, expect, it } from 'vitest'
import { ref } from 'vue'

describe('useGridLayout', () => {
  it('enforces MIN_SIZE_COL_WIDTH for short size headers and values', () => {
    const rows = ref([{ S: 0 }])
    const columns = ref([{ prop: 'S', name: 'S' }])
    const { columnWidths } = useGridLayout({ rows, columns })

    // "S" (1 char * 10 = 10) + CELL_PADDING (30) = 40, which is < MIN_SIZE_COL_WIDTH (68)
    expect(columnWidths.value['S']).toBe(MIN_SIZE_COL_WIDTH)
  })

  it('calculates width based on the longer part when formatted as x / y', () => {
    const rows = ref([{ M: '1,200 / 1,500' }])
    const columns = ref([{ prop: 'M', name: 'M' }])
    const { columnWidths } = useGridLayout({ rows, columns })

    // "1,500" is 5 chars -> 5 * 10 + 30 = 80px (instead of "1,200 / 1,500" which would be 13 * 10 + 30 = 160px)
    expect(columnWidths.value['M']).toBe(80)
  })

  it('extracts visual width correctly when cell data is an object with current and limit', () => {
    const rows = ref([{ L: { current: 1200, limit: 1500 } }])
    const columns = ref([{ prop: 'L', name: 'L' }])
    const { columnWidths } = useGridLayout({ rows, columns })

    // "1500" is 4 chars -> 4 * 10 + 30 = 70px (previously was "[object Object]" with 15 chars -> 180px)
    expect(columnWidths.value['L']).toBe(70)
  })

  it('preserves full string length for dates and non-matrix strings', () => {
    const rows = ref([{ date: '15/09/2026' }])
    const columns = ref([{ prop: 'date', name: 'Ngày giao' }])
    const { columnWidths } = useGridLayout({ rows, columns })

    // "15/09/2026" is 10 chars -> 10 * 10 + 30 = 130px
    expect(columnWidths.value['date']).toBe(130)
  })

  it('respects custom minSize when specified', () => {
    const rows = ref([{ S: 0 }])
    const columns = ref([{ prop: 'S', name: 'S', minSize: 100 }])
    const { columnWidths } = useGridLayout({ rows, columns })

    expect(columnWidths.value['S']).toBe(100)
  })
})
