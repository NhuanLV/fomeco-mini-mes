import type { MatrixGridColumn, MatrixGridRow } from '@/shared/components/grid/matrixGrid'
import { MIN_SIZE_COL_WIDTH, ROW_HEIGHT } from '@/shared/utils/colorSizeMatrix'
import { useElementSize } from '@vueuse/core'
import { computed, type Ref, ref } from 'vue'

const CHAR_WIDTH = 10
const CELL_PADDING = 30 // cell border + sort icon + buffer
const HEADER_HEIGHT = 52

function estimateWidth(text?: string | null): number {
  return CHAR_WIDTH * (text?.length ?? 0)
}

function extractCellVisualText(val: unknown): string {
  if (val === null || val === undefined) return ''
  if (typeof val === 'object') {
    const obj = val as Record<string, unknown>
    if ('current' in obj || 'limit' in obj) {
      const cur = obj.current !== undefined && obj.current !== null ? String(obj.current) : ''
      const lim = obj.limit !== undefined && obj.limit !== null ? String(obj.limit) : ''
      return cur.length >= lim.length ? cur : lim
    }
    return ''
  }
  const str = String(val)
  // When formatted as "x / y", x is centered and /y is in top-right corner,
  // so horizontal space only needs to fit the longer part
  const match = str.match(/^\s*([\d,.]+)\s*\/\s*([\d,.]+)\s*$/)
  if (match && match[1] && match[2]) {
    return match[1].length >= match[2].length ? match[1] : match[2]
  }
  return str
}

/**
 * GridRow đại diện cho dữ liệu của một hàng trong bảng RevoGrid.
 * Sử dụng unknown vì các key (cột) được tạo động dựa trên size/metadata
 * và giá trị có thể là string, number hoặc MatrixData.
 */
export type GridRow = MatrixGridRow

export type GridColumn = MatrixGridColumn

function calculateColumnWidths(
  displayRows: GridRow[],
  columns: GridColumn[],
): Record<string, number> {
  const widths: Record<string, number> = {}

  for (const col of columns) {
    const prop = col.prop as string
    const longestText = displayRows.reduce(
      (longest, row) => {
        const text = extractCellVisualText(row[prop])
        return text.length > longest.length ? text : longest
      },
      String(col.name ?? ''),
    )

    const maxWidth = estimateWidth(longestText)
    const minWidth = col.minSize ?? MIN_SIZE_COL_WIDTH
    widths[prop] = Math.max(maxWidth + CELL_PADDING + (col.extraWidth ?? 0), minWidth)
  }

  return widths
}

// ── Composable ─────────────────────────────────────────────────────────────

export interface UseGridLayoutOptions {
  rows: Ref<GridRow[]>
  columns: Ref<GridColumn[]>
  displayRows?: (rows: GridRow[]) => GridRow[]
}

export function useGridLayout(options: UseGridLayoutOptions) {
  const wrapperRef = ref<HTMLElement | null>(null)
  const { width: wrapperWidth } = useElementSize(wrapperRef)

  const columnWidths = computed<Record<string, number>>(() => {
    if (!options.columns.value.length) return {}
    const resolvedRows = options.displayRows
      ? options.displayRows(options.rows.value)
      : options.rows.value
    const measured = calculateColumnWidths(resolvedRows, options.columns.value)

    const w = wrapperWidth.value
    if (w <= 0) return measured

    const totalMeasured = Object.values(measured).reduce((sum, width) => sum + width, 0)
    const remaining = w - totalMeasured
    if (remaining <= 0) return measured

    const autoCols = options.columns.value.filter((col) => typeof col.size !== 'number')
    if (autoCols.length === 0) return measured

    const extraPerCol = Math.floor(remaining / autoCols.length) - 4
    if (extraPerCol <= 0) return measured

    const distributed: Record<string, number> = { ...measured }
    for (const col of autoCols) {
      distributed[col.prop as string] = measured[col.prop as string] + extraPerCol
    }
    return distributed
  })

  const gridColumns = computed<GridColumn[]>(() =>
    options.columns.value.map((col) => ({
      ...col,
      size: columnWidths.value[col.prop as string] ?? col.size ?? 80,
    })),
  )

  const scrollbarHeight = ROW_HEIGHT / 2

  const rowCount = computed(() => options.rows.value.length)
  const tableHeight = computed(() => rowCount.value * ROW_HEIGHT + scrollbarHeight + HEADER_HEIGHT)

  return { wrapperRef, columnWidths, gridColumns, tableHeight }
}
