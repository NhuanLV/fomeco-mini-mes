/**
 * Domain row type dùng bởi ColorSizeMatrix (readonly).
 * Internal grid shapes không export ra ngoài mỗi component.
 */
import type { MetadataVm } from '@/api/types.gen'

export interface MatrixData {
  current: number
  limit: number
}

export interface MatrixRow {
  id?: string
  color: string
  purchaseOrderId?: string
  poCode?: string
  destination?: string
  data: Record<string, number | MatrixData>
  metadata?: MetadataVm | null
  // UI metadata (dùng cho allocation rows)
  isFirst?: boolean
  groupIndex?: number
  rowIndex?: number
  teamId?: string
}

/**
 * Kiểu dữ liệu đầu vào cho hàm transformToMatrix.
 * Sử dụng [key: string]: unknown vì đầu vào có thể là bất kỳ object nào từ API (VM),
 * chúng ta chỉ yêu cầu tối thiểu các trường color và size.
 */
export interface MatrixInputItem {
  color: string
  size: string
  purchaseOrderId?: string
  quantity?: number
  completedQty?: number
  qty?: number
  kind?: 'alloc' | 'progress' | 'edit' | 'planned'
  [key: string]: unknown
}

/** Maps a size string to its quantity */
export type SizeQuantityMap = Record<string, number>

/** Maps a color string to its nested sizes and their quantities */
export type ColorDemandMap = Record<string, SizeQuantityMap>
export interface SelectOption {
  label: string
  value: string
}
