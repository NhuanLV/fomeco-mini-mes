import { beforeEach, describe, expect, it, vi } from 'vitest'
import { SUPER_ADMIN_ROOT_ID, useAuthStore } from '../auth'
import { getCurrentUser, getTree, type AccountVm, type UnitVm } from '@/api'
import { sessionRevision } from '../sessionCache'

vi.mock('@/api', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@/api')>()),
  getCurrentUser: vi.fn(),
  getTree: vi.fn(),
}))

describe('auth store permission hierarchy', () => {
  const auth = useAuthStore()

  const mockTree: UnitVm[] = [
    {
      id: 'corp-1',
      name: 'Corporation 1',
      code: 'CORP1',
      type: 'CORPORATION',
      operations: [],
      isActive: true,
      children: [
        {
          id: 'company-1',
          name: 'Company 1',
          code: 'COMP1',
          type: 'COMPANY',
          operations: [],
          isActive: true,
          children: [
            {
              id: 'factory-1',
              name: 'Factory 1',
              code: 'FAC1',
              type: 'FACTORY',
              operations: [],
              isActive: true,
              children: [
                {
                  id: 'team-1',
                  name: 'Team 1',
                  code: 'T1',
                  type: 'TEAM',
                  operations: [],
                  isActive: true,
                  children: [],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      id: 'corp-2',
      name: 'Corporation 2',
      code: 'CORP2',
      type: 'CORPORATION',
      operations: [],
      isActive: true,
      children: [],
    },
  ]

  beforeEach(() => {
    vi.clearAllMocks()
    auth.logout()
    auth.updateParentMap(mockTree)
  })

  it('does not restore an account when an auth request finishes after logout', async () => {
    let resolve!: (value: {
      data: AccountVm
      error: undefined
      request: Request
      response: Response
    }) => void
    vi.mocked(getCurrentUser).mockReturnValue(
      new Promise<{ data: AccountVm; error: undefined; request: Request; response: Response }>(
        (done) => {
          resolve = done
        },
      ),
    )
    vi.mocked(getTree).mockRejectedValue(new Error('no tree'))
    const pending = auth.checkAuth()
    auth.logout()
    resolve({
      data: { id: 'old-account', memberships: [] } as unknown as AccountVm,
      error: undefined,
      request: new Request('/api/accounts/current'),
      response: new Response(),
    })

    await pending

    expect(auth.currentUser.value).toBeNull()
    expect(auth.isAuthenticated.value).toBe(false)
  })

  it('changes the data session when permissions change but not when the name changes', () => {
    const user = { id: 'account', name: 'A', memberships: [] } as unknown as AccountVm
    auth.currentUser.value = user
    const revision = sessionRevision.value
    auth.currentUser.value = { ...user, name: 'B' }
    expect(sessionRevision.value).toBe(revision)
    auth.currentUser.value = {
      ...user,
      memberships: [
        { unitId: 'team', roles: [{ id: 'role', permissions: [{ code: 'CREATE_KANBAN' }] }] },
      ],
    } as unknown as AccountVm
    expect(sessionRevision.value).toBe(revision + 1)
  })

  it('clears stale hierarchy when refreshing the unit tree fails', async () => {
    const user = {
      id: 'u2',
      name: 'Factory Leader',
      username: 'u2',
      memberships: [
        {
          unitId: 'factory-1',
          unitName: 'Factory 1',
          unitType: 'FACTORY',
          roles: [
            {
              id: 'r1',
              name: 'Quản đốc',
              description: '',
              isSystem: false,
              permissions: [{ code: 'CREATE_KANBAN', name: 'Create Kanban' }],
            },
          ],
        },
      ],
    } as unknown as AccountVm
    vi.mocked(getCurrentUser).mockResolvedValue({
      data: user,
      error: undefined,
      request: new Request('/api/account/me'),
      response: new Response(),
    })
    vi.mocked(getTree).mockRejectedValue(new Error('network error'))

    await auth.checkAuth()

    expect(auth.hasPermission('CREATE_KANBAN', 'team-1')).toBe(false)
  })

  it('grants permission when user has role at exact team', () => {
    auth.currentUser.value = {
      id: 'u1',
      name: 'User 1',
      username: 'u1',
      memberships: [
        {
          unitId: 'team-1',
          unitName: 'Team 1',
          unitType: 'TEAM',
          roles: [
            {
              id: 'r1',
              name: 'Tổ trưởng',
              description: '',
              isSystem: false,
              permissions: [{ code: 'CREATE_KANBAN', name: 'Create Kanban' }],
            },
          ],
        },
      ],
    } as unknown as AccountVm

    expect(auth.hasPermission('CREATE_KANBAN', 'team-1')).toBe(true)
    expect(auth.hasPermission('CREATE_KANBAN', 'corp-2')).toBe(false)
  })

  it('grants permission on child team when user has role at parent factory or company or corporation', () => {
    // Role assigned at Factory 1
    auth.currentUser.value = {
      id: 'u2',
      name: 'Factory Leader',
      username: 'u2',
      memberships: [
        {
          unitId: 'factory-1',
          unitName: 'Factory 1',
          unitType: 'FACTORY',
          roles: [
            {
              id: 'r1',
              name: 'Quản đốc',
              description: '',
              isSystem: false,
              permissions: [{ code: 'CREATE_KANBAN', name: 'Create Kanban' }],
            },
          ],
        },
      ],
    } as unknown as AccountVm

    expect(auth.hasPermission('CREATE_KANBAN', 'team-1')).toBe(true)
    expect(auth.hasPermission('CREATE_KANBAN', 'factory-1')).toBe(true)
    expect(auth.hasPermission('CREATE_KANBAN', 'company-1')).toBe(false)
    expect(auth.hasPermission('CREATE_KANBAN', 'corp-2')).toBe(false)
  })

  it('grants permission everywhere when user has role at SUPER_ADMIN_ROOT_ID', () => {
    auth.currentUser.value = {
      id: 'admin',
      name: 'Admin',
      username: 'admin',
      memberships: [
        {
          unitId: SUPER_ADMIN_ROOT_ID,
          unitName: 'Root',
          unitType: 'CORPORATION',
          roles: [
            {
              id: 'r-admin',
              name: 'Tổ trưởng',
              description: '',
              isSystem: false,
              permissions: [{ code: 'CREATE_KANBAN', name: 'Create Kanban' }],
            },
          ],
        },
      ],
    } as unknown as AccountVm

    expect(auth.hasPermission('CREATE_KANBAN', 'team-1')).toBe(true)
    expect(auth.hasPermission('CREATE_KANBAN', 'factory-1')).toBe(true)
    expect(auth.hasPermission('CREATE_KANBAN', 'corp-2')).toBe(true)
    expect(auth.hasPermission('CREATE_KANBAN', 'unknown-unit')).toBe(true)
  })
})
