import { PiniaColada, useQueryCache } from '@pinia/colada'
import { createPinia } from 'pinia'
import { createApp, effectScope, nextTick } from 'vue'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { installSessionCache, sessionRevision } from '../sessionCache'

describe('session cache', () => {
  let cache: ReturnType<typeof useQueryCache>
  let dispose: () => void
  let authenticated: boolean

  beforeEach(() => {
    authenticated = false
    const app = createApp({})
    app.use(createPinia())
    app.use(PiniaColada)
    app.runWithContext(() => {
      cache = useQueryCache()
      dispose = installSessionCache(() => authenticated)
    })
  })

  afterEach(() => dispose())

  it('removes cached data and ignores an old query that finishes after logout', async () => {
    let resolve!: (value: string) => void
    const result = new Promise<string>((done) => {
      resolve = done
    })
    const entry = cache.ensure({ key: ['private'], query: () => result })
    cache.setQueryData(entry.key, 'account A')
    const pending = cache.fetch(entry)

    sessionRevision.value++

    expect(cache.getQueryData(entry.key)).toBeUndefined()
    expect(entry.state.value.data).toBeUndefined()
    resolve('late account A')
    await pending
    expect(entry.state.value.data).toBeUndefined()
    expect(cache.getQueryData(entry.key)).toBeUndefined()
  })

  it('clears active data immediately and refetches it under the new permissions', async () => {
    authenticated = true
    const query = vi.fn(async () => 'new scope')
    const entry = cache.ensure({ key: ['private'], query })
    const scope = effectScope()
    const consumer = { owner: scope }
    cache.track(entry, consumer)
    cache.setQueryData(entry.key, 'old scope')

    sessionRevision.value++

    expect(entry.state.value.data).toBeUndefined()
    await nextTick()
    await cache.refresh(entry)
    expect(entry.state.value.data).toBe('new scope')
    expect(query).toHaveBeenCalledTimes(1)
    cache.untrack(entry, consumer)
    scope.stop()
  })
})
