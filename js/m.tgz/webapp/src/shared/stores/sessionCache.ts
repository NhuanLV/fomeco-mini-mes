import { useMutationCache, useQueryCache } from '@pinia/colada'
import { nextTick, ref, watch } from 'vue'

// Đánh dấu phiên dữ liệu trên fe, auth store tăng khi login/logout hoặc permission/account thay đổi.
export const sessionRevision = ref(0)

export function installSessionCache(isAuthenticated: () => boolean) {
  const queryCache = useQueryCache()
  const mutationCache = useMutationCache()
  return watch(
    sessionRevision,
    () => {
      const revision = sessionRevision.value
      queryCache.cancelQueries()
      for (const entry of mutationCache.getEntries()) mutationCache.remove(entry)
      for (const entry of queryCache.getEntries()) {
        queryCache.setEntryState(entry, { data: undefined, error: null, status: 'pending' })
        entry.placeholderData = null
        queryCache.invalidate(entry)
        if (!entry.active) queryCache.remove(entry)
      }

      // Chờ auth store cập nhật xong; không tải lại nếu đã logout hoặc đổi phiên lần nữa.
      void nextTick().then(() => {
        if (revision === sessionRevision.value && isAuthenticated())
          return queryCache.invalidateQueries()
      })
    },
    { flush: 'sync' },
  )
}
