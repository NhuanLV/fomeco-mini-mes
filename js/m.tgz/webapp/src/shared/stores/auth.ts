import { createGlobalState } from '@vueuse/core'
import { computed, ref, watch } from 'vue'
import { sessionRevision } from './sessionCache'
import type { AccountVm, PermissionVm, UnitVm } from '@/api'
import { getCurrentUser, getTree } from '@/api'

type PermissionCode = PermissionVm['code']

export const SUPER_ADMIN_ROOT_ID = '00000000-0000-0000-0000-000000000000'

export const useAuthStore = createGlobalState(() => {
  const isInitialized = ref(false)
  const isAuthenticated = ref(false)
  const currentUser = ref<AccountVm | null>(null)
  const parentMap = ref(new Map<string, string>())

  // Tăng sessionRevision khi permission/account thay đổi.
  watch(
    () =>
      JSON.stringify(
        currentUser.value
          ? {
              id: currentUser.value.id,
              memberships: currentUser.value.memberships
                .map((membership) => ({
                  unitId: membership.unitId,
                  roles: membership.roles
                    .map((role) => ({
                      id: role.id,
                      permissions: role.permissions.map((permission) => permission.code).sort(),
                    }))
                    .sort((a, b) => a.id.localeCompare(b.id)),
                }))
                .sort((a, b) => a.unitId.localeCompare(b.unitId)),
            }
          : null,
      ),
    () => {
      sessionRevision.value++
    },
    { flush: 'sync' },
  )

  function updateParentMap(treeData: UnitVm | UnitVm[]) {
    const map = new Map<string, string>()
    const list = Array.isArray(treeData) ? treeData : [treeData]

    function traverse(units: UnitVm[], parentId?: string) {
      for (const unit of units) {
        if (parentId) {
          map.set(unit.id, parentId)
        }
        if (unit.children?.length) {
          traverse(unit.children, unit.id)
        }
      }
    }

    traverse(list)
    parentMap.value = map
  }

  function isAncestorOrSelf(ancestorId: string, descendantId: string): boolean {
    if (ancestorId === SUPER_ADMIN_ROOT_ID) return true
    if (ancestorId === descendantId) return true

    let currentId: string | undefined = descendantId
    const visited = new Set<string>()
    while (currentId) {
      if (visited.has(currentId)) break
      visited.add(currentId)
      if (currentId === ancestorId) return true
      currentId = parentMap.value.get(currentId)
    }
    return false
  }

  // Tổng hợp tất cả quyền từ mọi memberships (đơn vị) mà user tham gia
  const permissions = computed<Set<PermissionCode>>(() => {
    if (!currentUser.value) return new Set()
    return new Set(
      currentUser.value.memberships
        .flatMap((m) => m.roles)
        .flatMap((r) => r.permissions.map((p) => p.code)),
    )
  })

  function hasPermission(code: PermissionCode, unitId?: string): boolean {
    if (!currentUser.value) return false
    if (!unitId) return permissions.value.has(code)

    return currentUser.value.memberships
      .filter((m) => isAncestorOrSelf(m.unitId, unitId))
      .flatMap((m) => m.roles)
      .flatMap((r) => r.permissions)
      .some((p) => p.code === code)
  }

  const checkAuth = async () => {
    const revision = sessionRevision.value
    try {
      const [userRes, treeRes] = await Promise.all([
        getCurrentUser(),
        getTree().catch(() => ({ data: undefined })),
      ])
      // Không để response cũ khôi phục account sau logout hoặc ghi đè phiên mới.
      if (revision !== sessionRevision.value) return
      isInitialized.value = true
      parentMap.value = new Map()
      if (userRes.data) {
        currentUser.value = userRes.data
        isAuthenticated.value = true
      } else {
        currentUser.value = null
        isAuthenticated.value = false
      }
      if (treeRes?.data) {
        updateParentMap(treeRes.data as UnitVm | UnitVm[])
      }
    } catch {
      // Lỗi của lần kiểm tra cũ không được xóa thông tin phiên hiện tại.
      if (revision !== sessionRevision.value) return
      isInitialized.value = true
      parentMap.value = new Map()
      currentUser.value = null
      isAuthenticated.value = false
    }
  }

  function logout() {
    // Khi user chưa tải xong mà logout, vẫn tăng sessionRevision để hủy các request cũ.
    if (!currentUser.value) sessionRevision.value++
    currentUser.value = null
    isAuthenticated.value = false
    parentMap.value.clear()
  }

  return {
    isInitialized,
    isAuthenticated,
    currentUser,
    permissions,
    hasPermission,
    checkAuth,
    logout,
    updateParentMap,
  }
})
