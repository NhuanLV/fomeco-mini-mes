<script setup lang="ts">
import type { InventoryRequestDraftRow } from '@/features/inventory/inventory-request/inventoryRequest'
import { useInventoryRequestDraft } from '@/features/inventory/inventory-request/useInventoryRequestDraft'
import { rejectComma } from '@/shared/utils/numberInput'
import { fmtQty } from '@/shared/utils/fmtQty'
import type { TableColumn } from '@nuxt/ui'
import { computed } from 'vue'
import InventoryRequestGrid from './request-grid/InventoryRequestGrid.vue'

const props = defineProps<{
  id: string
  requestKind: 'return' | 'transfer'
  readOnly?: boolean
}>()

const {
  isReturnKind,
  nplMaterials,
  isExcessLoading,
  warehouseOptions,
  isWarehousesLoading,
  selectedMaterials,
  showCreateDialog,
  draftRows,
  isLoadingCandidates,
  isCreating,
  onSelectedRowsChange,
  openCreateDialog,
  getTeamOptions,
  getLcdOptions,
  onTeamChange,
  addSplitRow,
  removeDraftRow,
  submitRequest,
} = useInventoryRequestDraft(props)

const columns = computed<TableColumn<InventoryRequestDraftRow>[]>(() => [
  { accessorKey: 'article', header: 'Tên NPL' },
  { accessorKey: 'uom', header: 'ĐVT' },
  { accessorKey: 'color', header: 'Màu' },
  { accessorKey: 'size', header: 'Cỡ' },
  { accessorKey: 'excessQuantity', header: 'SL dư' },
  {
    accessorKey: 'quantity',
    header: isReturnKind.value ? 'SL trả lại' : 'SL điều chuyển',
  },
  ...(isReturnKind.value
    ? [{ accessorKey: 'targetWarehouseId', header: 'Nơi nhận' }]
    : [
        { accessorKey: 'targetTeamId', header: 'Tổ nhận' },
        { accessorKey: 'targetTeamAssignmentId', header: 'Lệnh công đoạn' },
      ]),
  { id: 'actions' },
])
</script>

<template>
  <div class="flex flex-col gap-6">
    <div class="card rounded-xl bg-white p-4 shadow-sm">
      <div class="mb-4 flex items-center justify-between">
        <h3 class="text-xl font-semibold text-highlighted">Danh sách NPL</h3>
        <UButton
          v-if="!readOnly"
          :label="isReturnKind ? 'Tạo yêu cầu trả lại' : 'Tạo yêu cầu điều chuyển'"
          icon="i-lucide-plus"
          @click="openCreateDialog"
          :disabled="selectedMaterials.length === 0"
        />
      </div>

      <div v-if="isExcessLoading && nplMaterials.length === 0" class="flex justify-center py-12">
        <UIcon name="i-lucide-loader-circle" class="animate-spin text-4xl text-primary" />
      </div>
      <InventoryRequestGrid
        v-else-if="nplMaterials.length > 0"
        :rows="nplMaterials"
        @update:selected-rows="onSelectedRowsChange"
      />
    </div>

    <UModal
      v-if="!readOnly"
      v-model:open="showCreateDialog"
      :title="isReturnKind ? 'Tạo yêu cầu trả lại' : 'Tạo yêu cầu điều chuyển'"
      class="max-w-[86vw]"
    >
      <template #body>
        <div
          v-if="(isWarehousesLoading && warehouseOptions.length === 0) || isLoadingCandidates"
          class="flex justify-center py-12"
        >
          <UIcon name="i-lucide-loader-circle" class="animate-spin text-3xl text-primary" />
        </div>

        <UTable v-else :data="draftRows" :columns="columns">
          <template #excessQuantity-cell="{ row }">
            {{ fmtQty(row.original.excessQuantity) }}
          </template>

          <template #quantity-cell="{ row }">
            <UInput
              v-model.number="row.original.quantity"
              type="text"
              inputmode="decimal"
              min="0"
              step="0.0001"
              @beforeinput="rejectComma"
            />
          </template>

          <template #targetWarehouseId-cell="{ row }">
            <USelect
              v-model="row.original.targetWarehouseId"
              :items="warehouseOptions"
              label-key="name"
              value-key="id"
              placeholder="Chọn kho"
              class="w-48"
            />
          </template>

          <template #targetTeamId-cell="{ row }">
            <USelect
              v-model="row.original.targetTeamId"
              :items="getTeamOptions(row.original)"
              label-key="teamName"
              value-key="teamId"
              placeholder="Chọn tổ nhận"
              class="w-48"
              @change="onTeamChange(row.original)"
            />
          </template>

          <template #targetTeamAssignmentId-cell="{ row }">
            <USelect
              v-model="row.original.targetTeamAssignmentId"
              :items="getLcdOptions(row.original)"
              label-key="productionOrderCode"
              value-key="teamAssignmentId"
              placeholder="Chọn lệnh"
              class="w-48"
              :disabled="!row.original.targetTeamId"
            />
          </template>

          <template #actions-cell="{ row }">
            <div class="flex justify-end gap-2">
              <UButton icon="i-lucide-plus" variant="ghost" @click="addSplitRow(row.original)" />
              <UButton
                icon="i-lucide-trash-2"
                variant="ghost"
                color="error"
                @click="removeDraftRow(row.original.lineId)"
              />
            </div>
          </template>
          <template #empty>Không có dữ liệu.</template>
        </UTable>
      </template>

      <template #footer>
        <UButton label="Hủy" icon="i-lucide-x" variant="ghost" @click="showCreateDialog = false" />
        <UButton
          label="Xác nhận"
          icon="i-lucide-check"
          @click="submitRequest"
          :loading="isCreating"
          :disabled="isWarehousesLoading || isLoadingCandidates"
        />
      </template>
    </UModal>
  </div>
</template>
