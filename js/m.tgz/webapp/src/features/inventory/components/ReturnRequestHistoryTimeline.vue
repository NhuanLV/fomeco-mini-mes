<script setup lang="ts">
import {
  getReturnRequestHistoryQuery,
  getTransferRequestHistoryQuery,
} from '@/api/@pinia/colada.gen'
import type { ReturnRequestHistoryEventVm, TransferRequestHistoryEventVm } from '@/api/types.gen'
import { useQuery } from '@pinia/colada'
import dayjs from 'dayjs'
import { computed, ref } from 'vue'

const COLLAPSE_LIMIT = 3

type HistoryEvent = ReturnRequestHistoryEventVm | TransferRequestHistoryEventVm
type EventType = ReturnRequestHistoryEventVm['type'] | TransferRequestHistoryEventVm['type']

const EVENT_CONFIG: Record<string, { title: string; icon: string; color: string }> = {
  ReturnRequestCreated: {
    title: 'Tạo phiếu yêu cầu',
    icon: 'i-lucide-circle-plus',
    color: 'text-primary bg-primary/10',
  },
  ReturnRequestApproved: {
    title: 'Duyệt phiếu yêu cầu',
    icon: 'i-lucide-circle-check',
    color: 'text-green-600 bg-green-50',
  },
  ReturnRequestRejected: {
    title: 'Từ chối phiếu yêu cầu',
    icon: 'i-lucide-circle-x',
    color: 'text-red-600 bg-red-50',
  },
  ReturnRequestRevised: {
    title: 'Sửa đổi phiếu yêu cầu',
    icon: 'i-lucide-square-pen',
    color: 'text-orange-600 bg-orange-50',
  },
  ReturnRequestMaterialReceived: {
    title: 'Xác nhận nhận vật tư',
    icon: 'i-lucide-package-check',
    color: 'text-green-600 bg-sky-50',
  },
  TransferRequestCreated: {
    title: 'Tạo phiếu yêu cầu',
    icon: 'i-lucide-circle-plus',
    color: 'text-primary bg-primary/10',
  },
  TransferRequestApproved: {
    title: 'Duyệt phiếu yêu cầu',
    icon: 'i-lucide-circle-check',
    color: 'text-green-600 bg-green-50',
  },
  TransferRequestRejected: {
    title: 'Từ chối phiếu yêu cầu',
    icon: 'i-lucide-circle-x',
    color: 'text-red-600 bg-red-50',
  },
  TransferRequestRevised: {
    title: 'Sửa đổi phiếu yêu cầu',
    icon: 'i-lucide-square-pen',
    color: 'text-orange-600 bg-orange-50',
  },
  TransferRequestMaterialReceived: {
    title: 'Xác nhận nhận vật tư',
    icon: 'i-lucide-package-check',
    color: 'text-green-600 bg-sky-50',
  },
}

const COLLAPSIBLE_EVENTS = new Set([
  'ReturnRequestMaterialReceived',
  'ReturnRequestRevised',
  'TransferRequestMaterialReceived',
  'TransferRequestRevised',
])

const props = defineProps<{
  requestId: string
  requestKind?: 'return' | 'transfer'
  requestType?: string
}>()

const { data: history, isLoading } = useQuery(() => ({
  ...(props.requestKind === 'transfer'
    ? getTransferRequestHistoryQuery({ path: { id: props.requestId } })
    : getReturnRequestHistoryQuery({ path: { id: props.requestId } })),
}))

const events = computed(() => history.value ?? [])

const expandedKeys = ref(new Set<string>())

function eventKey(index: number): string {
  return String(index)
}

function toggleExpand(key: string) {
  if (expandedKeys.value.has(key)) {
    expandedKeys.value.delete(key)
  } else {
    expandedKeys.value.add(key)
  }
  expandedKeys.value = new Set(expandedKeys.value)
}

function configOf(type: EventType) {
  return (
    EVENT_CONFIG[type] ?? {
      title: type,
      icon: 'i-lucide-circle',
      color: 'text-primary bg-primary/10',
    }
  )
}

function actionTitleOf(event: HistoryEvent): string {
  const typeLabel = props.requestType
    ? `yêu cầu ${props.requestType.toLowerCase()}`
    : 'phiếu yêu cầu'

  if (event.type === 'ReturnRequestCreated' || event.type === 'TransferRequestCreated')
    return `tạo ${typeLabel}`
  if (event.type === 'ReturnRequestApproved' || event.type === 'TransferRequestApproved')
    return `duyệt ${typeLabel}`
  if (event.type === 'ReturnRequestRejected' || event.type === 'TransferRequestRejected')
    return `từ chối ${typeLabel}`
  if (event.type === 'ReturnRequestRevised' || event.type === 'TransferRequestRevised')
    return `sửa đổi ${typeLabel}`

  return configOf(event.type).title.toLowerCase()
}

function subtitleOf(event: HistoryEvent): string | null {
  if (event.type === 'ReturnRequestRejected' || event.type === 'TransferRequestRejected')
    return event.subtitle ?? null
  if (event.type === 'ReturnRequestRevised' || event.type === 'TransferRequestRevised') {
    const n = Object.keys(event.detail).length
    return n > 0 ? `${n} dòng thay đổi` : null
  }
  return null
}

function visibleDetail(event: HistoryEvent, key: string): [string, string][] {
  const entries = Object.entries(event.detail)
  if (!COLLAPSIBLE_EVENTS.has(event.type)) return entries
  return expandedKeys.value.has(key) ? entries : entries.slice(0, COLLAPSE_LIMIT)
}

function hasMore(event: HistoryEvent): boolean {
  return COLLAPSIBLE_EVENTS.has(event.type) && Object.keys(event.detail).length > COLLAPSE_LIMIT
}
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex items-center gap-2">
        <UIcon name="i-lucide-history" class="size-5 text-primary" />
        <span>Lịch sử hoạt động</span>
      </div>
    </template>

    <template #default>
      <div v-if="isLoading && !events.length" class="flex justify-center py-6">
        <UIcon name="i-lucide-loader-circle" class="animate-spin text-2xl text-primary" />
      </div>

      <div
        v-else-if="!isLoading && events.length === 0"
        class="py-4 text-center text-sm text-toned"
      >
        Chưa có hoạt động nào.
      </div>

      <UTimeline
        v-else
        :items="events"
        :class="{ 'pointer-events-none opacity-50': isLoading }"
        :ui="{
          date: 'grow-0! whitespace-nowrap! min-w-[150px]! px-4!',
          wrapper: 'flex-1!',
        }"
      >
        <template #date="{ item }">
          <span class="text-sm whitespace-nowrap">
            {{ dayjs(item.occurredAt).format('HH:mm - DD/MM/YYYY') }}
          </span>
        </template>

        <template #indicator="{ item }">
          <span
            class="z-10 flex h-8 w-8 items-center justify-center rounded-full"
            :class="configOf(item.type).color"
          >
            <UIcon :name="configOf(item.type).icon" class="text-sm" />
          </span>
        </template>

        <template #wrapper="{ item }">
          <UCard class="mb-4">
            <template #title>
              <p class="text-sm leading-snug">
                <span class="font-semibold">{{ item.actor?.name ?? 'Hệ thống' }}</span>
                <span class="text-toned"> đã </span>
                <span class="font-medium">{{ actionTitleOf(item) }}</span>
              </p>
            </template>
            <template #description>
              {{ subtitleOf(item) }}
            </template>
            <template #default>
              <dl v-if="Object.keys(item.detail).length > 0" class="mt-2 space-y-0.5 text-xs">
                <div
                  v-for="[key, value] in visibleDetail(item, eventKey(events.indexOf(item)))"
                  :key="key"
                  class="flex gap-2"
                >
                  <dt class="min-w-0 shrink-0 text-toned">{{ key }}</dt>
                  <dd class="font-medium text-default">{{ value }}</dd>
                </div>
              </dl>
            </template>
            <template #footer>
              <UButton
                v-if="hasMore(item)"
                :label="
                  expandedKeys.has(eventKey(events.indexOf(item)))
                    ? 'Thu gọn'
                    : `Xem thêm ${Object.keys(item.detail).length - COLLAPSE_LIMIT} dòng`
                "
                variant="link"
                size="sm"
                class="mt-1 text-xs"
                @click="toggleExpand(eventKey(events.indexOf(item)))"
              />
            </template>
          </UCard>
        </template>
      </UTimeline>
    </template>
  </UCard>
</template>
