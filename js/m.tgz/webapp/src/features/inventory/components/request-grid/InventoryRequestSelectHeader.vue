<script setup lang="ts">
interface Addition {
  onToggleAll: () => void
  isAllSelected: boolean
}

const props = defineProps<{
  name?: string
  column?: { name?: string }
  addition?: Addition
}>()

function handleToggle() {
  if (props.addition?.onToggleAll) {
    props.addition.onToggleAll()
  }
}
</script>

<template>
  <div class="flex h-full w-full items-center justify-start gap-2 pl-3">
    <span>{{ props.name || props.column?.name || 'Chọn' }}</span>
    <UCheckbox :model-value="props.addition?.isAllSelected" @update:model-value="handleToggle" />
  </div>
</template>
