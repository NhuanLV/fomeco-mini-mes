<script setup lang="ts">
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'

interface Addition {
  onToggleSelect: (rowIndex: number) => void
}

const props = defineProps<MatrixGridCellProps & { addition?: Addition }>()

function handleToggle() {
  if (props.addition?.onToggleSelect) {
    props.addition.onToggleSelect(props.rowIndex)
  }
}
</script>

<template>
  <div class="flex h-full items-center justify-center">
    <UCheckbox
      :model-value="props.model.isSelected"
      :disabled="!(Number(props.model.excessQuantity || 0) > 0)"
      @update:model-value="handleToggle"
    />
  </div>
</template>
