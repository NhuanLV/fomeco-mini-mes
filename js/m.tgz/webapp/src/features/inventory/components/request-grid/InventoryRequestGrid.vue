<script setup lang="ts">
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import { matrixGridCell, type MatrixGridColumnTypes } from '@/shared/components/grid/matrixGrid'
import InventoryRequestSelectCell from './InventoryRequestSelectCell.vue'
import InventoryRequestSelectHeader from './InventoryRequestSelectHeader.vue'
import { computed, ref } from 'vue'
import { buildColumns } from '../../helpers/inventoryRequestGrid'
import type { ExcessMaterialVm } from '@/api'
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'

const props = defineProps<{
  rows: ExcessMaterialVm[]
}>()

const emit = defineEmits<{
  'update:selectedRows': [val: ExcessMaterialVm[]]
}>()

const COLUMN_TYPES: MatrixGridColumnTypes = {
  component: {
    cellTemplate: matrixGridCell(InventoryRequestSelectCell),
    columnTemplate: matrixGridCell(InventoryRequestSelectHeader),
  },
  qty: {
    cellTemplate: matrixGridCell(MatrixQtyCell),
  },
}

const columns = computed(() => buildColumns())

const selectedLineIds = ref<Set<string>>(new Set())

const displayRows = computed(() => {
  return props.rows.map((r) => {
    const lineId = `${r.article}-${r.color}-${r.size}`
    return {
      ...r,
      lineId,
      isSelected: selectedLineIds.value.has(lineId),
    }
  })
})

function handleToggleSelect(rowIndex: number) {
  const row = displayRows.value[rowIndex]
  if (row) {
    const newSet = new Set(selectedLineIds.value)
    if (newSet.has(row.lineId)) {
      newSet.delete(row.lineId)
    } else {
      newSet.add(row.lineId)
    }
    selectedLineIds.value = newSet

    emit(
      'update:selectedRows',
      props.rows.filter((r) => newSet.has(`${r.article}-${r.color}-${r.size}`)),
    )
  }
}

const selectableRows = computed(() => {
  return displayRows.value.filter((r) => Number(r.excessQuantity || 0) > 0)
})

const isAllSelected = computed(() => {
  if (selectableRows.value.length === 0) return false
  return selectableRows.value.every((r) => selectedLineIds.value.has(r.lineId))
})

function handleToggleAll() {
  if (isAllSelected.value) {
    selectedLineIds.value = new Set()
  } else {
    selectedLineIds.value = new Set(selectableRows.value.map((r) => r.lineId))
  }

  emit(
    'update:selectedRows',
    props.rows.filter((r) => selectedLineIds.value.has(`${r.article}-${r.color}-${r.size}`)),
  )
}
</script>

<template>
  <BaseMatrixGrid
    :source="displayRows"
    :columns="columns"
    :column-types="COLUMN_TYPES"
    :additional-data="{
      onToggleSelect: handleToggleSelect,
      onToggleAll: handleToggleAll,
      isAllSelected: isAllSelected,
    }"
  />
</template>
