<script setup lang="ts">
import { client } from '@/api/client.gen'
import { fmtQty } from '@/shared/utils/fmtQty'
import { useQuery } from '@pinia/colada'
import type { TableColumn } from '@nuxt/ui'
import dayjs from 'dayjs'
import { computed } from 'vue'
import { makeArticleVariantComparator } from '@/shared/utils/orderedValues'

const props = defineProps<{ id: string; styleColorOrder?: string[]; styleSizeOrder?: string[] }>()

type Balance = {
  article: string
  displayArticle: string
  color: string
  size: string
  uom: string
  totalReceived: number
  totalIssued: number
  balance: number
}
type Transaction = {
  eventType: string
  article: string
  displayArticle: string
  color: string
  size: string
  uom: string
  quantity: number
  kanbanId?: string
  kanbanCode?: string
  counterpartyName?: string
  occurredAt: string
}

const {
  data: balances,
  isLoading: loadingBalances,
  error: balanceError,
} = useQuery(() => ({
  key: ['btp-balance', props.id],
  query: async () => {
    const response = await client.get<Balance[]>({
      url: `/api/inventory/team-assignments/${props.id}/btp/balance`,
    })
    if (response.error) throw response.error
    return response.data ?? []
  },
}))
const {
  data: transactions,
  isLoading: loadingTransactions,
  error: transactionError,
} = useQuery(() => ({
  key: ['btp-transactions', props.id],
  query: async () => {
    const response = await client.get<Transaction[]>({
      url: `/api/inventory/team-assignments/${props.id}/btp/transactions`,
    })
    if (response.error) throw response.error
    return response.data ?? []
  },
}))

const viewBalances = computed(() =>
  [...(balances.value ?? [])].sort(
    makeArticleVariantComparator(props.styleColorOrder, props.styleSizeOrder),
  ),
)

const balanceColumns: TableColumn<Balance>[] = [
  { accessorKey: 'displayArticle', header: 'BTP' },
  { accessorKey: 'color', header: 'Màu' },
  { accessorKey: 'size', header: 'Cỡ' },
  { accessorKey: 'uom', header: 'ĐVT' },
  { id: 'totalReceived', header: 'Luỹ kế thực nhận + ra chuyền' },
  { id: 'totalIssued', header: 'Luỹ kế thực xuất' },
  { id: 'balance', header: 'SL tồn' },
]
const transactionColumns: TableColumn<Transaction>[] = [
  { id: 'occurredAt', header: 'Thời gian' },
  { id: 'eventType', header: 'Loại' },
  { accessorKey: 'displayArticle', header: 'BTP' },
  { accessorKey: 'color', header: 'Màu' },
  { accessorKey: 'size', header: 'Cỡ' },
  { id: 'quantity', header: 'Số lượng' },
  { accessorKey: 'kanbanCode', header: 'Mã kanban' },
  { accessorKey: 'counterpartyName', header: 'Nơi nhận/cấp phát' },
]
const eventLabels: Record<string, string> = {
  PRODUCED: 'Sản xuất',
  KANBAN_ISSUED: 'Xuất Kanban',
  KANBAN_RECEIVED: 'Nhận Kanban',
  KANBAN_CANCELLED: 'Huỷ Kanban',
}
const eventColors: Record<string, 'info' | 'warning' | 'success'> = {
  PRODUCED: 'info',
  KANBAN_ISSUED: 'warning',
  KANBAN_RECEIVED: 'success',
  KANBAN_CANCELLED: 'success',
}
</script>

<template>
  <div class="flex flex-col gap-6">
    <div class="card rounded-xl bg-white p-4 shadow-sm">
      <h3 class="mb-4 text-lg font-semibold text-highlighted">Luỹ kế tồn kho</h3>
      <p v-if="balanceError" class="text-red-600">Không tải được số dư BTP.</p>
      <p v-else-if="!loadingBalances && !balances?.length">Chưa có giao dịch BTP</p>
      <UTable
        v-else
        :data="viewBalances"
        :columns="balanceColumns"
        :loading="loadingBalances"
        class="text-sm"
      >
        <template #totalReceived-cell="{ row }">{{ fmtQty(row.original.totalReceived) }}</template>
        <template #totalIssued-cell="{ row }">{{ fmtQty(row.original.totalIssued) }}</template>
        <template #balance-cell="{ row }">
          <span
            :class="
              row.original.balance < 0 ? 'font-bold text-red-600' : 'font-bold text-green-600'
            "
          >
            {{ fmtQty(row.original.balance) }}
          </span>
        </template>
      </UTable>
    </div>
    <div class="card rounded-xl bg-white p-4 shadow-sm">
      <h3 class="mb-4 text-lg font-semibold text-highlighted">Lịch sử nhận/xuất BTP</h3>
      <p v-if="transactionError" class="text-red-600">Không tải được lịch sử BTP.</p>
      <p v-else-if="!loadingTransactions && !transactions?.length">Chưa có giao dịch BTP</p>
      <UTable
        v-else
        :data="transactions ?? []"
        :columns="transactionColumns"
        :loading="loadingTransactions"
        class="text-sm"
      >
        <template #occurredAt-cell="{ row }">
          {{ dayjs(row.original.occurredAt).format('DD/MM/YYYY HH:mm:ss') }}
        </template>
        <template #eventType-cell="{ row }">
          <UBadge
            :label="eventLabels[row.original.eventType] ?? row.original.eventType"
            :color="eventColors[row.original.eventType] ?? 'neutral'"
            class="text-xs"
          />
        </template>
        <template #kanbanCode-cell="{ row }">
          <RouterLink
            v-if="row.original.kanbanId && row.original.kanbanCode"
            :to="`/kanban/${row.original.kanbanId}`"
            class="font-mono text-sm font-semibold text-primary hover:underline"
            @click.stop
            >{{ row.original.kanbanCode }}
          </RouterLink>
        </template>
        <template #quantity-cell="{ row }"
          >{{ row.original.eventType === 'KANBAN_ISSUED' ? '-' : '+'
          }}{{ fmtQty(row.original.quantity) }}
        </template>
      </UTable>
    </div>
  </div>
</template>
