<script setup lang="ts">
import { ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import MaterialInventoryInfo from './MaterialInventoryInfo.vue'
import BtpInventoryInfo from './BtpInventoryInfo.vue'
import InventoryRequestTab from './InventoryRequestTab.vue'

defineProps<{
  id: string
  styleColorOrder?: string[]
  styleSizeOrder?: string[]
  readOnly?: boolean
}>()

const route = useRoute()
const router = useRouter()

const initialTab = (route.query.subtab as string) || 'npl'
const activeTab = ref(
  ['npl', 'btp', 'return', 'transfer'].includes(initialTab) ? initialTab : 'npl',
)

watch(activeTab, (newTab) => {
  if (route.query.subtab !== newTab) {
    void router.replace({ query: { ...route.query, subtab: newTab } })
  }
})

watch(
  () => route.query.subtab,
  (newSubtab) => {
    const tabVal = newSubtab as string
    if (['npl', 'btp', 'return', 'transfer'].includes(tabVal) && tabVal !== activeTab.value) {
      activeTab.value = tabVal
    }
  },
)

const options = [
  { label: 'Tồn NPL', value: 'npl' },
  { label: 'Tồn BTP', value: 'btp' },
  { label: 'Trả lại', value: 'return' },
  { label: 'Điều chuyển', value: 'transfer' },
]

function onChange(value: string | number) {
  if (value) {
    activeTab.value = String(value)
  }
}
</script>

<template>
  <div class="flex flex-col gap-4">
    <div class="flex items-center justify-between">
      <UTabs
        :model-value="activeTab"
        :items="options"
        :content="false"
        variant="link"
        @update:model-value="onChange"
      />
    </div>

    <div>
      <template v-if="activeTab === 'npl'">
        <MaterialInventoryInfo :id="id" />
      </template>
      <template v-else-if="activeTab === 'btp'">
        <BtpInventoryInfo
          :id="id"
          :style-color-order="styleColorOrder"
          :style-size-order="styleSizeOrder"
        />
      </template>
      <template v-else-if="activeTab === 'return'">
        <InventoryRequestTab :id="id" request-kind="return" :read-only="readOnly" />
      </template>
      <template v-else-if="activeTab === 'transfer'">
        <InventoryRequestTab :id="id" request-kind="transfer" :read-only="readOnly" />
      </template>
    </div>
  </div>
</template>
