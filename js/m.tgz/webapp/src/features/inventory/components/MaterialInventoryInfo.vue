<script setup lang="ts">
import { getMaterialBalanceQuery, getMaterialTransactionsQuery } from '@/api/@pinia/colada.gen'
import { toRef } from 'vue'
import { fmtQty } from '@/shared/utils/fmtQty'
import type { TableColumn } from '@nuxt/ui'
import dayjs from 'dayjs'
import { useQuery } from '@pinia/colada'

const props = defineProps<{
  id: string
}>()

const teamAssignmentId = toRef(props, 'id')

const {
  data: balances,
  isLoading: loadingBalances,
  error: balanceError,
} = useQuery(() => getMaterialBalanceQuery({ path: { id: teamAssignmentId.value } }))
const {
  data: transactions,
  isLoading: loadingTransactions,
  error: transactionError,
} = useQuery(() => getMaterialTransactionsQuery({ path: { id: teamAssignmentId.value } }))

type BalanceRow = NonNullable<typeof balances.value>[number]
type TransactionRow = NonNullable<typeof transactions.value>[number]

const balanceColumns: TableColumn<BalanceRow>[] = [
  { accessorKey: 'article', header: 'Vật tư' },
  { accessorKey: 'alternativeName', header: 'Tên thay thế' },
  { accessorKey: 'uom', header: 'ĐVT' },
  { accessorKey: 'color', header: 'Màu' },
  { accessorKey: 'size', header: 'Cỡ' },
  { id: 'totalReceived', header: 'Luỹ kế thực nhận' },
  { id: 'totalIssued', header: 'Luỹ kế thực xuất' },
  { id: 'balance', header: 'SL tồn' },
  { id: 'supplementQuantity', header: 'SL cần bổ sung' },
  { id: 'status', header: 'Trạng thái' },
  { id: 'isRequired', header: 'NPL bắt buộc' },
]
const transactionColumns: TableColumn<TransactionRow>[] = [
  { id: 'occurredAt', header: 'Thời gian' },
  { id: 'transactionType', header: 'Loại' },
  { id: 'transactionCategory', header: 'Phân loại' },
  { accessorKey: 'article', header: 'Vật tư' },
  { accessorKey: 'uom', header: 'ĐVT' },
  { accessorKey: 'color', header: 'Màu' },
  { accessorKey: 'size', header: 'Cỡ' },
  { id: 'quantity', header: 'Số lượng' },
  { accessorKey: 'counterparty', header: 'Nơi nhận/cấp phát' },
]

function formatDate(dateString: string) {
  return dayjs(dateString).format('DD/MM/YYYY HH:mm:ss')
}

function getCategorySeverity(category?: string | null) {
  if (!category) return 'neutral'
  switch (category.toLowerCase()) {
    case 'trả lại':
      return 'success'
    case 'điều chuyển':
      return 'info'
    case 'kanban':
      return 'warning'
    default:
      return 'neutral'
  }
}
</script>

<template>
  <div class="flex flex-col gap-6">
    <!-- Lũy kế tồn kho -->
    <div class="card rounded-xl bg-white p-4 shadow-sm">
      <h3 class="mb-4 text-lg font-semibold text-highlighted">Luỹ kế tồn kho</h3>
      <p v-if="balanceError" class="text-red-600">Không tải được số dư NPL.</p>
      <p v-else-if="!loadingBalances && !balances?.length">Chưa có giao dịch NPL</p>
      <UTable
        v-else
        :data="balances"
        :columns="balanceColumns"
        :loading="loadingBalances"
        class="text-sm"
      >
        <template #totalReceived-cell="{ row }">{{ fmtQty(row.original.totalReceived) }}</template>
        <template #totalIssued-cell="{ row }">{{ fmtQty(row.original.totalIssued) }}</template>
        <template #balance-cell="{ row }">
          <span
            :class="{
              'font-bold text-red-600': row.original.balance < 0,
              'font-bold text-green-600': row.original.balance > 0,
            }"
          >
            {{ fmtQty(row.original.balance) }}
          </span>
        </template>
        <template #supplementQuantity-cell="{ row }">
          {{ fmtQty(row.original.supplementQuantity) }}
        </template>
        <template #status-cell="{ row }">
          <UBadge
            v-if="row.original.status === 'CẦN BỔ SUNG'"
            label="Cần bổ sung"
            color="error"
            variant="subtle"
          />
          <span v-else>-</span>
        </template>
        <template #isRequired-cell="{ row }">
          <UBadge
            :label="row.original.isRequired !== false ? 'Bắt buộc' : 'Không bắt buộc'"
            :color="row.original.isRequired !== false ? 'neutral' : 'warning'"
            variant="subtle"
          />
        </template>
      </UTable>
    </div>

    <!-- Lịch sử giao dịch -->
    <div class="card rounded-xl bg-white p-4 shadow-sm">
      <h3 class="mb-4 text-lg font-semibold text-highlighted">Lịch sử nhận/xuất vật tư</h3>
      <p v-if="transactionError" class="text-red-600">Không tải được lịch sử NPL.</p>
      <p v-else-if="!loadingTransactions && !transactions?.length">Chưa có giao dịch NPL</p>
      <UTable
        v-else
        :data="transactions"
        :columns="transactionColumns"
        :loading="loadingTransactions"
        class="text-sm"
      >
        <template #occurredAt-cell="{ row }">
          {{ formatDate(row.original.occurredAt) }}
        </template>
        <template #transactionType-cell="{ row }">
          <UBadge
            v-if="row.original.transactionType === 'RECEIVED'"
            label="Nhập kho"
            color="success"
            class="text-xs"
          />
          <UBadge v-else label="Xuất kho" color="error" class="text-xs" />
        </template>
        <template #transactionCategory-cell="{ row }">
          <UBadge
            v-if="row.original.transactionCategory"
            :label="row.original.transactionCategory"
            :color="getCategorySeverity(row.original.transactionCategory)"
            class="text-xs"
          />
        </template>
        <template #quantity-cell="{ row }">{{ fmtQty(row.original.quantity) }}</template>
      </UTable>
    </div>
  </div>
</template>
