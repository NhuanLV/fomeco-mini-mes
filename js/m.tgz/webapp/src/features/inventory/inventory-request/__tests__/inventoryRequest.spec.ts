import type {
  ReturnRequestAssignmentDetailVm,
  ReturnRequestDetailVm,
  TransferRequestAssignmentDetailVm,
  TransferRequestDetailVm,
} from '@/api'
import {
  buildCreateRequest,
  buildReceiveItemsByTarget,
  buildRequestPolicy,
  buildReviseRequest,
  groupReceiveRows,
  normalizeRequest,
  toInventoryFilterRequest,
  type InventoryRequestDraftRow,
} from '@/features/inventory/inventory-request/inventoryRequest'
import { describe, expect, it } from 'vitest'

describe('Inventory Request rules', () => {
  it('normalizes Return and Transfer details into one request shape', () => {
    const returned = normalizeRequest('return', makeReturnDetail())
    const transferred = normalizeRequest('transfer', makeTransferDetail())

    expect(returned).toMatchObject({
      id: 'return-1',
      sourceId: 'source-assignment',
      sourceName: 'Source team',
      items: [
        {
          article: 'Fabric',
          targetId: 'warehouse-1',
          targetName: 'Warehouse',
          targetProductionOrderCode: undefined,
        },
      ],
    })
    expect(transferred).toMatchObject({
      id: 'transfer-1',
      sourceId: 'source-assignment',
      sourceName: 'Source team',
      items: [
        {
          article: 'Fabric',
          targetId: 'target-assignment',
          targetName: 'Target team',
          targetProductionOrderCode: 'LSX-TARGET',
        },
      ],
    })
  })

  it('derives permissions and active receiver targets from request assignments', () => {
    const request = normalizeRequest('return', makeReturnDetail())
    const policy = buildRequestPolicy({
      kind: 'return',
      request,
      hasPermission: (permission, unitId) =>
        permission === 'CREATE_REQUEST' ||
        permission === 'EVALUATE_REQUEST' ||
        (permission === 'RECEIVE_REQUEST' && unitId === 'warehouse-1'),
    })

    expect(policy).toMatchObject({
      canApproveOrReject: true,
      canRevise: false,
      canReceive: false,
    })

    request.status = 'APPROVED'
    const approved = buildRequestPolicy({
      kind: 'return',
      request,
      hasPermission: (permission, unitId) =>
        permission === 'RECEIVE_REQUEST' && unitId === 'warehouse-1',
    })
    expect([...approved.activeAssignmentTargetIds]).toEqual(['warehouse-1'])
    expect(approved.canReceive).toBe(true)
  })

  it('groups receive rows by request, preserves ACTIVE status and builds nested filters', () => {
    const rows: ReturnRequestAssignmentDetailVm[] = [
      makeReturnAssignment('COMPLETED', 'warehouse-1'),
      makeReturnAssignment('ACTIVE', 'warehouse-2'),
    ]

    expect(groupReceiveRows('return', rows)).toEqual([
      expect.objectContaining({ returnRequestId: 'return-1', status: 'ACTIVE' }),
    ])
    expect(
      toInventoryFilterRequest({
        styleName: ['STYLE'],
        productionOrderCode: [],
        requestCode: null,
        statuses: ['APPROVED'],
        teamIds: null,
      }),
    ).toEqual({
      styleName: ['STYLE'],
      productionOrderCode: undefined,
      requestCode: undefined,
      statuses: ['APPROVED'],
      teamIds: undefined,
    })
  })

  it('validates and aggregates Return draft rows by material and receiver', () => {
    const rows = [
      makeDraftRow({ lineId: '1', quantity: 2, targetWarehouseId: 'warehouse-1' }),
      makeDraftRow({ lineId: '2', quantity: 3, targetWarehouseId: 'warehouse-1' }),
      makeDraftRow({ lineId: '3', quantity: 0, targetWarehouseId: '' }),
    ]

    expect(buildCreateRequest('return', 'source-assignment', rows)).toEqual({
      ok: true,
      body: {
        teamAssignmentId: 'source-assignment',
        items: [
          {
            article: 'Fabric',
            color: 'Red',
            size: 'S',
            uom: 'M',
            quantity: 5,
            receiverId: 'warehouse-1',
          },
        ],
      },
    })

    expect(
      buildCreateRequest('return', 'source-assignment', [
        makeDraftRow({ quantity: 1, targetWarehouseId: '' }),
      ]),
    ).toEqual({ ok: false, error: 'Vui lòng chọn nơi nhận cho Fabric' })
  })

  it('validates and aggregates Transfer draft rows by target assignment', () => {
    const rows = [
      makeDraftRow({
        lineId: '1',
        quantity: 2,
        targetTeamId: 'team-1',
        targetTeamAssignmentId: 'target-assignment',
      }),
      makeDraftRow({
        lineId: '2',
        quantity: 3,
        targetTeamId: 'team-1',
        targetTeamAssignmentId: 'target-assignment',
      }),
    ]

    expect(buildCreateRequest('transfer', 'source-assignment', rows)).toEqual({
      ok: true,
      body: {
        sourceTeamAssignmentId: 'source-assignment',
        items: [
          {
            targetTeamAssignmentId: 'target-assignment',
            article: 'Fabric',
            color: 'Red',
            size: 'S',
            uom: 'M',
            quantity: 5,
          },
        ],
      },
    })

    expect(
      buildCreateRequest('transfer', 'source-assignment', [
        makeDraftRow({ quantity: 11, targetTeamAssignmentId: 'target-assignment' }),
      ]),
    ).toEqual({
      ok: false,
      error: 'Tổng số lượng điều chuyển vượt quá số lượng dư thừa',
    })
  })

  it('builds receive groups and revise bodies for both request kinds', () => {
    const returned = normalizeRequest('return', makeReturnDetail())
    const transferred = normalizeRequest('transfer', makeTransferDetail())

    expect(buildReceiveItemsByTarget(returned.items, new Set(['warehouse-1']))).toEqual({
      'warehouse-1': [{ article: 'Fabric', color: 'Red', size: 'S', quantity: 5 }],
    })
    expect(buildReviseRequest('return', returned, returned.items)).toEqual({
      teamAssignmentId: 'source-assignment',
      items: [
        {
          receiverId: 'warehouse-1',
          article: 'Fabric',
          color: 'Red',
          size: 'S',
          uom: 'M',
          quantity: 5,
        },
      ],
    })
    expect(buildReviseRequest('transfer', transferred, transferred.items)).toEqual({
      sourceTeamAssignmentId: 'source-assignment',
      items: [
        {
          targetTeamAssignmentId: 'target-assignment',
          article: 'Fabric',
          color: 'Red',
          size: 'S',
          uom: 'M',
          quantity: 5,
        },
      ],
    })
  })
})

function makeReturnDetail(): ReturnRequestDetailVm {
  return {
    id: 'return-1',
    teamAssignmentId: 'source-assignment',
    status: 'PENDING_APPROVAL',
    items: [
      {
        article: 'Fabric',
        color: 'Red',
        size: 'S',
        uom: 'M',
        quantity: 5,
        receiverId: 'warehouse-1',
        receiverName: 'Warehouse',
      },
    ],
    createdAt: '2026-07-20',
    createdById: 'user-1',
    createdByName: 'User',
    sourceName: 'Source team',
    assignments: [makeReturnAssignment('ACTIVE', 'warehouse-1')],
  }
}

function makeTransferDetail(): TransferRequestDetailVm {
  return {
    id: 'transfer-1',
    sourceTeamAssignmentId: 'source-assignment',
    status: 'REJECTED',
    items: [
      {
        article: 'Fabric',
        color: 'Red',
        size: 'S',
        uom: 'M',
        quantity: 5,
        targetTeamAssignmentId: 'target-assignment',
        targetTeamName: 'Target team',
        targetProductionOrderCode: 'LSX-TARGET',
      },
    ],
    createdAt: '2026-07-20',
    createdById: 'user-1',
    createdByName: 'User',
    sourceName: 'Source team',
    assignments: [makeTransferAssignment('ACTIVE')],
  }
}

function makeReturnAssignment(
  status: ReturnRequestAssignmentDetailVm['status'],
  receiverId: string,
): ReturnRequestAssignmentDetailVm {
  return {
    returnRequestId: 'return-1',
    returnCode: 'RETURN-1',
    styleName: 'STYLE',
    productionOrderCode: 'LSX-1',
    receiverId,
    receiverName: receiverId,
    status,
    items: [],
  }
}

function makeTransferAssignment(
  status: TransferRequestAssignmentDetailVm['status'],
): TransferRequestAssignmentDetailVm {
  return {
    transferRequestId: 'transfer-1',
    transferCode: 'TRANSFER-1',
    styleName: 'STYLE',
    productionOrderCode: 'LSX-1',
    targetTeamAssignmentId: 'target-assignment',
    targetTeamName: 'Target team',
    targetTeamId: 'team-1',
    status,
    items: [],
  }
}

function makeDraftRow(overrides: Partial<InventoryRequestDraftRow> = {}): InventoryRequestDraftRow {
  return {
    lineId: 'line-1',
    materialKey: 'Fabric::Red::S',
    article: 'Fabric',
    color: 'Red',
    size: 'S',
    uom: 'M',
    excessQuantity: 10,
    quantity: 5,
    targetWarehouseId: '',
    targetTeamId: undefined,
    targetTeamAssignmentId: '',
    ...overrides,
  }
}
