import type {
  CreateReturnRequestCommand,
  CreateTransferRequestCommand,
  InventoryFilterRequest,
  PermissionVm,
  ReceivedItemCmd,
  ReturnRequestAssignmentDetailVm,
  ReturnRequestDetailVm,
  ReturnRequestSummaryVm,
  TransferRequestAssignmentDetailVm,
  TransferRequestDetailVm,
  TransferRequestSummaryVm,
} from '@/api'

export type InventoryRequestKind = 'return' | 'transfer'
export type InventoryRequestStatus = 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'COMPLETED'

export type NormalizedInventoryRequestItem = {
  article: string
  color: string
  size: string
  uom: string
  quantity: number
  targetId: string
  targetName: string
  targetProductionOrderCode?: string
}

export type NormalizedInventoryRequest = {
  id: string
  status: InventoryRequestStatus
  sourceId: string
  sourceName: string
  items: NormalizedInventoryRequestItem[]
  rejectReason?: string | null
  createdAt: string
  createdById: string
  createdByName: string
  assignments:
    | Array<ReturnRequestAssignmentDetailVm>
    | Array<TransferRequestAssignmentDetailVm>
    | null
}

export type InventoryRequestDraftRow = {
  lineId: string
  materialKey: string
  article: string
  color: string
  size: string
  uom: string
  excessQuantity: number
  quantity: number
  targetWarehouseId: string
  targetTeamId?: string
  targetTeamAssignmentId: string
}

type HasPermission = (code: PermissionVm['code'], unitId?: string) => boolean

export function normalizeRequest(
  kind: 'return',
  detail: ReturnRequestDetailVm,
): NormalizedInventoryRequest
export function normalizeRequest(
  kind: 'transfer',
  detail: TransferRequestDetailVm,
): NormalizedInventoryRequest
export function normalizeRequest(
  kind: InventoryRequestKind,
  detail: ReturnRequestDetailVm | TransferRequestDetailVm,
): NormalizedInventoryRequest {
  if (kind === 'transfer') {
    const transfer = detail as TransferRequestDetailVm
    return {
      id: transfer.id,
      status: transfer.status,
      sourceId: transfer.sourceTeamAssignmentId,
      sourceName: transfer.sourceName || transfer.sourceTeamAssignmentId,
      items: transfer.items.map((item) => ({
        article: item.article,
        color: item.color,
        size: item.size,
        uom: item.uom,
        quantity: item.quantity,
        targetId: item.targetTeamAssignmentId,
        targetName: item.targetTeamName,
        targetProductionOrderCode: item.targetProductionOrderCode,
      })),
      rejectReason: transfer.rejectReason,
      createdAt: transfer.createdAt,
      createdById: transfer.createdById,
      createdByName: transfer.createdByName,
      assignments: transfer.assignments ?? null,
    }
  }

  const returned = detail as ReturnRequestDetailVm
  return {
    id: returned.id,
    status: returned.status,
    sourceId: returned.teamAssignmentId,
    sourceName: returned.sourceName || returned.teamAssignmentId,
    items: returned.items.map((item) => ({
      article: item.article,
      color: item.color,
      size: item.size,
      uom: item.uom,
      quantity: item.quantity,
      targetId: item.receiverId,
      targetName: item.receiverName,
      targetProductionOrderCode: undefined,
    })),
    rejectReason: returned.rejectReason,
    createdAt: returned.createdAt,
    createdById: returned.createdById,
    createdByName: returned.createdByName,
    assignments: returned.assignments ?? null,
  }
}

export function buildRequestPolicy(params: {
  kind: InventoryRequestKind
  request: NormalizedInventoryRequest
  hasPermission: HasPermission
}) {
  const assignments = params.request.assignments ?? []
  const myAssignments = assignments.filter((assignment) => {
    if (params.kind === 'transfer') {
      const transfer = assignment as TransferRequestAssignmentDetailVm
      return (
        !!transfer.targetTeamId && params.hasPermission('RECEIVE_REQUEST', transfer.targetTeamId)
      )
    }
    const returned = assignment as ReturnRequestAssignmentDetailVm
    return params.hasPermission('RECEIVE_REQUEST', returned.receiverId)
  })
  const activeAssignmentTargetIds = new Set(
    myAssignments
      .filter((assignment) => assignment.status === 'ACTIVE')
      .map((assignment) =>
        params.kind === 'transfer'
          ? (assignment as TransferRequestAssignmentDetailVm).targetTeamAssignmentId
          : (assignment as ReturnRequestAssignmentDetailVm).receiverId,
      ),
  )

  return {
    myAssignments,
    activeAssignmentTargetIds,
    canApproveOrReject:
      params.request.status === 'PENDING_APPROVAL' && params.hasPermission('EVALUATE_REQUEST'),
    canRevise: params.request.status === 'REJECTED' && params.hasPermission('CREATE_REQUEST'),
    canReceive: params.request.status === 'APPROVED' && activeAssignmentTargetIds.size > 0,
  }
}

export function toInventoryFilterRequest(filters: InventoryFilterRequest): InventoryFilterRequest {
  return {
    styleName: nonEmpty(filters.styleName),
    productionOrderCode: nonEmpty(filters.productionOrderCode),
    requestCode: nonEmpty(filters.requestCode),
    statuses: nonEmpty(filters.statuses),
    teamIds: nonEmpty(filters.teamIds),
  }
}

export function groupReceiveRows(
  kind: 'return',
  rows: ReturnRequestAssignmentDetailVm[],
): ReturnRequestAssignmentDetailVm[]
export function groupReceiveRows(
  kind: 'transfer',
  rows: TransferRequestAssignmentDetailVm[],
): TransferRequestAssignmentDetailVm[]
export function groupReceiveRows(
  kind: InventoryRequestKind,
  rows: Array<ReturnRequestAssignmentDetailVm | TransferRequestAssignmentDetailVm>,
) {
  const grouped = new Map<
    string,
    ReturnRequestAssignmentDetailVm | TransferRequestAssignmentDetailVm
  >()
  for (const row of rows) {
    const id =
      kind === 'transfer'
        ? (row as TransferRequestAssignmentDetailVm).transferRequestId
        : (row as ReturnRequestAssignmentDetailVm).returnRequestId
    const current = grouped.get(id)
    if (!current) {
      grouped.set(id, { ...row })
    } else if (current.status === 'COMPLETED' && row.status === 'ACTIVE') {
      current.status = 'ACTIVE'
    }
  }
  return [...grouped.values()]
}

export function buildReceiveItemsByTarget(
  items: NormalizedInventoryRequestItem[],
  activeTargetIds: Set<string>,
) {
  const result: Record<string, ReceivedItemCmd[]> = {}
  for (const item of items) {
    if (!activeTargetIds.has(item.targetId)) continue
    const targetItems = result[item.targetId] ?? []
    targetItems.push({
      article: item.article,
      color: item.color,
      size: item.size,
      quantity: item.quantity,
    })
    result[item.targetId] = targetItems
  }
  return result
}

export function buildReviseRequest(
  kind: InventoryRequestKind,
  request: NormalizedInventoryRequest,
  items: NormalizedInventoryRequestItem[],
): CreateReturnRequestCommand | CreateTransferRequestCommand {
  if (kind === 'transfer') {
    return {
      sourceTeamAssignmentId: request.sourceId,
      items: items.map((item) => ({
        targetTeamAssignmentId: item.targetId,
        article: item.article,
        color: item.color,
        size: item.size,
        uom: item.uom,
        quantity: Number(item.quantity),
      })),
    }
  }
  return {
    teamAssignmentId: request.sourceId,
    items: items.map((item) => ({
      receiverId: item.targetId,
      article: item.article,
      color: item.color,
      size: item.size,
      uom: item.uom,
      quantity: Number(item.quantity),
    })),
  }
}

export function buildCreateRequest(
  kind: InventoryRequestKind,
  sourceTeamAssignmentId: string,
  draftRows: InventoryRequestDraftRow[],
):
  | { ok: false; error: string }
  | { ok: true; body: CreateReturnRequestCommand | CreateTransferRequestCommand } {
  const rows = draftRows.filter((row) => row.quantity > 0)
  if (rows.length === 0) {
    return {
      ok: false,
      error: `Không có dữ liệu ${kind === 'return' ? 'trả lại' : 'điều chuyển'} hợp lệ`,
    }
  }

  for (const row of rows) {
    if (kind === 'return' && !row.targetWarehouseId) {
      return { ok: false, error: `Vui lòng chọn nơi nhận cho ${row.article}` }
    }
    if (kind === 'transfer' && !row.targetTeamAssignmentId) {
      return { ok: false, error: `Vui lòng chọn tổ nhận cho ${row.article}` }
    }
  }

  const totals = new Map<string, { total: number; max: number }>()
  for (const row of rows) {
    const current = totals.get(row.materialKey) ?? {
      total: 0,
      max: row.excessQuantity,
    }
    current.total += row.quantity
    totals.set(row.materialKey, current)
  }
  if ([...totals.values()].some(({ total, max }) => total > max)) {
    return {
      ok: false,
      error: `Tổng số lượng ${kind === 'return' ? 'trả lại' : 'điều chuyển'} vượt quá số lượng dư thừa`,
    }
  }

  if (kind === 'return') {
    const items = new Map<string, CreateReturnRequestCommand['items'][number]>()
    for (const row of rows) {
      const key = `${row.article}-${row.color || ''}-${row.size || ''}-${row.targetWarehouseId}`
      const current = items.get(key)
      if (current) {
        current.quantity += row.quantity
      } else {
        items.set(key, {
          article: row.article,
          color: row.color || '',
          size: row.size || '',
          uom: row.uom,
          quantity: row.quantity,
          receiverId: row.targetWarehouseId,
        })
      }
    }
    return {
      ok: true,
      body: {
        teamAssignmentId: sourceTeamAssignmentId,
        items: [...items.values()],
      },
    }
  }

  const items = new Map<string, CreateTransferRequestCommand['items'][number]>()
  for (const row of rows) {
    const key = `${row.targetTeamAssignmentId}::${row.article}::${row.color}::${row.size}`
    const current = items.get(key)
    if (current) {
      current.quantity += row.quantity
    } else {
      items.set(key, {
        targetTeamAssignmentId: row.targetTeamAssignmentId,
        article: row.article,
        color: row.color || '',
        size: row.size || '',
        uom: row.uom,
        quantity: row.quantity,
      })
    }
  }
  return {
    ok: true,
    body: {
      sourceTeamAssignmentId,
      items: [...items.values()],
    },
  }
}

export function getInventoryRequestStatusLabel(status: string) {
  switch (status) {
    case 'PENDING_APPROVAL':
      return 'Chờ duyệt'
    case 'APPROVED':
      return 'Đã duyệt / Chờ nhận'
    case 'REJECTED':
      return 'Đã từ chối'
    case 'COMPLETED':
      return 'Đã nhận'
    default:
      return status
  }
}

export function getInventoryRequestStatusSeverity(status: string) {
  switch (status) {
    case 'PENDING_APPROVAL':
      return 'warning'
    case 'APPROVED':
      return 'info'
    case 'REJECTED':
      return 'error'
    case 'COMPLETED':
      return 'success'
    default:
      return 'info'
  }
}

export type InventoryListRow =
  | ReturnRequestSummaryVm
  | TransferRequestSummaryVm
  | ReturnRequestAssignmentDetailVm
  | TransferRequestAssignmentDetailVm

function nonEmpty(value: string[] | null | undefined) {
  return value?.length ? value : undefined
}
