import {
  findReturnRequestAssignmentsForReceiverQuery,
  findReturnRequestsCreatedByActorQuery,
  findReturnRequestsPendingEvaluationQuery,
  findTransferRequestAssignmentsForReceiverQuery,
  findTransferRequestsCreatedByActorQuery,
  findTransferRequestsPendingEvaluationQuery,
  getReturnRequestCountersQuery,
  getReturnRequestFilterOptionsQuery,
  getTransferRequestCountersQuery,
  getTransferRequestFilterOptionsQuery,
} from '@/api/@pinia/colada.gen'
import type {
  InventoryFilterOptionsVm,
  PermissionVm,
  ReturnRequestAssignmentDetailVm,
  TransferRequestAssignmentDetailVm,
} from '@/api'
import { useQuery } from '@pinia/colada'
import type { TablePageEvent } from '@/shared/types/table'
import {
  computed,
  type ComputedRef,
  onMounted,
  reactive,
  type Ref,
  shallowRef,
  unref,
  watch,
} from 'vue'
import {
  getInventoryRequestStatusLabel,
  getInventoryRequestStatusSeverity,
  groupReceiveRows,
  toInventoryFilterRequest,
  type InventoryListRow,
  type InventoryRequestKind,
} from './inventoryRequest'

export type { InventoryRequestKind } from './inventoryRequest'

type PermissionCode = PermissionVm['code']
export type InventoryTab = 'created' | 'evaluate' | 'receive'
const EMPTY_FILTER_OPTIONS: InventoryFilterOptionsVm = {
  styleNames: [],
  productionOrderCodes: [],
  requestCodes: [],
  teams: [],
}

import { useRoute, useRouter } from 'vue-router'

const VALID_INVENTORY_TABS: InventoryTab[] = ['created', 'evaluate', 'receive']

export function useInventoryRequestList(
  hasPermission: (code: PermissionCode, unitId?: string) => boolean,
  showReceiveTab: Ref<boolean> | ComputedRef<boolean>,
  requestKind: Ref<InventoryRequestKind>,
) {
  const route = useRoute()
  const router = useRouter()

  const initialTab = route?.query?.tab as InventoryTab | undefined
  const activeTab = shallowRef<InventoryTab>(
    initialTab && VALID_INVENTORY_TABS.includes(initialTab) ? initialTab : 'created',
  )

  watch([activeTab, requestKind], ([newTab, newKind]) => {
    if (route?.query?.tab !== newTab || route?.query?.type !== newKind) {
      void router?.replace({ query: { ...route.query, tab: newTab, type: newKind } })
    }
  })

  if (route) {
    watch(
      () => route.query,
      (newQuery) => {
        const tabVal = newQuery.tab as InventoryTab
        if (VALID_INVENTORY_TABS.includes(tabVal) && tabVal !== activeTab.value) {
          activeTab.value = tabVal
        }
        const typeVal = newQuery.type as InventoryRequestKind
        if ((typeVal === 'return' || typeVal === 'transfer') && typeVal !== requestKind.value) {
          requestKind.value = typeVal
        }
      },
    )
  }

  const filters = reactive({
    page: 0,
    size: 20,
    styleName: [] as string[],
    productionOrderCode: [] as string[],
    requestCode: [] as string[],
    statuses: [] as string[],
    teamIds: [] as string[],
  })

  const filterRequest = computed(() => toInventoryFilterRequest(filters))
  const listQuery = computed(() => ({
    filterReq: filterRequest.value,
    page: filters.page,
    size: filters.size,
  }))

  watch(
    () => [
      filters.styleName,
      filters.productionOrderCode,
      filters.requestCode,
      filters.statuses,
      filters.teamIds,
    ],
    () => {
      filters.page = 0
    },
  )

  const { data: returnCreatedResponse, isPending: returnCreatedPending } = useQuery(() => ({
    ...findReturnRequestsCreatedByActorQuery({ query: listQuery.value }),
    enabled:
      activeTab.value === 'created' &&
      requestKind.value === 'return' &&
      hasPermission('CREATE_REQUEST'),
  }))
  const { data: returnEvaluateResponse, isPending: returnEvaluatePending } = useQuery(() => ({
    ...findReturnRequestsPendingEvaluationQuery({ query: listQuery.value }),
    enabled:
      activeTab.value === 'evaluate' &&
      requestKind.value === 'return' &&
      hasPermission('EVALUATE_REQUEST'),
  }))
  const { data: returnReceiveResponse, isPending: returnReceivePending } = useQuery(() => ({
    ...findReturnRequestAssignmentsForReceiverQuery({ query: listQuery.value }),
    enabled:
      activeTab.value === 'receive' && requestKind.value === 'return' && unref(showReceiveTab),
  }))
  const { data: transferCreatedResponse, isPending: transferCreatedPending } = useQuery(() => ({
    ...findTransferRequestsCreatedByActorQuery({ query: listQuery.value }),
    enabled:
      activeTab.value === 'created' &&
      requestKind.value === 'transfer' &&
      hasPermission('CREATE_REQUEST'),
  }))
  const { data: transferEvaluateResponse, isPending: transferEvaluatePending } = useQuery(() => ({
    ...findTransferRequestsPendingEvaluationQuery({ query: listQuery.value }),
    enabled:
      activeTab.value === 'evaluate' &&
      requestKind.value === 'transfer' &&
      hasPermission('EVALUATE_REQUEST'),
  }))
  const { data: transferReceiveResponse, isPending: transferReceivePending } = useQuery(() => ({
    ...findTransferRequestAssignmentsForReceiverQuery({ query: listQuery.value }),
    enabled:
      activeTab.value === 'receive' && requestKind.value === 'transfer' && unref(showReceiveTab),
  }))

  const { data: returnFilterOptions } = useQuery(() => ({
    ...getReturnRequestFilterOptionsQuery({ query: { tab: activeTab.value } }),
    enabled: requestKind.value === 'return',
  }))
  const { data: transferFilterOptions } = useQuery(() => ({
    ...getTransferRequestFilterOptionsQuery({ query: { tab: activeTab.value } }),
    enabled: requestKind.value === 'transfer',
  }))
  const { data: returnCounters } = useQuery(() => ({
    ...getReturnRequestCountersQuery({ query: { filterReq: filterRequest.value } }),
    enabled: requestKind.value === 'return',
  }))
  const { data: transferCounters } = useQuery(() => ({
    ...getTransferRequestCountersQuery({ query: { filterReq: filterRequest.value } }),
    enabled: requestKind.value === 'transfer',
  }))

  const currentResponse = computed(() => {
    if (requestKind.value === 'return') {
      if (activeTab.value === 'created') return returnCreatedResponse.value
      if (activeTab.value === 'evaluate') return returnEvaluateResponse.value
      return returnReceiveResponse.value
    }
    if (activeTab.value === 'created') return transferCreatedResponse.value
    if (activeTab.value === 'evaluate') return transferEvaluateResponse.value
    return transferReceiveResponse.value
  })

  const loading = computed(() => {
    if (requestKind.value === 'return') {
      if (activeTab.value === 'created') return returnCreatedPending.value
      if (activeTab.value === 'evaluate') return returnEvaluatePending.value
      return returnReceivePending.value
    }
    if (activeTab.value === 'created') return transferCreatedPending.value
    if (activeTab.value === 'evaluate') return transferEvaluatePending.value
    return transferReceivePending.value
  })

  const filterOptions = computed(
    () =>
      (requestKind.value === 'return' ? returnFilterOptions.value : transferFilterOptions.value) ??
      EMPTY_FILTER_OPTIONS,
  )
  const counters = computed(() => {
    const data = requestKind.value === 'return' ? returnCounters.value : transferCounters.value
    return {
      created: data?.created ?? 0,
      evaluate: data?.evaluate ?? 0,
      receive: data?.receive ?? 0,
    }
  })
  const isCreatedTab = computed(() => activeTab.value === 'created')
  const isEvaluateTab = computed(() => activeTab.value === 'evaluate')
  const isReceiveTab = computed(() => activeTab.value === 'receive')
  const isReturnKind = computed(() => requestKind.value === 'return')
  const requestTypeLabel = computed(() => (isReturnKind.value ? 'Trả lại' : 'Điều chuyển'))
  const requestTypeSeverity = computed(() => (isReturnKind.value ? 'success' : 'info'))
  const tableData = computed<InventoryListRow[]>(() => {
    const data = (currentResponse.value?.content ?? []) as InventoryListRow[]
    if (!isReceiveTab.value) return data
    return requestKind.value === 'return'
      ? groupReceiveRows('return', data as ReturnRequestAssignmentDetailVm[])
      : groupReceiveRows('transfer', data as TransferRequestAssignmentDetailVm[])
  })
  const totalRecords = computed(() => currentResponse.value?.page?.totalElements ?? 0)

  watch([activeTab, requestKind], () => {
    filters.page = 0
  })

  function handlePageChange(event: TablePageEvent) {
    filters.page = event.page || 0
    filters.size = event.rows
  }

  function clearFilters() {
    filters.styleName = []
    filters.productionOrderCode = []
    filters.requestCode = []
    filters.statuses = []
    filters.teamIds = []
  }

  function requestIdForRow(row: InventoryListRow) {
    if (!isReceiveTab.value) return 'id' in row ? row.id : ''
    if (requestKind.value === 'return') {
      return 'returnRequestId' in row ? row.returnRequestId : ''
    }
    return 'transferRequestId' in row ? row.transferRequestId : ''
  }

  onMounted(() => {
    if (!hasPermission('CREATE_REQUEST')) {
      if (hasPermission('EVALUATE_REQUEST')) {
        activeTab.value = 'evaluate'
      } else if (unref(showReceiveTab)) {
        activeTab.value = 'receive'
      }
    }
  })

  return {
    activeTab,
    filters,
    tableData,
    totalRecords,
    loading,
    handlePageChange,
    counters,
    filterOptions,
    statusOptions: [
      { label: 'Chờ duyệt', value: 'PENDING_APPROVAL' },
      { label: 'Đã duyệt / Chờ nhận', value: 'APPROVED' },
      { label: 'Đã từ chối', value: 'REJECTED' },
      { label: 'Đã nhận', value: 'COMPLETED' },
    ],
    clearFilters,
    isCreatedTab,
    isEvaluateTab,
    isReceiveTab,
    isReturnKind,
    requestTypeLabel,
    requestTypeSeverity,
    requestIdForRow,
    getStatusLabel: getInventoryRequestStatusLabel,
    getStatusSeverity: getInventoryRequestStatusSeverity,
  }
}
