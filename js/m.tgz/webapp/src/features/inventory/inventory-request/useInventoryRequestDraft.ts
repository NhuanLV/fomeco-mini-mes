import type {
  CreateReturnRequestCommand,
  CreateTransferRequestCommand,
  ExcessMaterialVm,
  TransferTargetCandidateVm,
} from '@/api'
import { findTargetCandidates } from '@/api'
import {
  createReturnRequestMutation,
  createTransferRequestMutation,
  getExcessMaterialsQuery,
  getTeamAssignmentDetailQuery,
  getWarehousesByCompanyQuery,
} from '@/api/@pinia/colada.gen'
import { ROUTE_PATH } from '@/app/router/path'
import { showError, showSuccess, showWarn } from '@/shared/utils/toast'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import {
  buildCreateRequest,
  type InventoryRequestDraftRow,
  type InventoryRequestKind,
} from './inventoryRequest'

export function useInventoryRequestDraft(props: { id: string; requestKind: InventoryRequestKind }) {
  const queryCache = useQueryCache()
  const router = useRouter()
  const isReturnKind = computed(() => props.requestKind === 'return')

  const { data: teamAssignment } = useQuery(() =>
    getTeamAssignmentDetailQuery({ path: { id: props.id } }),
  )
  const companyId = computed(() => teamAssignment.value?.companyId)
  const { data: excessMaterials, isLoading: isExcessLoading } = useQuery(() =>
    getExcessMaterialsQuery({ path: { id: props.id } }),
  )
  const { data: warehouses, isLoading: isWarehousesLoading } = useQuery(() => ({
    ...getWarehousesByCompanyQuery({ path: { companyId: companyId.value! } }),
    enabled: !!companyId.value && isReturnKind.value,
  }))

  const warehouseOptions = computed(
    () =>
      warehouses.value?.map((w) => ({ label: w.name, value: w.id, name: w.name, id: w.id })) ?? [],
  )
  const nplMaterials = computed(
    () => excessMaterials.value?.filter((material) => !material.article.startsWith('BTP ')) ?? [],
  )
  const selectedMaterials = ref<ExcessMaterialVm[]>([])
  const showCreateDialog = ref(false)
  const draftRows = ref<InventoryRequestDraftRow[]>([])
  const candidatesByMaterial = ref<Record<string, TransferTargetCandidateVm[]>>({})
  const isLoadingCandidates = ref(false)

  const { mutateAsync: createReturnRequest, isLoading: isCreatingReturn } = useMutation(
    createReturnRequestMutation(),
  )
  const { mutateAsync: createTransferRequest, isLoading: isCreatingTransfer } = useMutation(
    createTransferRequestMutation(),
  )
  const isCreating = computed(() => isCreatingReturn.value || isCreatingTransfer.value)

  function onSelectedRowsChange(rows: ExcessMaterialVm[]) {
    selectedMaterials.value = rows
  }

  async function openCreateDialog() {
    if (selectedMaterials.value.length === 0) {
      showWarn('Chưa chọn vật tư nào')
      return
    }

    showCreateDialog.value = true
    draftRows.value = selectedMaterials.value.map((material, index) =>
      buildDraftRow(material, index),
    )
    if (isReturnKind.value) return

    isLoadingCandidates.value = true
    try {
      const entries = await Promise.all(
        selectedMaterials.value.map(async (material) => {
          const { data } = await findTargetCandidates({
            path: { sourceId: props.id },
            query: {
              article: material.article,
              color: material.color || '',
              size: material.size || '',
            },
            throwOnError: true,
          })
          return [materialKey(material), data ?? []] as const
        }),
      )
      candidatesByMaterial.value = Object.fromEntries(entries)
    } catch (error) {
      showError(error instanceof Error ? error.message : 'Lỗi khi tải tổ nhận')
    } finally {
      isLoadingCandidates.value = false
    }
  }

  function getTeamOptions(row: InventoryRequestDraftRow) {
    const teams = new Map<string, { teamId: string; teamName: string }>()
    for (const candidate of candidatesByMaterial.value[row.materialKey] ?? []) {
      if (!teams.has(candidate.teamId)) {
        teams.set(candidate.teamId, {
          teamId: candidate.teamId,
          teamName: candidate.teamName,
        })
      }
    }
    return [...teams.values()]
  }

  function getLcdOptions(row: InventoryRequestDraftRow) {
    if (!row.targetTeamId) return []
    return (candidatesByMaterial.value[row.materialKey] ?? []).filter(
      (candidate) => candidate.teamId === row.targetTeamId,
    )
  }

  function onTeamChange(row: InventoryRequestDraftRow) {
    const assignments = getLcdOptions(row)
    row.targetTeamAssignmentId = assignments.length === 1 ? assignments[0].teamAssignmentId : ''
  }

  function addSplitRow(row: InventoryRequestDraftRow) {
    draftRows.value = [
      ...draftRows.value,
      {
        ...row,
        lineId: `${row.materialKey}::${Date.now()}`,
        quantity: 0,
        targetWarehouseId: '',
        targetTeamId: undefined,
        targetTeamAssignmentId: '',
      },
    ]
  }

  function removeDraftRow(lineId: string) {
    draftRows.value = draftRows.value.filter((row) => row.lineId !== lineId)
  }

  async function submitRequest() {
    const request = buildCreateRequest(props.requestKind, props.id, draftRows.value)
    if (!request.ok) {
      showError(request.error)
      return
    }

    try {
      if (props.requestKind === 'return') {
        await createReturnRequest({
          body: request.body as CreateReturnRequestCommand,
        })
      } else {
        await createTransferRequest({
          body: request.body as CreateTransferRequestCommand,
        })
      }
      showSuccess(`Tạo yêu cầu ${isReturnKind.value ? 'trả lại' : 'điều chuyển'} thành công`)
      showCreateDialog.value = false
      selectedMaterials.value = []
      void queryCache.invalidateQueries({ key: ['getExcessMaterials'] })
      void router.push({
        path: ROUTE_PATH.INVENTORY,
        query: { type: props.requestKind },
      })
    } catch (error) {
      showError(
        error instanceof Error
          ? error.message
          : `Tạo yêu cầu ${isReturnKind.value ? 'trả lại' : 'điều chuyển'} thất bại`,
      )
    }
  }

  return {
    isReturnKind,
    nplMaterials,
    isExcessLoading,
    warehouseOptions,
    isWarehousesLoading,
    selectedMaterials,
    showCreateDialog,
    draftRows,
    isLoadingCandidates,
    isCreating,
    onSelectedRowsChange,
    openCreateDialog,
    getTeamOptions,
    getLcdOptions,
    onTeamChange,
    addSplitRow,
    removeDraftRow,
    submitRequest,
  }
}

function materialKey(material: Pick<ExcessMaterialVm, 'article' | 'color' | 'size'>) {
  return `${material.article}::${material.color}::${material.size}`
}

function buildDraftRow(material: ExcessMaterialVm, index: number): InventoryRequestDraftRow {
  return {
    lineId: `${materialKey(material)}::${Date.now()}::${index}`,
    materialKey: materialKey(material),
    article: material.article,
    color: material.color,
    size: material.size,
    uom: material.uom,
    excessQuantity: material.excessQuantity,
    quantity: material.excessQuantity,
    targetWarehouseId: '',
    targetTeamId: undefined,
    targetTeamAssignmentId: '',
  }
}
