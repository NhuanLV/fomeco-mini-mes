import type { CreateReturnRequestCommand, CreateTransferRequestCommand, PermissionVm } from '@/api'
import {
  approveReturnRequestMutation,
  approveTransferRequestMutation,
  getReturnRequestHistoryQueryKey,
  getReturnRequestQuery,
  getReturnRequestQueryKey,
  getTransferRequestHistoryQueryKey,
  getTransferRequestQuery,
  getTransferRequestQueryKey,
  receiveReturnMaterialForAssignmentMutation,
  receiveTransferMaterialForAssignmentMutation,
  rejectReturnRequestMutation,
  rejectTransferRequestMutation,
  reviseReturnRequestMutation,
  reviseTransferRequestMutation,
} from '@/api/@pinia/colada.gen'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import { computed, type ComputedRef, ref, watch } from 'vue'
import {
  buildReceiveItemsByTarget,
  buildRequestPolicy,
  buildReviseRequest,
  getInventoryRequestStatusLabel,
  getInventoryRequestStatusSeverity,
  normalizeRequest,
  type InventoryRequestKind,
  type NormalizedInventoryRequestItem,
} from './inventoryRequest'

type HasPermission = (code: PermissionVm['code'], unitId?: string) => boolean

export function useInventoryRequestDetail(options: {
  requestId: string
  requestKind: ComputedRef<InventoryRequestKind>
  hasPermission: HasPermission
}) {
  const queryCache = useQueryCache()
  const isTransferRequest = computed(() => options.requestKind.value === 'transfer')

  const returnQuery = useQuery(() => ({
    ...getReturnRequestQuery({ path: { id: options.requestId } }),
    enabled: options.requestKind.value === 'return',
  }))
  const transferQuery = useQuery(() => ({
    ...getTransferRequestQuery({ path: { id: options.requestId } }),
    enabled: options.requestKind.value === 'transfer',
  }))
  const isLoading = computed(
    () =>
      (options.requestKind.value === 'return'
        ? returnQuery.isLoading.value
        : transferQuery.isLoading.value) ?? false,
  )
  const normalizedData = computed(() => {
    if (options.requestKind.value === 'transfer') {
      return transferQuery.data.value
        ? normalizeRequest('transfer', transferQuery.data.value)
        : null
    }
    return returnQuery.data.value ? normalizeRequest('return', returnQuery.data.value) : null
  })
  const policy = computed(() =>
    normalizedData.value
      ? buildRequestPolicy({
          kind: options.requestKind.value,
          request: normalizedData.value,
          hasPermission: options.hasPermission,
        })
      : null,
  )
  const isReviseMode = computed(() => policy.value?.canRevise ?? false)
  const canApproveOrReject = computed(() => policy.value?.canApproveOrReject ?? false)
  const canReceive = computed(() => policy.value?.canReceive ?? false)

  const { mutateAsync: approveTransferReq, isLoading: isApprovingTransfer } = useMutation(
    approveTransferRequestMutation(),
  )
  const { mutateAsync: approveReturnReq, isLoading: isApprovingReturn } = useMutation(
    approveReturnRequestMutation(),
  )
  const { mutateAsync: rejectTransferReq, isLoading: isRejectingTransfer } = useMutation(
    rejectTransferRequestMutation(),
  )
  const { mutateAsync: rejectReturnReq, isLoading: isRejectingReturn } = useMutation(
    rejectReturnRequestMutation(),
  )
  const { mutateAsync: receiveTransfer, isLoading: isReceivingTransfer } = useMutation(
    receiveTransferMaterialForAssignmentMutation(),
  )
  const { mutateAsync: receiveReturn, isLoading: isReceivingReturn } = useMutation(
    receiveReturnMaterialForAssignmentMutation(),
  )
  const { mutateAsync: reviseTransfer, isLoading: isUpdatingTransfer } = useMutation(
    reviseTransferRequestMutation(),
  )
  const { mutateAsync: reviseReturn, isLoading: isUpdatingReturn } = useMutation(
    reviseReturnRequestMutation(),
  )

  const isApproving = computed(() => isApprovingTransfer.value || isApprovingReturn.value)
  const isRejecting = computed(() => isRejectingTransfer.value || isRejectingReturn.value)
  const isReceiving = computed(() => isReceivingTransfer.value || isReceivingReturn.value)
  const isUpdating = computed(() => isUpdatingTransfer.value || isUpdatingReturn.value)
  const showRejectDialog = ref(false)
  const rejectReason = ref('')
  const reviseItems = ref<NormalizedInventoryRequestItem[]>([])

  watch(
    () => normalizedData.value?.items,
    (items) => {
      if (items) reviseItems.value = items.map((item) => ({ ...item }))
    },
    { immediate: true },
  )

  function scheduleRefresh() {
    const kind = options.requestKind.value
    setTimeout(() => {
      void queryCache.invalidateQueries({
        key:
          kind === 'return'
            ? getReturnRequestQueryKey({ path: { id: options.requestId } })
            : getTransferRequestQueryKey({ path: { id: options.requestId } }),
      })
      void queryCache.invalidateQueries({
        key:
          kind === 'return'
            ? getReturnRequestHistoryQueryKey({ path: { id: options.requestId } })
            : getTransferRequestHistoryQueryKey({ path: { id: options.requestId } }),
      })
      void queryCache.invalidateQueries({
        key: [
          kind === 'return'
            ? 'findReturnRequestAssignmentsForReceiver'
            : 'findTransferRequestAssignmentsForReceiver',
        ],
      })
      void queryCache.invalidateQueries({
        key: [
          kind === 'return'
            ? 'findReturnRequestsPendingEvaluation'
            : 'findTransferRequestsPendingEvaluation',
        ],
      })
    }, 1000)
  }

  async function handleApprove() {
    try {
      if (options.requestKind.value === 'transfer') {
        await approveTransferReq({ path: { id: options.requestId } })
      } else {
        await approveReturnReq({ path: { id: options.requestId } })
      }
      showSuccess('Đã duyệt yêu cầu')
      scheduleRefresh()
    } catch (error) {
      showError(errorMessage(error, 'Lỗi khi duyệt'))
    }
  }

  async function handleReject() {
    if (!rejectReason.value.trim()) return
    try {
      const body = { reason: rejectReason.value }
      if (options.requestKind.value === 'transfer') {
        await rejectTransferReq({ path: { id: options.requestId }, body })
      } else {
        await rejectReturnReq({ path: { id: options.requestId }, body })
      }
      showSuccess('Đã từ chối yêu cầu')
      showRejectDialog.value = false
      scheduleRefresh()
    } catch (error) {
      showError(errorMessage(error, 'Lỗi khi từ chối'))
    }
  }

  async function handleReceiveAction() {
    if (!normalizedData.value || !policy.value) return
    const itemsByTarget = buildReceiveItemsByTarget(
      normalizedData.value.items,
      policy.value.activeAssignmentTargetIds,
    )
    try {
      for (const [targetId, items] of Object.entries(itemsByTarget)) {
        if (options.requestKind.value === 'transfer') {
          await receiveTransfer({
            path: {
              transferRequestId: options.requestId,
              targetTeamAssignmentId: targetId,
            },
            body: { items },
          })
        } else {
          await receiveReturn({
            path: { returnRequestId: options.requestId, receiverId: targetId },
            body: { items },
          })
        }
      }
      showSuccess('Đã nhận vật tư')
      scheduleRefresh()
    } catch (error) {
      showError(errorMessage(error, 'Lỗi khi nhận'))
    }
  }

  async function handleUpdate() {
    if (!normalizedData.value) return
    try {
      if (options.requestKind.value === 'transfer') {
        await reviseTransfer({
          path: { id: options.requestId },
          body: buildReviseRequest(
            'transfer',
            normalizedData.value,
            reviseItems.value,
          ) as CreateTransferRequestCommand,
        })
      } else {
        await reviseReturn({
          path: { id: options.requestId },
          body: buildReviseRequest(
            'return',
            normalizedData.value,
            reviseItems.value,
          ) as CreateReturnRequestCommand,
        })
      }
      showSuccess('Đã cập nhật và gửi lại yêu cầu')
      scheduleRefresh()
    } catch (error) {
      showError(errorMessage(error, 'Lỗi khi cập nhật'))
    }
  }

  return {
    requestKind: options.requestKind,
    isTransferRequest,
    isLoading,
    normalizedData,
    isReviseMode,
    canApproveOrReject,
    canReceive,
    isApproving,
    isRejecting,
    isReceiving,
    isUpdating,
    showRejectDialog,
    rejectReason,
    reviseItems,
    handleApprove,
    handleReject,
    handleReceiveAction,
    handleUpdate,
    sourceName: computed(() => normalizedData.value?.sourceName),
    requestTypeLabel: computed(() =>
      options.requestKind.value === 'return' ? 'Trả lại' : 'Điều chuyển',
    ),
    requestTypeSeverity: computed(() =>
      options.requestKind.value === 'return' ? 'success' : 'info',
    ),
    getStatusLabel: getInventoryRequestStatusLabel,
    getStatusSeverity: getInventoryRequestStatusSeverity,
  }
}

function errorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback
}
