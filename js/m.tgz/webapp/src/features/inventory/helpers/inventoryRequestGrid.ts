import type { GridColumn } from '@/shared/composables/useGridLayout'

export function buildColumns(): GridColumn[] {
  return [
    {
      prop: 'article',
      name: 'Mã NPL',
      readonly: true,
    },
    {
      prop: 'uom',
      name: 'ĐVT',
      readonly: true,
    },
    {
      prop: 'color',
      name: 'Màu',
      readonly: true,
    },
    {
      prop: 'size',
      name: 'Cỡ',
      readonly: true,
    },
    {
      prop: 'totalConsumption',
      name: 'Tổng nhu cầu',
      readonly: true,
      columnType: 'qty',
      cellClass: 'text-right',
    },
    {
      prop: 'cumulativeReceived',
      name: 'Luỹ kế thực nhận',
      readonly: true,
      columnType: 'qty',
      cellClass: 'text-right',
    },
    {
      prop: 'isSelected',
      name: 'Chọn',
      readonly: true,
      columnType: 'component',
      componentName: 'InventoryRequestSelectCell',
      pin: 'colPinEnd',
      cellClass: 'flex justify-center',
      headerClass: 'text-center',
    },
  ]
}
