import type { NotificationTarget, NotificationView } from '@/api'
import { zNotificationView } from '@/api/zod.gen'

const RESOURCE_ICONS = {
  BUYER_ORDER: 'i-lucide-shopping-bag',
  KANBAN: 'i-lucide-clipboard-check',
  PRODUCTION_ORDER: 'i-lucide-factory',
  RETURN_REQUEST: 'i-lucide-undo-2',
  TEAM_ASSIGNMENT: 'i-lucide-workflow',
  TRANSFER_REQUEST: 'i-lucide-arrow-right-left',
} satisfies Record<NotificationTarget['resourceType'], string>

export const notificationResourceIcon = (resourceType: NotificationTarget['resourceType']) =>
  RESOURCE_ICONS[resourceType]

export const deserializeNotification = (raw?: string): NotificationView =>
  zNotificationView.parse(JSON.parse(raw ?? ''))
