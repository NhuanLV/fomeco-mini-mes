import {
  list,
  markAllAsRead,
  markTargetAsRead,
  type NotificationPageView,
  type NotificationTarget,
  type NotificationView,
} from '@/api'
import { ROUTE_PATH } from '@/app/router/path'
import {
  deserializeNotification,
  notificationResourceIcon,
} from '@/features/notification/notificationResource'
import { useToast } from '@nuxt/ui/composables'
import {
  setInfiniteQueryData,
  useInfiniteQuery,
  useQueryCache,
  type UseInfiniteQueryData,
} from '@pinia/colada'
import { useEventSource } from '@vueuse/core'
import { computed, h, shallowRef, watch } from 'vue'
import { useRoute, useRouter, type RouteLocationRaw } from 'vue-router'

const notificationKey = (unreadOnly: boolean) => ['notifications', unreadOnly] as const
type FeedData = UseInfiniteQueryData<NotificationPageView, string | undefined>

function useNotificationFeed(unreadOnly: boolean) {
  const query = useInfiniteQuery({
    key: notificationKey(unreadOnly),
    initialPageParam: undefined as string | undefined,
    query: async ({ pageParam }) => {
      const { data } = await list({
        query: { unreadOnly, cursor: pageParam, size: 10 },
        throwOnError: true,
      })
      return data
    },
    getNextPageParam: (page) => page.nextCursor ?? null,
  })

  const items = computed(() => query.data.value?.pages.flatMap((page) => page.items) ?? [])

  return {
    items,
    error: query.error,
    isLoading: computed(() => query.isLoading.value && items.value.length === 0),
    isLoadingMore: computed(() => query.asyncStatus.value === 'loading' && items.value.length > 0),
    hasMore: query.hasNextPage,
    refetch: query.refetch,
    loadMore: async () => {
      if (query.hasNextPage.value && query.asyncStatus.value !== 'loading') {
        await query.loadNextPage()
      }
    },
  }
}

function updateFeed(
  queryCache: ReturnType<typeof useQueryCache>,
  unreadOnly: boolean,
  updater: (data: FeedData | undefined) => FeedData,
) {
  setInfiniteQueryData(queryCache, notificationKey(unreadOnly), updater)
}

function resourcePath(notification: NotificationView): RouteLocationRaw {
  switch (notification.target.resourceType) {
    case 'BUYER_ORDER':
      return ROUTE_PATH.BUYER_ORDER_DETAIL.replace(':id', notification.target.resourceId)
    case 'KANBAN':
      return ROUTE_PATH.KANBAN_DETAIL.replace(':id', notification.target.resourceId)
    case 'PRODUCTION_ORDER':
      return ROUTE_PATH.PRODUCTION_ORDER_DETAIL.replace(':id', notification.target.resourceId)
    case 'RETURN_REQUEST':
      return {
        path: ROUTE_PATH.INVENTORY_DETAIL.replace(':id', notification.target.resourceId),
        query: { type: 'return' },
      }
    case 'TEAM_ASSIGNMENT':
      return ROUTE_PATH.TEAM_ASSIGNMENT_DETAIL.replace(':id', notification.target.resourceId)
    case 'TRANSFER_REQUEST':
      return {
        path: ROUTE_PATH.INVENTORY_DETAIL.replace(':id', notification.target.resourceId),
        query: { type: 'transfer' },
      }
    default: {
      const unsupported: never = notification.target.resourceType
      return unsupported
    }
  }
}

function targetFromRoute(route: ReturnType<typeof useRoute>): NotificationTarget | null {
  const id = route.params.id
  const resourceId = Array.isArray(id) ? id[0] : id
  if (!resourceId) return null

  switch (route.name) {
    case '/(main)/buyer-orders/[id]':
      return { resourceType: 'BUYER_ORDER', resourceId }
    case '/(main)/kanban/[id]':
      return { resourceType: 'KANBAN', resourceId }
    case '/(main)/production-orders/[id]':
    case '/(main)/production-orders/[id].revise':
      return { resourceType: 'PRODUCTION_ORDER', resourceId }
    case '/(main)/team-assignments/[id]':
      return { resourceType: 'TEAM_ASSIGNMENT', resourceId }
    case '/(main)/inventory/[id]':
      return {
        resourceType: route.query.type === 'transfer' ? 'TRANSFER_REQUEST' : 'RETURN_REQUEST',
        resourceId,
      }
    default:
      return null
  }
}

export function useNotificationReadTracking() {
  const route = useRoute()
  const queryCache = useQueryCache()
  const target = computed(() => targetFromRoute(route))

  watch(
    target,
    async (current) => {
      if (!current) return
      try {
        await markTargetAsRead({ body: current, throwOnError: true })
      } catch {
        return
      }
      await queryCache.invalidateQueries({ key: ['notifications'] })
    },
    { immediate: true },
  )
}

export function useNotifications() {
  const queryCache = useQueryCache()
  const router = useRouter()
  const toast = useToast()
  const unread = useNotificationFeed(true)
  const all = useNotificationFeed(false)
  const isMarkingAllAsRead = shallowRef(false)
  const unreadCount = computed(
    () => queryCache.getQueryData<FeedData>(notificationKey(false))?.pages[0]?.unreadCount ?? 0,
  )

  const { data: realtimeNotification, status } = useEventSource<['notification'], NotificationView>(
    '/api/notifications/stream',
    ['notification'],
    {
      withCredentials: true,
      autoReconnect: true,
      serializer: { read: deserializeNotification },
    },
  )

  watch(realtimeNotification, (notification) => {
    if (!notification || all.items.value.some(({ id }) => id === notification.id)) return

    for (const unreadOnly of [false, true]) {
      updateFeed(queryCache, unreadOnly, (data) => ({
        pages: data?.pages.length
          ? data.pages.map((page, index) => ({
              ...page,
              items: index === 0 ? [notification, ...page.items] : page.items,
              unreadCount: page.unreadCount + 1,
            }))
          : [{ items: [notification], nextCursor: null, unreadCount: 1 }],
        pageParams: data?.pageParams.length ? data.pageParams : [undefined],
      }))
    }

    toast.add({
      id: `notification-${notification.id}`,
      title: notification.title,
      description: h('span', [
        h('strong', notification.actor?.name ?? 'Hệ thống'),
        ` ${notification.body}`,
      ]),
      icon: notificationResourceIcon(notification.target.resourceType),
      color: 'info',
      onClick: () => void openNotification(notification),
    })
  })

  let openedOnce = false
  watch(status, (current) => {
    if (current !== 'OPEN') return
    if (openedOnce) void queryCache.invalidateQueries({ key: ['notifications'] })
    openedOnce = true
  })

  async function openNotification(notification: NotificationView) {
    await router.push(resourcePath(notification))
  }

  async function markAllNotificationsAsRead() {
    isMarkingAllAsRead.value = true
    try {
      await markAllAsRead({ throwOnError: true })
      await queryCache.invalidateQueries({ key: ['notifications'] })
    } catch {
      toast.add({ title: 'Không thể đánh dấu tất cả thông báo đã đọc', color: 'error' })
    } finally {
      isMarkingAllAsRead.value = false
    }
  }

  return {
    unread,
    all,
    unreadCount,
    openNotification,
    markAllNotificationsAsRead,
    isMarkingAllAsRead,
  }
}
