import type { NotificationView } from '@/api'
import { PiniaColada, useQueryCache } from '@pinia/colada'
import { flushPromises } from '@vue/test-utils'
import type { UseEventSourceOptions } from '@vueuse/core'
import { createPinia } from 'pinia'
import { createApp, defineComponent, nextTick, reactive, shallowRef } from 'vue'
import type { RouteLocationNormalizedLoaded } from 'vue-router'
import { afterEach, beforeEach, describe, expect, it, vi, type MockInstance } from 'vitest'
import { list, markAllAsRead, markTargetAsRead } from '@/api'
import { useNotifications, useNotificationReadTracking } from '../useNotifications'

const eventData = shallowRef<NotificationView | null>(null)
const eventStatus = shallowRef<'CONNECTING' | 'OPEN' | 'CLOSED'>('CONNECTING')
const push = vi.fn()
const addToast = vi.fn()
const currentRoute = reactive<Pick<RouteLocationNormalizedLoaded, 'name' | 'params' | 'query'>>({
  name: '/(main)/team-assignments/[id]',
  params: { id: 'assignment-1' },
  query: {},
})
const capturedEventSourceOptions = vi.hoisted<{
  current?: UseEventSourceOptions<NotificationView>
}>(() => ({}))

vi.mock('@/api', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@/api')>()),
  list: vi.fn(),
  markAllAsRead: vi.fn(),
  markTargetAsRead: vi.fn(),
}))

vi.mock('@vueuse/core', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@vueuse/core')>()),
  useEventSource: vi.fn(
    (_url: string, _events: string[], options: UseEventSourceOptions<NotificationView>) => {
      capturedEventSourceOptions.current = options
      return {
        data: eventData,
        status: eventStatus,
        event: shallowRef('notification'),
        error: shallowRef(null),
        close: vi.fn(),
        open: vi.fn(),
        eventSource: shallowRef(null),
        lastEventId: shallowRef(null),
      }
    },
  ),
}))

vi.mock('vue-router', async (importOriginal) => ({
  ...(await importOriginal<typeof import('vue-router')>()),
  useRoute: () => currentRoute,
  useRouter: () => ({ push }),
}))

vi.mock('@nuxt/ui/composables', () => ({
  useToast: () => ({ add: addToast }),
}))

const notification = (overrides: Partial<NotificationView> = {}): NotificationView => ({
  id: 'notification-1',
  actor: { id: 'unit-1', name: 'Phòng kế hoạch' },
  title: 'LSX mới',
  body: 'đã giao LSX LSX-001 cho tổ của bạn',
  target: { resourceType: 'TEAM_ASSIGNMENT', resourceId: 'assignment-1' },
  isRead: false,
  createdAt: '2026-08-04T08:00:00Z',
  ...overrides,
})

function mountComposable() {
  let result!: ReturnType<typeof useNotifications>
  let invalidateQueries!: MockInstance
  const app = createApp(
    defineComponent({
      setup() {
        invalidateQueries = vi.spyOn(useQueryCache(), 'invalidateQueries')
        result = useNotifications()
        return () => null
      },
    }),
  )
  app.use(createPinia())
  app.use(PiniaColada)
  app.mount(document.createElement('div'))
  return { result, app, invalidateQueries }
}

describe('useNotifications', () => {
  beforeEach(() => {
    eventData.value = null
    eventStatus.value = 'CONNECTING'
    vi.clearAllMocks()
    vi.mocked(list).mockResolvedValue({
      data: { items: [], nextCursor: null, unreadCount: 0 },
      error: undefined,
      request: new Request('/api/notifications'),
      response: new Response(),
    })
    vi.mocked(markTargetAsRead).mockResolvedValue({
      data: undefined,
      error: undefined,
      request: new Request('/api/notifications/read'),
      response: new Response(null, { status: 204 }),
    })
    vi.mocked(markAllAsRead).mockResolvedValue({
      data: undefined,
      error: undefined,
      request: new Request('/api/notifications/read-all'),
      response: new Response(null, { status: 204 }),
    })
  })

  afterEach(() => document.body.replaceChildren())

  it('loads unread and all feeds in pages of 10', async () => {
    const { app } = mountComposable()
    await flushPromises()

    expect(list).toHaveBeenCalledWith(
      expect.objectContaining({ query: { unreadOnly: true, cursor: undefined, size: 10 } }),
    )
    expect(list).toHaveBeenCalledWith(
      expect.objectContaining({ query: { unreadOnly: false, cursor: undefined, size: 10 } }),
    )
    app.unmount()
  })

  it('deserializes the raw SSE payload into a notification', () => {
    const { app } = mountComposable()

    const parsed = capturedEventSourceOptions.current?.serializer?.read(
      JSON.stringify(notification()),
    )

    expect(parsed).toEqual(notification())
    app.unmount()
  })

  it('deduplicates realtime notifications and increments unread count once', async () => {
    const { result, app } = mountComposable()
    await flushPromises()

    eventData.value = notification()
    await nextTick()
    eventData.value = { ...notification() }
    await nextTick()

    expect(result.all.items.value).toHaveLength(1)
    expect(result.unread.items.value).toHaveLength(1)
    expect(result.unreadCount.value).toBe(1)
    expect(addToast).toHaveBeenCalledTimes(1)
    expect(addToast).toHaveBeenCalledWith(expect.objectContaining({ icon: 'i-lucide-workflow' }))
    app.unmount()
  })

  it('navigates to a notification resource without changing unread state', async () => {
    const { result, app } = mountComposable()
    await flushPromises()
    eventData.value = notification()
    await nextTick()

    await result.openNotification(notification())

    expect(result.unread.items.value).toHaveLength(1)
    expect(result.all.items.value[0]?.isRead).toBe(false)
    expect(result.unreadCount.value).toBe(1)
    expect(push).toHaveBeenCalledWith('/team-assignments/assignment-1')
    expect(markTargetAsRead).not.toHaveBeenCalled()
    app.unmount()
  })

  it('marks all notifications as read and refetches the feeds', async () => {
    const { result, app, invalidateQueries } = mountComposable()
    await flushPromises()

    await result.markAllNotificationsAsRead()

    expect(markAllAsRead).toHaveBeenCalledWith({ throwOnError: true })
    expect(invalidateQueries).toHaveBeenCalledWith({ key: ['notifications'] })
    app.unmount()
  })

  it.each([
    ['BUYER_ORDER', '/buyer-orders/resource-1'],
    ['KANBAN', '/kanban/resource-1'],
    ['PRODUCTION_ORDER', '/production-orders/resource-1'],
    ['TEAM_ASSIGNMENT', '/team-assignments/resource-1'],
  ] satisfies Array<[NotificationView['target']['resourceType'], string]>)(
    'opens %s notifications at the resource detail',
    async (resourceType, path) => {
      const { result, app } = mountComposable()
      await flushPromises()
      const item = notification({
        isRead: true,
        target: { resourceType, resourceId: 'resource-1' },
      })

      await result.openNotification(item)

      expect(push).toHaveBeenCalledWith(path)
      app.unmount()
    },
  )

  it.each([
    ['RETURN_REQUEST', 'return'],
    ['TRANSFER_REQUEST', 'transfer'],
  ] satisfies Array<[NotificationView['target']['resourceType'], 'return' | 'transfer']>)(
    'opens %s notifications with the inventory request type',
    async (resourceType, type) => {
      const { result, app } = mountComposable()
      await flushPromises()
      const item = notification({
        isRead: true,
        target: { resourceType, resourceId: 'resource-1' },
      })

      await result.openNotification(item)

      expect(push).toHaveBeenCalledWith({
        path: '/inventory/resource-1',
        query: { type },
      })
      app.unmount()
    },
  )
})

describe('useNotificationReadTracking', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.mocked(markTargetAsRead).mockResolvedValue({
      data: undefined,
      error: undefined,
      request: new Request('/api/notifications/read'),
      response: new Response(null, { status: 204 }),
    })
  })

  it.each([
    ['/(main)/buyer-orders/[id]', {}, 'BUYER_ORDER'],
    ['/(main)/kanban/[id]', {}, 'KANBAN'],
    ['/(main)/production-orders/[id]', {}, 'PRODUCTION_ORDER'],
    ['/(main)/production-orders/[id].revise', {}, 'PRODUCTION_ORDER'],
    ['/(main)/team-assignments/[id]', {}, 'TEAM_ASSIGNMENT'],
    ['/(main)/inventory/[id]', { type: 'return' }, 'RETURN_REQUEST'],
    ['/(main)/inventory/[id]', { type: 'transfer' }, 'TRANSFER_REQUEST'],
  ] as const)('marks %s as read and refetches notifications', async (name, query, resourceType) => {
    currentRoute.name = name
    currentRoute.params = { id: 'resource-1' }
    currentRoute.query = query

    let invalidateQueries!: MockInstance
    const app = createApp(
      defineComponent({
        setup() {
          const queryCache = useQueryCache()
          invalidateQueries = vi.spyOn(queryCache, 'invalidateQueries')
          useNotificationReadTracking()
          return () => null
        },
      }),
    )
    app.use(createPinia())
    app.use(PiniaColada)
    app.mount(document.createElement('div'))

    await flushPromises()

    expect(markTargetAsRead).toHaveBeenCalledWith({
      body: { resourceType, resourceId: 'resource-1' },
      throwOnError: true,
    })
    expect(invalidateQueries).toHaveBeenCalledWith({ key: ['notifications'] })
    app.unmount()
  })
})
