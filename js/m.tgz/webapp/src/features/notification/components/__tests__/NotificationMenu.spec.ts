import type { NotificationView } from '@/api'
import { shallowMount } from '@vue/test-utils'
import { computed, defineComponent, h, shallowRef, type PropType } from 'vue'
import { describe, expect, it, vi } from 'vitest'
import NotificationMenu from '../NotificationMenu.vue'

const unreadItem: NotificationView = {
  id: 'unread-1',
  actor: { id: 'unit-1', name: 'Phòng kế hoạch' },
  title: 'LSX mới',
  body: 'đã giao LSX LSX-001 cho tổ của bạn',
  target: { resourceType: 'TEAM_ASSIGNMENT', resourceId: 'assignment-1' },
  isRead: false,
  createdAt: '2026-08-04T08:00:00Z',
}
const readItem: NotificationView = { ...unreadItem, id: 'read-1', isRead: true }
const openNotification = vi.fn()
const markAllNotificationsAsRead = vi.fn()

vi.mock('../../composables/useNotifications', () => ({
  useNotifications: () => ({
    unreadCount: computed(() => 1),
    unread: {
      items: computed(() => [unreadItem]),
      error: shallowRef(null),
      isLoading: computed(() => false),
      isLoadingMore: computed(() => false),
      hasMore: computed(() => false),
      loadMore: vi.fn(),
    },
    all: {
      items: computed(() => [unreadItem, readItem]),
      error: shallowRef(null),
      isLoading: computed(() => false),
      isLoadingMore: computed(() => false),
      hasMore: computed(() => false),
      loadMore: vi.fn(),
    },
    openNotification,
    markAllNotificationsAsRead,
    isMarkingAllAsRead: computed(() => false),
  }),
}))

vi.mock('@vueuse/core', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@vueuse/core')>()),
  useInfiniteScroll: vi.fn(() => ({ reset: vi.fn(), isLoading: computed(() => false) })),
}))

const close = vi.fn()
type TabItem = { label: string; value: string }
const NuxtUiStub = defineComponent({
  props: {
    items: {
      type: Array as PropType<TabItem[]>,
      default: undefined,
    },
  },
  emits: ['update:modelValue'],
  setup(props, { emit, slots }) {
    return () =>
      props.items
        ? h(
            'div',
            props.items.map((item) =>
              h('button', { onClick: () => emit('update:modelValue', item.value) }, item.label),
            ),
          )
        : h('div', [slots.default?.({ open: true }), slots.content?.({ close })])
  },
})

const stubs = {
  Popover: NuxtUiStub,
  Tabs: NuxtUiStub,
  ScrollArea: { template: '<div><slot /></div>' },
  Badge: { template: '<span>(<slot />)</span>' },
  Button: {
    props: ['label', 'disabled', 'loading'],
    emits: ['click'],
    template: '<button :disabled="disabled" @click="$emit(\'click\')">{{ label }}</button>',
  },
  NotificationItem: {
    props: ['notification'],
    emits: ['open'],
    template:
      '<button class="notification" @click="$emit(\'open\', notification)">{{ notification.id }}</button>',
  },
}

describe('NotificationMenu', () => {
  it('shows unread count and switches between unread and all tabs', async () => {
    const wrapper = shallowMount(NotificationMenu, {
      global: {
        stubs,
      },
    })

    expect(wrapper.get('h2').text()).toBe('Thông báo (1)')
    expect(wrapper.text()).toContain('Chưa đọc')
    const chip = wrapper.findComponent({ name: 'Chip' })
    expect(chip.props()).toMatchObject({
      color: 'error',
      show: true,
      size: 'xl',
    })
    expect(chip.props('text')).toBeUndefined()
    expect(wrapper.findAll('.notification')).toHaveLength(1)

    await wrapper
      .findAll('button')
      .find((button) => button.text() === 'Tất cả')!
      .trigger('click')
    expect(wrapper.findAll('.notification')).toHaveLength(2)
  })

  it('opens and closes the popover when a notification is clicked', async () => {
    const wrapper = shallowMount(NotificationMenu, {
      global: {
        stubs,
      },
    })

    await wrapper.get('.notification').trigger('click')
    expect(openNotification).toHaveBeenCalledWith(unreadItem)
    expect(close).toHaveBeenCalled()
  })

  it('marks all notifications as read', async () => {
    const wrapper = shallowMount(NotificationMenu, { global: { stubs } })

    await wrapper
      .findAll('button')
      .find((button) => button.text() === 'Đã đọc tất cả')!
      .trigger('click')

    expect(markAllNotificationsAsRead).toHaveBeenCalledOnce()
  })
})
