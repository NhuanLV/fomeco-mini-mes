import type { NotificationView } from '@/api'
import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import NotificationItem from '../NotificationItem.vue'

const item: NotificationView = {
  id: 'notification-1',
  actor: { id: 'unit-1', name: 'Phòng kế hoạch' },
  title: 'LSX mới',
  body: 'đã giao LSX LSX-001 cho tổ của bạn',
  target: { resourceType: 'TEAM_ASSIGNMENT', resourceId: 'assignment-1' },
  isRead: false,
  createdAt: '2026-08-04T08:00:00Z',
}

describe('NotificationItem', () => {
  it('renders actor separately and emits open from an accessible button', async () => {
    const wrapper = mount(NotificationItem, {
      props: { notification: item },
      global: {
        stubs: {
          Button: { template: '<button><slot /></button>' },
          Icon: {
            props: ['name'],
            template: '<i class="resource-icon" :data-icon="name" />',
          },
        },
      },
    })

    expect(wrapper.find('strong').text()).toBe('Phòng kế hoạch')
    expect(wrapper.text()).toContain('đã giao LSX LSX-001 cho tổ của bạn')
    expect(wrapper.get('.resource-icon').attributes('data-icon')).toBe('i-lucide-workflow')
    await wrapper.get('button').trigger('click')
    expect(wrapper.emitted('open')).toEqual([[item]])
  })

  it('labels a null actor as system', () => {
    const wrapper = mount(NotificationItem, {
      props: { notification: { ...item, actor: null } },
      global: {
        stubs: {
          Button: { template: '<button><slot /></button>' },
          Icon: {
            props: ['name'],
            template: '<i class="resource-icon" :data-icon="name" />',
          },
        },
      },
    })

    expect(wrapper.find('strong').text()).toBe('Hệ thống')
  })

  it.each([
    ['BUYER_ORDER', 'i-lucide-shopping-bag'],
    ['KANBAN', 'i-lucide-clipboard-check'],
    ['PRODUCTION_ORDER', 'i-lucide-factory'],
    ['RETURN_REQUEST', 'i-lucide-undo-2'],
    ['TEAM_ASSIGNMENT', 'i-lucide-workflow'],
    ['TRANSFER_REQUEST', 'i-lucide-arrow-right-left'],
  ] satisfies Array<[NotificationView['target']['resourceType'], string]>)(
    'shows the matching icon for %s',
    (resourceType, icon) => {
      const wrapper = mount(NotificationItem, {
        props: {
          notification: { ...item, target: { ...item.target, resourceType } },
        },
        global: {
          stubs: {
            Button: { template: '<button><slot /></button>' },
            Icon: {
              props: ['name'],
              template: '<i class="resource-icon" :data-icon="name" />',
            },
          },
        },
      })

      expect(wrapper.get('.resource-icon').attributes('data-icon')).toBe(icon)
    },
  )
})
