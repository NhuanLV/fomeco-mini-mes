<script setup lang="ts">
import type { NotificationView } from '@/api'
import { notificationResourceIcon } from '@/features/notification/notificationResource'
import { computed } from 'vue'

const props = defineProps<{ notification: NotificationView }>()
defineEmits<{ open: [notification: NotificationView] }>()
const resourceIcon = computed(() =>
  notificationResourceIcon(props.notification.target.resourceType),
)

const formatDate = (value: string) =>
  new Intl.DateTimeFormat('vi-VN', { dateStyle: 'short', timeStyle: 'short' }).format(
    new Date(value),
  )
</script>

<template>
  <UButton
    color="neutral"
    variant="ghost"
    class="h-auto w-full justify-start rounded-none px-4 py-3 text-left"
    :class="{ 'bg-elevated/60': !notification.isRead }"
    @click="$emit('open', notification)"
  >
    <UIcon :name="resourceIcon" class="mt-1 size-5 shrink-0 text-primary" />
    <span class="min-w-0 flex-1 whitespace-normal">
      <span class="block text-sm font-semibold text-default">{{ notification.title }}</span>
      <span class="mt-0.5 block text-sm leading-5 text-muted">
        <strong class="text-default">{{ notification.actor?.name ?? 'Hệ thống' }}</strong>
        {{ ` ${notification.body}` }}
      </span>
      <span class="mt-1 block text-xs text-dimmed">{{ formatDate(notification.createdAt) }}</span>
    </span>
    <span v-if="!notification.isRead" class="mt-2 size-2 shrink-0 rounded-full bg-primary" />
  </UButton>
</template>
