<script setup lang="ts">
import type { NotificationView } from '@/api'
import NotificationItem from './NotificationItem.vue'
import Aura from '@/shared/components/Aura.vue'
import { useNotifications } from '../composables/useNotifications'
import { useInfiniteScroll } from '@vueuse/core'
import { computed, nextTick, shallowRef, useTemplateRef, watch } from 'vue'

const tabs = [
  { label: 'Chưa đọc', value: 'unread' },
  { label: 'Tất cả', value: 'all' },
]
const activeTab = shallowRef<'unread' | 'all'>('unread')
const {
  unread,
  all,
  unreadCount,
  openNotification,
  markAllNotificationsAsRead,
  isMarkingAllAsRead,
} = useNotifications()
const activeFeed = computed(() => (activeTab.value === 'unread' ? unread : all))
const items = computed(() => activeFeed.value.items.value)
const error = computed(() => activeFeed.value.error.value)
const isLoading = computed(() => activeFeed.value.isLoading.value)
const isLoadingMore = computed(() => activeFeed.value.isLoadingMore.value)
const scrollArea = useTemplateRef<{ $el: HTMLElement }>('scrollArea')

const { reset } = useInfiniteScroll(
  () => scrollArea.value?.$el,
  async () => {
    await activeFeed.value.loadMore()
  },
  {
    distance: 48,
    canLoadMore: () => activeFeed.value.hasMore.value && !isLoadingMore.value,
  },
)

watch(activeTab, async () => {
  await nextTick()
  reset()
})

function handleOpen(notification: NotificationView, close: () => void) {
  close()
  void openNotification(notification)
}
</script>

<template>
  <UPopover
    :content="{ align: 'end', side: 'bottom', sideOffset: 8 }"
    :ui="{ content: 'w-[min(30rem,calc(100vw-1rem))] overflow-hidden p-0' }"
  >
    <template #default="{ open }">
      <UChip inset :show="unreadCount > 0" color="error" size="xl">
        <Aura variant="dual" class="text-primary">
          <UButton
            icon="i-lucide-bell"
            aria-label="Thông báo"
            color="neutral"
            variant="ghost"
            class="bg-default"
            :class="{ 'bg-elevated': open }"
          />
        </Aura>
      </UChip>
    </template>

    <template #content="{ close }">
      <div class="border-default">
        <div class="flex items-center justify-between gap-2 px-4 pt-4">
          <h2 class="text-base font-semibold text-default">
            Thông báo <UBadge class="text-bold">{{ unreadCount }}</UBadge>
          </h2>
          <UButton
            label="Đã đọc tất cả"
            class="cursor-pointer"
            icon="i-lucide-check-check"
            variant="outline"
            size="md"
            :loading="isMarkingAllAsRead"
            :disabled="unreadCount === 0 || isMarkingAllAsRead"
            @click="markAllNotificationsAsRead"
          />
        </div>
        <UTabs v-model="activeTab" :items="tabs" :content="false" class="mt-2 bg-transparent" />
      </div>

      <UScrollArea ref="scrollArea" class="h-96">
        <div v-if="isLoading" class="space-y-3 p-4" aria-label="Đang tải thông báo">
          <USkeleton v-for="index in 3" :key="index" class="h-16 w-full" />
        </div>

        <div v-else-if="error" class="p-4">
          <UAlert color="error" icon="i-lucide-circle-alert" title="Không thể tải thông báo" />
          <UButton
            label="Thử lại"
            color="neutral"
            variant="outline"
            size="sm"
            class="mt-3"
            @click="activeFeed.refetch()"
          />
        </div>

        <UEmpty
          v-else-if="items.length === 0"
          icon="i-lucide-bell-off"
          title="Không có thông báo"
          class="py-12"
        />

        <div v-else class="divide-y divide-default">
          <NotificationItem
            v-for="notification in items"
            :key="notification.id"
            :notification="notification"
            @open="handleOpen($event, close)"
            chip
          />
          <div v-if="isLoadingMore" class="flex justify-center py-3" aria-label="Đang tải thêm">
            <UIcon name="i-lucide-loader-circle" class="size-5 animate-spin text-muted" />
          </div>
        </div>
      </UScrollArea>
    </template>
  </UPopover>
</template>
