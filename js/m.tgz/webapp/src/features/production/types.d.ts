import type { BomRoutingVm, PurchaseOrderVm } from '@/api'

export interface TeamVm {
  id: string
  name: string
  operation: string
  isActive: boolean
  factoryName: string
  companyName: string
}

export interface TeamOption {
  label: string
  value: string
  disabled?: boolean
}

export type SkuKey = string

export type PoColorKey = string

export interface RowMeta {
  teamId: string | null
  teamName: string
  deliveryDate?: string
  checkDate?: string
  plannedStartDate?: string
  plannedEndDate?: string
  notes: string[]
}

export interface AllocationMatrix {
  opName: string
  qtyMap: Record<SkuKey, number[]> //SkuKey -> Mảng số lượng
  totalMap: Record<SkuKey, number> //SkuKey -> Tổng nhu cầu từ PO (master)
  rowMetaMap: Record<PoColorKey, RowMeta[]>
}

export interface AllocationGridRow {
  id: string
  poId: string
  poCode: string
  displayPoCode?: string
  destination: string
  deliveryDate: string
  checkDate: string
  color: string
  rowIndex: number
  teamId: string | null
  teamName: string
  total: number
  [sizeKey: string]: string | number | null | TeamOption[]
}
export interface AutoOperationMeta {
  opName: string
  teamId: string
  teamName: string
  plannedStartDate?: string
  plannedEndDate?: string
}

export interface TeamAssignmentScheduleItem {
  teamId: string
  operation: string
  teamName: string
  assignedQuantity: number
  plannedStartDate: string | null
  plannedEndDate: string | null
}
export interface AllocationTemplateContext {
  factoryIds: string[]
  allSizes: string[]
  selectedPOs: PurchaseOrderVm[]
  selectedRouting: BomRoutingVm | null
  styleColorOrder?: string[]
  styleName?: string
  fileName?: string
  customerName?: string
  brandName?: string
  matrices?: AllocationMatrix[]
  autoOps?: AutoOperationMeta[]
  opNames: string[]
  operationOrder?: string[]
  subTotalMap?: Record<string, number>
  teams: TeamVm[]
  noteColumnCount: number
  syncDate?: Date | null
  productDate?: Date | null
  firstSku?: string
  isExportData?: boolean
}
