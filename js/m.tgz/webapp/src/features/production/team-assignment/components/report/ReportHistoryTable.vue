<script lang="ts" setup>
import type { SkuReportVm, TeamAssignmentReportHistoryVm } from '@/api'
import ColumnDateFilter from '@/shared/components/ColumnDateFilter.vue'
import ColumnMultiSelectFilter from '@/shared/components/ColumnMultiSelectFilter.vue'
import { makeOrderComparator } from '@/shared/utils/orderedValues'
import type { TableColumn } from '@nuxt/ui'
import dayjs from 'dayjs'
import { computed, ref } from 'vue'

const props = defineProps<{
  history: TeamAssignmentReportHistoryVm[] | undefined | null
  styleColorOrder: string[]
  styleSizeOrder: string[]
  loading: boolean
  currentType: 'INPUT' | 'OUTPUT'
  purchaseOrderCodes?: Record<string, string>
  deleting?: boolean
  readOnly?: boolean
}>()

const isExpanded = defineModel<boolean>('isExpanded', { default: false })

const emit = defineEmits<{
  startEdit: [row: TeamAssignmentReportHistoryVm]
  confirmDelete: [expectedReportedAt: string]
  createGrn: [reportedAt: string]
  cancelGrn: [reportedAt: string]
}>()

type ReportGrnStatus =
  | 'NOT_READY'
  | 'PENDING'
  | 'SUCCESS'
  | 'FAILED'
  | 'CANCELLED'
  | 'NOT_APPLICABLE'
type ReportHistoryWithGrn = TeamAssignmentReportHistoryVm & {
  grnStatus?: ReportGrnStatus | null
  grnMode?: 'AUTO' | 'MANUAL' | null
  canCreateGrn?: boolean
  grnMessage?: string | null
  grnUpdatedAt?: string | null
  grnNo?: string | null
}

const detailItem = ref<TeamAssignmentReportHistoryVm | null>(null)
const detailDialogVisible = ref(false)

const reportTypeFilter = ref<string[]>([])
const actionTypeFilter = ref<string[]>([])
const actorFilter = ref<string[]>([])
const dateRangeFilter = ref<Date[] | null>(null)

const REPORT_TYPE_OPTIONS = [
  { label: 'Vào chuyền', value: 'INPUT' },
  { label: 'Ra chuyền', value: 'OUTPUT' },
]

const ACTION_TYPE_OPTIONS = [
  { label: 'Tạo mới', value: 'CREATED' },
  { label: 'Cập nhật', value: 'UPDATED' },
  { label: 'Xóa', value: 'DELETED' },
  { label: 'Đã hủy', value: 'CANCELLED' },
]

const cmpQuantity = computed(() => {
  const cmpColor = makeOrderComparator(props.styleColorOrder)
  const cmpSize = makeOrderComparator(props.styleSizeOrder)
  return (left: { color: string; size: string }, right: { color: string; size: string }) =>
    cmpColor(left.color, right.color) || cmpSize(left.size, right.size)
})

const progressHistory = computed<ReportHistoryWithGrn[]>(() =>
  (props.history ?? [])
    .filter((item) => item.reportType != null)
    .map((item) => ({
      ...item,
      quantities: [...item.quantities].sort(cmpQuantity.value),
    })),
)

const actorOptions = computed(() => {
  const actorNames = new Set<string>()
  progressHistory.value.forEach((e) => {
    actorNames.add(e.actor?.name ?? 'System')
  })
  return Array.from(actorNames)
    .sort((left, right) => left.localeCompare(right, 'vi'))
    .map((name) => ({ label: name, value: name }))
})

const filteredHistory = computed(() => {
  return progressHistory.value.filter((item) => {
    if (reportTypeFilter.value.length > 0) {
      if (!item.reportType || !reportTypeFilter.value.includes(item.reportType)) {
        return false
      }
    }

    if (actionTypeFilter.value.length > 0) {
      if (!actionTypeFilter.value.includes(item.actionType)) {
        return false
      }
    }

    if (actorFilter.value.length > 0) {
      const actorName = item.actor?.name ?? 'System'
      if (!actorFilter.value.includes(actorName)) {
        return false
      }
    }

    if (
      dateRangeFilter.value &&
      dateRangeFilter.value.length === 2 &&
      dateRangeFilter.value[0] &&
      dateRangeFilter.value[1]
    ) {
      const itemDate = dayjs(item.occurredAt)
      const startDate = dayjs(dateRangeFilter.value[0]).startOf('day')
      const endDate = dayjs(dateRangeFilter.value[1]).endOf('day')
      if (itemDate.isBefore(startDate) || itemDate.isAfter(endDate)) {
        return false
      }
    }

    return true
  })
})

const detailRows = computed(() => detailItem.value?.quantities ?? [])
const columns: TableColumn<TeamAssignmentReportHistoryVm>[] = [
  { accessorKey: 'productionCode', header: 'Mã LSX' },
  { id: 'reportType', meta: { class: { th: 'p-0!' } } },
  { id: 'purchaseOrderType', header: 'Loại PO' },
  { id: 'actionType', meta: { class: { th: 'p-0!' } } },
  { id: 'quantities', header: 'SL báo cáo' },
  { id: 'totalQuantity', header: 'Tổng' },
  { id: 'actor', meta: { class: { th: 'p-0!' } } },
  { id: 'occurredAt', meta: { class: { th: 'p-0!' } } },
  {
    id: 'grn',
    header: 'Phiếu nhập kho WFX (GRN)',
    meta: {
      class: {
        th: 'min-w-[500px] max-w-[650px]',
        td: 'min-w-[500px] max-w-[650px] whitespace-normal break-words',
      },
    },
  },
  { accessorKey: 'reason', header: 'Ghi chú' },
  { id: 'actions' },
]
const detailColumns: TableColumn<SkuReportVm>[] = [
  { accessorKey: 'purchaseOrderId', header: 'Mã PO' },
  { accessorKey: 'size', header: 'Cỡ' },
  { accessorKey: 'color', header: 'Màu' },
  { accessorKey: 'quantity', header: 'Thay đổi' },
]

function formatDate(dateString: string) {
  return dayjs(dateString).format('DD/MM/YYYY HH:mm:ss')
}

function formatSigned(quantity: number) {
  if (quantity > 0) return `+${quantity}`
  return String(quantity)
}

function formatQuantityItem(quantity: SkuReportVm) {
  const sku = `${quantity.size}/${quantity.color}`
  if (quantity.previousQuantity == null) {
    return `${sku} ${formatSigned(quantity.quantity)}`
  }

  const delta = quantity.quantity - quantity.previousQuantity
  const deltaText = delta >= 0 ? `+${delta}` : `${delta}`
  return `${sku} +${quantity.quantity} (${deltaText})`
}

function getSummary(row: TeamAssignmentReportHistoryVm) {
  const items = row.quantities.map(formatQuantityItem)
  const visibleIndexes: number[] = []
  const seenColors = new Set<string>()

  row.quantities.forEach((quantity, index) => {
    if (visibleIndexes.length >= 2) return
    if (seenColors.has(quantity.color)) return
    visibleIndexes.push(index)
    seenColors.add(quantity.color)
  })

  if (visibleIndexes.length < 2) {
    row.quantities.forEach((_, index) => {
      if (visibleIndexes.length >= 2) return
      if (visibleIndexes.includes(index)) return
      visibleIndexes.push(index)
    })
  }

  const visibleItems = visibleIndexes.map((index) => items[index])
  const remaining = items.length - visibleItems.length
  return {
    visibleText: visibleItems.join(', '),
    remaining,
  }
}

function getTotalQuantityText(row: TeamAssignmentReportHistoryVm): string {
  if (!row.quantities || row.quantities.length === 0) return '-'

  const isEdit = row.actionType === 'UPDATED' || row.actionType === 'ADJUSTED'
  if (isEdit) {
    let newTotal = 0
    let oldTotal = 0

    row.quantities.forEach((item) => {
      newTotal += item.quantity
      oldTotal += item.previousQuantity ?? item.quantity
    })

    const delta = newTotal - oldTotal
    const deltaText = delta >= 0 ? `+${delta}` : `${delta}`
    return `${newTotal} (${deltaText})`
  }

  const total = row.quantities.reduce((sum, item) => sum + item.quantity, 0)
  return String(total)
}

function getOperationLabel(reportType?: TeamAssignmentReportHistoryVm['reportType'] | null) {
  if (reportType === 'INPUT') return 'Vào chuyền'
  if (reportType === 'OUTPUT') return 'Ra chuyền'
  return '-'
}

function getActionLabel(actionType: TeamAssignmentReportHistoryVm['actionType']) {
  switch (actionType) {
    case 'CREATED':
      return 'Tạo mới'
    case 'UPDATED':
      return 'Cập nhật'
    case 'DELETED':
      return 'Xóa'
    case 'CANCELLED':
      return 'Đã hủy'
    default:
      return actionType
  }
}

function getOperationSeverity(reportType?: TeamAssignmentReportHistoryVm['reportType'] | null) {
  if (reportType === 'INPUT') return 'info'
  if (reportType === 'OUTPUT') return 'success'
  return 'neutral'
}

function getActionSeverity(actionType: TeamAssignmentReportHistoryVm['actionType']) {
  switch (actionType) {
    case 'CREATED':
      return 'success'
    case 'UPDATED':
      return 'warning'
    case 'DELETED':
      return 'error'
    case 'ADJUSTED':
      return 'info'
    case 'REVISED':
      return 'success'
    default:
      return 'neutral'
  }
}

function getGrnStatus(row: ReportHistoryWithGrn): ReportGrnStatus {
  return row.grnStatus ?? 'NOT_READY'
}

function getGrnLabel(row: ReportHistoryWithGrn) {
  switch (getGrnStatus(row)) {
    case 'PENDING':
      return 'Đang tạo'
    case 'SUCCESS':
      return 'Thành công'
    case 'FAILED':
      return 'Thất bại'
    case 'CANCELLED':
      return 'Đã hủy'
    case 'NOT_APPLICABLE':
      return 'Không áp dụng'
    default:
      return 'Chưa sẵn sàng'
  }
}

function getGrnColor(row: ReportHistoryWithGrn) {
  switch (getGrnStatus(row)) {
    case 'PENDING':
      return 'warning'
    case 'SUCCESS':
      return 'success'
    case 'FAILED':
      return 'error'
    case 'CANCELLED':
      return 'neutral'
    case 'NOT_APPLICABLE':
      return 'neutral'
    default:
      return 'neutral'
  }
}

function getGrnMessageLines(message: string, isSuccess = false) {
  if (!message) return []
  const text = message.trim()

  if (isSuccess) {
    const match = text.match(/\(([^()]+)\)/)
    const extracted = match && match[1].trim() ? match[1].trim() : text
    return extracted
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)
      .filter((line) => !line.startsWith('Tạo phiếu GRN thành công'))
  }

  const rawLines = text
    .split('\n')
    .map((s) => s.trim())
    .filter(Boolean)
  const result: string[] = []

  rawLines.forEach((line) => {
    const colonIndex = line.indexOf(': ')
    if (colonIndex !== -1) {
      const prefix = line.slice(0, colonIndex + 1).trim()
      const rest = line.slice(colonIndex + 2).trim()
      if (prefix) result.push(prefix)
      if (rest) result.push(rest)
    } else {
      result.push(line)
    }
  })

  return result
}

function canCreateGrn(row: ReportHistoryWithGrn) {
  return (
    !props.readOnly &&
    row.reportType === 'OUTPUT' &&
    (row.canCreateGrn || row.grnStatus === 'FAILED')
  )
}

function canModifyRow(row: TeamAssignmentReportHistoryVm) {
  return !props.readOnly && (row.canModify || row.grnStatus === 'FAILED')
}

function getDeleteReportedAt(row: TeamAssignmentReportHistoryVm) {
  return row.targetReportedAt ?? row.occurredAt
}

function openDetail(row: TeamAssignmentReportHistoryVm) {
  detailItem.value = row
  detailDialogVisible.value = true
}
</script>

<template>
  <UCard>
    <template #title>
      <div
        class="flex cursor-pointer items-center justify-between gap-2 select-none"
        @click="isExpanded = !isExpanded"
      >
        <div class="flex items-center gap-2">
          <UIcon name="i-lucide-clock" class="size-5 text-primary" />
          <span class="font-semibold">Lịch sử báo cáo</span>
        </div>
        <UButton
          :label="isExpanded ? 'Thu gọn' : 'Xem lịch sử'"
          :icon="isExpanded ? 'i-lucide-chevron-up' : 'i-lucide-chevron-down'"
          color="primary"
          variant="subtle"
          size="xs"
          class="font-medium"
          @click.stop="isExpanded = !isExpanded"
        />
      </div>
    </template>

    <template #default v-if="isExpanded">
      <UTable :data="filteredHistory" :columns="columns" :loading="loading" class="text-sm">
        <template #empty>
          <div class="py-4 text-center text-sm text-toned">Chưa có báo cáo nào.</div>
        </template>

        <template #reportType-header>
          <ColumnMultiSelectFilter
            v-model="reportTypeFilter"
            :items="REPORT_TYPE_OPTIONS"
            placeholder="Loại nghiệp vụ"
          />
        </template>

        <template #reportType-cell="{ row }">
          <UBadge
            :label="getOperationLabel(row.original.reportType)"
            :color="getOperationSeverity(row.original.reportType)"
            class="text-xs"
          />
        </template>

        <template #actionType-header>
          <ColumnMultiSelectFilter
            v-model="actionTypeFilter"
            :items="ACTION_TYPE_OPTIONS"
            placeholder="Loại thao tác"
          />
        </template>

        <template #actionType-cell="{ row }">
          <UBadge
            :label="getActionLabel(row.original.actionType)"
            :color="getActionSeverity(row.original.actionType)"
            class="text-xs"
          />
        </template>

        <template #purchaseOrderType-cell="{ row }">
          <UBadge
            v-if="row.original.purchaseOrderType"
            :color="row.original.purchaseOrderType === 'POSITIVE' ? 'info' : 'success'"
            variant="soft"
          >
            {{ row.original.purchaseOrderType === 'POSITIVE' ? 'Hàng dương' : 'Hàng thường' }}
          </UBadge>
        </template>
        <template #quantities-cell="{ row }">
          <div class="flex min-w-72 flex-wrap items-center gap-x-2 gap-y-1">
            <span>{{ getSummary(row.original).visibleText || '-' }}</span>
            <span
              v-if="getSummary(row.original).remaining > 0"
              class="rounded-full bg-sky-100 px-2 py-0.5 text-xs font-semibold text-sky-700"
            >
              +{{ getSummary(row.original).remaining }}
            </span>
            <UButton
              v-if="row.original.quantities.length > 0"
              label="Xem chi tiết"
              variant="link"
              size="sm"
              class="px-0!"
              @click="openDetail(row.original)"
            />
          </div>
        </template>

        <template #totalQuantity-cell="{ row }">
          <span class="font-medium">{{ getTotalQuantityText(row.original) }}</span>
        </template>

        <template #actor-header>
          <ColumnMultiSelectFilter
            v-model="actorFilter"
            :items="actorOptions"
            placeholder="Người báo cáo"
          />
        </template>

        <template #actor-cell="{ row }">
          {{ row.original.actor?.name ?? 'System' }}
        </template>

        <template #occurredAt-header>
          <ColumnDateFilter v-model="dateRangeFilter" label="Thời gian báo cáo" />
        </template>

        <template #occurredAt-cell="{ row }">
          {{ formatDate(row.original.occurredAt) }}
        </template>

        <template #grn-cell="{ row }">
          <template v-if="row.original.reportType === 'OUTPUT'">
            <div
              class="flex max-w-162.5 min-w-125 flex-col items-start gap-1 font-normal wrap-break-word whitespace-normal"
            >
              <div class="flex flex-wrap items-center gap-2">
                <UBadge
                  :label="getGrnLabel(row.original)"
                  :color="getGrnColor(row.original)"
                  class="text-xs"
                />
                <UButton
                  v-if="canCreateGrn(row.original)"
                  :icon="
                    row.original.grnStatus === 'FAILED'
                      ? 'i-lucide-refresh-cw'
                      : 'i-lucide-package-plus'
                  "
                  :label="row.original.grnStatus === 'FAILED' ? 'Tạo lại GRN' : 'Tạo GRN'"
                  color="primary"
                  size="xs"
                  variant="outline"
                  @click="
                    emit('createGrn', row.original.targetReportedAt ?? row.original.occurredAt)
                  "
                />
              </div>
              <div
                v-if="row.original.grnMessage"
                :class="[
                  'max-w-162.5 min-w-125 space-y-0.5 text-xs font-normal break-all whitespace-normal',
                  row.original.grnStatus === 'FAILED' ? 'text-error' : 'text-toned',
                ]"
              >
                <div
                  v-for="(line, idx) in getGrnMessageLines(
                    row.original.grnMessage,
                    row.original.grnStatus === 'SUCCESS',
                  )"
                  :key="`${line}-${idx}`"
                  class="break-all whitespace-normal"
                >
                  {{ line }}
                </div>
              </div>
            </div>
          </template>
          <span v-else>-</span>
        </template>

        <template #reason-cell="{ row }">
          {{ row.original.reason || '-' }}
        </template>

        <template #actions-cell="{ row }">
          <div class="flex justify-end gap-2">
            <UButton
              v-if="canModifyRow(row.original)"
              icon="i-lucide-square-pen"
              label="Sửa"
              variant="outline"
              color="neutral"
              size="sm"
              @click="emit('startEdit', row.original)"
            />
            <UButton
              v-if="canModifyRow(row.original)"
              icon="i-lucide-trash-2"
              label="Xóa"
              color="error"
              size="sm"
              :loading="deleting"
              @click="
                row.original.grnStatus === 'FAILED'
                  ? emit('cancelGrn', getDeleteReportedAt(row.original))
                  : emit('confirmDelete', getDeleteReportedAt(row.original))
              "
            />
          </div>
        </template>
      </UTable>
    </template>
  </UCard>

  <UModal
    v-model:open="detailDialogVisible"
    title="Chi tiết số lượng báo cáo"
    class="max-w-[95vw] sm:max-w-3xl"
  >
    <template #body>
      <div v-if="detailItem" class="flex flex-col gap-3">
        <div class="text-sm text-default">
          {{ detailItem.productionCode }} - {{ getOperationLabel(detailItem.reportType) }} -
          {{ getActionLabel(detailItem.actionType) }}
        </div>
        <UTable :data="detailRows" :columns="detailColumns" class="text-sm">
          <template #purchaseOrderId-cell="{ row }">
            {{
              props.purchaseOrderCodes?.[row.original.purchaseOrderId] ??
              row.original.purchaseOrderId
            }}
          </template>
          <template #quantity-cell="{ row }">
            {{ formatQuantityItem(row.original) }}
          </template>
        </UTable>
      </div>
    </template>
  </UModal>
</template>
