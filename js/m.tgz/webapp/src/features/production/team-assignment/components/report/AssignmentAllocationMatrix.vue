<script setup lang="ts">
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import MatrixColorCell from '@/shared/components/grid/MatrixColorCell.vue'
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import { matrixGridCell } from '@/shared/components/grid/matrixGrid'
import type { GridColumn } from '@/shared/composables/useGridLayout'
import { computed } from 'vue'

import type { MatrixData, MatrixRow } from '@/shared/types'

interface Props {
  rows: MatrixRow[]
  allSizes: string[]
}

const props = defineProps<Props>()

const META_FIELDS: Array<{ prop: string; name: string }> = [
  { prop: 'syncDate', name: 'Ngày đồng bộ' },
  { prop: 'productDate', name: 'Ngày vào chuyền' },
  { prop: 'firstSku', name: 'Màu/Cỡ đầu tiên' },
  { prop: 'checkDate', name: 'Ngày kiểm hàng' },
  { prop: 'deliveryDate', name: 'Ngày giao hàng' },
]

const activeMetaFields = computed(() => {
  return META_FIELDS.filter((f) =>
    source.value.some((row) => {
      const val = row[f.prop]
      return val !== null && val !== undefined && String(val).trim() !== ''
    }),
  )
})

const maxNoteCount = computed(() =>
  Math.max(0, ...props.rows.map((r) => r.metadata?.notes.length ?? 0)),
)

const activeNoteIndices = computed(() => {
  const activeSet = new Set<number>()
  props.rows.forEach((row) => {
    row.metadata?.notes.forEach((note, i) => {
      if (note) activeSet.add(i)
    })
  })
  return Array.from(activeSet).sort((a, b) => a - b)
})

interface GridRow {
  poCode: string
  color: string
  totalByColor: { current: number; limit: number }
  destination: string
  checkDate: string
  isTotalBySize?: boolean
  [key: string]:
    | MatrixData
    | string
    | number
    | boolean
    | { current: number; limit: number }
    | undefined
}

const PROGRESS_CELL = matrixGridCell(MatrixQtyCell)
const COLOR_CELL = matrixGridCell(MatrixColorCell)

const source = computed((): GridRow[] => {
  const result: GridRow[] = props.rows.map((row) => {
    const flat: GridRow = {
      poCode: row.poCode!,
      color: row.color,
      totalByColor: { current: 0, limit: 0 },
      destination: row.destination!,
      checkDate: row.metadata?.checkDate ?? '',
      deliveryDate: row.metadata?.deliveryDate ?? '',
    }
    let totalReported = 0
    let totalAssigned = 0
    for (const size of props.allSizes) {
      const d = row.data[size] ?? { current: 0, limit: 0 }
      flat[size] = d
      if (typeof d === 'object' && d !== null) {
        totalReported += d.current
        totalAssigned += d.limit
      }
    }
    flat.totalByColor = { current: totalReported, limit: totalAssigned }
    for (let i = 0; i < maxNoteCount.value; i++) {
      flat[`note_${i}`] = row.metadata?.notes[i] ?? ''
    }
    return flat
  })

  if (props.rows.length === 0) return result

  let grandReported = 0
  let grandAssigned = 0
  const sizeSums: Record<string, { current: number; limit: number }> = {}

  for (const size of props.allSizes) {
    let sizeReported = 0
    let sizeAssigned = 0
    for (const row of props.rows) {
      const d = row.data[size]
      if (typeof d === 'object' && d !== null) {
        sizeReported += d.current || 0
        sizeAssigned += d.limit || 0
      }
    }
    sizeSums[size] = { current: sizeReported, limit: sizeAssigned }
    grandReported += sizeReported
    grandAssigned += sizeAssigned
  }

  const totalBySizeRow: GridRow = {
    poCode: '',
    destination: '',
    color: 'Tổng',
    isTotalBySize: true,
    checkDate: '',
    deliveryDate: '',
    totalByColor: { current: grandReported, limit: grandAssigned },
    ...sizeSums,
  }

  result.push(totalBySizeRow)
  return result
})

const columns = computed((): GridColumn[] => [
  {
    prop: 'poCode',
    name: 'Mã PO',
    pin: 'colPinStart',
    readonly: true,
  },
  {
    prop: 'destination',
    name: 'Thị trường',
    pin: 'colPinStart',
    readonly: true,
  },
  {
    prop: 'color',
    name: 'Màu',
    pin: 'colPinStart',
    readonly: true,
    cellTemplate: COLOR_CELL,
  },
  ...props.allSizes.map((size): GridColumn => ({
    prop: size,
    name: size,
    readonly: true,
    cellTemplate: PROGRESS_CELL,
  })),
  ...activeMetaFields.value.map((f): GridColumn => ({
    prop: f.prop,
    name: f.name,
    readonly: true,
  })),
  ...activeNoteIndices.value.map((i): GridColumn => ({
    prop: `note_${i}`,
    name: `Ghi chú ${i + 1}`,
    readonly: true,
  })),
  {
    prop: 'totalByColor',
    name: 'Tổng',
    pin: 'colPinEnd',
    readonly: true,
    cellTemplate: PROGRESS_CELL,
  },
])
</script>

<template>
  <BaseMatrixGrid :source="source" :columns="columns" class="border-0!" />
</template>
