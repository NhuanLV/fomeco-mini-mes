<script setup lang="ts">
import AssignmentAllocationMatrix from '@/features/production/team-assignment/components/report/AssignmentAllocationMatrix.vue'

import type { MatrixRow } from '@/shared/types'

defineProps<{
  rows: MatrixRow[]
  allSizes: string[]
}>()
</script>

<template>
  <UCard :ui="{ body: 'p-2 sm:p-3' }">
    <template #title>
      <div class="flex items-center gap-2">
        <UIcon name="i-lucide-list-tree" class="size-5 text-primary" />
        <span>Chi tiết phân bổ theo PO</span>
      </div>
    </template>
    <template #default>
      <AssignmentAllocationMatrix :rows="rows" :all-sizes="allSizes" />
    </template>
  </UCard>
</template>
