<script setup lang="ts">
import { getTeamAssignmentDetailQuery } from '@/api/@pinia/colada.gen'
import AssignmentAllocationMatrix from '@/features/production/team-assignment/components/report/AssignmentAllocationMatrix.vue'
import { transformToMatrix } from '@/shared/composables/useColorSizeMatrix'
import type { MatrixInputItem, MatrixRow } from '@/shared/types'
import { makeOrderComparator, sortValuesByOrder } from '@/shared/utils/orderedValues'
import { useQuery } from '@pinia/colada'
import { computed } from 'vue'

const props = defineProps<{
  assignmentId: string | null
}>()

const open = defineModel<boolean>('open', { default: false })

const { data: assignment, isLoading: loading } = useQuery(() => ({
  ...getTeamAssignmentDetailQuery({ path: { id: props.assignmentId ?? '' } }),
  enabled: !!props.assignmentId && open.value,
}))

const modalTitle = 'Ma trận Màu/Cỡ'

const allSizes = computed(() => {
  if (!assignment.value) return []
  return sortValuesByOrder(
    assignment.value.allocations.map((a) => a.size),
    assignment.value.styleSizeOrder,
  )
})

const cmpByPoThenColor = computed(() => {
  const cmpColor = makeOrderComparator(assignment.value?.styleColorOrder ?? [])
  return (left: { poCode?: string; color: string }, right: { poCode?: string; color: string }) => {
    const byPoCode = (left.poCode || '').localeCompare(right.poCode || '')
    if (byPoCode !== 0) return byPoCode
    return cmpColor(left.color, right.color)
  }
})

const matrixRows = computed((): MatrixRow[] => {
  if (!assignment.value) return []

  const items: MatrixInputItem[] = [
    ...assignment.value.allocations.map((a) => ({ ...a, kind: 'alloc' as const })),
    ...assignment.value.outputReportTotals.map((t) => ({ ...t, kind: 'progress' as const })),
  ]

  const purchaseOrderCodes = assignment.value.purchaseOrderCodes || {}
  return transformToMatrix(items, allSizes.value, {
    getColor: (i) => i.color,
    getSize: (i) => i.size,
    getQuantity: (i) => {
      if (i.kind === 'alloc') return { current: 0, limit: i.quantity || 0 }
      if (i.kind === 'progress') return { current: i.completedQty || 0, limit: 0 }
      return { current: 0, limit: 0 }
    },
    groupBy: (i) => `${i.purchaseOrderId}|${i.color}`,
    getExtra: (i) => ({
      purchaseOrderId: i.purchaseOrderId,
      poCode: purchaseOrderCodes[i.purchaseOrderId!] || i.purchaseOrderId,
    }),
  }).sort(cmpByPoThenColor.value)
})
</script>

<template>
  <UModal
    v-model:open="open"
    :title="modalTitle"
    class="max-w-[95vw] sm:max-w-[1000px] xl:max-w-[1200px]"
  >
    <template #body>
      <div v-if="loading" class="flex items-center justify-center p-8">
        <UIcon name="i-lucide-loader-2" class="size-8 animate-spin text-primary" />
        <span class="ml-2 text-toned">Đang tải dữ liệu ma trận...</span>
      </div>

      <div v-else-if="assignment" class="space-y-4 py-2">
        <div class="rounded-lg bg-surface-50 p-3 text-sm font-medium">
          <div class="grid grid-cols-2 gap-2 sm:grid-cols-5">
            <div>
              <span class="text-toned">Mã hàng: </span>
              <span class="font-semibold">{{ assignment.styleName }}</span>
            </div>
            <div>
              <span class="text-toned">Công đoạn: </span>
              <span class="font-semibold">{{ assignment.operation }}</span>
            </div>
            <div>
              <span class="text-toned">Tổ: </span>
              <span class="font-semibold">{{ assignment.teamName }}</span>
            </div>
            <div>
              <span class="text-toned">Xí nghiệp: </span>
              <span class="font-semibold">{{ assignment.factoryName }}</span>
            </div>
            <div>
              <span class="text-toned">Công ty: </span>
              <span class="font-semibold">{{ assignment.companyName }}</span>
            </div>
          </div>
        </div>

        <AssignmentAllocationMatrix :rows="matrixRows" :all-sizes="allSizes" />
      </div>

      <div v-else class="p-8 text-center text-toned">Không tìm thấy thông tin phân công.</div>
    </template>
  </UModal>
</template>
