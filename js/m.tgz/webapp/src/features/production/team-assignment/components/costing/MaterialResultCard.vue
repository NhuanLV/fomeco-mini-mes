<script setup lang="ts">
import type { TableColumn } from '@nuxt/ui'
import { fmtQty } from '@/shared/utils/fmtQty'

export type ResultRow = {
  matColor: string
  matSize: string
  productSize: string
  plannedQty: number
  required: number
  isSubtotal: boolean
  subtotalRequired: number
}

defineProps<{
  group: {
    articleName: string
    category: string
    uom: string
    grandTotal: number
    rows: ResultRow[]
  }
}>()

const columns: TableColumn<ResultRow>[] = [
  { id: 'matColor', header: 'Màu NPL' },
  { id: 'matSize', header: 'Cỡ NPL' },
  { id: 'productSize', header: 'Cỡ SP' },
  { id: 'plannedQty', header: 'SL kế hoạch' },
  { id: 'required', header: 'Yêu cầu' },
]
</script>

<template>
  <UCard class="border-surface-200">
    <template #title>
      <div class="flex items-center gap-3">
        <span>{{ group.articleName }}</span>
        <UBadge :label="group.category" color="neutral" />
        <span class="ml-auto font-bold text-primary">Tổng: {{ fmtQty(group.grandTotal) }}</span>
        <UBadge :label="group.uom" color="info" variant="soft" />
      </div>
    </template>
    <template #default>
      <UTable :data="group.rows" :columns class="overflow-hidden">
        <template #matColor-cell="{ row }">
          <span v-if="row.original.isSubtotal" class="text-primary uppercase opacity-70">
            Tổng ({{ row.original.matColor ?? '-' }} / {{ row.original.matSize ?? '-' }})
          </span>
          <span v-else>{{ row.original.matColor ?? '-' }}</span>
        </template>
        <template #matSize-cell="{ row }">
          <span v-if="!row.original.isSubtotal">{{ row.original.matSize ?? '-' }}</span>
        </template>
        <template #productSize-cell="{ row }">
          <span v-if="!row.original.isSubtotal">{{ row.original.productSize }}</span>
        </template>
        <template #plannedQty-cell="{ row }">
          <span v-if="!row.original.isSubtotal">{{ fmtQty(row.original.plannedQty) }}</span>
        </template>
        <template #required-cell="{ row }">
          <span :class="row.original.isSubtotal ? 'text-primary' : 'font-medium'">
            {{
              row.original.isSubtotal
                ? fmtQty(row.original.subtotalRequired)
                : fmtQty(row.original.required)
            }}
          </span>
        </template>
      </UTable>
    </template>
  </UCard>
</template>
