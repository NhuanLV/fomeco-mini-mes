import { shallowMount } from '@vue/test-utils'
import { beforeEach, expect, it, vi } from 'vitest'
import TeamAssignmentConsumptionTab from '../TeamAssignmentConsumptionTab.vue'

const mocks = vi.hoisted(() => ({
  queryIndex: 0,
  queryData: [] as unknown[],
  getBom: vi.fn(),
  confirm: vi.fn(),
}))

vi.mock('@/api', () => ({ getBomByBuyerOrderId: mocks.getBom }))
vi.mock('@/api/@pinia/colada.gen', () => ({
  getTeamAssignmentDetailQuery: vi.fn(),
  getTeamBomQuery: vi.fn(),
  getProductionOrderDetailQuery: vi.fn(),
  getBomByBuyerOrderIdQuery: vi.fn(),
}))
vi.mock('@pinia/colada', () => ({
  useQuery: () => ({
    data: { value: mocks.queryData[mocks.queryIndex++] },
    isLoading: { value: false },
  }),
}))
vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({ hasPermission: () => true }),
}))
vi.mock('@/shared/composables/useConfirm', () => ({
  useConfirm: () => ({ require: mocks.confirm }),
}))
vi.mock('../costing/TeamBomTable.vue', () => ({
  default: { name: 'TeamBomTable', props: ['beforeSave'], template: '<div />' },
}))
vi.mock('../costing/ConsumptionComparisonCard.vue', () => ({
  default: { name: 'ConsumptionComparisonCard', template: '<div />' },
}))

beforeEach(() => {
  mocks.queryIndex = 0
  mocks.getBom.mockReset()
  mocks.confirm.mockReset()
})

it('warns about every remaining excess after correcting only one of five materials', async () => {
  const bom = {
    teamAssignmentId: 'assignment-1',
    lines: Array.from({ length: 5 }, (_, index) => ({
      id: `line-${index}`,
      wfxBomLineId: `wfx-${index}`,
      articleName: `NPL ${index}`,
      isRequired: true,
      category: 'FABRIC',
      uom: 'M',
      destinationCodes: [],
      sizes: [{ productSize: 'S', materialSize: 'S', consumption: 2 }],
      colors: [{ productColor: 'Red', materialColor: 'Red', consumption: 0 }],
      cuttingColors: [],
    })),
  }
  const wfx = {
    buyerOrderId: 'bo-1',
    materials: bom.lines.map((line) => ({
      wfxBomLineId: line.wfxBomLineId,
      material: { name: line.articleName, category: 'FABRIC', uom: 'M', isRequired: true },
      sizeDeps: [{ productSize: 'S', materialSize: 'S', consumption: 1 }],
      colorDeps: line.colors,
      usedForOperations: [],
      usedForDestinations: [],
    })),
  }
  mocks.queryData = [
    {
      operation: 'SEW-1',
      teamId: 'team-1',
      productionOrderId: 'lsx-1',
      allocations: [{ purchaseOrderId: 'po-1', color: 'Red', size: 'S', quantity: 10 }],
      purchaseOrderDestinations: {},
      styleColorOrder: [],
      styleSizeOrder: [],
    },
    bom,
    { buyerOrderId: 'bo-1' },
    wfx,
  ]
  mocks.getBom.mockResolvedValue({ data: wfx })
  mocks.confirm.mockResolvedValue(false)
  const wrapper = shallowMount(TeamAssignmentConsumptionTab, { props: { id: 'assignment-1' } })
  const pending = structuredClone(bom)
  pending.lines[0].sizes[0].consumption = 1
  const beforeSave = wrapper.findComponent({ name: 'TeamBomTable' }).props('beforeSave')
  expect(await beforeSave(pending, ['line-0'])).toBe(false)
  expect(mocks.getBom).toHaveBeenCalledTimes(1)
  const message = mocks.confirm.mock.calls[0][0].message as string
  expect(message).not.toContain('NPL 0')
  for (const index of [1, 2, 3, 4]) expect(message).toContain(`NPL ${index} — Màu: Red`)
  wrapper.unmount()
})
