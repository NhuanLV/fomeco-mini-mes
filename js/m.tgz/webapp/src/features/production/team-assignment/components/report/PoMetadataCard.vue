<script setup lang="ts">
import type { ProductionOrderVm } from '@/api'
import { getProductionOrderNumber } from '@/features/production/helpers/productionOrder'
import { formatDate } from '@/shared/utils/date'

defineProps<{
  poDetail: ProductionOrderVm
}>()
</script>

<template>
  <UCard>
    <template #default>
      <div class="grid grid-cols-1 gap-4 md:grid-cols-5">
        <div class="flex flex-col gap-1 border-surface-200 last:border-0 md:border-r">
          <span class="text-[10px] font-bold tracking-wider text-toned uppercase">Mã hàng</span>
          <span class="font-bold text-highlighted">{{ poDetail.styleName || '---' }}</span>
        </div>
        <div class="flex flex-col gap-1 border-surface-200 last:border-0 md:border-r">
          <span class="text-[10px] font-bold tracking-wider text-toned uppercase">Số lệnh</span>
          <span class="font-bold text-highlighted">{{
            getProductionOrderNumber(poDetail.code)
          }}</span>
        </div>
        <div class="flex flex-col gap-1 border-surface-200 last:border-0 md:border-r">
          <span class="text-[10px] font-bold tracking-wider text-toned uppercase"
            >Ngày đồng bộ WFX</span
          >
          <span class="font-bold text-highlighted">
            {{ formatDate(poDetail.metadata?.syncDate || '') || '---' }}
          </span>
        </div>
        <div class="flex flex-col gap-1 border-surface-200 last:border-0 md:border-r">
          <span class="text-[10px] font-bold tracking-wider text-toned uppercase"
            >Ngày vào chuyền</span
          >
          <span class="font-bold text-highlighted">
            {{ formatDate(poDetail.metadata?.productDate || '') || '---' }}
          </span>
        </div>
        <div class="flex flex-col gap-1">
          <span class="text-[10px] font-bold tracking-wider text-toned uppercase"
            >Màu/Cỡ đầu tiên</span
          >
          <span class="font-bold text-highlighted">{{ poDetail.metadata?.firstSku || '---' }}</span>
        </div>
      </div>
    </template>
  </UCard>
</template>
