<script setup lang="ts">
import { getTeamAssignmentDetailQuery, getTeamBomQuery } from '@/api/@pinia/colada.gen'
import { useTeamMaterialCalculation } from '@/features/production/team-material/teamMaterialCalculation'
import { useWfxBomValidation } from '@/features/production/team-assignment/composables/useWfxBomValidation'
import { makeOrderComparator } from '@/shared/utils/orderedValues'
import ConsumptionComparisonCard from '@/features/production/team-assignment/components/costing/ConsumptionComparisonCard.vue'
import TeamBomTable from '@/features/production/team-assignment/components/costing/TeamBomTable.vue'
// Retained for the currently disabled total-requirements table below.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { useQuery } from '@pinia/colada'
import type { TableExpandedRows } from '@/shared/types/table'
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import type { TableColumn, TableRow } from '@nuxt/ui'
import { computed, ref } from 'vue'

const props = defineProps<{
  id: string
}>()

const id = computed(() => props.id)

const { data: assignment } = useQuery(() =>
  getTeamAssignmentDetailQuery({ path: { id: id.value } }),
)

const { data: bomData, isLoading: loadingBom } = useQuery(() =>
  getTeamBomQuery({ path: { id: id.value } }),
)

const { sizeRequirements, colorRequirements, comparisons, totalComparison, comparisonUom } =
  useTeamMaterialCalculation(assignment, bomData)

const { canEdit, displayedComparisons, checkWfxBeforeSave } = useWfxBomValidation(
  id,
  assignment,
  bomData,
  comparisons,
)

const requirements = computed(() =>
  isCutting.value ? colorRequirements.value : sizeRequirements.value,
)

const isCutting = computed(() => assignment.value?.operation === 'CUT-1')

const isNoRequirementsFound = computed(
  () =>
    !loadingBom.value &&
    !!bomData.value &&
    !!assignment.value?.allocations.length &&
    !requirements.value.length,
)

type RequirementDetailRow = {
  id: string
  productColor: string
  productSize: string
  qty: number
}

type RequirementGroupRow = {
  id: string
  articleName: string
  alternativeName?: string | null
  materialColor: string
  materialSize: string
  uom: string
  totalQty: number
  details: RequirementDetailRow[]
}

const expandedRows = ref<TableExpandedRows>({})

function toggleExpandedRow(rowId: string) {
  const current = { ...expandedRows.value }
  if (current[rowId]) {
    delete current[rowId]
  } else {
    current[rowId] = true
  }
  expandedRows.value = current
}

// Retained for the currently disabled total-requirements table below.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function expandAllRows() {
  expandedRows.value = Object.fromEntries(groupedTableData.value.map((row) => [row.id, true]))
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function collapseAllRows() {
  expandedRows.value = {}
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function handleRowClick(_event: Event, row: TableRow<RequirementGroupRow>) {
  toggleExpandedRow(row.original.id)
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const getRequirementRowId = (row: RequirementGroupRow) => row.id

// ── DataTable for size requirements ─────────────────────────────────────────

const groupedTableData = computed<RequirementGroupRow[]>(() => {
  const cmpColor = makeOrderComparator(assignment.value?.styleColorOrder ?? [])
  const cmpSize = makeOrderComparator(assignment.value?.styleSizeOrder ?? [])

  const groups = new Map<string, RequirementGroupRow>()

  for (const requirement of requirements.value) {
    const materialColor = requirement.materialColor || '-'
    const materialSize = requirement.materialSize || '-'
    const groupKey = [requirement.articleName, materialColor, materialSize, requirement.uom].join(
      '::',
    )
    const detailKey = [requirement.productColor, requirement.productSize].join('::')

    let group = groups.get(groupKey)
    if (!group) {
      group = {
        id: groupKey,
        articleName: requirement.articleName,
        alternativeName: requirement.alternativeName,
        materialColor,
        materialSize,
        uom: requirement.uom,
        totalQty: 0,
        details: [],
      }
      groups.set(groupKey, group)
    }

    group.totalQty += requirement.qty

    const existingDetail = group.details.find((detail) => detail.id === detailKey)
    if (existingDetail) {
      existingDetail.qty += requirement.qty
    } else {
      group.details.push({
        id: detailKey,
        productColor: requirement.productColor,
        productSize: requirement.productSize,
        qty: requirement.qty,
      })
    }
  }

  return Array.from(groups.values())
    .map((group) => ({
      ...group,
      details: [...group.details].sort((left, right) => {
        if (isCutting.value) {
          const byProductColor = cmpColor(left.productColor, right.productColor)
          if (byProductColor !== 0) return byProductColor

          return cmpSize(left.productSize, right.productSize)
        }

        const byProductSize = cmpSize(left.productSize, right.productSize)
        if (byProductSize !== 0) return byProductSize

        return cmpColor(left.productColor, right.productColor)
      }),
    }))
    .sort((left, right) => {
      const byArticleName = left.articleName.localeCompare(right.articleName, 'vi')
      if (byArticleName !== 0) return byArticleName

      if (isCutting.value) {
        const byMaterialColor = left.materialColor.localeCompare(right.materialColor, 'vi')
        if (byMaterialColor !== 0) return byMaterialColor

        return left.materialSize.localeCompare(right.materialSize, 'vi')
      }

      const byMaterialSize = left.materialSize.localeCompare(right.materialSize, 'vi')
      if (byMaterialSize !== 0) return byMaterialSize

      return left.materialColor.localeCompare(right.materialColor, 'vi')
    })
})
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const columns: TableColumn<RequirementGroupRow>[] = [
  { id: 'expand' },
  { accessorKey: 'articleName', header: 'NPL' },
  { accessorKey: 'alternativeName', header: 'Tên thay thế' },
  { accessorKey: 'uom', header: 'ĐVT' },
  { accessorKey: 'materialColor', header: 'Màu' },
  { accessorKey: 'materialSize', header: 'Cỡ' },
  { accessorKey: 'totalQty', header: 'Tổng định mức' },
]
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const detailColumns: TableColumn<RequirementDetailRow>[] = [
  { accessorKey: 'productColor', header: 'Màu thành phẩm' },
  { accessorKey: 'productSize', header: 'Cỡ thành phẩm' },
  { accessorKey: 'qty', header: 'Định mức' },
]
</script>

<template>
  <div class="space-y-6">
    <!-- BOM Table -->
    <TeamBomTable
      :read-only="assignment?.productionOrderStatus === 'CANCELLED'"
      v-if="assignment"
      :team-assignment-id="id"
      :production-order-id="assignment.productionOrderId"
      :operation-code="assignment.operation"
      :bom-data="bomData"
      :style-size-order="assignment.styleSizeOrder"
      :style-color-order="assignment.styleColorOrder"
      :before-save="checkWfxBeforeSave"
      view-mode="consumption"
    />

    <!-- Comparison (Cutting only) -->
    <ConsumptionComparisonCard
      v-if="(isCutting || canEdit) && displayedComparisons.length"
      :comparisons="displayedComparisons"
      :is-cutting="isCutting"
      :show-wfx="canEdit"
      :total-comparison="totalComparison"
      :comparison-uom="comparisonUom"
    />

    <!-- Empty result warning -->
    <div
      v-if="isNoRequirementsFound"
      class="rounded-lg border border-warning-200 bg-warning-50 p-4 text-sm text-warning-700"
    >
      <UIcon name="i-lucide-triangle-alert" class="mr-2" />
      NPL không có màu/cỡ/thị trường áp dụng cho LSX này.
    </div>

    <!-- Results (Ẩn bảng Tổng định mức cho cả lệnh để sau này có thể dùng lại) -->
    <!--
    <UCard v-if="requirements.length" class="border-surface-200">
      <template #title>
        <div class="flex items-center gap-2">
          <UIcon name="i-lucide-calculator" class="text-primary" />
          <span>Tổng định mức cho cả lệnh</span>
          <div class="ml-auto">
            <ExpandCollapseButtons @expand-all="expandAllRows" @collapse-all="collapseAllRows" />
          </div>
        </div>
      </template>
      <template #default>
        <UTable
          :data="groupedTableData"
          :columns="columns"
          v-model:expanded="expandedRows"
          :get-row-id="getRequirementRowId"
          :ui="{ tr: 'cursor-pointer' }"
          @select="handleRowClick"
        >
          <template #expand-cell="{ row }">
            <UIcon
              :name="
                expandedRows[row.original.id] ? 'i-lucide-chevron-down' : 'i-lucide-chevron-right'
              "
              class="text-toned"
            />
          </template>
          <template #alternativeName-cell="{ row }">
            {{ row.original.alternativeName || '-' }}
          </template>
          <template #totalQty-cell="{ row }">
            {{ fmtQty(row.original.totalQty) }}
          </template>
          <template #expanded="{ row }">
            <div class="bg-surface-50 p-4">
              <UTable :data="row.original.details" :columns="detailColumns">
                <template #qty-cell="{ row: detailRow }">
                  {{ fmtQty(detailRow.original.qty) }}
                </template>
              </UTable>
            </div>
          </template>
        </UTable>
      </template>
    </UCard>
    -->
  </div>
</template>
