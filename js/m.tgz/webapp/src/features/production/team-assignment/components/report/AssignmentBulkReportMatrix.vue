<script lang="ts" setup>
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import MatrixColorCell from '@/shared/components/grid/MatrixColorCell.vue'
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import {
  matrixGridCell,
  type MatrixGridBeforeEdit,
  type MatrixGridEdit,
} from '@/shared/components/grid/matrixGrid'
import type { GridColumn } from '@/shared/composables/useGridLayout'
import { computed, ref } from 'vue'
import { rejectComma } from '@/shared/utils/numberInput'

import type { MatrixData, MatrixRow } from '@/shared/types'

interface MatrixBulkItem {
  purchaseOrderId: string
  color: string
  size: string
  incrementQty: number | null
}

interface Props {
  rows: MatrixRow[]
  allSizes: string[]
  // Model for bulk data
  modelValue: MatrixBulkItem[]
}

const props = defineProps<Props>()
const emit = defineEmits<{
  (e: 'update:modelValue', val: MatrixBulkItem[]): void
}>()

const ALLOC_CELL = matrixGridCell(MatrixQtyCell)
const COLOR_CELL = matrixGridCell(MatrixColorCell)

const bulkMap = computed(() => {
  // Key by (purchaseOrderId|colorCode|colorName)
  const map: Record<string, Record<string, number | null>> = {}
  props.modelValue.forEach((item) => {
    const key = `${item.purchaseOrderId}|${item.color}`
    if (!map[key]) map[key] = {}
    map[key]![item.size] = item.incrementQty
  })
  return map
})

// We need a grid layout that provides access to the remainingQty
interface BulkGridRow {
  purchaseOrderId: string
  poCode: string
  color: string
  colorKey: string // composite "purchaseOrderId|colorCode|colorName"
  totalByColor: number | string
  total_demand?: number
  isTotalBySize?: boolean

  [sizeKey: string]: string | number | boolean | undefined
}

const source = computed((): BulkGridRow[] =>
  props.rows.map((row) => {
    const colorKey = `${row.purchaseOrderId!}|${row.color}`
    const flat: BulkGridRow = {
      purchaseOrderId: row.purchaseOrderId!,
      poCode: row.poCode!,
      color: row.color,
      colorKey,
      totalByColor: '',
    }
    let totalIncrement = 0
    let totalRemaining = 0

    for (const size of props.allSizes) {
      const dVal = row.data[size]
      const d = (
        typeof dVal === 'object' && dVal !== null ? dVal : { current: 0, limit: 0 }
      ) as MatrixData
      const increment = bulkMap.value[colorKey]?.[size] ?? null
      const remainingQty = Math.max(0, d.limit - d.current)

      flat[size] = increment || ''
      flat[`${size}_demand`] = remainingQty

      if (increment) totalIncrement += increment
      totalRemaining += remainingQty
    }

    flat.totalByColor = totalIncrement || ''
    flat.total_demand = totalRemaining

    return flat
  }),
)

const poFilter = ref<string[]>([])
const colorFilter = ref<string[]>([])
const sizeFilter = ref<string[]>([])

const poOptions = computed(() => {
  return Array.from(
    new Set(props.rows.map((row) => row.poCode).filter((value): value is string => !!value)),
  ).sort()
})

const colorOptions = computed(() => {
  return Array.from(
    new Set(props.rows.map((row) => row.color).filter((value): value is string => !!value)),
  ).sort()
})

const sizeOptions = computed(() => props.allSizes)

const filteredSizes = computed(() => {
  if (sizeFilter.value.length === 0) return props.allSizes
  return props.allSizes.filter((s) => sizeFilter.value.includes(s))
})

const filteredSource = computed(() => {
  const dataRows = source.value.filter((row) => {
    if (poFilter.value.length > 0 && !poFilter.value.includes(row.poCode)) return false
    return !(colorFilter.value.length > 0 && !colorFilter.value.includes(row.color))
  })

  if (dataRows.length === 0) return dataRows

  let grandTotal = 0
  const sizeSums: Record<string, number | string> = {}

  for (const size of filteredSizes.value) {
    let sumForSize = 0
    for (const row of dataRows) {
      const val = Number(row[size]) || 0
      sumForSize += val
    }
    sizeSums[size] = sumForSize || ''
    grandTotal += sumForSize
  }

  const totalBySizeRow: BulkGridRow = {
    purchaseOrderId: '',
    poCode: '',
    color: 'Tổng',
    colorKey: '__total_row__',
    isTotalBySize: true,
    totalByColor: grandTotal || '',
    ...sizeSums,
  }

  return [...dataRows, totalBySizeRow]
})

function clearFilters() {
  poFilter.value = []
  colorFilter.value = []
  sizeFilter.value = []
}

// ─── Column definitions ───────────────────────────────────────────────────────
const columns = computed((): GridColumn[] => [
  {
    prop: 'poCode',
    name: 'PO',
    pin: 'colPinStart',
    readonly: true,
  },
  {
    prop: 'color',
    name: 'Màu',
    pin: 'colPinStart',
    readonly: true,
    cellTemplate: COLOR_CELL,
  },
  ...filteredSizes.value.map((size): GridColumn => ({
    prop: size,
    name: size,
    readonly: (params) => Boolean(params?.model?.isTotalBySize),
    cellTemplate: ALLOC_CELL,
  })),
  {
    prop: 'totalByColor',
    name: 'Tổng',
    pin: 'colPinEnd',
    readonly: true,
    cellTemplate: ALLOC_CELL,
    cellProperties: () => ({
      class: 'font-mono text-primary',
    }),
  },
])

function applyRowData(
  updatedMap: { [colorKey: string]: { [size: string]: number | null } },
  rowIndex: number,
  prop: string,
  val: string | number | null,
) {
  const row = filteredSource.value[rowIndex]
  if (!row || row.isTotalBySize) return

  if (props.allSizes.includes(prop)) {
    let parsed = parseInt(String(val), 10)
    if (isNaN(parsed) || parsed < 0) {
      parsed = 0
    }

    const demand = Number(row[`${prop}_demand`]) || 0

    if (parsed > demand) {
      parsed = demand
    }

    const colorKey = row.colorKey as string
    if (!updatedMap[colorKey]) updatedMap[colorKey] = {}
    updatedMap[colorKey]![prop] = parsed > 0 ? parsed : null
  }
}

function handleBeforeEdit(edit: MatrixGridBeforeEdit) {
  if (edit.row?.isTotalBySize || filteredSource.value[edit.rowIndex]?.isTotalBySize) {
    edit.preventDefault()
  }
}

function handleAfterEdit(edits: MatrixGridEdit[]) {
  // Clone current map state ONCE locally (keyed by composite color)
  const updatedMap: { [colorKey: string]: { [size: string]: number | null } } = {}
  Object.keys(bulkMap.value).forEach((ck) => {
    updatedMap[ck] = { ...bulkMap.value[ck] }
  })

  for (const edit of edits) {
    applyRowData(updatedMap, edit.rowIndex, edit.prop, edit.value as string | number | null)
  }

  // Convert the mutated map back to an array and emit ONCE
  const newModelValue: MatrixBulkItem[] = []
  Object.keys(updatedMap).forEach((ck) => {
    // Decode composite key: "purchaseOrderId|color"
    const parts = ck.split('|')
    const purchaseOrderId = parts[0]!
    const color = parts[1]!
    const colorSizeMap = updatedMap[ck]
    if (colorSizeMap) {
      Object.keys(colorSizeMap).forEach((s) => {
        const qty = colorSizeMap[s]
        if (qty != null && qty > 0) {
          newModelValue.push({
            purchaseOrderId,
            color,
            size: s,
            incrementQty: qty,
          })
        }
      })
    }
  })

  emit('update:modelValue', newModelValue)
}

const bulkQty = ref<number | null>(null)

function handleBulkFill() {
  const qty = bulkQty.value
  if (qty == null || qty < 0) return

  const updatedMap: { [colorKey: string]: { [size: string]: number | null } } = {}
  Object.keys(bulkMap.value).forEach((ck) => {
    updatedMap[ck] = { ...bulkMap.value[ck] }
  })

  filteredSource.value
    .filter((row) => !row.isTotalBySize)
    .forEach((row) => {
      const colorKey = row.colorKey as string
      if (!updatedMap[colorKey]) updatedMap[colorKey] = {}

      filteredSizes.value.forEach((size) => {
        const demand = Number(row[`${size}_demand`]) || 0
        let parsed = qty
        if (parsed > demand) parsed = demand
        updatedMap[colorKey]![size] = parsed > 0 ? parsed : null
      })
    })

  const newModelValue: MatrixBulkItem[] = []
  Object.keys(updatedMap).forEach((ck) => {
    const parts = ck.split('|')
    const purchaseOrderId = parts[0]!
    const color = parts[1]!
    const colorSizeMap = updatedMap[ck]
    if (colorSizeMap) {
      Object.keys(colorSizeMap).forEach((s) => {
        const incrementQty = colorSizeMap[s]
        if (incrementQty != null && incrementQty > 0) {
          newModelValue.push({
            purchaseOrderId,
            color,
            size: s,
            incrementQty,
          })
        }
      })
    }
  })

  emit('update:modelValue', newModelValue)
  bulkQty.value = null
}
</script>

<template>
  <div class="flex flex-col gap-3">
    <div class="flex flex-wrap items-center gap-2">
      <USelectMenu
        multiple
        v-model="poFilter"
        :items="poOptions"
        placeholder="Mã PO"
        search-input
        class="w-48"
      />
      <USelectMenu
        multiple
        v-model="colorFilter"
        :items="colorOptions"
        placeholder="Màu"
        search-input
        class="w-48"
      />
      <USelectMenu
        multiple
        v-model="sizeFilter"
        :items="sizeOptions"
        placeholder="Size"
        search-input
        class="w-48"
      />
      <UButton
        v-if="poFilter.length > 0 || colorFilter.length > 0 || sizeFilter.length > 0"
        variant="ghost"
        color="neutral"
        @click="clearFilters"
        icon="i-lucide-filter-x"
      />
      <div class="ml-auto flex items-center gap-2">
        <UInput
          v-model.number="bulkQty"
          type="text"
          inputmode="numeric"
          placeholder="Số lượng..."
          class="w-32"
          min="0"
          step="1"
          @beforeinput="rejectComma"
        />
        <UButton
          label="Điền tất cả"
          color="info"
          variant="outline"
          class="shrink-0 whitespace-nowrap"
          @click="handleBulkFill"
        />
      </div>
    </div>
    <BaseMatrixGrid
      :columns="columns"
      :source="filteredSource"
      @afteredit="handleAfterEdit"
      @beforeedit="handleBeforeEdit"
    />
  </div>
</template>
