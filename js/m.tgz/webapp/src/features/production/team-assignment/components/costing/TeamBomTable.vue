<script setup lang="ts">
import type { TeamBomVm } from '@/api'
import { getTeamBomQueryKey, resetTeamBomMutation } from '@/api/@pinia/colada.gen'
import { useBomLineEditor } from '@/features/production/team-assignment/composables/useBomLineEditor'
import BomTableBase from '@/shared/components/bom/BomTableBase.vue'
import type { BomLine } from '@/shared/components/bom/types'
import { useAuthStore } from '@/shared/stores/auth'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useMutation, useQueryCache } from '@pinia/colada'
import type { TableExpandedRows } from '@/shared/types/table'
import { useConfirm } from '@/shared/composables/useConfirm'
import { computed, ref } from 'vue'
import { makeOrderComparator } from '@/shared/utils/orderedValues'

const props = defineProps<{
  teamAssignmentId: string
  productionOrderId: string
  operationCode?: string
  bomData?: TeamBomVm
  viewMode?: 'costing' | 'consumption'
  styleSizeOrder?: string[]
  styleColorOrder?: string[]
  beforeSave?: (bom: TeamBomVm) => Promise<boolean>
  readOnly?: boolean
}>()

const { hasPermission } = useAuthStore()
const confirm = useConfirm()
const isCutting = computed(() => props.operationCode === 'CUT-1')
const canEdit = computed(() => !props.readOnly && hasPermission('UPDATE_COSTING'))
const canEditCutting = computed(() => !props.readOnly && hasPermission('REPORT_PROGRESS'))

const { mutateAsync: reloadBoms, isLoading: isReloading } = useMutation(resetTeamBomMutation())
const queryCache = useQueryCache()
const bomQueryKey = computed(() => getTeamBomQueryKey({ path: { id: props.teamAssignmentId } }))
const expandedRows = ref<TableExpandedRows>({})
const isEditingBom = ref(false)
const isSavingBom = ref(false)

const handleReloadBoms = async () => {
  const performReload = async () => {
    try {
      await reloadBoms({
        path: { id: props.teamAssignmentId },
      })
      queryCache.invalidateQueries({ key: bomQueryKey.value })
      showSuccess('Đã cập nhật định mức từ LSX thành công')
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : 'Không thể cập nhật định mức'
      showError(message)
    }
  }

  if (props.bomData?.lines?.length) {
    confirm.require({
      header: 'Xác nhận ghi đè',
      message:
        'Tổ này đã có định mức. Việc cập nhật lại sẽ ghi đè toàn bộ dữ liệu hiện tại. Bạn có chắc chắn muốn tiếp tục?',
      icon: 'i-lucide-triangle-alert',
      acceptLabel: 'Đồng ý',
      rejectLabel: 'Hủy',
      acceptProps: { color: 'error' },
      accept: performReload,
    })
  } else {
    await performReload()
  }
}

const {
  editStates,
  ensureState,
  removeState,
  isLineDirty,
  onSizeCellEdit,
  onColorCellEdit,
  applyFirstToAll,
  handleSave,
} = useBomLineEditor(
  () => props.teamAssignmentId,
  () => props.bomData,
  () => props.styleSizeOrder ?? [],
  () => props.styleColorOrder ?? [],
)

const mappedLines = computed<BomLine[]>(() => {
  const compareSize = makeOrderComparator(props.styleSizeOrder ?? [])
  return (props.bomData?.lines || []).map((l) => ({
    id: l.id,
    articleName: l.articleName,
    articleCode: l.articleCode,
    alternativeName: l.alternativeName,
    isRequired: l.isRequired,
    uom: l.uom,
    sizes: l.sizes
      .map((s) => ({
        productSize: s.productSize,
        materialSize: s.materialSize || '',
        consumption: s.consumption,
      }))
      .sort(
        (left, right) =>
          compareSize(left.productSize, right.productSize) ||
          left.materialSize.localeCompare(right.materialSize),
      ),
    colors: l.colors.map((c) => {
      const cut = l.cuttingColors.find((cc) => cc.productColor === c.productColor)
      return {
        productColor: c.productColor,
        materialColor: c.materialColor || '',
        consumption: c.consumption ?? 0,
        cuttingConsumption: cut?.consumption ?? 0,
      }
    }),
    destinationCodes: l.destinationCodes,
    lastUpdatedAt: l.lastUpdatedAt,
    lastUpdatedBy: l.lastUpdatedBy,
  }))
})

function toggleExpand(row: BomLine) {
  // Thu gọn/mở hàng phải giữ bản nháp; chỉ xóa khi Hủy hoặc lưu thành công.
  if (!isEditingBom.value) return
  const originalLine = props.bomData?.lines.find((l) => l.id === row.id)
  if (originalLine) ensureState(originalLine)
}

function handleExpandAll(lines: BomLine[]) {
  lines.forEach((line) => {
    if (!editStates.has(line.id)) {
      const originalLine = props.bomData?.lines.find((l) => l.id === line.id)
      if (originalLine) ensureState(originalLine)
    }
  })
}

function startBomEdit() {
  handleExpandAll(mappedLines.value)
  expandedRows.value = Object.fromEntries(mappedLines.value.map((line) => [line.id, true]))
  isEditingBom.value = true
}

function cancelBomEdit() {
  editStates.forEach((_, lineId) => removeState(lineId))
  isEditingBom.value = false
}

async function saveBom() {
  if (isSavingBom.value) return
  isSavingBom.value = true
  try {
    if (canEdit.value && props.bomData && props.beforeSave) {
      const pending: TeamBomVm = {
        ...props.bomData,
        lines: props.bomData.lines.map((line) => {
          const state = editStates.get(line.id)
          return state
            ? {
                ...line,
                sizes: state.sizes.map((size) => ({ ...size, consumption: size.consumption ?? 0 })),
                colors: state.colors.map((color) => ({
                  productColor: color.productColor,
                  materialColor: color.materialColor,
                  consumption: color.consumption ?? 0,
                })),
              }
            : line
        }),
      }
      if (!(await props.beforeSave(pending))) return
    }
    let saved = false
    for (const line of mappedLines.value) {
      if (!isLineDirty(line.id)) continue
      if (!(await handleSave(line.id))) return
      saved = true
    }
    if (saved) showSuccess('Đã lưu thay đổi định mức')
    editStates.forEach((_, lineId) => removeState(lineId))
    isEditingBom.value = false
  } catch (error) {
    showError(error instanceof Error ? error.message : 'Không thể kiểm tra định mức WFX')
  } finally {
    isSavingBom.value = false
  }
}
</script>

<template>
  <UCard :inert="isSavingBom">
    <template #default>
      <BomTableBase
        title="Bảng định mức (BOM)"
        :lines="mappedLines"
        :style-color-order="styleColorOrder"
        :style-size-order="styleSizeOrder"
        v-model:expanded-rows="expandedRows"
        :edit-states="editStates"
        :can-edit="canEdit"
        :can-edit-color="canEdit && isCutting"
        :can-edit-cutting="canEditCutting"
        :is-cutting="isCutting"
        :show-reload="!!productionOrderId && canEdit"
        :reloading="isReloading"
        :show-bom-edit="canEdit || (isCutting && canEditCutting)"
        :editing-bom="isEditingBom"
        :saving-bom="isSavingBom"
        @toggle-expand="toggleExpand"
        @expand-all="handleExpandAll"
        @cell-edit-size="(_id, data, val) => onSizeCellEdit(data, val)"
        @cell-edit-color="(_id, data, field, val) => onColorCellEdit(data, field, val)"
        @apply-first="
          (lineId, field) =>
            applyFirstToAll(lineId, field, canEdit && isCutting, canEditCutting && isCutting)
        "
        @reload="handleReloadBoms"
        @start-bom-edit="startBomEdit"
        @cancel-bom-edit="cancelBomEdit"
        @save-bom="saveBom"
      />
    </template>
  </UCard>
</template>
