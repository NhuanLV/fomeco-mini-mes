import type { TeamAssignmentReportHistoryVm } from '@/api'
import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import ReportHistoryTable from '../ReportHistoryTable.vue'

describe('ReportHistoryTable.vue', () => {
  const mockHistory = [
    {
      occurredAt: '2026-08-05T10:00:00Z',
      reportType: 'INPUT' as const,
      actionType: 'CREATED' as const,
      productionCode: 'PO-001',
      actor: { id: 'u1', name: 'Nguyễn Văn A' },
      quantities: [{ color: 'Mã 1', size: 'XL', quantity: 10 }],
      canModify: false,
    },
    {
      occurredAt: '2026-08-05T11:00:00Z',
      reportType: 'OUTPUT' as const,
      actionType: 'UPDATED' as const,
      productionCode: 'PO-002',
      actor: { id: 'u2', name: 'Trần Thị B' },
      quantities: [{ color: 'Mã 2', size: 'L', quantity: 5 }],
      canModify: false,
    },
  ] as unknown as TeamAssignmentReportHistoryVm[]

  it('keeps mixed PO tags and resolves popup PO codes by ID', async () => {
    const history = ['REGULAR', 'POSITIVE'].map((purchaseOrderType, index) => ({
      ...mockHistory[0]!,
      purchaseOrderType,
      quantities: [{ purchaseOrderId: `po-${index}`, color: 'Red', size: 'S', quantity: 5 }],
    })) as TeamAssignmentReportHistoryVm[]
    const wrapper = mount(ReportHistoryTable, {
      props: {
        isExpanded: true,
        history,
        styleColorOrder: ['Red'],
        styleSizeOrder: ['S'],
        loading: false,
        currentType: 'INPUT',
        purchaseOrderCodes: { 'po-0': 'PO-duplicate', 'po-1': 'PO-duplicate' },
      },
    })
    expect(wrapper.text()).toContain('Hàng thường')
    expect(wrapper.text()).toContain('Hàng dương')
    const columns = wrapper.findAll('th').map((header) => header.text())
    expect(columns.indexOf('Loại PO')).toBe(
      columns.findIndex((header) => header.includes('Loại nghiệp vụ')) + 1,
    )
    await wrapper
      .findAll('button')
      .find((button) => button.text() === 'Xem chi tiết')!
      .trigger('click')
    expect(document.body.textContent).toContain('PO-duplicate')
    wrapper.unmount()
  })

  it('is collapsed by default and expands when toggled', async () => {
    const wrapper = mount(ReportHistoryTable, {
      props: {
        history: mockHistory,
        styleColorOrder: ['Mã 1', 'Mã 2'],
        styleSizeOrder: ['XL', 'L'],
        loading: false,
        currentType: 'INPUT',
      },
    })

    expect(wrapper.text()).toContain('Lịch sử báo cáo')
    expect(wrapper.text()).toContain('Xem lịch sử')
    expect(wrapper.text()).not.toContain('PO-001')

    await wrapper.find('button').trigger('click')
    expect(wrapper.text()).toContain('Thu gọn')
    expect(wrapper.text()).toContain('PO-001')
  })

  it('renders history table with filter headers when expanded', () => {
    const wrapper = mount(ReportHistoryTable, {
      props: {
        isExpanded: true,
        history: mockHistory,
        styleColorOrder: ['Mã 1', 'Mã 2'],
        styleSizeOrder: ['XL', 'L'],
        loading: false,
        currentType: 'INPUT',
      },
    })

    expect(wrapper.text()).toContain('Lịch sử báo cáo')
    expect(wrapper.text()).toContain('Tổng')
    expect(wrapper.text()).toContain('PO-001')
    expect(wrapper.text()).toContain('PO-002')
  })

  it('renders total quantity column correctly for created and updated reports', () => {
    const historyWithEdits = [
      {
        occurredAt: '2026-08-05T10:00:00Z',
        reportType: 'INPUT' as const,
        actionType: 'CREATED' as const,
        productionCode: 'PO-001',
        actor: { id: 'u1', name: 'Nguyễn Văn A' },
        quantities: [
          { color: 'Mã 1', size: 'XL', quantity: 10 },
          { color: 'Mã 1', size: 'L', quantity: 20 },
        ],
        canModify: false,
      },
      {
        occurredAt: '2026-08-05T11:00:00Z',
        reportType: 'OUTPUT' as const,
        actionType: 'UPDATED' as const,
        productionCode: 'PO-002',
        actor: { id: 'u2', name: 'Trần Thị B' },
        quantities: [{ color: 'Mã 2', size: 'L', quantity: 15, previousQuantity: 10 }],
        canModify: false,
      },
      {
        occurredAt: '2026-08-05T12:00:00Z',
        reportType: 'OUTPUT' as const,
        actionType: 'UPDATED' as const,
        productionCode: 'PO-003',
        actor: { id: 'u3', name: 'Lê Văn C' },
        quantities: [{ color: 'Mã 2', size: 'M', quantity: 3, previousQuantity: 8 }],
        canModify: false,
      },
    ] as unknown as TeamAssignmentReportHistoryVm[]

    const wrapper = mount(ReportHistoryTable, {
      props: {
        isExpanded: true,
        history: historyWithEdits,
        styleColorOrder: ['Mã 1', 'Mã 2'],
        styleSizeOrder: ['XL', 'L', 'M'],
        loading: false,
        currentType: 'INPUT',
      },
    })

    expect(wrapper.text()).toContain('30')
    expect(wrapper.text()).toContain('15 (+5)')
    expect(wrapper.text()).toContain('3 (-5)')
  })

  it('allows modifying report row even when currentType differs from row reportType', async () => {
    const historyWithModifiableInput = [
      {
        occurredAt: '2026-08-05T10:00:00Z',
        targetReportedAt: '2026-08-05T10:00:00Z',
        reportType: 'INPUT' as const,
        actionType: 'CREATED' as const,
        productionCode: 'PO-001',
        actor: { id: 'u1', name: 'Nguyễn Văn A' },
        quantities: [{ color: 'Mã 1', size: 'XL', quantity: 10 }],
        canModify: true,
      },
    ] as unknown as TeamAssignmentReportHistoryVm[]

    // Mount with currentType OUTPUT while row is INPUT
    const wrapper = mount(ReportHistoryTable, {
      props: {
        isExpanded: true,
        history: historyWithModifiableInput,
        styleColorOrder: ['Mã 1'],
        styleSizeOrder: ['XL'],
        loading: false,
        currentType: 'OUTPUT',
      },
    })

    expect(wrapper.text()).toContain('Sửa')
    expect(wrapper.text()).toContain('Xóa')

    const editBtn = wrapper.findAll('button').find((b) => b.text() === 'Sửa')
    expect(editBtn).toBeDefined()
    await editBtn!.trigger('click')

    expect(wrapper.emitted('startEdit')).toBeTruthy()
    expect(wrapper.emitted('startEdit')![0][0]).toEqual(historyWithModifiableInput[0])

    const deleteBtn = wrapper.findAll('button').find((b) => b.text() === 'Xóa')
    expect(deleteBtn).toBeDefined()
    await deleteBtn!.trigger('click')

    expect(wrapper.emitted('confirmDelete')).toBeTruthy()
    expect(wrapper.emitted('confirmDelete')![0][0]).toBe('2026-08-05T10:00:00Z')
  })

  it('displays "Không áp dụng" and does not display create GRN button when grnStatus is NOT_APPLICABLE', () => {
    const historyWithNotApplicable = [
      {
        occurredAt: '2026-08-05T10:00:00Z',
        reportType: 'OUTPUT' as const,
        actionType: 'CREATED' as const,
        productionCode: 'PO-001',
        actor: { id: 'u1', name: 'Nguyễn Văn A' },
        quantities: [{ color: 'Mã 1', size: 'XL', quantity: 10 }],
        canModify: false,
        grnStatus: 'NOT_APPLICABLE' as const,
        canCreateGrn: false,
      },
    ] as unknown as TeamAssignmentReportHistoryVm[]

    const wrapper = mount(ReportHistoryTable, {
      props: {
        isExpanded: true,
        history: historyWithNotApplicable,
        styleColorOrder: ['Mã 1'],
        styleSizeOrder: ['XL'],
        loading: false,
        currentType: 'OUTPUT',
      },
    })

    expect(wrapper.text()).toContain('Không áp dụng')
    expect(wrapper.text()).not.toContain('Tạo GRN')
    expect(wrapper.text()).not.toContain('Tạo lại GRN')
  })
})
