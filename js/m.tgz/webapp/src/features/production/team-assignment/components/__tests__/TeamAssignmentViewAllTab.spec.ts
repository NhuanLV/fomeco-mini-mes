import type { ProductionOrderVm, TeamAssignmentDetailVm } from '@/api'
import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import TeamAssignmentViewAllTab from '../TeamAssignmentViewAllTab.vue'

describe('TeamAssignmentViewAllTab.vue', () => {
  const mockProductionOrder: ProductionOrderVm = {
    id: 'po-1',
    code: 'PO-TEST-001',
    poCode: 'PO-001',
    buyerOrderId: 'bo-1',
    mainCompanyCode: 'CP1',
    factories: [{ id: 'f-1', name: 'Xí nghiệp 1', unitPath: '/f1' }],
    styleName: 'Áo thun polo',
    status: 'IN_PROGRESS',
    teamCount: 2,
    sewingTeams: [{ id: 'team-1', name: 'Tổ 1' }],
    totalQuantity: 100,
    createdAt: '2026-09-01T00:00:00Z',
    needsAllocationRevision: false,
    historicalColorSizePairs: [],
    poSummaries: [
      {
        poId: 'po-sub-1',
        poCode: 'PO-SUB-01',
        destination: 'US',
        totalQuantity: 100,
        completedQuantity: 40,
        progressPercentage: 40,
      },
    ],
    teamAssignments: [
      {
        id: 'ta-1',
        teamId: 'team-1',
        teamName: 'Tổ Cắt 1',
        factoryName: 'Xí nghiệp Cắt',
        companyName: 'Công ty Cổ phần A',
        operation: 'CUT-1',
        allocations: [
          {
            purchaseOrderId: 'po-sub-1',
            color: 'Đỏ',
            size: 'M',
            quantity: 50,
            notes: [],
          },
          {
            purchaseOrderId: 'po-sub-1',
            color: 'Đỏ',
            size: 'L',
            quantity: 50,
            notes: [],
          },
        ],
        outputReportTotals: [
          {
            purchaseOrderId: 'po-sub-1',
            color: 'Đỏ',
            size: 'M',
            completedQty: 30,
          },
        ],
        inputReportTotals: [],
        totalReported: 30,
        assignedAt: '2026-09-01T00:00:00Z',
        code: 'PO-TEST-001',
        reconciliationStatus: 'NORMAL',
        displayStatus: 'IN_PROGRESS',
        hasPendingMaterialSupplement: false,
      },
      {
        id: 'ta-2',
        teamId: 'team-2',
        teamName: 'Tổ May 1',
        factoryName: 'Xí nghiệp May',
        companyName: 'Công ty Cổ phần A',
        operation: 'SEW-1',
        allocations: [
          {
            purchaseOrderId: 'po-sub-1',
            color: 'Đỏ',
            size: 'M',
            quantity: 50,
            notes: [],
          },
          {
            purchaseOrderId: 'po-sub-1',
            color: 'Đỏ',
            size: 'L',
            quantity: 50,
            notes: [],
          },
        ],
        outputReportTotals: [
          {
            purchaseOrderId: 'po-sub-1',
            color: 'Đỏ',
            size: 'M',
            completedQty: 20,
          },
        ],
        inputReportTotals: [],
        totalReported: 20,
        assignedAt: '2026-09-01T00:00:00Z',
        code: 'PO-TEST-001',
        reconciliationStatus: 'NORMAL',
        displayStatus: 'IN_PROGRESS',
        hasPendingMaterialSupplement: false,
      },
    ],
  }

  const mockCurrentAssignment: TeamAssignmentDetailVm = {
    productionOrderStatus: 'IN_PROGRESS',
    id: 'ta-2',
    productionOrderId: 'po-1',
    productionCode: 'PO-TEST-001',
    styleName: 'Áo thun polo',
    styleColorOrder: ['Đỏ'],
    styleSizeOrder: ['M', 'L'],
    factoryName: 'Xí nghiệp May',
    companyName: 'Công ty Cổ phần A',
    companyId: 'cp-1',
    teamId: 'team-2',
    teamName: 'Tổ May 1',
    operation: 'SEW-1',
    allocations: [
      {
        purchaseOrderId: 'po-sub-1',
        color: 'Đỏ',
        size: 'M',
        quantity: 50,
        notes: [],
      },
      {
        purchaseOrderId: 'po-sub-1',
        color: 'Đỏ',
        size: 'L',
        quantity: 50,
        notes: [],
      },
    ],
    outputReportTotals: [
      {
        purchaseOrderId: 'po-sub-1',
        color: 'Đỏ',
        size: 'M',
        completedQty: 20,
      },
    ],
    inputReportTotals: [],
    metadataRows: [],
    purchaseOrderTypes: {},
    purchaseOrderCodes: {
      'po-sub-1': 'PO-SUB-01',
    },
    purchaseOrderDestinations: {
      'po-sub-1': 'US',
    },
    assignedAt: '2026-09-01T00:00:00Z',
    reconciliationStatus: 'NORMAL',
  }

  it('renders operation pills with options and defaults to Tất cả', () => {
    const wrapper = mount(TeamAssignmentViewAllTab, {
      props: {
        productionOrder: mockProductionOrder,
        currentAssignment: mockCurrentAssignment,
        currentAssignmentId: 'ta-2',
      },
    })

    expect(wrapper.text()).toContain('Công đoạn:')
    expect(wrapper.text()).toContain('Tất cả')
    expect(wrapper.text()).toContain('CUT-1')
    expect(wrapper.text()).toContain('SEW-1')
    // When default is ALL, all assignments are displayed
    expect(wrapper.text()).toContain('Tổ Cắt 1')
    expect(wrapper.text()).toContain('Tổ May 1')
  })

  it('selects and disables filters that only have one option', async () => {
    const wrapper = mount(TeamAssignmentViewAllTab, {
      props: {
        productionOrder: mockProductionOrder,
        currentAssignment: mockCurrentAssignment,
        currentAssignmentId: 'ta-2',
      },
    })

    const disabledFilters = wrapper.findAll('button:disabled').map((filter) => filter.text())
    expect(disabledFilters).toEqual(
      expect.arrayContaining(['Công ty Cổ phần A', 'PO-SUB-01', 'Đỏ']),
    )
    expect(wrapper.find('[aria-label="Xóa bộ lọc"]').exists()).toBe(false)
  })

  it('filters assignment card when selecting a specific operation', async () => {
    const wrapper = mount(TeamAssignmentViewAllTab, {
      props: {
        productionOrder: mockProductionOrder,
        currentAssignment: mockCurrentAssignment,
        currentAssignmentId: 'ta-2',
      },
    })

    const cutButton = wrapper.findAll('button').find((b) => b.text().trim() === 'CUT-1')
    expect(cutButton).toBeDefined()
    await cutButton!.trigger('click')

    expect(wrapper.text()).toContain('Tổ Cắt 1')
    expect(wrapper.text()).not.toContain('Tổ May 1')
  })

  it('renders current assignment badge when current assignment is displayed', async () => {
    const wrapper = mount(TeamAssignmentViewAllTab, {
      props: {
        productionOrder: mockProductionOrder,
        currentAssignment: mockCurrentAssignment,
        currentAssignmentId: 'ta-2',
      },
    })

    // Click SEW-1 button to show Tổ May 1
    const sewButton = wrapper.findAll('button').find((b) => b.text().trim() === 'SEW-1')
    expect(sewButton).toBeDefined()
    await sewButton!.trigger('click')

    expect(wrapper.text()).toContain('Tổ May 1')
    expect(wrapper.text()).toContain('LCĐ hiện tại')
  })

  it('shows empty state when no assignments match', async () => {
    const emptyPo: ProductionOrderVm = {
      ...mockProductionOrder,
      teamAssignments: [],
    }
    const wrapper = mount(TeamAssignmentViewAllTab, {
      props: {
        productionOrder: emptyPo,
        currentAssignment: mockCurrentAssignment,
        currentAssignmentId: 'ta-2',
      },
    })

    expect(wrapper.text()).toContain('Không tìm thấy dữ liệu lệnh công đoạn phù hợp')
  })
})
