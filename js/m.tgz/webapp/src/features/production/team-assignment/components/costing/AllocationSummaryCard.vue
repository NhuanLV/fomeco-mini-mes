<script setup lang="ts">
import type { TableColumn } from '@nuxt/ui'
import { computed } from 'vue'

export interface AllocationRow {
  name: string
  key: string
  [size: string]: string | number | null
}

const props = defineProps<{
  allocationRows: AllocationRow[]
  allSizes: string[]
}>()

const columns = computed<TableColumn<AllocationRow>[]>(() => [
  { accessorKey: 'name', header: 'Màu / Cỡ' },
  ...props.allSizes.map((size) => ({ accessorKey: size, header: size })),
])
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex items-center gap-2">
        <UIcon name="i-lucide-calculator" class="text-primary" />
        <span>Tổng sản lượng LSX</span>
      </div>
    </template>
    <template #default>
      <UTable :data="allocationRows" :columns>
        <template v-for="s in allSizes" :key="s" #[`${s}-cell`]="{ row }">
          <span v-if="row.original[s]" class="font-medium">{{ row.original[s] }}</span>
          <span v-else class="text-toned">-</span>
        </template>
      </UTable>
    </template>
  </UCard>
</template>
