<script setup lang="ts">
import type { TeamMaterialComparison } from '@/features/production/team-material/teamMaterialCalculation'
import { fmtQty } from '@/shared/utils/fmtQty'
import Big from 'big.js'
import type { TableColumn } from '@nuxt/ui'
import { computed } from 'vue'
import ColumnMultiSelectFilter from '@/shared/components/ColumnMultiSelectFilter.vue'
import { useColumnFilters } from '@/shared/composables/useColumnFilters'

const props = defineProps<{
  isCutting?: boolean
  showWfx?: boolean
  comparisons: TeamMaterialComparison[]
  totalComparison: {
    bySizeQty: number
    byColorQty: number
    byCutterQty: number
  }
  comparisonUom: string
}>()

const sortedComparisons = computed(() =>
  [...props.comparisons].sort(
    (left, right) =>
      left.articleName.localeCompare(right.articleName, 'vi') ||
      left.materialColor.localeCompare(right.materialColor, 'vi'),
  ),
)

const filterColumns = {
  articleName: { label: 'NPL', values: (row: TeamMaterialComparison) => [row.articleName] },
  articleCode: { label: 'Mã NPL', values: (row: TeamMaterialComparison) => [row.articleCode] },
  alternativeName: {
    label: 'Tên thay thế',
    values: (row: TeamMaterialComparison) => [row.alternativeName],
    includeEmpty: false,
  },
  uom: { label: 'ĐVT', values: (row: TeamMaterialComparison) => [row.uom] },
  materialColor: {
    label: 'Màu',
    values: (row: TeamMaterialComparison) => [row.materialColor],
  },
}
const { filters, options, filteredRows, clearFilters } = useColumnFilters(
  () => sortedComparisons.value,
  filterColumns,
)

function diffVal(a: number, b: number) {
  return new Big(a).minus(b)
}

function fmtDiff(a: number, b: number): string {
  const d = diffVal(a, b)
  return (d.gt(0) ? '+' : '') + fmtQty(d.toNumber())
}

function diffClass(a: number, b: number): string {
  const d = diffVal(a, b)
  return d.eq(0) ? 'text-toned' : d.lt(0) ? 'text-red-500' : 'text-green-500'
}

const columns = computed<TableColumn<TeamMaterialComparison>[]>(() => [
  { accessorKey: 'articleName', header: 'NPL', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'articleCode', header: 'Mã NPL', meta: { class: { th: 'p-0!' } } },
  { id: 'alternativeName', header: 'Tên thay thế', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'uom', header: 'ĐVT', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'materialColor', header: 'Màu', meta: { class: { th: 'p-0!' } } },
  ...(props.showWfx ? [{ id: 'byWfxSizeQty', header: 'Theo cỡ (WFX)' }] : []),
  { id: 'bySizeQty', header: 'Theo cỡ (Kỹ thuật)' },
  ...(props.isCutting
    ? [
        { id: 'byColorQty', header: 'Theo Màu (Kỹ thuật)' },
        { id: 'byCutterQty', header: 'Theo Màu (Tổ cắt)' },
      ]
    : []),
])
</script>

<template>
  <UCard class="border-surface-200">
    <template #title>
      <div class="flex items-center gap-2">
        <UIcon name="i-lucide-chart-bar" class="text-primary" />
        <span>{{ isCutting !== false ? 'So sánh định mức (Cỡ vs Màu)' : 'So sánh định mức' }}</span>
        <UButton
          class="ml-auto"
          icon="i-lucide-filter-x"
          aria-label="Xóa bộ lọc"
          title="Xóa bộ lọc"
          color="neutral"
          variant="ghost"
          :disabled="!Object.values(filters).some((values) => values.length)"
          @click="clearFilters"
        />
      </div>
    </template>
    <template #default>
      <UTable :data="filteredRows" :columns class="overflow-hidden">
        <template v-for="(column, key) in filterColumns" :key="key" #[`${key}-header`]>
          <ColumnMultiSelectFilter
            :model-value="filters[key]!"
            :items="options[key]!"
            :disabled="!options[key]!.length"
            :placeholder="column.label"
            :aria-label="`Lọc ${column.label.toLowerCase()}`"
            :search-placeholder="`Tìm ${column.label.toLowerCase()}...`"
            @update:model-value="filters[key] = $event"
          />
        </template>
        <template #empty>Không có NPL phù hợp.</template>
        <template #articleCode-cell="{ row }">
          {{ row.original.articleCode || '-' }}
        </template>
        <template #alternativeName-cell="{ row }">
          {{ row.original.alternativeName || '-' }}
        </template>
        <template #byWfxSizeQty-cell="{ row }">
          <span class="font-medium">{{
            row.original.byWfxSizeQty == null ? '-' : fmtQty(row.original.byWfxSizeQty)
          }}</span>
        </template>
        <template #bySizeQty-cell="{ row }">
          <div class="flex flex-col">
            <span class="font-medium">{{ fmtQty(row.original.bySizeQty) }}</span>
            <small
              v-if="isCutting !== false"
              class="font-normal"
              :class="diffClass(row.original.bySizeQty, row.original.byColorQty)"
            >
              ({{ fmtDiff(row.original.bySizeQty, row.original.byColorQty) }})
            </small>
          </div>
        </template>
        <template #byColorQty-cell="{ row }">
          <span class="font-medium">{{ fmtQty(row.original.byColorQty) }}</span>
        </template>
        <template #byCutterQty-cell="{ row }">
          <div class="flex flex-col">
            <span class="font-medium">{{ fmtQty(row.original.byCutterQty) }}</span>
            <small
              class="font-normal"
              :class="diffClass(row.original.byCutterQty, row.original.byColorQty)"
            >
              ({{ fmtDiff(row.original.byCutterQty, row.original.byColorQty) }})
            </small>
          </div>
        </template>
      </UTable>
    </template>
  </UCard>
</template>
