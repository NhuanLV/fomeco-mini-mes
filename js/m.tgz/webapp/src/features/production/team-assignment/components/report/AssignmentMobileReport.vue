<script setup lang="ts">
import { computed, ref } from 'vue'

import type { MatrixData, MatrixRow } from '@/shared/types'

interface MatrixBulkItem {
  purchaseOrderId: string
  color: string
  size: string
  incrementQty: number | null
}

interface Props {
  rows: MatrixRow[]
  allSizes: string[]
  modelValue: MatrixBulkItem[]
  disabled?: boolean
}

const props = defineProps<Props>()
const emit = defineEmits<{
  (e: 'update:modelValue', val: MatrixBulkItem[]): void
  (e: 'submit'): void
}>()

const expandedPO = ref<string | null>(null)
const expandedColor = ref<string | null>(null)

function togglePO(id: string) {
  if (expandedPO.value === id) {
    expandedPO.value = null
    expandedColor.value = null
  } else {
    expandedPO.value = id
    expandedColor.value = null
  }
}

function toggleColor(key: string) {
  expandedColor.value = expandedColor.value === key ? null : key
}

const poGroups = computed(() => {
  const groups: Record<string, { poCode: string; rows: MatrixRow[] }> = {}
  props.rows.forEach((r) => {
    const poId = r.purchaseOrderId!
    if (!groups[poId]) {
      groups[poId] = { poCode: r.poCode!, rows: [] }
    }
    groups[poId]!.rows.push(r)
  })
  return groups
})

if (props.modelValue.length > 0) {
  const firstItem = props.modelValue[0]!
  expandedPO.value = firstItem.purchaseOrderId
  expandedColor.value = `${firstItem.purchaseOrderId}|${firstItem.color}`
} else if (Object.keys(poGroups.value).length > 0) {
  expandedPO.value = Object.keys(poGroups.value)[0]!
}

function getQty(poId: string, color: string, size: string): number {
  const item = props.modelValue.find(
    (i) => i.purchaseOrderId === poId && i.color === color && i.size === size,
  )
  return item?.incrementQty ?? 0
}

function updateQty(poId: string, color: string, size: string, val: number | null, max: number) {
  let currentVal = val || 0
  if (currentVal < 0) currentVal = 0
  if (currentVal > max) currentVal = max

  const newModel = [...props.modelValue]
  const existingIdx = newModel.findIndex(
    (i) => i.purchaseOrderId === poId && i.color === color && i.size === size,
  )

  if (currentVal <= 0) {
    if (existingIdx >= 0) newModel.splice(existingIdx, 1)
  } else {
    if (existingIdx >= 0) {
      newModel[existingIdx] = { ...newModel[existingIdx], incrementQty: currentVal }
    } else {
      newModel.push({
        purchaseOrderId: poId,
        color,
        size,
        incrementQty: currentVal,
      })
    }
  }

  emit('update:modelValue', newModel)
}

function getColorTotal(poId: string, color: string) {
  return props.modelValue
    .filter((i) => i.purchaseOrderId === poId && i.color === color)
    .reduce((sum, item) => sum + (item.incrementQty || 0), 0)
}

function getPOTotal(poId: string) {
  return props.modelValue
    .filter((i) => i.purchaseOrderId === poId)
    .reduce((sum, item) => sum + (item.incrementQty || 0), 0)
}

function getSizeData(row: MatrixRow, size: string): MatrixData {
  const dVal = row.data[size]
  return (typeof dVal === 'object' && dVal !== null ? dVal : { current: 0, limit: 0 }) as MatrixData
}

const totalReportedCount = computed(() => {
  return props.modelValue.reduce((sum, item) => sum + (item.incrementQty || 0), 0)
})
</script>

<template>
  <div class="mobile-report-nested flex flex-col gap-3 text-highlighted select-none">
    <div
      v-for="(group, poId) in poGroups"
      :key="poId"
      class="overflow-hidden rounded-xl border border-surface-200 bg-surface-0 shadow-sm transition-all"
    >
      <div
        class="flex cursor-pointer items-center justify-between bg-surface-50/50 p-4"
        @click="togglePO(poId as string)"
      >
        <div class="flex flex-col">
          <span class="text-lg font-bold text-primary">{{ group.poCode }}</span>
        </div>
        <div class="flex items-center gap-3">
          <div
            v-if="getPOTotal(poId as string) > 0"
            class="rounded bg-primary/10 px-2 py-0.5 text-sm font-semibold text-primary"
          >
            +{{ getPOTotal(poId as string) }}
          </div>
          <UIcon :name="expandedPO === poId ? 'i-lucide-chevron-up' : 'i-lucide-chevron-down'" />
        </div>
      </div>

      <div
        v-if="expandedPO === poId"
        class="divide-y divide-surface-100 border-t border-surface-100"
      >
        <div v-for="row in group.rows" :key="row.color" class="flex flex-col">
          <div
            class="flex cursor-pointer items-center justify-between p-4 active:bg-surface-50"
            :class="{ 'bg-primary/5': expandedColor === `${poId}|${row.color}` }"
            @click="toggleColor(`${poId}|${row.color}`)"
          >
            <div class="flex flex-col">
              <span class="font-semibold text-highlighted">{{ row.color }}</span>
            </div>
            <div class="flex items-center gap-2">
              <span
                v-if="getColorTotal(row.purchaseOrderId!, row.color) > 0"
                class="font-semibold text-primary"
              >
                +{{ getColorTotal(row.purchaseOrderId!, row.color) }}
              </span>
              <UIcon
                :name="
                  expandedColor === `${poId}|${row.color}`
                    ? 'i-lucide-chevron-up'
                    : 'i-lucide-chevron-down'
                "
                class="text-xs text-toned"
              />
            </div>
          </div>

          <div v-if="expandedColor === `${poId}|${row.color}`" class="bg-surface-50/30 p-4 pt-0">
            <div class="divide-y divide-surface-100">
              <template v-for="size in allSizes" :key="size">
                <div
                  v-if="getSizeData(row, size).limit > 0"
                  class="flex items-center justify-between py-3"
                >
                  <div class="flex flex-col">
                    <span class="font-medium">{{ size }}</span>
                    <span class="text-[10px] text-toned"
                      >Còn:
                      {{
                        Math.max(0, getSizeData(row, size).limit - getSizeData(row, size).current)
                      }}</span
                    >
                  </div>

                  <div class="flex items-center gap-2">
                    <UButton
                      icon="i-lucide-minus"
                      variant="ghost"
                      color="neutral"
                      class="h-10! w-10! border bg-surface-0 p-2!"
                      :disabled="getQty(row.purchaseOrderId!, row.color, size) <= 0"
                      @click="
                        updateQty(
                          row.purchaseOrderId!,
                          row.color,
                          size,
                          getQty(row.purchaseOrderId!, row.color, size) - 1,
                          getSizeData(row, size).limit - getSizeData(row, size).current,
                        )
                      "
                    />

                    <UInput
                      type="number"
                      :model-value="getQty(row.purchaseOrderId!, row.color, size)"
                      min="0"
                      :max="getSizeData(row, size).limit - getSizeData(row, size).current"
                      class="w-16 border-none bg-transparent p-0 text-center text-lg font-semibold"
                      @update:model-value="
                        updateQty(
                          row.purchaseOrderId!,
                          row.color,
                          size,
                          Number($event),
                          getSizeData(row, size).limit - getSizeData(row, size).current,
                        )
                      "
                    />

                    <UButton
                      icon="i-lucide-plus"
                      variant="ghost"
                      class="h-10! w-10! border border-primary/50 bg-surface-0 p-2!"
                      :disabled="
                        getQty(row.purchaseOrderId!, row.color, size) >=
                        getSizeData(row, size).limit - getSizeData(row, size).current
                      "
                      @click="
                        updateQty(
                          row.purchaseOrderId!,
                          row.color,
                          size,
                          getQty(row.purchaseOrderId!, row.color, size) + 1,
                          getSizeData(row, size).limit - getSizeData(row, size).current,
                        )
                      "
                    />
                  </div>
                </div>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div
      class="sticky bottom-0 z-10 -mx-4 mt-4 -mb-4 flex flex-col gap-2 border-t bg-surface-0 p-4 shadow-[0_-4px_6px_-1px_rgb(0,0,0,0.1)]"
    >
      <div class="flex items-center justify-between px-1 text-sm font-medium">
        <span>Tổng cộng báo cáo:</span>
        <span class="text-xl font-bold text-primary">{{ totalReportedCount }}</span>
      </div>
      <UButton
        label="Xác nhận báo cáo"
        class="w-full"
        :disabled="props.disabled || totalReportedCount === 0"
        @click="emit('submit')"
      />
    </div>
  </div>
</template>
