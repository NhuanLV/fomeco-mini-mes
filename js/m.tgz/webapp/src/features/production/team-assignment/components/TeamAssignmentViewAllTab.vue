<script setup lang="ts">
import type { MetadataVm, ProductionOrderVm, TeamAssignmentDetailVm, TeamAssignmentVm } from '@/api'
import AssignmentAllocationMatrix from '@/features/production/team-assignment/components/report/AssignmentAllocationMatrix.vue'
import { transformToMatrix } from '@/shared/composables/useColorSizeMatrix'
import type { MatrixInputItem, MatrixRow } from '@/shared/types'
import { makeOrderComparator, sortValuesByOrder } from '@/shared/utils/orderedValues'
import { computed, ref, watchEffect, type Ref } from 'vue'

const props = defineProps<{
  productionOrder?: ProductionOrderVm
  currentAssignment?: TeamAssignmentDetailVm
  currentAssignmentId: string
}>()

// ── 1. Operations (Pills / Tabs trên cùng) ──────────────────────────────
const operationList = computed(() => {
  const ops = new Set<string>()
  props.productionOrder?.teamAssignments.forEach((ta) => {
    if (ta.operation) ops.add(ta.operation)
  })
  return Array.from(ops)
})

const operationOptions = computed(() => [
  { label: 'Tất cả', value: 'ALL' },
  ...operationList.value.map((op) => ({ label: op, value: op })),
])

const selectedOperation = ref<string>('ALL')

// ── 2. Filters ─────────────────────────────────────────────────────────
const selectedCompanies = ref<string[]>([])
const selectedFactories = ref<string[]>([])
const selectedTeams = ref<string[]>([])
const selectedPoCodes = ref<string[]>([])
const selectedColors = ref<string[]>([])
const selectedSizes = ref<string[]>([])

const companyOptions = computed(() => {
  const companies = new Set<string>()
  props.productionOrder?.teamAssignments.forEach((ta) => {
    if (ta.companyName) companies.add(ta.companyName)
  })
  return Array.from(companies).sort()
})

const factoryOptions = computed(() => {
  const factories = new Set<string>()
  props.productionOrder?.teamAssignments.forEach((ta) => {
    if (selectedCompanies.value.length > 0 && !selectedCompanies.value.includes(ta.companyName)) {
      return
    }
    if (ta.factoryName) factories.add(ta.factoryName)
  })
  return Array.from(factories).sort()
})

const teamOptions = computed(() => {
  const teamsMap = new Map<string, { id: string; name: string; label: string }>()
  props.productionOrder?.teamAssignments.forEach((ta) => {
    if (selectedCompanies.value.length > 0 && !selectedCompanies.value.includes(ta.companyName)) {
      return
    }
    if (selectedFactories.value.length > 0 && !selectedFactories.value.includes(ta.factoryName)) {
      return
    }
    if (!teamsMap.has(ta.teamId)) {
      teamsMap.set(ta.teamId, {
        id: ta.teamId,
        name: ta.teamName,
        label: `${ta.teamName} (${ta.factoryName})`,
      })
    }
  })
  return Array.from(teamsMap.values()).sort((a, b) => a.name.localeCompare(b.name))
})

const poCodeMap = computed(() => {
  const map: Record<string, string> = { ...props.currentAssignment?.purchaseOrderCodes }
  if (props.productionOrder?.poSummaries) {
    for (const s of props.productionOrder.poSummaries) {
      if (!map[s.poId]) map[s.poId] = s.poCode
    }
  }
  return map
})

const poDestMap = computed(() => {
  const map: Record<string, string> = { ...props.currentAssignment?.purchaseOrderDestinations }
  if (props.productionOrder?.poSummaries) {
    for (const s of props.productionOrder.poSummaries) {
      if (!map[s.poId]) map[s.poId] = s.destination ?? ''
    }
  }
  return map
})

const poCodeOptions = computed(() => {
  const codes = new Set<string>()
  if (props.productionOrder?.poSummaries) {
    props.productionOrder.poSummaries.forEach((s) => {
      if (s.poCode) codes.add(s.poCode)
    })
  }
  if (props.currentAssignment?.purchaseOrderCodes) {
    Object.values(props.currentAssignment.purchaseOrderCodes).forEach((code) => {
      if (code) codes.add(code)
    })
  }
  return Array.from(codes).sort()
})

const colorOptions = computed(() => {
  const colors = new Set<string>()
  props.productionOrder?.teamAssignments.forEach((ta) => {
    ta.allocations.forEach((a) => {
      if (a.color) colors.add(a.color)
    })
  })
  const colorOrder = props.currentAssignment?.styleColorOrder ?? []
  return sortValuesByOrder(Array.from(colors), colorOrder)
})

const allAvailableSizes = computed(() => {
  const sizes = new Set<string>()
  props.currentAssignment?.styleSizeOrder.forEach((s) => sizes.add(s))
  props.productionOrder?.teamAssignments.forEach((ta) => {
    ta.allocations.forEach((a) => {
      if (a.size) sizes.add(a.size)
    })
  })
  const sizeOrder = props.currentAssignment?.styleSizeOrder ?? []
  return sortValuesByOrder(Array.from(sizes), sizeOrder)
})

const sizeOptions = computed(() => allAvailableSizes.value)

function selectSingleOption<T>(selection: Ref<T[]>, options: T[]) {
  if (options.length === 1 && (selection.value.length !== 1 || selection.value[0] !== options[0])) {
    selection.value = [options[0]!]
  }
}

watchEffect(() => {
  selectSingleOption(selectedCompanies, companyOptions.value)
  selectSingleOption(selectedFactories, factoryOptions.value)
  selectSingleOption(
    selectedTeams,
    teamOptions.value.map((team) => team.id),
  )
  selectSingleOption(selectedPoCodes, poCodeOptions.value)
  selectSingleOption(selectedColors, colorOptions.value)
  selectSingleOption(selectedSizes, sizeOptions.value)
})

const displaySizes = computed(() => {
  if (selectedSizes.value.length === 0) return allAvailableSizes.value
  return allAvailableSizes.value.filter((s) => selectedSizes.value.includes(s))
})

const hasActiveFilters = computed(() => {
  return (
    (companyOptions.value.length > 1 && selectedCompanies.value.length > 0) ||
    (factoryOptions.value.length > 1 && selectedFactories.value.length > 0) ||
    (teamOptions.value.length > 1 && selectedTeams.value.length > 0) ||
    (poCodeOptions.value.length > 1 && selectedPoCodes.value.length > 0) ||
    (colorOptions.value.length > 1 && selectedColors.value.length > 0) ||
    (sizeOptions.value.length > 1 && selectedSizes.value.length > 0)
  )
})

function clearFilters() {
  selectedCompanies.value = []
  selectedFactories.value = []
  selectedTeams.value = []
  selectedPoCodes.value = []
  selectedColors.value = []
  selectedSizes.value = []
}

// ── 3. Lọc Team Assignments ───────────────────────────────────────────
const filteredAssignments = computed(() => {
  let list = props.productionOrder?.teamAssignments ?? []

  if (selectedOperation.value !== 'ALL') {
    list = list.filter((ta) => ta.operation === selectedOperation.value)
  }

  if (selectedCompanies.value.length > 0) {
    list = list.filter((ta) => selectedCompanies.value.includes(ta.companyName))
  }

  if (selectedFactories.value.length > 0) {
    list = list.filter((ta) => selectedFactories.value.includes(ta.factoryName))
  }

  if (selectedTeams.value.length > 0) {
    list = list.filter((ta) => selectedTeams.value.includes(ta.teamId))
  }

  return list
})

// ── 4. Xây dựng ma trận cho từng Team Assignment ────────────────────────
const cmpByPoThenColor = computed(() => {
  const cmpColor = makeOrderComparator(props.currentAssignment?.styleColorOrder ?? [])
  return (left: { poCode?: string; color: string }, right: { poCode?: string; color: string }) => {
    const byPoCode = (left.poCode || '').localeCompare(right.poCode || '')
    if (byPoCode !== 0) return byPoCode
    return cmpColor(left.color, right.color)
  }
})

interface AssignmentMatrixEntry {
  assignment: TeamAssignmentVm
  rows: MatrixRow[]
}

const assignmentMatrices = computed<AssignmentMatrixEntry[]>(() => {
  const result: AssignmentMatrixEntry[] = []

  for (const ta of filteredAssignments.value) {
    const metaByKey = new Map<string, MetadataVm>()
    for (const a of ta.allocations) {
      const key = `${a.purchaseOrderId}|${a.color}`
      if (!metaByKey.has(key)) {
        metaByKey.set(key, {
          purchaseOrderId: a.purchaseOrderId,
          color: a.color,
          checkDate: a.checkDate,
          deliveryDate: a.deliveryDate,
          notes: a.notes ?? [],
        })
      }
    }

    const items: MatrixInputItem[] = [
      ...ta.allocations.map((a) => ({ ...a, kind: 'alloc' as const })),
      ...ta.outputReportTotals.map((t) => ({ ...t, kind: 'progress' as const })),
    ]

    const rawRows = transformToMatrix(items, displaySizes.value, {
      getColor: (i) => i.color,
      getSize: (i) => i.size,
      getQuantity: (i) => {
        if (i.kind === 'alloc') return { current: 0, limit: i.quantity || 0 }
        if (i.kind === 'progress') return { current: i.completedQty || 0, limit: 0 }
        return { current: 0, limit: 0 }
      },
      groupBy: (i) => `${i.purchaseOrderId}|${i.color}`,
      getExtra: (i) => {
        const key = `${i.purchaseOrderId}|${i.color}`
        return {
          purchaseOrderId: i.purchaseOrderId,
          poCode: poCodeMap.value[i.purchaseOrderId!] || i.purchaseOrderId,
          destination: poDestMap.value[i.purchaseOrderId!] || '',
          metadata: metaByKey.get(key) || null,
        }
      },
    }).sort(cmpByPoThenColor.value)

    const filteredRows = rawRows.filter((row) => {
      if (selectedPoCodes.value.length > 0 && !selectedPoCodes.value.includes(row.poCode!)) {
        return false
      }
      return !(selectedColors.value.length > 0 && !selectedColors.value.includes(row.color))
    })

    if (filteredRows.length > 0) {
      result.push({
        assignment: ta,
        rows: filteredRows,
      })
    }
  }

  return result
})

function getOutputTotal(assignment: TeamAssignmentVm): number {
  return (
    assignment.outputReportTotals?.reduce((sum, item) => sum + (item.completedQty || 0), 0) ??
    assignment.totalReported ??
    0
  )
}

function getAllocatedTotal(assignment: TeamAssignmentVm): number {
  return assignment.allocations?.reduce((sum, item) => sum + (item.quantity || 0), 0) ?? 0
}
</script>

<template>
  <div class="flex flex-col gap-6">
    <!-- Top Filter Section -->
    <UCard :ui="{ body: 'p-4 flex flex-col gap-4' }">
      <!-- Operation Selector (Pills) -->
      <div class="flex flex-wrap items-center gap-2">
        <span class="text-sm font-semibold text-default">Công đoạn:</span>
        <div class="flex flex-wrap items-center gap-1.5">
          <UButton
            v-for="op in operationOptions"
            :key="op.value"
            :label="op.label"
            :variant="selectedOperation === op.value ? 'solid' : 'outline'"
            :color="selectedOperation === op.value ? 'primary' : 'neutral'"
            size="sm"
            @click="selectedOperation = op.value"
          />
        </div>
      </div>

      <!-- Filters: Công ty, Xí nghiệp, Tổ, Mã PO, Màu, Size -->
      <div class="flex flex-wrap items-end gap-4">
        <UFormField label="Công ty">
          <USelectMenu
            v-model="selectedCompanies"
            multiple
            :items="companyOptions"
            :disabled="companyOptions.length === 1"
            :variant="companyOptions.length === 1 ? 'subtle' : 'outline'"
            search-input
            placeholder="Tất cả"
            class="w-48"
          />
        </UFormField>

        <UFormField label="Xí nghiệp">
          <USelectMenu
            v-model="selectedFactories"
            multiple
            :items="factoryOptions"
            :disabled="factoryOptions.length === 1"
            :variant="factoryOptions.length === 1 ? 'subtle' : 'outline'"
            search-input
            placeholder="Tất cả"
            class="w-48"
          />
        </UFormField>

        <UFormField label="Tổ thực hiện">
          <USelectMenu
            v-model="selectedTeams"
            multiple
            :items="teamOptions"
            :disabled="teamOptions.length === 1"
            :variant="teamOptions.length === 1 ? 'subtle' : 'outline'"
            label-key="label"
            value-key="id"
            search-input
            placeholder="Tất cả"
            class="w-56"
          />
        </UFormField>

        <UFormField label="Mã PO">
          <USelectMenu
            v-model="selectedPoCodes"
            multiple
            :items="poCodeOptions"
            :disabled="poCodeOptions.length === 1"
            :variant="poCodeOptions.length === 1 ? 'subtle' : 'outline'"
            search-input
            placeholder="Tất cả"
            class="w-44"
          />
        </UFormField>

        <UFormField label="Màu">
          <USelectMenu
            v-model="selectedColors"
            multiple
            :items="colorOptions"
            :disabled="colorOptions.length === 1"
            :variant="colorOptions.length === 1 ? 'subtle' : 'outline'"
            search-input
            placeholder="Tất cả"
            class="w-44"
          />
        </UFormField>

        <UFormField label="Size">
          <USelectMenu
            v-model="selectedSizes"
            multiple
            :items="sizeOptions"
            :disabled="sizeOptions.length === 1"
            :variant="sizeOptions.length === 1 ? 'subtle' : 'outline'"
            search-input
            placeholder="Tất cả"
            class="w-44"
          />
        </UFormField>

        <UButton
          v-if="hasActiveFilters"
          icon="i-lucide-filter-x"
          color="neutral"
          variant="outline"
          aria-label="Xóa bộ lọc"
          class="mb-0.5"
          @click="clearFilters"
        />
      </div>
    </UCard>

    <!-- Matrix Cards for each matching assignment -->
    <div v-if="assignmentMatrices.length > 0" class="flex flex-col gap-6">
      <UCard
        v-for="{ assignment: ta, rows } in assignmentMatrices"
        :key="ta.id"
        :ui="{ body: 'p-2 sm:p-3' }"
      >
        <template #title>
          <div class="flex flex-wrap items-center justify-between gap-2">
            <div class="flex items-center gap-2">
              <UIcon name="i-lucide-users" class="size-5 text-primary" />
              <span class="font-semibold text-default">
                {{ ta.teamName }} — {{ ta.factoryName }} — {{ ta.companyName }}
              </span>
              <UBadge variant="subtle" color="primary">{{ ta.operation }}</UBadge>
              <UBadge v-if="ta.id === currentAssignmentId" variant="subtle" color="info">
                LCĐ hiện tại
              </UBadge>
            </div>
            <div class="text-sm font-normal text-toned">
              Ra chuyền / Phân bổ:
              <span class="font-semibold text-default">
                {{ getOutputTotal(ta).toLocaleString('vi-VN') }} /
                {{ getAllocatedTotal(ta).toLocaleString('vi-VN') }}
              </span>
            </div>
          </div>
        </template>
        <template #default>
          <AssignmentAllocationMatrix :rows="rows" :all-sizes="displaySizes" />
        </template>
      </UCard>
    </div>

    <!-- Empty State -->
    <div v-else class="rounded-lg border border-dashed border-default p-12 text-center text-toned">
      <UIcon name="i-lucide-inbox" class="mx-auto mb-3 size-10 text-toned/60" />
      <p class="text-base font-medium">Không tìm thấy dữ liệu lệnh công đoạn phù hợp</p>
      <p class="mt-1 text-sm text-toned/80">
        Hãy thử thay đổi công đoạn hoặc điều chỉnh lại các bộ lọc phía trên.
      </p>
    </div>
  </div>
</template>
