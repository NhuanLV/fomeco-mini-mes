<script setup lang="ts">
import type { PurchaseOrderQuantityDeltaCommand, TeamAssignmentDetailVm } from '@/api'
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import {
  matrixGridCell,
  matrixGridEditor,
  type MatrixGridBeforeEdit,
} from '@/shared/components/grid/matrixGrid'
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import MatrixColorCell from '@/shared/components/grid/MatrixColorCell.vue'
import MatrixQtyEditor from '@/shared/components/grid/MatrixQtyEditor.vue'
import { usePurchaseOrderAdjustmentDraft } from '@/features/production/team-assignment/composables/usePurchaseOrderAdjustmentDraft'
import type { GridColumn } from '@/shared/composables/useGridLayout'
import { computed, ref } from 'vue'

const props = defineProps<{
  assignment: TeamAssignmentDetailVm
  submitting: boolean
}>()

const emit = defineEmits<{
  submit: [payload: { reason: string; deltas: PurchaseOrderQuantityDeltaCommand[] }]
}>()

const QTY_CELL = matrixGridCell(MatrixQtyCell)
const COLOR_CELL = matrixGridCell(MatrixColorCell)
const QTY_EDITOR = matrixGridEditor(MatrixQtyEditor)

const {
  reason,
  allSizes,
  poAdjustmentRows,
  summaryRows,
  totalMismatches,
  unresolvedRows,
  canSubmit,
  handleAfterEdit,
  createPayload,
} = usePurchaseOrderAdjustmentDraft(() => props.assignment)

const activePoType = ref<'REGULAR' | 'POSITIVE'>('REGULAR')
const visiblePoRows = computed(() =>
  poAdjustmentRows.value.filter(
    (row) =>
      !row.isTotalBySize &&
      (props.assignment.purchaseOrderTypes?.[String(row.rowKey).split('|')[0]!] ?? 'REGULAR') ===
        activePoType.value,
  ),
)
function editVisibleRows(edits: Parameters<typeof handleAfterEdit>[0]) {
  handleAfterEdit(
    edits.map((edit) => ({
      ...edit,
      rowIndex: poAdjustmentRows.value.indexOf(visiblePoRows.value[edit.rowIndex]!),
    })),
  )
}

const poColumns = computed((): GridColumn[] => [
  { prop: 'poCode', name: 'Mã PO', pin: 'colPinStart', readonly: true },
  { prop: 'destination', name: 'Thị trường', pin: 'colPinStart', readonly: true },
  {
    prop: 'color',
    name: 'Màu',
    pin: 'colPinStart',
    readonly: true,
    cellTemplate: COLOR_CELL,
  },
  ...allSizes.value.map((size): GridColumn => ({
    prop: size,
    name: size,
    readonly: (params) => Boolean(params?.model?.isTotalBySize),
    cellTemplate: QTY_CELL,
    editor: QTY_EDITOR,
  })),
  {
    prop: 'totalByColor',
    name: 'Tổng',
    pin: 'colPinEnd',
    readonly: true,
    cellTemplate: QTY_CELL,
  },
])

const summaryColumns = computed((): GridColumn[] => [
  {
    prop: 'color',
    name: 'Màu',
    pin: 'colPinStart',
    readonly: true,
    cellTemplate: COLOR_CELL,
  },
  ...allSizes.value.map((size): GridColumn => ({
    prop: size,
    name: size,
    readonly: true,
    cellTemplate: QTY_CELL,
  })),
  {
    prop: 'totalByColor',
    name: 'Tổng',
    pin: 'colPinEnd',
    readonly: true,
    cellTemplate: QTY_CELL,
  },
])

function handleBeforeEdit(edit: MatrixGridBeforeEdit) {
  if (edit.row?.isTotalBySize || poAdjustmentRows.value[edit.rowIndex]?.isTotalBySize) {
    edit.preventDefault()
  }
}

function submit() {
  const payload = createPayload()
  if (payload) emit('submit', payload)
}
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="flex items-center gap-2">
          <UIcon name="i-lucide-refresh-cw" class="size-5 text-primary" />
          <span>Điều chỉnh PO quantity</span>
        </div>
        <UButton
          label="Xác nhận điều chỉnh"
          icon="i-lucide-check"
          :disabled="!canSubmit"
          :loading="props.submitting"
          @click="submit"
        />
      </div>
    </template>
    <template #default>
      <UTabs
        v-model="activePoType"
        :items="[
          { label: 'Hàng thường', value: 'REGULAR' },
          { label: 'Hàng dương', value: 'POSITIVE' },
        ]"
        :content="false"
      />
      <div class="flex flex-col gap-4">
        <div class="flex flex-col gap-2">
          <label for="po-adjustment-reason" class="text-sm font-medium">Lý do điều chỉnh</label>
          <UTextarea
            id="po-adjustment-reason"
            v-model="reason"
            :rows="3"
            autoresize
            placeholder="Nhập lý do nghiệp vụ"
          />
        </div>

        <div class="flex flex-col gap-2">
          <div class="text-sm font-semibold text-default">Chi tiết phân bổ theo PO</div>
          <BaseMatrixGrid
            :source="visiblePoRows"
            :columns="poColumns"
            @afteredit="editVisibleRows"
            @beforeedit="handleBeforeEdit"
          />
        </div>

        <div class="flex flex-col gap-2">
          <div class="text-sm font-semibold text-default">Tổng sản lượng theo màu/cỡ</div>
          <BaseMatrixGrid :source="summaryRows" :columns="summaryColumns" />
        </div>

        <div
          v-if="totalMismatches.length > 0 || unresolvedRows.length > 0"
          class="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700"
        >
          <div class="mb-2 font-semibold">Chưa thể xác nhận</div>
          <ul class="space-y-1">
            <li v-if="totalMismatches.length > 0">
              Tổng mới theo màu/cỡ phải bằng tổng tiến độ đã sản xuất.
            </li>
            <li v-if="unresolvedRows.length > 0">
              Số sau điều chỉnh của từng PO/màu/cỡ không được vượt phân bổ hiện tại.
            </li>
          </ul>
        </div>
      </div>
    </template>
  </UCard>
</template>
