<script lang="ts" setup>
import type {
  MetadataVm,
  PurchaseOrderQuantityDeltaCommand,
  TeamAssignmentReportHistoryVm,
} from '@/api'
import { client } from '@/api/client.gen'
import {
  adjustPurchaseOrderQuantityMutation,
  deleteLastReportMutation,
  updateLastReportMutation,
  getHistoryQuery,
  getHistoryQueryKey,
  getMyAssignmentsQueryKey,
  getProductionOrderDetailQuery,
  getReportQuery,
  getReportQueryKey,
  getTeamAssignmentDetailQuery,
  getTeamAssignmentDetailQueryKey,
  reportMutation,
} from '@/api/@pinia/colada.gen'
import AllocationDetailCard from '@/features/production/team-assignment/components/report/AllocationDetailCard.vue'
import PurchaseOrderAdjustmentCard from '@/features/production/team-assignment/components/report/PurchaseOrderAdjustmentCard.vue'
import ReportCard from '@/features/production/team-assignment/components/report/ReportCard.vue'
import ReportHistoryTable from '@/features/production/team-assignment/components/report/ReportHistoryTable.vue'
import { getInsufficientMaterialsNotification } from '@/features/production/team-assignment/helpers/insufficientMaterialsError'
import { needsAdjustment } from '@/features/production/helpers/reconciliation'
import { transformToMatrix } from '@/shared/composables/useColorSizeMatrix'
import { makeOrderComparator, sortValuesByOrder } from '@/shared/utils/orderedValues'
import { useAuthStore } from '@/shared/stores/auth'
import type { MatrixInputItem } from '@/shared/types'
import { showError, showSuccess, showToast, showWarn } from '@/shared/utils/toast'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import { useConfirm } from '@/shared/composables/useConfirm'
import { useIntervalFn } from '@vueuse/core'
import { computed, h, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const props = defineProps<{
  id: string
  type: 'INPUT' | 'OUTPUT'
}>()

const route = useRoute()
const { hasPermission } = useAuthStore()
const confirm = useConfirm()
const canLoadProductionOrderDetail = computed(
  () =>
    hasPermission('VIEW_PRODUCTION_ORDER') ||
    hasPermission('ISSUE_PRODUCTION_ORDER') ||
    hasPermission('UPDATE_COSTING') ||
    hasPermission('REPORT_PROGRESS'),
)

const { data: assignment, isLoading: loading } = useQuery(() =>
  getTeamAssignmentDetailQuery({ path: { id: props.id } }),
)

const { data: poDetail } = useQuery(() => ({
  ...getProductionOrderDetailQuery({
    path: { id: assignment.value?.productionOrderId ?? '' },
  }),
  enabled: !!assignment.value?.productionOrderId && canLoadProductionOrderDetail.value,
}))

const reportingLocked = computed(
  () =>
    assignment.value?.productionOrderStatus === 'CANCELLED' ||
    needsAdjustment(assignment.value) ||
    poDetail.value?.needsAllocationRevision === true,
)

const { data: report, isLoading: loadingReport } = useQuery(() =>
  getReportQuery({ path: { id: props.id } }),
)

const isHistoryExpanded = defineModel<boolean>('isHistoryExpanded', { default: false })
const historyWrapperRef = ref<HTMLElement | null>(null)
const isHistoryHighlighted = ref(false)

watch(
  () => route?.query?.highlightReportDate,
  (date) => {
    if (date) {
      isHistoryExpanded.value = true
      isHistoryHighlighted.value = true
      setTimeout(() => {
        historyWrapperRef.value?.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }, 300)
      setTimeout(() => {
        isHistoryHighlighted.value = false
      }, 4000)
    }
  },
  { immediate: true },
)

const {
  data: history,
  isLoading: loadingHistory,
  refetch: refetchHistory,
} = useQuery(() => ({
  ...getHistoryQuery({ path: { id: props.id } }),
  enabled: !!props.id,
}))

const hasPendingGrn = computed(
  () => history.value?.some((item) => item.grnStatus === 'PENDING') ?? false,
)

const failedGrn = computed(() =>
  props.type === 'OUTPUT' ? history.value?.find((item) => item.grnStatus === 'FAILED') : undefined,
)
const hasBlockingGrn = computed(
  () =>
    props.type === 'OUTPUT' &&
    (history.value?.some((item) => item.grnStatus === 'PENDING' || item.grnStatus === 'FAILED') ??
      false),
)
const dismissedGrnAt = ref<string | null>(null)
const showFailedGrn = computed(
  () =>
    !!failedGrn.value &&
    dismissedGrnAt.value !== (failedGrn.value.targetReportedAt ?? failedGrn.value.occurredAt),
)

const { pause: pauseGrnPolling, resume: resumeGrnPolling } = useIntervalFn(
  () => {
    void refetchHistory()
  },
  3000,
  { immediate: false },
)

watch(
  failedGrn,
  (failed) => {
    if (failed) {
      isHistoryExpanded.value = true
    }
  },
  { immediate: true },
)

watch(
  hasPendingGrn,
  (pending, oldPending) => {
    if (pending) {
      resumeGrnPolling()
    } else {
      pauseGrnPolling()
      if (oldPending) {
        void queryCache.invalidateQueries({
          key: getTeamAssignmentDetailQueryKey({ path: { id: props.id } }),
        })
        void queryCache.invalidateQueries({
          key: getReportQueryKey({ path: { id: props.id } }),
        })
      }
    }
  },
  { immediate: true },
)

const bulkReportData = ref<
  {
    purchaseOrderId: string
    color: string
    size: string
    incrementQty: number
  }[]
>([])
const originalBulkReportData = ref<typeof bulkReportData.value>([])

const allSizes = computed(() => {
  if (!assignment.value) return []
  return sortValuesByOrder(
    assignment.value.allocations.map((a) => a.size),
    assignment.value.styleSizeOrder,
  )
})

const cmpByPoThenColor = computed(() => {
  const cmpColor = makeOrderComparator(assignment.value?.styleColorOrder ?? [])
  return (left: { poCode?: string; color: string }, right: { poCode?: string; color: string }) => {
    const byPoCode = (left.poCode || '').localeCompare(right.poCode || '')
    if (byPoCode !== 0) return byPoCode
    return cmpColor(left.color, right.color)
  }
})

// ...
const matrixData = computed(() => {
  if (!assignment.value) return []

  const totals =
    props.type === 'INPUT'
      ? assignment.value.inputReportTotals
      : assignment.value.outputReportTotals
  const items: MatrixInputItem[] = [
    ...assignment.value.allocations.map((a) => ({ ...a, kind: 'alloc' as const })),
    ...totals.map((t) => ({ ...t, kind: 'progress' as const })),
  ]

  if (isEditing.value) {
    const latest = report.value?.history?.[0]
    if (latest) {
      items.push(...latest.quantities.map((q) => ({ ...q, kind: 'edit' as const })))
    }
  }

  const purchaseOrderCodes = assignment.value.purchaseOrderCodes
  return transformToMatrix(items, allSizes.value, {
    getColor: (i) => i.color,
    getSize: (i) => i.size,
    getQuantity: (i) => {
      if (i.kind === 'alloc') return { current: 0, limit: i.quantity || 0 }
      if (i.kind === 'progress') return { current: i.completedQty || 0, limit: 0 }
      if (i.kind === 'edit') return { current: -(i.quantity || 0), limit: 0 }
      return { current: 0, limit: 0 }
    },
    groupBy: (i) => `${i.purchaseOrderId}|${i.color}`,
    getExtra: (i) => ({
      purchaseOrderId: i.purchaseOrderId,
      poCode: purchaseOrderCodes[i.purchaseOrderId!] || i.purchaseOrderId,
    }),
  }).sort(cmpByPoThenColor.value)
})

// Flat rows for AssignmentAllocationMatrix: one row per (PO, color)
const allocationRows = computed(() => {
  if (!assignment.value) return []

  const metaByKey = new Map<string, MetadataVm>()
  for (const m of assignment.value.metadataRows) {
    metaByKey.set(`${m.purchaseOrderId}|${m.color}`, m)
  }

  const totals =
    props.type === 'INPUT'
      ? assignment.value.inputReportTotals
      : assignment.value.outputReportTotals
  const items: MatrixInputItem[] = [
    ...assignment.value.allocations.map((a) => ({ ...a, kind: 'alloc' as const })),
    ...totals.map((t) => ({ ...t, kind: 'progress' as const })),
  ]

  const { purchaseOrderCodes, purchaseOrderDestinations } = assignment.value

  return transformToMatrix(items, allSizes.value, {
    getColor: (i) => i.color,
    getSize: (i) => i.size,
    getQuantity: (i) => {
      if (i.kind === 'alloc') return { current: 0, limit: i.quantity || 0 }
      if (i.kind === 'progress') return { current: i.completedQty || 0, limit: 0 }
      return { current: 0, limit: 0 }
    },
    groupBy: (i) => `${i.purchaseOrderId}|${i.color}`,
    getExtra: (i) => {
      const key = `${i.purchaseOrderId}|${i.color}`
      return {
        purchaseOrderId: i.purchaseOrderId,
        poCode: purchaseOrderCodes[i.purchaseOrderId!] || i.purchaseOrderId,
        destination: purchaseOrderDestinations?.[i.purchaseOrderId!] || '',
        metadata: metaByKey.get(key) || null,
      }
    },
  }).sort(cmpByPoThenColor.value)
})

const queryCache = useQueryCache()
const { mutateAsync: reportMutate, isLoading: reporting } = useMutation(reportMutation())
const { mutateAsync: deleteMutate, isLoading: deleting } = useMutation(deleteLastReportMutation())
const { mutateAsync: updateMutate, isLoading: updating } = useMutation(updateLastReportMutation())
const { mutateAsync: adjustPoQuantityMutate, isLoading: adjustingPoQuantity } = useMutation(
  adjustPurchaseOrderQuantityMutation(),
)
const router = useRouter()
const reportCardRef = ref<HTMLElement | null>(null)

// ── Edit mode ──────────────────────────────────────────────────────────
const isEditing = ref(false)
const editingFailedGrn = ref<TeamAssignmentReportHistoryVm | null>(null)

function startEdit(row?: TeamAssignmentReportHistoryVm) {
  if (row?.reportType && row.reportType !== props.type) {
    const targetTab = row.reportType === 'INPUT' ? 'input-report' : 'output-report'
    void router.replace({
      query: { ...route.query, tab: targetTab, edit: 'true' },
    })
    return
  }

  reportCardRef.value?.scrollIntoView({
    behavior: 'smooth',
    block: 'center',
  })

  isEditing.value = true

  const source = row?.grnStatus === 'FAILED' ? row : report.value?.history?.[0]
  if (!source) return
  editingFailedGrn.value = row?.grnStatus === 'FAILED' ? row : null

  const allocations = assignment.value?.allocations ?? []
  bulkReportData.value = source.quantities.map((q) => {
    const alloc = allocations.find(
      (a) => a.purchaseOrderId === q.purchaseOrderId && a.color === q.color && a.size === q.size,
    )
    return {
      purchaseOrderId: q.purchaseOrderId,
      color: alloc?.color ?? q.color,
      size: q.size,
      incrementQty: q.quantity,
    }
  })
  originalBulkReportData.value = bulkReportData.value.map((item) => ({ ...item }))
}

function cancelEdit() {
  isEditing.value = false
  editingFailedGrn.value = null
  bulkReportData.value = []
  originalBulkReportData.value = []
  if (route.query.edit) {
    void router.replace({
      query: { ...route.query, edit: undefined },
    })
  }
}

watch(
  [() => route.query.edit, () => report.value, () => assignment.value],
  ([editQuery, reportVal, assignmentVal]) => {
    if (editQuery === 'true' && reportVal && assignmentVal && !isEditing.value) {
      startEdit()
      void router.replace({
        query: { ...route.query, edit: undefined },
      })
    }
  },
  { immediate: true },
)

function getReportKey(item: { purchaseOrderId: string; color: string; size: string }) {
  return `${item.purchaseOrderId}|${item.color}|${item.size}`
}

function isSameReportData(left: typeof bulkReportData.value, right: typeof bulkReportData.value) {
  if (left.length !== right.length) return false

  const leftMap = new Map(left.map((item) => [getReportKey(item), item.incrementQty]))
  const rightMap = new Map(right.map((item) => [getReportKey(item), item.incrementQty]))

  if (leftMap.size !== rightMap.size) return false

  for (const [key, qty] of leftMap) {
    if (rightMap.get(key) !== qty) return false
  }

  return true
}

function scheduleReportRefresh() {
  setTimeout(() => {
    void queryCache.invalidateQueries({
      key: getTeamAssignmentDetailQueryKey({ path: { id: props.id } }),
    })
    void queryCache.invalidateQueries({
      key: [{ _id: 'getKanban' }],
    })
    void queryCache.invalidateQueries({
      key: getReportQueryKey({ path: { id: props.id } }),
    })
    void queryCache.invalidateQueries({
      key: getHistoryQueryKey({ path: { id: props.id } }),
    })
    void queryCache.invalidateQueries({ key: getMyAssignmentsQueryKey() })
  }, 1000)
}

async function submitPoQuantityAdjustment(payload: {
  reason: string
  deltas: PurchaseOrderQuantityDeltaCommand[]
}) {
  try {
    await adjustPoQuantityMutate({
      path: { id: props.id },
      body: payload,
    })
    showSuccess('Điều chỉnh PO quantity thành công')
    scheduleReportRefresh()
  } catch (error: unknown) {
    const message = (error as { message?: string })?.message || 'Có lỗi xảy ra khi điều chỉnh'
    showError(message)
  }
}

const submitReport = async () => {
  if (!bulkReportData.value.length) return
  if (reportingLocked.value) {
    showError('Phòng kế hoạch đang điều chỉnh phân bổ PO, chưa thể báo cáo thêm')
    return
  }
  if (hasBlockingGrn.value && !editingFailedGrn.value) return

  const items = bulkReportData.value.map((item) => ({
    purchaseOrderId: item.purchaseOrderId,
    color: item.color,
    size: item.size,
    incrementQty: item.incrementQty,
  }))

  try {
    if (isEditing.value) {
      if (isSameReportData(originalBulkReportData.value, bulkReportData.value)) {
        showWarn('Bạn chưa thay đổi dữ liệu báo cáo')
        return
      }

      if (editingFailedGrn.value) {
        await reportMutate({
          path: { id: props.id },
          body: {
            type: props.type,
            items,
            targetReportedAt:
              editingFailedGrn.value.targetReportedAt ?? editingFailedGrn.value.occurredAt,
          },
        })
        showSuccess('Đang tạo lại phiếu nhập kho trên WFX')
      } else {
        await updateMutate({
          path: { id: props.id },
          body: { type: props.type, items },
        })
        showSuccess('Cập nhật báo cáo thành công')
      }
    } else {
      await reportMutate({
        path: { id: props.id },
        body: { type: props.type, items },
      })
      const successMsg =
        props.type === 'INPUT'
          ? 'Báo tiến độ vào chuyền thành công'
          : 'Đang tạo phiếu nhập kho trên WFX'
      showSuccess(successMsg)
    }
    scheduleReportRefresh()
    if (isEditing.value) {
      cancelEdit()
    } else {
      bulkReportData.value = []
    }
  } catch (error: unknown) {
    const materialsNotification = getInsufficientMaterialsNotification(error)
    if (materialsNotification) {
      showToast({
        color: 'error',
        summary: materialsNotification.title,
        detail: h(
          'div',
          { class: 'space-y-1' },
          materialsNotification.lines.map((line) => h('div', line)),
        ),
        life: 5000,
      })
      return
    }
    const message = (error as { message?: string })?.message || 'Có lỗi xảy ra khi báo cáo'
    showError(message)
  }
}

async function performDelete(expectedReportedAt: string) {
  try {
    await deleteMutate({
      path: { id: props.id },
      query: { reportedAt: expectedReportedAt },
    })
    showSuccess('Đã xoá báo cáo thành công')
    scheduleReportRefresh()
    if (isEditing.value) cancelEdit()
  } catch (error: unknown) {
    const message = (error as { message?: string })?.message || 'Có lỗi xảy ra khi xoá'
    showError(message)
  }
}

async function createGrn(reportedAt: string) {
  try {
    await client.post({
      url: '/api/team-assignments/{id}/reports/{reportedAt}/create-grn',
      path: { id: props.id, reportedAt },
      throwOnError: true,
    })
    showSuccess('Đang tạo phiếu nhập kho trên WFX')
    scheduleReportRefresh()
  } catch (error: unknown) {
    const message = (error as { message?: string })?.message || 'Không thể tạo phiếu nhập kho'
    if (message.includes('đã tạo phiếu nhập kho thành công')) {
      showSuccess(message)
    } else {
      showError(message)
    }
  }
}

async function cancelGrn(reportedAt: string) {
  try {
    await client.delete({
      url: '/api/team-assignments/{id}/reports/{reportedAt}/create-grn',
      path: { id: props.id, reportedAt },
      throwOnError: true,
    })
    showSuccess('Đã hủy lần báo ra chuyền lỗi')
    bulkReportData.value = []
    if (isEditing.value) cancelEdit()
    scheduleReportRefresh()
  } catch (error: unknown) {
    showError((error as { message?: string })?.message || 'Không thể hủy báo cáo')
  }
}

function confirmCancelGrn(reportedAt?: string) {
  const target = reportedAt ?? failedGrn.value?.targetReportedAt ?? failedGrn.value?.occurredAt
  if (!target) return
  confirm.require({
    message: 'Bạn có chắc chắn muốn hủy lần báo ra chuyền bị lỗi?',
    header: 'Xác nhận hủy',
    rejectLabel: 'Không',
    acceptLabel: 'Hủy báo cáo',
    acceptProps: { color: 'error' },
    accept: () => void cancelGrn(target),
  })
}

function confirmDelete(expectedReportedAt: string) {
  if (deleting.value) return

  confirm.require({
    message: 'Bạn có chắc chắn muốn xoá lần báo cáo gần nhất?',
    header: 'Xác nhận xoá',
    rejectLabel: 'Huỷ',
    acceptLabel: 'Xoá',
    acceptProps: { color: 'error' },
    accept: () => {
      void performDelete(expectedReportedAt)
    },
  })
}
</script>

<template>
  <div v-if="loading && !assignment" class="flex justify-center p-12">
    <UIcon name="i-lucide-loader-circle" class="animate-spin text-4xl text-primary" />
  </div>

  <div v-else-if="assignment" class="flex flex-col gap-6">
    <UAlert
      v-if="showFailedGrn && failedGrn"
      role="alert"
      color="error"
      icon="i-lucide-triangle-alert"
      close
      :title="'Chưa báo ra chuyền thành công'"
      :description="`${failedGrn.grnMessage || 'Không xác định'}. Vui lòng kiểm tra lịch sử bên dưới để thử lại.`"
      @update:open="
        (open: boolean) =>
          !open && (dismissedGrnAt = failedGrn!.targetReportedAt ?? failedGrn!.occurredAt)
      "
    />

    <!-- Per-PO allocation detail with metadata -->
    <AllocationDetailCard
      v-if="
        assignment.productionOrderStatus === 'CANCELLED' ||
        !reportingLocked ||
        !hasPermission('ISSUE_PRODUCTION_ORDER')
      "
      :all-sizes="allSizes"
      :rows="allocationRows"
    />

    <div
      v-if="reportingLocked && assignment.productionOrderStatus !== 'CANCELLED'"
      class="rounded-lg border border-red-200 bg-red-50 p-4 text-sm font-medium text-red-700"
    >
      <UIcon name="i-lucide-triangle-alert" class="mr-2" />
      BO đang cần điều chỉnh phân bổ. Báo cáo sản lượng sẽ mở lại khi tổng phân bổ của mọi LSX không
      còn vượt quantity BO và phân công trở về trạng thái đối soát bình thường.
    </div>

    <PurchaseOrderAdjustmentCard
      v-if="
        assignment.productionOrderStatus !== 'CANCELLED' &&
        needsAdjustment(assignment) &&
        hasPermission('ISSUE_PRODUCTION_ORDER')
      "
      :assignment="assignment"
      :submitting="adjustingPoQuantity"
      @submit="submitPoQuantityAdjustment"
    />

    <div
      v-if="!reportingLocked"
      ref="reportCardRef"
      :class="{ 'rounded-xl ring-2 ring-primary/30': isEditing }"
    >
      <ReportCard
        v-if="hasPermission('REPORT_PROGRESS')"
        v-model="bulkReportData"
        :all-sizes="allSizes"
        :is-editing="isEditing"
        :matrix-data="
          editingFailedGrn
            ? matrixData.filter(
                (row) => assignment?.purchaseOrderTypes[row.purchaseOrderId ?? ''] !== 'POSITIVE',
              )
            : matrixData
        "
        :reporting="reporting"
        :updating="updating"
        :disabled="hasBlockingGrn && !editingFailedGrn"
        @submit="submitReport"
        @cancel-edit="cancelEdit"
      />
    </div>

    <div
      ref="historyWrapperRef"
      :class="{
        'rounded-xl ring-2 ring-rose-500 transition-all duration-300': isHistoryHighlighted,
      }"
    >
      <ReportHistoryTable
        :read-only="assignment.productionOrderStatus === 'CANCELLED'"
        v-model:is-expanded="isHistoryExpanded"
        :current-type="type"
        :deleting="deleting"
        :history="history"
        :loading="loadingReport || loadingHistory"
        :style-color-order="assignment.styleColorOrder"
        :style-size-order="assignment.styleSizeOrder"
        :purchase-order-codes="assignment.purchaseOrderCodes"
        @start-edit="startEdit"
        @confirm-delete="confirmDelete"
        @create-grn="createGrn"
        @cancel-grn="confirmCancelGrn"
      />
    </div>
  </div>
</template>
