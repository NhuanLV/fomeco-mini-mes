<script setup lang="ts">
import AssignmentBulkReportMatrix from '@/features/production/team-assignment/components/report/AssignmentBulkReportMatrix.vue'
import AssignmentMobileReport from '@/features/production/team-assignment/components/report/AssignmentMobileReport.vue'
import type { MatrixRow } from '@/shared/types'

type BulkReportItem = {
  purchaseOrderId: string
  color: string
  size: string
  incrementQty: number
}

const props = defineProps<{
  matrixData: MatrixRow[]
  allSizes: string[]
  isEditing: boolean
  reporting: boolean
  updating: boolean
  disabled?: boolean
}>()

const bulkReportData = defineModel<BulkReportItem[]>({ required: true })

const emit = defineEmits<{
  submit: []
  cancelEdit: []
}>()
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex justify-between">
        <h2 class="flex items-center gap-2 font-semibold">
          <UIcon name="i-lucide-clipboard-pen" class="size-5 text-primary" />
          <span>{{
            props.isEditing ? 'Cập nhật báo cáo sản lượng' : 'Báo cáo sản lượng mới'
          }}</span>
        </h2>
        <div class="hidden gap-2 md:flex">
          <UButton
            v-if="props.isEditing"
            label="Huỷ"
            variant="ghost"
            color="neutral"
            icon="i-lucide-x"
            @click="emit('cancelEdit')"
          />
          <UButton
            :label="props.isEditing ? 'Xác nhận' : 'Báo cáo'"
            variant="ghost"
            icon="i-lucide-check"
            :loading="props.reporting || props.updating"
            :disabled="props.disabled"
            @click="emit('submit')"
          />
        </div>
      </div>
    </template>
    <template #default>
      <div class="hidden md:block">
        <AssignmentBulkReportMatrix
          :rows="props.matrixData"
          :all-sizes="props.allSizes"
          :disabled="props.disabled"
          v-model="bulkReportData"
        />
      </div>
      <div class="md:hidden">
        <AssignmentMobileReport
          :rows="props.matrixData"
          :all-sizes="props.allSizes"
          :disabled="props.disabled"
          v-model="bulkReportData"
          @submit="emit('submit')"
        />
      </div>
    </template>
  </UCard>
</template>
