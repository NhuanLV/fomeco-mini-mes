import type { TeamAssignmentVm } from '@/api'
import { getMyAssignmentsQuery } from '@/api/@pinia/colada.gen'
import { useQuery } from '@pinia/colada'
import dayjs from 'dayjs'
import { computed, ref, watch } from 'vue'

export function useTeamAssignmentList() {
  const page = ref(0)
  const pageSize = ref(20)

  const styleFilter = ref<string[]>([])
  const orderNumberFilter = ref<string[]>([])
  const boWfxIdFilter = ref<string[]>([])
  const teamFilter = ref<string[]>([])
  const statusFilter = ref<string[]>([])

  const assignedAtRange = ref<Date[] | null>(null)
  const productDateRange = ref<Date[] | null>(null)
  const syncDateRange = ref<Date[] | null>(null)
  const lastProgressUpdateRange = ref<Date[] | null>(null)

  watch(
    [
      styleFilter,
      orderNumberFilter,
      boWfxIdFilter,
      teamFilter,
      statusFilter,
      assignedAtRange,
      productDateRange,
      syncDateRange,
      lastProgressUpdateRange,
    ],
    () => {
      page.value = 0
    },
    { deep: true },
  )

  function formatDate(range: Date[] | null, index: 0 | 1) {
    if (!range?.[0] || !range?.[1]) return undefined
    return dayjs(range[index]).format('YYYY-MM-DD')
  }

  const {
    data,
    isLoading: loading,
    refresh: fetchAssignments,
  } = useQuery(() =>
    getMyAssignmentsQuery({
      query: {
        page: page.value,
        size: pageSize.value,
        sort: [],
        styles: styleFilter.value.length > 0 ? styleFilter.value : undefined,
        orderNumbers: orderNumberFilter.value.length > 0 ? orderNumberFilter.value : undefined,
        boCodes: boWfxIdFilter.value.length > 0 ? boWfxIdFilter.value : undefined,
        teams: teamFilter.value.length > 0 ? teamFilter.value : undefined,
        statuses: statusFilter.value.length > 0 ? statusFilter.value : undefined,
        assignedAtFrom: formatDate(assignedAtRange.value, 0),
        assignedAtTo: formatDate(assignedAtRange.value, 1),
        productDateFrom: formatDate(productDateRange.value, 0),
        productDateTo: formatDate(productDateRange.value, 1),
        syncDateFrom: formatDate(syncDateRange.value, 0),
        syncDateTo: formatDate(syncDateRange.value, 1),
        lastReportUpdateFrom: formatDate(lastProgressUpdateRange.value, 0),
        lastReportUpdateTo: formatDate(lastProgressUpdateRange.value, 1),
      },
    }),
  )

  const assignments = computed<TeamAssignmentVm[]>(() => data.value?.content ?? [])
  const totalRecords = computed(() => data.value?.page?.totalElements ?? 0)

  function resetFilters() {
    styleFilter.value = []
    orderNumberFilter.value = []
    boWfxIdFilter.value = []
    teamFilter.value = []
    statusFilter.value = []
    assignedAtRange.value = null
    productDateRange.value = null
    syncDateRange.value = null
    lastProgressUpdateRange.value = null
    page.value = 0
  }

  return {
    page,
    pageSize,
    styleFilter,
    orderNumberFilter,
    boWfxIdFilter,
    teamFilter,
    statusFilter,
    assignedAtRange,
    productDateRange,
    syncDateRange,
    lastProgressUpdateRange,
    loading,
    assignments,
    totalRecords,
    fetchAssignments,
    resetFilters,
  }
}
