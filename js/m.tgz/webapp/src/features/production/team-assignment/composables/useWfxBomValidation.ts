import {
  type BillOfMaterial,
  getBomByBuyerOrderId,
  type TeamAssignmentDetailVm,
  type TeamBomVm,
} from '@/api'
import { getBomByBuyerOrderIdQuery, getProductionOrderDetailQuery } from '@/api/@pinia/colada.gen'
import {
  compareTeamMaterialWithWfx,
  type TeamMaterialComparison,
} from '@/features/production/team-material/teamMaterialCalculation'
import { useAuthStore } from '@/shared/stores/auth'
import { useConfirm } from '@/shared/composables/useConfirm'
import { useQuery } from '@pinia/colada'
import Big from 'big.js'
import { computed, ref, type Ref, watch } from 'vue'

export function useWfxBomValidation(
  id: Ref<string>,
  assignment: Ref<TeamAssignmentDetailVm | undefined>,
  bomData: Ref<TeamBomVm | undefined>,
  comparisons: Ref<TeamMaterialComparison[]>,
) {
  const { hasPermission } = useAuthStore()
  const confirm = useConfirm()
  const canEdit = computed(
    () =>
      !!assignment.value &&
      assignment.value.productionOrderStatus !== 'CANCELLED' &&
      hasPermission('UPDATE_COSTING', assignment.value.teamId),
  )
  const { data: productionOrder } = useQuery(() => ({
    ...getProductionOrderDetailQuery({ path: { id: assignment.value?.productionOrderId ?? '' } }),
    enabled: canEdit.value && !!assignment.value?.productionOrderId,
  }))
  const { data: wfxBom } = useQuery(() => ({
    ...getBomByBuyerOrderIdQuery({ path: { id: productionOrder.value?.buyerOrderId ?? '' } }),
    enabled: canEdit.value && !!productionOrder.value?.buyerOrderId,
  }))
  const latestWfxBom = ref<BillOfMaterial>()
  watch(id, () => {
    latestWfxBom.value = undefined
  })

  const displayedComparisons = computed(() => {
    const source = latestWfxBom.value ?? wfxBom.value
    return canEdit.value && assignment.value && bomData.value && source
      ? compareTeamMaterialWithWfx(assignment.value, bomData.value, source).comparisons
      : comparisons.value
  })

  // Phòng kỹ thuật bấm Lưu -> fetch BOM WFX một lần -> cập nhật cột WFX -> quét toàn bộ NPL + màu.
  // Nếu vượt, chờ xác nhận; trả true mới cho TeamBomTable gọi API lưu. Hủy trả false, giữ dữ liệu đang chỉnh.
  async function checkWfxBeforeSave(pending: TeamBomVm) {
    if (!assignment.value || !productionOrder.value) {
      throw new Error('Chưa tải được thông tin phân công để kiểm tra định mức WFX')
    }
    const response = await getBomByBuyerOrderId({
      path: { id: productionOrder.value.buyerOrderId },
      throwOnError: true,
    })
    if (!response.data) throw new Error('Không tìm thấy BOM WFX của đơn hàng')
    latestWfxBom.value = response.data
    const result = compareTeamMaterialWithWfx(assignment.value, pending, response.data)
    if (result.missingLines.length) {
      throw new Error('Không ghép được NPL với BOM WFX. Vui lòng kiểm tra lại BOM.')
    }
    const exceeded = result.comparisons.filter((row) =>
      new Big(assignment.value?.operation === 'CUT-1' ? row.byColorQty : row.bySizeQty).gt(
        row.byWfxSizeQty ?? 0,
      ),
    )
    if (!exceeded.length) return true
    return confirm.require({
      header: 'Xác nhận lưu định mức',
      message: `Định mức MES+ của (các) NPL sau đang lớn hơn định mức WFX:\n${exceeded.map((row) => `• ${row.articleCode ? `${row.articleCode} — ` : ''}${row.articleName} — Màu: ${row.materialColor || '-'}`).join('\n')}\nBạn có chắc chắn muốn lưu định mức này không?`,
      acceptLabel: 'Xác nhận',
      rejectLabel: 'Hủy',
    })
  }

  return { canEdit, displayedComparisons, checkWfxBeforeSave }
}
