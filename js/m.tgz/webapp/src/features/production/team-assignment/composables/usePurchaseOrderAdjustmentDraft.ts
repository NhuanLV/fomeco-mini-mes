import type { PurchaseOrderQuantityDeltaCommand, TeamAssignmentDetailVm } from '@/api'
import type { MatrixGridEdit } from '@/shared/components/grid/matrixGrid'
import { computed, ref, shallowRef, watch } from 'vue'
import {
  buildNonZeroDeltas,
  buildPoAdjustmentRows,
  buildRowComparator,
  buildRows,
  buildSummaryRows,
  buildTotalMismatches,
  collectAllSizes,
  setAfterQty,
  type AdjustmentRow,
} from './purchaseOrderAdjustmentDraft.helpers'

export function usePurchaseOrderAdjustmentDraft(assignment: () => TeamAssignmentDetailVm) {
  const reason = shallowRef('')
  const draftRows = ref<AdjustmentRow[]>([])

  const cmpRow = computed(() => buildRowComparator(assignment()))

  const adjustmentRows = computed(() => [...draftRows.value].sort(cmpRow.value))

  const allSizes = computed(() => collectAllSizes(assignment(), adjustmentRows.value))

  const poAdjustmentRows = computed(() => buildPoAdjustmentRows(adjustmentRows.value))

  const summaryRows = computed(() => buildSummaryRows(adjustmentRows.value, cmpRow.value))

  const totalMismatches = computed(() =>
    buildTotalMismatches({
      summaryRows: summaryRows.value,
      allSizes: allSizes.value,
      compareRows: cmpRow.value,
    }),
  )

  const negativeEffectiveRows = computed(() =>
    adjustmentRows.value.filter((row) => row.afterQty < 0),
  )

  const unresolvedRows = computed(() =>
    adjustmentRows.value.filter((row) => row.afterQty > row.allocationQty),
  )

  const nonZeroDeltas = computed<PurchaseOrderQuantityDeltaCommand[]>(() =>
    buildNonZeroDeltas(adjustmentRows.value),
  )

  const typeTotalsBalanced = computed(() => {
    const totals = new Map<string, number>()
    for (const delta of nonZeroDeltas.value) {
      const type = assignment().purchaseOrderTypes?.[delta.purchaseOrderId] ?? 'REGULAR'
      const key = `${delta.color}|${delta.size}|${type}`
      totals.set(key, (totals.get(key) ?? 0) + delta.quantity)
    }
    return [...totals.values()].every((quantity) => quantity === 0)
  })

  const canSubmit = computed(
    () =>
      reason.value.trim().length > 0 &&
      nonZeroDeltas.value.length > 0 &&
      totalMismatches.value.length === 0 &&
      typeTotalsBalanced.value &&
      negativeEffectiveRows.value.length === 0 &&
      unresolvedRows.value.length === 0,
  )

  watch(
    assignment,
    (currentAssignment) => {
      draftRows.value = buildRows(currentAssignment)
      reason.value = ''
    },
    { immediate: true },
  )

  function applyGridEdit(rowIndex: number, prop: string, val: string | number | null | undefined) {
    if (!allSizes.value.includes(prop)) return
    const gridRow = poAdjustmentRows.value[rowIndex]
    if (!gridRow) return

    const [purchaseOrderId, color] = String(gridRow.rowKey).split('|')
    if (!purchaseOrderId || !color) return

    const row = draftRows.value.find(
      (item) =>
        item.purchaseOrderId === purchaseOrderId && item.color === color && item.size === prop,
    )
    if (!row) return

    const parsed = Number.parseInt(String(val ?? 0), 10)
    setAfterQty(row, Number.isFinite(parsed) ? parsed : 0)
  }

  function handleAfterEdit(edits: MatrixGridEdit[]) {
    for (const edit of edits) {
      applyGridEdit(edit.rowIndex, edit.prop, edit.value as string | number | null | undefined)
    }
  }

  function createPayload() {
    if (!canSubmit.value) return null
    return {
      reason: reason.value.trim(),
      deltas: nonZeroDeltas.value,
    }
  }

  return {
    reason,
    allSizes,
    poAdjustmentRows,
    summaryRows,
    totalMismatches,
    unresolvedRows,
    canSubmit,
    handleAfterEdit,
    createPayload,
  }
}
