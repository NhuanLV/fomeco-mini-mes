import { mount } from '@vue/test-utils'
import { defineComponent } from 'vue'
import { expect, it, vi } from 'vitest'
import { useBomLineEditor } from '../useBomLineEditor'
import type { LineEditState } from '@/shared/components/bom/types'

vi.mock('@pinia/colada', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@pinia/colada')>()),
  useMutation: () => ({ mutateAsync: vi.fn() }),
  useQueryCache: () => ({ invalidateQueries: vi.fn() }),
}))

it('overwrites all following rows from the first row, including zero, and respects editable columns', () => {
  let editor!: ReturnType<typeof useBomLineEditor>
  const wrapper = mount(
    defineComponent({
      setup() {
        editor = useBomLineEditor(
          () => 'team',
          () => undefined,
        )
        return () => null
      },
    }),
  )
  const state: LineEditState = {
    sizes: [2, null, 0, 3].map((consumption) => ({
      productSize: '',
      materialSize: '',
      consumption,
    })),
    colors: [
      { productColor: 'A', materialColor: '', consumption: 0, cuttingConsumption: 2 },
      { productColor: 'B', materialColor: '', consumption: null, cuttingConsumption: 3 },
      { productColor: 'C', materialColor: '', consumption: 4, cuttingConsumption: null },
    ],
    originalSizes: '',
    originalColors: '',
    saving: false,
  }
  editor.editStates.set('line', state)
  editor.applyFirstToAll('line', 'sizes')
  editor.applyFirstToAll('line', 'colors', false, true)
  expect(state.sizes.map((row) => row.consumption)).toEqual([2, 2, 2, 2])
  expect(state.colors.map((row) => row.consumption)).toEqual([0, null, 4])
  expect(state.colors.map((row) => row.cuttingConsumption)).toEqual([2, 2, 2])
  editor.applyFirstToAll('line', 'colors', true, false)
  expect(state.colors.map((row) => row.consumption)).toEqual([0, 0, 0])
  state.sizes[0]!.consumption = null
  state.sizes[1]!.consumption = null
  editor.applyFirstToAll('line', 'sizes')
  expect(state.sizes.map((row) => row.consumption)).toEqual([null, null, 2, 2])
  wrapper.unmount()
})
