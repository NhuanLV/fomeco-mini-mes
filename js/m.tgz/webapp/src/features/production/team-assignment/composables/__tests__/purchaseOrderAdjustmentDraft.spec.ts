import type { TeamAssignmentDetailVm } from '@/api'
import { usePurchaseOrderAdjustmentDraft } from '@/features/production/team-assignment/composables/usePurchaseOrderAdjustmentDraft'
import { describe, expect, it } from 'vitest'

describe('usePurchaseOrderAdjustmentDraft', () => {
  it('rejects a balanced transfer between different PO types', () => {
    const assignment = makeAssignment()
    assignment.purchaseOrderTypes = { 'po-1': 'REGULAR', 'po-2': 'POSITIVE' }
    const draft = usePurchaseOrderAdjustmentDraft(() => assignment)
    draft.handleAfterEdit([
      { rowIndex: 0, prop: 'S', value: 5 },
      { rowIndex: 1, prop: 'S', value: 10 },
    ])
    draft.reason.value = 'Chuyển khác loại'
    expect(draft.canSubmit.value).toBe(false)
  })

  it('builds a balanced PO adjustment payload from normalized grid edits and includes totalBySizeRow', () => {
    const draft = usePurchaseOrderAdjustmentDraft(makeAssignment)

    expect(draft.poAdjustmentRows.value).toEqual([
      expect.objectContaining({
        rowKey: 'po-1|Red',
        S: { current: 8, limit: 5 },
        totalByColor: { current: 8, limit: 5 },
      }),
      expect.objectContaining({
        rowKey: 'po-2|Red',
        S: { current: 7, limit: 10 },
        totalByColor: { current: 7, limit: 10 },
      }),
      expect.objectContaining({
        rowKey: '__total_row__',
        color: 'Tổng',
        isTotalBySize: true,
        S: { current: 15, limit: 15 },
        totalByColor: { current: 15, limit: 15 },
      }),
    ])

    expect(draft.summaryRows.value).toEqual([
      expect.objectContaining({
        color: 'Red',
        S: { current: 15, limit: 15 },
        totalByColor: { current: 15, limit: 15 },
      }),
      expect.objectContaining({
        color: 'Tổng',
        isTotalBySize: true,
        S: { current: 15, limit: 15 },
        totalByColor: { current: 15, limit: 15 },
      }),
    ])

    draft.handleAfterEdit([
      { rowIndex: 0, prop: 'S', value: 5 },
      { rowIndex: 1, prop: 'S', value: 10 },
    ])
    draft.reason.value = 'Điều chỉnh lại PO'

    expect(draft.canSubmit.value).toBe(true)
    expect(draft.createPayload()).toEqual({
      reason: 'Điều chỉnh lại PO',
      deltas: [
        { purchaseOrderId: 'po-1', color: 'Red', size: 'S', quantity: -3 },
        { purchaseOrderId: 'po-2', color: 'Red', size: 'S', quantity: 3 },
      ],
    })
  })
})

function makeAssignment(): TeamAssignmentDetailVm {
  return {
    productionOrderStatus: 'IN_PROGRESS',
    id: 'assignment-1',
    productionOrderId: 'production-1',
    productionCode: 'LSX-1',
    styleName: 'Style 1',
    styleColorOrder: ['Red'],
    styleSizeOrder: ['S'],
    factoryName: 'Factory 1',
    companyName: 'Company 1',
    companyId: 'company-1',
    teamId: 'team-1',
    teamName: 'Team 1',
    operation: 'SEW',
    allocations: [
      {
        purchaseOrderId: 'po-1',
        color: 'Red',
        size: 'S',
        quantity: 5,
        notes: [],
      },
      {
        purchaseOrderId: 'po-2',
        color: 'Red',
        size: 'S',
        quantity: 10,
        notes: [],
      },
    ],
    outputReportTotals: [
      { purchaseOrderId: 'po-1', color: 'Red', size: 'S', completedQty: 8 },
      { purchaseOrderId: 'po-2', color: 'Red', size: 'S', completedQty: 7 },
    ],
    inputReportTotals: [],
    metadataRows: [],
    purchaseOrderTypes: {},
    purchaseOrderCodes: { 'po-1': 'PO-1', 'po-2': 'PO-2' },
    purchaseOrderDestinations: { 'po-1': 'US', 'po-2': 'US' },
    assignedAt: '2026-07-26T00:00:00Z',
    reconciliationStatus: 'NEEDS_ADJUSTMENT',
  }
}
