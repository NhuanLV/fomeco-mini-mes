import type { TeamBomLineVm, TeamBomVm } from '@/api'
import {
  getTeamBomQueryKey,
  overrideBomLineMutation,
  updateCuttingConsumptionMutation,
} from '@/api/@pinia/colada.gen'
import { makeOrderComparator } from '@/shared/utils/orderedValues'
import { showError } from '@/shared/utils/toast'
import { useMutation, useQueryCache } from '@pinia/colada'
import { reactive, watch } from 'vue'
import type { EditableColor, EditableSize, LineEditState } from '@/shared/components/bom/types'

export function initEditState(
  line: TeamBomLineVm,
  styleSizeOrder: readonly string[] = [],
  styleColorOrder: readonly string[] = [],
): LineEditState {
  const cmpSize = makeOrderComparator(styleSizeOrder)
  const cmpColor = makeOrderComparator(styleColorOrder)
  const sizes: EditableSize[] = line.sizes
    .map((s) => ({
      productSize: s.productSize,
      materialSize: s.materialSize,
      consumption: s.consumption,
    }))
    .sort(
      (left, right) =>
        cmpSize(left.productSize, right.productSize) ||
        left.materialSize.localeCompare(right.materialSize),
    )
  const colors: EditableColor[] = line.colors
    .map((c) => {
      const cut = line.cuttingColors.find((cc) => cc.productColor === c.productColor)
      return {
        productColor: c.productColor,
        materialColor: c.materialColor,
        consumption: c.consumption ?? null,
        cuttingConsumption: cut?.consumption ?? null,
      }
    })
    .sort(
      (left, right) =>
        cmpColor(left.productColor, right.productColor) ||
        left.materialColor.localeCompare(right.materialColor, 'vi'),
    )
  return {
    sizes,
    colors,
    originalSizes: JSON.stringify(sizes),
    originalColors: JSON.stringify(colors),
    saving: false,
  }
}

export function useBomLineEditor(
  teamAssignmentId: () => string,
  bomData: () => TeamBomVm | undefined,
  styleSizeOrder: () => readonly string[] = () => [],
  styleColorOrder: () => readonly string[] = () => [],
) {
  const { mutateAsync: saveOverride } = useMutation(overrideBomLineMutation())
  const { mutateAsync: saveCutting } = useMutation(updateCuttingConsumptionMutation())
  const queryCache = useQueryCache()

  const editStates = reactive(new Map<string, LineEditState>())

  function ensureState(line: TeamBomLineVm) {
    if (!editStates.has(line.id)) {
      editStates.set(line.id, initEditState(line, styleSizeOrder(), styleColorOrder()))
    }
  }

  function isLineDirty(lineId: string): boolean {
    const s = editStates.get(lineId)
    if (!s) return false
    return (
      JSON.stringify(s.sizes) !== s.originalSizes || JSON.stringify(s.colors) !== s.originalColors
    )
  }

  function removeState(lineId: string) {
    editStates.delete(lineId)
  }

  function onSizeCellEdit(data: EditableSize, newValue: number | null) {
    data.consumption = newValue
  }

  function onColorCellEdit(
    data: EditableColor,
    field: 'consumption' | 'cuttingConsumption',
    newValue: number | null,
  ) {
    if (field === 'consumption') data.consumption = newValue ?? null
    if (field === 'cuttingConsumption') data.cuttingConsumption = newValue ?? null
  }

  function applyFirstToAll(
    lineId: string,
    field: 'sizes' | 'colors',
    canEditConsumption = true,
    canEditCuttingConsumption = true,
  ) {
    const state = editStates.get(lineId)
    if (!state) return
    const rows = state[field]
    if (rows.length < 2) return
    if (field === 'sizes') {
      const val = (rows as EditableSize[])[0].consumption
      if (val == null) return
      ;(rows as EditableSize[]).slice(1).forEach((r) => {
        r.consumption = val
      })
    } else {
      const val = (rows as EditableColor[])[0].consumption
      const cutVal = (rows as EditableColor[])[0].cuttingConsumption
      ;(rows as EditableColor[]).slice(1).forEach((r) => {
        if (canEditConsumption && val != null) r.consumption = val
        if (canEditCuttingConsumption && cutVal != null) r.cuttingConsumption = cutVal
      })
    }
  }

  async function handleSave(lineId: string): Promise<boolean> {
    const state = editStates.get(lineId)
    if (!state) return false

    state.saving = true
    try {
      const sizesChanged = JSON.stringify(state.sizes) !== state.originalSizes
      const origColors = JSON.parse(state.originalColors) as EditableColor[]
      const colorsConsumptionChanged = state.colors.some(
        (c, i) => c.consumption !== origColors[i]?.consumption,
      )
      const tid = teamAssignmentId()
      if (sizesChanged || colorsConsumptionChanged) {
        await saveOverride({
          path: { id: tid, lineId },
          body: {
            sizes: state.sizes.map((s) => ({
              materialSize: s.materialSize,
              productSize: s.productSize,
              consumption: s.consumption ?? 0,
            })),
            colors: state.colors.map((c) => ({
              productColor: c.productColor,
              materialColor: c.materialColor,
              consumption: c.consumption ?? 0,
            })),
          },
        })
      }

      const cuttingChanged = state.colors.some(
        (c, i) => c.cuttingConsumption !== origColors[i]?.cuttingConsumption,
      )
      if (cuttingChanged) {
        await saveCutting({
          path: { id: tid },
          body: {
            lineId,
            items: state.colors.map((c) => ({
              productColor: c.productColor,
              materialColor: c.materialColor,
              consumption: c.cuttingConsumption ?? 0,
            })),
          },
        })
      }

      // Update original baseline so the line is marked non-dirty after save
      state.originalSizes = JSON.stringify(state.sizes)
      state.originalColors = JSON.stringify(state.colors)

      void queryCache.invalidateQueries({
        key: getTeamBomQueryKey({ path: { id: tid } }),
      })
      return true
    } catch (e: unknown) {
      showError((e as Error).message || 'Lỗi khi lưu định mức')
      return false
    } finally {
      state.saving = false
    }
  }

  watch(bomData, () => {
    for (const [lineId] of editStates) {
      if (isLineDirty(lineId)) continue
      const line = bomData()?.lines?.find((l) => l.id === lineId)
      if (line) editStates.set(line.id, initEditState(line, styleSizeOrder()))
      else editStates.delete(lineId)
    }
  })

  return {
    editStates,
    ensureState,
    removeState,
    isLineDirty,
    onSizeCellEdit,
    onColorCellEdit,
    applyFirstToAll,
    handleSave,
  }
}
