import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'
import { nextTick } from 'vue'
import { useTeamAssignmentList } from '../useTeamAssignmentList'

describe('useTeamAssignmentList', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  it('resets all filters back to initial state', () => {
    const list = useTeamAssignmentList()
    list.boWfxIdFilter.value = ['BO-123']
    list.styleFilter.value = ['STYLE-A']
    list.statusFilter.value = ['IN_PROGRESS']
    list.page.value = 2

    list.resetFilters()

    expect(list.boWfxIdFilter.value).toEqual([])
    expect(list.styleFilter.value).toEqual([])
    expect(list.statusFilter.value).toEqual([])
    expect(list.page.value).toBe(0)
    expect(list.assignedAtRange.value).toBeNull()
  })

  it('returns to the first page when a filter changes', async () => {
    const list = useTeamAssignmentList()
    list.page.value = 2

    list.statusFilter.value = ['IN_PROGRESS']
    await nextTick()

    expect(list.page.value).toBe(0)
  })
})
