import type { PurchaseOrderQuantityDeltaCommand, TeamAssignmentDetailVm } from '@/api'
import { makeOrderComparator } from '@/shared/utils/orderedValues'

export type AdjustmentRow = {
  purchaseOrderId: string
  poCode: string
  destination: string
  color: string
  size: string
  allocationQty: number
  effectiveQty: number
  afterQty: number
}

export type GridLimitCell = { current: number; limit: number }

export type AdjustmentGridRow = {
  rowKey: string
  poCode: string
  destination: string
  color: string
  totalByColor: GridLimitCell
  isTotalBySize?: boolean
  [key: string]: string | number | GridLimitCell | boolean | undefined
}

export type SummaryGridRow = {
  color: string
  totalByColor: GridLimitCell
  isTotalBySize?: boolean
  [key: string]: string | number | GridLimitCell | boolean | undefined
}

export type QuantityMismatch = {
  color: string
  size: string
  afterQty: number
  effectiveQty: number
}

const emptyRow: AdjustmentRow = {
  purchaseOrderId: '',
  poCode: '',
  destination: '',
  color: '',
  size: '',
  allocationQty: 0,
  effectiveQty: 0,
  afterQty: 0,
}

export function buildRows(assignment: TeamAssignmentDetailVm): AdjustmentRow[] {
  const rowsByKey = new Map<string, AdjustmentRow>()

  function ensureRow(item: {
    purchaseOrderId: string
    color: string
    size: string
  }): AdjustmentRow {
    const key = `${item.purchaseOrderId}|${item.color}|${item.size}`
    const existing = rowsByKey.get(key)
    if (existing) return existing

    const row = {
      purchaseOrderId: item.purchaseOrderId,
      poCode: assignment.purchaseOrderCodes[item.purchaseOrderId] ?? item.purchaseOrderId,
      destination: assignment.purchaseOrderDestinations[item.purchaseOrderId] ?? '',
      color: item.color,
      size: item.size,
      allocationQty: 0,
      effectiveQty: 0,
      afterQty: 0,
    }
    rowsByKey.set(key, row)
    return row
  }

  for (const allocation of assignment.allocations) {
    ensureRow(allocation).allocationQty += allocation.quantity
  }

  for (const total of assignment.outputReportTotals) {
    ensureRow(total).effectiveQty += total.completedQty
  }

  return [...rowsByKey.values()].map((row) => ({ ...row, afterQty: row.effectiveQty }))
}

export function buildRowComparator(assignment: TeamAssignmentDetailVm) {
  const cmpColor = makeOrderComparator(assignment.styleColorOrder)
  const cmpSize = makeOrderComparator(assignment.styleSizeOrder)
  return (left: AdjustmentRow, right: AdjustmentRow) =>
    cmpColor(left.color, right.color) ||
    cmpSize(left.size, right.size) ||
    left.poCode.localeCompare(right.poCode)
}

export function collectAllSizes(assignment: TeamAssignmentDetailVm, rows: AdjustmentRow[]) {
  const sizes = new Set<string>(assignment.styleSizeOrder)
  for (const row of rows) {
    sizes.add(row.size)
  }
  const cmpSize = makeOrderComparator(assignment.styleSizeOrder)
  return [...sizes].sort(cmpSize)
}

export function buildPoAdjustmentRows(rows: AdjustmentRow[]) {
  const rowMap = new Map<string, AdjustmentGridRow>()

  for (const row of rows) {
    const rowKey = `${row.purchaseOrderId}|${row.color}`
    const gridRow =
      rowMap.get(rowKey) ??
      ({
        rowKey,
        poCode: row.poCode,
        destination: row.destination,
        color: row.color,
        totalByColor: { current: 0, limit: 0 },
      } as AdjustmentGridRow)

    gridRow[row.size] = { current: row.afterQty, limit: row.allocationQty }
    gridRow.totalByColor.current += row.afterQty
    gridRow.totalByColor.limit += row.allocationQty
    rowMap.set(rowKey, gridRow)
  }

  const dataRows = [...rowMap.values()]
  if (dataRows.length === 0) return dataRows

  const sizes = new Set<string>()
  for (const r of rows) sizes.add(r.size)

  let grandCurrent = 0
  let grandLimit = 0
  const sizeSums: Record<string, GridLimitCell> = {}

  for (const size of sizes) {
    let currentSum = 0
    let limitSum = 0
    for (const r of rows) {
      if (r.size === size) {
        currentSum += r.afterQty
        limitSum += r.allocationQty
      }
    }
    sizeSums[size] = { current: currentSum, limit: limitSum }
    grandCurrent += currentSum
    grandLimit += limitSum
  }

  const totalBySizeRow: AdjustmentGridRow = {
    rowKey: '__total_row__',
    poCode: '',
    destination: '',
    color: 'Tổng',
    isTotalBySize: true,
    totalByColor: { current: grandCurrent, limit: grandLimit },
    ...sizeSums,
  }

  return [...dataRows, totalBySizeRow]
}

export function buildSummaryRows(
  rows: AdjustmentRow[],
  compareRows: (left: AdjustmentRow, right: AdjustmentRow) => number,
) {
  const summaryMap = new Map<string, SummaryGridRow>()

  for (const row of rows) {
    const summary =
      summaryMap.get(row.color) ??
      ({
        color: row.color,
        totalByColor: { current: 0, limit: 0 },
      } as SummaryGridRow)

    const currentCell = summary[row.size]
    const cell =
      typeof currentCell === 'object' && currentCell !== null
        ? (currentCell as GridLimitCell)
        : { current: 0, limit: 0 }

    cell.current += row.afterQty
    cell.limit += row.effectiveQty
    summary[row.size] = cell
    summary.totalByColor.current += row.afterQty
    summary.totalByColor.limit += row.effectiveQty
    summaryMap.set(row.color, summary)
  }

  const dataRows = [...summaryMap.values()].sort((left, right) =>
    compareRows(
      { ...emptyRow, color: String(left.color) },
      { ...emptyRow, color: String(right.color) },
    ),
  )

  if (dataRows.length === 0) return dataRows

  const sizes = new Set<string>()
  for (const r of rows) sizes.add(r.size)

  let grandCurrent = 0
  let grandEffective = 0
  const sizeSums: Record<string, GridLimitCell> = {}

  for (const size of sizes) {
    let currentSum = 0
    let effectiveSum = 0
    for (const r of rows) {
      if (r.size === size) {
        currentSum += r.afterQty
        effectiveSum += r.effectiveQty
      }
    }
    sizeSums[size] = { current: currentSum, limit: effectiveSum }
    grandCurrent += currentSum
    grandEffective += effectiveSum
  }

  const totalBySizeRow: SummaryGridRow = {
    color: 'Tổng',
    isTotalBySize: true,
    totalByColor: { current: grandCurrent, limit: grandEffective },
    ...sizeSums,
  }

  return [...dataRows, totalBySizeRow]
}

export function buildTotalMismatches(params: {
  summaryRows: SummaryGridRow[]
  allSizes: string[]
  compareRows: (left: AdjustmentRow, right: AdjustmentRow) => number
}) {
  const mismatches: QuantityMismatch[] = []

  for (const summary of params.summaryRows) {
    if (summary.isTotalBySize) continue
    for (const size of params.allSizes) {
      const cell = summary[size]
      if (typeof cell !== 'object' || cell === null) continue
      if (cell.current !== cell.limit) {
        mismatches.push({
          color: String(summary.color),
          size,
          afterQty: Number(cell.current),
          effectiveQty: Number(cell.limit),
        })
      }
    }
  }

  return mismatches.sort((left, right) =>
    params.compareRows(
      { ...emptyRow, color: left.color, size: left.size },
      {
        ...emptyRow,
        color: right.color,
        size: right.size,
      },
    ),
  )
}

export function buildNonZeroDeltas(rows: AdjustmentRow[]): PurchaseOrderQuantityDeltaCommand[] {
  return rows
    .map((row) => ({
      row,
      deltaQty: row.afterQty - row.effectiveQty,
    }))
    .filter(({ deltaQty }) => deltaQty !== 0)
    .map((row) => ({
      purchaseOrderId: row.row.purchaseOrderId,
      color: row.row.color,
      size: row.row.size,
      quantity: row.deltaQty,
    }))
}

export function setAfterQty(row: AdjustmentRow, quantity: number | null | undefined) {
  row.afterQty = Math.max(0, Math.trunc(quantity ?? 0))
}
