import type { TeamAssignmentVm } from '@/api'

export type TeamAssignmentStatus = TeamAssignmentVm['displayStatus'] | 'WAITING_FOR_MATERIALS'

export function getTeamAssignmentStatus(assignment: TeamAssignmentVm): TeamAssignmentStatus {
  return assignment.displayStatus
}

export const TEAM_ASSIGNMENT_STATUS_OPTIONS: Array<{
  value: TeamAssignmentStatus
  label: string
  color: 'error' | 'warning' | 'success' | 'info' | 'neutral'
}> = [
  { value: 'CANCELLED', label: 'Đã hủy', color: 'neutral' },
  { value: 'WAITING_FOR_MATERIALS', label: 'Chờ bổ sung NPL', color: 'error' },
  { value: 'NEEDS_ADJUSTMENT', label: 'Cần điều chỉnh', color: 'warning' },
  { value: 'COMPLETED', label: 'Hoàn thành', color: 'success' },
  { value: 'IN_PROGRESS', label: 'Đang thực hiện', color: 'info' },
  { value: 'NOT_STARTED', label: 'Chưa thực hiện', color: 'neutral' },
]

export function getTeamAssignmentStatusLabel(status: TeamAssignmentStatus | string): string {
  const found = TEAM_ASSIGNMENT_STATUS_OPTIONS.find((opt) => opt.value === status)
  return found ? found.label : status
}

export function getTeamAssignmentStatusColor(
  status: TeamAssignmentStatus | string,
): 'error' | 'warning' | 'success' | 'info' | 'neutral' {
  const found = TEAM_ASSIGNMENT_STATUS_OPTIONS.find((opt) => opt.value === status)
  return found ? found.color : 'neutral'
}
