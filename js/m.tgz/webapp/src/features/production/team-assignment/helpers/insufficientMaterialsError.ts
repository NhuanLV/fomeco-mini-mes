type MissingMaterial = {
  material: string
  color: string
  size: string
  shortage: number | string
  uom: string | null
}

type InsufficientMaterialsError = {
  message: string
  details: {
    code: 'INSUFFICIENT_MATERIALS'
    materials: MissingMaterial[]
  }
}

export function getInsufficientMaterialsNotification(error: unknown): {
  title: string
  lines: string[]
} | null {
  if (!isInsufficientMaterialsError(error)) return null

  const visibleMaterials = error.details.materials.slice(0, 2)
  const lines = visibleMaterials.map((material) => {
    const variant = [material.color, material.size].filter(Boolean).join(' / ')
    const shortage = `${material.shortage}${material.uom ? ` ${material.uom}` : ''}`
    return `• ${material.material}${variant ? ` (${variant})` : ''}: thiếu ${shortage}`
  })
  const remaining = error.details.materials.length - visibleMaterials.length
  if (remaining > 0) lines.push(`… và ${remaining} NPL khác`)

  return { title: error.message, lines }
}

function isInsufficientMaterialsError(error: unknown): error is InsufficientMaterialsError {
  if (!error || typeof error !== 'object') return false
  const candidate = error as Partial<InsufficientMaterialsError>
  return (
    typeof candidate.message === 'string' &&
    candidate.details?.code === 'INSUFFICIENT_MATERIALS' &&
    Array.isArray(candidate.details.materials)
  )
}
