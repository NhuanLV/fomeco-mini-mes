import { describe, expect, it } from 'vitest'
import { getInsufficientMaterialsNotification } from '../insufficientMaterialsError'

describe('getInsufficientMaterialsNotification', () => {
  it('formats up to two missing materials for one notification', () => {
    expect(
      getInsufficientMaterialsNotification({
        message: 'Không đủ NPL để báo ra chuyền',
        details: {
          code: 'INSUFFICIENT_MATERIALS',
          materials: [
            { material: 'NPL01 - Vải A', color: 'Đen', size: 'M', shortage: 20, uom: 'm' },
            { material: 'NPL02 - Chỉ B', color: '', size: '', shortage: 5, uom: 'cuộn' },
            { material: 'NPL03', color: '', size: '', shortage: 1, uom: null },
            { material: 'NPL04', color: '', size: '', shortage: 2, uom: null },
          ],
        },
      }),
    ).toEqual({
      title: 'Không đủ NPL để báo ra chuyền',
      lines: [
        '• NPL01 - Vải A (Đen / M): thiếu 20 m',
        '• NPL02 - Chỉ B: thiếu 5 cuộn',
        '… và 2 NPL khác',
      ],
    })
  })

  it('ignores unrelated errors', () => {
    expect(getInsufficientMaterialsNotification({ message: 'Không có quyền' })).toBeNull()
  })
})
