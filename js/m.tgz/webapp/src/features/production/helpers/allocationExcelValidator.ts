import type { PurchaseOrderVm } from '@/api'
import type { AllocationMatrix, SkuKey } from '../types'
import type { ExcelDataMap } from './allocationExcelTransformer'

// Kiểm tra tính hợp lệ của dữ liệu Excel so với demand
export function validateExcelAllocation(
  excelOpData: ExcelDataMap,
  matrices: AllocationMatrix[],
  selectedPOs: PurchaseOrderVm[],
): string[] {
  const errors: string[] = []
  const proposedTotals = new Map<string, number>()

  matrices.forEach((matrix) => {
    const matchedKey = Array.from(excelOpData.keys()).find(
      (key) => key.toLowerCase() === matrix.opName.toLowerCase(),
    )
    const opData = matchedKey ? excelOpData.get(matchedKey) : undefined

    const isMaster = Object.keys(matrix.totalMap || {}).length > 0

    if (!opData) {
      if (isMaster) {
        selectedPOs.forEach((po) => {
          po.skuQuantities.forEach((sku) => {
            const skuKey: SkuKey = `${po.id}|${sku.color}|${sku.size}`
            if (!proposedTotals.has(skuKey)) proposedTotals.set(skuKey, 0)
          })
        })
      }
      return
    }

    opData.forEach((teamMap, poColorKey) => {
      const [poId, colorName] = poColorKey.split('|')
      const po = selectedPOs.find((p) => p.id === poId)
      if (!po) return

      po.skuQuantities.forEach((sku) => {
        if (sku.color === colorName) {
          const skuKey: SkuKey = `${poId}|${colorName}|${sku.size}`
          let excelTotalForSku = 0
          teamMap.forEach((entry) => {
            excelTotalForSku += entry.qtys[sku.size] || 0
          })

          const limit = isMaster ? matrix.totalMap?.[skuKey] || 0 : proposedTotals.get(skuKey) || 0

          if (excelTotalForSku > limit) {
            errors.push(
              `[${matrix.opName}] PO: ${po.code}, Màu: ${colorName}, Size: ${sku.size} - Nhập: ${excelTotalForSku}, Tối đa: ${limit}`,
            )
          }

          proposedTotals.set(skuKey, excelTotalForSku)
        }
      })
    })
  })

  return errors
}
