export type POStatus = 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'

export const getStatusLabel = (status: POStatus | string): string => {
  switch (status) {
    case 'CANCELLED':
      return 'Đã hủy'
    case 'IN_PROGRESS':
      return 'Đang thực hiện'
    case 'COMPLETED':
      return 'Hoàn thành'
    default:
      return status
  }
}

export const getStatusSeverity = (status: POStatus | string): string => {
  switch (status) {
    case 'CANCELLED':
      return 'neutral'
    case 'IN_PROGRESS':
      return 'info'
    case 'COMPLETED':
      return 'success'
    default:
      return 'neutral'
  }
}

export const allPOStatuses: Array<{ value: POStatus; label: string }> = [
  { value: 'CANCELLED', label: 'Đã hủy' },
  { value: 'IN_PROGRESS', label: 'Đang thực hiện' },
  { value: 'COMPLETED', label: 'Hoàn thành' },
]

const getProductionOrderCodeParts = (code: string) => {
  const separatorIndex = code.lastIndexOf('-')
  if (separatorIndex === -1) {
    return { styleName: code, number: code }
  }

  return {
    styleName: code.slice(0, separatorIndex),
    number: code.slice(separatorIndex + 1),
  }
}

export const getProductionOrderStyleName = (code: string) =>
  getProductionOrderCodeParts(code).styleName

export const getProductionOrderNumber = (code: string) => getProductionOrderCodeParts(code).number
