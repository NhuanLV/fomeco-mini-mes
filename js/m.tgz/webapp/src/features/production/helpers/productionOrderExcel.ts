export const EXCEL_COLS = {
  PO: 'PO',
  PO_ID: 'PO ID',
  STYLE: 'Mã hàng',
  CUSTOMER: 'Khách hàng',
  BRAND: 'Thương hiệu',
  DESTINATION: 'Thị trường',
  COLOR: 'Màu',
  TOTAL: 'Tổng',
  OPERATION: 'Công đoạn',
  COMPANY: 'Công ty',
  FACTORY: 'Xí nghiệp',
  TEAM: 'Tổ',
  UNIT: 'Đơn vị',
  CHECK_DATE: 'Ngày kiểm',
  DELIVERY_DATE: 'Ngày giao',
  PLANNED_START_DATE: 'Ngày dự kiến bắt đầu',
  PLANNED_END_DATE: 'Ngày dự kiến hoàn thành',
  SYNC_DATE: 'Ngày đồng bộ chuẩn bị sản xuất',
  PROD_DATE: 'Ngày vào chuyền',
  FIRST_SKU: 'Màu cỡ đầu tiên',
} as const

export const EXCEL_LAYOUT = {
  TITLE: 'LỆNH SẢN XUẤT',
  METADATA_ROW_INDEX: 1,
  HEADER_ROW_INDEX: 5,
  DATA_ROW_START_INDEX: 6,
} as const

export const RESERVED_COLS: ReadonlySet<string> = new Set(Object.values(EXCEL_COLS))
