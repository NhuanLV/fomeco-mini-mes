import type { ProductionOrderExportData, PurchaseOrderVm } from '@/api'
import { makeOrderComparator } from '@/shared/utils/orderedValues'
import { formatDate } from '@/shared/utils/date'
import { formatJSDate } from '@/shared/utils/excelDate'
import { client } from '@/api/client.gen'
import { showError } from '@/shared/utils/toast'
import type { AllocationTemplateContext } from '../types'

export async function downloadAllocationTemplate(context: AllocationTemplateContext) {
  const {
    allSizes,
    selectedPOs,
    selectedRouting,
    styleColorOrder,
    styleName,
    fileName,
    customerName,
    brandName,
    matrices,
    autoOps,
    opNames,
    operationOrder,
    teams,
    noteColumnCount,
    syncDate,
    productDate,
    firstSku,
    subTotalMap,
  } = context

  const actualNoteCount = Math.max(1, noteColumnCount)

  const COL_START_NOTE = 3
  const COL_START_SIZE = COL_START_NOTE + actualNoteCount
  const COL_TOTAL = COL_START_SIZE + allSizes.length
  const COL_COMPANY = COL_TOTAL + 2
  const COL_FACTORY = COL_TOTAL + 3
  const COL_TEAM = COL_TOTAL + 4
  const COL_CHECK_DATE = COL_TOTAL + 5
  const COL_DELIVERY_DATE = COL_TOTAL + 6
  const COL_PLANNED_START_DATE = COL_TOTAL + 7
  const COL_PLANNED_END_DATE = COL_TOTAL + 8
  const totalColumnCount = COL_PLANNED_END_DATE + 1

  const teamMap = new Map(teams.map((team) => [team.id, team]))
  const poMap = new Map(selectedPOs.map((po) => [po.id, po]))
  const poOrder = new Map(selectedPOs.map((po, index) => [po.id, index]))
  const matrixMap = new Map(matrices?.map((matrix) => [matrix.opName.trim().toLowerCase(), matrix]))
  const autoOpMap = new Map(autoOps?.map((op) => [op.opName.trim().toLowerCase(), op]))
  const operationRank = new Map(
    (operationOrder ?? selectedRouting?.operations ?? opNames).map((op, index) => [op, index]),
  )
  const compareColor = makeOrderComparator(styleColorOrder ?? [])

  const createEmptyRow = () => Array<string | number>(totalColumnCount).fill('')

  const createBaseRow = (po: PurchaseOrderVm | undefined): (string | number)[] => {
    const row = createEmptyRow()
    row[0] = po?.code || ''
    row[1] = po?.destination || ''
    return row
  }

  const fillTeamInfo = (row: (string | number)[], teamId: string | null) => {
    if (!teamId) return
    const team = teamMap.get(teamId)
    if (!team) return

    row[COL_COMPANY] = team.companyName || ''
    row[COL_FACTORY] = team.factoryName || ''
    row[COL_TEAM] = team.name || ''
  }

  interface ExportRow {
    values: (string | number)[]
    opName: string
    poId: string
    color: string
    teamName: string
  }

  const dataRows: ExportRow[] = []

  if (opNames.length > 0) {
    opNames.forEach((opName) => {
      const opKey = opName.trim().toLowerCase()
      const allOperationsAuto = autoOps?.length === opNames.length
      const matrix = matrixMap.get(opKey) ?? (allOperationsAuto ? matrices?.[0] : undefined)
      const autoOp = autoOpMap.get(opKey)

      if (matrix) {
        Object.entries(matrix.rowMetaMap).forEach(([poColorKey, rows]) => {
          const [poId, colorName] = poColorKey.split('|')
          const po = poMap.get(poId)

          rows.forEach((rowMeta, rowIndex) => {
            const row = createBaseRow(po)
            let rowTotal = 0

            allSizes.forEach((size, sizeIndex) => {
              const skuKey = `${poId}|${colorName}|${size}`
              const qty = matrix.qtyMap[skuKey]?.[rowIndex] ?? 0
              row[COL_START_SIZE + sizeIndex] = qty
              rowTotal += qty
            })

            if (rowMeta.notes) {
              rowMeta.notes.forEach((note, noteIndex) => {
                row[COL_START_NOTE + noteIndex] = note
              })
            }

            row[COL_CHECK_DATE] = formatDate(rowMeta.checkDate || '')
            row[COL_DELIVERY_DATE] = formatDate(rowMeta.deliveryDate || '')
            row[COL_PLANNED_START_DATE] = formatDate(rowMeta.plannedStartDate || '')
            row[COL_PLANNED_END_DATE] = formatDate(rowMeta.plannedEndDate || '')
            fillTeamInfo(row, rowMeta.teamId ?? autoOp?.teamId ?? null)

            if (rowTotal > 0 || rowMeta.teamId || rowMeta.notes.length > 0) {
              dataRows.push({
                values: row,
                opName,
                poId,
                color: colorName,
                teamName: String(row[COL_TEAM] || ''),
              })
            }
          })
        })
      } else if (autoOp) {
        selectedPOs.forEach((po) => {
          const colors = [...new Set(po.skuQuantities.map((sku) => sku.color))]

          colors.forEach((color) => {
            const row = createBaseRow(po)
            let rowTotal = 0

            allSizes.forEach((size, sizeIndex) => {
              const skuKey = `${po.id}|${color}|${size}`
              const qty = subTotalMap?.[skuKey] || 0
              row[COL_START_SIZE + sizeIndex] = qty
              rowTotal += qty
            })

            if (rowTotal > 0) {
              row[COL_DELIVERY_DATE] = formatDate(po.deliveryDate || '')
              row[COL_PLANNED_START_DATE] = formatDate(autoOp.plannedStartDate || '')
              row[COL_PLANNED_END_DATE] = formatDate(autoOp.plannedEndDate || '')
              fillTeamInfo(row, autoOp.teamId)
              dataRows.push({
                values: row,
                opName,
                poId: po.id,
                color,
                teamName: String(row[COL_TEAM] || ''),
              })
            }
          })
        })
      }
    })
  }

  dataRows.sort((left, right) => {
    const opRankDiff =
      (operationRank.get(left.opName) ?? Number.MAX_SAFE_INTEGER) -
      (operationRank.get(right.opName) ?? Number.MAX_SAFE_INTEGER)
    if (opRankDiff !== 0) return opRankDiff

    const poRankDiff =
      (poOrder.get(left.poId) ?? Number.MAX_SAFE_INTEGER) -
      (poOrder.get(right.poId) ?? Number.MAX_SAFE_INTEGER)
    if (poRankDiff !== 0) return poRankDiff

    const colorDiff = compareColor(left.color, right.color)
    if (colorDiff !== 0) return colorDiff

    return left.teamName.localeCompare(right.teamName, undefined, { sensitivity: 'base' })
  })

  try {
    const { data } = await client.post<Blob, unknown, true>({
      url: '/api/production-orders/export',
      body: {
        factoryIds: context.factoryIds,
        styleName: styleName || '',
        orderNumber: fileName || '',
        customer: customerName || '',
        brand: brandName || '',
        syncDate: formatJSDate(syncDate),
        productDate: formatJSDate(productDate),
        firstSku: firstSku || '',
        allSizes,
        noteColumnCount: actualNoteCount,
        rows: dataRows.map(({ values, poId, color, opName }) => ({
          poId,
          poCode: String(values[0] || ''),
          destination: String(values[1] || ''),
          color,
          notes: values.slice(COL_START_NOTE, COL_START_SIZE).map(String),
          quantities: values.slice(COL_START_SIZE, COL_TOTAL).map(Number),
          operation: opName,
          company: String(values[COL_COMPANY] || ''),
          factory: String(values[COL_FACTORY] || ''),
          team: String(values[COL_TEAM] || ''),
          checkDate: String(values[COL_CHECK_DATE] || ''),
          deliveryDate: String(values[COL_DELIVERY_DATE] || ''),
          plannedStartDate: String(values[COL_PLANNED_START_DATE] || ''),
          plannedEndDate: String(values[COL_PLANNED_END_DATE] || ''),
        })),
      } satisfies ProductionOrderExportData,
      headers: { 'Content-Type': 'application/json' },
      responseType: 'blob',
      throwOnError: true,
    })
    const url = URL.createObjectURL(data)
    const link = document.createElement('a')
    link.href = url
    link.download = `LSX_${fileName || styleName || 'Chung'}.xlsx`
    document.body.appendChild(link)
    link.click()
    link.remove()
    URL.revokeObjectURL(url)
  } catch (err) {
    showError(err instanceof Error ? err.message : 'Lỗi khi xuất lệnh sản xuất')
  }
}
