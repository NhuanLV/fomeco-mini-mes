import type { BuyerOrderDetailVm, ProductionOrderVm, PurchaseOrderVm } from '@/api'
import { downloadAllocationTemplate } from '@/features/production/helpers/allocationExcelTemplate'
import type { AllocationMatrix, PoColorKey, RowMeta, SkuKey, TeamVm } from '../types'

export function exportProductionOrderToExcel(
  order: ProductionOrderVm,
  buyerOrder?: BuyerOrderDetailVm,
) {
  const allSizes = [
    ...new Set(order.teamAssignments.flatMap((ta) => ta.allocations.map((a) => a.size))),
  ]
  const opNames = [...new Set(order.teamAssignments.map((ta) => ta.operation))]

  const matrices: AllocationMatrix[] = opNames.map((opName) => {
    const qtyMap: Record<SkuKey, number[]> = {}
    const rowMetaMap: Record<PoColorKey, RowMeta[]> = {}

    const assignmentsForOp = order.teamAssignments.filter((ta) => ta.operation === opName)

    assignmentsForOp.forEach((ta, rowIndex) => {
      ta.allocations.forEach((alloc) => {
        const color = alloc.color
        const poColorKey = `${alloc.purchaseOrderId}|${color}`
        const skuKey = `${alloc.purchaseOrderId}|${color}|${alloc.size}`

        if (!qtyMap[skuKey]) {
          qtyMap[skuKey] = Array.from({ length: assignmentsForOp.length }, () => 0)
        }
        qtyMap[skuKey][rowIndex] = alloc.quantity

        if (!rowMetaMap[poColorKey]) {
          rowMetaMap[poColorKey] = Array.from({ length: assignmentsForOp.length }, () => ({
            teamId: null,
            teamName: '',
            notes: [],
          }))
        }
        rowMetaMap[poColorKey][rowIndex] = {
          teamId: ta.teamId,
          teamName: `${ta.teamName} - ${ta.factoryName} - ${ta.companyName}`,
          deliveryDate: alloc.deliveryDate || undefined,
          checkDate: alloc.checkDate || undefined,
          plannedStartDate: ta.plannedStartDate || undefined,
          plannedEndDate: ta.plannedEndDate || undefined,
          notes: alloc.notes || [],
        }
      })
    })

    return { opName, qtyMap, rowMetaMap, totalMap: {} }
  })

  // Danh sách POs đầy đủ cho TemplateContext
  const selectedPOs: PurchaseOrderVm[] = order.poSummaries.map((ps) => {
    return {
      id: ps.poId,
      code: ps.poCode,
      destination: ps.destination || '',
      deliveryDate: ps.deliveryDate || '',
      totalQuantity: ps.totalQuantity,
      skuQuantities: [],
      wfxId: '',
      type: 'REGULAR',
    }
  })

  // Các Teams tham gia
  const teams: TeamVm[] = []
  const teamIds = new Set<string>()
  order.teamAssignments.forEach((ta) => {
    if (!teamIds.has(ta.teamId)) {
      teamIds.add(ta.teamId)
      teams.push({
        id: ta.teamId,
        name: ta.teamName,
        operation: ta.operation,
        isActive: true,
        factoryName: ta.factoryName,
        companyName: ta.companyName,
      })
    }
  })

  // Số lượng cột ghi chú
  const maxNotes = order.teamAssignments.reduce((max, ta) => {
    const currentMax = ta.allocations.reduce((m, a) => Math.max(m, a.notes?.length || 0), 0)
    return Math.max(max, currentMax)
  }, 1)

  return downloadAllocationTemplate({
    factoryIds: order.factories.map((factory) => factory.id),
    allSizes,
    selectedPOs,
    selectedRouting: null,
    styleColorOrder: buyerOrder?.styleColorOrder,
    styleName: order.styleName,
    fileName: order.code,
    customerName: order.customer || buyerOrder?.customer || '',
    brandName: order.brand || buyerOrder?.brand || '',
    matrices,
    opNames,
    operationOrder: opNames,
    teams,
    noteColumnCount: maxNotes,
    syncDate: order.metadata?.syncDate ? new Date(order.metadata.syncDate) : null,
    productDate: order.metadata?.productDate ? new Date(order.metadata.productDate) : null,
    firstSku: order.metadata?.firstSku || undefined,
    isExportData: true,
  })
}
