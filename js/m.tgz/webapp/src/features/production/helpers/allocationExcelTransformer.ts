import {
  EXCEL_COLS,
  EXCEL_LAYOUT,
  RESERVED_COLS,
} from '@/features/production/helpers/productionOrderExcel'
import { formatExcelDate, parseToDate } from '@/shared/utils/excelDate'
import type { PoColorKey, RowMeta, TeamVm } from '../types'

export interface ExcelMetadata {
  syncDate: Date | null
  productDate: Date | null
  firstSku: string
  styleName?: string
  customerName?: string
  brandName?: string
}

export interface ExcelImportRow extends Record<string, unknown> {
  __excelRowNumber: number
}

export interface ExcelOpGroup {
  qtys: Record<string, number>
  meta: Partial<RowMeta>
}

export type ExcelDataMap = Map<string, Map<PoColorKey, Map<string, ExcelOpGroup>>>

type ExcelRow = ExcelImportRow
const UNASSIGNED_TEAM_KEY = ''

const REQUIRED_IMPORT_COLS = [
  EXCEL_COLS.PO,
  EXCEL_COLS.COLOR,
  EXCEL_COLS.TOTAL,
  EXCEL_COLS.OPERATION,
  EXCEL_COLS.CHECK_DATE,
  EXCEL_COLS.DELIVERY_DATE,
]

function normalizeCell(value: unknown): string {
  return String(value ?? '').trim()
}

function normalizeLookupKey(...parts: unknown[]): string {
  return parts
    .map((part) => normalizeCell(part))
    .filter(Boolean)
    .join(' - ')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/\s*-\s*/g, ' - ')
}

function isNoteColumn(header: string): boolean {
  return header.toLowerCase().startsWith('ghi chú')
}

function isRowEmpty(values: unknown[]): boolean {
  return values.every((value) => normalizeCell(value) === '')
}

function getRow(rawRows: unknown[], rowIndex: number): unknown[] {
  const row = rawRows[rowIndex]
  if (!Array.isArray(row)) {
    throw new Error('File Excel không đúng cấu trúc template mới.')
  }
  return row
}

function buildRowObject(headers: string[], values: unknown[], excelRowNumber: number): ExcelRow {
  const row: ExcelRow = { __excelRowNumber: excelRowNumber }
  headers.forEach((header, index) => {
    if (header) {
      row[header] = values[index]
    }
  })
  return row
}

function getHeaderLayout(headers: string[], allSizes: string[]) {
  if (!headers.includes(EXCEL_COLS.PO_ID)) {
    throw new Error('File Excel thiếu PO ID. Vui lòng tải lại mẫu phân bổ mới.')
  }
  const missingColumns = REQUIRED_IMPORT_COLS.filter((column) => !headers.includes(column))
  if (missingColumns.length > 0) {
    throw new Error(`Thiếu cột bắt buộc trong file Excel: ${missingColumns.join(', ')}`)
  }
  const hasUnitCol = headers.includes(EXCEL_COLS.UNIT)
  const hasLegacyTeamCol = headers.includes(EXCEL_COLS.TEAM)
  if (!hasUnitCol && !hasLegacyTeamCol) {
    throw new Error(
      `Thiếu cột đơn vị/tổ trong file Excel (cần cột "${EXCEL_COLS.UNIT}" hoặc "${EXCEL_COLS.TEAM}").`,
    )
  }

  const totalColumnIndex = headers.indexOf(EXCEL_COLS.TOTAL)
  if (totalColumnIndex === -1) {
    throw new Error(`Không tìm thấy cột ${EXCEL_COLS.TOTAL}.`)
  }

  const sizeColumns = headers.filter((header, index) => {
    if (!header || index >= totalColumnIndex) return false
    if (RESERVED_COLS.has(header) || isNoteColumn(header)) return false
    return allSizes.includes(header)
  })

  if (sizeColumns.length === 0) {
    throw new Error('Không tìm thấy cột size hợp lệ trong file Excel.')
  }

  return { sizeColumns }
}

function findHeaderRowIndex(rawRows: unknown[]): number {
  for (let i = 0; i < Math.min(rawRows.length, 15); i++) {
    const row = rawRows[i]
    if (Array.isArray(row)) {
      const normalized = row.map((cell) => normalizeCell(cell).toLowerCase())
      if (
        normalized.includes(EXCEL_COLS.PO.toLowerCase()) &&
        (normalized.includes(EXCEL_COLS.COLOR.toLowerCase()) ||
          normalized.includes(EXCEL_COLS.DESTINATION.toLowerCase()))
      ) {
        return i
      }
    }
  }
  return EXCEL_LAYOUT.HEADER_ROW_INDEX
}

function getMetadataValue(row: unknown[], label: string): unknown {
  const cleanLabel = label.toLowerCase().replace(/:$/, '').trim()
  const index = row.findIndex((cell) => {
    const cleanCell = normalizeCell(cell).toLowerCase().replace(/:$/, '').trim()
    return cleanCell === cleanLabel
  })
  return index === -1 ? undefined : row[index + 1]
}

function getTeamKey(team: Pick<TeamVm, 'companyName' | 'factoryName' | 'name'>): string {
  return normalizeLookupKey(team.name, team.factoryName, team.companyName)
}

function parseRowQtys(row: ExcelRow, sizeColumns: string[]): Record<string, number> {
  const qtys: Record<string, number> = {}

  sizeColumns.forEach((size) => {
    const value = Number(row[size]) || 0
    if (value > 0) {
      qtys[size] = value
    }
  })

  return qtys
}

export function extractMetadata(rawRows: unknown[]): ExcelMetadata {
  const headerRowIndex = findHeaderRowIndex(rawRows)
  const metadataRows = rawRows.slice(1, headerRowIndex).filter(Array.isArray)

  const findValue = (label: string): unknown => {
    for (const row of metadataRows) {
      const val = getMetadataValue(row, label)
      if (val !== undefined && normalizeCell(val) !== '') {
        return val
      }
    }
    return undefined
  }

  return {
    syncDate: parseToDate(findValue(EXCEL_COLS.SYNC_DATE)),
    productDate: parseToDate(findValue(EXCEL_COLS.PROD_DATE)),
    firstSku: normalizeCell(findValue(EXCEL_COLS.FIRST_SKU)),
    styleName: normalizeCell(findValue('mã hàng') ?? findValue(EXCEL_COLS.STYLE)),
    customerName: normalizeCell(findValue('khách hàng') ?? findValue(EXCEL_COLS.CUSTOMER)),
    brandName: normalizeCell(findValue('thương hiệu') ?? findValue(EXCEL_COLS.BRAND)),
  }
}

export function extractRows(
  rawRows: unknown[],
  allSizes: string[],
): { rows: ExcelImportRow[]; sizeColumns: string[] } {
  const headerRowIndex = findHeaderRowIndex(rawRows)
  const headerRow = getRow(rawRows, headerRowIndex)
  const headers = headerRow.map((cell) => normalizeCell(cell))
  const { sizeColumns } = getHeaderLayout(headers, allSizes)

  const dataStartRowIndex = headerRowIndex + 1
  const rows = rawRows
    .slice(dataStartRowIndex)
    .map((row, index) => ({ row, excelRowNumber: dataStartRowIndex + index + 1 }))
    .filter(
      (entry): entry is { row: unknown[]; excelRowNumber: number } =>
        Array.isArray(entry.row) && !isRowEmpty(entry.row),
    )
    .map((entry) => buildRowObject(headers, entry.row, entry.excelRowNumber))

  // Điền giá trị kế thừa từ dòng trước nếu ô bị merge hoặc khi người dùng bẻ dòng (tách dòng)
  let lastPo = ''
  let lastPoId = ''
  let lastDestination = ''
  let lastOperation = ''
  let lastDeliveryDate = ''

  rows.forEach((row) => {
    const currentPo = normalizeCell(row[EXCEL_COLS.PO])
    const currentPoId = normalizeCell(row[EXCEL_COLS.PO_ID])

    if (currentPo && currentPoId) {
      lastPo = currentPo
      lastPoId = currentPoId
    } else if (!currentPo && lastPo) {
      // Ô PO bị merge hoặc người dùng chèn dòng mới để bẻ dòng
      row[EXCEL_COLS.PO] = lastPo
      if (!currentPoId && lastPoId) {
        row[EXCEL_COLS.PO_ID] = lastPoId
      }
    } else if (currentPo && !currentPoId && currentPo === lastPo && lastPoId) {
      // Người dùng duplicate dòng hoặc gõ lại PO code nhưng cột ẩn PO ID bị trống
      row[EXCEL_COLS.PO_ID] = lastPoId
    } else if (currentPo && !currentPoId) {
      lastPo = currentPo
    }

    const currentDest = normalizeCell(row[EXCEL_COLS.DESTINATION])
    if (currentDest) {
      lastDestination = currentDest
    } else if (lastDestination) {
      row[EXCEL_COLS.DESTINATION] = lastDestination
    }

    const currentOp = normalizeCell(row[EXCEL_COLS.OPERATION])
    if (currentOp) {
      lastOperation = currentOp
    } else if (lastOperation) {
      row[EXCEL_COLS.OPERATION] = lastOperation
    }

    const currentDelivery = normalizeCell(row[EXCEL_COLS.DELIVERY_DATE])
    if (currentDelivery) {
      lastDeliveryDate = currentDelivery
    } else if (lastDeliveryDate) {
      row[EXCEL_COLS.DELIVERY_DATE] = lastDeliveryDate
    }
  })

  return { rows, sizeColumns }
}

export function extractRowNotes(row: ExcelRow): string[] {
  return Object.keys(row)
    .filter((key) => isNoteColumn(key))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }))
    .map((key) => normalizeCell(row[key]))
    .filter(Boolean)
}

export function transformExcelToOpData(
  rows: ExcelRow[],
  sizeColumns: string[],
  teams: TeamVm[],
  poById: Map<string, { id: string }>,
  resolvedTeamIdsByRowNumber?: Map<number, string>,
): ExcelDataMap {
  const opMap: ExcelDataMap = new Map()
  if (rows.length === 0) return opMap

  const teamLookupByOp = new Map<string, TeamVm>()
  const teamLookupByKey = new Map<string, TeamVm>()
  teams.forEach((team) => {
    const key = getTeamKey(team)
    teamLookupByOp.set(`${team.operation.toLowerCase()}|${key}`, team)
    teamLookupByKey.set(key, team)
  })

  rows.forEach((row) => {
    const opRaw = normalizeCell(row[EXCEL_COLS.OPERATION])
    const poCode = normalizeCell(row[EXCEL_COLS.PO])
    const poId = normalizeCell(row[EXCEL_COLS.PO_ID])
    const colorName = normalizeCell(row[EXCEL_COLS.COLOR])
    const unitRaw = normalizeCell(row[EXCEL_COLS.UNIT])
    const teamName = normalizeCell(row[EXCEL_COLS.TEAM])
    const excelRowNumber = row.__excelRowNumber
    const teamKey =
      unitRaw.length > 0
        ? normalizeLookupKey(unitRaw)
        : teamName.length > 0
          ? normalizeLookupKey(
              row[EXCEL_COLS.TEAM],
              row[EXCEL_COLS.FACTORY],
              row[EXCEL_COLS.COMPANY],
            )
          : UNASSIGNED_TEAM_KEY

    const po = poById.get(poId)
    const resolvedTeamId = resolvedTeamIdsByRowNumber?.get(excelRowNumber)
    const team = resolvedTeamId
      ? teams.find((candidate) => candidate.id === resolvedTeamId)
      : teamKey
        ? (teamLookupByOp.get(`${opRaw.toLowerCase()}|${teamKey}`) ?? teamLookupByKey.get(teamKey))
        : undefined

    if (!opRaw || !po || !colorName || (teamKey && !team)) {
      if (!opRaw && !poId && !poCode && !colorName && !teamName && !unitRaw) {
        return
      }

      if (!poId) {
        throw new Error(
          `Lỗi tại dòng ${excelRowNumber}: Thiếu PO ID. Vui lòng tải lại mẫu phân bổ mới.`,
        )
      }
      if (!po) {
        throw new Error(
          `Lỗi tại dòng ${excelRowNumber}: PO "${poCode}" (ID: ${poId}) không thuộc danh sách đang chọn.`,
        )
      }

      if (teamKey && !team) {
        const displayTeam =
          unitRaw.length > 0
            ? unitRaw
            : `${normalizeCell(row[EXCEL_COLS.TEAM])} - ${normalizeCell(row[EXCEL_COLS.FACTORY])} - ${normalizeCell(row[EXCEL_COLS.COMPANY])}`
        throw new Error(
          `Lỗi tại dòng ${excelRowNumber}: Không tìm thấy tổ khớp với "${displayTeam}".`,
        )
      }

      throw new Error(`Lỗi tại dòng ${excelRowNumber}: Thiếu dữ liệu bắt buộc để nhập phân bổ.`)
    }

    if (team && team.operation.toLowerCase() !== opRaw.toLowerCase()) {
      throw new Error(
        `Lỗi tại dòng ${excelRowNumber}: Tổ "${team.name}" thuộc công đoạn "${team.operation}", không khớp với "${opRaw}".`,
      )
    }

    if (!opMap.has(opRaw)) opMap.set(opRaw, new Map())
    const poGroup = opMap.get(opRaw)!
    const poColorKey: PoColorKey = `${po.id}|${colorName}`

    if (!poGroup.has(poColorKey)) poGroup.set(poColorKey, new Map())
    const teamGroup = poGroup.get(poColorKey)!

    const teamId = team?.id ?? UNASSIGNED_TEAM_KEY

    if (!teamGroup.has(teamId)) {
      teamGroup.set(teamId, {
        qtys: {},
        meta: {
          checkDate: formatExcelDate(row[EXCEL_COLS.CHECK_DATE]),
          deliveryDate: formatExcelDate(row[EXCEL_COLS.DELIVERY_DATE]),
          plannedStartDate: formatExcelDate(row[EXCEL_COLS.PLANNED_START_DATE]),
          plannedEndDate: formatExcelDate(row[EXCEL_COLS.PLANNED_END_DATE]),
          notes: extractRowNotes(row),
        },
      })
    }

    const entry = teamGroup.get(teamId)!
    const rowQtys = parseRowQtys(row, sizeColumns)
    Object.entries(rowQtys).forEach(([size, qty]) => {
      entry.qtys[size] = (entry.qtys[size] || 0) + qty
    })
  })

  return opMap
}
