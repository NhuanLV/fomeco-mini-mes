import { EXCEL_COLS } from '@/features/production/helpers/productionOrderExcel'
import type { TeamVm } from '../types'
import type { ExcelImportRow } from './allocationExcelTransformer'

export interface PendingTeamResolutionRow {
  key: string
  status: 'ambiguous' | 'unresolved'
  operationName: string
  excelValue: string
  rowNumbers: number[]
  candidateLabels: string[]
  selectedTeamId: string | null
}

export interface TeamResolutionResult {
  resolvedTeamIdsByRowNumber: Map<number, string>
  pendingRows: PendingTeamResolutionRow[]
}

export interface AllocationExcelTeamMatcher {
  match(rows: ExcelImportRow[], teams: TeamVm[]): TeamResolutionResult
}

export function buildTeamOptionLabel(team: TeamVm): string {
  return `${team.name} - ${team.factoryName} - ${team.companyName}`
}

function normalizeLabel(value: unknown): string {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/\s*-\s*/g, ' - ')
}

function normalizeOperationName(value: unknown): string {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
}

function getExcelUnitValue(row: ExcelImportRow): string {
  if (row[EXCEL_COLS.UNIT] != null && String(row[EXCEL_COLS.UNIT]).trim() !== '') {
    return String(row[EXCEL_COLS.UNIT]).trim()
  }
  const parts = [row[EXCEL_COLS.TEAM], row[EXCEL_COLS.FACTORY], row[EXCEL_COLS.COMPANY]]
    .map((val) => String(val ?? '').trim())
    .filter(Boolean)
  return parts.join(' - ')
}

function addPending(
  pendingMap: Map<string, PendingTeamResolutionRow>,
  row: ExcelImportRow,
  status: 'ambiguous' | 'unresolved',
  opRaw: string,
  excelValue: string,
  normalizedOp: string,
  normalizedExcelValue: string,
  candidateLabels: string[],
) {
  const key = `${normalizedOp}::${normalizedExcelValue}`
  const existing = pendingMap.get(key)
  if (existing) {
    existing.rowNumbers.push(row.__excelRowNumber)
  } else {
    pendingMap.set(key, {
      key,
      status,
      operationName: opRaw,
      excelValue,
      rowNumbers: [row.__excelRowNumber],
      candidateLabels,
      selectedTeamId: null,
    })
  }
}

export function matchAllocationExcelTeams(
  rows: ExcelImportRow[],
  teams: TeamVm[],
): TeamResolutionResult {
  const resolvedTeamIdsByRowNumber = new Map<number, string>()
  const pendingRowsMap = new Map<string, PendingTeamResolutionRow>()

  rows.forEach((row) => {
    const excelValue = getExcelUnitValue(row)
    if (!excelValue) {
      // Hàng chưa phân bổ tổ (unassigned) -> bỏ qua không cần match
      return
    }

    const opRaw = String(row[EXCEL_COLS.OPERATION] ?? '').trim()
    const normalizedOp = normalizeOperationName(opRaw)
    const opScopedTeams = teams.filter(
      (team) => normalizeOperationName(team.operation) === normalizedOp,
    )

    const normalizedExcelValue = normalizeLabel(excelValue)

    // 1. So khớp 100% theo full label của template: "${team.name} - ${factory.name} - ${company.name}"
    const fullLabelMatches = opScopedTeams.filter(
      (team) => normalizeLabel(buildTeamOptionLabel(team)) === normalizedExcelValue,
    )

    if (fullLabelMatches.length === 1) {
      resolvedTeamIdsByRowNumber.set(row.__excelRowNumber, fullLabelMatches[0].id)
      return
    }

    if (fullLabelMatches.length > 1) {
      addPending(
        pendingRowsMap,
        row,
        'ambiguous',
        opRaw,
        excelValue,
        normalizedOp,
        normalizedExcelValue,
        fullLabelMatches.map(buildTeamOptionLabel),
      )
      return
    }

    // 2. Fallback: 2 phần "${team.name} - ${factory.name}"
    const twoPartMatches = opScopedTeams.filter(
      (team) => normalizeLabel(`${team.name} - ${team.factoryName}`) === normalizedExcelValue,
    )

    if (twoPartMatches.length === 1) {
      resolvedTeamIdsByRowNumber.set(row.__excelRowNumber, twoPartMatches[0].id)
      return
    }

    if (twoPartMatches.length > 1) {
      addPending(
        pendingRowsMap,
        row,
        'ambiguous',
        opRaw,
        excelValue,
        normalizedOp,
        normalizedExcelValue,
        twoPartMatches.map(buildTeamOptionLabel),
      )
      return
    }

    // 3. Fallback: Tên tổ đơn lẻ (nếu duy nhất trong công đoạn)
    const nameMatches = opScopedTeams.filter(
      (team) => normalizeLabel(team.name) === normalizedExcelValue,
    )

    if (nameMatches.length === 1) {
      resolvedTeamIdsByRowNumber.set(row.__excelRowNumber, nameMatches[0].id)
      return
    }

    if (nameMatches.length > 1) {
      addPending(
        pendingRowsMap,
        row,
        'ambiguous',
        opRaw,
        excelValue,
        normalizedOp,
        normalizedExcelValue,
        nameMatches.map(buildTeamOptionLabel),
      )
      return
    }

    // Không tìm thấy tổ khớp
    addPending(
      pendingRowsMap,
      row,
      'unresolved',
      opRaw,
      excelValue,
      normalizedOp,
      normalizedExcelValue,
      opScopedTeams.slice(0, 5).map(buildTeamOptionLabel),
    )
  })

  return {
    resolvedTeamIdsByRowNumber,
    pendingRows: Array.from(pendingRowsMap.values()),
  }
}

export const exactAllocationExcelTeamMatcher: AllocationExcelTeamMatcher = {
  match: matchAllocationExcelTeams,
}

export const defaultAllocationExcelTeamMatcher: AllocationExcelTeamMatcher =
  exactAllocationExcelTeamMatcher
