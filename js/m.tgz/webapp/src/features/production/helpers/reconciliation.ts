import type { ProductionOrderVm, TeamAssignmentDetailVm, TeamAssignmentVm } from '@/api'

export function needsAdjustment(assignment: TeamAssignmentDetailVm | TeamAssignmentVm | undefined) {
  if (
    assignment &&
    (('productionOrderStatus' in assignment && assignment.productionOrderStatus === 'CANCELLED') ||
      ('displayStatus' in assignment && assignment.displayStatus === 'CANCELLED'))
  )
    return false
  return assignment?.reconciliationStatus === 'NEEDS_ADJUSTMENT'
}

export function hasNeedsAdjustment(order: ProductionOrderVm | undefined) {
  if (order?.status === 'CANCELLED') return false
  return order?.teamAssignments.some(needsAdjustment) ?? false
}

export function needsAllocationRevision(order: ProductionOrderVm | undefined) {
  return order?.needsAllocationRevision ?? false
}
