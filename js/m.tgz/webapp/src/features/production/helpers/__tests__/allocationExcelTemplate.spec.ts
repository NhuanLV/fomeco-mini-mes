import type { PurchaseOrderVm } from '@/api'
import { client } from '@/api/client.gen'
import { showError } from '@/shared/utils/toast'
import { downloadAllocationTemplate } from '../allocationExcelTemplate'
import { beforeEach, describe, expect, it, vi } from 'vitest'

vi.mock('@/api/client.gen', () => ({ client: { post: vi.fn() } }))
vi.mock('@/shared/utils/toast', () => ({ showError: vi.fn() }))

describe('allocation Excel export', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.mocked(client.post).mockResolvedValue({ data: new Blob(['excel']) } as never)
    vi.spyOn(URL, 'createObjectURL').mockReturnValue('blob:lsx')
    vi.spyOn(URL, 'revokeObjectURL').mockImplementation(() => {})
    vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {})
  })

  it('exports the shared quantities and metadata with each automatic team', async () => {
    await downloadAllocationTemplate({
      factoryIds: ['factory-1'],
      allSizes: ['S'],
      selectedPOs: [],
      selectedRouting: { title: 'Route', operations: ['CUT', 'SEW'] },
      opNames: ['CUT', 'SEW'],
      noteColumnCount: 1,
      teams: ['CUT', 'SEW'].map((operation) => ({
        id: operation,
        name: operation,
        operation,
        factoryName: 'XN',
        companyName: 'CT',
        isActive: true,
      })),
      autoOps: ['CUT', 'SEW'].map((opName) => ({ opName, teamId: opName, teamName: opName })),
      matrices: [
        {
          opName: 'CUT',
          totalMap: {},
          qtyMap: { 'po-1|Red|S': [3] },
          rowMetaMap: {
            'po-1|Red': [
              { teamId: null, teamName: '', notes: ['Chung'], deliveryDate: '2026-09-02' },
            ],
          },
        },
      ],
    })
    expect(client.post).toHaveBeenCalledWith(
      expect.objectContaining({
        body: expect.objectContaining({
          rows: [
            expect.objectContaining({
              team: 'CUT',
              quantities: [3],
              notes: ['Chung'],
              deliveryDate: '02/09/2026',
            }),
            expect.objectContaining({
              team: 'SEW',
              quantities: [3],
              notes: ['Chung'],
              deliveryDate: '02/09/2026',
            }),
          ],
        }),
      }),
    )
  })

  it('sends all export columns and stable PO IDs to POI in operation, PO and color order', async () => {
    const pos: PurchaseOrderVm[] = ['po-1', 'po-2'].map((id) => ({
      id,
      wfxId: `wfx-${id}`,
      code: 'SHARED',
      destination: 'US',
      deliveryDate: '2026-09-01',
      totalQuantity: 20,
      type: 'REGULAR',
      skuQuantities: [],
    }))
    await downloadAllocationTemplate({
      factoryIds: ['factory-1'],
      allSizes: ['S', 'M'],
      selectedPOs: pos,
      selectedRouting: { title: 'Route', operations: ['CUT'] },
      opNames: ['CUT'],
      styleColorOrder: ['Blue', 'Red'],
      styleName: 'STYLE',
      fileName: 'LSX-1',
      teams: [
        {
          id: 'team-1',
          name: 'Tổ 1',
          factoryName: 'XN 1',
          companyName: 'CT 1',
          operation: 'CUT',
          isActive: true,
        },
      ],
      noteColumnCount: 3,
      matrices: [
        {
          opName: 'CUT',
          totalMap: {},
          qtyMap: { 'po-1|Red|S': [10], 'po-1|Blue|M': [2], 'po-2|Red|S': [11] },
          rowMetaMap: Object.fromEntries(
            ['po-2|Red', 'po-1|Red', 'po-1|Blue'].map((key) => [
              key,
              [
                {
                  teamId: 'team-1',
                  teamName: 'Tổ 1',
                  notes: ['note 1', '', 'note 3'],
                  checkDate: '2026-09-01',
                  deliveryDate: '2026-09-02',
                  plannedStartDate: '2026-08-01',
                  plannedEndDate: '2026-08-31',
                },
              ],
            ]),
          ),
        },
      ],
    })
    expect(client.post).toHaveBeenCalledWith(
      expect.objectContaining({
        url: '/api/production-orders/export',
        responseType: 'blob',
        throwOnError: true,
        body: expect.objectContaining({
          factoryIds: ['factory-1'],
          orderNumber: 'LSX-1',
          allSizes: ['S', 'M'],
          noteColumnCount: 3,
          rows: [
            expect.objectContaining({ poId: 'po-1', color: 'Blue', quantities: [0, 2] }),
            expect.objectContaining({ poId: 'po-1', color: 'Red', quantities: [10, 0] }),
            expect.objectContaining({
              poId: 'po-2',
              color: 'Red',
              quantities: [11, 0],
              poCode: 'SHARED',
              company: 'CT 1',
              factory: 'XN 1',
              team: 'Tổ 1',
              notes: ['note 1', '', 'note 3'],
              checkDate: '01/09/2026',
              deliveryDate: '02/09/2026',
              plannedStartDate: '01/08/2026',
              plannedEndDate: '31/08/2026',
            }),
          ],
        }),
      }),
    )
    expect(HTMLAnchorElement.prototype.click).toHaveBeenCalledOnce()
    expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:lsx')
  })

  it('reports export failures without downloading a broken file', async () => {
    vi.mocked(client.post).mockRejectedValue(new Error('Export failed'))
    await downloadAllocationTemplate({
      factoryIds: ['factory-1'],
      allSizes: [],
      selectedPOs: [],
      selectedRouting: null,
      opNames: [],
      teams: [],
      noteColumnCount: 0,
    })
    expect(showError).toHaveBeenCalledWith('Export failed')
    expect(HTMLAnchorElement.prototype.click).not.toHaveBeenCalled()
  })
})
