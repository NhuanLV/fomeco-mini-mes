import { describe, expect, it } from 'vitest'
import { EXCEL_COLS } from '@/features/production/helpers/productionOrderExcel'
import type { TeamVm } from '@/features/production/types'
import { exactAllocationExcelTeamMatcher } from '../allocationExcelTeamMatcher'

describe('allocationExcelTeamMatcher', () => {
  const teams: TeamVm[] = [
    {
      id: 'team-1',
      name: 'Tổ May 1',
      operation: 'SEW',
      isActive: true,
      factoryName: 'Xí nghiệp 1',
      companyName: 'Công ty LGG',
    },
    {
      id: 'team-2',
      name: 'Tổ May 2',
      operation: 'SEW',
      isActive: true,
      factoryName: 'Xí nghiệp 1',
      companyName: 'Công ty LGG',
    },
    {
      id: 'team-cut-1',
      name: 'Tổ Cắt 1',
      operation: 'CUT',
      isActive: true,
      factoryName: 'Xí nghiệp 1',
      companyName: 'Công ty LGG',
    },
  ]

  it('matches 100% exactly from template unit label', () => {
    const rows = [
      {
        __excelRowNumber: 5,
        [EXCEL_COLS.OPERATION]: 'SEW',
        [EXCEL_COLS.UNIT]: 'Tổ May 1 - Xí nghiệp 1 - Công ty LGG',
      },
      {
        __excelRowNumber: 6,
        [EXCEL_COLS.OPERATION]: 'SEW',
        [EXCEL_COLS.UNIT]: 'Tổ May 2 - Xí nghiệp 1 - Công ty LGG',
      },
    ]

    const result = exactAllocationExcelTeamMatcher.match(rows, teams)

    expect(result.pendingRows).toHaveLength(0)
    expect(result.resolvedTeamIdsByRowNumber.get(5)).toBe('team-1')
    expect(result.resolvedTeamIdsByRowNumber.get(6)).toBe('team-2')
  })

  it('matches case-insensitively and tolerates extra whitespace around dashes', () => {
    const rows = [
      {
        __excelRowNumber: 5,
        [EXCEL_COLS.OPERATION]: 'SEW',
        [EXCEL_COLS.UNIT]: '  tổ may 1  -   xí nghiệp 1 -  công ty lgg  ',
      },
    ]

    const result = exactAllocationExcelTeamMatcher.match(rows, teams)

    expect(result.pendingRows).toHaveLength(0)
    expect(result.resolvedTeamIdsByRowNumber.get(5)).toBe('team-1')
  })

  it('matches fallback legacy 3 columns (TEAM, FACTORY, COMPANY)', () => {
    const rows = [
      {
        __excelRowNumber: 5,
        [EXCEL_COLS.OPERATION]: 'SEW',
        [EXCEL_COLS.TEAM]: 'Tổ May 1',
        [EXCEL_COLS.FACTORY]: 'Xí nghiệp 1',
        [EXCEL_COLS.COMPANY]: 'Công ty LGG',
      },
    ]

    const result = exactAllocationExcelTeamMatcher.match(rows, teams)

    expect(result.pendingRows).toHaveLength(0)
    expect(result.resolvedTeamIdsByRowNumber.get(5)).toBe('team-1')
  })

  it('matches fallback single team name when unique in the operation', () => {
    const rows = [
      {
        __excelRowNumber: 5,
        [EXCEL_COLS.OPERATION]: 'SEW',
        [EXCEL_COLS.UNIT]: 'Tổ May 1',
      },
    ]

    const result = exactAllocationExcelTeamMatcher.match(rows, teams)

    expect(result.pendingRows).toHaveLength(0)
    expect(result.resolvedTeamIdsByRowNumber.get(5)).toBe('team-1')
  })

  it('skips empty/blank unit rows (unallocated rows)', () => {
    const rows = [
      {
        __excelRowNumber: 5,
        [EXCEL_COLS.OPERATION]: 'SEW',
        [EXCEL_COLS.UNIT]: '',
      },
      {
        __excelRowNumber: 6,
        [EXCEL_COLS.OPERATION]: 'SEW',
        [EXCEL_COLS.UNIT]: '   ',
      },
      {
        __excelRowNumber: 7,
        [EXCEL_COLS.OPERATION]: 'SEW',
      },
    ]

    const result = exactAllocationExcelTeamMatcher.match(rows, teams)

    expect(result.pendingRows).toHaveLength(0)
    expect(result.resolvedTeamIdsByRowNumber.size).toBe(0)
  })

  it('marks unknown team as unresolved and groups by key', () => {
    const rows = [
      {
        __excelRowNumber: 5,
        [EXCEL_COLS.OPERATION]: 'SEW',
        [EXCEL_COLS.UNIT]: 'Tổ Không Tồn Tại',
      },
      {
        __excelRowNumber: 8,
        [EXCEL_COLS.OPERATION]: 'SEW',
        [EXCEL_COLS.UNIT]: 'Tổ Không Tồn Tại',
      },
    ]

    const result = exactAllocationExcelTeamMatcher.match(rows, teams)

    expect(result.resolvedTeamIdsByRowNumber.size).toBe(0)
    expect(result.pendingRows).toHaveLength(1)
    expect(result.pendingRows[0].status).toBe('unresolved')
    expect(result.pendingRows[0].rowNumbers).toEqual([5, 8])
    expect(result.pendingRows[0].excelValue).toBe('Tổ Không Tồn Tại')
  })

  it('does not match teams across different operations', () => {
    const rows = [
      {
        __excelRowNumber: 5,
        [EXCEL_COLS.OPERATION]: 'CUT',
        [EXCEL_COLS.UNIT]: 'Tổ May 1 - Xí nghiệp 1 - Công ty LGG',
      },
    ]

    const result = exactAllocationExcelTeamMatcher.match(rows, teams)

    expect(result.resolvedTeamIdsByRowNumber.size).toBe(0)
    expect(result.pendingRows).toHaveLength(1)
    expect(result.pendingRows[0].status).toBe('unresolved')
  })

  it('marks ambiguous when team name matches multiple teams in the same operation', () => {
    const duplicateTeams: TeamVm[] = [
      {
        id: 'team-a',
        name: 'Tổ Chung',
        operation: 'SEW',
        isActive: true,
        factoryName: 'Xí nghiệp 1',
        companyName: 'Công ty LGG',
      },
      {
        id: 'team-b',
        name: 'Tổ Chung',
        operation: 'SEW',
        isActive: true,
        factoryName: 'Xí nghiệp 2',
        companyName: 'Công ty LGG',
      },
    ]

    const rows = [
      {
        __excelRowNumber: 5,
        [EXCEL_COLS.OPERATION]: 'SEW',
        [EXCEL_COLS.UNIT]: 'Tổ Chung',
      },
    ]

    const result = exactAllocationExcelTeamMatcher.match(rows, duplicateTeams)

    expect(result.resolvedTeamIdsByRowNumber.size).toBe(0)
    expect(result.pendingRows).toHaveLength(1)
    expect(result.pendingRows[0].status).toBe('ambiguous')
  })
})
