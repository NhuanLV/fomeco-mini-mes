import { EXCEL_COLS } from '@/features/production/helpers/productionOrderExcel'
import {
  extractMetadata,
  extractRows,
  transformExcelToOpData,
} from '@/features/production/helpers/allocationExcelTransformer'
import type { TeamVm } from '@/features/production/types'
import { describe, expect, it } from 'vitest'

describe('transformExcelToOpData', () => {
  it('keeps planned dates from allocation rows', () => {
    const data = transformExcelToOpData(
      [
        {
          __excelRowNumber: 5,
          [EXCEL_COLS.OPERATION]: 'CUT',
          [EXCEL_COLS.PO]: 'PO-1',
          [EXCEL_COLS.PO_ID]: 'po-1',
          [EXCEL_COLS.COLOR]: 'Red',
          [EXCEL_COLS.TEAM]: 'Tổ cắt',
          [EXCEL_COLS.FACTORY]: 'XN 1',
          [EXCEL_COLS.COMPANY]: 'Công ty 1',
          [EXCEL_COLS.PLANNED_START_DATE]: '15/09/2026',
          [EXCEL_COLS.PLANNED_END_DATE]: '20/09/2026',
          S: 10,
        },
      ],
      ['S'],
      [team()],
      new Map([['po-1', { id: 'po-1' }]]),
    )

    expect(data.get('CUT')?.get('po-1|Red')?.get('team-1')?.meta).toMatchObject({
      plannedStartDate: '2026-09-15',
      plannedEndDate: '2026-09-20',
    })
  })

  it('keeps split POs separate even when their display codes match or change', () => {
    const rows = ['po-1', 'po-2'].map((id, index) => ({
      __excelRowNumber: index + 5,
      [EXCEL_COLS.PO_ID]: id,
      [EXCEL_COLS.PO]: 'OLD-SHARED-CODE',
      [EXCEL_COLS.OPERATION]: 'CUT',
      [EXCEL_COLS.COLOR]: 'Red',
      S: index + 10,
    }))
    const pos = [
      { id: 'po-1', code: 'RENAMED' },
      { id: 'po-2', code: 'RENAMED' },
    ]
    const data = transformExcelToOpData(rows, ['S'], [], new Map(pos.map((po) => [po.id, po])))

    expect(data.get('CUT')?.size).toBe(2)
    expect(data.get('CUT')?.get('po-1|Red')?.get('')?.qtys).toEqual({ S: 10 })
    expect(data.get('CUT')?.get('po-2|Red')?.get('')?.qtys).toEqual({ S: 11 })
  })

  it.each(['', 'outside-selected-pos'])('rejects missing or out-of-scope PO ID %s', (id) => {
    const row = {
      __excelRowNumber: 5,
      [EXCEL_COLS.PO_ID]: id,
      [EXCEL_COLS.PO]: 'PO-1',
      [EXCEL_COLS.OPERATION]: 'CUT',
      [EXCEL_COLS.COLOR]: 'Red',
      S: 10,
    }
    expect(() =>
      transformExcelToOpData([row], ['S'], [], new Map([['po-1', { id: 'po-1' }]])),
    ).toThrow(id ? 'không thuộc danh sách đang chọn' : 'Thiếu PO ID')
  })

  it('maps unit column to team accurately', () => {
    const data = transformExcelToOpData(
      [
        {
          __excelRowNumber: 5,
          [EXCEL_COLS.OPERATION]: 'CUT',
          [EXCEL_COLS.PO]: 'PO-1',
          [EXCEL_COLS.PO_ID]: 'po-1',
          [EXCEL_COLS.COLOR]: 'Red',
          [EXCEL_COLS.UNIT]: 'Tổ cắt - XN 1 - Công ty 1',
          S: 15,
        },
      ],
      ['S'],
      [team()],
      new Map([['po-1', { id: 'po-1' }]]),
    )

    expect(data.get('CUT')?.get('po-1|Red')?.get('team-1')?.qtys).toEqual({ S: 15 })
  })

  it('extracts metadata across multiple rows', () => {
    const rawRows = [
      ['LỆNH SẢN XUẤT'],
      ['Mã hàng:', 'STYLE-101', 'LỆNH SỐ:', 'LSX-001'],
      ['Khách hàng:', 'Customer Alpha', 'Ngày đồng bộ chuẩn bị sản xuất:', '15/09/2026'],
      ['Thương hiệu:', 'Brand Beta', 'Ngày vào chuyền:', '20/09/2026', 'Màu cỡ đầu tiên:', 'Red-M'],
      [],
      [
        EXCEL_COLS.PO,
        EXCEL_COLS.DESTINATION,
        EXCEL_COLS.COLOR,
        'S',
        EXCEL_COLS.TOTAL,
        EXCEL_COLS.OPERATION,
        EXCEL_COLS.CHECK_DATE,
        EXCEL_COLS.DELIVERY_DATE,
        EXCEL_COLS.UNIT,
        EXCEL_COLS.PO_ID,
      ],
    ]
    const meta = extractMetadata(rawRows)
    expect(meta.styleName).toBe('STYLE-101')
    expect(meta.customerName).toBe('Customer Alpha')
    expect(meta.brandName).toBe('Brand Beta')
    expect(meta.firstSku).toBe('Red-M')
  })

  it('carries forward both PO and destination for merged cells in rows', () => {
    const rawRows = [
      ['LỆNH SẢN XUẤT'],
      ['Mã hàng:', 'STYLE-101'],
      ['Khách hàng:', 'Customer Alpha'],
      ['Thương hiệu:', 'Brand Beta'],
      [],
      [
        EXCEL_COLS.PO,
        EXCEL_COLS.DESTINATION,
        EXCEL_COLS.COLOR,
        'S',
        EXCEL_COLS.TOTAL,
        EXCEL_COLS.OPERATION,
        EXCEL_COLS.CHECK_DATE,
        EXCEL_COLS.DELIVERY_DATE,
        EXCEL_COLS.UNIT,
        EXCEL_COLS.PO_ID,
      ],
      ['PO-01', 'US', 'Red', 10, 10, 'CUT', '01/09/2026', '10/09/2026', 'Tổ cắt', 'po-1'],
      ['', '', 'Blue', 15, 15, 'CUT', '01/09/2026', '10/09/2026', 'Tổ cắt', 'po-1'],
      ['PO-02', '', 'Green', 20, 20, 'CUT', '01/09/2026', '10/09/2026', 'Tổ cắt', 'po-2'],
    ]
    const result = extractRows(rawRows, ['S'])
    expect(result.rows[0]?.[EXCEL_COLS.PO]).toBe('PO-01')
    expect(result.rows[0]?.[EXCEL_COLS.DESTINATION]).toBe('US')
    expect(result.rows[1]?.[EXCEL_COLS.PO]).toBe('PO-01')
    expect(result.rows[1]?.[EXCEL_COLS.DESTINATION]).toBe('US')
    expect(result.rows[2]?.[EXCEL_COLS.PO]).toBe('PO-02')
    expect(result.rows[2]?.[EXCEL_COLS.DESTINATION]).toBe('US')
  })

  it('supports splitting one PO-color row into multiple rows for different teams (bẻ dòng)', () => {
    const team1: TeamVm = {
      id: 'team-1',
      name: 'Tổ May 1',
      operation: 'SEW',
      isActive: true,
      factoryName: 'XN 1',
      companyName: 'LGG',
    }
    const team2: TeamVm = {
      id: 'team-2',
      name: 'Tổ May 2',
      operation: 'SEW',
      isActive: true,
      factoryName: 'XN 1',
      companyName: 'LGG',
    }

    const rawRows = [
      ['LỆNH SẢN XUẤT'],
      ['Mã hàng:', 'STYLE-101'],
      ['Khách hàng:', 'Customer Alpha'],
      ['Thương hiệu:', 'Brand Beta'],
      [],
      [
        EXCEL_COLS.PO,
        EXCEL_COLS.DESTINATION,
        EXCEL_COLS.COLOR,
        'S',
        'M',
        EXCEL_COLS.TOTAL,
        EXCEL_COLS.OPERATION,
        EXCEL_COLS.CHECK_DATE,
        EXCEL_COLS.DELIVERY_DATE,
        EXCEL_COLS.UNIT,
        EXCEL_COLS.PO_ID,
      ],
      // Row 1: Tổ May 1 được giao 30 áo size S
      [
        'PO-01',
        'US',
        'Red',
        30,
        0,
        30,
        'SEW',
        '01/09/2026',
        '10/09/2026',
        'Tổ May 1 - XN 1 - LGG',
        'po-1',
      ],
      // Row 2: Bẻ dòng cho Tổ May 2 được giao 20 áo size S và 50 áo size M (bỏ trống PO và PO ID do chèn dòng dưới ô merge)
      ['', '', 'Red', 20, 50, 70, '', '', '', 'Tổ May 2 - XN 1 - LGG', ''],
    ]

    const parsed = extractRows(rawRows, ['S', 'M'])
    expect(parsed.rows).toHaveLength(2)
    expect(parsed.rows[1]?.[EXCEL_COLS.PO]).toBe('PO-01')
    expect(parsed.rows[1]?.[EXCEL_COLS.PO_ID]).toBe('po-1')
    expect(parsed.rows[1]?.[EXCEL_COLS.OPERATION]).toBe('SEW')

    const data = transformExcelToOpData(
      parsed.rows,
      parsed.sizeColumns,
      [team1, team2],
      new Map([['po-1', { id: 'po-1' }]]),
    )

    const sewOp = data.get('SEW')
    expect(sewOp).toBeDefined()
    const colorGroup = sewOp?.get('po-1|Red')
    expect(colorGroup).toBeDefined()
    // Cả 2 tổ đều được ghi nhận riêng biệt cho cùng 1 PO-color
    expect(colorGroup?.size).toBe(2)
    expect(colorGroup?.get('team-1')?.qtys).toEqual({ S: 30 })
    expect(colorGroup?.get('team-2')?.qtys).toEqual({ S: 20, M: 50 })
  })

  it('does not inherit check dates within a PO or across POs', () => {
    const { rows, sizeColumns } = extractRows(
      [
        [
          EXCEL_COLS.PO,
          EXCEL_COLS.PO_ID,
          EXCEL_COLS.COLOR,
          'S',
          EXCEL_COLS.TOTAL,
          EXCEL_COLS.OPERATION,
          EXCEL_COLS.UNIT,
          EXCEL_COLS.CHECK_DATE,
          EXCEL_COLS.DELIVERY_DATE,
        ],
        ['PO-1', 'po-1', 'Red', 10, 10, 'CUT', '', '01/09/2026', ''],
        ['', '', 'Blue', 10, 10, '', '', '', ''],
        ['PO-2', 'po-2', 'Red', 10, 10, 'CUT', '', '', ''],
      ],
      ['S'],
    )
    const data = transformExcelToOpData(
      rows,
      sizeColumns,
      [],
      new Map(['po-1', 'po-2'].map((id) => [id, { id }])),
    )

    expect(data.get('CUT')?.get('po-1|Red')?.get('')?.meta.checkDate).toBe('2026-09-01')
    expect(data.get('CUT')?.get('po-1|Blue')?.get('')?.meta.checkDate).toBeUndefined()
    expect(data.get('CUT')?.get('po-2|Red')?.get('')?.meta.checkDate).toBeUndefined()
  })

  it('asks for a new template when the file has no PO ID column', () => {
    expect(() =>
      extractRows([[], [], [], [], [], [EXCEL_COLS.PO, 'S', EXCEL_COLS.TOTAL]], ['S']),
    ).toThrow('Vui lòng tải lại mẫu phân bổ mới')
  })
})

function team(): TeamVm {
  return {
    id: 'team-1',
    name: 'Tổ cắt',
    operation: 'CUT',
    isActive: true,
    factoryName: 'XN 1',
    companyName: 'Công ty 1',
  }
}
