import type { AllocationMatrix, SkuKey } from '../types'

export function buildSubTotalMap(masterMatrix: AllocationMatrix): Record<SkuKey, number> {
  const map: Record<SkuKey, number> = {}
  for (const [skuKey, qtys] of Object.entries(masterMatrix.qtyMap)) {
    map[skuKey] = qtys.reduce((sum, v) => sum + v, 0)
  }
  return map
}

export function buildDemandMaps(
  matrices: AllocationMatrix[],
  subTotalMap: Record<SkuKey, number>,
): Record<SkuKey, number[]>[] {
  return matrices.map((matrix, idx) => {
    const sourceTotal = idx === 0 ? matrix.totalMap : subTotalMap
    const dMap: Record<SkuKey, number[]> = {}
    for (const [skuKey, qtys] of Object.entries(matrix.qtyMap)) {
      const totalForSku = sourceTotal[skuKey] || 0
      const allRowsSum = qtys.reduce((sum, v) => sum + v, 0)
      dMap[skuKey] = qtys.map((qty) => Math.max(0, totalForSku - (allRowsSum - qty)))
    }
    return dMap
  })
}

export function buildSummaryMatrix(
  masterMatrix: AllocationMatrix,
): { color: string; data: Record<string, number> }[] {
  const summary = new Map<string, Record<string, number>>()
  for (const [skuKey, qtys] of Object.entries(masterMatrix.qtyMap)) {
    const [, colorName, size] = skuKey.split('|')
    if (!summary.has(colorName)) summary.set(colorName, {})
    const row = summary.get(colorName)!
    row[size] = (row[size] || 0) + qtys.reduce((sum, v) => sum + v, 0)
  }
  return Array.from(summary.entries())
    .map(([color, data]) => ({ color, data }))
    .sort((a, b) => a.color.localeCompare(b.color))
}
