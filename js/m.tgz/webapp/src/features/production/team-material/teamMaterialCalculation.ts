import type { BillOfMaterial, TeamAssignmentDetailVm, TeamBomVm } from '@/api'
import Big from 'big.js'
import { computed, type Ref } from 'vue'

export type TeamMaterialProduct = {
  poId: string
  destination: string
  color: string
  size: string
  qty: number
}

export type TeamMaterialRequirement = {
  poId: string
  articleName: string
  articleCode?: string | null
  alternativeName?: string | null
  isRequired?: boolean
  category: string
  uom: string
  productColor: string
  productSize: string
  materialColor: string
  materialSize: string
  qty: number
  lineType?: 'NPL' | 'BTP'
  sourceOperation?: string
}

export type TeamMaterialComparison = {
  articleName: string
  articleCode?: string | null
  alternativeName?: string | null
  materialColor: string
  bySizeQty: number
  byWfxSizeQty?: number | null
  byColorQty: number
  byCutterQty: number
  uom: string
}

type TeamMaterialRequirementRow = Omit<TeamMaterialRequirement, 'poId'>

type CalculationMode = 'size' | 'color' | 'cutting-color'

type MaterialLine = {
  articleName: string
  articleCode?: string | null
  alternativeName?: string | null
  isRequired?: boolean
  category: string
  uom: string
  destinationCodes: string[]
  sizes: Array<{
    productSize: string
    materialSize: string
    consumption: number
  }>
  colors: Array<{
    productColor: string
    materialColor: string
    consumption: number | null
  }>
}

export function calculateTeamMaterialRequirements(
  products: TeamMaterialProduct[],
  bomData: TeamBomVm,
  mode: CalculationMode,
): TeamMaterialRequirement[] {
  const lines = toMaterialLines(bomData, mode === 'cutting-color')
  return mode === 'size' ? calculateBySize(products, lines) : calculateByColor(products, lines)
}

export function calculateTeamMaterial(assignment: TeamAssignmentDetailVm, bomData: TeamBomVm) {
  const products = toProducts(assignment)
  const sizeEntries = calculateTeamMaterialRequirements(products, bomData, 'size')
  const colorEntries = calculateTeamMaterialRequirements(products, bomData, 'color')
  const cutterEntries = calculateTeamMaterialRequirements(products, bomData, 'cutting-color')
  const sizeRequirements = groupByMaterialColorSize(sizeEntries)
  const colorRequirements = groupByMaterialColorSize(colorEntries)
  const comparisons = buildComparisons(sizeEntries, colorEntries, cutterEntries)
  const totalComparison = comparisons.reduce(
    (total, comparison) => ({
      bySizeQty: new Big(total.bySizeQty).plus(comparison.bySizeQty).toNumber(),
      byColorQty: new Big(total.byColorQty).plus(comparison.byColorQty).toNumber(),
      byCutterQty: new Big(total.byCutterQty).plus(comparison.byCutterQty).toNumber(),
    }),
    { bySizeQty: 0, byColorQty: 0, byCutterQty: 0 },
  )
  const uoms = [...new Set(comparisons.map((comparison) => comparison.uom))]

  return {
    sizeRequirements,
    colorRequirements,
    comparisons,
    totalComparison,
    comparisonUom: uoms.length === 1 ? uoms[0] : '',
  }
}

export function compareTeamMaterialWithWfx(
  assignment: TeamAssignmentDetailVm,
  bom: TeamBomVm,
  wfx: BillOfMaterial,
) {
  const missingLines: string[] = []
  const baseline: TeamBomVm = {
    ...bom,
    lines: bom.lines.map((line) => {
      const matches = wfx.materials.filter((source) =>
        line.wfxBomLineId
          ? source.wfxBomLineId === line.wfxBomLineId
          : source.material.name === line.articleName &&
            source.material.category === line.category &&
            source.material.uom === line.uom,
      )
      const source = matches.length === 1 ? matches[0] : undefined
      if (!source || source.material.uom !== line.uom) {
        missingLines.push(line.id)
        return { ...line, sizes: [], colors: [] }
      }
      const operationQty = source.usedForOperations.find(
        (usage) => usage.operation === assignment.operation,
      )?.consumption
      return {
        ...line,
        sizes: source.sizeDeps.map((size) => ({
          ...size,
          consumption: size.consumption === 0 ? (operationQty ?? 0) : size.consumption,
        })),
        colors: source.colorDeps,
        cuttingColors: [],
        destinationCodes: source.usedForDestinations,
      }
    }),
  }
  const currentRows = calculateTeamMaterial(assignment, bom).comparisons
  const wfxRows = calculateTeamMaterial(assignment, baseline).comparisons
  const key = (row: TeamMaterialComparison) => `${row.articleName}::${row.materialColor}`
  const currentByKey = new Map(currentRows.map((row) => [key(row), row]))
  const wfxByKey = new Map(wfxRows.map((row) => [key(row), row.bySizeQty]))
  const missingNames = new Set(
    bom.lines.filter((line) => missingLines.includes(line.id)).map((line) => line.articleName),
  )
  for (const row of wfxRows) {
    if (!currentByKey.has(key(row))) {
      currentByKey.set(key(row), { ...row, bySizeQty: 0, byColorQty: 0, byCutterQty: 0 })
    }
  }
  return {
    missingLines,
    comparisons: [...currentByKey.values()].map((row) => ({
      ...row,
      byWfxSizeQty: missingNames.has(row.articleName) ? null : (wfxByKey.get(key(row)) ?? 0),
    })),
  }
}

export function useTeamMaterialCalculation(
  assignment: Ref<TeamAssignmentDetailVm | undefined>,
  bomData: Ref<TeamBomVm | undefined>,
) {
  const calculation = computed(() =>
    assignment.value && bomData.value
      ? calculateTeamMaterial(assignment.value, bomData.value)
      : emptyCalculation(),
  )
  return {
    sizeRequirements: computed(() => calculation.value.sizeRequirements),
    colorRequirements: computed(() => calculation.value.colorRequirements),
    comparisons: computed(() => calculation.value.comparisons),
    totalComparison: computed(() => calculation.value.totalComparison),
    comparisonUom: computed(() => calculation.value.comparisonUom),
  }
}

function toProducts(assignment: TeamAssignmentDetailVm): TeamMaterialProduct[] {
  return assignment.allocations.map((allocation) => ({
    poId: allocation.purchaseOrderId,
    destination: assignment.purchaseOrderDestinations[allocation.purchaseOrderId] ?? '',
    color: allocation.color,
    size: allocation.size,
    qty: allocation.quantity,
  }))
}

function toMaterialLines(bomData: TeamBomVm, useCuttingColors: boolean): MaterialLine[] {
  return bomData.lines.map((line) => ({
    articleName: line.articleName,
    articleCode: line.articleCode,
    alternativeName: line.alternativeName,
    isRequired: line.isRequired,
    category: line.category,
    uom: line.uom,
    destinationCodes: line.destinationCodes,
    sizes: line.sizes.map((size) => ({
      productSize: size.productSize,
      materialSize: size.materialSize,
      consumption: size.consumption,
    })),
    colors: (useCuttingColors ? line.cuttingColors : line.colors).map((color) => ({
      productColor: color.productColor,
      materialColor: color.materialColor,
      consumption: color.consumption ?? null,
    })),
  }))
}

function calculateBySize(products: TeamMaterialProduct[], lines: MaterialLine[]) {
  const result: TeamMaterialRequirement[] = []
  for (const product of products) {
    for (const line of applicableLines(product, lines)) {
      const colors = line.colors.filter((color) => color.productColor === product.color)
      const sizes = line.sizes.filter((size) => size.productSize === product.size)
      for (const color of colors) {
        for (const size of sizes) {
          result.push(
            requirement(
              product,
              line,
              color.materialColor,
              size.materialSize,
              new Big(size.consumption).times(product.qty).toNumber(),
            ),
          )
        }
      }
    }
  }
  return result
}

function calculateByColor(products: TeamMaterialProduct[], lines: MaterialLine[]) {
  const result: TeamMaterialRequirement[] = []
  for (const product of products) {
    for (const line of applicableLines(product, lines)) {
      const colors = line.colors.filter(
        (color) => color.productColor.trim() === product.color.trim(),
      )
      const sizes = line.sizes.filter((size) => size.productSize === product.size)
      for (const color of colors) {
        for (const size of sizes) {
          result.push(
            requirement(
              product,
              line,
              color.materialColor,
              size.materialSize,
              new Big(color.consumption ?? 0).times(product.qty).toNumber(),
            ),
          )
        }
      }
    }
  }
  return result
}

function applicableLines(product: TeamMaterialProduct, lines: MaterialLine[]) {
  return lines.filter(
    (line) =>
      line.destinationCodes.length === 0 || line.destinationCodes.includes(product.destination),
  )
}

function requirement(
  product: TeamMaterialProduct,
  line: MaterialLine,
  materialColor: string,
  materialSize: string,
  qty: number,
): TeamMaterialRequirement {
  return {
    poId: product.poId,
    articleName: line.articleName,
    articleCode: line.articleCode,
    alternativeName: line.alternativeName,
    isRequired: line.isRequired,
    category: line.category,
    uom: line.uom,
    productColor: product.color,
    productSize: product.size,
    materialColor,
    materialSize,
    qty,
  }
}

function groupByMaterialColorSize(
  entries: TeamMaterialRequirement[],
): TeamMaterialRequirementRow[] {
  const grouped = new Map<string, TeamMaterialRequirementRow>()
  for (const entry of entries) {
    const key = [
      entry.articleName,
      entry.productColor,
      entry.productSize,
      entry.materialColor,
      entry.materialSize,
    ].join('::')
    const current = grouped.get(key)
    if (current) {
      current.qty = new Big(current.qty).plus(entry.qty).toNumber()
    } else {
      const { poId: _poId, ...row } = entry
      grouped.set(key, row)
    }
  }
  return [...grouped.values()]
}

function buildComparisons(
  sizeEntries: TeamMaterialRequirement[],
  colorEntries: TeamMaterialRequirement[],
  cutterEntries: TeamMaterialRequirement[],
) {
  const comparisons = new Map<string, TeamMaterialComparison>()
  addComparisonValues(comparisons, groupByMaterialColor(sizeEntries), 'bySizeQty')
  addComparisonValues(comparisons, groupByMaterialColor(colorEntries), 'byColorQty')
  addComparisonValues(comparisons, groupByMaterialColor(cutterEntries), 'byCutterQty')
  return [...comparisons.values()]
}

function groupByMaterialColor(entries: TeamMaterialRequirement[]) {
  const grouped = new Map<
    string,
    {
      articleName: string
      articleCode?: string | null
      alternativeName?: string | null
      materialColor: string
      uom: string
      qty: number
    }
  >()
  for (const entry of entries) {
    const key = `${entry.articleName}::${entry.materialColor}`
    const current = grouped.get(key)
    if (current) {
      current.qty = new Big(current.qty).plus(entry.qty).toNumber()
    } else {
      grouped.set(key, {
        articleName: entry.articleName,
        articleCode: entry.articleCode,
        alternativeName: entry.alternativeName,
        materialColor: entry.materialColor,
        uom: entry.uom,
        qty: entry.qty,
      })
    }
  }
  return [...grouped.values()]
}

function addComparisonValues(
  comparisons: Map<string, TeamMaterialComparison>,
  values: ReturnType<typeof groupByMaterialColor>,
  field: 'bySizeQty' | 'byColorQty' | 'byCutterQty',
) {
  for (const value of values) {
    const key = `${value.articleName}::${value.materialColor}`
    const comparison = comparisons.get(key) ?? {
      articleName: value.articleName,
      articleCode: value.articleCode,
      alternativeName: value.alternativeName,
      materialColor: value.materialColor,
      bySizeQty: 0,
      byColorQty: 0,
      byCutterQty: 0,
      uom: value.uom,
    }
    comparison[field] = value.qty
    comparisons.set(key, comparison)
  }
}

function emptyCalculation() {
  return {
    sizeRequirements: [] as TeamMaterialRequirementRow[],
    colorRequirements: [] as TeamMaterialRequirementRow[],
    comparisons: [] as TeamMaterialComparison[],
    totalComparison: {
      bySizeQty: 0,
      byColorQty: 0,
      byCutterQty: 0,
    },
    comparisonUom: '',
  }
}
