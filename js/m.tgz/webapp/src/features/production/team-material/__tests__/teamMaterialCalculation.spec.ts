import type { TeamAssignmentDetailVm, TeamBomVm } from '@/api'
import {
  calculateTeamMaterialRequirements,
  compareTeamMaterialWithWfx,
  useTeamMaterialCalculation,
} from '@/features/production/team-material/teamMaterialCalculation'
import { describe, expect, it } from 'vitest'
import { ref } from 'vue'

describe('Team Material calculation', () => {
  it('compares each material color against WFX size consumption using assigned quantities', () => {
    const bom = makeBom()
    const assignment = makeAssignment()
    bom.lines[0].wfxBomLineId = 'wfx-line-1'
    bom.lines[0].colors.push({ productColor: 'Blue', materialColor: 'B-01', consumption: 0 })
    assignment.allocations.push({ ...assignment.allocations[0], color: 'Blue', quantity: 5 })
    const result = compareTeamMaterialWithWfx(assignment, bom, {
      buyerOrderId: 'bo-1',
      materials: [
        {
          wfxBomLineId: 'wfx-line-1',
          material: { name: 'Fabric', category: 'FABRIC', uom: 'M', isRequired: true },
          sizeDeps: [{ productSize: 'S', materialSize: 'S-MAT', consumption: 0.1 }],
          colorDeps: [
            { productColor: 'Red', materialColor: 'R-01' },
            { productColor: 'Blue', materialColor: 'B-01' },
          ],
          usedForOperations: [],
          usedForDestinations: ['VN'],
        },
      ],
    })
    expect(result.missingLines).toEqual([])
    expect(result.comparisons).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ materialColor: 'R-01', byWfxSizeQty: 0.5, byColorQty: 1 }),
        expect.objectContaining({ materialColor: 'B-01', byWfxSizeQty: 0.5, byColorQty: 0 }),
      ]),
    )
    // Red exceeds even though the sum across colors equals WFX.
    expect(
      result.comparisons
        .filter((row) => row.byColorQty > (row.byWfxSizeQty ?? 0))
        .map((row) => row.materialColor),
    ).toEqual(['R-01'])
  })

  it('reports missing WFX material instead of treating it as a zero baseline', () => {
    const result = compareTeamMaterialWithWfx(makeAssignment(), makeBom(), {
      buyerOrderId: 'bo-1',
      materials: [],
    })
    expect(result.missingLines).toEqual(['line-1'])
    expect(result.comparisons.every((row) => row.byWfxSizeQty === null)).toBe(true)
  })

  it('calculates size requirements with destination filtering and exact decimals', () => {
    expect(
      calculateTeamMaterialRequirements(
        [
          {
            poId: 'po-1',
            destination: 'VN',
            color: 'Red',
            size: 'S',
            qty: 3,
          },
          {
            poId: 'po-2',
            destination: 'US',
            color: 'Red',
            size: 'S',
            qty: 2,
          },
        ],
        makeBom(),
        'size',
      ),
    ).toEqual([
      expect.objectContaining({
        poId: 'po-1',
        articleName: 'Fabric',
        materialColor: 'R-01',
        materialSize: 'S-MAT',
        qty: 0.3,
      }),
    ])
  })

  it('uses normal and cutting color consumption without exposing adapters', () => {
    const products = [
      {
        poId: 'po-1',
        destination: 'VN',
        color: ' Red ',
        size: 'S',
        qty: 3,
      },
    ]

    expect(calculateTeamMaterialRequirements(products, makeBom(), 'color')).toEqual([
      expect.objectContaining({ materialColor: 'R-01', qty: 0.6 }),
    ])
    expect(calculateTeamMaterialRequirements(products, makeBom(), 'cutting-color')).toEqual([
      expect.objectContaining({ materialColor: 'CUT-R', qty: 0.9 }),
    ])
  })

  it('returns zero for nullable color consumption', () => {
    const bom = makeBom()
    bom.lines[0].colors[0].consumption = null

    expect(
      calculateTeamMaterialRequirements(
        [
          {
            poId: 'po-1',
            destination: 'VN',
            color: 'Red',
            size: 'S',
            qty: 5,
          },
        ],
        bom,
        'color',
      )[0].qty,
    ).toBe(0)
  })

  it('aggregates assignment requirements and comparison totals with Big decimals', () => {
    const result = useTeamMaterialCalculation(ref(makeAssignment()), ref(makeBom()))

    expect(result.sizeRequirements.value).toEqual([
      expect.objectContaining({
        articleName: 'Fabric',
        materialColor: 'R-01',
        materialSize: 'S-MAT',
        qty: 0.5,
      }),
    ])
    expect(result.colorRequirements.value).toEqual([
      expect.objectContaining({ materialColor: 'R-01', qty: 1 }),
    ])
    expect(result.comparisons.value).toEqual([
      {
        articleName: 'Fabric',
        alternativeName: 'Vải chính',
        materialColor: 'R-01',
        bySizeQty: 0.5,
        byColorQty: 1,
        byCutterQty: 0,
        uom: 'M',
      },
      {
        articleName: 'Fabric',
        alternativeName: 'Vải chính',
        materialColor: 'CUT-R',
        bySizeQty: 0,
        byColorQty: 0,
        byCutterQty: 1.5,
        uom: 'M',
      },
    ])
    expect(result.totalComparison.value).toEqual({
      bySizeQty: 0.5,
      byColorQty: 1,
      byCutterQty: 1.5,
    })
    expect(result.comparisonUom.value).toBe('M')
  })
})

function makeBom(): TeamBomVm {
  return {
    teamAssignmentId: 'assignment-1',
    lines: [
      {
        id: 'line-1',
        articleName: 'Fabric',
        alternativeName: 'Vải chính',
        isRequired: true,
        category: 'FABRIC',
        uom: 'M',
        destinationCodes: ['VN'],
        sizes: [
          {
            productSize: 'S',
            materialSize: 'S-MAT',
            consumption: 0.1,
          },
        ],
        colors: [
          {
            productColor: 'Red',
            materialColor: 'R-01',
            consumption: 0.2,
          },
        ],
        cuttingColors: [
          {
            productColor: 'Red',
            materialColor: 'CUT-R',
            consumption: 0.3,
          },
        ],
      },
    ],
  }
}

function makeAssignment(): TeamAssignmentDetailVm {
  return {
    productionOrderStatus: 'IN_PROGRESS',
    id: 'assignment-1',
    productionOrderId: 'lsx-1',
    productionCode: 'LSX-1',
    styleName: 'STYLE',
    styleColorOrder: ['Red'],
    styleSizeOrder: ['S'],
    factoryName: 'Factory',
    companyName: 'Company',
    companyId: 'company-1',
    teamId: 'team-1',
    teamName: 'Team',
    operation: 'SEW-1',
    allocations: [
      {
        purchaseOrderId: 'po-1',
        color: 'Red',
        size: 'S',
        quantity: 3,
        notes: [],
      },
      {
        purchaseOrderId: 'po-2',
        color: 'Red',
        size: 'S',
        quantity: 2,
        notes: [],
      },
    ],
    outputReportTotals: [],
    inputReportTotals: [],
    metadataRows: [],
    purchaseOrderTypes: {},
    purchaseOrderCodes: { 'po-1': 'PO-1', 'po-2': 'PO-2' },
    purchaseOrderDestinations: { 'po-1': 'VN', 'po-2': 'VN' },
    assignedAt: '2026-07-26',
    reconciliationStatus: 'NORMAL',
  }
}
