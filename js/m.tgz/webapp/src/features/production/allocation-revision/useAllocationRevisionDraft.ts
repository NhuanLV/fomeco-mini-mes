import type { BuyerOrderDetailVm, ProductionOrderVm, TeamAssignmentVm } from '@/api'
import { computed, shallowRef, watch } from 'vue'
import {
  buildActivePlanByKey,
  buildAllAllocationKeys,
  buildAllReportKeys,
  buildAssignmentsByOperation,
  buildBaselineTotalsByKey,
  buildCurrentByOpTeamKey,
  buildCurrentWfxKeys,
  buildLabelForKey,
  buildManualRows,
  buildMaxReportedByColorSize,
  buildPoInfoById,
  buildRemainingByKey,
  buildRevisionModes,
  buildStandardRows,
  buildTargetByKey,
  buildValidationMessages,
  buildAllocationsFromPlan,
  buildRowsToAllocations,
  collectAllSizes,
  collectPoColorKeys,
  rowTotal as calcRowTotal,
  type AllocationCommand,
  type RevisionGridRow,
  type RevisionMode,
} from './allocationRevisionDraft.internal'

export type { RevisionGridRow, RevisionMode, TeamOption } from './allocationRevisionDraft.internal'

export function useAllocationRevisionDraft(options: {
  visible: () => boolean
  order: () => ProductionOrderVm
  buyerOrder: () => BuyerOrderDetailVm | null | undefined
}) {
  const draftRowsByOp = shallowRef<Record<string, RevisionGridRow[]>>({})
  const initialDraftRowsByOp = shallowRef<Record<string, RevisionGridRow[]>>({})
  const activeTab = shallowRef('')
  const initialSnapshot = shallowRef('')

  const assignmentsByOperation = computed(() =>
    buildAssignmentsByOperation(options.order().teamAssignments),
  )

  const modes = computed<RevisionMode[]>(() => buildRevisionModes(assignmentsByOperation.value))

  const baselineTotalsByKey = computed(() => buildBaselineTotalsByKey(assignmentsByOperation.value))
  const poInfoById = computed(() => buildPoInfoById(options.order(), options.buyerOrder()))
  const existingPoTypes = computed(
    () =>
      new Set(
        options
          .order()
          .teamAssignments.flatMap((assignment) =>
            assignment.allocations.map(
              (allocation) =>
                poInfoById.value[allocation.purchaseOrderId]?.purchaseOrderType ?? 'REGULAR',
            ),
          ),
      ),
  )
  const eligibleBuyerOrder = computed(() => {
    const buyerOrder = options.buyerOrder()
    return buyerOrder
      ? {
          ...buyerOrder,
          purchaseOrders: buyerOrder.purchaseOrders.filter((po) =>
            existingPoTypes.value.has(po.type ?? 'REGULAR'),
          ),
        }
      : buyerOrder
  })

  const remainingByKey = computed(() => buildRemainingByKey(eligibleBuyerOrder.value))

  const currentWfxKeys = computed(() => buildCurrentWfxKeys(eligibleBuyerOrder.value))

  const allSizes = computed(() => collectAllSizes(options.order(), eligibleBuyerOrder.value))

  const allAllocationKeys = computed(() => buildAllAllocationKeys(options.order().teamAssignments))

  const allReportKeys = computed(() => buildAllReportKeys(options.order().teamAssignments))

  const targetByKey = computed(() =>
    buildTargetByKey({
      baseline: baselineTotalsByKey.value,
      remaining: remainingByKey.value,
      allAllocationKeys: allAllocationKeys.value,
      allReportKeys: allReportKeys.value,
    }),
  )

  const poColorKeys = computed(() =>
    collectPoColorKeys({
      targetByKey: targetByKey.value,
      teamAssignments: options.order().teamAssignments,
      poInfoById: poInfoById.value,
    }),
  )

  const isDirty = computed(
    () =>
      initialSnapshot.value !== '' && serializeDraft(draftRowsByOp.value) !== initialSnapshot.value,
  )

  const activePlanByKey = computed(() =>
    buildActivePlanByKey({
      modes: modes.value,
      draftRowsByOp: draftRowsByOp.value,
      allSizes: allSizes.value,
    }),
  )

  const overAllocatedKeys = computed(() =>
    [...new Set([...Object.keys(activePlanByKey.value), ...Object.keys(targetByKey.value)])].filter(
      (key) => (activePlanByKey.value[key] ?? 0) > (targetByKey.value[key] ?? 0),
    ),
  )
  const overAllocatedMessages = computed(() =>
    overAllocatedKeys.value.map((key) => {
      const allocated = activePlanByKey.value[key] ?? 0
      const limit = targetByKey.value[key] ?? 0
      return `${buildLabelForKey(key, poInfoById.value)}: phân bổ ${allocated} vượt mức BO ${limit} (vượt ${allocated - limit})`
    }),
  )

  const maxReportedByColorSize = computed(() =>
    buildMaxReportedByColorSize(options.order().teamAssignments),
  )

  const validationMessages = computed(() => {
    const messages = buildValidationMessages({
      draftRowsByOp: draftRowsByOp.value,
      modes: modes.value,
      allSizes: allSizes.value,
      targetByKey: targetByKey.value,
      baselineByKey: baselineTotalsByKey.value,
      currentWfxKeys: currentWfxKeys.value,
      activePlanByKey: activePlanByKey.value,
      labelForKey: (key) => buildLabelForKey(key, poInfoById.value),
      maxReportedByColorSize: maxReportedByColorSize.value,
      order: options.order(),
      allocationsForAssignment,
      poInfoById: poInfoById.value,
    })
    for (const type of existingPoTypes.value) {
      const hasAllocation = Object.entries(activePlanByKey.value).some(
        ([key, quantity]) =>
          quantity > 0 &&
          (poInfoById.value[key.split('|')[0]!]?.purchaseOrderType ?? 'REGULAR') === type,
      )
      if (!hasAllocation)
        messages.push(
          type === 'REGULAR'
            ? 'PO hàng thường phải còn phân bổ lớn hơn 0'
            : 'PO hàng dương phải còn phân bổ lớn hơn 0',
        )
    }
    return messages
  })

  watch(
    () => [options.visible(), options.order(), options.buyerOrder()] as const,
    () => {
      if (!options.visible() || !options.buyerOrder()) return
      rebuildDraft()
      activeTab.value = modes.value[0]?.opName ?? ''
    },
    { immediate: true },
  )

  function rebuildDraft() {
    const next: Record<string, RevisionGridRow[]> = {}
    for (const mode of modes.value) {
      next[mode.opName] =
        mode.kind === 'all-single'
          ? buildStandardRows({
              poColorKeys: poColorKeys.value,
              allSizes: allSizes.value,
              targetByKey: targetByKey.value,
              poInfoById: poInfoById.value,
              baseline: baselineTotalsByKey.value,
              currentAllocations: (assignmentsByOperation.value[0]?.[1] ?? []).flatMap(
                (assignment) => assignment.allocations,
              ),
            })
          : buildManualRows({
              opName: mode.opName,
              teams: mode.teams,
              teamAssignments: options
                .order()
                .teamAssignments.filter((assignment) => assignment.operation === mode.opName),
              poColorKeys: poColorKeys.value,
              allSizes: allSizes.value,
              targetByKey: targetByKey.value,
              poInfoById: poInfoById.value,
              currentByOpTeamKey: buildCurrentByOpTeamKey(
                options.order().teamAssignments,
                mode.opName,
              ),
            })
    }
    initialDraftRowsByOp.value = next
    draftRowsByOp.value = next
    initialSnapshot.value = serializeDraft(next)
  }

  function updateRowData(opName: string, rowIndex: number, prop: string, value: unknown) {
    const rows = draftRowsByOp.value[opName] ?? []
    const currentRow = rows[rowIndex]
    if (!currentRow) return

    const row: RevisionGridRow = { ...currentRow }

    if (allSizes.value.includes(prop) && currentRow[prop] !== null) {
      const demand = Number(currentRow[`${prop}_demand`] ?? 0)
      const allocatedByOtherRows = rows.reduce(
        (total, item, index) =>
          index !== rowIndex && item.poId === row.poId && item.color === row.color
            ? total + Number(item[prop] ?? 0)
            : total,
        0,
      )
      row[prop] = Math.min(
        Math.max(0, Number.parseInt(String(value), 10) || 0),
        Math.max(0, demand - allocatedByOtherRows),
      )
      row.total = calcRowTotal(row, allSizes.value)
    } else if (prop === 'teamId') {
      const teamId = String(value ?? '')
      const option = row.teamOptions?.find((item) => item.value === teamId)
      row.teamId = teamId
      row.teamName = option?.label ?? ''
    } else if (prop === 'deliveryDate' || prop === 'checkDate') {
      row[prop] = String(value ?? '')
    } else if (prop === 'noteText') {
      const noteText = String(value ?? '')
      row.noteText = noteText
      row.notes = noteText
        .split('|')
        .map((note: string) => note.trim())
        .filter(Boolean)
    }

    draftRowsByOp.value = {
      ...draftRowsByOp.value,
      [opName]: rows.map((item, index) => (index === rowIndex ? row : item)),
    }
  }

  function createPayload() {
    if (validationMessages.value.length > 0) return null
    return { teamAssignments: options.order().teamAssignments.map(toCommand) }
  }

  function quickFillAll() {
    const next: Record<string, RevisionGridRow[]> = {}
    for (const mode of modes.value) {
      const rows = (draftRowsByOp.value[mode.opName] ?? []).map((row) => ({ ...row }))
      const firstRowByPoColor = new Map<string, number>()
      rows.forEach((row, index) => {
        const key = `${row.poId}|${row.color}`
        if (!firstRowByPoColor.has(key)) firstRowByPoColor.set(key, index)
      })
      rows.forEach((row, index) => {
        const firstIndex = firstRowByPoColor.get(`${row.poId}|${row.color}`)
        for (const size of allSizes.value) {
          if (row[size] === null) continue
          const key = `${row.poId}|${row.color}|${size}`
          row[size] = index === firstIndex ? Math.max(0, targetByKey.value[key] ?? 0) : 0
        }
        row.total = calcRowTotal(row, allSizes.value)
      })
      next[mode.opName] = rows
    }
    draftRowsByOp.value = next
  }

  function splitRow(opName: string, row: RevisionGridRow) {
    const rows = draftRowsByOp.value[opName] ?? []
    let lastIndex = -1
    rows.forEach((item, index) => {
      if (item.poId === row.poId && item.color === row.color) lastIndex = index
    })
    if (lastIndex < 0) return
    const newRow: RevisionGridRow = {
      ...row,
      id: `${opName}|${row.poId}|${row.color}|${crypto.randomUUID()}`,
      teamId: null,
      teamName: '',
      notes: [],
      noteText: '',
      total: 0,
    }
    for (const size of allSizes.value) {
      if (newRow[size] !== null) newRow[size] = 0
    }
    const next = [...rows]
    next.splice(lastIndex + 1, 0, newRow)
    draftRowsByOp.value = { ...draftRowsByOp.value, [opName]: reindexRows(next) }
  }

  function deleteRow(opName: string, row: RevisionGridRow) {
    const rows = draftRowsByOp.value[opName] ?? []
    const group = rows.filter((item) => item.poId === row.poId && item.color === row.color)
    if (group.length <= 1) return
    draftRowsByOp.value = {
      ...draftRowsByOp.value,
      [opName]: reindexRows(rows.filter((item) => item.id !== row.id)),
    }
  }

  function replaceDraft(rowsByOperation: Record<string, RevisionGridRow[]>) {
    draftRowsByOp.value = Object.fromEntries(
      modes.value.map((mode) => [mode.opName, reindexRows(rowsByOperation[mode.opName] ?? [])]),
    )
  }

  function allocationsForAssignment(assignment: TeamAssignmentVm) {
    const mode = modes.value.find(
      (item) => item.kind === 'manual' && item.opName === assignment.operation,
    )
    if (mode?.kind === 'manual') {
      const rows = (draftRowsByOp.value[mode.opName] ?? []).filter(
        (row) => row.teamId === assignment.teamId,
      )
      return buildRowsToAllocations({
        rows,
        currentAllocations: assignment.allocations,
        allSizes: allSizes.value,
        poInfoById: poInfoById.value,
      })
    }

    if (modes.value[0]?.kind === 'all-single') {
      return buildRowsToAllocations({
        rows: draftRowsByOp.value.__standard__ ?? [],
        currentAllocations: assignment.allocations,
        allSizes: allSizes.value,
        poInfoById: poInfoById.value,
        initialRows: initialDraftRowsByOp.value.__standard__,
      })
    }

    return buildAllocationsFromPlan({
      plan: activePlanByKey.value,
      currentAllocations: assignment.allocations,
      poInfoById: poInfoById.value,
    })
  }

  function toCommand(assignment: TeamAssignmentVm): AllocationCommand {
    return {
      teamAssignmentId: assignment.id,
      allocations: allocationsForAssignment(assignment),
    }
  }

  return {
    draftRowsByOp,
    activeTab,
    assignmentsByOperation,
    allSizes,
    modes,
    validationMessages,
    updateRowData,
    createPayload,
    quickFillAll,
    splitRow,
    deleteRow,
    replaceDraft,
    overAllocatedKeys,
    overAllocatedMessages,
    isDirty,
  }
}

function serializeDraft(draft: Record<string, RevisionGridRow[]>) {
  return JSON.stringify(draft)
}

function reindexRows(rows: RevisionGridRow[]) {
  const counters = new Map<string, number>()
  return rows.map((row) => {
    const key = `${row.poId}|${row.color}`
    const rowIndex = counters.get(key) ?? 0
    counters.set(key, rowIndex + 1)
    return { ...row, rowIndex }
  })
}
