import type { RevisionGridRow, RevisionMode } from './useAllocationRevisionDraft'
import * as XLSX from 'xlsx'

const FIXED_HEADERS = [
  'CÔNG_ĐOẠN',
  'PO_ID',
  'MÃ_PO',
  'THỊ_TRƯỜNG',
  'MÀU',
  'TEAM_ID',
  'TỔ',
  'NGÀY_GIAO',
  'NGÀY_KIỂM',
  'GHI_CHÚ',
] as const

export function exportRevisionAllocation(params: {
  orderCode: string
  rowsByOperation: Record<string, RevisionGridRow[]>
  sizes: string[]
}) {
  const rows = Object.entries(params.rowsByOperation).flatMap(([operation, operationRows]) =>
    operationRows.map((row) => [
      operation,
      row.poId,
      row.poCode,
      row.destination,
      row.color,
      row.teamId ?? '',
      row.teamName ?? '',
      row.deliveryDate ?? '',
      row.checkDate ?? '',
      Array.isArray(row.notes) ? row.notes.join(' | ') : '',
      ...params.sizes.map((size) => row[size] ?? ''),
    ]),
  )
  const sheet = XLSX.utils.aoa_to_sheet([[...FIXED_HEADERS, ...params.sizes], ...rows])
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, sheet, 'Phan_bo_San_xuat')
  XLSX.writeFile(workbook, `LSX_${params.orderCode}_revision.xlsx`)
}

export async function importRevisionAllocation(params: {
  file: File
  currentRowsByOperation: Record<string, RevisionGridRow[]>
  modes: RevisionMode[]
  sizes: string[]
}) {
  const workbook = XLSX.read(await params.file.arrayBuffer(), { type: 'array', cellDates: false })
  const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
  if (!firstSheet) throw new Error('File Excel không có dữ liệu')
  const data = XLSX.utils.sheet_to_json<unknown[]>(firstSheet, { header: 1, defval: '' })
  const headers = (data[0] ?? []).map(String)
  const expectedHeaders = [...FIXED_HEADERS, ...params.sizes]
  if (expectedHeaders.some((header, index) => headers[index] !== header)) {
    throw new Error('Cấu trúc file Excel không đúng mẫu revision hiện tại')
  }

  const modeByName = new Map(params.modes.map((mode) => [mode.opName, mode]))
  const baseByOperationAndPoColor = new Map<string, RevisionGridRow>()
  const teamsByOperation = new Map<string, Map<string, string>>()
  for (const [operation, rows] of Object.entries(params.currentRowsByOperation)) {
    const teams = new Map<string, string>()
    for (const row of rows) {
      baseByOperationAndPoColor.set(`${operation}|${row.poId}|${row.color}`, row)
      for (const option of row.teamOptions ?? []) teams.set(option.value, option.label)
    }
    teamsByOperation.set(operation, teams)
  }

  const result: Record<string, RevisionGridRow[]> = Object.fromEntries(
    params.modes.map((mode) => [mode.opName, []]),
  )
  const seen = new Set<string>()

  for (const [dataIndex, raw] of data.slice(1).entries()) {
    if (raw.every((value) => String(value).trim() === '')) continue
    const line = dataIndex + 2
    const operation = String(raw[0]).trim()
    const poId = String(raw[1]).trim()
    const color = String(raw[4]).trim()
    const teamId = String(raw[5]).trim()
    const mode = modeByName.get(operation)
    if (!mode) throw new Error(`Dòng ${line}: công đoạn không thuộc LSX`)

    const base = baseByOperationAndPoColor.get(`${operation}|${poId}|${color}`)
    if (!base) throw new Error(`Dòng ${line}: PO/màu nằm ngoài phạm vi LSX`)

    const row: RevisionGridRow = {
      ...base,
      id: `excel|${operation}|${poId}|${color}|${dataIndex}`,
      teamId: mode.kind === 'manual' ? teamId || null : base.teamId,
      teamName:
        mode.kind === 'manual' && teamId
          ? (teamsByOperation.get(operation)?.get(teamId) ?? '')
          : (base.teamName ?? ''),
      deliveryDate: String(raw[7]).trim(),
      checkDate: String(raw[8]).trim(),
      notes: String(raw[9])
        .split('|')
        .map((note) => note.trim())
        .filter(Boolean),
      noteText: String(raw[9]).trim(),
      total: 0,
    }

    if (mode.kind === 'manual' && teamId && !teamsByOperation.get(operation)?.has(teamId)) {
      throw new Error(`Dòng ${line}: tổ không thuộc công đoạn hiện tại`)
    }

    let hasQuantity = false
    params.sizes.forEach((size, sizeIndex) => {
      const rawQuantity = raw[FIXED_HEADERS.length + sizeIndex]
      if (base[size] === null) {
        if (String(rawQuantity).trim() !== '' && Number(rawQuantity) !== 0) {
          throw new Error(`Dòng ${line}: SKU ${color}/${size} không hợp lệ trên PO`)
        }
        row[size] = null
        return
      }
      const quantity = Number(rawQuantity || 0)
      if (!Number.isInteger(quantity) || quantity < 0) {
        throw new Error(`Dòng ${line}: quantity ${color}/${size} phải là số nguyên không âm`)
      }
      row[size] = quantity
      row.total += quantity
      hasQuantity ||= quantity > 0
    })

    if (mode.kind === 'manual' && hasQuantity && !teamId) {
      throw new Error(`Dòng ${line}: dòng có sản lượng phải chọn tổ`)
    }
    if (!hasQuantity) continue

    const duplicateKey = `${operation}|${poId}|${color}|${mode.kind === 'manual' ? teamId : ''}`
    if (seen.has(duplicateKey)) {
      throw new Error(`Dòng ${line}: trùng PO/màu/tổ trong cùng công đoạn`)
    }
    seen.add(duplicateKey)
    result[operation].push(row)
  }

  for (const [key, base] of baseByOperationAndPoColor) {
    const [operation] = key.split('|')
    if (result[operation].some((row) => row.poId === base.poId && row.color === base.color))
      continue
    const empty: RevisionGridRow = { ...base, teamId: null, teamName: '', total: 0 }
    for (const size of params.sizes) {
      if (empty[size] !== null) empty[size] = 0
    }
    result[operation].push(empty)
  }

  return result
}
