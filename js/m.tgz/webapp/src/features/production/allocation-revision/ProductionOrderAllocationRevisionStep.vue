<script setup lang="ts">
import AllocationColorCell from '@/features/production/components/AllocationColorCell.vue'
import DateEditor from '@/features/production/components/DateEditor.vue'
import TeamSelectEditor from '@/features/production/components/TeamSelectEditor.vue'
import type { RevisionGridRow, RevisionMode, TeamOption } from './useAllocationRevisionDraft'
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import type {
  MatrixGridBeforeEdit,
  MatrixGridColumnTypes,
  MatrixGridEdit,
} from '@/shared/components/grid/matrixGrid'
import { matrixGridCell, matrixGridEditor } from '@/shared/components/grid/matrixGrid'
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import NoteEditor from '@/shared/components/grid/NoteEditor.vue'
import type { GridColumn, GridRow } from '@/shared/composables/useGridLayout'
import { fmtQty } from '@/shared/utils/fmtQty'
import { formatDate } from '@/shared/utils/date'
import { getMatrixQtyDisplayValue } from '@/shared/utils/matrixQtyDisplay'
import { computed, shallowRef, watch } from 'vue'

const props = defineProps<{
  draftRowsByOp: Record<string, RevisionGridRow[]>
  activeTab: string
  assignmentsByOperation: Array<[string, unknown[]]>
  allSizes: string[]
  modes: RevisionMode[]
  validationMessages: string[]
  warningMessages?: string[]
  readonly?: boolean
}>()

const emit = defineEmits<{
  'update:activeTab': [value: string]
  updateRow: [opName: string, rowIndex: number, prop: string, value: unknown]
  splitRow: [opName: string, row: RevisionGridRow]
  deleteRow: [opName: string, row: RevisionGridRow]
}>()

const COLUMN_TYPES: MatrixGridColumnTypes = {
  size: { cellTemplate: matrixGridCell(MatrixQtyCell) },
  select: { editor: matrixGridEditor(TeamSelectEditor) },
  color: { cellTemplate: matrixGridCell(AllocationColorCell) },
  date: { editor: matrixGridEditor(DateEditor) },
  note: { editor: matrixGridEditor(NoteEditor) },
}

const filterText = shallowRef('')
const activePoType = shallowRef<'REGULAR' | 'POSITIVE'>('REGULAR')
const poTypeTabs = [
  { label: 'Hàng thường', value: 'REGULAR' },
  { label: 'Hàng dương', value: 'POSITIVE' },
]

watch(
  () => props.draftRowsByOp,
  (rowsByOp) => {
    const rows = Object.values(rowsByOp).flat()
    if (
      rows.length &&
      !rows.some((row) => (row.purchaseOrderType ?? 'REGULAR') === activePoType.value)
    ) {
      activePoType.value = rows[0]!.purchaseOrderType === 'POSITIVE' ? 'POSITIVE' : 'REGULAR'
    }
  },
  { immediate: true },
)

const availableRowsByOp = computed(() =>
  Object.fromEntries(
    Object.entries(props.draftRowsByOp).map(([opName, rows]) => {
      const allocatedBySku = new Map<string, number>()
      for (const row of rows) {
        for (const size of props.allSizes) {
          const key = `${row.poId}|${row.color}|${size}`
          allocatedBySku.set(key, (allocatedBySku.get(key) ?? 0) + Number(row[size] ?? 0))
        }
      }

      return [
        opName,
        rows.map((row) => {
          const remainingDemand: Record<string, number | null> = {}
          for (const size of props.allSizes) {
            if (row[`${size}_demand`] === undefined) continue
            if (row[size] === null) {
              remainingDemand[`${size}_demand`] = null
              continue
            }
            const key = `${row.poId}|${row.color}|${size}`
            const allocatedByOtherRows = (allocatedBySku.get(key) ?? 0) - Number(row[size] ?? 0)
            remainingDemand[`${size}_demand`] = Math.max(
              0,
              Number(row[`${size}_demand`] ?? 0) - allocatedByOtherRows,
            )
          }
          return { ...row, ...remainingDemand }
        }),
      ]
    }),
  ),
)

const rowsByPoType = computed(() =>
  Object.fromEntries(
    Object.entries(availableRowsByOp.value).map(([opName, rows]) => [
      opName,
      rows.filter((row) => (row.purchaseOrderType ?? 'REGULAR') === activePoType.value),
    ]),
  ),
)

const filteredRowsByOp = computed(() => {
  const search = filterText.value.trim().toLowerCase()
  if (!search) return rowsByPoType.value
  return Object.fromEntries(
    Object.entries(rowsByPoType.value).map(([opName, rows]) => [
      opName,
      rows.filter(
        (row) =>
          row.poCode.toLowerCase().includes(search) ||
          row.destination.toLowerCase().includes(search) ||
          row.color.toLowerCase().includes(search) ||
          (row.teamName ?? '').toLowerCase().includes(search),
      ),
    ]),
  )
})

const columnsByMode = computed(() => {
  const result: Record<string, GridColumn[]> = {}
  for (const mode of props.modes) {
    const fixed: GridColumn[] = [
      { prop: 'poCode', name: 'Mã PO', pin: 'colPinStart', readonly: true },
      { prop: 'destination', name: 'Thị trường', pin: 'colPinStart', readonly: true },
      {
        prop: 'color',
        name: 'Màu',
        pin: 'colPinStart',
        readonly: true,
        columnType: mode.kind === 'manual' && !props.readonly ? 'color' : undefined,
      },
    ]

    result[mode.opName] = [
      ...fixed,
      ...props.allSizes.map((size) => ({
        prop: size,
        name: size,
        columnType: 'size',
        readonly: props.readonly ?? false,
      })),
      {
        prop: 'deliveryDate',
        name: 'Ngày giao hàng',
        readonly: props.readonly ?? false,
        columnType: props.readonly ? undefined : 'date',
        cellTemplate: (_h, { model }) =>
          model.deliveryDate ? formatDate(String(model.deliveryDate)) : '',
      },
      {
        prop: 'checkDate',
        name: 'Ngày kiểm hàng',
        readonly: props.readonly ?? false,
        columnType: props.readonly ? undefined : 'date',
        cellTemplate: (_h, { model }) =>
          model.checkDate ? formatDate(String(model.checkDate)) : '',
      },
      {
        prop: 'noteText',
        name: 'Ghi chú',
        readonly: props.readonly ?? false,
        columnType: props.readonly ? undefined : 'note',
      },
      {
        prop: 'total',
        name: 'Tổng',
        pin: 'colPinEnd',
        readonly: true,
        cellProperties: () => ({ class: 'font-mono font-bold text-primary' }),
      },
    ]

    if (mode.kind === 'manual' && !props.readonly) {
      result[mode.opName].push({
        prop: 'teamId',
        name: 'Tổ',
        pin: 'colPinEnd',
        readonly: false,
        columnType: 'select',
        source: mode.teams,
        labelKey: 'label',
        valueKey: 'value',
        cellTemplate: (_h, { model }) => {
          const options = Array.isArray(model.teamOptions) ? model.teamOptions : []
          return options.find((option) => option.value === model.teamId)?.label ?? ''
        },
      })
    } else if (mode.kind === 'manual') {
      result[mode.opName].push({
        prop: 'teamName',
        name: 'Tổ',
        pin: 'colPinEnd',
        readonly: true,
      })
    }
  }
  return result
})

const displayRows = (rows: GridRow[]): GridRow[] =>
  rows.map((row) => ({
    ...row,
    ...Object.fromEntries(
      props.allSizes.map((size) => [size, getMatrixQtyDisplayValue(row, size)]),
    ),
    total: fmtQty(Number(row.total ?? 0)),
    teamId:
      Array.isArray(row.teamOptions) && typeof row.teamId === 'string'
        ? (row.teamOptions as TeamOption[]).find((option) => option.value === row.teamId)?.label
        : '',
  }))

function handleAfterEdit(opName: string, edits: MatrixGridEdit[]) {
  for (const edit of edits) {
    const sourceRow = filteredRowsByOp.value[opName]?.[edit.rowIndex]
    const sourceIndex = props.draftRowsByOp[opName]?.findIndex((row) => row.id === sourceRow?.id)
    if (sourceIndex !== undefined && sourceIndex >= 0) {
      emit('updateRow', opName, sourceIndex, edit.prop, edit.value)
    }
  }
}

function handleBeforeEdit(edit: MatrixGridBeforeEdit) {
  if (!props.allSizes.includes(edit.prop)) return
  const row = edit.row as RevisionGridRow
  if (row[edit.prop] === null) edit.preventDefault()
}
</script>

<template>
  <div class="flex flex-col gap-6">
    <div
      v-if="!readonly"
      class="flex items-center gap-4 rounded-lg border border-surface-200 bg-surface-50 p-3"
    >
      <UIcon name="i-lucide-search" class="text-toned" />
      <input
        v-model="filterText"
        type="text"
        placeholder="Lọc theo PO, thị trường, màu hoặc tổ..."
        class="w-full border-none bg-transparent p-1 text-sm outline-none sm:w-80"
      />
    </div>

    <div
      v-if="modes.some((mode) => mode.kind === 'manual')"
      class="rounded border border-surface-200 bg-surface-50 p-3 text-sm"
    >
      <div class="mb-2 font-semibold text-default">Các công đoạn được tính tự động:</div>
      <div class="flex flex-wrap gap-2">
        <UBadge
          v-for="[opName] in assignmentsByOperation.filter(([, items]) => items.length === 1)"
          :key="opName"
          color="neutral"
          :label="opName"
        />
      </div>
    </div>

    <div class="flex flex-wrap items-center justify-between gap-3">
      <UTabs
        :model-value="activeTab"
        :items="modes.map((mode) => ({ label: mode.label, value: mode.opName }))"
        :content="false"
        variant="link"
        @update:model-value="emit('update:activeTab', String($event))"
      />
      <UTabs
        v-model="activePoType"
        :items="poTypeTabs"
        :content="false"
        size="md"
        class="ml-auto w-auto shrink-0"
      />
    </div>
    <div v-for="mode in modes" v-show="activeTab === mode.opName" :key="mode.opName">
      <div class="flex flex-col gap-3">
        <div v-if="mode.kind === 'all-single'" class="text-sm text-default">
          Tất cả công đoạn chỉ có 1 tổ. Chỉnh bảng chuẩn này, các công đoạn còn lại tự nhận cùng
          tổng PO/màu/cỡ.
        </div>
        <BaseMatrixGrid
          :source="filteredRowsByOp[mode.opName] ?? []"
          :columns="columnsByMode[mode.opName] ?? []"
          :column-types="COLUMN_TYPES"
          :display-rows="displayRows"
          :additional-data="{
            onSplit: (row: RevisionGridRow) => emit('splitRow', mode.opName, row),
            onDelete: (row: RevisionGridRow) => emit('deleteRow', mode.opName, row),
          }"
          @afteredit="(event) => handleAfterEdit(mode.opName, event)"
          @beforeedit="handleBeforeEdit"
        />
        <div
          class="-mt-3 flex items-center gap-4 rounded-b-lg border border-surface-200 bg-surface-50 p-3"
        >
          <span class="text-[10px] font-bold tracking-wider text-toned uppercase">
            Tổng sản lượng {{ activePoType === 'POSITIVE' ? 'hàng dương' : 'hàng thường' }}:
          </span>
          <span class="font-mono text-xl font-bold text-primary">
            {{
              fmtQty(
                (rowsByPoType[mode.opName] ?? []).reduce(
                  (sum, row) => sum + Number(row.total ?? 0),
                  0,
                ),
              )
            }}
          </span>
        </div>
      </div>
    </div>
    <div
      v-if="validationMessages.length > 0"
      class="flex items-start gap-3 rounded-lg border border-red-200 bg-red-50 p-3"
    >
      <UIcon name="i-lucide-circle-alert" class="mt-0.5 text-red-600" />
      <ul class="flex flex-col gap-1 text-sm text-red-800">
        <li v-for="message in validationMessages" :key="message">{{ message }}</li>
      </ul>
    </div>
    <div
      v-if="warningMessages?.length"
      class="flex items-start gap-3 rounded-lg border border-yellow-200 bg-yellow-50 p-3"
    >
      <UIcon name="i-lucide-triangle-alert" class="mt-0.5 text-yellow-600" />
      <ul class="flex flex-col gap-1 text-sm text-yellow-800">
        <li v-for="message in warningMessages" :key="message">{{ message }}</li>
      </ul>
    </div>
  </div>
</template>
