import type {
  BuyerOrderDetailVm,
  ProductionOrderVm,
  SkuAllocationVm,
  TeamAssignmentVm,
} from '@/api'
import type { GridRow } from '@/shared/composables/useGridLayout'
import { formatTeamHierarchy } from '@/shared/utils/orgUnit'

export type AllocationCommand = {
  teamAssignmentId: string
  allocations: Array<{
    purchaseOrderId: string
    color: string
    size: string
    quantity: number
    notes: string[]
    checkDate: string | null
    deliveryDate: string | null
  }>
}

type PoInfo = {
  code: string
  destination: string
  deliveryDate: string
  purchaseOrderType?: 'REGULAR' | 'POSITIVE'
}

export type TeamOption = { label: string; value: string; factoryName?: string; disabled?: boolean }

export type RevisionGridRow = GridRow & {
  id: string
  poId: string
  poCode: string
  destination: string
  color: string
  teamId?: string | null
  teamName?: string
  teamOptions?: TeamOption[]
  rowIndex: number
  total: number
}

export type RevisionMode =
  | { kind: 'all-single'; opName: string; label: string }
  | { kind: 'manual'; opName: string; label: string; teams: TeamOption[] }

export function buildAssignmentsByOperation(teamAssignments: TeamAssignmentVm[]) {
  const groups = new Map<string, TeamAssignmentVm[]>()
  for (const assignment of teamAssignments) {
    const list = groups.get(assignment.operation) ?? []
    list.push(assignment)
    groups.set(assignment.operation, list)
  }
  return [...groups.entries()]
}

export function collectAllSizes(
  order: ProductionOrderVm,
  buyerOrder: BuyerOrderDetailVm | null | undefined,
) {
  return [
    ...new Set([
      ...order.historicalColorSizePairs.map((pair) => pair.size),
      ...(buyerOrder?.purchaseOrders.flatMap((po) => po.skuQuantities.map((sku) => sku.size)) ??
        []),
    ]),
  ]
}

export function buildRevisionModes(
  assignmentsByOperation: Array<[string, TeamAssignmentVm[]]>,
): RevisionMode[] {
  const manualModes = assignmentsByOperation
    .filter(([, assignments]) => assignments.length > 1)
    .map(([opName, assignments]) => ({
      kind: 'manual' as const,
      opName,
      label: opName,
      teams: assignments.map((assignment) => ({
        label: formatTeamHierarchy(
          assignment.teamName,
          assignment.factoryName,
          assignment.companyName,
        ),
        value: assignment.teamId,
        factoryName: assignment.factoryName,
      })),
    }))

  if (manualModes.length > 0) return manualModes

  const firstOp = assignmentsByOperation[0]?.[0] ?? 'Phân bổ'
  return [{ kind: 'all-single', opName: '__standard__', label: `Phân bổ chuẩn (${firstOp})` }]
}

export function buildTargetByKey(params: {
  baseline: Record<string, number>
  remaining: Record<string, number>
  allAllocationKeys: string[]
  allReportKeys: string[]
}) {
  const keys = new Set([
    ...Object.keys(params.baseline),
    ...Object.keys(params.remaining),
    ...params.allAllocationKeys,
    ...params.allReportKeys,
  ])
  const result: Record<string, number> = {}
  for (const key of keys) {
    const existsInWfx = Object.prototype.hasOwnProperty.call(params.remaining, key)
    result[key] = existsInWfx ? (params.baseline[key] ?? 0) + (params.remaining[key] ?? 0) : 0
  }
  return result
}

export function buildPoInfoById(
  order: ProductionOrderVm,
  buyerOrder: BuyerOrderDetailVm | null | undefined,
) {
  const result: Record<string, PoInfo> = {}
  for (const po of buyerOrder?.purchaseOrders ?? []) {
    result[po.id] = {
      code: po.code,
      purchaseOrderType: po.type ?? 'REGULAR',
      destination: po.destination,
      deliveryDate: po.deliveryDate,
    }
  }
  for (const po of order.poSummaries) {
    result[po.poId] = {
      code: po.poCode,
      purchaseOrderType: result[po.poId]?.purchaseOrderType ?? 'REGULAR',
      destination: po.destination ?? result[po.poId]?.destination ?? '',
      deliveryDate: result[po.poId]?.deliveryDate ?? po.deliveryDate ?? '',
    }
  }
  return result
}

export function collectPoColorKeys(params: {
  targetByKey: Record<string, number>
  teamAssignments: TeamAssignmentVm[]
  poInfoById: Record<string, PoInfo>
}) {
  const keys = new Set<string>()
  for (const key of Object.keys(params.targetByKey)) {
    const [poId, color] = key.split('|')
    keys.add(`${poId}|${color}`)
  }
  for (const assignment of params.teamAssignments) {
    for (const allocation of assignment.allocations) {
      keys.add(`${allocation.purchaseOrderId}|${allocation.color}`)
    }
  }
  return [...keys].sort((left, right) => {
    const [leftPo, leftColor] = left.split('|')
    const [rightPo, rightColor] = right.split('|')
    const byPo = (params.poInfoById[leftPo]?.code ?? leftPo).localeCompare(
      params.poInfoById[rightPo]?.code ?? rightPo,
    )
    if (byPo !== 0) return byPo
    return leftColor.localeCompare(rightColor)
  })
}

export function buildStandardRows(params: {
  poColorKeys: string[]
  allSizes: string[]
  targetByKey: Record<string, number>
  poInfoById: Record<string, PoInfo>
  baseline: Record<string, number>
  currentAllocations: SkuAllocationVm[]
}) {
  return params.poColorKeys.map((poColorKey, index) => {
    const [poId, color] = poColorKey.split('|')
    const row = baseRow(poId, color, index, params.poInfoById)
    const currentAllocation = params.currentAllocations.find(
      (allocation) => allocation.purchaseOrderId === poId && allocation.color === color,
    )
    row.deliveryDate =
      currentAllocation?.deliveryDate?.trim() || params.poInfoById[poId]?.deliveryDate || ''
    row.checkDate = currentAllocation?.checkDate ?? ''
    const notes = currentAllocation?.notes ?? []
    row.notes = notes
    row.noteText = notes.join(' | ')
    for (const size of params.allSizes) {
      const key = skuKey(poId, color, size)
      const valid = Object.prototype.hasOwnProperty.call(params.targetByKey, key)
      row[size] = valid ? (params.baseline[key] ?? 0) : null
      row[`${size}_demand`] = valid ? Math.max(0, params.targetByKey[key] ?? 0) : null
    }
    row.total = rowTotal(row, params.allSizes)
    return row
  })
}

export function buildManualRows(params: {
  opName: string
  teams: TeamOption[]
  teamAssignments: TeamAssignmentVm[]
  poColorKeys: string[]
  allSizes: string[]
  targetByKey: Record<string, number>
  poInfoById: Record<string, PoInfo>
  currentByOpTeamKey: Record<string, number>
}) {
  const rows: RevisionGridRow[] = []
  for (const poColorKey of params.poColorKeys) {
    const [poId, color] = poColorKey.split('|')
    const activeTeams = params.teams.filter((team) =>
      params.allSizes.some(
        (size) =>
          (params.currentByOpTeamKey[`${team.value}|${skuKey(poId, color, size)}`] ?? 0) > 0,
      ),
    )
    const lineTeams: Array<TeamOption | null> = activeTeams.length > 0 ? activeTeams : [null]
    const assignedFactoryName = activeTeams[0]?.factoryName
    lineTeams.forEach((team, teamIndex) => {
      const row = baseRow(poId, color, teamIndex, params.poInfoById)
      row.teamId = team?.value ?? null
      row.teamName = team?.label ?? ''
      row.teamOptions = params.teams.map((option) => {
        const disabled =
          !!assignedFactoryName &&
          option.factoryName !== assignedFactoryName &&
          option.value !== team?.value
        return {
          ...option,
          disabled,
          label: disabled
            ? `${option.label} — SKU này đã được phân cho Xí nghiệp ${assignedFactoryName}`
            : option.label,
        }
      })
      const currentAllocation = params.teamAssignments
        .find((assignment) => assignment.teamId === team?.value)
        ?.allocations.find(
          (allocation) => allocation.purchaseOrderId === poId && allocation.color === color,
        )
      row.deliveryDate =
        currentAllocation?.deliveryDate?.trim() || params.poInfoById[poId]?.deliveryDate || ''
      row.checkDate = currentAllocation?.checkDate ?? ''
      const notes = currentAllocation?.notes ?? []
      row.notes = notes
      row.noteText = notes.join(' | ')
      for (const size of params.allSizes) {
        const key = skuKey(poId, color, size)
        const valid = Object.prototype.hasOwnProperty.call(params.targetByKey, key)
        row[size] = valid ? (params.currentByOpTeamKey[`${team?.value ?? ''}|${key}`] ?? 0) : null
        row[`${size}_demand`] = valid ? Math.max(0, params.targetByKey[key] ?? 0) : null
      }
      row.total = rowTotal(row, params.allSizes)
      row.id = `${params.opName}|${poColorKey}|${teamIndex}`
      rows.push(row)
    })
  }
  return rows
}

export function buildActivePlanByKey(params: {
  modes: RevisionMode[]
  draftRowsByOp: Record<string, RevisionGridRow[]>
  allSizes: string[]
}) {
  if (params.modes[0]?.kind === 'all-single') {
    return totalsFromRows(params.draftRowsByOp.__standard__ ?? [], params.allSizes)
  }

  const firstManual = params.modes.find((mode) => mode.kind === 'manual')
  return firstManual
    ? totalsFromRows(params.draftRowsByOp[firstManual.opName] ?? [], params.allSizes)
    : {}
}

export function buildValidationMessages(params: {
  draftRowsByOp: Record<string, RevisionGridRow[]>
  modes: RevisionMode[]
  allSizes: string[]
  targetByKey: Record<string, number>
  baselineByKey: Record<string, number>
  currentWfxKeys: Set<string>
  activePlanByKey: Record<string, number>
  labelForKey: (key: string) => string
  maxReportedByColorSize: Record<string, number>
  order: ProductionOrderVm
  allocationsForAssignment: (assignment: TeamAssignmentVm) => AllocationCommand['allocations']
  poInfoById: Record<string, PoInfo>
}) {
  const messages: string[] = []

  for (const [key, quantity] of Object.entries(params.activePlanByKey)) {
    if (!params.currentWfxKeys.has(key) && quantity > (params.baselineByKey[key] ?? 0)) {
      messages.push(
        `${params.labelForKey(key)}: SKU đã bị WFX loại chỉ được giảm, không được tăng quá ${params.baselineByKey[key] ?? 0}`,
      )
    }
  }

  for (const mode of params.modes) {
    const draft = colorSizeTotalsFromRows(params.draftRowsByOp[mode.opName] ?? [], params.allSizes)
    const produced = params.maxReportedByColorSize
    const keys = new Set([...Object.keys(draft), ...Object.keys(produced)])
    for (const key of keys) {
      const producedQty = produced[key] ?? 0
      const draftQty = draft[key] ?? 0
      if (producedQty > draftQty) {
        const [color, size] = key.split('|')
        messages.push(
          `${mode.label}: màu ${color}, size ${size} đã sản xuất ${producedQty} vượt tổng phân bổ ${draftQty}`,
        )
      }
    }
  }

  if (params.modes[0]?.kind !== 'all-single') {
    const base = params.activePlanByKey
    for (const mode of params.modes.filter((item) => item.kind === 'manual')) {
      const totals = totalsFromRows(params.draftRowsByOp[mode.opName] ?? [], params.allSizes)
      const keys = new Set([
        ...Object.keys(base),
        ...Object.keys(totals),
        ...Object.keys(params.targetByKey),
      ])
      for (const key of keys) {
        if ((totals[key] ?? 0) !== (base[key] ?? 0)) {
          messages.push(`${mode.label}: tổng ${params.labelForKey(key)} không khớp công đoạn chuẩn`)
          break
        }
      }
    }
  }

  for (const [opName, rows] of Object.entries(params.draftRowsByOp)) {
    const seen = new Set<string>()
    for (const row of rows) {
      const hasQuantity = params.allSizes.some((size) => Number(row[size] ?? 0) > 0)
      const mode = params.modes.find((item) => item.opName === opName)
      if (hasQuantity && mode?.kind === 'manual' && !row.teamId) {
        messages.push(`${opName}: ${row.poCode} / ${row.color} có sản lượng nhưng chưa chọn tổ`)
        continue
      }
      if (!hasQuantity || !row.teamId) continue
      const duplicateKey = `${row.poId}|${row.color}|${row.teamId ?? ''}`
      if (seen.has(duplicateKey)) {
        messages.push(`${opName}: trùng dòng ${row.poCode} / ${row.color} / ${row.teamName}`)
        break
      }
      seen.add(duplicateKey)
      for (const size of params.allSizes) {
        if (Number(row[size] ?? 0) < 0) {
          messages.push(`${opName}: ${row.poCode} / ${row.color} / ${size} không được âm`)
          break
        }
      }
    }
  }

  for (const assignment of params.order.teamAssignments) {
    const allocatedByTypeColorSize: Record<string, number> = {}
    for (const allocation of params.allocationsForAssignment(assignment)) {
      const type = params.poInfoById[allocation.purchaseOrderId]?.purchaseOrderType ?? 'REGULAR'
      const key = `${allocation.color}|${allocation.size}|${type}`
      allocatedByTypeColorSize[key] = (allocatedByTypeColorSize[key] ?? 0) + allocation.quantity
    }

    const reportedByTypeColorSize: Record<string, number> = {}
    for (const total of assignment.outputReportTotals) {
      const type = params.poInfoById[total.purchaseOrderId]?.purchaseOrderType ?? 'REGULAR'
      const key = `${total.color}|${total.size}|${type}`
      reportedByTypeColorSize[key] = (reportedByTypeColorSize[key] ?? 0) + total.completedQty
    }

    for (const [key, reportedQuantity] of Object.entries(reportedByTypeColorSize)) {
      const allocatedQuantity = allocatedByTypeColorSize[key] ?? 0
      if (allocatedQuantity < reportedQuantity) {
        const [color, size, type] = key.split('|')
        const teamLabel = formatTeamHierarchy(
          assignment.teamName,
          assignment.factoryName,
          assignment.companyName,
        )
        messages.push(
          `${assignment.operation} - ${teamLabel}: đã làm ${reportedQuantity} chiếc ${color}/${size}, không thể phân bổ còn ${allocatedQuantity} (${type === 'POSITIVE' ? 'Hàng dương' : 'Hàng thường'})`,
        )
      }
    }
  }
  if (
    params.order.teamAssignments.every(
      (assignment) => params.allocationsForAssignment(assignment).length === 0,
    )
  ) {
    messages.push('LSX phải còn ít nhất một phân bổ hoạt động')
  }

  return [...new Set(messages)]
}

export function buildBaselineTotalsByKey(
  assignmentsByOperation: Array<[string, TeamAssignmentVm[]]>,
) {
  const firstOpAssignments = assignmentsByOperation[0]?.[1] ?? []
  return sumAllocations(firstOpAssignments.flatMap((assignment) => assignment.allocations))
}

export function buildRemainingByKey(buyerOrder: BuyerOrderDetailVm | null | undefined) {
  const result: Record<string, number> = {}
  for (const po of buyerOrder?.purchaseOrders ?? []) {
    for (const sku of po.skuQuantities) {
      result[skuKey(po.id, sku.color, sku.size)] = sku.remainingQuantity
    }
  }
  return result
}

export function buildCurrentWfxKeys(buyerOrder: BuyerOrderDetailVm | null | undefined) {
  const keys = new Set<string>()
  for (const po of buyerOrder?.purchaseOrders ?? []) {
    for (const sku of po.skuQuantities) {
      keys.add(skuKey(po.id, sku.color, sku.size))
    }
  }
  return keys
}

export function buildAllAllocationKeys(teamAssignments: TeamAssignmentVm[]) {
  return teamAssignments.flatMap((assignment) =>
    assignment.allocations.map((allocation) =>
      skuKey(allocation.purchaseOrderId, allocation.color, allocation.size),
    ),
  )
}

export function buildAllReportKeys(teamAssignments: TeamAssignmentVm[]) {
  return teamAssignments.flatMap((assignment) =>
    assignment.outputReportTotals.map((total) =>
      skuKey(total.purchaseOrderId, total.color, total.size),
    ),
  )
}

export function buildCurrentByOpTeamKey(teamAssignments: TeamAssignmentVm[], opName: string) {
  const result: Record<string, number> = {}
  for (const assignment of teamAssignments.filter((item) => item.operation === opName)) {
    for (const allocation of assignment.allocations) {
      const key = `${assignment.teamId}|${skuKey(
        allocation.purchaseOrderId,
        allocation.color,
        allocation.size,
      )}`
      result[key] = (result[key] ?? 0) + allocation.quantity
    }
  }
  return result
}

export function buildReportedByOpColorSize(teamAssignments: TeamAssignmentVm[], opName: string) {
  const result: Record<string, number> = {}
  for (const assignment of teamAssignments.filter((item) => item.operation === opName)) {
    for (const total of assignment.outputReportTotals) {
      const key = colorSizeKey(total.color, total.size)
      result[key] = (result[key] ?? 0) + total.completedQty
    }
  }
  return result
}

export function buildMaxReportedByColorSize(teamAssignments: TeamAssignmentVm[]) {
  const result: Record<string, number> = {}
  const operationNames = [...new Set(teamAssignments.map((assignment) => assignment.operation))]
  for (const opName of operationNames) {
    const totals = buildReportedByOpColorSize(teamAssignments, opName)
    for (const [key, quantity] of Object.entries(totals)) {
      result[key] = Math.max(result[key] ?? 0, quantity)
    }
  }
  return result
}

export function buildRowsToAllocations(params: {
  rows: RevisionGridRow[]
  currentAllocations: SkuAllocationVm[]
  allSizes: string[]
  poInfoById: Record<string, { deliveryDate: string }>
  initialRows?: RevisionGridRow[]
}) {
  const currentByKey = new Map(
    params.currentAllocations.map((allocation) => [
      skuKey(allocation.purchaseOrderId, allocation.color, allocation.size),
      allocation,
    ]),
  )
  const initialByPoColor = new Map(
    (params.initialRows ?? []).map((row) => [`${row.poId}|${row.color}`, row]),
  )
  const result: AllocationCommand['allocations'] = []
  for (const row of params.rows) {
    const initial = initialByPoColor.get(`${row.poId}|${row.color}`)
    const notes = Array.isArray(row.notes) ? row.notes.map(String) : []
    const notesChanged = !initial || JSON.stringify(notes) !== JSON.stringify(initial.notes ?? [])
    const checkDateChanged = !initial || row.checkDate !== initial.checkDate
    const deliveryDateChanged = !initial || row.deliveryDate !== initial.deliveryDate
    for (const size of params.allSizes) {
      const quantity = Number(row[size] ?? 0)
      if (quantity <= 0) continue
      const key = skuKey(row.poId, row.color, size)
      const current = currentByKey.get(key)
      result.push({
        purchaseOrderId: row.poId,
        color: row.color,
        size,
        quantity,
        notes: notesChanged ? notes : (current?.notes ?? []),
        checkDate: checkDateChanged
          ? typeof row.checkDate === 'string'
            ? row.checkDate
            : null
          : (current?.checkDate ?? null),
        deliveryDate: deliveryDateChanged
          ? typeof row.deliveryDate === 'string'
            ? row.deliveryDate
            : null
          : current?.deliveryDate?.trim() || params.poInfoById[row.poId]?.deliveryDate || null,
      })
    }
  }
  return result
}

export function buildAllocationsFromPlan(params: {
  plan: Record<string, number>
  currentAllocations: SkuAllocationVm[]
  poInfoById: Record<string, { deliveryDate: string }>
}): AllocationCommand['allocations'] {
  const currentByKey = new Map(
    params.currentAllocations.map((allocation) => [
      skuKey(allocation.purchaseOrderId, allocation.color, allocation.size),
      allocation,
    ]),
  )
  const result: AllocationCommand['allocations'] = []
  for (const [key, quantity] of Object.entries(params.plan)) {
    if (quantity <= 0) continue
    const [purchaseOrderId, color, size] = key.split('|')
    const current = currentByKey.get(key)
    result.push({
      purchaseOrderId,
      color,
      size,
      quantity,
      notes: current?.notes ?? [],
      checkDate: current?.checkDate ?? null,
      deliveryDate:
        current?.deliveryDate?.trim() || params.poInfoById[purchaseOrderId]?.deliveryDate || null,
    })
  }
  return result
}

export function buildLabelForKey(key: string, poInfoById: Record<string, { code: string }>) {
  const [poId, color, size] = key.split('|')
  return `${poInfoById[poId]?.code ?? poId} / ${color} / ${size}`
}

export function skuKey(poId: string, color: string, size: string): string {
  return `${poId}|${color}|${size}`
}

export function colorSizeKey(color: string, size: string): string {
  return `${color}|${size}`
}

export function rowTotal(row: GridRow, allSizes: string[]): number {
  return allSizes.reduce((sum, size) => sum + Number(row[size] ?? 0), 0)
}

export function totalsFromRows(
  rows: RevisionGridRow[],
  allSizes: string[],
): Record<string, number> {
  const totals: Record<string, number> = {}
  for (const row of rows) {
    for (const size of allSizes) {
      const quantity = Number(row[size] ?? 0)
      if (quantity <= 0) continue
      const key = skuKey(row.poId, row.color, size)
      totals[key] = (totals[key] ?? 0) + quantity
    }
  }
  return totals
}

export function colorSizeTotalsFromRows(
  rows: RevisionGridRow[],
  allSizes: string[],
): Record<string, number> {
  const totals: Record<string, number> = {}
  for (const row of rows) {
    for (const size of allSizes) {
      const quantity = Number(row[size] ?? 0)
      if (quantity <= 0) continue
      const key = colorSizeKey(row.color, size)
      totals[key] = (totals[key] ?? 0) + quantity
    }
  }
  return totals
}

export function sumAllocations(allocations: SkuAllocationVm[]): Record<string, number> {
  const result: Record<string, number> = {}
  for (const allocation of allocations) {
    const key = skuKey(allocation.purchaseOrderId, allocation.color, allocation.size)
    result[key] = (result[key] ?? 0) + allocation.quantity
  }
  return result
}

function baseRow(
  poId: string,
  color: string,
  index: number,
  poInfoById: Record<string, PoInfo>,
): RevisionGridRow {
  const info = poInfoById[poId]
  return {
    id: `${poId}|${color}|${index}`,
    poId,
    poCode: info?.code ?? poId,
    purchaseOrderType: info?.purchaseOrderType ?? 'REGULAR',
    destination: info?.destination ?? '',
    color,
    rowIndex: index,
    total: 0,
  }
}
