import type { BuyerOrderDetailVm, ProductionOrderVm, TeamAssignmentVm } from '@/api'
import {
  type RevisionGridRow,
  useAllocationRevisionDraft,
} from '@/features/production/allocation-revision/useAllocationRevisionDraft'
import ProductionOrderAllocationRevisionStep from '@/features/production/allocation-revision/ProductionOrderAllocationRevisionStep.vue'
import { mount } from '@vue/test-utils'
import { defineComponent } from 'vue'
import { describe, expect, it } from 'vitest'

describe('useAllocationRevisionDraft', () => {
  it.each(['REGULAR', 'POSITIVE'] as const)(
    'allocates current %s PO colors and sizes not previously in the LSX',
    (type) => {
      const order = makeSingleModeOrder()
      const buyerOrder = makeBuyerOrder([
        { color: 'Red', size: 'S', quantity: 10, remainingQuantity: 0 },
        { color: 'Blue', size: 'M', quantity: 7, remainingQuantity: 7 },
      ])
      buyerOrder.purchaseOrders[0]!.type = type
      const draft = useAllocationRevisionDraft({
        visible: () => true,
        order: () => order,
        buyerOrder: () => buyerOrder,
      })

      expect(draft.allSizes.value).toContain('M')
      const index = draft.draftRowsByOp.value.__standard__.findIndex((row) => row.color === 'Blue')
      expect(index).toBeGreaterThanOrEqual(0)
      draft.updateRowData('__standard__', index, 'M', 7)
      expect(draft.createPayload()?.teamAssignments[0]?.allocations).toContainEqual(
        expect.objectContaining({ purchaseOrderId: 'po-1', color: 'Blue', size: 'M', quantity: 7 }),
      )
    },
  )

  it.each(['REGULAR', 'POSITIVE'] as const)(
    'only offers BO POs of the existing %s type',
    (type) => {
      const order = makeSingleModeOrder()
      const buyerOrder = makeBuyerOrder()
      buyerOrder.purchaseOrders[0]!.type = type
      buyerOrder.purchaseOrders.push(
        { ...buyerOrder.purchaseOrders[0]!, id: 'po-same', code: 'PO-SAME' },
        {
          ...buyerOrder.purchaseOrders[0]!,
          id: 'po-other',
          code: 'PO-OTHER',
          type: type === 'REGULAR' ? 'POSITIVE' : 'REGULAR',
        },
      )
      const draft = useAllocationRevisionDraft({
        visible: () => true,
        order: () => order,
        buyerOrder: () => buyerOrder,
      })
      expect([...new Set(draft.draftRowsByOp.value.__standard__.map((row) => row.poId))]).toEqual([
        'po-1',
        'po-same',
      ])
    },
  )

  it.each(['REGULAR', 'POSITIVE'] as const)(
    'blocks setting all %s allocations to zero in a mixed LSX',
    (type) => {
      const order = makeSingleModeOrder()
      const buyerOrder = makeBuyerOrder()
      buyerOrder.purchaseOrders.push({
        ...buyerOrder.purchaseOrders[0]!,
        id: 'po-positive',
        code: 'PO-POSITIVE',
        type: 'POSITIVE',
      })
      order.teamAssignments[0]!.allocations.push({
        ...order.teamAssignments[0]!.allocations[0]!,
        purchaseOrderId: 'po-positive',
      })
      const draft = useAllocationRevisionDraft({
        visible: () => true,
        order: () => order,
        buyerOrder: () => buyerOrder,
      })
      draft.replaceDraft({
        __standard__: draft.draftRowsByOp.value.__standard__.map((row) =>
          row.purchaseOrderType === type ? { ...row, S: 0, M: 0, total: 0 } : row,
        ),
      })
      expect(draft.validationMessages.value).toContain(
        type === 'REGULAR'
          ? 'PO hàng thường phải còn phân bổ lớn hơn 0'
          : 'PO hàng dương phải còn phân bổ lớn hơn 0',
      )
      expect(draft.createPayload()).toBeNull()
    },
  )

  it('rejects replacing one teams produced regular capacity while operation totals stay balanced', () => {
    const teamA = makeAssignment({
      id: 'a',
      teamId: 'team-a',
      operation: 'SEW',
      color: 'Red',
      quantity: 60,
    })
    const teamB = makeAssignment({
      id: 'b',
      teamId: 'team-b',
      operation: 'SEW',
      color: 'Red',
      quantity: 40,
    })
    for (const team of [teamA, teamB])
      team.allocations.push({ ...team.allocations[0]!, purchaseOrderId: 'positive', quantity: 5 })
    teamA.outputReportTotals = [
      { purchaseOrderId: 'po-1', color: 'Red', size: 'S', completedQty: 60 },
      { purchaseOrderId: 'positive', color: 'Red', size: 'S', completedQty: 5 },
    ]
    const buyerOrder = makeBuyerOrder([
      { color: 'Red', size: 'S', quantity: 100, remainingQuantity: 0 },
    ])
    buyerOrder.purchaseOrders.push({
      ...buyerOrder.purchaseOrders[0]!,
      id: 'positive',
      code: 'POS',
      type: 'POSITIVE',
      skuQuantities: [{ color: 'Red', size: 'S', quantity: 10, remainingQuantity: 0 }],
    })
    const draft = useAllocationRevisionDraft({
      visible: () => true,
      order: () => makeOrder([teamA, teamB], [{ color: 'Red', size: 'S' }]),
      buyerOrder: () => buyerOrder,
    })
    for (const [poId, teamId, quantity] of [
      ['po-1', 'team-a', 55],
      ['po-1', 'team-b', 45],
      ['positive', 'team-a', 10],
      ['positive', 'team-b', 0],
    ] as const) {
      const index = draft.draftRowsByOp.value.SEW!.findIndex(
        (row) => row.poId === poId && row.teamId === teamId,
      )
      draft.updateRowData('SEW', index, 'S', quantity)
    }
    expect(draft.createPayload()).toBeNull()
    expect(draft.validationMessages.value.join(' ')).toContain('Hàng thường')
  })

  it('rebuilds manual rows with existing allocation data and resets row indexes per PO/color', () => {
    const order = makeManualOrder()
    const draft = useAllocationRevisionDraft({
      visible: () => true,
      order: () => order,
      buyerOrder: () => makeBuyerOrder(),
    })

    const rows = draft.draftRowsByOp.value['SEW-1']
    const red = rows.find((row) => row.color === 'Red')
    const blue = rows.find((row) => row.color === 'Blue')

    expect(rows.map((row) => [row.color, row.rowIndex])).toEqual([
      ['Blue', 0],
      ['Red', 0],
    ])
    expect(red).toMatchObject({
      teamId: 'team-red',
      S: 36,
      M: 0,
      deliveryDate: '2026-07-30',
      checkDate: '2026-07-29',
      notes: ['keep-red'],
      noteText: 'keep-red',
    })
    expect(blue).toMatchObject({
      teamId: 'team-blue',
      S: 50,
      M: 0,
      deliveryDate: '2026-08-01',
      notes: ['keep-blue'],
    })
    expect(draft.isDirty.value).toBe(false)
  })

  it('edits, splits, fills, deletes and replaces rows through controlled actions', () => {
    const order = makeManualOrder()
    const draft = useAllocationRevisionDraft({
      visible: () => true,
      order: () => order,
      buyerOrder: () => makeBuyerOrder(),
    })
    const operation = 'SEW-1'
    const redIndex = draft.draftRowsByOp.value[operation].findIndex((row) => row.color === 'Red')

    draft.updateRowData(operation, redIndex, 'S', '41.9')
    draft.updateRowData(operation, redIndex, 'noteText', ' first | second | ')

    const editedRed = draft.draftRowsByOp.value[operation][redIndex]
    expect(editedRed.S).toBe(41)
    expect(editedRed.notes).toEqual(['first', 'second'])
    expect(draft.isDirty.value).toBe(true)

    draft.updateRowData(operation, redIndex, 'S', 999)
    expect(draft.draftRowsByOp.value[operation][redIndex].S).toBe(100)

    draft.splitRow(operation, editedRed)
    const redRows = draft.draftRowsByOp.value[operation].filter((row) => row.color === 'Red')
    expect(redRows.map((row) => row.rowIndex)).toEqual([0, 1])
    expect(redRows[1]).toMatchObject({ teamId: null, S: 0, M: 0, total: 0 })

    draft.quickFillAll()
    const filledRedRows = draft.draftRowsByOp.value[operation].filter((row) => row.color === 'Red')
    expect(filledRedRows.map((row) => [row.S, row.M])).toEqual([
      [100, 20],
      [0, 0],
    ])

    draft.deleteRow(operation, filledRedRows[1])
    expect(draft.draftRowsByOp.value[operation].filter((row) => row.color === 'Red')).toHaveLength(
      1,
    )

    const reversed = [...draft.draftRowsByOp.value[operation]].reverse()
    draft.replaceDraft({ [operation]: reversed })
    expect(draft.draftRowsByOp.value[operation].map((row) => [row.color, row.rowIndex])).toEqual([
      ['Red', 0],
      ['Blue', 0],
    ])
  })

  it('blocks payload when a removed WFX SKU is increased above its baseline', () => {
    const order = makeSingleModeOrder()
    const draft = useAllocationRevisionDraft({
      visible: () => true,
      order: () => order,
      buyerOrder: () => makeBuyerOrder([]),
    })

    const rows = draft.draftRowsByOp.value.__standard__.map((row) => ({
      ...row,
      S: 11,
      total: 11,
    }))
    draft.replaceDraft({ __standard__: rows })

    expect(draft.validationMessages.value).toContain(
      'PO-1 / Red / S: SKU đã bị WFX loại chỉ được giảm, không được tăng quá 10',
    )
    expect(draft.createPayload()).toBeNull()
  })

  it('keeps over-allocation as a warning without blocking payload creation', () => {
    const order = makeSingleModeOrder()
    order.teamAssignments[0]!.allocations[0]!.quantity = 11
    const draft = useAllocationRevisionDraft({
      visible: () => true,
      order: () => order,
      buyerOrder: () =>
        makeBuyerOrder([{ color: 'Red', size: 'S', quantity: 10, remainingQuantity: -1 }]),
    })

    expect(draft.overAllocatedKeys.value).toEqual(['po-1|Red|S'])
    expect(draft.overAllocatedMessages.value).toEqual([
      'PO-1 / Red / S: phân bổ 11 vượt mức BO 10 (vượt 1)',
    ])
    expect(draft.validationMessages.value).toEqual([])
    expect(draft.createPayload()).not.toBeNull()
  })

  it('uses the BuyerOrder delivery date in a single-team draft and payload', () => {
    const draft = useAllocationRevisionDraft({
      visible: () => true,
      order: () => makeSingleModeOrder(),
      buyerOrder: () => makeBuyerOrder(),
    })

    expect(draft.draftRowsByOp.value.__standard__[0]?.deliveryDate).toBe('2026-08-01')
    expect(draft.createPayload()?.teamAssignments[0]?.allocations[0]?.deliveryDate).toBe(
      '2026-08-01',
    )
  })

  it('rebuilds an all-single row with existing allocation metadata', () => {
    const order = makeOrder(
      [
        makeAssignment({
          id: 'cut',
          teamId: 'cut-team',
          operation: 'CUT',
          color: 'Red',
          quantity: 10,
          deliveryDate: '2026-07-30',
          checkDate: '2026-07-29',
          notes: ['keep-cut'],
        }),
      ],
      [{ color: 'Red', size: 'S' }],
    )
    const draft = useAllocationRevisionDraft({
      visible: () => true,
      order: () => order,
      buyerOrder: () => makeBuyerOrder(),
    })

    expect(draft.draftRowsByOp.value.__standard__.find((row) => row.color === 'Red')).toMatchObject(
      {
        deliveryDate: '2026-07-30',
        checkDate: '2026-07-29',
        notes: ['keep-cut'],
        noteText: 'keep-cut',
      },
    )
  })

  it('applies metadata edited in the standard draft to every single-team assignment', () => {
    const order = makeOrder(
      [
        makeAssignment({
          id: 'cut',
          teamId: 'cut-team',
          operation: 'CUT',
          color: 'Red',
          quantity: 10,
        }),
        makeAssignment({
          id: 'sew',
          teamId: 'sew-team',
          operation: 'SEW',
          color: 'Red',
          quantity: 10,
        }),
      ],
      [{ color: 'Red', size: 'S' }],
    )
    const draft = useAllocationRevisionDraft({
      visible: () => true,
      order: () => order,
      buyerOrder: () => makeBuyerOrder(),
    })

    const redIndex = draft.draftRowsByOp.value.__standard__.findIndex((row) => row.color === 'Red')
    draft.updateRowData('__standard__', redIndex, 'deliveryDate', '2026-09-01')
    draft.updateRowData('__standard__', redIndex, 'checkDate', '2026-08-25')
    draft.updateRowData('__standard__', redIndex, 'noteText', 'updated')

    expect(draft.createPayload()?.teamAssignments).toHaveLength(2)
    for (const assignment of draft.createPayload()?.teamAssignments ?? []) {
      expect(assignment.allocations.find((allocation) => allocation.color === 'Red')).toMatchObject(
        {
          deliveryDate: '2026-09-01',
          checkDate: '2026-08-25',
          notes: ['updated'],
        },
      )
    }
  })

  it('creates one command per assignment and preserves allocation metadata', () => {
    const cut = makeAssignment({
      id: 'cut',
      teamId: 'cut-team',
      operation: 'CUT',
      color: 'Red',
      quantity: 10,
      notes: ['cut-note'],
      deliveryDate: '2026-08-01',
      checkDate: '2026-07-31',
    })
    const sew = makeAssignment({
      id: 'sew',
      teamId: 'sew-team',
      operation: 'SEW',
      color: 'Red',
      quantity: 10,
      notes: ['sew-note'],
      deliveryDate: '2026-08-03',
      checkDate: '2026-08-02',
    })
    const order = makeOrder([cut, sew], [{ color: 'Red', size: 'S' }])
    const draft = useAllocationRevisionDraft({
      visible: () => true,
      order: () => order,
      buyerOrder: () =>
        makeBuyerOrder([{ color: 'Red', size: 'S', quantity: 10, remainingQuantity: 0 }]),
    })

    expect(draft.createPayload()).toEqual({
      teamAssignments: [
        {
          teamAssignmentId: 'cut',
          allocations: [
            {
              purchaseOrderId: 'po-1',
              color: 'Red',
              size: 'S',
              quantity: 10,
              notes: ['cut-note'],
              deliveryDate: '2026-08-01',
              checkDate: '2026-07-31',
            },
          ],
        },
        {
          teamAssignmentId: 'sew',
          allocations: [
            {
              purchaseOrderId: 'po-1',
              color: 'Red',
              size: 'S',
              quantity: 10,
              notes: ['sew-note'],
              deliveryDate: '2026-08-03',
              checkDate: '2026-08-02',
            },
          ],
        },
      ],
    })
  })

  it('creates matching allocations for auto-calculated single-team operations in hybrid mode', () => {
    const cut = makeAssignment({
      id: 'cut-id',
      teamId: 'cut-team',
      operation: 'CUT',
      color: 'Red',
      quantity: 10,
      notes: ['cut-note'],
      deliveryDate: '2026-08-01',
      checkDate: '2026-07-31',
    })
    const sew1 = makeAssignment({
      id: 'sew-1-id',
      teamId: 'sew-team-1',
      operation: 'SEW',
      color: 'Red',
      quantity: 6,
    })
    const sew2 = makeAssignment({
      id: 'sew-2-id',
      teamId: 'sew-team-2',
      operation: 'SEW',
      color: 'Red',
      quantity: 4,
    })
    const order = makeOrder([cut, sew1, sew2], [{ color: 'Red', size: 'S' }])
    const draft = useAllocationRevisionDraft({
      visible: () => true,
      order: () => order,
      buyerOrder: () =>
        makeBuyerOrder([{ color: 'Red', size: 'S', quantity: 20, remainingQuantity: 10 }]),
    })

    expect(draft.modes.value).toHaveLength(1)
    expect(draft.modes.value[0]?.opName).toBe('SEW')
    expect(draft.modes.value[0]?.kind).toBe('manual')

    const sewRows = draft.draftRowsByOp.value.SEW
    expect(sewRows).toHaveLength(2)

    draft.updateRowData('SEW', 0, 'S', 7)

    const payload = draft.createPayload()
    expect(payload).not.toBeNull()

    const cutCmd = payload?.teamAssignments.find((cmd) => cmd.teamAssignmentId === 'cut-id')
    const sew1Cmd = payload?.teamAssignments.find((cmd) => cmd.teamAssignmentId === 'sew-1-id')
    const sew2Cmd = payload?.teamAssignments.find((cmd) => cmd.teamAssignmentId === 'sew-2-id')

    expect(sew1Cmd?.allocations[0]?.quantity).toBe(7)
    expect(sew2Cmd?.allocations[0]?.quantity).toBe(4)

    expect(cutCmd?.allocations[0]).toMatchObject({
      purchaseOrderId: 'po-1',
      color: 'Red',
      size: 'S',
      quantity: 11,
      notes: ['cut-note'],
      deliveryDate: '2026-08-01',
      checkDate: '2026-07-31',
    })
    expect(draft.validationMessages.value).toEqual([])
  })
})

describe('ProductionOrderAllocationRevisionStep', () => {
  it('separates PO type tabs and edits the original row without losing the other type', async () => {
    const rows = makeComponentRows().map((row, index) => ({
      ...row,
      purchaseOrderType: index === 0 ? 'REGULAR' : 'POSITIVE',
    }))
    const wrapper = mountRevisionStep(rows)
    const grid = wrapper.findComponent({ name: 'BaseMatrixGrid' })
    expect(grid.props('source')).toEqual([rows[0]])
    expect(
      grid.props('columns').some((column: { prop: string }) => column.prop === 'purchaseOrderType'),
    ).toBe(false)
    expect(wrapper.text()).toContain('Tổng sản lượng hàng thường:')

    const tabs = wrapper.findAllComponents({ name: 'UTabs' })[1]!
    tabs.vm.$emit('update:modelValue', 'POSITIVE')
    await wrapper.vm.$nextTick()
    expect(grid.props('source')).toEqual([rows[1]])
    expect(wrapper.text()).toContain('Tổng sản lượng hàng dương:')
    grid.vm.$emit('afteredit', [{ rowIndex: 0, prop: 'S', value: 75 }])
    expect(wrapper.emitted('updateRow')).toEqual([['SEW-1', 1, 'S', 75]])

    tabs.vm.$emit('update:modelValue', 'REGULAR')
    await wrapper.vm.$nextTick()
    expect(grid.props('source')).toEqual([rows[0]])
    wrapper.unmount()
  })

  it('renders validation feedback and filters visible allocation rows', async () => {
    const rows = makeComponentRows()
    const wrapper = mountRevisionStep(rows, ['Allocation is invalid'])

    expect(wrapper.text()).toContain('Allocation is invalid')

    await wrapper.find('input').setValue('blue')

    const grid = wrapper.findComponent({ name: 'BaseMatrixGrid' })
    expect(grid.props('source')).toEqual([rows[1]])
  })

  it('emits the edited source row through its public event contract', async () => {
    const rows = makeComponentRows()
    const wrapper = mountRevisionStep(rows)
    const grid = wrapper.findComponent({ name: 'BaseMatrixGrid' })

    grid.vm.$emit('afteredit', [{ rowIndex: 1, prop: 'S', value: 75 }])
    await wrapper.vm.$nextTick()

    expect(wrapper.emitted('updateRow')).toEqual([['SEW-1', 1, 'S', 75]])
  })

  it('renders the PO, color and size that exceed the BO limit', () => {
    const message = 'PO-1 / Red / S: phân bổ 11 vượt mức BO 10 (vượt 1)'
    const wrapper = mountRevisionStep(makeComponentRows(), [], [message])

    expect(wrapper.text()).toContain(message)
  })

  it('shows each split row quantity against the amount still available to that row', () => {
    const rows = makeComponentRows().map((row, index) => ({
      ...row,
      color: 'Red',
      S: index === 0 ? 5 : 0,
      S_demand: 5,
    }))
    const wrapper = mountRevisionStep(rows)
    const source = wrapper.findComponent({ name: 'BaseMatrixGrid' }).props('source')

    expect(source.map((row: RevisionGridRow) => row.S_demand)).toEqual([5, 0])
  })
})

const BaseMatrixGridStub = defineComponent({
  name: 'BaseMatrixGrid',
  props: {
    source: { type: Array, required: true },
    columns: { type: Array, required: true },
  },
  emits: ['afteredit', 'beforeedit'],
  template: '<div data-testid="matrix-grid">{{ source.length }}</div>',
})

const SlotStub = defineComponent({
  template: '<div><slot /></div>',
})

function mountRevisionStep(
  rows: RevisionGridRow[],
  validationMessages: string[] = [],
  warningMessages: string[] = [],
) {
  return mount(ProductionOrderAllocationRevisionStep, {
    props: {
      draftRowsByOp: { 'SEW-1': rows },
      activeTab: 'SEW-1',
      assignmentsByOperation: [['SEW-1', [{ id: 'assignment' }]]],
      allSizes: ['S'],
      modes: [
        {
          kind: 'manual',
          opName: 'SEW-1',
          label: 'SEW-1',
          teams: [{ label: 'Team red', value: 'team-red' }],
        },
      ],
      validationMessages,
      warningMessages,
    },
    global: {
      stubs: {
        BaseMatrixGrid: BaseMatrixGridStub,
        Tabs: defineComponent({
          name: 'UTabs',
          props: ['modelValue', 'items'],
          emits: ['update:modelValue'],
          template: '<div />',
        }),
        Tab: SlotStub,
        TabList: SlotStub,
        TabPanel: SlotStub,
        TabPanels: SlotStub,
        Tag: true,
      },
    },
  })
}

function makeComponentRows(): RevisionGridRow[] {
  return [
    {
      id: 'red',
      poId: 'po-1',
      poCode: 'PO-1',
      destination: 'US',
      color: 'Red',
      teamId: 'team-red',
      teamName: 'Team red',
      rowIndex: 0,
      total: 36,
      S: 36,
    },
    {
      id: 'blue',
      poId: 'po-1',
      poCode: 'PO-1',
      destination: 'US',
      color: 'Blue',
      teamId: 'team-blue',
      teamName: 'Team blue',
      rowIndex: 0,
      total: 50,
      S: 50,
    },
  ]
}

function makeManualOrder(): ProductionOrderVm {
  return makeOrder(
    [
      makeAssignment({
        id: 'red-assignment',
        teamId: 'team-red',
        operation: 'SEW-1',
        color: 'Red',
        quantity: 36,
        notes: ['keep-red'],
        deliveryDate: '2026-07-30',
        checkDate: '2026-07-29',
      }),
      makeAssignment({
        id: 'blue-assignment',
        teamId: 'team-blue',
        operation: 'SEW-1',
        color: 'Blue',
        quantity: 50,
        notes: ['keep-blue'],
      }),
    ],
    [
      { color: 'Red', size: 'S' },
      { color: 'Red', size: 'M' },
      { color: 'Blue', size: 'S' },
    ],
  )
}

function makeSingleModeOrder(): ProductionOrderVm {
  return makeOrder(
    [
      makeAssignment({
        id: 'cut',
        teamId: 'cut-team',
        operation: 'CUT',
        color: 'Red',
        quantity: 10,
      }),
    ],
    [{ color: 'Red', size: 'S' }],
  )
}

function makeOrder(
  teamAssignments: TeamAssignmentVm[],
  historicalColorSizePairs: ProductionOrderVm['historicalColorSizePairs'],
): ProductionOrderVm {
  return {
    id: 'order-1',
    code: 'LSX-1',
    poCode: 'PO-1',
    buyerOrderId: 'buyer-order-1',
    mainCompanyCode: 'LGG-BG',
    factories: [],
    styleName: 'Style',
    status: 'IN_PROGRESS',
    teamCount: teamAssignments.length,
    sewingTeams: [],
    totalQuantity: 270,
    createdAt: '2026-07-20',
    poSummaries: [
      {
        poId: 'po-1',
        poCode: 'PO-1',
        destination: 'US',
        totalQuantity: 270,
        completedQuantity: 0,
        progressPercentage: 0,
      },
    ],
    teamAssignments,
    historicalColorSizePairs,
    needsAllocationRevision: false,
  }
}

function makeAssignment(params: {
  id: string
  teamId: string
  operation: string
  color: string
  quantity: number
  notes?: string[]
  deliveryDate?: string
  checkDate?: string
}): TeamAssignmentVm {
  return {
    id: params.id,
    teamId: params.teamId,
    teamName: params.teamId,
    factoryName: 'Factory',
    companyName: 'Company',
    operation: params.operation,
    allocations: [
      {
        purchaseOrderId: 'po-1',
        color: params.color,
        size: 'S',
        quantity: params.quantity,
        notes: params.notes ?? [],
        deliveryDate: params.deliveryDate,
        checkDate: params.checkDate,
      },
    ],
    outputReportTotals: [],
    inputReportTotals: [],
    totalReported: 0,
    assignedAt: '2026-07-20',
    code: 'LSX-1',
    reconciliationStatus: 'NORMAL',
    displayStatus: 'NOT_STARTED',
    hasPendingMaterialSupplement: false,
  }
}

function makeBuyerOrder(
  skuQuantities: BuyerOrderDetailVm['purchaseOrders'][number]['skuQuantities'] = [
    { color: 'Red', size: 'S', quantity: 100, remainingQuantity: 64 },
    { color: 'Red', size: 'M', quantity: 20, remainingQuantity: 20 },
    { color: 'Blue', size: 'S', quantity: 150, remainingQuantity: 100 },
    { color: 'Blue', size: 'M', quantity: 999, remainingQuantity: 999 },
  ],
): BuyerOrderDetailVm {
  return {
    id: 'buyer-order-1',
    wfxId: 'WFX-1',
    styleName: 'Style',
    customer: 'Customer',
    brand: 'Brand',
    season: 'Season',
    status: 'PROCESSING',
    receivedDate: '2026-07-01',
    totalQuantity: 270,
    styleColorOrder: ['Red', 'Blue'],
    styleSizeOrder: ['S', 'M'],
    purchaseOrders: [
      {
        id: 'po-1',
        wfxId: 'WFX-PO-1',
        code: 'PO-1',
        destination: 'US',
        deliveryDate: '2026-08-01',
        totalQuantity: 270,
        skuQuantities,
        type: 'REGULAR',
      },
    ],
    routings: [],
    needsAllocationRevision: false,
  }
}
