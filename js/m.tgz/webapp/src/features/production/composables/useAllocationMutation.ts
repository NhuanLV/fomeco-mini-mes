import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { storeToRefs } from 'pinia'
import type { PoColorKey, RowMeta, SkuKey } from '../types'
export function useAllocationMutations() {
  const issuanceStore = useProductionOrderIssuanceStore()
  const { matrices, subTotalMap, demandMaps } = storeToRefs(issuanceStore)
  const { triggerMatrices } = issuanceStore

  // Cập nhật số lượng 1 ô
  function updateQty(matrixIdx: number, skuKey: SkuKey, rowIndex: number, value: number) {
    const matrix = matrices.value[matrixIdx]
    if (!matrix) return
    const isMaster = matrixIdx === 0
    const totalForSku = isMaster ? matrix.totalMap[skuKey] || 0 : subTotalMap.value[skuKey] || 0
    const qtys = matrix.qtyMap[skuKey] || [0]
    const otherRowsSum = qtys.reduce((sum, v, idx) => (idx === rowIndex ? sum : sum + v), 0)
    const maxAllowed = Math.max(0, totalForSku - otherRowsSum)
    const clampedValue = Math.min(Math.max(0, value), maxAllowed)
    if (!matrix.qtyMap[skuKey]) matrix.qtyMap[skuKey] = []
    matrix.qtyMap[skuKey][rowIndex] = clampedValue
    triggerMatrices()
  }
  // Chia dòng
  function splitRow(matrixIdx: number, poColorKey: PoColorKey) {
    const matrix = matrices.value[matrixIdx]
    if (!matrix) return
    for (const skuKey in matrix.qtyMap) {
      if (skuKey.startsWith(`${poColorKey}|`)) {
        matrix.qtyMap[skuKey].push(0)
      }
    }
    matrix.rowMetaMap[poColorKey].push({
      teamId: null,
      teamName: '',
      deliveryDate: matrix.rowMetaMap[poColorKey][0]?.deliveryDate,
      notes: [],
    })
    triggerMatrices()
  }
  // Xoá 1 dòng
  function deleteRow(matrixIdx: number, poColorKey: PoColorKey, rowIndex: number) {
    const matrix = matrices.value[matrixIdx]
    if (!matrix) return
    if (matrix.rowMetaMap[poColorKey].length <= 1) return
    for (const skuKey in matrix.qtyMap) {
      if (skuKey.startsWith(`${poColorKey}|`)) {
        matrix.qtyMap[skuKey].splice(rowIndex, 1)
      }
    }
    matrix.rowMetaMap[poColorKey].splice(rowIndex, 1)
    triggerMatrices()
  }

  function fillRow(matrixIdx: number, poColorKey: PoColorKey, rowIndex: number) {
    const matrix = matrices.value[matrixIdx]
    const dMap = demandMaps.value[matrixIdx]
    if (!matrix || !dMap) return
    for (const skuKey in matrix.qtyMap) {
      if (skuKey.startsWith(`${poColorKey}|`)) {
        const remainingDemand = dMap[skuKey]?.[rowIndex] || 0
        matrix.qtyMap[skuKey][rowIndex] += remainingDemand
      }
    }
    triggerMatrices()
  }
  function updateMeta(
    matrixIdx: number,
    poColorKey: PoColorKey,
    rowIndex: number,
    patch: Partial<RowMeta>,
  ) {
    const matrix = matrices.value[matrixIdx]
    if (!matrix) return
    const meta = matrix.rowMetaMap[poColorKey][rowIndex]
    if (meta) {
      Object.assign(meta, patch)
      triggerMatrices()
    }
  }
  return {
    updateQty,
    splitRow,
    deleteRow,
    fillRow,
    updateMeta,
  }
}
