import type { PurchaseOrderVm } from '@/api'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { storeToRefs } from 'pinia'
import type { AllocationMatrix, PoColorKey, RowMeta, SkuKey } from '../types'

export function useAllocationInit() {
  const { selectedRouting, selectedPOs, teams, opNames, autoOps, matrices } = storeToRefs(
    useProductionOrderIssuanceStore(),
  )
  function init() {
    const routing = selectedRouting.value
    const pos = selectedPOs.value
    if (!routing || pos.length === 0) return
    const newOpNames: string[] = []
    const newAutoOps: { opName: string; teamId: string; teamName: string }[] = []
    const newMatrices: AllocationMatrix[] = []
    routing.operations.forEach((opName) => {
      newOpNames.push(opName)
      const opTeams = teams.value.filter((t) => t.operation === opName)
      const isAuto = opTeams.length === 1
      if (isAuto) {
        newAutoOps.push({
          opName: opName,
          teamId: opTeams[0].id,
          teamName: opTeams[0].name,
        })
      } else {
        const isMaster = newMatrices.length === 0
        newMatrices.push({
          opName: opName,
          qtyMap: buildQtyMap(pos),
          totalMap: isMaster ? buildTotalMap(pos) : {},
          rowMetaMap: buildRowMetaMap(pos),
        })
      }
    })
    if (newMatrices.length === 0 && newAutoOps.length > 0) {
      newMatrices.push({
        opName: newAutoOps[0].opName,
        qtyMap: buildQtyMap(pos),
        totalMap: buildTotalMap(pos),
        rowMetaMap: buildRowMetaMap(pos),
      })
    }
    opNames.value = newOpNames
    autoOps.value = newAutoOps
    matrices.value = newMatrices
  }
  function buildQtyMap(pos: PurchaseOrderVm[]): Record<SkuKey, number[]> {
    const map: Record<SkuKey, number[]> = {}
    pos.forEach((po) => {
      po.skuQuantities.forEach((sku) => {
        if (sku.remainingQuantity > 0) {
          const key: SkuKey = `${po.id}|${sku.color}|${sku.size}`
          map[key] = [0]
        }
      })
    })
    return map
  }

  function buildTotalMap(pos: PurchaseOrderVm[]): Record<SkuKey, number> {
    const map: Record<SkuKey, number> = {}
    pos.forEach((po) => {
      po.skuQuantities.forEach((sku) => {
        if (sku.remainingQuantity > 0) {
          const key: SkuKey = `${po.id}|${sku.color}|${sku.size}`
          map[key] = sku.remainingQuantity
        }
      })
    })
    return map
  }
  function buildRowMetaMap(pos: PurchaseOrderVm[]): Record<PoColorKey, RowMeta[]> {
    const map: Record<PoColorKey, RowMeta[]> = {}
    pos.forEach((po) => {
      const colorsInPo = new Set(
        po.skuQuantities.filter((s) => s.remainingQuantity > 0).map((s) => s.color),
      )
      colorsInPo.forEach((color) => {
        const key: PoColorKey = `${po.id}|${color}`
        map[key] = [
          {
            teamId: null,
            teamName: '',
            deliveryDate: po.deliveryDate,
            notes: [],
          },
        ]
      })
    })
    return map
  }
  return { init }
}
