import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import type { MatrixGridEdit } from '@/shared/components/grid/matrixGrid'
import { storeToRefs } from 'pinia'
import type { AllocationGridRow, PoColorKey, SkuKey } from '../types'
import { type ComputedRef } from 'vue'
import { useAllocationMutations } from './useAllocationMutation'
export function useAllocationActions(
  opName: string,
  filteredSource: ComputedRef<AllocationGridRow[]>,
) {
  const { allSizes, matrices, teams } = storeToRefs(useProductionOrderIssuanceStore())
  const { updateQty, updateMeta, splitRow, deleteRow } = useAllocationMutations()
  function updateRowData(filteredRowIndex: number, prop: string, val: unknown) {
    const gridRow = filteredSource.value[filteredRowIndex]
    const currentMatrixIdx = matrices.value.findIndex((m) => m.opName === opName)
    if (!gridRow || currentMatrixIdx === -1) return
    const poColorKey: PoColorKey = `${gridRow.poId}|${gridRow.color}`
    const rowIndex = gridRow.rowIndex
    if (allSizes.value.includes(prop)) {
      const skuKey: SkuKey = `${poColorKey}|${prop}`
      const parsedValue = parseInt(String(val), 10)
      if (isNaN(parsedValue)) return
      updateQty(currentMatrixIdx, skuKey, rowIndex, parsedValue)
    } else if (prop === 'teamId') {
      const teamId = String(val ?? '').trim()
      const normalizedTeamId = teamId.length > 0 ? teamId : null
      const team = teams.value.find((t) => t.id === normalizedTeamId)
      updateMeta(currentMatrixIdx, poColorKey, rowIndex, {
        teamId: normalizedTeamId,
        teamName: team ? `${team.name} - ${team.factoryName} - ${team.companyName}` : '',
      })
    } else if (prop === 'deliveryDate' || prop === 'checkDate') {
      const valStr = String(val ?? '')
      const dateRegex = /^\d{4}-\d{2}-\d{2}$/
      if (valStr === '' || dateRegex.test(valStr)) {
        updateMeta(currentMatrixIdx, poColorKey, rowIndex, { [prop]: valStr })
      }
    } else if (prop.startsWith('note_')) {
      const noteIdx = parseInt(prop.slice(5), 10)
      const matrix = matrices.value[currentMatrixIdx]
      const currentNotes = [...(matrix.rowMetaMap[poColorKey][rowIndex].notes || [])]
      while (currentNotes.length <= noteIdx) currentNotes.push('')
      currentNotes[noteIdx] = String(val ?? '')
      updateMeta(currentMatrixIdx, poColorKey, rowIndex, { notes: currentNotes })
    }
  }
  function handleAfterEdit(edits: MatrixGridEdit[]) {
    for (const edit of edits) updateRowData(edit.rowIndex, edit.prop, edit.value)
  }
  function handleSplit(gridRow: AllocationGridRow) {
    const currentMatrixIdx = matrices.value.findIndex((m) => m.opName === opName)
    const poColorKey: PoColorKey = `${gridRow.poId}|${gridRow.color}`
    splitRow(currentMatrixIdx, poColorKey)
  }
  function handleDelete(gridRow: AllocationGridRow) {
    const currentMatrixIdx = matrices.value.findIndex((m) => m.opName === opName)
    const poColorKey: PoColorKey = `${gridRow.poId}|${gridRow.color}`
    deleteRow(currentMatrixIdx, poColorKey, gridRow.rowIndex)
  }
  return {
    handleAfterEdit,
    handleSplit,
    handleDelete,
  }
}
