import { issueProductionOrder } from '@/api'
import {
  buildProductionOrderIssueCommand,
  findDuplicateTeamAssignments,
  findMissingTeamAssignments,
} from '@/features/production/production-order-issuance/productionOrderIssuance'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { clearLoading, showError, showLoading } from '@/shared/utils/toast'
import { storeToRefs } from 'pinia'
import { shallowRef } from 'vue'

export function wfxSyncErrorMessage(error: unknown) {
  const message =
    error instanceof Error
      ? error.message
      : typeof error === 'object' &&
          error !== null &&
          'message' in error &&
          typeof error.message === 'string'
        ? error.message
        : 'Lỗi không xác định'
  return `Đồng bộ WFX thất bại: ${message}`
}

export function useOrderSubmit() {
  const {
    selectedPOs,
    buyerOrder,
    selectedFactoryIds,
    mainCompanyCode,
    matrices,
    autoOps,
    allOperationsAuto,
    subTotalMap,
    syncDate,
    productDate,
    firstSku,
    plannedDates,
    opNames,
    totalSummaryQty,
  } = storeToRefs(useProductionOrderIssuanceStore())
  const submitting = shallowRef(false)
  const submissionError = shallowRef('')

  function poCodeById() {
    return new Map(selectedPOs.value.map((po) => [po.id, po.code]))
  }

  function checkDuplicateTeamAssignments() {
    if (allOperationsAuto.value) return []
    return findDuplicateTeamAssignments(matrices.value, poCodeById())
  }

  function checkMissingTeamAssignments() {
    if (allOperationsAuto.value) return []
    return findMissingTeamAssignments(matrices.value, poCodeById())
  }

  async function submitOrder(): Promise<boolean> {
    const command = buildProductionOrderIssueCommand({
      buyerOrderId: buyerOrder.value!.id,
      factoryIds: selectedFactoryIds.value,
      mainCompanyCode: mainCompanyCode.value,
      selectedPOs: selectedPOs.value,
      matrices: matrices.value,
      autoOps: autoOps.value,
      allOperationsAuto: allOperationsAuto.value,
      subTotalMap: subTotalMap.value,
      opNames: opNames.value,
      totalSummaryQty: totalSummaryQty.value,
      syncDate: syncDate.value,
      productDate: productDate.value,
      firstSku: firstSku.value,
      plannedDates: plannedDates.value,
    })
    if (!command.ok) {
      showError(command.error)
      return false
    }

    submissionError.value = ''
    submitting.value = true
    showLoading('Đang tạo FPO/FPPO trên WFX...', 'Đang phát lệnh', 'fppo-sync')
    try {
      await issueProductionOrder({ body: command.body })
      return true
    } catch (error) {
      submissionError.value = wfxSyncErrorMessage(error)
      return false
    } finally {
      clearLoading('fppo-sync')
      submitting.value = false
    }
  }

  return {
    checkDuplicateTeamAssignments,
    submitOrder,
    checkMissingTeamAssignments,
    submitting,
    submissionError,
  }
}
