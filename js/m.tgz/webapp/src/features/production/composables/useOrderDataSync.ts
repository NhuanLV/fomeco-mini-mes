import type { BuyerOrderDetailVm, GetTreeResponse, UnitVm } from '@/api'
import { defaultSelectedPurchaseOrderIds } from '@/features/production/production-order-issuance/productionOrderIssuance'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { storeToRefs } from 'pinia'
import type { TeamVm } from '../types'

export function useOrderDataSync() {
  const {
    buyerOrder,
    selectedPOIds,
    selectedRoutingIndex,
    matrices,
    autoOps,
    opNames,
    teams,
    factories,
  } = storeToRefs(useProductionOrderIssuanceStore())

  function setOrderData(data: BuyerOrderDetailVm | null | undefined) {
    if (!data) return
    const isNewBO = buyerOrder.value?.id !== data.id
    buyerOrder.value = data
    if (isNewBO) {
      selectedPOIds.value = defaultSelectedPurchaseOrderIds(data.purchaseOrders)
      selectedRoutingIndex.value = data.routings.length === 1 ? 0 : null
      matrices.value = []
      autoOps.value = []
      opNames.value = []
    }
  }

  function setTeamsData(
    data: UnitVm[] | null | undefined,
    treeData: GetTreeResponse | null | undefined,
  ) {
    if (!data) return
    const roots: UnitVm[] = Array.isArray(treeData) ? treeData : treeData ? [treeData] : []
    const newTeams: TeamVm[] = data
      .map((t) => {
        let factoryName = 'Unknown'
        let companyName = 'Unknown'

        for (const corp of roots) {
          if (corp.children) {
            for (const company of corp.children) {
              const factory = company.children?.find((f) =>
                f.children?.some((team) => team.id === t.id),
              )
              if (factory) {
                factoryName = factory.name
                companyName = company.name
                break
              }
            }
          }
        }
        return {
          id: t.id,
          name: t.name,
          operation: t.operations?.[0] || '',
          isActive: t.isActive ?? true,
          factoryName,
          companyName,
        }
      })
      .filter((t) => t.operation !== '')

    const currentTeamIds = teams.value
      .map((t) => t.id)
      .sort()
      .join(',')
    const newTeamIds = newTeams
      .map((t) => t.id)
      .sort()
      .join(',')
    const teamsChanged = currentTeamIds !== newTeamIds

    teams.value = newTeams
    if (teamsChanged) {
      matrices.value = []
      autoOps.value = []
      opNames.value = []
    }
  }

  function setTreeData(data: GetTreeResponse | null | undefined) {
    if (!data) return
    const allFactories: UnitVm[] = []
    const roots: UnitVm[] = Array.isArray(data) ? data : [data]
    roots.forEach((corp: UnitVm) => {
      corp.children?.forEach((company: UnitVm) => {
        company.children?.forEach((factory: UnitVm) => {
          if (factory.type === 'FACTORY')
            allFactories.push({
              ...factory,
              companyName: company.name,
              companyCode: company.code,
            } as UnitVm)
        })
      })
    })
    factories.value = allFactories
  }

  return { setOrderData, setTeamsData, setTreeData }
}
