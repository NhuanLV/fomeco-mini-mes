import { useAllocationInit } from '@/features/production/composables/useAllocationInit'
import { useOrderSubmit } from '@/features/production/composables/useOrderSubmit'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { showError } from '@/shared/utils/toast'
import { storeToRefs } from 'pinia'
import { shallowRef } from 'vue'

export function useStepNavigation() {
  const issuanceStore = useProductionOrderIssuanceStore()
  const { currentStep } = storeToRefs(issuanceStore)
  const { goToStep, isCurrentStep, validateStep1, validateStep2 } = issuanceStore
  const { init: initAllocations } = useAllocationInit()
  const {
    checkDuplicateTeamAssignments,
    submitOrder,
    checkMissingTeamAssignments,
    submitting,
    submissionError,
  } = useOrderSubmit()

  const showDuplicateDialog = shallowRef(false)
  const duplicateWarnings = shallowRef<string[]>([])

  function goToStep1() {
    goToStep('1')
  }

  function goToStep2() {
    const error = validateStep1()
    if (error) {
      showError(error)
      return
    }

    if (issuanceStore.matrices.length === 0) {
      initAllocations()
    }

    goToStep('2')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function goToStep3() {
    goToStep('3')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function backToStep2() {
    goToStep('2')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function handleSubmit() {
    const dupes = checkDuplicateTeamAssignments()
    const missing = checkMissingTeamAssignments()

    const error = validateStep2(missing)
    if (error) {
      showError(error)
      return
    }

    if (dupes.length > 0) {
      duplicateWarnings.value = dupes
      showDuplicateDialog.value = true
      return
    }

    goToStep3()
  }

  function closeDuplicateDialog() {
    showDuplicateDialog.value = false
  }

  function doSubmit(): Promise<boolean> {
    closeDuplicateDialog()
    issuanceStore.hasAttemptedSubmit = true
    const error = issuanceStore.validateStep3()
    if (error) {
      showError(error)
      return Promise.resolve(false)
    }
    return submitOrder()
  }

  return {
    showDuplicateDialog,
    duplicateWarnings,
    closeDuplicateDialog,
    goToStep1,
    goToStep2,
    backToStep2,
    handleSubmit,
    doSubmit,
    submitting,
    submissionError,
    stepValue: currentStep,
    isCurrent: isCurrentStep,
  }
}
