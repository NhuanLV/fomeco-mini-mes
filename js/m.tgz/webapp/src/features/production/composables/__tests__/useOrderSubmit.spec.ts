import { wfxSyncErrorMessage } from '@/features/production/composables/useOrderSubmit'
import { describe, expect, it } from 'vitest'

describe('wfxSyncErrorMessage', () => {
  it('keeps the backend WFX message unchanged', () => {
    const message =
      'Error in procedures:xspFPOConfirmation, message: Please Cancel The OutSource FPPO (8291) of FPO(1559-1)., line: 544'

    expect(wfxSyncErrorMessage({ message })).toBe(`Đồng bộ WFX thất bại: ${message}`)
  })

  it('supports network errors and unknown failures', () => {
    expect(wfxSyncErrorMessage(new Error('Network error'))).toBe(
      'Đồng bộ WFX thất bại: Network error',
    )
    expect(wfxSyncErrorMessage(null)).toBe('Đồng bộ WFX thất bại: Lỗi không xác định')
  })
})
