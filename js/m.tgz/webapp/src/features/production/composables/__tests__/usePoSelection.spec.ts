import { usePoSelection } from '@/features/production/composables/usePoSelection'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'

describe('usePoSelection', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  const mockBuyerOrder = {
    id: 'bo-1',
    wfxId: 'WFX-1',
    styleName: 'Style A',
    customer: 'Cust A',
    brand: 'Brand A',
    season: 'SS26',
    status: 'NEW' as const,
    receivedDate: '2026-08-01T00:00:00Z',
    totalQuantity: 100,
    styleColorOrder: ['Red'],
    styleSizeOrder: ['S'],
    needsAllocationRevision: false,
    routings: [],
    purchaseOrders: [
      {
        id: 'po-reg-1',
        wfxId: 'PO-REG-1',
        code: 'REG1',
        destination: 'US',
        deliveryDate: '2026-09-01',
        totalQuantity: 50,
        type: 'REGULAR' as const,
        skuQuantities: [{ color: 'Red', size: 'S', quantity: 50, remainingQuantity: 50 }],
      },
      {
        id: 'po-reg-2',
        wfxId: 'PO-REG-2',
        code: 'REG2',
        destination: 'US',
        deliveryDate: '2026-09-01',
        totalQuantity: 30,
        type: 'REGULAR' as const,
        skuQuantities: [{ color: 'Red', size: 'S', quantity: 30, remainingQuantity: 30 }],
      },
      {
        id: 'po-pos-1',
        wfxId: '',
        code: 'POS1',
        destination: 'US',
        deliveryDate: '2026-09-01',
        totalQuantity: 20,
        type: 'POSITIVE' as const,
        skuQuantities: [{ color: 'Red', size: 'S', quantity: 20, remainingQuantity: 20 }],
      },
    ],
  }

  it('toggles PO of same type normally', () => {
    const store = useProductionOrderIssuanceStore()
    store.buyerOrder = mockBuyerOrder
    store.selectedPOIds = ['po-reg-1']

    const { togglePO } = usePoSelection()
    togglePO('po-reg-2')
    expect(store.selectedPOIds).toEqual(['po-reg-1', 'po-reg-2'])

    togglePO('po-reg-1')
    expect(store.selectedPOIds).toEqual(['po-reg-2'])
  })

  it('keeps selections across PO types', () => {
    const store = useProductionOrderIssuanceStore()
    store.buyerOrder = mockBuyerOrder
    store.selectedPOIds = ['po-reg-1', 'po-reg-2']

    const { togglePO } = usePoSelection()
    togglePO('po-pos-1')

    // Both types stay selected
    expect(store.selectedPOIds).toEqual(['po-reg-1', 'po-reg-2', 'po-pos-1'])

    // Toggling a selected regular PO only removes that PO
    togglePO('po-reg-1')
    expect(store.selectedPOIds).toEqual(['po-reg-2', 'po-pos-1'])
  })

  it('handles toggleAllFiltered for different types', () => {
    const store = useProductionOrderIssuanceStore()
    store.buyerOrder = mockBuyerOrder
    store.selectedPOIds = ['po-reg-1']

    const { toggleAllFiltered } = usePoSelection()
    // Select all positive POs
    toggleAllFiltered(true, ['po-pos-1'])
    expect(store.selectedPOIds).toEqual(['po-reg-1', 'po-pos-1'])

    // Select all regular POs
    toggleAllFiltered(true, ['po-reg-1', 'po-reg-2'])
    expect(store.selectedPOIds).toEqual(['po-reg-1', 'po-pos-1', 'po-reg-2'])

    // Deselect filtered
    toggleAllFiltered(false, ['po-reg-1'])
    expect(store.selectedPOIds).toEqual(['po-pos-1', 'po-reg-2'])
  })
})
