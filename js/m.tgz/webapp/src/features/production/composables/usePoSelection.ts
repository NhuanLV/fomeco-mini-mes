import { togglePurchaseOrderSelection } from '@/features/production/production-order-issuance/productionOrderIssuance'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { storeToRefs } from 'pinia'

export function usePoSelection() {
  const { buyerOrder, selectedPOIds } = storeToRefs(useProductionOrderIssuanceStore())

  function poHasRemaining(id: string): boolean {
    const po = buyerOrder.value?.purchaseOrders.find((p) => p.id === id)
    return po ? po.skuQuantities.some((sku) => sku.remainingQuantity > 0) : false
  }

  function togglePO(id: string) {
    selectedPOIds.value = togglePurchaseOrderSelection(selectedPOIds.value, id, poHasRemaining(id))
  }

  function toggleAllFiltered(selected: boolean, filteredPOIds: string[]) {
    if (selected) {
      selectedPOIds.value = filteredPOIds.reduce(
        (current, id) =>
          current.includes(id)
            ? current
            : togglePurchaseOrderSelection(current, id, poHasRemaining(id)),
        selectedPOIds.value,
      )
    } else {
      selectedPOIds.value = selectedPOIds.value.filter((id) => !filteredPOIds.includes(id))
    }
  }

  return { togglePO, toggleAllFiltered }
}
