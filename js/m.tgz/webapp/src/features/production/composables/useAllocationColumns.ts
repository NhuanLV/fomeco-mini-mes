import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import type { GridColumn, GridRow } from '@/shared/composables/useGridLayout'
import { formatDate } from '@/shared/utils/date'
import { fmtQty } from '@/shared/utils/fmtQty'
import { getMatrixQtyDisplayValue } from '@/shared/utils/matrixQtyDisplay'
import { storeToRefs } from 'pinia'
import { computed, type ComputedRef } from 'vue'

export function useAllocationColumns(
  opName: string,
  readonly: boolean,
  teamOptions: ComputedRef<Array<{ label: string; value: string }>>,
) {
  const { allSizes, noteColumnCount, allOperationsAuto } = storeToRefs(
    useProductionOrderIssuanceStore(),
  )

  const columns = computed((): GridColumn[] => {
    const poInfoCols: GridColumn[] = [
      {
        prop: 'poCode',
        name: 'Mã PO',
        pin: 'colPinStart',
        readonly: true,
        cellTemplate: (_h, { model }) => {
          return (model as { displayPoCode?: string }).displayPoCode ?? model.poCode ?? ''
        },
      },
      {
        prop: 'purchaseOrderType',
        name: 'Loại PO',
        pin: 'colPinStart',
        readonly: true,
        cellTemplate: (h, { model }) =>
          h(
            'span',
            {
              class: [
                'rounded px-2 py-1 text-xs',
                model.purchaseOrderType === 'POSITIVE'
                  ? 'bg-info/10 text-info'
                  : 'bg-success/10 text-success',
              ],
            },
            model.purchaseOrderType === 'POSITIVE' ? 'Hàng dương' : 'Hàng thường',
          ),
      },
      {
        prop: 'destination',
        name: 'Thị trường',
        pin: 'colPinStart',
        readonly: true,
      },
      {
        prop: 'color',
        name: 'Màu',
        pin: 'colPinStart',
        readonly: true,
        columnType: 'color',
        extraWidth: 28,
      },
    ]

    const sizeCols: GridColumn[] = allSizes.value.map((size) => ({
      prop: size,
      name: size,
      readonly: readonly,
      columnType: readonly ? 'sizeReadonly' : 'size',
    }))

    const dateCols: GridColumn[] = [
      {
        prop: 'deliveryDate',
        name: 'Ngày giao hàng',
        readonly: readonly,
        columnType: readonly ? undefined : 'date',
        cellTemplate: (h, { model }) => {
          return model.deliveryDate ? formatDate(model.deliveryDate) : ''
        },
      },
      {
        prop: 'checkDate',
        name: 'Ngày kiểm hàng',
        readonly: readonly,
        columnType: readonly ? undefined : 'date',
        cellTemplate: (h, { model }) => {
          return model.checkDate ? formatDate(model.checkDate) : ''
        },
      },
    ]

    const noteCols: GridColumn[] = Array.from({ length: noteColumnCount.value }, (_, i) => ({
      prop: `note_${i}`,
      name: `Ghi chú ${i + 1}`,
      readonly: readonly,
      columnType: readonly ? undefined : 'note',
    }))

    const actionCols: GridColumn[] = [
      {
        prop: 'total',
        name: 'Tổng',
        pin: 'colPinEnd',
        readonly: true,
        cellProperties: () => ({ class: 'font-mono font-bold text-primary' }),
      },
      readonly
        ? {
            prop: 'teamName',
            name: 'Tổ',
            pin: 'colPinEnd',
            readonly: true,
          }
        : {
            prop: 'teamId',
            name: 'Tổ',
            pin: 'colPinEnd',
            readonly: false,
            columnType: 'select',
            source: teamOptions.value,
            labelKey: 'label',
            valueKey: 'value',
            cellTemplate: (_h, { model }) => {
              const options = Array.isArray(model.teamOptions) ? model.teamOptions : []
              const selected = options.find((option) => option.value === model.teamId)
              return selected?.label || ''
            },
          },
    ]

    return [
      ...poInfoCols,
      ...sizeCols,
      ...dateCols,
      ...noteCols,
      ...actionCols.filter((column) => !allOperationsAuto.value || column.prop === 'total'),
    ]
  })

  const displayRows = (rows: GridRow[]): GridRow[] =>
    rows.map((row, index) => ({
      ...row,
      displayPoCode:
        index === 0 || row.poCode !== rows[index - 1]?.poCode ? (row.poCode as string) : '',
      ...Object.fromEntries(
        allSizes.value.map((size) => [size, getMatrixQtyDisplayValue(row, size)]),
      ),
      total: row.total !== undefined && row.total !== null ? fmtQty(row.total as number) : '-',
      teamId:
        teamOptions.value.find((o) => String(o.value) === String(row.teamId))?.label ??
        String(row.teamId ?? ''),
    }))

  return { columns, displayRows }
}
