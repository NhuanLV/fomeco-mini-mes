import { downloadAllocationTemplate as downloadAllocationTemplateApi } from '@/api'
import { useAllocationInit } from '@/features/production/composables/useAllocationInit'
import { downloadAllocationTemplate as exportAllocationExcel } from '@/features/production/helpers/allocationExcelTemplate'
import {
  buildTeamOptionLabel,
  defaultAllocationExcelTeamMatcher,
  type PendingTeamResolutionRow,
} from '@/features/production/helpers/allocationExcelTeamMatcher'
import {
  extractMetadata,
  extractRows,
  transformExcelToOpData,
  type ExcelDataMap,
  type ExcelImportRow,
} from '@/features/production/helpers/allocationExcelTransformer'
import { validateExcelAllocation } from '@/features/production/helpers/allocationExcelValidator'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { showError, showSuccess } from '@/shared/utils/toast'
import { storeToRefs } from 'pinia'
import { computed, shallowRef } from 'vue'
import * as XLSX from 'xlsx'
import type { SkuKey, TeamVm } from '../types'

function normalizeOperationName(value: string): string {
  return value.trim().toLowerCase()
}

function buildTeamOptions(teams: TeamVm[]) {
  return teams
    .map((team) => ({
      label: buildTeamOptionLabel(team),
      value: team.id,
    }))
    .sort((left, right) =>
      left.label.localeCompare(right.label, undefined, { sensitivity: 'base' }),
    )
}

export function useAllocationExcel() {
  const issuanceStore = useProductionOrderIssuanceStore()
  const {
    buyerOrder,
    selectedPOs,
    selectedRouting,
    allSizes,
    matrices,
    autoOps,
    opNames,
    teams,
    noteColumnCount,
    syncDate,
    productDate,
    firstSku,
    subTotalMap,
    selectedFactoryIds,
    selectedRoutingIndex,
    selectedPOIds,
  } = storeToRefs(issuanceStore)
  const { isCurrentStep, setPlannedDates, triggerMatrices } = issuanceStore
  const isImporting = shallowRef(false)
  const importRequestId = shallowRef(0)
  const showTeamResolutionDialog = shallowRef(false)
  const pendingTeamResolutionRows = shallowRef<PendingTeamResolutionRow[]>([])
  const pendingImportPayload = shallowRef<{
    rows: ExcelImportRow[]
    sizeColumns: string[]
    metaData: {
      syncDate: Date | null
      productDate: Date | null
      firstSku: string
    }
    resolvedTeamIdsByRowNumber: Map<number, string>
  } | null>(null)
  const allocationInit = useAllocationInit()

  const manualTeamOptionsByOperation = computed(() => {
    const optionsByOperation = new Map<string, Array<{ label: string; value: string }>>()
    matrices.value.forEach((matrix) => {
      const operationName = normalizeOperationName(matrix.opName)
      const operationTeams = teams.value.filter(
        (team) => normalizeOperationName(team.operation) === operationName,
      )
      optionsByOperation.set(operationName, buildTeamOptions(operationTeams))
    })
    return optionsByOperation
  })

  const importCandidateTeams = computed(() => {
    const allowedOperations = new Set(manualTeamOptionsByOperation.value.keys())
    return teams.value.filter((team) =>
      allowedOperations.has(normalizeOperationName(team.operation)),
    )
  })

  const teamResolutionOptionsByRowKey = computed(() =>
    Object.fromEntries(
      pendingTeamResolutionRows.value.map((row) => [
        row.key,
        manualTeamOptionsByOperation.value.get(normalizeOperationName(row.operationName)) ?? [],
      ]),
    ),
  )

  const resetImportState = () => {
    syncDate.value = null
    productDate.value = null
    firstSku.value = ''
    noteColumnCount.value = 0
    allocationInit.init()
  }

  const closeTeamResolutionDialog = () => {
    showTeamResolutionDialog.value = false
    pendingTeamResolutionRows.value = []
    pendingImportPayload.value = null
  }

  const updatePendingTeamResolution = (key: string, teamId: string | null) => {
    const row = pendingTeamResolutionRows.value.find((item) => item.key === key)
    if (!row) return
    row.selectedTeamId = teamId
    pendingTeamResolutionRows.value = [...pendingTeamResolutionRows.value]
  }

  const hasIncompleteTeamResolutions = computed(() =>
    pendingTeamResolutionRows.value.some((row) => !row.selectedTeamId),
  )

  const calculateMaxNoteCount = (excelOpData: ExcelDataMap) => {
    let maxExcelNotes = 0
    excelOpData.forEach((poMap) => {
      poMap.forEach((teamMap) => {
        teamMap.forEach((entry) => {
          if (entry.meta.notes) {
            maxExcelNotes = Math.max(maxExcelNotes, entry.meta.notes.length)
          }
        })
      })
    })
    return maxExcelNotes
  }

  const resetMatricesData = () => {
    matrices.value.forEach((matrix) => {
      selectedPOs.value.forEach((po) => {
        const colors = [...new Set(po.skuQuantities.map((s) => s.color))]
        colors.forEach((color) => {
          const poColorKey = `${po.id}|${color}`
          matrix.rowMetaMap[poColorKey] = [
            {
              teamId: null,
              teamName: '',
              deliveryDate: undefined,
              checkDate: undefined,
              notes: [],
            },
          ]
          po.skuQuantities.forEach((sku) => {
            if (sku.color === color && sku.quantity > 0) {
              const skuKey: SkuKey = `${po.id}|${color}|${sku.size}`
              matrix.qtyMap[skuKey] = [0]
            }
          })
        })
      })
    })
  }

  const applyExcelToStore = (excelOpData: ExcelDataMap) => {
    let appliedRowCount = 0
    matrices.value.forEach((matrix) => {
      const matchedKey = Array.from(excelOpData.keys()).find(
        (key) => key.toLowerCase() === matrix.opName.toLowerCase(),
      )
      const opData = matchedKey ? excelOpData.get(matchedKey) : undefined

      if (!opData) return

      opData.forEach((teamMap, poColorKey) => {
        if (!matrix.rowMetaMap[poColorKey]) return

        const teamIds = Array.from(teamMap.keys())
        if (teamIds.length === 0) return

        appliedRowCount += teamIds.length

        // Ghi đè RowMeta hoàn toàn từ Excel
        matrix.rowMetaMap[poColorKey] = teamIds.map((tId) => {
          const normalizedTeamId = tId.trim().length > 0 ? tId : null
          const t = teams.value.find((item) => item.id === normalizedTeamId)
          const excelEntry = teamMap.get(tId)!

          if (normalizedTeamId) {
            setPlannedDates(
              normalizedTeamId,
              matrix.opName,
              excelEntry.meta.plannedStartDate ?? null,
              excelEntry.meta.plannedEndDate ?? null,
            )
          }

          return {
            teamId: normalizedTeamId,
            teamName: t ? `${t.name} - ${t.factoryName} - ${t.companyName}` : '',
            deliveryDate: excelEntry.meta.deliveryDate || undefined,
            checkDate: excelEntry.meta.checkDate || undefined,
            plannedStartDate: excelEntry.meta.plannedStartDate,
            plannedEndDate: excelEntry.meta.plannedEndDate,
            notes:
              excelEntry.meta.notes && excelEntry.meta.notes.length > 0
                ? excelEntry.meta.notes
                : [],
          }
        })

        // Cập nhật QtyMap cho từng SKU tương ứng với số dòng từ Excel
        const [poId, color] = poColorKey.split('|')
        const po = selectedPOs.value.find((p) => p.id === poId)

        if (po) {
          po.skuQuantities.forEach((sku) => {
            if (sku.color === color && sku.quantity > 0) {
              const skuKey = `${poId}|${color}|${sku.size}`
              matrix.qtyMap[skuKey] = teamIds.map((tId) => {
                const qtysFromExcel = teamMap.get(tId)?.qtys
                return qtysFromExcel ? qtysFromExcel[sku.size] || 0 : 0
              })
            }
          })
        }
      })
    })

    return appliedRowCount
  }

  const fillExcelToStore = (
    { rows, sizeColumns }: { rows: ExcelImportRow[]; sizeColumns: string[] },
    metaData: {
      syncDate: Date | null
      productDate: Date | null
      firstSku: string
    },
    resolvedTeamIdsByRowNumber?: Map<number, string>,
  ) => {
    const poById = new Map(selectedPOs.value.map((p) => [p.id, p]))

    const excelOpData = transformExcelToOpData(
      rows,
      sizeColumns,
      teams.value,
      poById,
      resolvedTeamIdsByRowNumber,
    )
    if (excelOpData.size === 0) {
      showError('Không tìm thấy dữ liệu phân bổ hợp lệ trong file Excel.')
      return false
    }
    //Validate
    const validationErrors = validateExcelAllocation(excelOpData, matrices.value, selectedPOs.value)
    if (validationErrors.length > 0) {
      showError(
        `Dữ liệu Excel vượt định mức:\n${validationErrors.slice(0, 3).join('\n')}${validationErrors.length > 3 ? '\n...' : ''}`,
      )
      return false
    }

    if (metaData.syncDate) syncDate.value = metaData.syncDate
    if (metaData.productDate) productDate.value = metaData.productDate
    if (metaData.firstSku) firstSku.value = metaData.firstSku

    noteColumnCount.value = calculateMaxNoteCount(excelOpData)

    // Reset dữ liệu phân bổ về trạng thái ban đầu
    resetMatricesData()

    // Ghi dữ liệu đã xử lý vào Matrices của Store
    const appliedRowCount = applyExcelToStore(excelOpData)
    if (appliedRowCount === 0) {
      showError('Không áp được dữ liệu Excel vào bảng phân bổ hiện tại.')
      resetImportState()
      return false
    }

    triggerMatrices()
    showSuccess(`Đã nhập dữ liệu thành công!`)
    return true
  }

  const importExcelFile = (file: File) => {
    if (!isCurrentStep('2')) {
      showError('Vui lòng chuyển sang bước Phân bổ trước khi nhập Excel.')
      return
    }

    importRequestId.value += 1
    const requestId = importRequestId.value
    closeTeamResolutionDialog()
    resetImportState()
    isImporting.value = true
    const reader = new FileReader()
    reader.onload = (e) => {
      if (requestId !== importRequestId.value) return
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer)
        const workbook = XLSX.read(data, { type: 'array', cellDates: true })
        const sheet = workbook.Sheets[workbook.SheetNames[0]]
        if (!sheet) {
          showError('Không tìm thấy sheet dữ liệu trong file Excel.')
          resetImportState()
          return
        }
        const rawRows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1 })

        const metaData = extractMetadata(rawRows)

        const jsonData = extractRows(rawRows, allSizes.value)
        const { resolvedTeamIdsByRowNumber, pendingRows } = defaultAllocationExcelTeamMatcher.match(
          jsonData.rows,
          importCandidateTeams.value,
        )
        if (requestId !== importRequestId.value) return

        if (pendingRows.length > 0) {
          pendingTeamResolutionRows.value = pendingRows
          pendingImportPayload.value = {
            rows: jsonData.rows,
            sizeColumns: jsonData.sizeColumns,
            metaData,
            resolvedTeamIdsByRowNumber,
          }
          showTeamResolutionDialog.value = true
          return
        }

        fillExcelToStore(jsonData, metaData, resolvedTeamIdsByRowNumber)
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Lỗi đọc file Excel'
        showError(message)
        resetImportState()
      } finally {
        if (requestId === importRequestId.value) {
          isImporting.value = false
        }
      }
    }
    reader.readAsArrayBuffer(file)
  }

  const downloadTemplate = async () => {
    if (isCurrentStep('3')) {
      await exportAllocationExcel({
        factoryIds: selectedFactoryIds.value,
        allSizes: allSizes.value,
        selectedPOs: selectedPOs.value,
        selectedRouting: selectedRouting.value,
        styleColorOrder: buyerOrder.value?.styleColorOrder,
        styleName: buyerOrder.value?.styleName,
        fileName: buyerOrder.value?.wfxId,
        customerName: buyerOrder.value?.customer,
        brandName: buyerOrder.value?.brand,
        matrices: matrices.value,
        autoOps: autoOps.value,
        opNames: opNames.value,
        operationOrder: selectedRouting.value?.operations ?? opNames.value,
        subTotalMap: subTotalMap.value,
        teams: teams.value,
        noteColumnCount: noteColumnCount.value,
        syncDate: syncDate.value,
        productDate: productDate.value,
        firstSku: firstSku.value,
        isExportData: true,
      })
      return
    }

    if (!buyerOrder.value) {
      showError('Vui lòng chọn đơn hàng trước khi tải mẫu.')
      return
    }
    if (selectedRoutingIndex.value === null) {
      showError('Vui lòng chọn quy trình sản xuất (Routing).')
      return
    }
    if (selectedFactoryIds.value.length === 0) {
      showError('Vui lòng chọn ít nhất một xí nghiệp.')
      return
    }

    try {
      const { data, response } = await downloadAllocationTemplateApi({
        query: {
          buyerOrderId: buyerOrder.value.id,
          routingIndex: selectedRoutingIndex.value,
          factoryId: selectedFactoryIds.value,
          poId: selectedPOIds.value.length > 0 ? selectedPOIds.value : undefined,
        },
        responseType: 'blob',
      })

      const rawData: unknown = data
      const blob =
        rawData instanceof Blob
          ? rawData
          : new Blob([rawData as BlobPart], {
              type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            })

      let fileName = `LSX_${buyerOrder.value.wfxId || buyerOrder.value.id}_template.xlsx`
      const disposition = response?.headers?.get('content-disposition')
      if (disposition && disposition.includes('filename=')) {
        const match = disposition.match(/filename="?([^"]+)"?/)
        if (match?.[1]) {
          fileName = match[1]
        }
      }

      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', fileName)
      document.body.appendChild(link)
      link.click()
      link.remove()
      URL.revokeObjectURL(url)
    } catch (err) {
      showError(err instanceof Error ? err.message : 'Lỗi khi tải mẫu Excel')
    }
  }
  return {
    showTeamResolutionDialog,
    pendingTeamResolutionRows,
    teamResolutionOptionsByRowKey,
    hasIncompleteTeamResolutions,
    importExcelFile,
    downloadTemplate,
    updatePendingTeamResolution,
    closeTeamResolutionDialog,
    confirmTeamResolutions: () => {
      const payload = pendingImportPayload.value
      if (!payload) return
      if (hasIncompleteTeamResolutions.value) {
        showError('Vui lòng chọn tổ đúng trên hệ thống cho tất cả các dòng cần xác nhận.')
        return
      }

      const resolvedTeamIdsByRowNumber = new Map(payload.resolvedTeamIdsByRowNumber)
      pendingTeamResolutionRows.value.forEach((row) => {
        row.rowNumbers.forEach((rowNumber) => {
          resolvedTeamIdsByRowNumber.set(rowNumber, row.selectedTeamId!)
        })
      })

      const success = fillExcelToStore(
        { rows: payload.rows, sizeColumns: payload.sizeColumns },
        payload.metaData,
        resolvedTeamIdsByRowNumber,
      )
      if (success) closeTeamResolutionDialog()
    },
  }
}
