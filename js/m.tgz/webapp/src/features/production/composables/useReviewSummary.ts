import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { storeToRefs } from 'pinia'
import { computed } from 'vue'

export function useReviewSummary() {
  const {
    mainCompanyCode,
    syncDate,
    productDate,
    firstSku,
    matrices,
    autoOps,
    totalSummaryQty,
    opNames,
  } = storeToRefs(useProductionOrderIssuanceStore())

  const metadataSummary = computed(() => [
    {
      label: 'Công ty đảm nhiệm chính',
      value: mainCompanyCode.value || 'Chưa chọn',
      icon: 'i-lucide-building-2',
    },
    {
      label: 'Ngày đồng bộ WFX',
      value: syncDate.value?.toLocaleDateString('vi-VN') || 'Chưa nhập',
      icon: 'i-lucide-refresh-cw',
    },
    {
      label: 'Ngày vào chuyền',
      value: productDate.value?.toLocaleDateString('vi-VN') || 'Chưa nhập',
      icon: 'i-lucide-calendar',
    },
    { label: 'Màu/Cỡ đầu tiên', value: firstSku.value || 'Chưa nhập', icon: 'i-lucide-tag' },
  ])

  const teamSummary = computed(() => {
    const summary: Record<string, { teamName: string; operation: string; total: number }> = {}
    matrices.value.forEach((matrix) => {
      for (const [poColorKey, metas] of Object.entries(matrix.rowMetaMap)) {
        metas.forEach((meta, rowIndex) => {
          if (!meta.teamId) return
          let rowTotal = 0
          for (const skuKey in matrix.qtyMap) {
            if (skuKey.startsWith(`${poColorKey}|`)) {
              rowTotal += matrix.qtyMap[skuKey][rowIndex] || 0
            }
          }
          const key = `${meta.teamId}-${matrix.opName}`
          if (!summary[key]) {
            summary[key] = { teamName: meta.teamName, operation: matrix.opName, total: 0 }
          }
          summary[key].total += rowTotal
        })
      }
    })
    autoOps.value.forEach((auto) => {
      const key = `${auto.teamId}-${auto.opName}`
      summary[key] = {
        teamName: auto.teamName,
        operation: auto.opName,
        total: totalSummaryQty.value,
      }
    })
    return Object.values(summary).sort((a, b) => a.operation.localeCompare(b.operation))
  })
  const operationSummary = computed(() => {
    return opNames.value.map((name) => {
      const matrix = matrices.value.find((m) => m.opName === name)
      let total = 0
      if (matrix) {
        total = Object.values(matrix.qtyMap).reduce(
          (sum, qtys) => sum + qtys.reduce((s, v) => s + v, 0),
          0,
        )
      } else {
        total = totalSummaryQty.value
      }
      return { name, total }
    })
  })
  const isBalanced = computed(() => {
    if (operationSummary.value.length <= 1) return true
    const firstTotal = operationSummary.value[0]?.total
    return operationSummary.value.every((op) => op.total === firstTotal)
  })
  return { metadataSummary, teamSummary, operationSummary, isBalanced }
}
