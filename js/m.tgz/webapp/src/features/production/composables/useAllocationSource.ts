import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { storeToRefs } from 'pinia'
import { computed, type Ref } from 'vue'
import type { AllocationGridRow, TeamOption } from '../types'
export function useAllocationSource(opName: string, filterText: Ref<string>) {
  const { selectedPOs, allSizes, matrices, demandMaps, teams, noteColumnCount } = storeToRefs(
    useProductionOrderIssuanceStore(),
  )
  const teamOptions = computed(() =>
    teams.value
      .filter((team) => team.operation === opName)
      .map((team) => ({
        label: `${team.name} - ${team.factoryName} - ${team.companyName}`,
        value: team.id,
      })),
  )
  const source = computed(() => {
    // Chuyển từ Map -> Flat để hiển thị Grid
    const matrixIdx = matrices.value.findIndex((m) => m.opName === opName)
    const matrix = matrices.value[matrixIdx]
    const dMap = demandMaps.value[matrixIdx]
    if (!matrix || !dMap) return []
    const rows: AllocationGridRow[] = []
    for (const [poColorKey, metas] of Object.entries(matrix.rowMetaMap)) {
      const [poId, colorName] = poColorKey.split('|')
      const po = selectedPOs.value.find((p) => p.id === poId)
      if (!po) continue
      metas.forEach((meta, rowIndex) => {
        const assignedFactoryNames = new Set<string>()
        for (const [skuKey, quantities] of Object.entries(matrix.qtyMap)) {
          if (!skuKey.startsWith(`${poColorKey}|`)) continue
          quantities.forEach((quantity, assignedRowIndex) => {
            if (quantity <= 0 || assignedRowIndex === rowIndex) return
            const assignedTeamId = metas[assignedRowIndex]?.teamId
            const factoryName = teams.value.find((team) => team.id === assignedTeamId)?.factoryName
            if (factoryName) assignedFactoryNames.add(factoryName)
          })
        }
        const rowTeamOptions: TeamOption[] = teamOptions.value.map((option) => {
          const team = teams.value.find((item) => item.id === option.value)
          const assignedFactoryName = [...assignedFactoryNames][0]
          const disabled =
            assignedFactoryNames.size > 0 && !assignedFactoryNames.has(team?.factoryName ?? '')
          return {
            ...option,
            disabled,
            label: disabled
              ? `${option.label} — SKU này đã được phân cho Xí nghiệp ${assignedFactoryName}`
              : option.label,
          }
        })
        const flat: AllocationGridRow = {
          id: `${poColorKey}_${rowIndex}`,
          poId,
          poCode: po.code,
          purchaseOrderType: po.type ?? 'REGULAR',
          destination: po.destination || '',
          deliveryDate:
            meta.deliveryDate && meta.deliveryDate.trim() !== ''
              ? meta.deliveryDate
              : po.deliveryDate,
          checkDate: meta.checkDate || '',
          color: colorName,
          rowIndex,
          teamId: meta.teamId,
          teamName: (() => {
            const t = teams.value.find((team) => team.id === meta.teamId)
            return t ? `${t.name} - ${t.factoryName} - ${t.companyName}` : ''
          })(),
          teamOptions: rowTeamOptions,
          total: 0,
        }
        let rowTotal = 0
        allSizes.value.forEach((size) => {
          const skuKey = `${poId}|${colorName}|${size}`
          const qtys = matrix.qtyMap[skuKey]
          const demands = dMap[skuKey]
          if (qtys && demands) {
            const qty = qtys[rowIndex] || 0
            const demand = demands[rowIndex] || 0
            flat[size] = qty
            flat[`${size}_demand`] = demand
            rowTotal += qty
          } else {
            flat[size] = null
            flat[`${size}_demand`] = null
          }
        })
        flat.total = rowTotal
        for (let i = 0; i < noteColumnCount.value; i++) {
          flat[`note_${i}`] = meta.notes?.[i] ?? ''
        }
        rows.push(flat)
      })
    }
    return rows.sort(
      (a, b) =>
        a.poCode.localeCompare(b.poCode) ||
        a.color.localeCompare(b.color) ||
        a.rowIndex - b.rowIndex,
    )
  })
  const filteredSource = computed(() => {
    const list = !filterText.value.trim()
      ? source.value
      : source.value.filter((row) => {
          const search = filterText.value.toLowerCase()
          return (
            row.poCode.toLowerCase().includes(search) ||
            row.destination.toLowerCase().includes(search) ||
            row.deliveryDate.toLowerCase().includes(search) ||
            row.color.toLowerCase().includes(search) ||
            row.teamName.toLowerCase().includes(search)
          )
        })

    return list.map((row, index) => ({
      ...row,
      displayPoCode: index === 0 || row.poCode !== list[index - 1]?.poCode ? row.poCode : '',
    }))
  })
  const totalTableQuantity = computed(() => {
    return source.value.reduce((sum, row) => sum + (row.total || 0), 0)
  })

  return {
    source,
    filteredSource,
    totalTableQuantity,
    teamOptions,
  }
}
