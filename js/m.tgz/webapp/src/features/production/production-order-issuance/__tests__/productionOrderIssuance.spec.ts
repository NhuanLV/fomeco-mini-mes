import {
  buildProductionOrderIssueCommand,
  defaultSelectedPurchaseOrderIds,
  findDuplicateTeamAssignments,
  findMissingTeamAssignments,
  togglePurchaseOrderSelection,
  validateIssuanceStep1,
  validateIssuanceStep2,
  validateIssuanceStep3,
} from '@/features/production/production-order-issuance/productionOrderIssuance'
import type { AllocationMatrix } from '@/features/production/types'
import dayjs from 'dayjs'
import { describe, expect, it } from 'vitest'

describe('Production Order Issuance rules', () => {
  it('validates step one in the existing user-facing order', () => {
    const valid = {
      selectedBOId: 'bo-1',
      needsAllocationRevision: false,
      routingCount: 1,
      selectedRoutingIndex: 0,
      selectedFactoryCount: 1,
      mainCompanyCode: 'LGG-BG',
      selectedPOCount: 1,
      operationAllocations: [{ operationName: 'CUT', teamCount: 1 }],
    }

    expect(validateIssuanceStep1({ ...valid, selectedBOId: '' })).toBe(
      'Vui lòng chọn Đơn hàng (BO).',
    )
    expect(validateIssuanceStep1({ ...valid, needsAllocationRevision: true })).toBe(
      'BO đang vượt phân bổ. Vui lòng điều chỉnh các LSX trước khi phát lệnh mới.',
    )
    expect(validateIssuanceStep1({ ...valid, mainCompanyCode: '' })).toBe(
      'Vui lòng chọn Mã Công ty đảm nhiệm chính.',
    )
    expect(
      validateIssuanceStep1({
        ...valid,
        operationAllocations: [
          { operationName: 'CUT', teamCount: 0 },
          { operationName: 'SEW', teamCount: 0 },
        ],
      }),
    ).toBe(
      'Xí nghiệp này thiếu tổ cho các công đoạn: CUT, SEW. Vui lòng chọn xí nghiệp khác hoặc cấu hình thêm tổ.',
    )
    expect(validateIssuanceStep1(valid)).toBeNull()
    expect(validateIssuanceStep2(['PO-1: Red'])).toBe(
      'Vui lòng chọn tổ cho các dòng đã phân bổ:\nPO-1: Red',
    )
  })

  it('defaults and toggles only purchase orders with remaining quantity', () => {
    const purchaseOrders = [
      {
        id: 'po-1',
        deliveryDate: '2026-08-01',
        skuQuantities: [{ color: 'Red', size: 'S', remainingQuantity: 5 }],
      },
      {
        id: 'po-2',
        deliveryDate: '2026-08-02',
        skuQuantities: [{ color: 'Blue', size: 'M', remainingQuantity: 0 }],
      },
    ]

    expect(defaultSelectedPurchaseOrderIds(purchaseOrders)).toEqual(['po-1'])
    expect(togglePurchaseOrderSelection(['po-1'], 'po-1', true)).toEqual([])
    expect(togglePurchaseOrderSelection([], 'po-2', false)).toEqual([])
    expect(togglePurchaseOrderSelection([], 'po-1', true)).toEqual(['po-1'])
  })

  it('preselects regular POs when both regular and positive POs have remaining quantity', () => {
    expect(
      defaultSelectedPurchaseOrderIds([
        {
          id: 'regular',
          type: 'REGULAR',
          deliveryDate: '2026-08-01',
          skuQuantities: [{ color: 'Red', size: 'S', remainingQuantity: 5 }],
        },
        {
          id: 'positive',
          type: 'POSITIVE',
          deliveryDate: '2026-08-01',
          skuQuantities: [{ color: 'Red', size: 'S', remainingQuantity: 5 }],
        },
      ]),
    ).toEqual(['regular'])
  })

  it('preselects positive POs when regular POs have no remaining quantity', () => {
    expect(
      defaultSelectedPurchaseOrderIds([
        {
          id: 'regular',
          type: 'REGULAR',
          deliveryDate: '2026-08-01',
          skuQuantities: [{ color: 'Red', size: 'S', remainingQuantity: 0 }],
        },
        {
          id: 'positive',
          type: 'POSITIVE',
          deliveryDate: '2026-08-01',
          skuQuantities: [{ color: 'Red', size: 'S', remainingQuantity: 5 }],
        },
      ]),
    ).toEqual(['positive'])
  })

  it('finds duplicate and missing team assignments by allocated row', () => {
    const matrix = makeMatrix('CUT', [
      { teamId: 'team-1', teamName: 'Tổ 1', notes: [] },
      { teamId: 'team-1', teamName: 'Tổ 1', notes: [] },
      { teamId: null, teamName: '', notes: [] },
    ])
    matrix.qtyMap['po-1|Red|S'] = [2, 1, 3]

    expect(findDuplicateTeamAssignments([matrix], new Map([['po-1', 'PO-1']]))).toEqual([
      'PO-1: Red (Công đoạn CUT)',
    ])
    expect(findMissingTeamAssignments([matrix], new Map([['po-1', 'PO-1']]))).toEqual([
      'PO-1: Red (Công đoạn CUT) - Dòng 3',
    ])
  })

  it('ignores unselected POs when finding duplicate and missing team assignments', () => {
    const matrix = makeMatrix('CUT', [{ teamId: 'team-1', teamName: 'Tổ 1', notes: [] }])
    matrix.rowMetaMap['po-2|Blue'] = [{ teamId: null, teamName: '', notes: [] }]
    matrix.qtyMap['po-1|Red|S'] = [5]
    matrix.qtyMap['po-2|Blue|M'] = [10]

    // Only po-1 is in poCodeById map
    const selectedPoMap = new Map([['po-1', 'PO-1']])
    expect(findMissingTeamAssignments([matrix], selectedPoMap)).toEqual([])
    expect(findDuplicateTeamAssignments([matrix], selectedPoMap)).toEqual([])
  })

  it('builds balanced manual and automatic operation assignments', () => {
    const matrix = makeMatrix('CUT', [
      {
        teamId: 'cut-team',
        teamName: 'Tổ cắt',
        deliveryDate: '2026-08-01',
        checkDate: '2026-07-30',
        notes: ['Ưu tiên'],
      },
    ])
    matrix.qtyMap['po-1|Red|S'] = [5]

    expect(
      buildProductionOrderIssueCommand({
        buyerOrderId: 'bo-1',
        factoryIds: ['factory-1'],
        mainCompanyCode: 'LGG-BG',
        selectedPOs: [makePurchaseOrder()],
        matrices: [matrix],
        autoOps: [{ opName: 'SEW', teamId: 'sew-team', teamName: 'Tổ may' }],
        allOperationsAuto: false,
        subTotalMap: { 'po-1|Red|S': 5 },
        opNames: ['CUT', 'SEW'],
        totalSummaryQty: 5,
        syncDate: new Date(2026, 6, 25),
        productDate: null,
        firstSku: 'SKU-1',
        plannedDates: {
          'cut-team|CUT': { plannedStartDate: '2026-07-20', plannedEndDate: '2026-07-25' },
          'sew-team|SEW': { plannedStartDate: '2026-07-26', plannedEndDate: '2026-07-31' },
        },
      }),
    ).toEqual({
      ok: true,
      body: {
        buyerOrderId: 'bo-1',
        factoryIds: ['factory-1'],
        mainCompanyCode: 'LGG-BG',
        routing: ['CUT', 'SEW'],
        metadata: {
          syncDate: '2026-07-25',
          productDate: null,
          firstSku: 'SKU-1',
        },
        teamAssignments: [
          {
            teamId: 'cut-team',
            operation: 'CUT',
            plannedStartDate: '2026-07-20',
            plannedEndDate: '2026-07-25',
            allocations: [
              {
                purchaseOrderId: 'po-1',
                color: 'Red',
                size: 'S',
                quantity: 5,
                checkDate: '2026-07-30',
                deliveryDate: '2026-08-01',
                notes: ['Ưu tiên'],
              },
            ],
          },
          {
            teamId: 'sew-team',
            operation: 'SEW',
            plannedStartDate: '2026-07-26',
            plannedEndDate: '2026-07-31',
            allocations: [
              {
                purchaseOrderId: 'po-1',
                color: 'Red',
                size: 'S',
                quantity: 5,
                checkDate: '',
                deliveryDate: '2026-08-01',
                notes: [],
              },
            ],
          },
        ],
      },
    })
  })

  it('applies the shared allocation to every automatic operation and rejects imbalance', () => {
    const base = {
      buyerOrderId: 'bo-1',
      factoryIds: ['factory-1'],
      mainCompanyCode: 'LGG-BG',
      selectedPOs: [makePurchaseOrder()],
      matrices: [
        {
          ...makeMatrix('CUT', [
            {
              teamId: null,
              teamName: '',
              deliveryDate: '2026-08-03',
              checkDate: '2026-08-02',
              notes: ['Chung'],
            },
          ]),
          qtyMap: { 'po-1|Red|S': [3] },
        },
      ],
      autoOps: [
        { opName: 'CUT', teamId: 'cut-team', teamName: 'Tổ cắt' },
        { opName: 'SEW', teamId: 'sew-team', teamName: 'Tổ may' },
      ],
      allOperationsAuto: true,
      subTotalMap: {},
      opNames: ['CUT', 'SEW'],
      totalSummaryQty: 3,
      syncDate: null,
      productDate: null,
      firstSku: '',
      plannedDates: {
        'cut-team|CUT': { plannedStartDate: '2026-07-20', plannedEndDate: '2026-07-25' },
        'sew-team|SEW': { plannedStartDate: '2026-07-26', plannedEndDate: '2026-07-31' },
      },
    }

    const result = buildProductionOrderIssueCommand(base)
    expect(result.ok && result.body.teamAssignments).toEqual([
      expect.objectContaining({
        operation: 'CUT',
        allocations: [
          expect.objectContaining({
            quantity: 3,
            deliveryDate: '2026-08-03',
            checkDate: '2026-08-02',
            notes: ['Chung'],
          }),
        ],
      }),
      expect.objectContaining({
        operation: 'SEW',
        allocations: [
          expect.objectContaining({
            quantity: 3,
            deliveryDate: '2026-08-03',
            checkDate: '2026-08-02',
            notes: ['Chung'],
          }),
        ],
      }),
    ])

    expect(
      buildProductionOrderIssueCommand({
        ...base,
        matrices: [makeMatrix('CUT', [])],
        allOperationsAuto: false,
      }),
    ).toEqual({
      ok: false,
      error: 'Sản lượng các công đoạn không khớp hoặc chưa được phân bổ đủ!',
    })

    expect(buildProductionOrderIssueCommand({ ...base, plannedDates: {} })).toEqual({
      ok: false,
      error: 'Vui lòng nhập ngày dự kiến bắt đầu và hoàn thành cho từng lệnh công đoạn.',
    })
  })

  it('validates step 3 planned dates', () => {
    const today = dayjs().format('YYYY-MM-DD')
    const yesterday = dayjs().subtract(1, 'day').format('YYYY-MM-DD')
    const tomorrow = dayjs().add(1, 'day').format('YYYY-MM-DD')
    const future = dayjs().add(5, 'day').format('YYYY-MM-DD')

    expect(
      validateIssuanceStep3({
        assignments: [
          {
            teamId: 't-1',
            operation: 'CUT',
            teamName: 'Tổ cắt',
            plannedStartDate: null,
            plannedEndDate: future,
          },
        ],
      }),
    ).toBe('Vui lòng nhập Ngày dự kiến bắt đầu cho tổ Tổ cắt (Công đoạn CUT)')

    expect(
      validateIssuanceStep3({
        assignments: [
          {
            teamId: 't-1',
            operation: 'CUT',
            teamName: 'Tổ cắt',
            plannedStartDate: tomorrow,
            plannedEndDate: null,
          },
        ],
      }),
    ).toBe('Vui lòng nhập Ngày dự kiến hoàn thành cho tổ Tổ cắt (Công đoạn CUT)')

    expect(
      validateIssuanceStep3({
        assignments: [
          {
            teamId: 't-1',
            operation: 'CUT',
            teamName: 'Tổ cắt',
            plannedStartDate: yesterday,
            plannedEndDate: future,
          },
        ],
      }),
    ).toBe('Ngày dự kiến bắt đầu của tổ Tổ cắt (Công đoạn CUT) không được trong quá khứ')

    expect(
      validateIssuanceStep3({
        assignments: [
          {
            teamId: 't-1',
            operation: 'CUT',
            teamName: 'Tổ cắt',
            plannedStartDate: future,
            plannedEndDate: tomorrow,
          },
        ],
      }),
    ).toBe('Ngày dự kiến hoàn thành của tổ Tổ cắt (Công đoạn CUT) phải sau hoặc bằng ngày bắt đầu')

    expect(
      validateIssuanceStep3({
        assignments: [
          {
            teamId: 't-1',
            operation: 'CUT',
            teamName: 'Tổ cắt',
            plannedStartDate: today,
            plannedEndDate: future,
          },
        ],
      }),
    ).toBeNull()
  })
})

function makePurchaseOrder() {
  return {
    id: 'po-1',
    deliveryDate: '2026-08-01',
    skuQuantities: [
      { color: 'Red', size: 'S', remainingQuantity: 5 },
      { color: 'Red', size: 'M', remainingQuantity: 0 },
    ],
  }
}

function makeMatrix(
  opName: string,
  metas: AllocationMatrix['rowMetaMap'][string],
): AllocationMatrix {
  return {
    opName,
    qtyMap: {},
    totalMap: { 'po-1|Red|S': 5 },
    rowMetaMap: { 'po-1|Red': metas },
  }
}
