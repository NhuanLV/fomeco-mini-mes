import type { BuyerOrderDetailVm, UnitVm } from '@/api'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { useAllocationInit } from '@/features/production/composables/useAllocationInit'
import { useAllocationColumns } from '@/features/production/composables/useAllocationColumns'
import { computed } from 'vue'
import { shallowMount } from '@vue/test-utils'
import PurchaseOrderAllocationStep from '@/features/production/components/PurchaseOrderAllocationStep.vue'
import PurchaseOrderAllocationTable from '@/features/production/components/PurchaseOrderAllocationTable.vue'
import AutoOpsAssignmentBanner from '@/features/production/components/AutoOpsAssignmentBanner.vue'
import type { AllocationMatrix, TeamVm } from '@/features/production/types'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'

describe('useProductionOrderIssuanceStore', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  it('creates one shared table without a team column and schedules all single-team operations', () => {
    const store = useProductionOrderIssuanceStore()
    store.buyerOrder = makeBuyerOrder()
    store.buyerOrder.routings = [{ operations: ['CUT', 'SEW'] }] as BuyerOrderDetailVm['routings']
    store.selectedRoutingIndex = 0
    store.selectedPOIds = ['po-1']
    store.teams = [
      { id: 'cut-team', operation: 'CUT', name: 'Cắt' },
      { id: 'sew-team', operation: 'SEW', name: 'May' },
    ] as TeamVm[]
    useAllocationInit().init()

    expect(store.allOperationsAuto).toBe(true)
    expect(store.autoOperations.map((op) => op.operationName)).toEqual(['CUT', 'SEW'])
    expect(store.matrices).toHaveLength(1)
    expect(store.matrices[0].qtyMap).toEqual({ 'po-1|Red|M': [0], 'po-1|Red|S': [0] })
    const wrapper = shallowMount(PurchaseOrderAllocationStep, {
      props: { onImportExcel: () => {} },
      global: { stubs: { UIcon: true, UTextarea: true, UBadge: true } },
    })
    expect(wrapper.findAllComponents(PurchaseOrderAllocationTable)).toHaveLength(1)
    expect(wrapper.findComponent(AutoOpsAssignmentBanner).props('ops')).toHaveLength(2)
    expect(wrapper.text()).toContain('Phân bổ chung cho tất cả công đoạn')
    expect(wrapper.text()).not.toContain('Tất cả công đoạn đã được phân công tự động')
    wrapper.unmount()
    const { columns } = useAllocationColumns(
      'CUT',
      false,
      computed(() => []),
    )
    expect(columns.value.some((column) => column.name === 'Tổ')).toBe(false)
    store.matrices[0].qtyMap['po-1|Red|S'] = [3]
    store.triggerMatrices()
    expect(
      store.scheduledAssignments.map((item) => [item.operation, item.assignedQuantity]),
    ).toEqual([
      ['CUT', 3],
      ['SEW', 3],
    ])

    store.teams = [...store.teams, { id: 'sew-team-2', operation: 'SEW', name: 'May 2' } as TeamVm]
    useAllocationInit().init()
    expect(store.allOperationsAuto).toBe(false)
    expect(store.matrices.map((matrix) => matrix.opName)).toEqual(['SEW'])
    expect(store.autoOperations.map((op) => op.operationName)).toEqual(['CUT'])
    expect(columns.value.some((column) => column.name === 'Tổ')).toBe(true)
  })

  it('resets wizard and allocation state as one workflow', () => {
    const store = useProductionOrderIssuanceStore()
    store.goToStep('3')
    store.selectedBOId = 'bo-1'
    store.selectedFactoryIds = ['factory-1']
    store.noteColumnCount = 2
    store.syncDate = new Date(2026, 6, 26)
    store.matrices = [makeMatrix()]

    store.reset()

    expect(store.currentStep).toBe('1')
    expect(store.selectedBOId).toBe('')
    expect(store.selectedFactoryIds).toEqual([])
    expect(store.mainCompanyCode).toBe('')
    expect(store.noteColumnCount).toBe(0)
    expect(store.syncDate).toBeNull()
    expect(store.matrices).toEqual([])
  })

  it('derives available companies and auto-selects when single company is present', () => {
    const store = useProductionOrderIssuanceStore()
    store.factories = [
      {
        id: 'f-1',
        name: 'Xí nghiệp 1',
        type: 'FACTORY',
        companyName: 'LGG Bắc Giang',
        code: 'XN-1',
        operations: [],
        isActive: true,
        children: [],
        companyCode: 'LGG-BG',
      } as unknown as UnitVm,
      {
        id: 'f-2',
        name: 'Xí nghiệp 2',
        type: 'FACTORY',
        companyName: 'LGG Bắc Giang',
        code: 'XN-2',
        operations: [],
        isActive: true,
        children: [],
        companyCode: 'LGG-BG',
      } as unknown as UnitVm,
      {
        id: 'f-3',
        name: 'Xí nghiệp 3',
        type: 'FACTORY',
        companyName: 'LGG Tuyên Quang',
        code: 'XN-3',
        operations: [],
        isActive: true,
        children: [],
        companyCode: 'LGG-TQ',
      } as unknown as UnitVm,
    ]

    store.selectedFactoryIds = ['f-1', 'f-2']
    expect(store.availableCompanies).toEqual([{ code: 'LGG-BG', name: 'LGG Bắc Giang' }])
    expect(store.mainCompanyCode).toBe('LGG-BG')
    expect(store.mainCompanyOptions).toEqual([{ label: 'LGG-BG (LGG Bắc Giang)', value: 'LGG-BG' }])

    store.selectedFactoryIds = ['f-1', 'f-3']
    expect(store.availableCompanies).toEqual([
      { code: 'LGG-BG', name: 'LGG Bắc Giang' },
      { code: 'LGG-TQ', name: 'LGG Tuyên Quang' },
    ])
    expect(store.mainCompanyOptions).toEqual([
      { label: 'LGG-BG (LGG Bắc Giang)', value: 'LGG-BG' },
      { label: 'LGG-TQ (LGG Tuyên Quang)', value: 'LGG-TQ' },
    ])
  })

  it('derives selected purchase orders and sizes from the same state owner', () => {
    const store = useProductionOrderIssuanceStore()
    store.buyerOrder = makeBuyerOrder()
    store.selectedPOIds = ['po-1']

    expect(store.selectedPOs.map((po) => po.id)).toEqual(['po-1'])
    expect(store.allSizes).toEqual(['S', 'M', 'L'])
  })

  it('quick-fills remaining quantities using workflow sizes', () => {
    const store = useProductionOrderIssuanceStore()
    store.buyerOrder = makeBuyerOrder()
    store.matrices = [makeMatrix()]

    store.quickFillAll()

    expect(store.matrices[0].qtyMap).toEqual({
      'po-1|Red|S': [5],
      'po-1|Red|M': [2],
    })
  })

  it('deletes removed note columns from every allocation row without changing quantities', () => {
    const store = useProductionOrderIssuanceStore()
    store.noteColumnCount = 3
    store.matrices = ['CUT', 'SEW'].map((opName) => ({
      ...makeMatrix(),
      opName,
      qtyMap: { 'po-1|Red|S': [10, 20] },
      rowMetaMap: {
        'po-1|Red': [
          { teamId: 'team-1', teamName: 'Tổ 1', notes: ['A', '2', '3'] },
          { teamId: 'team-2', teamName: 'Tổ 2', notes: ['B'] },
        ],
        'po-2|Blue': [{ teamId: null, teamName: '', notes: [] }],
      },
    }))

    store.removeNoteColumn()
    store.removeNoteColumn()

    expect(store.noteColumnCount).toBe(1)
    for (const matrix of store.matrices) {
      expect(matrix.rowMetaMap['po-1|Red'].map((row) => row.notes)).toEqual([['A'], ['B']])
      expect(matrix.rowMetaMap['po-2|Blue'][0].notes).toEqual([])
      expect(matrix.qtyMap['po-1|Red|S']).toEqual([10, 20])
    }

    store.addNoteColumn()
    expect(store.matrices[0].rowMetaMap['po-1|Red'][0].notes).toEqual(['A'])
    store.removeNoteColumn()
    store.removeNoteColumn()
    store.removeNoteColumn()

    expect(store.noteColumnCount).toBe(0)
    for (const matrix of store.matrices) {
      expect(
        Object.values(matrix.rowMetaMap).flatMap((rows) => rows.map((row) => row.notes)),
      ).toEqual([[], [], []])
    }
  })

  it('quick-fills only selected purchase orders when multiple POs exist in matrix', () => {
    const store = useProductionOrderIssuanceStore()
    store.buyerOrder = makeBuyerOrder()
    store.selectedPOIds = ['po-1']
    store.matrices = [
      {
        opName: 'CUT',
        qtyMap: {},
        totalMap: {
          'po-1|Red|S': 5,
          'po-2|Blue|L': 3,
        },
        rowMetaMap: {
          'po-1|Red': [{ teamId: 'team-1', teamName: 'Tổ 1', notes: [] }],
          'po-2|Blue': [{ teamId: null, teamName: '', notes: [] }],
        },
      },
    ]

    store.quickFillAll()

    expect(store.matrices[0].qtyMap['po-1|Red|S']).toEqual([5])
    expect(store.matrices[0].qtyMap['po-2|Blue|L']).toBeUndefined()
  })
})

function makeBuyerOrder() {
  return {
    id: 'bo-1',
    styleSizeOrder: ['S', 'M'],
    purchaseOrders: [
      {
        id: 'po-1',
        skuQuantities: [
          { color: 'Red', size: 'M', remainingQuantity: 2 },
          { color: 'Red', size: 'S', remainingQuantity: 5 },
        ],
      },
      {
        id: 'po-2',
        skuQuantities: [{ color: 'Blue', size: 'L', remainingQuantity: 3 }],
      },
    ],
    routings: [],
  } as unknown as BuyerOrderDetailVm
}

function makeMatrix(): AllocationMatrix {
  return {
    opName: 'CUT',
    qtyMap: {},
    totalMap: {
      'po-1|Red|S': 5,
      'po-1|Red|M': 2,
    },
    rowMetaMap: {
      'po-1|Red': [{ teamId: 'team-1', teamName: 'Tổ 1', notes: [] }],
    },
  }
}
