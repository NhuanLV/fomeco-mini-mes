import type { IssueProductionOrderCommand, SkuAllocation, TeamAssignmentCommandData } from '@/api'
import type { AllocationMatrix, AutoOperationMeta } from '@/features/production/types'
import dayjs from 'dayjs'

export type SelectablePurchaseOrder = {
  id: string
  type?: 'REGULAR' | 'POSITIVE'
  deliveryDate: string
  skuQuantities: Array<{
    color: string
    size: string
    remainingQuantity: number
  }>
}

export function validateIssuanceStep1(input: {
  selectedBOId: string
  needsAllocationRevision: boolean
  routingCount: number
  selectedRoutingIndex: number | null
  selectedFactoryCount: number
  mainCompanyCode: string
  selectedPOCount: number
  operationAllocations: Array<{
    teamCount: number
    operationName: string
  }>
}): string | null {
  if (!input.selectedBOId) return 'Vui lòng chọn Đơn hàng (BO).'
  if (input.needsAllocationRevision) {
    return 'BO đang vượt phân bổ. Vui lòng điều chỉnh các LSX trước khi phát lệnh mới.'
  }
  if (input.routingCount === 0) {
    return 'Đơn hàng này chưa có Routing. Vui lòng đồng bộ BOM từ WFX trước.'
  }
  if (input.selectedRoutingIndex === null) {
    return 'Vui lòng chọn Quy trình sản xuất (Routing).'
  }
  if (input.selectedFactoryCount === 0) {
    return 'Vui lòng chọn ít nhất một Xí nghiệp thực hiện.'
  }
  if (!input.mainCompanyCode) {
    return 'Vui lòng chọn Mã Công ty đảm nhiệm chính.'
  }
  if (input.selectedPOCount === 0) return 'Vui lòng chọn ít nhất 1 PO.'
  if (input.operationAllocations.length === 0) {
    return 'Chưa có thông tin phân công công đoạn. Vui lòng chọn lại Xí nghiệp.'
  }

  const missingTeams = input.operationAllocations.filter((operation) => operation.teamCount === 0)
  if (missingTeams.length > 0) {
    return `Xí nghiệp này thiếu tổ cho các công đoạn: ${missingTeams.map((operation) => operation.operationName).join(', ')}. Vui lòng chọn xí nghiệp khác hoặc cấu hình thêm tổ.`
  }
  return null
}

export function validateIssuanceStep2(missing: string[]): string | null {
  return missing.length > 0
    ? `Vui lòng chọn tổ cho các dòng đã phân bổ:\n${missing.join('\n')}`
    : null
}

export function validateIssuanceStep3(input: {
  assignments: Array<{
    teamId: string
    operation: string
    teamName: string
    plannedStartDate?: string | null
    plannedEndDate?: string | null
  }>
}): string | null {
  const todayStr = dayjs().format('YYYY-MM-DD')
  for (const item of input.assignments) {
    if (!item.plannedStartDate) {
      return `Vui lòng nhập Ngày dự kiến bắt đầu cho tổ ${item.teamName} (Công đoạn ${item.operation})`
    }
    if (!item.plannedEndDate) {
      return `Vui lòng nhập Ngày dự kiến hoàn thành cho tổ ${item.teamName} (Công đoạn ${item.operation})`
    }
    if (dayjs(item.plannedStartDate).isBefore(todayStr, 'day')) {
      return `Ngày dự kiến bắt đầu của tổ ${item.teamName} (Công đoạn ${item.operation}) không được trong quá khứ`
    }
    if (dayjs(item.plannedEndDate).isBefore(todayStr, 'day')) {
      return `Ngày dự kiến hoàn thành của tổ ${item.teamName} (Công đoạn ${item.operation}) không được trong quá khứ`
    }
    if (dayjs(item.plannedEndDate).isBefore(dayjs(item.plannedStartDate), 'day')) {
      return `Ngày dự kiến hoàn thành của tổ ${item.teamName} (Công đoạn ${item.operation}) phải sau hoặc bằng ngày bắt đầu`
    }
  }
  return null
}

export function defaultSelectedPurchaseOrderIds(purchaseOrders: SelectablePurchaseOrder[]) {
  const regularWithRemaining = purchaseOrders.filter(
    (purchaseOrder) =>
      purchaseOrder.type !== 'POSITIVE' &&
      purchaseOrder.skuQuantities.some((sku) => sku.remainingQuantity > 0),
  )
  if (regularWithRemaining.length > 0) {
    return regularWithRemaining.map((purchaseOrder) => purchaseOrder.id)
  }
  const positiveWithRemaining = purchaseOrders.filter(
    (purchaseOrder) =>
      purchaseOrder.type === 'POSITIVE' &&
      purchaseOrder.skuQuantities.some((sku) => sku.remainingQuantity > 0),
  )
  return positiveWithRemaining.map((purchaseOrder) => purchaseOrder.id)
}

export function togglePurchaseOrderSelection(
  selectedIds: string[],
  id: string,
  hasRemaining: boolean,
) {
  return selectedIds.includes(id)
    ? selectedIds.filter((selectedId) => selectedId !== id)
    : hasRemaining
      ? [...selectedIds, id]
      : selectedIds
}

export function findDuplicateTeamAssignments(
  matrices: AllocationMatrix[],
  poCodeById: Map<string, string>,
) {
  const duplicates: string[] = []
  for (const matrix of matrices) {
    for (const [poColorKey, metas] of Object.entries(matrix.rowMetaMap)) {
      const [poId, color] = poColorKey.split('|')
      if (poCodeById.size > 0 && !poCodeById.has(poId)) continue
      const teamIds = metas
        .map((meta) => meta.teamId)
        .filter((teamId): teamId is string => !!teamId)
      if (new Set(teamIds).size === teamIds.length) continue
      duplicates.push(`${poCodeById.get(poId) ?? poId}: ${color} (Công đoạn ${matrix.opName})`)
    }
  }
  return duplicates
}

export function findMissingTeamAssignments(
  matrices: AllocationMatrix[],
  poCodeById: Map<string, string>,
) {
  const missing: string[] = []
  for (const matrix of matrices) {
    for (const [poColorKey, metas] of Object.entries(matrix.rowMetaMap)) {
      const [poId, color] = poColorKey.split('|')
      if (poCodeById.size > 0 && !poCodeById.has(poId)) continue
      metas.forEach((meta, rowIndex) => {
        const hasQuantity = Object.entries(matrix.qtyMap).some(
          ([skuKey, quantities]) =>
            skuKey.startsWith(`${poColorKey}|`) && (quantities[rowIndex] || 0) > 0,
        )
        if (!hasQuantity || meta.teamId) return
        missing.push(
          `${poCodeById.get(poId) ?? poId}: ${color} (Công đoạn ${matrix.opName}) - Dòng ${rowIndex + 1}`,
        )
      })
    }
  }
  return missing
}

export function buildProductionOrderIssueCommand(input: {
  buyerOrderId: string
  factoryIds: string[]
  mainCompanyCode: string
  selectedPOs: SelectablePurchaseOrder[]
  matrices: AllocationMatrix[]
  autoOps: AutoOperationMeta[]
  allOperationsAuto: boolean
  subTotalMap: Record<string, number>
  opNames: string[]
  totalSummaryQty: number
  syncDate: Date | null
  productDate: Date | null
  firstSku: string
  plannedDates?: Record<string, { plannedStartDate: string | null; plannedEndDate: string | null }>
}): { ok: true; body: IssueProductionOrderCommand } | { ok: false; error: string } {
  const totals = input.opNames.map((name) => {
    const matrix = input.matrices.find((candidate) => candidate.opName === name)
    return matrix
      ? Object.values(matrix.qtyMap).reduce(
          (sum, quantities) => sum + quantities.reduce((subtotal, value) => subtotal + value, 0),
          0,
        )
      : input.totalSummaryQty
  })
  if (totals.some((total) => total === 0 || total !== totals[0])) {
    return {
      ok: false,
      error: 'Sản lượng các công đoạn không khớp hoặc chưa được phân bổ đủ!',
    }
  }

  const sharedMatrix = input.matrices[0]
  const teamAssignments =
    input.allOperationsAuto && sharedMatrix
      ? buildManualAssignments(
          input.autoOps.map((operation) => ({
            ...sharedMatrix,
            opName: operation.opName,
            rowMetaMap: Object.fromEntries(
              Object.entries(sharedMatrix.rowMetaMap).map(([key, rows]) => [
                key,
                rows.map((row) => ({
                  ...row,
                  teamId: operation.teamId,
                  teamName: operation.teamName,
                })),
              ]),
            ),
          })),
          input.plannedDates,
        )
      : buildManualAssignments(input.matrices, input.plannedDates)
  if (!input.allOperationsAuto) {
    const deliveryDateByPoId = new Map(input.selectedPOs.map((po) => [po.id, po.deliveryDate]))
    for (const operation of input.autoOps) {
      const dates = input.plannedDates?.[`${operation.teamId}|${operation.opName}`]
      teamAssignments.push({
        teamId: operation.teamId,
        operation: operation.opName,
        allocations: toAllocations(input.subTotalMap, deliveryDateByPoId),
        plannedStartDate: dates?.plannedStartDate ?? '',
        plannedEndDate: dates?.plannedEndDate ?? '',
      })
    }
  }

  if (
    teamAssignments.some((assignment) => !assignment.plannedStartDate || !assignment.plannedEndDate)
  ) {
    return {
      ok: false,
      error: 'Vui lòng nhập ngày dự kiến bắt đầu và hoàn thành cho từng lệnh công đoạn.',
    }
  }

  return {
    ok: true,
    body: {
      buyerOrderId: input.buyerOrderId,
      factoryIds: input.factoryIds,
      mainCompanyCode: input.mainCompanyCode,
      teamAssignments,
      metadata: {
        syncDate: input.syncDate ? dayjs(input.syncDate).format('YYYY-MM-DD') : null,
        productDate: input.productDate ? dayjs(input.productDate).format('YYYY-MM-DD') : null,
        firstSku: input.firstSku,
      },
      routing: input.opNames,
    },
  }
}

function buildManualAssignments(
  matrices: AllocationMatrix[],
  plannedDates?: Record<string, { plannedStartDate: string | null; plannedEndDate: string | null }>,
): TeamAssignmentCommandData[] {
  const result: TeamAssignmentCommandData[] = []
  for (const matrix of matrices) {
    const allocationsByTeam = new Map<string, SkuAllocation[]>()
    for (const [poColorKey, metas] of Object.entries(matrix.rowMetaMap)) {
      const [purchaseOrderId, color] = poColorKey.split('|')
      metas.forEach((meta, rowIndex) => {
        if (!meta.teamId) return
        const allocations = allocationsByTeam.get(meta.teamId) ?? []
        for (const [skuKey, quantities] of Object.entries(matrix.qtyMap)) {
          if (!skuKey.startsWith(`${poColorKey}|`)) continue
          const quantity = quantities[rowIndex] || 0
          if (quantity <= 0) continue
          allocations.push({
            purchaseOrderId,
            color,
            size: skuKey.split('|')[2],
            quantity,
            checkDate: meta.checkDate || '',
            deliveryDate: meta.deliveryDate || '',
            notes: meta.notes,
          })
        }
        allocationsByTeam.set(meta.teamId, allocations)
      })
    }
    for (const [teamId, allocations] of allocationsByTeam) {
      const dates = plannedDates?.[`${teamId}|${matrix.opName}`]
      result.push({
        teamId,
        operation: matrix.opName,
        allocations,
        plannedStartDate: dates?.plannedStartDate ?? '',
        plannedEndDate: dates?.plannedEndDate ?? '',
      })
    }
  }
  return result
}

function toAllocations(
  source: Record<string, number>,
  deliveryDateByPoId: Map<string, string>,
): SkuAllocation[] {
  const allocations: SkuAllocation[] = []
  for (const [skuKey, quantity] of Object.entries(source)) {
    if (quantity <= 0) continue
    const [purchaseOrderId, color, size] = skuKey.split('|')
    allocations.push({
      purchaseOrderId,
      color,
      size,
      quantity,
      checkDate: '',
      deliveryDate: deliveryDateByPoId.get(purchaseOrderId) ?? '',
      notes: [],
    })
  }
  return allocations
}
