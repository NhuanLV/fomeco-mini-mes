import {
  getBuyerOrderDetailQuery,
  getTeamsByFactoriesQuery,
  getTreeQuery,
} from '@/api/@pinia/colada.gen'
import { ROUTE_PATH } from '@/app/router/path'
import { useAllocationExcel } from '@/features/production/composables/useAllocationExcel'
import { useOrderDataSync } from '@/features/production/composables/useOrderDataSync'
import { usePoSelection } from '@/features/production/composables/usePoSelection'
import { useStepNavigation } from '@/features/production/composables/useStepNavigation'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { useQuery } from '@pinia/colada'
import { storeToRefs } from 'pinia'
import { computed, onActivated, onMounted, onUnmounted, watch } from 'vue'
import { useRouter } from 'vue-router'

export function useProductionOrderIssuance() {
  const router = useRouter()
  const store = useProductionOrderIssuanceStore()
  const { selectedBOId, selectedFactoryIds } = storeToRefs(store)

  const { data: orderData } = useQuery(() => ({
    ...getBuyerOrderDetailQuery({
      path: { id: selectedBOId.value },
    }),
    enabled: !!selectedBOId.value,
  }))
  const { data: teamsData } = useQuery(() => ({
    ...getTeamsByFactoriesQuery({
      query: { factoryIds: selectedFactoryIds.value },
    }),
    enabled: selectedFactoryIds.value.length > 0,
  }))
  const { data: treeData, isPending: loading } = useQuery({
    ...getTreeQuery(),
  })

  const { setOrderData, setTeamsData, setTreeData } = useOrderDataSync()
  const { togglePO, toggleAllFiltered } = usePoSelection()
  const { stepValue } = useStepNavigation()
  const allocationExcel = useAllocationExcel()

  watch(orderData, setOrderData, { immediate: true })
  watch([teamsData, treeData], ([teams, tree]) => setTeamsData(teams, tree), { immediate: true })
  watch(treeData, setTreeData, { immediate: true })

  const boLocked = computed(
    () => typeof router.currentRoute.value.query['buyer-order'] === 'string',
  )
  const breadcrumbHome = {
    icon: 'i-lucide-house',
    to: ROUTE_PATH.DASHBOARD,
  }
  const breadcrumbItems = [{ label: 'Lập Lệnh sản xuất', icon: 'i-lucide-file-plus-2' }]

  function reset() {
    store.reset()
  }

  function buyerOrderIdFromRoute() {
    return router.currentRoute.value.query['buyer-order'] as string | undefined
  }

  function onSubmitSuccess() {
    reset()
    void router.push(ROUTE_PATH.PRODUCTION_ORDERS)
  }

  onMounted(() => {
    reset()
    const buyerOrderId = buyerOrderIdFromRoute()
    if (buyerOrderId) store.selectedBOId = buyerOrderId
  })

  onActivated(() => {
    const buyerOrderId = buyerOrderIdFromRoute()
    if (buyerOrderId && buyerOrderId !== store.selectedBOId) {
      reset()
      store.selectedBOId = buyerOrderId
    }
  })

  onUnmounted(reset)

  return {
    store,
    loading,
    boLocked,
    breadcrumbHome,
    breadcrumbItems,
    togglePO,
    toggleAllFiltered,
    stepValue,
    onSubmitSuccess,
    ...allocationExcel,
  }
}
