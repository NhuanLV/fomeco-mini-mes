import type { BuyerOrderDetailVm, PurchaseOrderVm, UnitVm } from '@/api'
import {
  buildDemandMaps,
  buildSubTotalMap,
  buildSummaryMatrix,
} from '@/features/production/helpers/allocation'
import {
  validateIssuanceStep1,
  validateIssuanceStep2,
  validateIssuanceStep3,
} from '@/features/production/production-order-issuance/productionOrderIssuance'
import type {
  AllocationMatrix,
  SkuKey,
  TeamAssignmentScheduleItem,
  TeamVm,
} from '@/features/production/types'
import { sortValuesByOrder } from '@/shared/utils/orderedValues'
import { acceptHMRUpdate, defineStore } from 'pinia'
import { computed, ref, shallowRef, triggerRef, watch } from 'vue'

type IssuanceStep = '1' | '2' | '3'

export const useProductionOrderIssuanceStore = defineStore('production-order-issuance', () => {
  const currentStep = shallowRef<IssuanceStep>('1')
  const selectedBOId = shallowRef('')
  const selectedFactoryIds = ref<string[]>([])
  const mainCompanyCode = shallowRef('')
  const selectedRoutingIndex = shallowRef<number | null>(null)
  const buyerOrder = shallowRef<BuyerOrderDetailVm | null>(null)
  const selectedPOIds = ref<string[]>([])

  const matrices = shallowRef<AllocationMatrix[]>([])
  const autoOps = shallowRef<{ opName: string; teamId: string; teamName: string }[]>([])
  const opNames = shallowRef<string[]>([])
  const teams = shallowRef<TeamVm[]>([])
  const factories = shallowRef<UnitVm[]>([])
  const noteColumnCount = shallowRef(0)
  const syncDate = shallowRef<Date | null>(null)
  const productDate = shallowRef<Date | null>(null)
  const firstSku = shallowRef('')
  const plannedDates = ref<
    Record<string, { plannedStartDate: string | null; plannedEndDate: string | null }>
  >({})
  const hasAttemptedSubmit = ref(false)

  const availableCompanies = computed(() => {
    const selectedFactories = factories.value.filter((f) => selectedFactoryIds.value.includes(f.id))
    const map = new Map<string, { code: string; name: string }>()
    for (const f of selectedFactories) {
      const code = (f as UnitVm & { companyCode?: string }).companyCode || f.code || ''
      const name = f.companyName || code
      if (code) {
        map.set(code, { code, name })
      }
    }
    return Array.from(map.values())
  })

  const mainCompanyOptions = computed(() =>
    availableCompanies.value.map((c) => ({
      label: `${c.code} (${c.name})`,
      value: c.code,
    })),
  )

  watch(
    () => availableCompanies.value,
    (companies) => {
      if (companies.length === 1) {
        mainCompanyCode.value = companies[0].code
      } else if (companies.length === 0) {
        mainCompanyCode.value = ''
      } else if (!companies.some((c) => c.code === mainCompanyCode.value)) {
        mainCompanyCode.value = ''
      }
    },
    { immediate: true, flush: 'sync' },
  )

  const selectedPOs = computed((): PurchaseOrderVm[] => {
    if (!buyerOrder.value) return []
    return buyerOrder.value.purchaseOrders.filter((po) => selectedPOIds.value.includes(po.id))
  })

  const selectedRouting = computed(() => {
    if (!buyerOrder.value || selectedRoutingIndex.value === null) return null
    return buyerOrder.value.routings[selectedRoutingIndex.value] ?? null
  })

  const allSizes = computed(() => {
    if (!buyerOrder.value) return []
    return sortValuesByOrder(
      buyerOrder.value.purchaseOrders.flatMap((po) => po.skuQuantities.map((sku) => sku.size)),
      buyerOrder.value.styleSizeOrder,
    )
  })

  const subTotalMap = computed((): Record<SkuKey, number> => {
    const master = matrices.value[0]
    return master ? buildSubTotalMap(master) : {}
  })
  const demandMaps = computed(() => buildDemandMaps(matrices.value, subTotalMap.value))
  const summaryMatrix = computed(() => {
    const master = matrices.value[0]
    return master ? buildSummaryMatrix(master) : []
  })
  const totalSummaryQty = computed(() =>
    Object.values(subTotalMap.value).reduce((sum, value) => sum + value, 0),
  )
  const manualOperations = computed(() => matrices.value)
  const allOperationsAuto = computed(
    () => autoOps.value.length > 0 && autoOps.value.length === opNames.value.length,
  )
  const operationAllocations = computed(() =>
    opNames.value.map((operationName) => {
      const operationTeams = teams.value.filter((team) => team.operation === operationName)
      const isAuto = operationTeams.length === 1
      return {
        operationName,
        isAuto,
        teamCount: operationTeams.length,
        autoTeamName: isAuto ? operationTeams[0].name : '',
      }
    }),
  )
  const autoOperations = computed(() =>
    operationAllocations.value.filter((operation) => operation.isAuto),
  )
  const hasAnyTeamSelected = computed(() => {
    if (allOperationsAuto.value) return autoOps.value.length > 0
    return matrices.value.some((matrix) =>
      Object.values(matrix.rowMetaMap).some((metas) => metas.some((meta) => !!meta.teamId)),
    )
  })

  const scheduledAssignments = computed<TeamAssignmentScheduleItem[]>(() => {
    const list: TeamAssignmentScheduleItem[] = []
    const processedKeys = new Set<string>()

    matrices.value.forEach((matrix) => {
      if (allOperationsAuto.value) return
      for (const [poColorKey, metas] of Object.entries(matrix.rowMetaMap)) {
        metas.forEach((meta, rowIndex) => {
          if (!meta.teamId) return
          const key = `${meta.teamId}|${matrix.opName}`
          let rowTotal = 0
          for (const skuKey in matrix.qtyMap) {
            if (skuKey.startsWith(`${poColorKey}|`)) {
              rowTotal += matrix.qtyMap[skuKey][rowIndex] || 0
            }
          }
          if (!processedKeys.has(key)) {
            processedKeys.add(key)
            const team = teams.value.find((t) => t.id === meta.teamId)
            const dates = plannedDates.value[key]
            list.push({
              teamId: meta.teamId,
              operation: matrix.opName,
              teamName: team?.name || meta.teamName || 'Unknown',
              assignedQuantity: rowTotal,
              plannedStartDate: dates?.plannedStartDate ?? null,
              plannedEndDate: dates?.plannedEndDate ?? null,
            })
          } else {
            const existing = list.find(
              (item) => item.teamId === meta.teamId && item.operation === matrix.opName,
            )
            if (existing) {
              existing.assignedQuantity += rowTotal
            }
          }
        })
      }
    })

    autoOps.value.forEach((auto) => {
      const key = `${auto.teamId}|${auto.opName}`
      if (!processedKeys.has(key)) {
        processedKeys.add(key)
        const team = teams.value.find((t) => t.id === auto.teamId)
        const dates = plannedDates.value[key]
        list.push({
          teamId: auto.teamId,
          operation: auto.opName,
          teamName: team?.name || auto.teamName || 'Unknown',
          assignedQuantity: totalSummaryQty.value,
          plannedStartDate: dates?.plannedStartDate ?? null,
          plannedEndDate: dates?.plannedEndDate ?? null,
        })
      }
    })

    return list.sort((a, b) => {
      const opDiff = opNames.value.indexOf(a.operation) - opNames.value.indexOf(b.operation)
      if (opDiff !== 0) return opDiff
      return a.teamName.localeCompare(b.teamName)
    })
  })

  function setPlannedDates(
    teamId: string,
    operation: string,
    plannedStartDate: string | null,
    plannedEndDate: string | null,
  ) {
    const key = `${teamId}|${operation}`
    plannedDates.value = {
      ...plannedDates.value,
      [key]: { plannedStartDate, plannedEndDate },
    }
  }

  function applyDatesToAll(plannedStartDate: string | null, plannedEndDate: string | null) {
    const updated: Record<
      string,
      { plannedStartDate: string | null; plannedEndDate: string | null }
    > = {}
    scheduledAssignments.value.forEach((assignment) => {
      const key = `${assignment.teamId}|${assignment.operation}`
      updated[key] = { plannedStartDate, plannedEndDate }
    })
    plannedDates.value = updated
  }

  function goToStep(step: IssuanceStep) {
    if (step !== '3') {
      hasAttemptedSubmit.value = false
    }
    currentStep.value = step
  }

  function isCurrentStep(step: IssuanceStep) {
    return currentStep.value === step
  }

  function resetBOSelection() {
    buyerOrder.value = null
  }

  function validateStep1() {
    return validateIssuanceStep1({
      selectedBOId: selectedBOId.value,
      needsAllocationRevision: buyerOrder.value?.needsAllocationRevision ?? false,
      routingCount: buyerOrder.value?.routings.length ?? 0,
      selectedRoutingIndex: selectedRoutingIndex.value,
      selectedFactoryCount: selectedFactoryIds.value.length,
      mainCompanyCode: mainCompanyCode.value,
      selectedPOCount: selectedPOs.value.length,
      operationAllocations: operationAllocations.value,
    })
  }

  function validateStep2(missing: string[]) {
    return validateIssuanceStep2(missing)
  }

  function validateStep3() {
    return validateIssuanceStep3({ assignments: scheduledAssignments.value })
  }

  function addNoteColumn() {
    noteColumnCount.value++
  }

  function removeNoteColumn() {
    if (noteColumnCount.value === 0) return
    noteColumnCount.value--
    matrices.value.forEach((matrix) => {
      Object.values(matrix.rowMetaMap).forEach((rows) => {
        rows.forEach((row) => {
          row.notes = row.notes.slice(0, noteColumnCount.value)
        })
      })
    })
    triggerMatrices()
  }

  function triggerMatrices() {
    triggerRef(matrices)
  }

  function quickFillAll() {
    if (matrices.value.length === 0) return

    matrices.value.forEach((matrix) => {
      const temporarySums: Record<string, number> = {}
      for (const [skuKey, quantities] of Object.entries(matrix.qtyMap)) {
        temporarySums[skuKey] = quantities.reduce((sum, value) => sum + value, 0)
      }

      for (const [poColorKey, metas] of Object.entries(matrix.rowMetaMap)) {
        const [poId, color] = poColorKey.split('|')
        if (selectedPOIds.value.length > 0 && !selectedPOIds.value.includes(poId)) continue
        metas.forEach((_, rowIndex) => {
          allSizes.value.forEach((size) => {
            const skuKey = `${poId}|${color}|${size}`
            const remaining = Math.max(
              0,
              (matrix.totalMap[skuKey] || 0) - (temporarySums[skuKey] || 0),
            )
            if (remaining > 0) {
              if (!matrix.qtyMap[skuKey]) matrix.qtyMap[skuKey] = []
              matrix.qtyMap[skuKey][rowIndex] = (matrix.qtyMap[skuKey][rowIndex] || 0) + remaining
              temporarySums[skuKey] = (temporarySums[skuKey] || 0) + remaining
            }
          })
        })
      }
    })
    triggerMatrices()
  }

  function reset() {
    currentStep.value = '1'
    selectedBOId.value = ''
    selectedFactoryIds.value = []
    mainCompanyCode.value = ''
    selectedRoutingIndex.value = null
    buyerOrder.value = null
    selectedPOIds.value = []
    matrices.value = []
    autoOps.value = []
    opNames.value = []
    noteColumnCount.value = 0
    syncDate.value = null
    productDate.value = null
    firstSku.value = ''
    plannedDates.value = {}
    hasAttemptedSubmit.value = false
  }

  return {
    currentStep,
    selectedBOId,
    selectedFactoryIds,
    mainCompanyCode,
    availableCompanies,
    mainCompanyOptions,
    selectedRoutingIndex,
    buyerOrder,
    selectedPOIds,
    matrices,
    autoOps,
    opNames,
    teams,
    factories,
    noteColumnCount,
    syncDate,
    productDate,
    firstSku,
    plannedDates,
    hasAttemptedSubmit,
    scheduledAssignments,
    selectedPOs,
    selectedRouting,
    allSizes,
    subTotalMap,
    demandMaps,
    summaryMatrix,
    totalSummaryQty,
    manualOperations,
    allOperationsAuto,
    operationAllocations,
    autoOperations,
    hasAnyTeamSelected,
    goToStep,
    isCurrentStep,
    resetBOSelection,
    validateStep1,
    validateStep2,
    validateStep3,
    setPlannedDates,
    applyDatesToAll,
    addNoteColumn,
    removeNoteColumn,
    triggerMatrices,
    quickFillAll,
    reset,
  }
})

if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useProductionOrderIssuanceStore, import.meta.hot))
}
