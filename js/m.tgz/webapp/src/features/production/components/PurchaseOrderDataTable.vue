<script setup lang="ts">
import type { ProductionOrderVm } from '@/api'
import { ROUTE_PATH } from '@/app/router/path'
import ColumnDateFilter from '@/features/production/components/ColumnDateFilter.vue'
import ColumnMultiSelectFilter from '@/shared/components/ColumnMultiSelectFilter.vue'
import { fmtQty } from '@/shared/utils/fmtQty'
import {
  getProductionOrderNumber,
  getStatusLabel,
  getStatusSeverity,
} from '@/features/production/helpers/productionOrder'
import {
  hasNeedsAdjustment,
  needsAllocationRevision,
} from '@/features/production/helpers/reconciliation'
import type { SelectOption } from '@/shared/types'
import { handleRowNavigation, handleTableAuxClick } from '@/shared/utils/navigation'
import dayjs from 'dayjs'
import type { TableExpandedRows, TablePageEvent } from '@/shared/types/table'
import type { TableColumn, TableRow } from '@nuxt/ui'
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const props = defineProps<{
  orders: ProductionOrderVm[]
  loading: boolean
  totalRecords: number
  currentPage: number
  pageSize: number
  styleOptions: SelectOption[]
  boWfxIdOptions: SelectOption[]
  productionOrderOptions: SelectOption[]
  factoryOptions: SelectOption[]
  firstSkuOptions: SelectOption[]
  statusOptions: SelectOption[]
  sewingTeamOptions: SelectOption[]
}>()
const expandedRows = ref<TableExpandedRows>({})
type PoSummary = ProductionOrderVm['poSummaries'][number]
const columns: TableColumn<ProductionOrderVm>[] = [
  { id: 'expand' },
  { accessorKey: 'createdAt', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'styleName', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'code', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'boWfxId', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'factories', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'sewingTeams', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'totalQuantity', header: 'Sản lượng' },
  { id: 'syncDate', meta: { class: { th: 'p-0!' } } },
  { id: 'productDate', meta: { class: { th: 'p-0!' } } },
  { id: 'firstSku', meta: { class: { th: 'p-0!' } } },
  { id: 'deliveryDate', header: 'Ngày xuất hàng' },
  { accessorKey: 'status', meta: { class: { th: 'p-0!' } } },
]
const poColumns: TableColumn<PoSummary>[] = [
  { accessorKey: 'poCode', header: 'Mã PO' },
  { accessorKey: 'deliveryDate', header: 'Ngày giao' },
  { accessorKey: 'progressPercentage', header: 'Tiến độ' },
]

const styleFilter = defineModel<string[]>('styleFilter', { required: true })
const boWfxIdFilter = defineModel<string[]>('boWfxIdFilter', { required: true })
const productionOrderIdFilter = defineModel<string[]>('productionOrderIdFilter', {
  required: true,
})
const factoryIdFilter = defineModel<string[]>('factoryIdFilter', { required: true })
const firstSkuFilter = defineModel<string[]>('firstSkuFilter', { required: true })
const statusFilter = defineModel<string[]>('statusFilter', { required: true })
const sewingTeamIdsFilter = defineModel<string[]>('sewingTeamIdsFilter', { required: true })
const deliveryDateRange = defineModel<Date[] | null>('deliveryDateRange', { required: true })
const syncDateRange = defineModel<Date[] | null>('syncDateRange', { required: true })
const productDateRange = defineModel<Date[] | null>('productDateRange', { required: true })
const createdAtRange = defineModel<Date[] | null>('createdAtRange', { required: true })

const emit = defineEmits<{
  filterChange: [field: string, value: Date[] | null]
  page: [event: TablePageEvent]
}>()
const page = computed({
  get: () => props.currentPage + 1,
  set: (value: number) => emitPage(value - 1, props.pageSize),
})
const rows = computed({
  get: () => props.pageSize,
  set: (value: number) => emitPage(0, value),
})

// Make status helpers available in template
const statusLabel = getStatusLabel
const statusSeverity = getStatusSeverity

function selectOrder(event: Event, row: TableRow<ProductionOrderVm>) {
  handleRowNavigation(
    event,
    router,
    ROUTE_PATH.PRODUCTION_ORDER_DETAIL.replace(':id', row.original.id),
  )
}

function handleAuxClick(event: MouseEvent) {
  handleTableAuxClick(event, router, props.orders, (row) =>
    ROUTE_PATH.PRODUCTION_ORDER_DETAIL.replace(':id', row.id),
  )
}

const getOrderRowId = (row: ProductionOrderVm) => row.id

function emitPage(pageIndex: number, pageSize: number) {
  emit('page', {
    first: pageIndex * pageSize,
    rows: pageSize,
    page: pageIndex,
    pageCount: Math.ceil(props.totalRecords / pageSize),
  })
}

const handleSyncDateChange = (value: Date | Date[] | (Date | null)[] | null | undefined) =>
  emit('filterChange', 'syncDate', (value as Date[]) || null)
const handleProductDateChange = (value: Date | Date[] | (Date | null)[] | null | undefined) =>
  emit('filterChange', 'productDate', (value as Date[]) || null)
const handleCreatedAtChange = (value: Date | Date[] | (Date | null)[] | null | undefined) =>
  emit('filterChange', 'createdAt', (value as Date[]) || null)
const handleDeliveryDateChange = (value: Date | Date[] | (Date | null)[] | null | undefined) =>
  emit('filterChange', 'deliveryDate', (value as Date[]) || null)
</script>

<template>
  <div class="flex flex-col">
    <UTable
      :data="orders"
      :columns="columns"
      :loading="loading"
      v-model:expanded="expandedRows"
      :get-row-id="getOrderRowId"
      :ui="{ tr: 'cursor-pointer' }"
      @select="selectOrder"
      @auxclick="handleAuxClick"
    >
      <template #empty>
        <div
          class="rounded-lg border-2 border-dashed border-surface-200 bg-surface-50 p-12 text-center"
        >
          <UIcon name="i-lucide-inbox" class="mx-auto mb-4 size-12 text-toned" />
          <p class="text-toned">Chưa có lệnh sản xuất nào.</p>
        </div>
      </template>

      <template #expand-cell="{ row }">
        <UButton
          variant="ghost"
          color="neutral"
          size="xs"
          :icon="row.getIsExpanded() ? 'i-lucide-chevron-down' : 'i-lucide-chevron-right'"
          @click.stop="row.toggleExpanded()"
        />
      </template>

      <template #styleName-header>
        <ColumnMultiSelectFilter
          v-model="styleFilter"
          :items="styleOptions"
          placeholder="Mã hàng"
        />
      </template>

      <template #code-header>
        <ColumnMultiSelectFilter
          v-model="productionOrderIdFilter"
          :items="productionOrderOptions"
          placeholder="Lệnh số"
        />
      </template>
      <template #styleName-cell="{ row }">
        <RouterLink
          :to="ROUTE_PATH.PRODUCTION_ORDER_DETAIL.replace(':id', row.original.id)"
          class="font-medium hover:text-primary hover:underline"
          @click.stop
        >
          {{ row.original.styleName }}
        </RouterLink>
      </template>

      <template #code-cell="{ row }">
        <div class="flex items-center gap-2">
          <RouterLink
            :to="ROUTE_PATH.PRODUCTION_ORDER_DETAIL.replace(':id', row.original.id)"
            class="font-mono font-semibold hover:text-primary hover:underline"
            @click.stop
          >
            <code>{{ getProductionOrderNumber(row.original.code) }}</code>
          </RouterLink>
          <UButton
            v-if="hasNeedsAdjustment(row.original)"
            :title="'Có phân công cần điều chỉnh PO'"
            icon="i-lucide-triangle-alert"
            color="error"
            variant="ghost"
            size="sm"
            aria-label="Có phân công cần điều chỉnh PO"
            :to="{
              path: ROUTE_PATH.PRODUCTION_ORDER_DETAIL.replace(':id', row.original.id),
              query: { reconciliation: 'needs-adjustment' },
            }"
            @click.stop
          />
        </div>
      </template>

      <template #boWfxId-header>
        <ColumnMultiSelectFilter
          v-model="boWfxIdFilter"
          :items="boWfxIdOptions"
          placeholder="Đơn hàng"
        />
      </template>
      <template #boWfxId-cell="{ row }">
        <RouterLink
          v-if="row.original.buyerOrderId"
          :to="`/buyer-orders/${row.original.buyerOrderId}`"
          class="font-mono font-semibold hover:text-primary hover:underline"
          @click.stop
        >
          {{ row.original.boWfxId }}
        </RouterLink>
        <span v-else class="font-mono">{{ row.original.boWfxId }}</span>
      </template>

      <template #factories-header>
        <ColumnMultiSelectFilter
          v-model="factoryIdFilter"
          :items="factoryOptions"
          placeholder="Xí nghiệp"
        />
      </template>
      <template #factories-cell="{ row }">
        <div class="flex flex-wrap gap-1">
          <UBadge
            v-for="factory in row.original.factories"
            :key="factory.id"
            color="neutral"
            :label="factory.unitPath || factory.name"
            class="text-[10px]"
          />
        </div>
      </template>

      <template #sewingTeams-header>
        <ColumnMultiSelectFilter
          v-model="sewingTeamIdsFilter"
          :items="sewingTeamOptions"
          placeholder="Tổ may"
        />
      </template>
      <template #sewingTeams-cell="{ row }">
        <div v-if="row.original.sewingTeams.length" class="flex flex-wrap gap-1">
          <UBadge
            v-for="team in row.original.sewingTeams"
            :key="team.id"
            color="neutral"
            :label="team.name"
            class="text-[10px]"
          />
        </div>
        <span v-else class="text-toned">-</span>
      </template>

      <template #totalQuantity-cell="{ row }">
        <span class="font-mono font-medium">{{ fmtQty(row.original.totalQuantity) }}</span>
      </template>

      <template #syncDate-header>
        <ColumnDateFilter
          v-model="syncDateRange"
          label="Ngày đồng bộ"
          @update:model-value="handleSyncDateChange"
        />
      </template>
      <template #syncDate-cell="{ row }">
        {{
          row.original.metadata?.syncDate
            ? dayjs(row.original.metadata.syncDate).format('DD/MM/YYYY')
            : '-'
        }}
      </template>

      <template #productDate-header>
        <ColumnDateFilter
          v-model="productDateRange"
          label="Ngày vào chuyền"
          @update:model-value="handleProductDateChange"
        />
      </template>
      <template #productDate-cell="{ row }">
        {{
          row.original.metadata?.productDate
            ? dayjs(row.original.metadata.productDate).format('DD/MM/YYYY')
            : '-'
        }}
      </template>

      <template #firstSku-header>
        <ColumnMultiSelectFilter
          v-model="firstSkuFilter"
          :items="firstSkuOptions"
          placeholder="Màu/cỡ đầu tiên"
        />
      </template>
      <template #firstSku-cell="{ row }">
        {{ row.original.metadata?.firstSku || '-' }}
      </template>

      <template #deliveryDate-header>
        <ColumnDateFilter
          v-model="deliveryDateRange"
          label="Ngày xuất hàng"
          @update:model-value="handleDeliveryDateChange"
        />
      </template>
      <template #deliveryDate-cell="{ row }">
        <div v-if="row.original.earliestDeliveryDate" class="flex flex-col gap-0.5">
          <span class="font-medium text-highlighted">
            {{ dayjs(row.original.earliestDeliveryDate).format('DD/MM/YYYY') }}
          </span>
          <span
            v-if="
              row.original.latestDeliveryDate &&
              row.original.latestDeliveryDate !== row.original.earliestDeliveryDate
            "
            class="text-toned italic"
          >
            {{ dayjs(row.original.latestDeliveryDate).format('DD/MM/YYYY') }}
          </span>
        </div>
        <span v-else class="text-toned">-</span>
      </template>

      <template #status-header>
        <ColumnMultiSelectFilter
          v-model="statusFilter"
          :items="statusOptions"
          placeholder="Trạng thái"
        />
      </template>
      <template #status-cell="{ row }">
        <div class="flex flex-wrap gap-2">
          <UBadge
            :label="statusLabel(row.original.status)"
            :color="statusSeverity(row.original.status)"
          />
          <UBadge
            v-if="needsAllocationRevision(row.original)"
            :title="'WFX đã đổi PO/SKU, cần chỉnh phân bổ LSX'"
            label="Cần chỉnh phân bổ"
            color="warning"
            icon="i-lucide-triangle-alert"
          />
        </div>
      </template>

      <template #createdAt-header>
        <ColumnDateFilter
          v-model="createdAtRange"
          label="Ngày phát lệnh"
          @update:model-value="handleCreatedAtChange"
        />
      </template>
      <template #createdAt-cell="{ row }">
        {{ dayjs(row.original.createdAt).format('HH:mm, DD/MM/YYYY') }}
      </template>

      <!-- Expansion Row -->
      <template #expanded="{ row }">
        <div class="bg-surface-50 p-4">
          <div class="rounded-xl border border-surface-200 bg-surface-0 p-5 shadow-sm">
            <div class="mb-5 flex items-center justify-between">
              <h3 class="flex items-center gap-2 text-lg font-bold text-highlighted">
                <UIcon name="i-lucide-clipboard-list" class="text-primary" />
                Danh sách PO
              </h3>
            </div>

            <UTable :data="row.original.poSummaries" :columns="poColumns">
              <template #deliveryDate-cell="{ row: poRow }">
                {{
                  poRow.original.deliveryDate
                    ? dayjs(poRow.original.deliveryDate).format('DD/MM/YYYY')
                    : '-'
                }}
              </template>
              <template #progressPercentage-cell="{ row: poRow }">
                <div class="flex items-center gap-3">
                  <UProgress
                    :model-value="Math.round(poRow.original.progressPercentage)"
                    class="h-1.5! flex-1 bg-surface-200!"
                  />
                  <span class="min-w-16 text-right text-xs font-semibold text-default">
                    {{ poRow.original.completedQuantity }}/{{ poRow.original.totalQuantity }} ({{
                      Math.round(poRow.original.progressPercentage)
                    }}%)
                  </span>
                </div>
              </template>
            </UTable>
          </div>
        </div>
      </template>
    </UTable>

    <div class="flex items-center justify-center gap-3 border-t border-default px-3 py-3">
      <UPagination v-model:page="page" :total="totalRecords" :items-per-page="pageSize" />
      <USelect v-model="rows" :items="[2, 5, 10, 20, 50]" class="w-20" />
    </div>
  </div>
</template>
