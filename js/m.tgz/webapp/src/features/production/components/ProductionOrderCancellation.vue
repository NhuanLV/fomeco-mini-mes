<script setup lang="ts">
import { cancelProductionOrder, type ProductionOrderHistory, type ProductionOrderVm } from '@/api'
import { useAuthStore } from '@/shared/stores/auth'
import { clearLoading, showError, showLoading, showSuccess } from '@/shared/utils/toast'
import { computed, onUnmounted, ref, watch } from 'vue'

const props = defineProps<{ order: ProductionOrderVm; history?: ProductionOrderHistory[] | null }>()
const emit = defineEmits<{ refresh: [] }>()
const { hasPermission } = useAuthStore()
const open = ref(false)
const reason = ref('')
const submitting = ref(false)
const canCancel = computed(
  () =>
    props.order.status !== 'CANCELLED' &&
    props.order.factories.length > 0 &&
    props.order.factories.every((factory) => hasPermission('CANCEL_PRODUCTION_ORDER', factory.id)),
)
const latest = computed(() => props.history?.find((row) => row.action === 'CANCEL'))
const pendingActivityId = ref<string | null>(null)
const pending = computed(() => !!pendingActivityId.value || latest.value?.syncStatus === 'PENDING')
const toastGroup = `po-cancel-${props.order.id}`
const showPending = () =>
  showLoading('Đang đồng bộ FPO/FPPO trên WFX...', 'Đang hủy LSX', toastGroup)

watch(
  [latest, pendingActivityId],
  ([activity, requestId], [previous]) => {
    const status = activity?.syncStatus
    if (status === 'PENDING') {
      showPending()
    } else if (status && (previous?.syncStatus === 'PENDING' || activity?.id === requestId)) {
      pendingActivityId.value = null
      clearLoading(toastGroup)
      if (status === 'SUCCESS' || status === 'NOT_APPLICABLE') {
        showSuccess('Đã hủy Lệnh sản xuất')
      } else if (status === 'FAILED') {
        showError(latest.value?.syncMessage || 'Hủy Lệnh sản xuất chưa thành công')
      }
    }
  },
  { immediate: true },
)
onUnmounted(() => clearLoading(toastGroup))

async function submit() {
  if (submitting.value || pending.value || !canCancel.value) return
  if (!reason.value.trim()) {
    showError('Vui lòng nhập lý do hủy Lệnh sản xuất.')
    return
  }
  submitting.value = true
  try {
    const { data } = await cancelProductionOrder({
      path: { id: props.order.id },
      body: { reason: reason.value.trim() },
      throwOnError: true,
    })
    open.value = false
    reason.value = ''
    if (data.syncStatus === 'PENDING') {
      pendingActivityId.value = data.id
      showPending()
    } else {
      clearLoading(toastGroup)
      showSuccess('Đã hủy Lệnh sản xuất')
    }
    emit('refresh')
  } catch (e) {
    clearLoading(toastGroup)
    showError((e as Error).message)
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <slot
    name="actions"
    :can-cancel="canCancel"
    :disabled="pending || submitting || !history"
    :open="() => (open = true)"
  >
    <UButton
      v-if="canCancel"
      label="Hủy LSX"
      color="error"
      icon="i-lucide-trash-2"
      size="md"
      class="shrink-0"
      :disabled="pending || submitting || !history"
      @click="open = true"
    />
  </slot>
  <UModal v-model:open="open" title="Hủy Lệnh sản xuất" :dismissible="!submitting">
    <template #body>
      <p class="mb-4">Hủy vĩnh viễn LSX {{ order.code }}. Cần hủy hết Kanban trước khi tiếp tục.</p>
      <UFormField label="Lý do hủy" required>
        <UTextarea v-model="reason" class="w-full" :disabled="submitting" />
      </UFormField>
    </template>
    <template #footer>
      <UButton
        label="Đóng"
        color="neutral"
        variant="ghost"
        :disabled="submitting"
        @click="open = false"
      />
      <UButton label="Xác nhận hủy" color="error" :loading="submitting" @click="submit" />
    </template>
  </UModal>
  <slot />
</template>
