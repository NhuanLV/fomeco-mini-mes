<script setup lang="ts">
import { useBuyerOrderSearch } from '@/features/buyer-order/composables/useBuyerOrderSearch'
import { useStyleSearch } from '@/features/buyer-order/composables/useStyleSearch'
import OperationAssignmentPreview from '@/features/production/components/OperationAssignmentPreview.vue'
import { useAllocationInit } from '@/features/production/composables/useAllocationInit'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { refDebounced } from '@vueuse/core'
import { storeToRefs } from 'pinia'
import { computed, shallowRef, watch } from 'vue'

const props = defineProps<{ boLocked?: boolean }>()
const issuanceStore = useProductionOrderIssuanceStore()
const {
  buyerOrder,
  selectedBOId,
  selectedPOIds,
  selectedFactoryIds,
  mainCompanyCode,
  mainCompanyOptions,
  selectedRoutingIndex,
  selectedRouting,
  factories,
  teams,
  operationAllocations,
} = storeToRefs(issuanceStore)
const { resetBOSelection } = issuanceStore
const { init: initOperationAllocations } = useAllocationInit()

const _styleFilter = shallowRef('')
const searchBoText = shallowRef('')
const searchStyleText = shallowRef('')
const searchBoDebounced = refDebounced(searchBoText, 300)
const searchStyleDebounced = refDebounced(searchStyleText, 300)

// selectedStyle derives from buyerOrder when loaded, falls back to local filter.
// The setter clears the selected BO when the user picks a different style.
const selectedStyle = computed({
  get: () => buyerOrder.value?.styleName ?? _styleFilter.value,
  set: (val: string) => {
    if (props.boLocked) return
    _styleFilter.value = val
    const boStyle =
      buyerOrder.value?.styleName ??
      allOrders.value.find((o) => o.id === selectedBOId.value)?.styleName
    if (selectedBOId.value && boStyle && boStyle !== val) {
      selectedBOId.value = ''
      resetBOSelection()
    }
  },
})

const { allOrders, isLoading, isFetchingNextPage, hasMore, fetchNextPage } = useBuyerOrderSearch(
  _styleFilter,
  searchBoDebounced,
)

const {
  allStyles,
  isLoading: isStyleLoading,
  isFetchingNextPage: isFetchingNextStylePage,
  hasMore: hasMoreStyle,
  fetchNextPage: fetchNextStylePage,
} = useStyleSearch(searchStyleDebounced)

// Style options (unique styles from loaded styles + ensure locked style is always present)
const styleOptions = computed(() => {
  const styles = new Set(allStyles.value.map((o) => o.id).filter((id): id is string => !!id))
  if (buyerOrder.value?.styleName) styles.add(buyerOrder.value.styleName)
  // BO style fallback
  const boStyle = allOrders.value.find((o) => o.id === selectedBOId.value)?.styleName
  if (boStyle) styles.add(boStyle)

  return Array.from(styles).map((s) => ({ label: s, value: s }))
})

const factoryOptions = computed(() =>
  factories.value.map((f) => ({
    label: `${f.name} - ${f.companyName || 'Unknown'}`,
    value: f.id,
  })),
)

const currentBO = computed(() => {
  if (buyerOrder.value && buyerOrder.value.id === selectedBOId.value) {
    return buyerOrder.value
  }
  return allOrders.value.find((o) => o.id === selectedBOId.value)
})

const routingOptions = computed(() => {
  if (!buyerOrder.value) return []
  return buyerOrder.value.routings.map((r, i) => ({
    label: `${r.title || `Routing ${i + 1}`} — ${r.operations.join(' → ')}`,
    value: i,
  }))
})

const showRoutingSelector = computed(() => buyerOrder.value && buyerOrder.value.routings.length > 1)

const boHasNoRouting = computed(() => buyerOrder.value && buyerOrder.value.routings.length === 0)

function onBOChange(newId: string | null) {
  if (!newId) {
    resetBOSelection()
  }
}

function onRoutingChange() {
  initOperationAllocations()
}

watch(
  () => [teams.value, selectedPOIds.value, selectedRoutingIndex.value],
  () => {
    if (issuanceStore.isCurrentStep('1')) {
      initOperationAllocations()
    }
  },
  { deep: true },
)
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex w-full items-center justify-between gap-4">
        <div class="flex items-center gap-2">
          <span
            class="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs text-white"
            >1</span
          >
          <span>Thiết lập thông tin</span>
        </div>

        <div
          v-if="currentBO"
          class="flex items-center gap-4 rounded-lg border border-surface-200 bg-surface-50 px-3 py-1.5 text-xs font-normal"
        >
          <div class="flex min-w-0 items-center gap-1.5">
            <span class="text-[10px] font-medium text-toned uppercase">Khách hàng:</span>
            <span class="truncate font-semibold text-primary">{{
              currentBO?.customer || '---'
            }}</span>
          </div>
          <div class="flex min-w-0 items-center gap-1.5">
            <span class="text-[10px] font-medium text-toned uppercase">Mùa:</span>
            <span class="truncate font-semibold text-highlighted">{{
              currentBO?.season || '---'
            }}</span>
          </div>
        </div>
      </div>
    </template>

    <template #default>
      <div class="grid grid-cols-1 gap-6 md:grid-cols-4">
        <!-- Style Select -->
        <div class="flex flex-col gap-2">
          <label class="text-sm font-medium text-default">1. Chọn Mã hàng (Style)</label>
          <USelectMenu
            v-model="selectedStyle"
            :items="styleOptions"
            label-key="label"
            value-key="value"
            placeholder="Tất cả Mã hàng"
            class="w-full"
            clear
            :search-input="{ placeholder: 'Tìm kiếm Mã hàng...' }"
            @update:search-term="searchStyleText = $event"
            :loading="isStyleLoading"
            :disabled="props.boLocked"
          >
            <template #content-bottom>
              <div v-if="isFetchingNextStylePage" class="p-2 text-center">
                <UIcon name="i-lucide-loader-circle" class="size-4 animate-spin text-primary" />
              </div>
              <div
                v-else-if="hasMoreStyle"
                class="flex cursor-pointer items-center justify-center gap-1.5 p-2 text-center text-xs font-medium text-blue-500 transition-colors hover:bg-surface-100"
                @click.stop="fetchNextStylePage()"
              >
                <UIcon name="i-lucide-chevron-down" />
                Tải thêm
              </div>
            </template>
          </USelectMenu>
        </div>

        <!-- BO Select -->
        <div class="flex flex-col gap-2">
          <label class="text-sm font-medium text-default">2. Chọn Đơn hàng (BO)</label>
          <USelectMenu
            v-model="selectedBOId"
            :items="allOrders"
            label-key="wfxId"
            value-key="id"
            :placeholder="props.boLocked ? `${buyerOrder?.wfxId}` : 'Chọn đơn hàng'"
            class="w-full"
            clear
            :search-input="{ placeholder: 'Tìm kiếm BO...' }"
            @update:search-term="searchBoText = $event"
            @update:model-value="onBOChange"
            :loading="isLoading"
            :disabled="props.boLocked"
          >
            <template #default>
              <span class="truncate">{{ currentBO?.wfxId || 'Chọn đơn hàng' }}</span>
            </template>
            <template #item="slotProps">
              <div class="flex flex-col">
                <div class="font-semibold">{{ slotProps.item.wfxId }}</div>
                <div class="text-xs text-toned">
                  {{ slotProps.item.customer }} - {{ slotProps.item.season }}
                </div>
              </div>
            </template>
            <template #content-bottom>
              <div v-if="isFetchingNextPage" class="p-2 text-center">
                <UIcon name="i-lucide-loader-circle" class="size-4 animate-spin text-primary" />
              </div>
              <div
                v-else-if="hasMore"
                class="flex cursor-pointer items-center justify-center gap-1.5 p-2 text-center text-xs font-medium text-blue-500 transition-colors hover:bg-surface-100"
                @click.stop="fetchNextPage()"
              >
                <UIcon name="i-lucide-chevron-down" />
                Tải thêm
              </div>
            </template>
          </USelectMenu>
        </div>

        <!-- Factory Select -->
        <div class="flex flex-col gap-2">
          <label class="text-sm font-medium text-default">3. Chọn Xí nghiệp (Factory)</label>
          <USelectMenu
            multiple
            v-model="selectedFactoryIds"
            :items="factoryOptions"
            label-key="label"
            value-key="value"
            placeholder="Chọn các xí nghiệp"
            class="w-full"
            search-input
          />
        </div>

        <!-- Main Company Select -->
        <div class="flex flex-col gap-2">
          <label class="text-sm font-medium text-default">4. Chọn Mã Công ty đảm nhiệm chính</label>
          <USelectMenu
            v-model="mainCompanyCode"
            :items="mainCompanyOptions"
            label-key="label"
            value-key="value"
            placeholder="Chọn mã công ty"
            class="w-full"
            :disabled="mainCompanyOptions.length === 0"
          />
        </div>
      </div>

      <!-- Routing Section -->
      <div v-if="buyerOrder" class="mt-6">
        <!-- Warning: BO không có routing -->
        <div
          v-if="boHasNoRouting"
          class="flex items-center gap-3 rounded-lg border border-amber-200 bg-amber-50 p-3 text-amber-800"
        >
          <UIcon name="i-lucide-triangle-alert" class="size-5 shrink-0 text-amber-500" />
          <span class="text-sm font-medium">
            Đơn hàng này chưa có Routing. Vui lòng đồng bộ BOM từ WFX trước khi phát LSX.
          </span>
        </div>

        <!-- Routing selector (nếu BO có nhiều routing) -->
        <div v-else-if="showRoutingSelector" class="flex flex-col gap-2">
          <label class="text-sm font-medium text-default">
            <span>5. Chọn Quy trình (Routing)</span>
          </label>
          <USelect
            :model-value="selectedRoutingIndex ?? undefined"
            :items="routingOptions"
            label-key="label"
            value-key="value"
            placeholder="Chọn quy trình sản xuất"
            class="w-full md:w-1/2"
            @update:model-value="
              (val: number | undefined) => {
                selectedRoutingIndex = val ?? null
                onRoutingChange()
              }
            "
          />
        </div>

        <!-- Auto-selected routing (chỉ 1 routing) -->
        <div v-else-if="selectedRouting" class="flex items-center gap-3">
          <span class="text-sm text-toned">Quy trình sản xuất:</span>
          <div class="flex items-center gap-1.5">
            <template v-for="(op, idx) in selectedRouting.operations" :key="op">
              <UBadge :label="op" color="neutral" />
              <UIcon
                v-if="idx < selectedRouting.operations.length - 1"
                name="i-lucide-arrow-right"
                class="size-3 text-toned"
              />
            </template>
          </div>
        </div>

        <!-- Operation auto-assign preview (sau khi chọn routing + factory) -->
        <OperationAssignmentPreview :allocations="operationAllocations" />
      </div>
    </template>
  </UCard>
</template>
