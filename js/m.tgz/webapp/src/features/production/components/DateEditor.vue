<script setup lang="ts">
import { onMounted, ref } from 'vue'
import AppDatePicker from '@/shared/components/AppDatePicker.vue'

const props = defineProps<{
  value: string | null | undefined
  save: (val: string, preventFocus?: boolean) => void
  close: (isCancel?: boolean) => void
}>()

type DatePickerInstance = InstanceType<typeof AppDatePicker> & {
  $el?: HTMLElement
  show?: () => void
}

const pickerRef = ref<DatePickerInstance | null>(null)
const dateValue = ref<Date | null>(props.value ? new Date(props.value) : null)

function handleSelect(val: Date | null): void {
  if (val instanceof Date && !isNaN(val.getTime())) {
    const year = val.getFullYear()
    const month = String(val.getMonth() + 1).padStart(2, '0')
    const day = String(val.getDate()).padStart(2, '0')
    const dateStr = `${year}-${month}-${day}`

    props.save(dateStr, true)
  } else {
    props.save('', true)
  }

  props.close()
}

function handleHide(): void {
  props.close(true)
}

onMounted(() => {
  setTimeout(() => {
    const picker = pickerRef.value
    const input = picker?.$el?.querySelector('input')

    input?.focus()
    input?.select()
    picker?.show?.()
  }, 10)
})
</script>

<template>
  <div class="date-editor-container flex h-full w-full items-center bg-white px-1">
    <AppDatePicker
      ref="pickerRef"
      v-model="dateValue"
      @date-select="handleSelect"
      @hide="handleHide"
      autofocus
      input-class="h-8 border-none bg-transparent px-2 text-[13px] shadow-none focus:ring-0"
      class="w-full"
    />
  </div>
</template>
