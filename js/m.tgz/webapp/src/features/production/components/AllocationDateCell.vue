<script setup lang="ts">
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { computed } from 'vue'
import AppDatePicker from '@/shared/components/AppDatePicker.vue'

interface Addition {
  onSplit: (groupIndex: number) => void
  onDelete: (groupIndex: number, rowIndex: number) => void
  onDateChange: (rowIndex: number, prop: string, value: string) => void
}

const props = defineProps<MatrixGridCellProps & { addition?: Addition }>()

function parseDate(val: unknown): Date | null {
  if (!val || typeof val !== 'string' || val.trim() === '') return null
  const [y, m, d] = val.split('-').map(Number)
  if (!y || !m || !d) return null
  return new Date(y, m - 1, d)
}

function formatDate(date: Date): string {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

const dateValue = computed({
  get(): Date | null {
    return parseDate(props.model?.[props.prop as string])
  },
  set(date: Date | null) {
    const formatted = date ? formatDate(date) : ''
    props.addition?.onDateChange(props.rowIndex as number, String(props.prop), formatted)
  },
})
</script>

<template>
  <div class="flex h-full w-full items-center justify-center px-1" @click.stop @mousedown.stop>
    <AppDatePicker
      v-model="dateValue"
      input-class="!shadow-none !border-none !bg-transparent !p-0"
    />
    <UIcon name="i-lucide-calendar" />
  </div>
</template>
