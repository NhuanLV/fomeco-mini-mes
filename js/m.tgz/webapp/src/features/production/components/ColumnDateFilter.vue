<script setup lang="ts">
import ColumnDateFilter from '@/shared/components/ColumnDateFilter.vue'

defineProps<{
  modelValue: Date[] | null
  label: string
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: Date[] | null): void
}>()
</script>

<template>
  <ColumnDateFilter
    :model-value="modelValue"
    :label="label"
    @update:model-value="emit('update:modelValue', $event)"
  />
</template>
