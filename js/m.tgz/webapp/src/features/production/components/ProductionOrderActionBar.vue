<script setup lang="ts">
import { useStepNavigation } from '@/features/production/composables/useStepNavigation'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { storeToRefs } from 'pinia'

const emit = defineEmits<{ submitSuccess: [] }>()

const { buyerOrder, selectedPOs, hasAnyTeamSelected } = storeToRefs(
  useProductionOrderIssuanceStore(),
)
const {
  showDuplicateDialog,
  duplicateWarnings,
  closeDuplicateDialog,
  goToStep1,
  goToStep2,
  backToStep2,
  handleSubmit,
  doSubmit,
  submitting,
  submissionError,
  isCurrent,
} = useStepNavigation()

async function onDoSubmit() {
  const success = await doSubmit()
  if (success) emit('submitSuccess')
}
</script>

<template>
  <!-- Sticky bottom action bar -->
  <div
    class="fixed right-0 bottom-0 left-0 z-10 border-t border-surface-200 bg-surface-0 px-4 py-3 shadow-lg"
  >
    <UAlert
      v-if="submissionError"
      role="alert"
      color="error"
      icon="i-lucide-triangle-alert"
      :description="submissionError"
      class="mb-3"
    />
    <div class="flex items-center justify-between gap-3">
      <div class="flex-1">
        <UButton
          v-if="isCurrent('2')"
          color="neutral"
          variant="ghost"
          size="sm"
          icon="i-lucide-arrow-left"
          label="Quay lại"
          class="w-full sm:w-auto"
          @click="goToStep1"
        />
        <UButton
          v-else-if="isCurrent('3')"
          color="neutral"
          variant="ghost"
          size="sm"
          icon="i-lucide-arrow-left"
          label="Sửa lại"
          class="w-full sm:w-auto"
          @click="backToStep2"
        />
      </div>

      <div class="flex flex-1 justify-end">
        <UButton
          v-if="isCurrent('1') && buyerOrder"
          label="Phân bổ"
          icon="i-lucide-arrow-right"
          icon-pos="right"
          size="sm"
          :disabled="selectedPOs.length === 0"
          :title="selectedPOs.length === 0 ? 'Vui lòng chọn ít nhất 1 PO' : undefined"
          class="w-full sm:w-auto"
          @click="goToStep2"
        />
        <UButton
          v-if="isCurrent('2')"
          icon="i-lucide-eye"
          label="Preview"
          size="sm"
          :disabled="!hasAnyTeamSelected"
          :title="!hasAnyTeamSelected ? 'Chưa chọn tổ' : undefined"
          class="w-full sm:w-auto"
          @click="handleSubmit"
        />
        <UButton
          v-if="isCurrent('3')"
          icon="i-lucide-send"
          :label="submissionError ? 'Thử lại và Phát lệnh' : 'Phát lệnh'"
          color="primary"
          size="sm"
          raised
          :loading="submitting"
          class="w-full sm:w-auto"
          @click="onDoSubmit"
        />
      </div>
    </div>
  </div>

  <!-- Duplicate team assignment warning dialog -->
  <UModal
    v-model:open="showDuplicateDialog"
    title="Phân công trùng tổ"
    :close="false"
    class="sm:max-w-[28rem]"
  >
    <template #body>
      <div class="flex flex-col gap-3">
        <p class="text-sm text-default">
          Các màu sau đang được phân bổ cho cùng một tổ ở nhiều dòng. Vui lòng sửa lại.
        </p>
        <ul class="flex flex-col gap-1">
          <li
            v-for="item in duplicateWarnings"
            :key="item"
            class="flex items-center gap-2 text-sm font-medium"
          >
            <UIcon name="i-lucide-triangle-alert" class="size-4 shrink-0 text-amber-500" />
            {{ item }}
          </li>
        </ul>
      </div>
    </template>
    <template #footer>
      <div class="flex justify-end gap-2">
        <UButton label="Sửa lại" color="neutral" @click="closeDuplicateDialog" />
      </div>
    </template>
  </UModal>
</template>
