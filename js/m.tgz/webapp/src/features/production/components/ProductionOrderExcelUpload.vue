<script setup lang="ts">
import { shallowRef } from 'vue'

const props = withDefaults(
  defineProps<{
    variant?: 'button' | 'dropzone'
    label?: string
  }>(),
  {
    variant: 'button',
    label: 'Nhập từ Excel',
  },
)

const emit = defineEmits<{
  selectFile: [file: File]
}>()

const uploadInstanceKey = shallowRef(0)

function onSelect(file: File | null | undefined) {
  if (file) emit('selectFile', file)
  uploadInstanceKey.value += 1
}
</script>

<template>
  <UFileUpload
    :key="uploadInstanceKey"
    name="allocation-excel"
    accept=".xlsx,.xls"
    :variant="props.variant === 'button' ? 'button' : 'area'"
    :preview="false"
    reset
    @update:model-value="onSelect"
  >
    <template v-if="props.variant === 'dropzone'" #default>
      <div>
        <slot />
      </div>
    </template>
    <template v-else #default="{ open }">
      <UButton
        :label="props.label"
        color="success"
        variant="outline"
        icon="i-lucide-file-spreadsheet"
        @click="open()"
      />
    </template>
  </UFileUpload>
</template>
