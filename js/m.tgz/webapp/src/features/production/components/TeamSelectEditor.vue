<script setup lang="ts">
import { ref } from 'vue'

const props = defineProps<{
  value: string | null | undefined
  model: {
    teamOptions?: Array<{ label: string; value: string; disabled?: boolean }>
  }
  save: (val: string, preventFocus?: boolean) => void
  close: (isCancel?: boolean) => void
}>()

const selectRef = ref()
const open = ref(true)
const selectedValue = ref(props.value ?? '')
const options = ref(props.model?.teamOptions || [])

function handleSave() {
  props.save(String(selectedValue.value ?? ''), true)
  props.close()
}

function handleCancel() {
  props.close(true)
}
</script>

<template>
  <div class="flex h-full w-full items-center bg-white px-1">
    <USelectMenu
      ref="selectRef"
      v-model:open="open"
      v-model="selectedValue"
      :items="options"
      label-key="label"
      value-key="value"
      @update:model-value="handleSave"
      @blur="handleCancel"
      autofocus
      :ui="{
        base: 'border-none! shadow-none! bg-transparent focus:ring-0 h-8',
        content: 'w-96 max-w-[calc(100vw-2rem)]',
      }"
    />
  </div>
</template>
