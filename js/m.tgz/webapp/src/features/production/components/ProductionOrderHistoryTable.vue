<script setup lang="ts">
import type { ProductionOrderAllocationChange, ProductionOrderHistory } from '@/api'
import type { TableColumn } from '@nuxt/ui'
import { fmtQty } from '@/shared/utils/fmtQty'
import dayjs from 'dayjs'
import { computed, ref } from 'vue'

withDefaults(
  defineProps<{
    history?: ProductionOrderHistory[] | null
    loading: boolean
    error?: boolean
  }>(),
  { history: null, error: false },
)

const isExpanded = defineModel<boolean>('isExpanded', { default: false })
const detailItem = ref<ProductionOrderHistory | null>(null)
const detailOpen = ref(false)
const detailRows = computed(() => detailItem.value?.changes ?? [])

const columns: TableColumn<ProductionOrderHistory>[] = [
  { id: 'action', header: 'Loại thao tác' },
  { id: 'content', header: 'Nội dung hoạt động' },
  { id: 'actor', header: 'Người thực hiện' },
  { id: 'occurredAt', header: 'Thời gian' },
  { id: 'sync', header: 'Trạng thái FPO/FPPO' },
  { accessorKey: 'note', header: 'Ghi chú' },
]
const detailColumns: TableColumn<ProductionOrderAllocationChange>[] = [
  { accessorKey: 'operation', header: 'Công đoạn' },
  { id: 'team', header: 'Tổ' },
  { id: 'po', header: 'Mã PO' },
  { accessorKey: 'size', header: 'Cỡ' },
  { accessorKey: 'color', header: 'Màu' },
  { id: 'change', header: 'Thay đổi' },
]
const actionLabels = { CREATE: 'Tạo LSX', REVISE: 'Điều chỉnh LSX', CANCEL: 'Hủy LSX' }
const syncLabels = {
  PENDING: 'Đang xử lý',
  SUCCESS: 'Thành công',
  FAILED: 'Thất bại',
  NOT_APPLICABLE: 'Không áp dụng',
}

function actionLabel(action: ProductionOrderHistory['action']) {
  return actionLabels[action]
}

function syncLabel(status: ProductionOrderHistory['syncStatus']) {
  return status ? syncLabels[status] : 'Không có dữ liệu lịch sử'
}

function syncColor(status: ProductionOrderHistory['syncStatus']) {
  if (status === 'SUCCESS') return 'success'
  if (status === 'FAILED') return 'error'
  if (status === 'PENDING') return 'warning'
  return 'neutral'
}

function actionColor(action: ProductionOrderHistory['action']) {
  if (action === 'CREATE') return 'success'
  if (action === 'REVISE') return 'warning'
  return 'error'
}

function formatQuantityChange(change: ProductionOrderAllocationChange) {
  return `${fmtQty(change.before?.quantity ?? 0)} → ${fmtQty(change.after?.quantity ?? 0)}`
}

function formatAllocationChange(change: ProductionOrderAllocationChange) {
  return `${change.operation} / ${change.teamName ?? change.teamId} / ${change.purchaseOrderCode ?? change.purchaseOrderId} — ${change.size}/${change.color}: ${formatQuantityChange(change)}`
}

function getSummary(changes: ProductionOrderAllocationChange[]) {
  const visibleIndexes: number[] = []
  const seenColors = new Set<string>()

  changes.forEach((change, index) => {
    if (visibleIndexes.length >= 2 || seenColors.has(change.color)) return
    visibleIndexes.push(index)
    seenColors.add(change.color)
  })

  if (visibleIndexes.length < 2) {
    changes.forEach((_, index) => {
      if (visibleIndexes.length >= 2 || visibleIndexes.includes(index)) return
      visibleIndexes.push(index)
    })
  }

  return {
    visible: visibleIndexes.map((index) => changes[index]!),
    remaining: changes.length - visibleIndexes.length,
  }
}

function showDetail(item: ProductionOrderHistory) {
  detailItem.value = item
  detailOpen.value = true
}
</script>

<template>
  <UCard>
    <template #title>
      <div
        data-testid="history-header"
        class="flex cursor-pointer items-center justify-between gap-2 select-none"
        @click="isExpanded = !isExpanded"
      >
        <div class="flex items-center gap-2">
          <UIcon name="i-lucide-clock" class="size-5 text-primary" />
          <span class="font-semibold">Lịch sử hoạt động</span>
        </div>
        <UButton
          :label="isExpanded ? 'Thu gọn' : 'Xem lịch sử'"
          :icon="isExpanded ? 'i-lucide-chevron-up' : 'i-lucide-chevron-down'"
          :aria-expanded="isExpanded"
          color="primary"
          variant="subtle"
          size="xs"
          class="font-medium"
          @click.stop="isExpanded = !isExpanded"
        />
      </div>
    </template>
    <template v-if="isExpanded" #default>
      <UAlert v-if="error" color="error" title="Không tải được lịch sử LSX" />
      <UTable v-else :data="history ?? []" :columns="columns" :loading="loading" class="text-sm">
        <template #action-cell="{ row }">
          <UBadge
            :label="actionLabel(row.original.action)"
            :color="actionColor(row.original.action)"
          />
        </template>
        <template #content-cell="{ row }">
          <div
            v-if="row.original.action === 'REVISE'"
            class="flex min-w-72 flex-wrap items-center gap-x-2 gap-y-1"
          >
            <span
              v-for="(change, index) in getSummary(row.original.changes).visible"
              :key="index"
              data-testid="allocation-summary"
            >
              {{ formatAllocationChange(change)
              }}<template v-if="index < getSummary(row.original.changes).visible.length - 1"
                >,</template
              >
            </span>
            <span
              v-if="getSummary(row.original.changes).remaining > 0"
              data-testid="remaining-count"
              class="rounded-full bg-sky-100 px-2 py-0.5 text-xs font-semibold text-sky-700"
            >
              +{{ getSummary(row.original.changes).remaining }}
            </span>
            <UButton
              v-if="row.original.changes.length"
              label="Xem chi tiết"
              variant="link"
              size="sm"
              class="px-0!"
              @click="showDetail(row.original)"
            />
          </div>
        </template>
        <template #actor-cell="{ row }">{{
          row.original.actor?.name ?? 'Không xác định'
        }}</template>
        <template #occurredAt-cell="{ row }">{{
          dayjs(row.original.occurredAt).format('HH:mm, DD/MM/YYYY')
        }}</template>
        <template #sync-cell="{ row }">
          <div class="flex max-w-32 min-w-0 flex-col items-start gap-1">
            <UBadge
              data-testid="sync-badge"
              :color="syncColor(row.original.syncStatus)"
              :label="syncLabel(row.original.syncStatus)"
              class="max-w-full text-center whitespace-normal"
            />
            <span
              v-if="row.original.syncMessage"
              class="max-w-full text-xs break-words whitespace-pre-wrap"
              >{{ row.original.syncMessage }}</span
            >
          </div>
        </template>
      </UTable>
    </template>
  </UCard>

  <UModal
    v-model:open="detailOpen"
    title="Chi tiết điều chỉnh LSX"
    class="max-w-[95vw] sm:max-w-4xl"
  >
    <template #body>
      <UTable :data="detailRows" :columns="detailColumns" class="text-sm">
        <template #team-cell="{ row }">{{ row.original.teamName ?? row.original.teamId }}</template>
        <template #po-cell="{ row }">{{
          row.original.purchaseOrderCode ?? row.original.purchaseOrderId
        }}</template>
        <template #change-cell="{ row }">{{ formatQuantityChange(row.original) }}</template>
      </UTable>
    </template>
  </UModal>
</template>
