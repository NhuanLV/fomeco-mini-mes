<script setup lang="ts">
import AllocationSummaryDataTable from '@/features/production/components/AllocationSummaryDataTable.vue'
import ProductionOrderExcelUpload from '@/features/production/components/ProductionOrderExcelUpload.vue'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { fmtQty } from '@/shared/utils/fmtQty'
import { storeToRefs } from 'pinia'
import { computed } from 'vue'

withDefaults(
  defineProps<{
    onImportExcel?: ((file: File) => void) | undefined
  }>(),
  {
    onImportExcel: undefined,
  },
)

const { selectedFactoryIds, factories, totalSummaryQty } = storeToRefs(
  useProductionOrderIssuanceStore(),
)

const selectedFactories = computed(() => {
  return factories.value.filter((f) => selectedFactoryIds.value.includes(f.id))
})
</script>

<template>
  <UCard class="border border-primary/20">
    <template #title>
      <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div class="flex flex-col gap-2 sm:flex-row sm:items-center">
          <div class="flex items-center gap-2">
            <UIcon name="i-lucide-list-checks" class="text-xl text-primary sm:text-2xl" />
            <span class="text-sm font-semibold sm:text-lg">Tổng hợp SL Phân bổ (Lệnh SX)</span>
          </div>
          <div class="flex flex-wrap gap-1">
            <span
              v-for="factory in selectedFactories"
              :key="factory.id"
              class="rounded border border-primary/20 bg-primary/5 px-2 py-0.5 text-[9px] font-medium text-primary uppercase sm:text-[10px]"
            >
              {{ factory.name }}
              <template v-if="factory.companyName"> - {{ factory.companyName }}</template>
            </span>
          </div>
        </div>
        <div
          class="text-primary-contrast self-start rounded-full bg-primary px-3 py-1.5 text-xs font-semibold sm:self-center sm:px-4 sm:text-sm"
        >
          Tổng: {{ fmtQty(totalSummaryQty) }}
        </div>
      </div>
    </template>

    <template #default>
      <ProductionOrderExcelUpload
        v-if="onImportExcel"
        variant="dropzone"
        @select-file="onImportExcel"
      >
        <div class="overflow-hidden rounded-lg bg-white/85">
          <AllocationSummaryDataTable />
        </div>
      </ProductionOrderExcelUpload>

      <div v-else class="overflow-hidden">
        <AllocationSummaryDataTable />
      </div>
    </template>
  </UCard>
</template>
