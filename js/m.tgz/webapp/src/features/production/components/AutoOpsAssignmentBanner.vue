<script setup lang="ts">
defineProps<{
  ops: {
    operationName: string
    autoTeamName: string
  }[]
}>()
</script>

<template>
  <div v-if="ops.length > 0" class="rounded-lg border border-green-200 bg-green-50 p-4">
    <div class="mb-2 flex items-center gap-2 text-sm font-semibold text-green-800">
      <UIcon name="i-lucide-circle-check" class="size-5 text-green-600" />
      <span>Công đoạn tự động phân công</span>
    </div>
    <div class="flex flex-wrap gap-3">
      <div
        v-for="op in ops"
        :key="op.operationName"
        class="flex items-center gap-2 text-sm text-green-700"
      >
        <UBadge :label="op.operationName" color="success" />
        <span class="text-green-500">→</span>
        <span class="font-medium">{{ op.autoTeamName }}</span>
        <span class="text-xs text-green-500">(toàn bộ số lượng)</span>
      </div>
    </div>
  </div>
</template>
