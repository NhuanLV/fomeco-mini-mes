<script setup lang="ts">
import AllocationColorCell from '@/features/production/components/AllocationColorCell.vue'
import DateEditor from '@/features/production/components/DateEditor.vue'
import { useAllocationActions } from '@/features/production/composables/useAllocationActions'
import { useAllocationColumns } from '@/features/production/composables/useAllocationColumns'
import { useAllocationSource } from '@/features/production/composables/useAllocationSource'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import { matrixGridCell, matrixGridEditor } from '@/shared/components/grid/matrixGrid'
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import NoteEditor from '@/shared/components/grid/NoteEditor.vue'
import TeamSelectEditor from '@/features/production/components/TeamSelectEditor.vue'
import { fmtQty } from '@/shared/utils/fmtQty'
import { storeToRefs } from 'pinia'
import { shallowRef } from 'vue'

interface Props {
  opName: string
  readonly?: boolean
}
const props = defineProps<Props>()
const issuanceStore = useProductionOrderIssuanceStore()
const { noteColumnCount } = storeToRefs(issuanceStore)
const { addNoteColumn, removeNoteColumn } = issuanceStore

const filterText = shallowRef('')

const COLUMN_TYPES = {
  select: { editor: matrixGridEditor(TeamSelectEditor) },
  color: { cellTemplate: matrixGridCell(AllocationColorCell) },
  size: { cellTemplate: matrixGridCell(MatrixQtyCell) },
  sizeReadonly: { cellTemplate: matrixGridCell(MatrixQtyCell) },
  date: { editor: matrixGridEditor(DateEditor) },
  note: { editor: matrixGridEditor(NoteEditor) },
}

const { filteredSource, totalTableQuantity, teamOptions } = useAllocationSource(
  props.opName,
  filterText,
)
const { columns, displayRows } = useAllocationColumns(
  props.opName,
  props.readonly ?? false,
  teamOptions,
)

const { handleAfterEdit, handleSplit, handleDelete } = useAllocationActions(
  props.opName,
  filteredSource,
)
</script>

<template>
  <div class="flex flex-col gap-3">
    <!-- Thanh công cụ: Bộ lọc -->
    <div
      v-if="!props.readonly"
      class="flex flex-col gap-2 rounded-t-lg border border-b-0 border-surface-200 bg-surface-50 p-3 sm:flex-row sm:items-center sm:justify-between sm:p-2"
    >
      <div class="flex items-center gap-4">
        <UIcon name="i-lucide-search" class="ml-2 text-toned" />
        <input
          v-model="filterText"
          type="text"
          placeholder="Lọc theo PO, Thị trường, Ngày giao..."
          class="w-full border-none bg-transparent p-1 text-sm outline-none sm:w-64"
        />
      </div>

      <div class="flex items-center justify-between sm:mr-2 sm:justify-end sm:gap-4">
        <div class="flex items-center gap-2">
          <!-- add ghi chu-->
          <UButton
            @click="addNoteColumn()"
            icon="i-lucide-plus"
            variant="ghost"
            :title="'Thêm cột ghi chú'"
          />

          <!-- delete ghi chu-->
          <UButton
            v-if="noteColumnCount > 0"
            @click="removeNoteColumn()"
            :title="'Xóa cột ghi chú'"
            icon="i-lucide-trash-2"
            variant="ghost"
            color="error"
          />
        </div>
      </div>
    </div>

    <!-- Bảng dữ liệu BaseMatrixGrid -->
    <BaseMatrixGrid
      :source="filteredSource"
      :columns="columns"
      :column-types="COLUMN_TYPES"
      :display-rows="displayRows"
      :additional-data="
        props.readonly
          ? {}
          : {
              onSplit: handleSplit,
              onDelete: handleDelete,
            }
      "
      @afteredit="handleAfterEdit"
    />

    <!-- Hàng Tổng cộng Footer -->
    <div
      class="-mt-3 flex items-center justify-start gap-4 rounded-b-lg border border-surface-200 bg-surface-50 p-3"
    >
      <span class="text-[10px] font-bold tracking-wider text-toned uppercase"
        >Tổng sản lượng công đoạn:</span
      >
      <span class="font-mono text-xl font-bold text-primary">{{ fmtQty(totalTableQuantity) }}</span>
    </div>
  </div>
</template>
