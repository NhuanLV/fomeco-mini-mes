<script setup lang="ts">
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import AppDatePicker from '@/shared/components/AppDatePicker.vue'
import { fmtQty } from '@/shared/utils/fmtQty'
import { showWarn } from '@/shared/utils/toast'
import { storeToRefs } from 'pinia'
import { ref } from 'vue'

const store = useProductionOrderIssuanceStore()
const { scheduledAssignments, hasAttemptedSubmit } = storeToRefs(store)
const { setPlannedDates, applyDatesToAll } = store

const now = new Date()
const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())

const quickStartDate = ref<Date | null>(null)
const quickEndDate = ref<Date | null>(null)

function toDate(val: string | null | undefined): Date | null {
  if (!val || typeof val !== 'string' || val.trim() === '') return null
  const [y, m, d] = val.split('-').map(Number)
  if (!y || !m || !d) return null
  return new Date(y, m - 1, d)
}

function toDateString(val: Date | null | undefined): string | null {
  if (!val || !(val instanceof Date) || isNaN(val.getTime())) return null
  const y = val.getFullYear()
  const m = String(val.getMonth() + 1).padStart(2, '0')
  const d = String(val.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

function handleQuickApply() {
  const startStr = toDateString(quickStartDate.value)
  const endStr = toDateString(quickEndDate.value)

  if (!startStr && !endStr) {
    showWarn('Vui lòng chọn ngày trước khi áp dụng')
    return
  }
  if (startStr && endStr && endStr < startStr) {
    showWarn('Ngày hoàn thành phải sau hoặc bằng ngày bắt đầu')
    return
  }
  applyDatesToAll(startStr, endStr)
}

function onStartDateChange(
  item: { teamId: string; operation: string; plannedEndDate: string | null },
  val: Date | null,
) {
  const newStart = toDateString(val)
  let end = item.plannedEndDate
  if (newStart && end && end < newStart) {
    end = null
  }
  setPlannedDates(item.teamId, item.operation, newStart, end)
}

function onEndDateChange(
  item: { teamId: string; operation: string; plannedStartDate: string | null },
  val: Date | null,
) {
  const newEnd = toDateString(val)
  setPlannedDates(item.teamId, item.operation, item.plannedStartDate, newEnd)
}
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div class="flex items-center gap-2">
          <UIcon name="i-lucide-calendar-days" class="size-5 text-primary" />
          <span class="font-semibold text-default">Kế hoạch thời gian cho từng LCĐ</span>
        </div>

        <!-- Quick apply all -->
        <div
          v-if="scheduledAssignments.length > 1"
          class="flex flex-wrap items-center gap-2 rounded-lg border border-surface-200 bg-surface-50 p-2 text-xs"
        >
          <span class="font-medium text-toned">Áp dụng chung:</span>
          <AppDatePicker
            v-model="quickStartDate"
            :min-date="today"
            placeholder="Ngày bắt đầu..."
            class="w-40"
          />
          <span class="text-toned">→</span>
          <AppDatePicker
            v-model="quickEndDate"
            :min-date="quickStartDate || today"
            placeholder="Ngày hoàn thành..."
            class="w-40"
          />
          <UButton
            label="Áp dụng tất cả"
            size="xs"
            color="primary"
            variant="soft"
            icon="i-lucide-check-check"
            @click="handleQuickApply"
          />
        </div>
      </div>
    </template>

    <template #default>
      <div class="overflow-x-auto">
        <table class="w-full text-left text-sm">
          <thead>
            <tr
              class="border-b border-surface-200 text-xs font-semibold text-neutral-600 uppercase"
            >
              <th class="py-2.5 pr-3 pl-1 text-center">STT</th>
              <th class="px-3 py-2.5">Công đoạn</th>
              <th class="px-3 py-2.5">Tổ thực hiện</th>
              <th class="px-3 py-2.5 text-center">Sản lượng giao</th>
              <th class="px-3 py-2.5">
                <span>Ngày dự kiến bắt đầu</span>
                <span class="text-red-500">*</span>
              </th>
              <th class="px-3 py-2.5">
                <span>Ngày dự kiến hoàn thành</span>
                <span class="text-red-500">*</span>
              </th>
            </tr>
          </thead>
          <tbody class="divide-y divide-surface-100">
            <tr
              v-for="(item, index) in scheduledAssignments"
              :key="`${item.teamId}|${item.operation}`"
              class="hover:bg-surface-50"
            >
              <td class="py-3 pr-3 pl-1 text-center font-medium text-toned">
                {{ index + 1 }}
              </td>
              <td class="px-3 py-3 font-medium">
                <UBadge :label="item.operation" color="info" />
              </td>
              <td class="px-3 py-3 font-semibold text-neutral-800">
                {{ item.teamName }}
              </td>
              <td class="px-3 py-3 text-center font-semibold">
                {{ fmtQty(item.assignedQuantity) }}
              </td>
              <td class="px-3 py-3">
                <div class="flex flex-col gap-1">
                  <AppDatePicker
                    :model-value="toDate(item.plannedStartDate)"
                    :min-date="today"
                    placeholder="Chọn ngày bắt đầu..."
                    :input-class="
                      hasAttemptedSubmit && !item.plannedStartDate
                        ? 'border-red-500! ring-1! ring-red-500!'
                        : ''
                    "
                    class="w-full min-w-42.5"
                    @update:model-value="(val) => onStartDateChange(item, val as Date | null)"
                  />
                  <span
                    v-if="hasAttemptedSubmit && !item.plannedStartDate"
                    class="text-[11px] font-medium text-red-500"
                  >
                    Bắt buộc nhập ngày bắt đầu
                  </span>
                </div>
              </td>
              <td class="px-3 py-3">
                <div class="flex flex-col gap-1">
                  <AppDatePicker
                    :model-value="toDate(item.plannedEndDate)"
                    :min-date="toDate(item.plannedStartDate) || today"
                    placeholder="Chọn ngày hoàn thành..."
                    :input-class="
                      hasAttemptedSubmit &&
                      (!item.plannedEndDate ||
                        (item.plannedStartDate && item.plannedEndDate < item.plannedStartDate))
                        ? 'border-red-500! ring-1! ring-red-500!'
                        : ''
                    "
                    class="w-full min-w-42.5"
                    @update:model-value="(val) => onEndDateChange(item, val as Date | null)"
                  />
                  <span
                    v-if="hasAttemptedSubmit && !item.plannedEndDate"
                    class="text-[11px] font-medium text-red-500"
                  >
                    Bắt buộc nhập ngày hoàn thành
                  </span>
                  <span
                    v-else-if="
                      hasAttemptedSubmit &&
                      item.plannedStartDate &&
                      item.plannedEndDate &&
                      item.plannedEndDate < item.plannedStartDate
                    "
                    class="text-[11px] font-medium text-red-500"
                  >
                    Ngày hoàn thành không được trước ngày bắt đầu
                  </span>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>
  </UCard>
</template>
