<template>
  <UAlert
    role="alert"
    color="error"
    icon="i-lucide-lock-keyhole"
    title="Lệnh sản xuất đã hủy"
    description="Lệnh sản xuất này chỉ được xem, không thể cập nhật hoặc phát sinh giao dịch mới."
  />
</template>
