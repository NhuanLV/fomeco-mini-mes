import { flushPromises, mount } from '@vue/test-utils'
import { beforeEach, expect, it, vi } from 'vitest'
import type { ProductionOrderHistory, ProductionOrderVm } from '@/api'
import ProductionOrderCancellation from '../ProductionOrderCancellation.vue'

const mocks = vi.hoisted(() => ({
  cancel: vi.fn(),
  error: vi.fn(),
  success: vi.fn(),
  loading: vi.fn(),
  clearLoading: vi.fn(),
  denied: '' as string,
}))
vi.mock('@/api', () => ({
  cancelProductionOrder: mocks.cancel,
}))
vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({ hasPermission: (_: string, unit: string) => unit !== mocks.denied }),
}))
vi.mock('@/shared/utils/toast', () => ({
  showError: mocks.error,
  showSuccess: mocks.success,
  showLoading: mocks.loading,
  clearLoading: mocks.clearLoading,
}))

const order = {
  id: 'lsx',
  code: 'LSX-1',
  status: 'IN_PROGRESS',
  factories: [{ id: 'f1' }, { id: 'f2' }],
} as ProductionOrderVm
const row = (id: string, status: ProductionOrderHistory['syncStatus']): ProductionOrderHistory => ({
  id,
  productionOrderId: 'lsx',
  action: 'CANCEL',
  changes: [],
  occurredAt: '',
  note: 'Dừng',
  actor: null,
  syncStatus: status,
})
function render(history: ProductionOrderHistory[] = [], status = order.status) {
  return mount(ProductionOrderCancellation, {
    props: { order: { ...order, status }, history },
    global: {
      stubs: {
        Modal: { template: '<div><slot name="body"/><slot name="footer"/></div>' },
        FormField: { template: '<div><slot/></div>' },
        Button: {
          props: ['label', 'disabled'],
          template: '<button :disabled="disabled">{{ label }}</button>',
        },
        Textarea: {
          props: ['modelValue'],
          emits: ['update:modelValue'],
          template:
            '<textarea :value="modelValue" @input="$emit(\'update:modelValue\', $event.target.value)" />',
        },
      },
    },
  })
}
beforeEach(() => {
  vi.clearAllMocks()
  mocks.denied = ''
})

it('requires permission for every factory and hides actions on cancelled orders', () => {
  mocks.denied = 'f2'
  const denied = render([row('latest', 'FAILED')])
  expect(denied.text()).not.toContain('Hủy LSX')
  denied.unmount()
  mocks.denied = ''
  const cancelled = render([row('latest', 'SUCCESS')], 'CANCELLED')
  expect(cancelled.text()).not.toContain('Hủy LSX')
  cancelled.unmount()
})

it('requires trimmed reason and reports pending instead of successful cancellation', async () => {
  mocks.cancel.mockResolvedValue({ data: row('latest', 'PENDING') })
  const wrapper = render()
  const confirm = () =>
    wrapper.findAll('button').find((button) => button.text() === 'Xác nhận hủy')!
  await confirm().trigger('click')
  expect(mocks.cancel).not.toHaveBeenCalled()
  expect(mocks.error).toHaveBeenCalledWith('Vui lòng nhập lý do hủy Lệnh sản xuất.')
  await wrapper.find('textarea').setValue('  Dừng  ')
  await confirm().trigger('click')
  await flushPromises()
  expect(mocks.cancel).toHaveBeenCalledWith(expect.objectContaining({ body: { reason: 'Dừng' } }))
  expect(mocks.loading).toHaveBeenCalledWith(
    'Đang đồng bộ FPO/FPPO trên WFX...',
    'Đang hủy LSX',
    'po-cancel-lsx',
  )
  expect(mocks.success).not.toHaveBeenCalled()
  expect(wrapper.emitted('refresh')).toHaveLength(1)
  wrapper.unmount()
})

it('does not announce WFX synchronization before validation or when Kanban blocks cancellation', async () => {
  let rejectRequest!: (error: Error) => void
  mocks.cancel.mockImplementation(
    () =>
      new Promise((_, reject) => {
        rejectRequest = reject
      }),
  )
  const wrapper = render()
  await wrapper.find('textarea').setValue('Dừng')
  await wrapper
    .findAll('button')
    .find((button) => button.text() === 'Xác nhận hủy')!
    .trigger('click')
  expect(mocks.loading).not.toHaveBeenCalled()
  rejectRequest(new Error('Cần hủy hết Kanban trước khi hủy LSX'))
  await flushPromises()
  expect(mocks.error).toHaveBeenCalledExactlyOnceWith('Cần hủy hết Kanban trước khi hủy LSX')
  expect(mocks.loading).not.toHaveBeenCalled()
  expect(mocks.success).not.toHaveBeenCalled()
  wrapper.unmount()
})

it('replaces the pending toast with success', async () => {
  const wrapper = render([row('latest', 'PENDING')])
  expect(mocks.loading).toHaveBeenCalled()
  await wrapper.setProps({
    history: [row('latest', 'SUCCESS')],
    order: { ...order, status: 'CANCELLED' },
  })
  expect(mocks.clearLoading).toHaveBeenCalledWith('po-cancel-lsx')
  expect(mocks.success).toHaveBeenCalledWith('Đã hủy Lệnh sản xuất')
  wrapper.unmount()
})

it('clears the pending toast on failure and shows the error without a false success', async () => {
  const wrapper = render([row('latest', 'PENDING')])
  await wrapper.setProps({ history: [{ ...row('latest', 'FAILED'), syncMessage: 'WFX từ chối' }] })
  expect(mocks.clearLoading).toHaveBeenCalledWith('po-cancel-lsx')
  expect(mocks.error).toHaveBeenCalledWith('WFX từ chối')
  expect(mocks.success).not.toHaveBeenCalled()
  wrapper.unmount()
})

it.each([
  ['SUCCESS', false],
  ['FAILED', false],
  ['SUCCESS', true],
  ['FAILED', true],
] as const)(
  'handles a fast %s result without observing pending history (previous failure: %s)',
  async (status, previousFailure) => {
    mocks.cancel.mockResolvedValue({ data: row('new', 'PENDING') })
    const oldHistory = previousFailure ? [row('old', 'FAILED')] : []
    const wrapper = render(oldHistory)
    await wrapper.find('textarea').setValue('Dừng sản xuất')
    await wrapper
      .findAll('button')
      .find((button) => button.text() === 'Xác nhận hủy')!
      .trigger('click')
    await flushPromises()
    expect(mocks.loading).toHaveBeenCalled()
    mocks.clearLoading.mockClear()

    await wrapper.setProps({
      history: [{ ...row('new', status), syncMessage: 'WFX từ chối' }, ...oldHistory],
    })

    expect(mocks.clearLoading).toHaveBeenCalledWith('po-cancel-lsx')
    if (status === 'SUCCESS') {
      expect(mocks.success).toHaveBeenCalledExactlyOnceWith('Đã hủy Lệnh sản xuất')
      expect(mocks.error).not.toHaveBeenCalled()
    } else {
      expect(mocks.error).toHaveBeenCalledExactlyOnceWith('WFX từ chối')
      expect(mocks.success).not.toHaveBeenCalled()
    }
    wrapper.unmount()
  },
)

it('allows cancelling again after failure and blocks duplicates while submitting or pending', async () => {
  let finish!: (value: unknown) => void
  mocks.cancel.mockImplementation(
    () =>
      new Promise((resolve) => {
        finish = resolve
      }),
  )
  const wrapper = render([row('old', 'FAILED')])
  expect(wrapper.text()).not.toContain('Thử lại')
  await wrapper.find('textarea').setValue('Lý do mới')
  const confirm = () =>
    wrapper.findAll('button').find((button) => button.text() === 'Xác nhận hủy')!
  await confirm().trigger('click')
  await confirm().trigger('click')
  expect(mocks.cancel).toHaveBeenCalledTimes(1)
  expect(mocks.cancel).toHaveBeenCalledWith(
    expect.objectContaining({
      path: { id: 'lsx' },
      body: { reason: 'Lý do mới' },
    }),
  )
  finish({ data: row('new', 'PENDING') })
  await flushPromises()
  await wrapper.setProps({ history: [row('new', 'PENDING'), row('old', 'FAILED')] })
  expect(
    wrapper
      .findAll('button')
      .find((button) => button.text() === 'Hủy LSX')!
      .attributes('disabled'),
  ).toBeDefined()
  await wrapper.find('textarea').setValue('Bấm thêm')
  await confirm().trigger('click')
  expect(mocks.cancel).toHaveBeenCalledTimes(1)
  wrapper.unmount()
})
