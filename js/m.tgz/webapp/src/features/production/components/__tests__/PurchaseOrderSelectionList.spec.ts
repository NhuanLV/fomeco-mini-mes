import { shallowMount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import PurchaseOrderSelectionList from '../PurchaseOrderSelectionList.vue'

describe('PurchaseOrderSelectionList.vue', () => {
  const samplePOs = [
    {
      id: 'po-1',
      wfxId: 'WFX-1',
      code: 'PO01',
      destination: 'US',
      deliveryDate: '2026-09-01',
      totalQuantity: 50,
      type: 'REGULAR' as const,
      skuQuantities: [{ color: 'Red', size: 'S', quantity: 50, remainingQuantity: 50 }],
    },
    {
      id: 'po-2',
      wfxId: '',
      code: 'POS01',
      destination: 'US',
      deliveryDate: '2026-09-01',
      totalQuantity: 20,
      type: 'POSITIVE' as const,
      skuQuantities: [{ color: 'Red', size: 'S', quantity: 20, remainingQuantity: 20 }],
    },
  ]

  it('does not render UTabs when showTypeTabs is false', () => {
    const wrapper = shallowMount(PurchaseOrderSelectionList, {
      props: {
        pos: samplePOs,
        allSizes: ['S'],
        selectedPOIds: [],
        showTypeTabs: false,
      },
    })
    expect(wrapper.findComponent({ name: 'UTabs' }).exists()).toBe(false)
  })

  it('renders UTabs with PO thường and PO hàng dương tabs when showTypeTabs is true', () => {
    const wrapper = shallowMount(PurchaseOrderSelectionList, {
      props: {
        pos: samplePOs,
        allSizes: ['S'],
        selectedPOIds: [],
        showTypeTabs: true,
      },
    })
    const tabs = wrapper.findComponent({ name: 'Tabs' })
    expect(tabs.exists()).toBe(true)

    const items = tabs.props('items') as Array<{ label: string; value: string }>
    expect(items).toHaveLength(2)
    expect(items[0].value).toBe('REGULAR')
    expect(items[0].label).toContain('PO thường')
    expect(items[0].label).toContain('1')
    expect(items[1].value).toBe('POSITIVE')
    expect(items[1].label).toContain('PO hàng dương')
    expect(items[1].label).toContain('1')
  })

  it('resolves initial active tab to POSITIVE when a positive PO is preselected', () => {
    const wrapper = shallowMount(PurchaseOrderSelectionList, {
      props: {
        pos: samplePOs,
        allSizes: ['S'],
        selectedPOIds: ['po-2'],
        showTypeTabs: true,
      },
    })
    const tabs = wrapper.findComponent({ name: 'Tabs' })
    expect(tabs.props('modelValue')).toBe('POSITIVE')
  })

  it('switches active tab when modelValue is updated', async () => {
    const wrapper = shallowMount(PurchaseOrderSelectionList, {
      props: {
        pos: samplePOs,
        allSizes: ['S'],
        selectedPOIds: ['po-1'],
        showTypeTabs: true,
      },
    })
    const tabs = wrapper.findComponent({ name: 'Tabs' })
    expect(tabs.props('modelValue')).toBe('REGULAR')

    // Switch to POSITIVE tab
    await tabs.vm.$emit('update:modelValue', 'POSITIVE')
    expect(tabs.props('modelValue')).toBe('POSITIVE')
  })
})
