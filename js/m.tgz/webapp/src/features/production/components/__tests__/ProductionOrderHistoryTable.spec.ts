import type { ProductionOrderHistory, ProductionOrderAllocationChange } from '@/api'
import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import ProductionOrderHistoryTable from '../ProductionOrderHistoryTable.vue'

const change = (index: number): ProductionOrderAllocationChange => ({
  assignmentId: `assignment-${index}`,
  operation: 'CUT-1',
  teamId: `team-${index}`,
  teamName: `Tổ ${index}`,
  purchaseOrderId: `po-${index}`,
  purchaseOrderCode: `PO-${index}`,
  color: 'Đỏ',
  size: 'M',
  before: { purchaseOrderId: `po-${index}`, color: 'Đỏ', size: 'M', quantity: 10, notes: [] },
  after: { purchaseOrderId: `po-${index}`, color: 'Đỏ', size: 'M', quantity: 20, notes: [] },
})
const history = (
  count = 0,
  action: ProductionOrderHistory['action'] = 'REVISE',
): ProductionOrderHistory => ({
  id: 'history',
  productionOrderId: 'order',
  action,
  actor: { id: 'planner', name: 'Người phát' },
  occurredAt: '2026-10-12T08:00:00Z',
  note: 'Đổi kế hoạch',
  changes: Array.from({ length: count }, (_, index) => change(index)),
  syncStatus: 'SUCCESS',
})

describe('ProductionOrderHistoryTable', () => {
  it('keeps failed requests and their errors without retry actions', async () => {
    const wrapper = mount(ProductionOrderHistoryTable, {
      props: {
        isExpanded: true,
        loading: false,
        history: [
          {
            ...history(0, 'CANCEL'),
            id: 'new',
            syncStatus: 'FAILED',
            syncMessage: 'FPPO 1 (Completed)',
          },
          {
            ...history(0, 'CANCEL'),
            id: 'old',
            syncStatus: 'FAILED',
            syncMessage: 'Old WFX error',
          },
        ],
      },
    })
    const buttons = wrapper.findAll('button').filter((button) => button.text() === 'Thử lại')
    expect(buttons).toHaveLength(0)
    expect(wrapper.text()).toContain('FPPO 1 (Completed)')
    expect(wrapper.text()).toContain('Old WFX error')
    wrapper.unmount()
  })
  it('starts collapsed and expands from the header to show six columns without roles', async () => {
    const wrapper = mount(ProductionOrderHistoryTable, {
      props: { history: [history(1)], loading: false },
    })
    expect(wrapper.text()).toContain('Lịch sử hoạt động')
    expect(wrapper.text()).not.toContain('Người phát')
    await wrapper.find('[data-testid="history-header"]').trigger('click')
    expect(wrapper.findAll('th')).toHaveLength(6)
    expect(wrapper.text()).toContain('Người phát')
    expect(wrapper.text()).not.toContain('Vai trò')
    expect(wrapper.text()).not.toContain('Kế hoạch, Quản lý')
    expect(wrapper.text()).toContain('Đổi kế hoạch')
    expect(wrapper.text()).toContain('Thành công')
    wrapper.unmount()
  })

  it('uses semantic action badges and keeps the FPO badge inside its cell', () => {
    const wrapper = mount(ProductionOrderHistoryTable, {
      props: {
        isExpanded: true,
        history: [history(0, 'CREATE'), history(1, 'REVISE')],
        loading: false,
      },
    })
    const badges = wrapper.findAllComponents({ name: 'Badge' })
    expect(badges.find((badge) => badge.props('label') === 'Tạo LSX')?.props('color')).toBe(
      'success',
    )
    expect(badges.find((badge) => badge.props('label') === 'Điều chỉnh LSX')?.props('color')).toBe(
      'warning',
    )
    expect(wrapper.find('[data-testid="sync-badge"]').classes()).toContain('whitespace-normal')
    wrapper.unmount()
  })

  it.each([0, 1, 2, 4])('shows at most two allocation summaries for %s changes', (count) => {
    const wrapper = mount(ProductionOrderHistoryTable, {
      props: { isExpanded: true, history: [history(count)], loading: false },
    })
    expect(wrapper.findAll('[data-testid="allocation-summary"]')).toHaveLength(Math.min(count, 2))
    expect(wrapper.find('[data-testid="remaining-count"]').exists()).toBe(count === 4)
    if (count === 4) expect(wrapper.find('[data-testid="remaining-count"]').text()).toBe('+2')
    expect(wrapper.text().includes('Xem chi tiết')).toBe(count > 0)
    if (count > 0) {
      expect(wrapper.text()).toContain('M/Đỏ: 10 → 20')
      expect(wrapper.text()).not.toContain('assignment-0')
    }
    wrapper.unmount()
  })

  it('opens every stored change in a detail table with before after and delta', async () => {
    const wrapper = mount(ProductionOrderHistoryTable, {
      props: { isExpanded: true, history: [history(4)], loading: false },
    })
    await wrapper
      .findAll('button')
      .find((button) => button.text() === 'Xem chi tiết')!
      .trigger('click')
    expect(document.body.textContent).toContain('Chi tiết điều chỉnh LSX')
    expect(document.body.textContent).toContain('PO-3')
    expect(document.body.textContent).toContain('Công đoạn')
    expect(document.body.textContent).toContain('CUT-1')
    expect(document.body.textContent).toContain('Tổ')
    expect(document.body.textContent).toContain('Tổ 3')
    expect(document.body.textContent).toContain('Thay đổi')
    expect(document.body.textContent).toContain('10 → 20')
    expect(document.body.textContent).not.toContain('M/Đỏ +20')
    expect(document.body.textContent).not.toContain('Chênh lệch')
    wrapper.unmount()
  })

  it('keeps CREATE and CANCEL content empty and uses unknown labels without guessing', () => {
    const rows = [
      history(2, 'CREATE'),
      { ...history(2, 'CANCEL'), actor: null, syncStatus: undefined },
    ]
    const wrapper = mount(ProductionOrderHistoryTable, {
      props: { isExpanded: true, history: rows, loading: false },
    })
    expect(wrapper.findAll('[data-testid="allocation-summary"]')).toHaveLength(0)
    expect(wrapper.text()).not.toContain('Xem chi tiết')
    expect(wrapper.text()).toContain('Không xác định')
    expect(wrapper.text()).toContain('Không có dữ liệu lịch sử')
    wrapper.unmount()
  })

  it('shows positive orders as not applicable and retains sync failures without retry controls', () => {
    const wrapper = mount(ProductionOrderHistoryTable, {
      props: {
        isExpanded: true,
        loading: false,
        history: [
          { ...history(0, 'CREATE'), syncStatus: 'NOT_APPLICABLE' },
          { ...history(0, 'CANCEL'), syncStatus: 'FAILED', syncMessage: 'WFX từ chối' },
        ],
      },
    })
    expect(wrapper.text()).toContain('Không áp dụng')
    expect(wrapper.text()).toContain('WFX từ chối')
    expect(wrapper.text()).not.toContain('Thử lại')
    wrapper.unmount()
  })
})
