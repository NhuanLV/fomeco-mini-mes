<script setup lang="ts">
import type { PurchaseOrderVm } from '@/api'
import ColorSizeMatrix from '@/shared/components/ColorSizeMatrix.vue'
import { transformToMatrix } from '@/shared/composables/useColorSizeMatrix'
import type { MatrixRow } from '@/shared/types'
import { makeOrderComparator } from '@/shared/utils/orderedValues'
import { formatDate } from '@/shared/utils/date'
import { fmtQty } from '@/shared/utils/fmtQty'
import AppDatePicker from '@/shared/components/AppDatePicker.vue'
import ExpandCollapseButtons from '@/shared/components/ExpandCollapseButtons.vue'
import { computed, ref, watch } from 'vue'

interface Props {
  pos: PurchaseOrderVm[]
  allSizes: string[]
  styleColorOrder?: string[]
  selectedPOIds: string[]
  /**
   * Field dùng để hiển thị số lượng trong grid:
   * - `'quantity'`: tổng số lượng của BO (dùng trong BuyerOrderDetailView)
   * - `'remainingQuantity'`: số lượng còn lại chưa phát LSX (dùng trong ProductionOrderCreateView)
   * @default 'quantity'
   */
  quantityField?: 'quantity' | 'remainingQuantity'
  readonly?: boolean
  focusPOId?: string | null
  disabledPOIds?: string[]
  disabledReason?: string | ((po: PurchaseOrderVm) => string | undefined)
  showTypeTabs?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  quantityField: 'quantity',
  readonly: false,
  styleColorOrder: () => [],
  focusPOId: null,
  disabledPOIds: () => [],
  disabledReason: undefined,
  showTypeTabs: false,
})

type PurchaseOrderWithType = PurchaseOrderVm & { type?: 'REGULAR' | 'POSITIVE' }

function isPositive(po: PurchaseOrderVm) {
  return (po as PurchaseOrderWithType).type === 'POSITIVE'
}

function getDisabledReason(po: PurchaseOrderVm): string {
  if (typeof props.disabledReason === 'function') {
    return props.disabledReason(po) ?? 'Không cùng loại PO đã chọn'
  }
  return props.disabledReason ?? 'Không cùng loại PO đã chọn'
}

const emit = defineEmits<{
  togglePO: [id: string]
  toggleAll: [checked: boolean, filteredPOIds: string[]]
}>()

// ─── Filters ──────────────────────────────────────────────────────────────────
const marketFilter = ref<string[]>([])
const dateFilter = ref<Date[]>([])
const poCodeFilter = ref<string[]>([])
const colorFilter = ref<string[]>([])

const uniqueMarkets = computed(() =>
  [...new Set(props.pos.map((po) => po.destination).filter(Boolean))].sort(),
)
const uniquePOCodes = computed(() =>
  [...new Set(props.pos.map((po) => po.code).filter(Boolean))].sort(),
)
const uniqueColors = computed(() =>
  [
    ...new Set(props.pos.flatMap((po) => po.skuQuantities.map((sku) => sku.color).filter(Boolean))),
  ].sort(),
)

// Cache remaining totals — shared by filteredPOs, allFullyReleased, and displayTotal
const remainingTotalsCache = computed(() => {
  const map = new Map<string, number>()
  if (props.quantityField === 'remainingQuantity') {
    props.pos.forEach((po) =>
      map.set(
        po.id,
        po.skuQuantities.reduce((sum, sku) => sum + sku.remainingQuantity, 0),
      ),
    )
  }
  return map
})

const activeTypeTab = ref<'REGULAR' | 'POSITIVE'>('REGULAR')

function resolveInitialTab(): 'REGULAR' | 'POSITIVE' {
  if (props.selectedPOIds.length > 0) {
    const firstSelected = props.pos.find((p) => props.selectedPOIds.includes(p.id))
    if (firstSelected && isPositive(firstSelected)) {
      return 'POSITIVE'
    }
    return 'REGULAR'
  }
  const regularHasRemaining = props.pos.some(
    (p) =>
      !isPositive(p) &&
      p.skuQuantities.some((sku) =>
        props.quantityField === 'remainingQuantity' ? sku.remainingQuantity > 0 : sku.quantity > 0,
      ),
  )
  if (!regularHasRemaining) {
    const positiveHasRemaining = props.pos.some(
      (p) =>
        isPositive(p) &&
        p.skuQuantities.some((sku) =>
          props.quantityField === 'remainingQuantity'
            ? sku.remainingQuantity > 0
            : sku.quantity > 0,
        ),
    )
    if (positiveHasRemaining) return 'POSITIVE'
  }
  return 'REGULAR'
}

watch(
  () => props.pos,
  () => {
    activeTypeTab.value = resolveInitialTab()
  },
  { immediate: true },
)

const baseFilteredPOs = computed(() =>
  props.pos.filter((po) => {
    const remaining = remainingTotalsCache.value.get(po.id)
    if (remaining !== undefined && remaining === 0) return false
    const matchMarket =
      marketFilter.value.length === 0 || marketFilter.value.includes(po.destination)
    const matchPoCode = poCodeFilter.value.length === 0 || poCodeFilter.value.includes(po.code)
    const matchColor =
      colorFilter.value.length === 0 ||
      po.skuQuantities.some((sku) => colorFilter.value.includes(sku.color))

    let matchDate = true
    if (dateFilter.value && dateFilter.value[0]) {
      const d = po.deliveryDate ? new Date(po.deliveryDate).getTime() : 0
      const startObj = new Date(dateFilter.value[0])
      startObj.setHours(0, 0, 0, 0)
      const start = startObj.getTime()

      const endObj = dateFilter.value[1]
        ? new Date(dateFilter.value[1])
        : new Date(dateFilter.value[0])
      endObj.setHours(23, 59, 59, 999)
      const end = endObj.getTime()

      matchDate = d >= start && d <= end
    }

    return matchMarket && matchPoCode && matchColor && matchDate
  }),
)

const regularFilteredPOs = computed(() => baseFilteredPOs.value.filter((po) => !isPositive(po)))

const positiveFilteredPOs = computed(() => baseFilteredPOs.value.filter((po) => isPositive(po)))

const typeTabItems = computed(() => [
  {
    label: `PO thường (${regularFilteredPOs.value.length})`,
    value: 'REGULAR',
    icon: 'i-lucide-package',
  },
  {
    label: `PO hàng dương (${positiveFilteredPOs.value.length})`,
    value: 'POSITIVE',
    icon: 'i-lucide-sparkles',
  },
])

const filteredPOs = computed(() => {
  if (!props.showTypeTabs) return baseFilteredPOs.value
  return activeTypeTab.value === 'POSITIVE' ? positiveFilteredPOs.value : regularFilteredPOs.value
})

const selectableFilteredPOs = computed(() =>
  filteredPOs.value.filter((po) => !props.disabledPOIds.includes(po.id)),
)

const allFullyReleased = computed(() => {
  if (props.quantityField !== 'remainingQuantity' || props.pos.length === 0) return false
  if (props.showTypeTabs) {
    const currentTabPOs = props.pos.filter((po) =>
      activeTypeTab.value === 'POSITIVE' ? isPositive(po) : !isPositive(po),
    )
    return (
      currentTabPOs.length > 0 &&
      currentTabPOs.every((po) => (remainingTotalsCache.value.get(po.id) ?? 0) === 0)
    )
  }
  return props.pos.every((po) => (remainingTotalsCache.value.get(po.id) ?? 0) === 0)
})

const currentTabHasNoPOs = computed(() => {
  if (!props.showTypeTabs) return false
  const currentTabPOs = props.pos.filter((po) =>
    activeTypeTab.value === 'POSITIVE' ? isPositive(po) : !isPositive(po),
  )
  return currentTabPOs.length === 0
})

function clearFilters() {
  marketFilter.value = []
  dateFilter.value = []
  poCodeFilter.value = []
  colorFilter.value = []
}

const expandedPOs = ref<string[]>([])

watch(
  () => props.focusPOId,
  (poId) => {
    if (poId) {
      clearFilters()
      if (!expandedPOs.value.includes(poId)) expandedPOs.value.push(poId)
      const target = props.pos.find((p) => p.id === poId)
      if (target && isPositive(target)) {
        activeTypeTab.value = 'POSITIVE'
      } else if (target) {
        activeTypeTab.value = 'REGULAR'
      }
    }
  },
  { immediate: true },
)

function toggleExpand(id: string) {
  const index = expandedPOs.value.indexOf(id)
  if (index >= 0) {
    expandedPOs.value.splice(index, 1)
  } else {
    expandedPOs.value.push(id)
  }
}

function expandAll() {
  expandedPOs.value = filteredPOs.value.map((po) => po.id)
}

function collapseAll() {
  expandedPOs.value = []
}

// ─── Selection ────────────────────────────────────────────────────────────────
const selectedCount = computed(
  () => selectableFilteredPOs.value.filter((po) => props.selectedPOIds.includes(po.id)).length,
)

const allFilteredSelected = computed(() => {
  if (selectableFilteredPOs.value.length === 0) return false
  return selectableFilteredPOs.value.every((po) => props.selectedPOIds.includes(po.id))
})

const isIndeterminate = computed(() => {
  if (selectableFilteredPOs.value.length === 0) return false
  const selected = selectedCount.value
  return selected > 0 && selected < selectableFilteredPOs.value.length
})

function handleToggleAll(checked: boolean | 'indeterminate') {
  if (checked === 'indeterminate') return

  const filteredPOIds = selectableFilteredPOs.value.map((po) => po.id)
  emit('toggleAll', checked, filteredPOIds)
}

// ─── Matrix rows ──────────────────────────────────────────────────────────────
// Cache tính sẵn cho toàn bộ pos (không chỉ filteredPOs) để tránh tính lại khi filter thay đổi
const matrixRowsCache = computed(() => {
  const cmpColor = makeOrderComparator(props.styleColorOrder)
  const cache = new Map<string, MatrixRow[]>()
  props.pos.forEach((po) => {
    cache.set(
      po.id,
      transformToMatrix(po.skuQuantities, props.allSizes, {
        getColor: (sku) => sku.color,
        getSize: (sku) => sku.size,
        getQuantity: (sku) => Number(sku[props.quantityField] || 0),
      }).sort((left, right) => cmpColor(left.color, right.color)),
    )
  })
  return cache
})

function filteredMatrixRows(poId: string) {
  const rows = matrixRowsCache.value.get(poId) || []
  if (colorFilter.value.length === 0) return rows
  return rows.filter((row) => colorFilter.value.includes(row.color))
}

function displayTotal(po: PurchaseOrderVm): number {
  let skus = po.skuQuantities
  if (colorFilter.value.length > 0) {
    skus = skus.filter((sku) => colorFilter.value.includes(sku.color))
  }
  if (props.quantityField === 'quantity') {
    return skus.reduce((sum, sku) => sum + (sku.quantity || 0), 0)
  }
  return skus.reduce((sum, sku) => sum + (sku.remainingQuantity || 0), 0)
}
</script>

<template>
  <div class="flex flex-col gap-4">
    <!-- Filters Toolbar (Chung cho các tab) -->
    <div class="flex flex-col gap-4 px-1 sm:flex-row sm:items-center sm:justify-between">
      <div class="flex flex-wrap items-center gap-4">
        <div v-if="!showTypeTabs" class="flex items-center gap-3">
          <UCheckbox
            v-if="!readonly"
            :model-value="isIndeterminate ? 'indeterminate' : allFilteredSelected"
            :disabled="selectableFilteredPOs.length === 0"
            @update:model-value="handleToggleAll"
          />
          <div class="flex items-center gap-2">
            <span class="font-semibold text-default">
              {{ readonly ? 'Danh sách PO' : 'Chọn tất cả' }}
            </span>
            <UBadge
              v-if="filteredPOs.length > 0"
              color="neutral"
              :label="`${selectedCount}/${selectableFilteredPOs.length}`"
            />
          </div>
        </div>

        <div class="flex flex-wrap gap-2">
          <USelectMenu
            multiple
            v-model="marketFilter"
            :items="uniqueMarkets"
            placeholder="Thị trường"
            class="sm:w-48"
            search-input
          />
          <USelectMenu
            multiple
            v-model="poCodeFilter"
            :items="uniquePOCodes"
            placeholder="Mã PO"
            class="sm:w-48"
            search-input
          />
          <USelectMenu
            multiple
            v-model="colorFilter"
            :items="uniqueColors"
            placeholder="Màu"
            class="sm:w-48"
            search-input
          />
          <AppDatePicker
            v-model="dateFilter"
            selection-mode="range"
            placeholder="Khoảng ngày giao"
          />
          <UButton
            v-if="
              marketFilter.length > 0 ||
              poCodeFilter.length > 0 ||
              colorFilter.length > 0 ||
              (dateFilter && dateFilter.length > 0)
            "
            variant="ghost"
            color="neutral"
            @click="clearFilters"
            icon="i-lucide-filter-x"
          />
        </div>
      </div>

      <div class="flex items-center gap-2 self-end sm:self-auto">
        <ExpandCollapseButtons @expand-all="expandAll" @collapse-all="collapseAll" />
      </div>
    </div>

    <!-- 2 Tabs: PO thường & PO hàng dương (khi showTypeTabs = true) -->
    <div v-if="showTypeTabs" class="flex flex-col gap-3">
      <UTabs v-model="activeTypeTab" :items="typeTabItems" :content="false" variant="link" />

      <!-- Subtoolbar cho tab hiện tại -->
      <div class="flex flex-wrap items-center justify-between gap-3 px-1 pt-1">
        <div class="flex items-center gap-3">
          <UCheckbox
            v-if="!readonly"
            :model-value="isIndeterminate ? 'indeterminate' : allFilteredSelected"
            :disabled="selectableFilteredPOs.length === 0"
            @update:model-value="handleToggleAll"
          />
          <div class="flex items-center gap-2">
            <span class="text-sm font-semibold text-default">
              {{ readonly ? 'Danh sách PO' : 'Chọn tất cả' }}
            </span>
            <UBadge
              v-if="filteredPOs.length > 0"
              color="neutral"
              :label="`${selectedCount}/${selectableFilteredPOs.length}`"
            />
          </div>
        </div>
      </div>
    </div>

    <!-- PO List -->
    <div class="flex flex-col gap-3">
      <UCard v-for="po in filteredPOs" :id="`po-${po.id}`" :key="po.id" :ui="{ body: 'hidden!' }">
        <template #header>
          <div
            class="flex cursor-pointer items-center justify-between gap-2 p-4 select-none"
            :class="{
              'cursor-default': readonly,
            }"
            @click="toggleExpand(po.id)"
          >
            <div class="flex items-center gap-4">
              <UButton
                :icon="
                  expandedPOs.includes(po.id) ? 'i-lucide-chevron-down' : 'i-lucide-chevron-right'
                "
                variant="ghost"
                @click.stop="toggleExpand(po.id)"
                class="h-8! w-8! p-0!"
              />
              <UCheckbox
                v-if="!readonly"
                :model-value="selectedPOIds.includes(po.id)"
                :disabled="disabledPOIds.includes(po.id)"
                @click.stop
                @update:model-value="emit('togglePO', po.id)"
              />
              <div
                class="flex items-center gap-2 rounded bg-surface-100 px-3 py-1 font-mono text-sm font-bold text-default"
              >
                <span>{{ po.code }}</span>
                <template v-if="po.wfxId">
                  <span class="font-normal text-toned">|</span>
                  <span class="font-normal text-toned">{{ po.wfxId }}</span>
                </template>
              </div>
              <span v-if="disabledPOIds.includes(po.id)" class="text-xs text-toned">
                {{ getDisabledReason(po) }}
              </span>
              <div class="hidden items-center text-sm text-default lg:flex lg:gap-4">
                <span>
                  <span class="text-toned">Thị trường:</span>
                  <span class="ml-1 font-semibold text-highlighted">{{ po.destination }}</span>
                </span>
                <span class="text-toned">|</span>
                <span>
                  <span class="text-toned">Ngày giao:</span>
                  <span class="ml-1 font-semibold text-highlighted">{{
                    formatDate(po.deliveryDate)
                  }}</span>
                </span>
                <UBadge
                  v-if="isPositive(po)"
                  label="Hàng dương"
                  color="info"
                  variant="soft"
                  size="md"
                  class="ml-3 font-semibold"
                />
              </div>
              <UBadge
                v-if="isPositive(po)"
                label="Hàng dương"
                color="info"
                variant="soft"
                size="md"
                class="font-semibold lg:hidden"
              />
            </div>
            <div class="flex items-center gap-3">
              <slot name="po-actions" :po="po" />
              <div class="font-mono text-sm">
                Tổng:
                <span class="text-lg font-bold text-primary">{{ fmtQty(displayTotal(po)) }}</span>
              </div>
            </div>
          </div>

          <div v-if="expandedPOs.includes(po.id)" class="bg-surface-0 px-4 pt-2 pb-4">
            <ColorSizeMatrix :rows="filteredMatrixRows(po.id)" :all-sizes="allSizes" />
          </div>
        </template>
      </UCard>

      <!-- Empty State: all fully released -->
      <div
        v-if="allFullyReleased"
        class="flex flex-col items-center gap-3 rounded-lg border-2 border-dashed border-surface-200 bg-surface-50 py-12 text-toned"
      >
        <UIcon style="font-size: 48px" name="i-lucide-circle-check" class="text-green-400" />
        <p class="font-medium">
          {{
            showTypeTabs && activeTypeTab === 'POSITIVE'
              ? 'Đã phát hết toàn bộ sản lượng PO hàng dương'
              : 'Đã phát hết toàn bộ sản lượng'
          }}
        </p>
      </div>

      <!-- Empty State: tab has no POs in BO -->
      <div
        v-else-if="currentTabHasNoPOs"
        class="flex flex-col items-center gap-3 rounded-lg border-2 border-dashed border-surface-200 bg-surface-50 py-12 text-toned"
      >
        <UIcon
          style="font-size: 48px"
          :name="activeTypeTab === 'POSITIVE' ? 'i-lucide-sparkles' : 'i-lucide-package'"
          class="opacity-40"
        />
        <p class="font-medium">
          {{
            activeTypeTab === 'POSITIVE'
              ? 'Đơn hàng này chưa có PO hàng dương nào'
              : 'Đơn hàng này không có PO thường nào'
          }}
        </p>
      </div>

      <!-- Empty State: filter -->
      <div
        v-else-if="filteredPOs.length === 0"
        class="flex flex-col items-center gap-3 rounded-lg border-2 border-dashed border-surface-200 bg-surface-50 py-12 text-toned"
      >
        <UIcon style="font-size: 48px" name="i-lucide-inbox" />
        <p class="font-medium">Không tìm thấy PO nào phù hợp bộ lọc</p>
        <UButton
          v-if="
            marketFilter.length > 0 ||
            poCodeFilter.length > 0 ||
            colorFilter.length > 0 ||
            dateFilter.length > 0
          "
          label="Xóa bộ lọc"
          color="neutral"
          variant="ghost"
          @click="clearFilters"
        />
      </div>
    </div>
  </div>
</template>
