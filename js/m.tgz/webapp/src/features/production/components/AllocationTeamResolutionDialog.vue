<script setup lang="ts">
import type { PendingTeamResolutionRow } from '@/features/production/helpers/allocationExcelTeamMatcher'
import type { TableColumn } from '@nuxt/ui'

const columns: TableColumn<PendingTeamResolutionRow>[] = [
  { id: 'status', header: 'Trạng thái' },
  { id: 'rowNumbers', header: 'Dòng Excel' },
  { id: 'excelValue', header: 'Giá trị từ Excel' },
  { id: 'team', header: 'Tổ đúng trên hệ thống' },
]

const props = defineProps<{
  visible: boolean
  rows: PendingTeamResolutionRow[]
  optionsByRowKey: Record<string, Array<{ label: string; value: string }>>
  disabledConfirm: boolean
}>()

const emit = defineEmits<{
  close: []
  confirm: []
  updateSelection: [key: string, teamId: string | null]
}>()

function onSelectionChange(key: string, teamId: string | null | undefined) {
  emit('updateSelection', key, teamId ?? null)
}
</script>

<template>
  <UModal :open="visible" title="Xác nhận tổ từ Excel" :close="false" class="sm:max-w-[72rem]">
    <template #body>
      <div class="flex flex-col gap-4">
        <p class="text-sm leading-6 text-default">
          Một số giá trị tổ/xí nghiệp/công ty từ Excel không đủ rõ để tự map. Chọn tổ đúng trên hệ
          thống cho từng dòng trước khi tiếp tục import.
        </p>

        <UTable :data="props.rows" :columns>
          <template #status-cell="{ row }">
            <UBadge
              :label="row.original.status === 'ambiguous' ? 'Mơ hồ' : 'Không tìm thấy'"
              :color="row.original.status === 'ambiguous' ? 'warning' : 'error'"
            />
          </template>
          <template #rowNumbers-cell="{ row }">
            {{ row.original.rowNumbers.join(', ') }}
          </template>
          <template #excelValue-cell="{ row }">
            <div class="flex flex-col gap-1">
              <span class="font-medium">{{ row.original.excelValue }}</span>
              <span class="text-xs text-toned"> Công đoạn: {{ row.original.operationName }} </span>
              <span v-if="row.original.candidateLabels.length > 0" class="text-xs text-toned">
                Gợi ý: {{ row.original.candidateLabels.join(' | ') }}
              </span>
            </div>
          </template>
          <template #team-cell="{ row }">
            <USelectMenu
              :model-value="row.original.selectedTeamId ?? undefined"
              :items="props.optionsByRowKey[row.original.key] ?? []"
              label-key="label"
              value-key="value"
              class="w-full"
              placeholder="Chọn tổ đúng"
              @update:model-value="onSelectionChange(row.original.key, $event)"
            />
          </template>
        </UTable>
      </div>
    </template>

    <template #footer>
      <div class="flex justify-end gap-2">
        <UButton label="Hủy" color="neutral" @click="emit('close')" />
        <UButton
          label="Tiếp tục import"
          icon="i-lucide-check"
          :disabled="disabledConfirm"
          @click="emit('confirm')"
        />
      </div>
    </template>
  </UModal>
</template>
