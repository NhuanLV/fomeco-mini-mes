<script setup lang="ts">
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { computed } from 'vue'

interface AllocationRowData {
  poId?: string
  groupIndex: number
  rowIndex: number
  color: string
}
interface Addition {
  onSplit: (groupIndex: AllocationRowData) => void
  onDelete: (groupIndex: AllocationRowData) => void
}

const props = defineProps<MatrixGridCellProps & { addition?: Addition }>()
const rowData = computed(() => props.model as AllocationRowData)

const isFirstRow = computed(() => (props.model?.rowIndex ?? 0) === 0)
const color = computed(() => String(props.model?.color ?? ''))
function handleSplit() {
  props.addition?.onSplit(rowData.value)
}

function handleDelete() {
  props.addition?.onDelete(rowData.value)
}
</script>

<template>
  <div class="flex h-full w-full items-center justify-between gap-0.5 px-0.5">
    <span v-if="isFirstRow" class="truncate font-semibold">{{ color }}</span>
    <span v-else class="text-toned select-none">↳</span>

    <UButton
      v-if="isFirstRow"
      title="Thêm dòng phân bổ"
      @click.stop="handleSplit"
      variant="ghost"
      size="sm"
      icon="i-lucide-circle-plus"
      class="p-0!"
    />

    <UButton
      v-else
      title="Xoá dòng phân bổ này"
      @click.stop="handleDelete"
      variant="ghost"
      size="sm"
      icon="i-lucide-trash-2"
      class="p-0!"
    />
  </div>
</template>
