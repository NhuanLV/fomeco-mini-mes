<script setup lang="ts">
import AutoOpsAssignmentBanner from '@/features/production/components/AutoOpsAssignmentBanner.vue'
import PurchaseOrderAllocationSummary from '@/features/production/components/PurchaseOrderAllocationSummary.vue'
import PurchaseOrderAllocationTable from '@/features/production/components/PurchaseOrderAllocationTable.vue'
import TeamAssignmentScheduleTable from '@/features/production/components/TeamAssignmentScheduleTable.vue'
import { useReviewSummary } from '@/features/production/composables/useReviewSummary'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { storeToRefs } from 'pinia'

const { autoOperations, manualOperations } = storeToRefs(useProductionOrderIssuanceStore())
const { metadataSummary } = useReviewSummary()
</script>

<template>
  <div class="flex flex-col gap-6">
    <!-- Summary card (readonly) -->
    <PurchaseOrderAllocationSummary />

    <!-- Metadata -->
    <div class="grid grid-cols-1 gap-4 md:grid-cols-4">
      <div
        v-for="item in metadataSummary"
        :key="item.label"
        class="flex items-center gap-3 rounded-lg border border-surface-200 bg-surface-50 p-3"
      >
        <UIcon :name="item.icon" class="text-xl text-primary" />
        <div class="flex flex-col">
          <span class="text-xs font-semibold text-toned uppercase">{{ item.label }}</span>
          <span class="text-sm font-bold text-highlighted">{{ item.value }}</span>
        </div>
      </div>
    </div>

    <!-- Auto-ops banner -->
    <AutoOpsAssignmentBanner :ops="autoOperations" />

    <!-- Schedule table for planned dates per team assignment -->
    <TeamAssignmentScheduleTable />

    <!-- Readonly allocation table per manual operation -->
    <template v-for="(op, opIdx) in manualOperations" :key="op.opName">
      <div class="flex items-center gap-3 px-1">
        <span
          class="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs text-white"
        >
          {{ opIdx + 1 }}
        </span>
        <span class="text-lg font-semibold">Phân bổ — Công đoạn:</span>
        <UBadge :label="op.opName" color="info" />
      </div>
      <PurchaseOrderAllocationTable :op-name="op.opName" :readonly="true" />
    </template>

    <!-- Warning -->
    <div class="flex items-start gap-3 rounded-lg border border-yellow-200 bg-yellow-50 p-3">
      <UIcon name="i-lucide-triangle-alert" class="mt-1 text-yellow-600" />
      <div class="text-xs leading-relaxed text-yellow-800">
        <p class="mb-1 text-sm font-bold uppercase">Lưu ý trước khi phát hành:</p>
        <p>
          Dữ liệu sau khi phát hành sẽ được gửi đến các bộ phận liên quan. Vui lòng kiểm tra kỹ số
          lượng phân bổ và ngày dự kiến vào chuyền để tránh sai sót trong quá trình sản xuất.
        </p>
      </div>
    </div>
  </div>
</template>
