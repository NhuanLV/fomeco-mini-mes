<script setup lang="ts">
import { fmtQty } from '@/shared/utils/fmtQty'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { storeToRefs } from 'pinia'
import type { TableColumn } from '@nuxt/ui'
import { computed } from 'vue'
import { makeOrderComparator } from '@/shared/utils/orderedValues'

const { allSizes, summaryMatrix, buyerOrder } = storeToRefs(useProductionOrderIssuanceStore())
const viewRows = computed(() => {
  const cmpColor = makeOrderComparator(buyerOrder.value?.styleColorOrder ?? [])
  return [...summaryMatrix.value].sort((left, right) => cmpColor(left.color, right.color))
})

type SummaryRow = (typeof summaryMatrix.value)[number]

const columns = computed<TableColumn<SummaryRow>[]>(() => [
  { accessorKey: 'color', header: 'Màu' },
  ...allSizes.value.map((size) => ({ id: size, header: size })),
  { id: 'total', header: 'Tổng' },
])

function calculateRowTotal(data: Record<string, number>): number {
  return Object.values(data).reduce((sum, val) => sum + val, 0)
}
</script>

<template>
  <UTable :data="viewRows" :columns class="text-xs sm:text-sm">
    <template #empty>
      <div class="flex flex-col items-center gap-2 py-8 text-toned">
        <UIcon style="font-size: 48px" name="i-lucide-inbox" />
        <span>Chưa có số lượng phân bổ</span>
      </div>
    </template>

    <template #color-cell="{ row }">
      <span class="font-semibold">{{ row.original.color }}</span>
    </template>
    <template v-for="size in allSizes" :key="size" #[`${size}-cell`]="{ row }">
      <span v-if="row.original.data[size] > 0" class="font-mono font-semibold text-primary">
        {{ fmtQty(row.original.data[size]) }}
      </span>
      <span v-else class="text-toned">-</span>
    </template>
    <template #total-cell="{ row }">
      <span class="font-mono font-bold text-primary">
        {{ fmtQty(calculateRowTotal(row.original.data)) }}
      </span>
    </template>
  </UTable>
</template>
