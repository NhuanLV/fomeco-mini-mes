<script setup lang="ts">
interface OpPreview {
  operationName: string
  isAuto: boolean
  autoTeamName?: string
  teamCount: number
}
defineProps<{ allocations: OpPreview[] }>()
</script>

<template>
  <div v-if="allocations.length > 0" class="mt-4 rounded-lg border border-surface-200 p-4">
    <div class="mb-3 text-sm font-semibold text-default">Phân công công đoạn</div>
    <div class="flex flex-wrap gap-3">
      <div
        v-for="op in allocations"
        :key="op.operationName"
        class="flex items-center gap-2 rounded-md px-3 py-2 text-sm"
        :class="
          op.teamCount === 0
            ? 'border border-red-200 bg-red-50'
            : op.isAuto
              ? 'border border-green-200 bg-green-50'
              : 'border border-blue-200 bg-blue-50'
        "
      >
        <UIcon
          :name="
            op.teamCount === 0
              ? 'i-lucide-circle-x'
              : op.isAuto
                ? 'i-lucide-circle-check'
                : 'i-lucide-pencil'
          "
          class="size-4 text-[16px]"
          :class="
            op.teamCount === 0 ? 'text-red-600' : op.isAuto ? 'text-green-600' : 'text-blue-600'
          "
        />
        <span
          :class="
            op.teamCount === 0 ? 'text-red-800' : op.isAuto ? 'text-green-800' : 'text-blue-800'
          "
          class="font-medium"
        >
          {{ op.operationName }}
        </span>
        <span
          :class="
            op.teamCount === 0 ? 'text-red-600' : op.isAuto ? 'text-green-600' : 'text-blue-500'
          "
          class="text-xs"
        >
          {{
            op.teamCount === 0
              ? '(thiếu tổ đảm nhận)'
              : op.isAuto
                ? `→ ${op.autoTeamName} (tự động)`
                : '(nhập thủ công)'
          }}
        </span>
      </div>
    </div>
  </div>
</template>
