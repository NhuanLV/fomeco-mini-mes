<script setup lang="ts">
import AutoOpsAssignmentBanner from '@/features/production/components/AutoOpsAssignmentBanner.vue'
import PurchaseOrderAllocationSummary from '@/features/production/components/PurchaseOrderAllocationSummary.vue'
import PurchaseOrderAllocationTable from '@/features/production/components/PurchaseOrderAllocationTable.vue'
import { useProductionOrderIssuanceStore } from '@/features/production/production-order-issuance/useProductionOrderIssuanceStore'
import { storeToRefs } from 'pinia'
import AppDatePicker from '@/shared/components/AppDatePicker.vue'

defineProps<{
  onImportExcel: (file: File) => void
}>()

const {
  selectedPOs,
  syncDate,
  productDate,
  firstSku,
  autoOperations,
  manualOperations,
  allOperationsAuto,
} = storeToRefs(useProductionOrderIssuanceStore())
</script>

<template>
  <div class="flex flex-col gap-6">
    <!-- Summary -->
    <PurchaseOrderAllocationSummary :on-import-excel="onImportExcel" />
    <!-- Product Order Metadata-->
    <div class="mb-2 border-b border-surface-200 pb-8">
      <div
        class="mb-6 flex items-center gap-2 text-[10px] font-bold tracking-[0.2em] text-toned uppercase"
      >
        <UIcon name="i-lucide-info" class="text-xs text-primary" />
        <span>Thông tin chung lệnh sản xuất</span>
      </div>
      <div class="grid grid-cols-1 gap-8 md:grid-cols-3">
        <div class="flex flex-col gap-2">
          <label for="syncDate" class="ml-1 text-xs font-semibold text-default"
            >Ngày đồng bộ chuẩn bị sản xuất</label
          >
          <AppDatePicker
            v-model="syncDate"
            id="syncDate"
            placeholder="Chọn ngày..."
            class="w-full"
          />
        </div>

        <div class="flex flex-col gap-2">
          <label for="productDate" class="ml-1 text-xs font-semibold text-default"
            >Ngày dự kiến vào chuyền</label
          >
          <AppDatePicker
            v-model="productDate"
            id="productDate"
            placeholder="Chọn ngày..."
            class="w-full"
          />
        </div>

        <div class="flex flex-col gap-2">
          <label for="firstSku" class="ml-1 text-xs font-semibold text-default"
            >Màu/Cỡ đầu tiên</label
          >
          <UTextarea
            :rows="1"
            autoresize
            v-model="firstSku"
            id="firstSku"
            class="w-full"
            placeholder="VD: Black/S"
          />
        </div>
      </div>
    </div>

    <!-- ── Auto-assigned operations banner ─────────────────────────────── -->
    <AutoOpsAssignmentBanner :ops="autoOperations" />

    <!-- ── Manual operations: allocation per operation ──────────────────── -->
    <template v-for="(op, opIdx) in manualOperations" :key="op.opName">
      <!-- Operation header -->
      <div class="flex items-center gap-3 px-1">
        <span
          class="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs text-white"
        >
          {{ opIdx + 1 }}
        </span>
        <span class="text-lg font-semibold">{{
          allOperationsAuto ? 'Phân bổ chung cho tất cả công đoạn' : 'Phân bổ — Công đoạn:'
        }}</span>
        <UBadge v-if="!allOperationsAuto" :label="op.opName" color="info" />
        <span v-if="selectedPOs.length > 0" class="text-sm text-toned">
          ({{ selectedPOs.length }} PO đã chọn)
        </span>
      </div>

      <div class="flex flex-col gap-4">
        <PurchaseOrderAllocationTable :op-name="op.opName" />
      </div>
    </template>

    <p v-if="allOperationsAuto" class="text-sm text-toned">
      Sản lượng, ngày và ghi chú trong bảng phân bổ chung được áp dụng cho tất cả công đoạn.
    </p>
  </div>
</template>
