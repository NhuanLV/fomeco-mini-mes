export const ADMIN_ROLE_ID = 'ffffffff-ffff-ffff-ffff-ffffffffffff'
