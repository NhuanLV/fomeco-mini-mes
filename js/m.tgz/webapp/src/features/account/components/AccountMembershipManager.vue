<script setup lang="ts">
import type { RoleVm } from '@/api'
import type {
  EditableMembership,
  PendingMembership,
} from '@/features/account/composable/useAccountFormMemberships'
import { useUnitTree } from '@/features/account/composable/useUnitTree'
import { ADMIN_ROLE_ID } from '@/features/account/helpers/iam'
import AppTreeSelect from '@/shared/components/AppTreeSelect.vue'
import { computed } from 'vue'
import AccountRoleMultiSelector from './AccountRoleMultiSelector.vue'

const props = defineProps<{
  roles: RoleVm[]
}>()

const nonAdminRoles = computed(() => props.roles.filter((r) => r.id !== ADMIN_ROLE_ID))

const memberships = defineModel<EditableMembership[]>('memberships', { required: true })
const pendingMemberships = defineModel<PendingMembership[]>('pendingMemberships', {
  default: () => [],
})

const emit = defineEmits<{
  remove: [index: number]
}>()

const { unitNodes } = useUnitTree()

const addPendingMembership = () => {
  pendingMemberships.value.push({ id: crypto.randomUUID(), selectedUnit: null, roleIds: [] })
}

const removePendingMembership = (index: number) => {
  pendingMemberships.value.splice(index, 1)
}
</script>

<template>
  <div class="flex flex-col gap-3">
    <div class="flex items-center justify-between">
      <label class="text-sm font-bold tracking-wider text-toned uppercase">Đơn vị phân công</label>
      <UButton
        variant="ghost"
        size="sm"
        icon="i-lucide-plus"
        label="Thêm phân công"
        @click="addPendingMembership"
      />
    </div>

    <div class="flex flex-col gap-3">
      <!-- Existing Memberships Cards -->
      <div
        v-for="m in memberships"
        :key="m.unitId"
        class="flex items-center gap-4 rounded-xl border border-surface-200 bg-surface-50 p-4"
      >
        <div class="flex flex-1 flex-col gap-1">
          <span class="text-sm font-semibold text-highlighted">{{ m.unitName }}</span>
          <span class="text-xs text-toned italic">
            {{ [m.factoryName, m.companyName].filter(Boolean).join(' — ') }}
          </span>
        </div>
        <div class="w-96">
          <AccountRoleMultiSelector
            :model-value="m.roleIds.filter((id) => id !== ADMIN_ROLE_ID)"
            @update:model-value="m.roleIds = $event"
            :roles="nonAdminRoles"
            placeholder="Chọn vai trò"
          />
        </div>
        <UButton
          :disabled="m.isAdmin"
          icon="i-lucide-trash-2"
          color="error"
          variant="ghost"
          @click="emit('remove', memberships.indexOf(m))"
          :title="
            m.isAdmin ? 'Không thể xoá phân công ở Tổng công ty của Super Admin' : 'Xóa phân công'
          "
        />
      </div>

      <!-- Pending New Membership Cards -->
      <div
        v-for="(pending, index) in pendingMemberships"
        :key="pending.id"
        class="flex items-center gap-4 rounded-xl border border-dashed border-primary-200 bg-primary-50/30 p-4"
      >
        <div class="flex-1">
          <AppTreeSelect
            v-model="pending.selectedUnit"
            :options="unitNodes"
            placeholder="Chọn đơn vị mới"
            class="w-full text-sm"
          />
        </div>
        <div class="w-96">
          <AccountRoleMultiSelector
            :model-value="pending.roleIds.filter((id) => id !== ADMIN_ROLE_ID)"
            @update:model-value="pending.roleIds = $event"
            :roles="nonAdminRoles"
            placeholder="Chọn vai trò"
          />
        </div>
        <UButton
          icon="i-lucide-x"
          color="error"
          variant="ghost"
          @click="removePendingMembership(index)"
          :title="'Hủy thêm'"
        />
      </div>
    </div>
  </div>
</template>
