<script setup lang="ts">
import type { RoleVm } from '@/api'
import { ADMIN_ROLE_ID } from '@/features/account/helpers/iam'
import { computed } from 'vue'
import AccountRoleMultiSelector from './AccountRoleMultiSelector.vue'

const props = defineProps<{
  modelValue: string[]
  roles: RoleVm[]
  disabled?: boolean
  required?: boolean
  invalid?: boolean
}>()

const emit = defineEmits<{
  'update:modelValue': [value: string[]]
}>()

const selectableRoles = computed(() => props.roles.filter((r) => r.id !== ADMIN_ROLE_ID))

const selectedRoleIds = computed({
  get: () => props.modelValue,
  set: (value) => emit('update:modelValue', value),
})
</script>

<template>
  <div class="flex flex-col gap-2">
    <label class="text-sm font-medium">
      Vai trò <span v-if="required" class="text-red-500">*</span>
    </label>

    <div :class="invalid ? 'rounded-md ring ring-error' : undefined">
      <AccountRoleMultiSelector
        v-model="selectedRoleIds"
        :roles="selectableRoles"
        placeholder="Chọn vai trò"
        :disabled="disabled"
        class="w-full"
      />
    </div>
  </div>
</template>
