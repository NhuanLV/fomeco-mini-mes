<script setup lang="ts">
import type { RoleVm } from '@/api'
import { ADMIN_ROLE_ID } from '@/features/account/helpers/iam'
import { computed, ref } from 'vue'

const props = defineProps<{
  modelValue: string[]
  roles: RoleVm[]
  disabled?: boolean
  placeholder?: string
}>()

const emit = defineEmits<{
  'update:modelValue': [value: string[]]
}>()

const searchTerm = ref('')

const selectableRoles = computed(() => props.roles.filter((role) => role.id !== ADMIN_ROLE_ID))

const selectedRoleIds = computed({
  get: () => props.modelValue.filter((id) => selectableRoles.value.some((role) => role.id === id)),
  set: (value: string[]) => emit('update:modelValue', [...new Set(value)]),
})

const selectedRoles = computed(() =>
  selectableRoles.value.filter((role) => selectedRoleIds.value.includes(role.id)),
)

const filteredRoles = computed(() => {
  const keyword = searchTerm.value.trim().toLowerCase()
  if (!keyword) return selectableRoles.value

  return selectableRoles.value.filter((role) => {
    const haystack = `${role.name} ${role.description ?? ''}`.toLowerCase()
    return haystack.includes(keyword)
  })
})

const isAllSelected = computed(
  () =>
    selectableRoles.value.length > 0 &&
    selectableRoles.value.every((role) => selectedRoleIds.value.includes(role.id)),
)

const isPartialSelected = computed(() => {
  const count = selectedRoleIds.value.length
  return count > 0 && count < selectableRoles.value.length
})

const triggerLabel = computed(() => {
  if (selectedRoles.value.length === 0) return props.placeholder ?? 'Chọn vai trò'
  if (selectedRoles.value.length === 1) return selectedRoles.value[0]?.name ?? ''
  return `Đã chọn ${selectedRoles.value.length} vai trò`
})

const isSelected = (roleId: string) => selectedRoleIds.value.includes(roleId)

const toggleRole = (roleId: string, checked: boolean | 'indeterminate') => {
  if (checked === 'indeterminate') return

  if (checked) {
    selectedRoleIds.value = [...selectedRoleIds.value, roleId]
    return
  }

  selectedRoleIds.value = selectedRoleIds.value.filter((id) => id !== roleId)
}

const toggleAll = (checked: boolean | 'indeterminate') => {
  if (checked === 'indeterminate') return
  selectedRoleIds.value = checked ? selectableRoles.value.map((role) => role.id) : []
}

const clearAll = () => {
  selectedRoleIds.value = []
}

const removeRole = (roleId: string) => {
  selectedRoleIds.value = selectedRoleIds.value.filter((id) => id !== roleId)
}
</script>

<template>
  <div class="flex flex-col gap-2">
    <UPopover :content="{ align: 'start', side: 'bottom', sideOffset: 8 }">
      <UButton
        type="button"
        color="neutral"
        variant="outline"
        class="w-full justify-between text-left"
        :disabled="disabled"
        trailing-icon="i-lucide-chevron-down"
      >
        <span class="truncate">{{ triggerLabel }}</span>
      </UButton>

      <template #content>
        <div class="w-96 p-3">
          <div class="flex flex-col gap-3">
            <UInput
              v-model="searchTerm"
              placeholder="Tìm vai trò..."
              icon="i-lucide-search"
              :disabled="disabled"
            />

            <div
              class="flex items-center justify-between gap-2 rounded-lg border border-surface-200 bg-surface-50 px-3 py-2"
            >
              <div class="flex items-center gap-2">
                <UCheckbox
                  :model-value="isAllSelected || isPartialSelected"
                  :indeterminate="isPartialSelected"
                  :disabled="disabled"
                  @update:model-value="toggleAll"
                />
                <span class="text-sm font-medium">Chọn tất cả</span>
              </div>

              <UButton
                v-if="selectedRoleIds.length > 0"
                type="button"
                variant="ghost"
                size="sm"
                color="neutral"
                label="Xóa hết"
                :disabled="disabled"
                @click="clearAll"
              />
            </div>

            <div
              class="flex max-h-64 flex-col gap-1 overflow-y-auto rounded-lg border border-surface-200 p-2"
            >
              <button
                v-for="role in filteredRoles"
                :key="role.id"
                type="button"
                class="flex items-start gap-2 rounded px-2 py-1.5 text-left hover:bg-surface-50"
                :disabled="disabled"
                @click="toggleRole(role.id, !isSelected(role.id))"
              >
                <UCheckbox
                  :model-value="isSelected(role.id)"
                  :disabled="disabled"
                  @click.stop
                  @update:model-value="toggleRole(role.id, $event)"
                />
                <div class="flex min-w-0 flex-1 flex-col">
                  <span class="text-sm">{{ role.name }}</span>
                  <span v-if="role.description" class="text-xs text-toned">
                    {{ role.description }}
                  </span>
                </div>
              </button>

              <div
                v-if="filteredRoles.length === 0"
                class="px-2 py-3 text-center text-sm text-toned"
              >
                Không có vai trò phù hợp
              </div>
            </div>
          </div>
        </div>
      </template>
    </UPopover>

    <div v-if="selectedRoles.length > 0" class="flex flex-wrap gap-2">
      <span
        v-for="role in selectedRoles"
        :key="role.id"
        class="inline-flex max-w-full items-center gap-1 rounded-full bg-primary-50 px-3 py-1 text-xs font-medium text-primary-700"
      >
        <span class="truncate">{{ role.name }}</span>
        <button
          type="button"
          class="shrink-0 hover:text-primary-900"
          :disabled="disabled"
          @click="removeRole(role.id)"
        >
          <UIcon name="i-lucide-x" class="size-3.5" />
        </button>
      </span>
    </div>
  </div>
</template>
