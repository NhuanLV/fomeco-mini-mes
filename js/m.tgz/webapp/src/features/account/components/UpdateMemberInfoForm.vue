<script setup lang="ts">
import type { AccountVm, RoleVm } from '@/api'
import {
  createUnitMembershipMutation,
  deleteUnitMembershipMutation,
  getRolesQuery,
  transferAdminMutation,
  updateAccountInfoMutation,
  updateMembershipMutation,
} from '@/api/@pinia/colada.gen'
import type {
  EditableMembership,
  PendingMembership,
} from '@/features/account/composable/useAccountFormMemberships'
import { ADMIN_ROLE_ID } from '@/features/account/helpers/iam'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useMutation, useQuery } from '@pinia/colada'
import { useConfirm } from '@/shared/composables/useConfirm'
import { computed, ref, watch } from 'vue'
import AccountMembershipManager from './AccountMembershipManager.vue'
import AccountProfileSection from './AccountProfileSection.vue'

const props = defineProps<{
  visible: boolean
  account: AccountVm
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
  updated: []
  adminTransferred: []
}>()

const confirm = useConfirm()

const { data: rolesResult } = useQuery(getRolesQuery())
const roles = computed<RoleVm[]>(() => rolesResult.value ?? [])

const name = ref('')
const username = ref('')

const memberships = ref<EditableMembership[]>([])
const pendingMemberships = ref<PendingMembership[]>([])

watch(
  () => props.visible,
  (visible) => {
    if (visible) {
      name.value = props.account.name
      username.value = props.account.username
      memberships.value = props.account.memberships.map((m) => ({
        unitId: m.unitId,
        unitName: m.unitName,
        factoryName: m.factoryName ?? '',
        companyName: m.companyName ?? '',
        roleIds: m.roles.map((r) => r.id).filter((id) => id !== ADMIN_ROLE_ID),
        isAdmin: m.roles.some((r) => r.id === ADMIN_ROLE_ID),
      }))
      pendingMemberships.value = []
    }
  },
  { immediate: true },
)

const { mutateAsync: updateMembershipMutate } = useMutation(updateMembershipMutation())
const { mutateAsync: updateInfoMutate } = useMutation(updateAccountInfoMutation())
const { mutateAsync: deleteMembershipMutate } = useMutation(deleteUnitMembershipMutation())
const { mutateAsync: assignUnitMembershipMutate } = useMutation(createUnitMembershipMutation())
const { mutateAsync: transferAdminMutate } = useMutation(transferAdminMutation())

const isCorporationMember = computed(() =>
  props.account.memberships.some((m) => m.unitType === 'CORPORATION'),
)

const isAdmin = computed(() =>
  props.account.memberships.some((m) => m.roles.some((r) => r.id === ADMIN_ROLE_ID)),
)

const saving = ref(false)
const transferring = ref(false)

const handleTransferAdmin = () => {
  confirm.require({
    message: `Bạn có chắc chắn muốn chuyển quyền Quản trị viên hệ thống cho tài khoản "${props.account.name}" không? Sau khi chuyển, bạn sẽ mất quyền Quản trị viên.`,
    header: 'Xác nhận chuyển quyền Admin',
    icon: 'i-lucide-triangle-alert',
    rejectLabel: 'Hủy',
    rejectProps: {
      label: 'Hủy',
    },
    acceptProps: {
      label: 'Chuyển quyền',
      color: 'warning',
    },
    accept: async () => {
      transferring.value = true
      try {
        await transferAdminMutate({ body: { newAdminId: props.account.id } })
        showSuccess('Chuyển quyền Admin thành công')
        emit('adminTransferred')
        emit('update:visible', false)
      } catch (error: unknown) {
        showError((error as Error)?.message || 'Không thể chuyển quyền Admin')
      } finally {
        transferring.value = false
      }
    },
  })
}

const save = async () => {
  if (!name.value.trim() || !username.value.trim()) {
    showError('Vui lòng nhập đầy đủ họ tên và tên tài khoản')
    return
  }

  saving.value = true
  try {
    const promises: Promise<unknown>[] = []

    // 1. Update Profile if changed
    if (name.value !== props.account.name || username.value !== props.account.username) {
      promises.push(
        updateInfoMutate({
          path: { id: props.account.id },
          body: { name: name.value, username: username.value },
        }),
      )
    }

    // 2. Update/Delete existing memberships
    // 2.1 Handle updates and keep track of current units
    const currentUnitIds = new Set(memberships.value.map((m) => m.unitId))

    memberships.value.forEach((m) => {
      const original = props.account.memberships.find((om) => om.unitId === m.unitId)
      if (original) {
        const originalRoleIds = original.roles.map((r) => r.id).sort()
        const currentRoleIds = [...m.roleIds].sort()

        if (JSON.stringify(originalRoleIds) !== JSON.stringify(currentRoleIds)) {
          promises.push(
            updateMembershipMutate({
              path: { id: props.account.id },
              body: { unitId: m.unitId, roleIds: m.roleIds.filter((id) => id !== ADMIN_ROLE_ID) },
            }),
          )
        }
      }
    })

    // 2.2 Handle deletions
    props.account.memberships.forEach((om) => {
      if (!currentUnitIds.has(om.unitId)) {
        promises.push(
          deleteMembershipMutate({
            path: { id: props.account.id, unitId: om.unitId },
          }),
        )
      }
    })

    // 3. Assign new memberships (batch)
    const newMemberships = pendingMemberships.value
      .map((p) => {
        const [unitId] = Object.keys(p.selectedUnit ?? {})
        const roleIds = p.roleIds.filter((id) => id !== ADMIN_ROLE_ID)
        return unitId && roleIds.length > 0 ? { unitId, roleIds } : null
      })
      .filter((m): m is { unitId: string; roleIds: string[] } => m !== null)

    if (newMemberships.length > 0) {
      promises.push(
        assignUnitMembershipMutate({
          path: { id: props.account.id },
          body: { memberships: newMemberships },
        }),
      )
    }

    await Promise.all(promises)
    showSuccess('Cập nhật tài khoản thành công')
    emit('updated')
    emit('update:visible', false)
  } catch (error: unknown) {
    showError((error as Error)?.message || 'Không thể cập nhật tài khoản')
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <UModal
    :open="visible"
    @update:open="emit('update:visible', $event)"
    title="Cập nhật tài khoản & Phân công"
    class="sm:max-w-[700px]"
  >
    <template #body>
      <div class="flex flex-col gap-6 py-2">
        <AccountProfileSection v-model:name="name" v-model:username="username" />

        <AccountMembershipManager
          v-model:memberships="memberships"
          v-model:pending-memberships="pendingMemberships"
          :roles="roles"
          @remove="memberships.splice($event, 1)"
        />
      </div>
    </template>

    <template #footer>
      <div class="flex w-full items-center justify-between gap-2">
        <div>
          <UButton
            v-if="isCorporationMember && !isAdmin"
            :loading="transferring"
            color="warning"
            variant="outline"
            type="button"
            icon="i-lucide-shield"
            label="Chuyển quyền Admin"
            @click="handleTransferAdmin"
          />
        </div>
        <div class="flex gap-2">
          <UButton
            color="neutral"
            variant="ghost"
            type="button"
            @click="emit('update:visible', false)"
            label="Hủy"
          />
          <UButton
            :loading="saving"
            type="button"
            @click="save"
            icon="i-lucide-check"
            label="Lưu thay đổi"
          />
        </div>
      </div>
    </template>
  </UModal>
</template>
