<script setup lang="ts">
import type { AccountVm, MembershipVm } from '@/api'

defineProps<{
  visible: boolean
  account: AccountVm | null
  membership: MembershipVm | null
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
}>()
</script>

<template>
  <UModal
    :open="visible"
    @update:open="emit('update:visible', $event)"
    title="Chi tiết tài khoản"
    class="sm:max-w-[700px]"
  >
    <template #body>
      <div v-if="account" class="flex flex-col gap-6 py-2">
        <div class="grid grid-cols-2 gap-4">
          <div class="flex flex-col gap-1">
            <label class="text-sm font-medium">Họ và tên</label>
            <div class="rounded-md border border-surface-200 px-3 py-2 text-sm">
              {{ account.name }}
            </div>
          </div>
          <div class="flex flex-col gap-1">
            <label class="text-sm font-medium">Tên tài khoản</label>
            <div class="rounded-md border border-surface-200 px-3 py-2 text-sm">
              {{ account.username }}
            </div>
          </div>
        </div>

        <div class="flex flex-col gap-3">
          <div class="text-sm font-medium">Đơn vị & Vai trò</div>
          <div v-if="membership" class="rounded-md border border-surface-200 p-3">
            <div class="text-sm font-semibold">
              {{
                [membership.unitName, membership.factoryName, membership.companyName]
                  .filter((v, i, a) => v && a.indexOf(v) === i)
                  .join(' — ')
              }}
            </div>
            <div class="mt-2 flex flex-wrap gap-1">
              <UBadge
                v-for="role in membership.roles"
                :key="role.id"
                :label="role.name"
                color="info"
                class="px-1 py-0! text-[10px]"
              />
            </div>
          </div>
          <div
            v-else
            class="rounded-md border border-surface-200 px-3 py-2 text-sm text-toned italic"
          >
            Chưa phân công
          </div>
        </div>
      </div>
    </template>
    <template #footer>
      <div class="flex w-full justify-end">
        <UButton
          color="neutral"
          variant="ghost"
          type="button"
          @click="emit('update:visible', false)"
          label="Đóng"
        />
      </div>
    </template>
  </UModal>
</template>
