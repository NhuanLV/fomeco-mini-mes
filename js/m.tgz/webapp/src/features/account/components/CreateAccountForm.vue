<script setup lang="ts">
import type { RoleVm } from '@/api'
import { createAccountMutation, getRolesQuery } from '@/api/@pinia/colada.gen'
import { useAccountFormMemberships } from '@/features/account/composable/useAccountFormMemberships'
import { useUnitTree } from '@/features/account/composable/useUnitTree'
import { ADMIN_ROLE_ID } from '@/features/account/helpers/iam'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useMutation, useQuery } from '@pinia/colada'
import type { FormSubmitEvent } from '@nuxt/ui'
import { computed, reactive, ref } from 'vue'
import * as z from 'zod'
import AccountMembershipRow from './AccountMembershipRow.vue'

const props = withDefaults(
  defineProps<{
    visible: boolean
    mode?: 'create'
  }>(),
  { mode: 'create' },
)

const emit = defineEmits<{
  'update:visible': [value: boolean]
  created: []
}>()

const schema = z.object({
  name: z.string().trim().min(1, 'Vui lòng nhập họ và tên'),
  username: z.string().trim().min(1, 'Vui lòng nhập tên đăng nhập'),
  password: z
    .string()
    .min(1, 'Vui lòng nhập mật khẩu')
    .regex(/^[a-zA-Z0-9]+$/, 'Mật khẩu chỉ chứa chữ và số'),
})
type Schema = z.output<typeof schema>

const state = reactive<Schema>({ name: '', username: '', password: '' })

const membershipError = ref('')
const { memberships, addMembershipRow, removeMembershipRow, isAdminAssignment } =
  useAccountFormMemberships(props, membershipError)

const { unitNodes } = useUnitTree()
const { data: rolesResult } = useQuery(getRolesQuery())
const roles = computed<RoleVm[]>(() => rolesResult.value ?? [])

const { mutateAsync: createMutate, isLoading: loading } = useMutation(createAccountMutation())

const save = async (e: FormSubmitEvent<Schema>) => {
  const assignments = memberships.value
    .map((m) => {
      const [unitId] = Object.keys(m.selectedUnit ?? {})
      return { unitId, roleIds: m.roleIds.filter((id) => id !== ADMIN_ROLE_ID) }
    })
    .filter((a): a is { unitId: string; roleIds: string[] } => !!a.unitId && a.roleIds.length > 0)

  if (assignments.length === 0) membershipError.value = 'Vui lòng thêm ít nhất một phân công'
  if (assignments.length === 0) return
  const values = e.data

  // Group roles by unit (in case of duplicates in the UI list)
  const rolesByUnit = new Map<string, Set<string>>()
  assignments.forEach((a) => {
    const set = rolesByUnit.get(a.unitId) ?? new Set<string>()
    a.roleIds.forEach((id) => set.add(id))
    rolesByUnit.set(a.unitId, set)
  })

  const membershipPayload = Array.from(rolesByUnit.entries()).map(([unitId, roleSet]) => ({
    unitId,
    roleIds: Array.from(roleSet),
  }))

  try {
    await createMutate({
      body: {
        name: values.name,
        username: values.username,
        password: values.password!,
        memberships: membershipPayload,
      },
    })
    showSuccess('Tạo tài khoản thành công')
    emit('created')
    emit('update:visible', false)
  } catch (error: unknown) {
    showError((error as Error)?.message || 'Không thể tạo tài khoản')
  }
}
</script>

<template>
  <UModal
    :open="visible"
    @update:open="emit('update:visible', $event)"
    title="Tạo tài khoản mới"
    class="sm:max-w-[700px]"
  >
    <template #body>
      <UForm id="create-account-form" :schema :state @submit="save" class="flex flex-col gap-4">
        <div class="flex flex-col gap-4">
          <UFormField label="Họ và tên" name="name" required>
            <UInput v-model="state.name" />
          </UFormField>
          <UFormField label="Tên đăng nhập" name="username" required>
            <UInput v-model="state.username" />
          </UFormField>
          <UFormField label="Mật khẩu" name="password" required>
            <UInput v-model="state.password" type="password" />
          </UFormField>
        </div>

        <div class="flex flex-col gap-2">
          <div class="flex items-center justify-between">
            <label class="text-sm font-medium">Phân công <span class="text-red-500">*</span></label>
            <UButton
              type="button"
              variant="ghost"
              size="sm"
              icon="i-lucide-plus"
              label="Thêm vai trò"
              @click="addMembershipRow"
            />
          </div>
          <AccountMembershipRow
            v-for="(row, index) in memberships"
            :key="row.id"
            v-model:selected-unit="row.selectedUnit"
            v-model:role-ids="row.roleIds"
            :index="index"
            :unit-nodes="unitNodes"
            :roles="roles"
            mode="create"
            :can-remove="memberships.length > 1"
            :is-admin-assignment="isAdminAssignment(index)"
            :target-membership-exists="false"
            @remove="removeMembershipRow"
          />
          <small v-if="membershipError" class="text-red-500">{{ membershipError }}</small>
        </div>
      </UForm>
    </template>
    <template #footer>
      <div class="flex justify-end gap-2">
        <UButton
          color="neutral"
          variant="ghost"
          type="button"
          @click="emit('update:visible', false)"
          icon="i-lucide-x"
          label="Hủy"
        />
        <UButton
          :loading="loading"
          type="submit"
          form="create-account-form"
          icon="i-lucide-check"
          label="Lưu"
        />
      </div>
    </template>
  </UModal>
</template>
