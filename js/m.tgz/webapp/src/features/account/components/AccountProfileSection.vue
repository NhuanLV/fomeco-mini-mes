<script setup lang="ts">
const name = defineModel<string>('name', { required: true })
const username = defineModel<string>('username', { required: true })
</script>

<template>
  <div class="grid grid-cols-2 gap-4">
    <div class="flex flex-col gap-1">
      <label class="text-sm font-medium">Họ và tên <span class="text-red-500">*</span></label>
      <UInput v-model="name" placeholder="Nhập họ và tên" />
    </div>
    <div class="flex flex-col gap-1">
      <label class="text-sm font-medium">Tên tài khoản <span class="text-red-500">*</span></label>
      <UInput v-model="username" placeholder="Nhập tên tài khoản" />
    </div>
  </div>
</template>
