<script setup lang="ts">
import type { AccountVm } from '@/api'
import { changePasswordMutation } from '@/api/@pinia/colada.gen'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useMutation } from '@pinia/colada'
import { ref } from 'vue'

const props = defineProps<{
  account: AccountVm
}>()

const visible = defineModel<boolean>('visible', { default: false })

const newPassword = ref('')
const confirmPassword = ref('')
const showNewPassword = ref(false)
const showConfirmPassword = ref(false)
const isSubmitting = ref(false)

const { mutateAsync } = useMutation(changePasswordMutation())

const resetForm = () => {
  newPassword.value = ''
  confirmPassword.value = ''
  showNewPassword.value = false
  showConfirmPassword.value = false
}

const handleClose = () => {
  visible.value = false
  resetForm()
}

const handleSave = async () => {
  if (!newPassword.value) {
    return
  }
  if (newPassword.value !== confirmPassword.value) {
    return
  }

  isSubmitting.value = true
  try {
    await mutateAsync({
      path: { id: props.account.id },
      body: { newPassword: newPassword.value },
    })
    showSuccess('Đổi mật khẩu thành công')
    handleClose()
  } catch (error: unknown) {
    showError((error as Error).message || 'Không thể đổi mật khẩu')
  } finally {
    isSubmitting.value = false
  }
}
</script>

<template>
  <UModal
    v-model:open="visible"
    title="Đổi mật khẩu"
    class="sm:max-w-[400px]"
    @after:leave="resetForm"
  >
    <template #body>
      <div class="flex flex-col gap-4 py-2">
        <div class="flex flex-col gap-2">
          <label for="newPassword" class="text-sm font-semibold">Mật khẩu mới</label>
          <UInput
            id="newPassword"
            v-model="newPassword"
            :type="showNewPassword ? 'text' : 'password'"
            class="w-full"
            placeholder="Nhập mật khẩu mới"
            autofocus
          >
            <template #trailing>
              <UButton
                :icon="showNewPassword ? 'i-lucide-eye-off' : 'i-lucide-eye'"
                color="neutral"
                variant="ghost"
                size="sm"
                aria-label="Hiện/ẩn mật khẩu mới"
                @click="showNewPassword = !showNewPassword"
              />
            </template>
          </UInput>
        </div>

        <div class="flex flex-col gap-2">
          <label for="confirmPassword" class="text-sm font-semibold">Xác nhận mật khẩu</label>
          <UInput
            id="confirmPassword"
            v-model="confirmPassword"
            :type="showConfirmPassword ? 'text' : 'password'"
            class="w-full"
            placeholder="Nhập lại mật khẩu mới"
          >
            <template #trailing>
              <UButton
                :icon="showConfirmPassword ? 'i-lucide-eye-off' : 'i-lucide-eye'"
                color="neutral"
                variant="ghost"
                size="sm"
                aria-label="Hiện/ẩn mật khẩu xác nhận"
                @click="showConfirmPassword = !showConfirmPassword"
              />
            </template>
          </UInput>
          <UAlert
            v-if="confirmPassword && newPassword !== confirmPassword"
            color="error"
            description="Mật khẩu xác nhận không khớp"
          />
        </div>
      </div>
    </template>

    <template #footer>
      <UButton
        label="Hủy"
        variant="ghost"
        color="neutral"
        @click="handleClose"
        :disabled="isSubmitting"
      />
      <UButton
        label="Lưu"
        icon="i-lucide-check"
        @click="handleSave"
        :loading="isSubmitting"
        :disabled="!newPassword || newPassword !== confirmPassword"
      />
    </template>
  </UModal>
</template>
