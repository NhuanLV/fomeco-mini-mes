<script setup lang="ts">
import type { RoleVm } from '@/api'
import type { UnitTreeNode } from '@/features/account/composable/useUnitTree'
import { ADMIN_ROLE_ID } from '@/features/account/helpers/iam'
import AppTreeSelect from '@/shared/components/AppTreeSelect.vue'
import { computed } from 'vue'
import AccountRoleMultiSelector from './AccountRoleMultiSelector.vue'

const props = defineProps<{
  selectedUnit: Record<string, boolean> | null
  roleIds: string[]
  index: number
  unitNodes: UnitTreeNode[]
  roles: RoleVm[]
  canRemove: boolean
  isAdminAssignment: boolean
  targetMembershipExists: boolean
  mode: string
}>()

const emit = defineEmits<{
  'update:selectedUnit': [value: Record<string, boolean> | null]
  'update:roleIds': [value: string[]]
  remove: [index: number]
}>()

const nonAdminRoles = computed(() => props.roles.filter((r) => r.id !== ADMIN_ROLE_ID))
</script>

<template>
  <div class="flex items-center gap-4 rounded-lg border border-surface-200 p-3">
    <div class="flex-1">
      <AppTreeSelect
        :model-value="selectedUnit"
        @update:model-value="emit('update:selectedUnit', $event)"
        :options="unitNodes"
        placeholder="Chọn đơn vị..."
        class="w-full text-sm"
        :disabled="isAdminAssignment || (mode === 'edit-membership' && targetMembershipExists)"
      />
    </div>

    <div class="w-96">
      <AccountRoleMultiSelector
        :model-value="roleIds.filter((id) => id !== ADMIN_ROLE_ID)"
        @update:model-value="emit('update:roleIds', $event)"
        :roles="nonAdminRoles"
        placeholder="Chọn vai trò"
      />
    </div>

    <UButton
      v-if="canRemove && !isAdminAssignment"
      type="button"
      variant="ghost"
      color="error"
      icon="i-lucide-x"
      @click="emit('remove', index)"
      :title="'Xóa đơn vị'"
    />
  </div>
</template>
