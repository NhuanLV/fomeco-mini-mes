import { ref, watch, type Ref } from 'vue'
import type { AccountVm, MembershipVm } from '@/api'

export interface EditableMembership {
  unitId: string
  unitName: string
  factoryName: string
  companyName: string
  roleIds: string[]
  isAdmin: boolean
}

export interface PendingMembership {
  id: string
  selectedUnit: Record<string, boolean> | null
  roleIds: string[]
}

export interface MembershipRow {
  id: string
  selectedUnit: Record<string, boolean> | null
  roleIds: string[]
  isSystem: boolean
}

export const useAccountFormMemberships = (
  props: {
    mode?: 'create' | 'edit-profile' | 'edit-membership'
    targetMembership?: MembershipVm | null
    account?: AccountVm | null
    visible: boolean
  },
  membershipError: Ref<string>,
) => {
  const memberships = ref<MembershipRow[]>([])

  const addMembershipRow = () => {
    memberships.value.unshift({
      id: crypto.randomUUID(),
      selectedUnit: null,
      roleIds: [],
      isSystem: false,
    })
  }

  const removeMembershipRow = (index: number) => {
    memberships.value.splice(index, 1)
  }

  const isAdminAssignment = (index: number) => {
    return memberships.value[index]?.isSystem ?? false
  }

  const initMemberships = (account?: AccountVm | null): MembershipRow[] => {
    if (props.mode === 'edit-membership' && props.targetMembership) {
      const containsSystemRole = props.targetMembership.roles.some((r) => r.isSystem)
      return [
        {
          id: crypto.randomUUID(),
          selectedUnit: { [props.targetMembership.unitId]: true },
          roleIds: props.targetMembership.roles.filter((r) => !r.isSystem).map((r) => r.id),
          isSystem: containsSystemRole,
        },
      ]
    }

    if (props.mode === 'edit-membership' && !props.targetMembership) {
      return [{ id: crypto.randomUUID(), selectedUnit: null, roleIds: [], isSystem: false }]
    }

    if (!account || account.memberships.length === 0) {
      return [{ id: crypto.randomUUID(), selectedUnit: null, roleIds: [], isSystem: false }]
    }

    return account.memberships.map((m) => ({
      id: crypto.randomUUID(),
      selectedUnit: { [m.unitId]: true },
      roleIds: m.roles.filter((r) => !r.isSystem).map((r) => r.id),
      isSystem: m.roles.some((r) => r.isSystem),
    }))
  }

  watch(
    [() => props.account, () => props.visible],
    ([account, visible]) => {
      if (visible) {
        memberships.value = initMemberships(account)
        membershipError.value = ''
      }
    },
    { immediate: true },
  )

  return {
    memberships,
    addMembershipRow,
    removeMembershipRow,
    isAdminAssignment,
  }
}
