import { computed } from 'vue'
import { useQuery } from '@pinia/colada'
import { getTreeQuery } from '@/api/@pinia/colada.gen'
import type { UnitVm } from '@/api'

export type UnitTreeNode = {
  key: string
  label: string
  data: UnitVm
  children: UnitTreeNode[]
}

export const useUnitTree = () => {
  const { data: treeResult } = useQuery(getTreeQuery())

  const buildTreeNodes = (unit: UnitVm): UnitTreeNode => {
    return {
      key: unit.id,
      label: unit.name,
      data: unit,
      children: unit.children?.map((child) => buildTreeNodes(child)) || [],
    }
  }

  const unitNodes = computed<UnitTreeNode[]>(() => {
    const treeData = treeResult.value
    if (!treeData) return []
    const trees = Array.isArray(treeData) ? treeData : [treeData]
    return trees.map((tree) => buildTreeNodes(tree as UnitVm))
  })

  return {
    unitNodes,
  }
}
