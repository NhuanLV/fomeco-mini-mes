import type { UnitVm } from '@/api'

// Organization tree node wrapper
export interface OrgTreeNode {
  key: string
  label: string
  data: UnitVm
  children: OrgTreeNode[]
  parent?: OrgTreeNode
}

export interface TreeNode {
  key: string
  label: string
  data: UnitVm
  icon: string
  children: TreeNode[]
}
