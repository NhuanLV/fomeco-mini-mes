import type { UnitVm } from '@/api'
import type { OrgTreeNode } from '../types'

export function mapUnitToTreeNode(node: UnitVm, parent?: OrgTreeNode): OrgTreeNode {
  const treeNode: OrgTreeNode = {
    key: node.id,
    label: node.name,
    data: node,
    children: [],
    parent,
  }

  if (!node.children?.length) return treeNode

  if (node.type === 'FACTORY') {
    const groups: Record<string, UnitVm[]> = {}
    const others: UnitVm[] = []

    for (const child of node.children) {
      if (child.type === 'TEAM') {
        const op = child.operations?.[0] || 'Chưa phân loại'
        ;(groups[op] ??= []).push(child)
      } else {
        others.push(child)
      }
    }

    const sorted = Object.keys(groups)
      .sort((a, b) => a.localeCompare(b))
      .flatMap((op) => [...(groups[op] || [])].sort((a, b) => a.name.localeCompare(b.name, 'vi')))

    treeNode.children = [...others, ...sorted].map((c) => mapUnitToTreeNode(c, treeNode))
  } else {
    treeNode.children = node.children.map((c) => mapUnitToTreeNode(c, treeNode))
  }

  return treeNode
}

type OrgNodeType = 'CORPORATION' | 'COMPANY' | 'FACTORY' | 'TEAM' | 'WAREHOUSE'
type OrgButtonKey = 'add-company' | 'add-factory' | 'add-team' | 'add-warehouse' | 'edit' | 'delete'

export const NODE_CONFIG: Record<
  OrgNodeType,
  { icon: string; color: string; addButtons: OrgButtonKey[]; otherActions: OrgButtonKey[] }
> = {
  CORPORATION: {
    icon: 'i-lucide-building-2',
    color: 'text-primary-600',
    addButtons: ['add-company'],
    otherActions: ['edit', 'delete'],
  },
  COMPANY: {
    icon: 'i-lucide-building',
    color: 'text-blue-600',
    addButtons: ['add-factory', 'add-warehouse'],
    otherActions: ['edit', 'delete'],
  },
  FACTORY: {
    icon: 'i-lucide-factory',
    color: 'text-red-500',
    addButtons: ['add-team'],
    otherActions: ['edit', 'delete'],
  },
  TEAM: {
    icon: 'i-lucide-users',
    color: 'text-amber-500',
    addButtons: [],
    otherActions: ['edit', 'delete'],
  },
  WAREHOUSE: {
    icon: 'i-lucide-warehouse',
    color: 'text-teal-500',
    addButtons: [],
    otherActions: ['edit', 'delete'],
  },
}

export const BUTTON_CONFIG: Record<string, { icon: string; title: string; color: string }> = {
  'add-corporation': { icon: 'i-lucide-circle-plus', title: 'Thêm tổng công ty', color: 'primary' },
  'add-company': { icon: 'i-lucide-circle-plus', title: 'Thêm công ty', color: 'primary' },
  'add-factory': { icon: 'i-lucide-circle-plus', title: 'Thêm xí nghiệp', color: 'primary' },
  'add-team': { icon: 'i-lucide-circle-plus', title: 'Thêm tổ', color: 'primary' },
  'add-warehouse': { icon: 'i-lucide-circle-plus', title: 'Thêm kho', color: 'primary' },
  edit: { icon: 'i-lucide-pencil', title: 'Sửa', color: 'neutral' },
  delete: { icon: 'i-lucide-trash-2', title: 'Xóa', color: 'error' },
}

export const MAX_OPS_SHOWN = 8
