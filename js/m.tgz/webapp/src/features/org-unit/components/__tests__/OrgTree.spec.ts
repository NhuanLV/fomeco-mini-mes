import type { UnitVm } from '@/api'
import * as api from '@/api'
import * as toast from '@/shared/utils/toast'
import { mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import OrgTree from '../OrgTree.vue'

vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({
    hasPermission: () => true,
  }),
}))

vi.mock('@/features/org-unit/composables/useOrgNodeDelete', () => ({
  useOrgNodeDelete: () => ({
    deleteNode: vi.fn(),
  }),
}))

describe('OrgTree', () => {
  const mockTreeData = [
    {
      key: 'corp-1',
      label: 'Tổng công ty May 1',
      data: {
        id: 'corp-1',
        code: 'CORP-01',
        name: 'Tổng công ty May 1',
        type: 'CORPORATION',
        classification: 'INHOUSE',
        isActive: true,
        operations: [],
        children: [
          {
            id: 'comp-1',
            code: 'COMP-01',
            name: 'Công ty May 1',
            type: 'COMPANY',
            isActive: true,
            operations: [],
            children: [],
          },
        ],
      } as UnitVm,
      children: [
        {
          key: 'comp-1',
          label: 'Công ty May 1',
          data: {
            id: 'comp-1',
            code: 'COMP-01',
            name: 'Công ty May 1',
            type: 'COMPANY',
            isActive: true,
            operations: [],
            children: [],
          } as UnitVm,
          children: [],
        },
      ],
    },
  ]

  beforeEach(() => {
    vi.restoreAllMocks()
  })

  it('renders tree table with code and name', () => {
    const wrapper = mount(OrgTree, {
      props: {
        treeData: mockTreeData,
      },
    })

    expect(wrapper.text()).toContain('Tổng công ty May 1')
    expect(wrapper.text()).toContain('CORP-01')
  })

  it('filters tree nodes when searching by code or name', async () => {
    const wrapper = mount(OrgTree, {
      props: {
        treeData: mockTreeData,
      },
    })

    const searchInput = wrapper.find('input')
    await searchInput.setValue('COMP-01')

    expect(wrapper.text()).toContain('Tổng công ty May 1')
  })

  it('warns when adding factory to company with no active operations', async () => {
    vi.spyOn(api, 'getFactoryOperationsByCompany').mockResolvedValue({
      data: [
        {
          id: 'op-1',
          factoryId: 'fact-1',
          factoryCode: 'FACT-01',
          factoryName: 'Xí nghiệp 1',
          operationCode: 'CUT',
          operationName: 'Cắt',
          isActive: false,
        },
      ],
      response: {} as Response,
      request: {} as Request,
      error: undefined,
    } as unknown as Awaited<ReturnType<typeof api.getFactoryOperationsByCompany>>)
    const warnSpy = vi.spyOn(toast, 'showWarn').mockImplementation(() => {})

    const wrapper = mount(OrgTree, {
      props: {
        treeData: mockTreeData,
        expandedKeys: { 'corp-1': true },
      },
    })

    // Find add button or dropdown menu item for company
    const dropdowns = wrapper.findAllComponents({ name: 'DropdownMenu' })
    for (const dd of dropdowns) {
      const items = dd.props('items') as
        | Array<{ label: string; onSelect?: () => Promise<void> }>
        | undefined
      const addFactoryItem = items?.find((item) => item.label === 'Thêm xí nghiệp')
      if (addFactoryItem?.onSelect) {
        await addFactoryItem.onSelect()
        break
      }
    }

    expect(warnSpy).toHaveBeenCalledWith(
      expect.stringContaining('Công ty chưa có công đoạn hoạt động'),
    )
    expect(wrapper.emitted('add-factory')).toBeFalsy()
  })

  it('blocks factory creation when loading company operations fails', async () => {
    vi.spyOn(api, 'getFactoryOperationsByCompany').mockRejectedValue(new Error('Network error'))
    const warnSpy = vi.spyOn(toast, 'showWarn').mockImplementation(() => {})

    const wrapper = mount(OrgTree, {
      props: {
        treeData: mockTreeData,
        expandedKeys: { 'corp-1': true },
      },
    })

    const dropdowns = wrapper.findAllComponents({ name: 'DropdownMenu' })
    for (const dd of dropdowns) {
      const items = dd.props('items') as
        | Array<{ label: string; onSelect?: () => Promise<void> }>
        | undefined
      const addFactoryItem = items?.find((item) => item.label === 'Thêm xí nghiệp')
      if (addFactoryItem?.onSelect) {
        await addFactoryItem.onSelect()
        break
      }
    }

    expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('Không thể tải công đoạn'))
    expect(wrapper.emitted('add-factory')).toBeFalsy()
  })

  it('renders Inhouse badge for corporation with classification INHOUSE', () => {
    const wrapper = mount(OrgTree, {
      props: {
        treeData: mockTreeData,
      },
    })

    const badges = wrapper.findAllComponents({ name: 'Badge' })
    const inhouseBadge = badges.find((b) => b.props('label') === 'Inhouse')
    expect(inhouseBadge).toBeTruthy()
  })
})
