import type { UnitVm } from '@/api'
import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'
import { ref } from 'vue'
import OperationManager from '../OperationManager.vue'

const mockGlobalOperations = ref(['May', 'Cat', 'Ui'])

vi.mock('@/features/org-unit/composables/useOrganization', () => ({
  useOrganization: () => ({
    globalOperations: mockGlobalOperations,
  }),
}))

vi.mock('@pinia/colada', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@pinia/colada')>()),
  useQueryCache: () => ({
    invalidateQueries: vi.fn(),
  }),
}))

describe('OperationManager', () => {
  it('renders operations and reflects checked state correctly', () => {
    const wrapper = mount(OperationManager, {
      props: {
        operations: ['May'],
        existingFactory: null,
      },
    })

    const checkboxes = wrapper.findAllComponents({ name: 'Checkbox' })
    expect(checkboxes).toHaveLength(4)
    // checkboxes[0] is Select All
    expect(checkboxes[0]!.props('modelValue')).toBe('indeterminate')
    // May should be checked
    expect(checkboxes[1]!.props('modelValue')).toBe(true)
    // Cat should not be checked
    expect(checkboxes[2]!.props('modelValue')).toBe(false)
  })

  it('selects all operations when select all is triggered', async () => {
    const wrapper = mount(OperationManager, {
      props: {
        operations: ['May'],
        existingFactory: null,
      },
    })

    const selectAllCheckbox = wrapper.findAllComponents({ name: 'Checkbox' })[0]!
    await selectAllCheckbox.vm.$emit('update:modelValue', true)

    expect(wrapper.emitted('update:operations')).toBeTruthy()
    expect(wrapper.emitted('update:operations')![0]![0]).toEqual(['May', 'Cat', 'Ui'])
  })

  it('toggles individual operation correctly', async () => {
    const wrapper = mount(OperationManager, {
      props: {
        operations: ['May'],
        existingFactory: null,
      },
    })

    const checkboxes = wrapper.findAllComponents({ name: 'Checkbox' })
    // Toggle 'Cat' (index 2) to checked
    await checkboxes[2]!.vm.$emit('update:modelValue', true)

    expect(wrapper.emitted('update:operations')).toBeTruthy()
    expect(wrapper.emitted('update:operations')![0]![0]).toEqual(['May', 'Cat'])
  })

  it('disables operation if it is in use by a team', () => {
    const mockFactory: UnitVm = {
      id: 'fac-1',
      code: 'FAC-1',
      name: 'Xí nghiệp 1',
      type: 'FACTORY',
      isActive: true,
      operations: ['May', 'Cat'],
      children: [
        {
          id: 'team-1',
          code: 'TEAM-1',
          name: 'Tổ 1',
          type: 'TEAM',
          isActive: true,
          operations: ['May'],
          children: [],
        },
      ],
    }

    const wrapper = mount(OperationManager, {
      props: {
        operations: ['May', 'Cat'],
        existingFactory: mockFactory,
      },
    })

    const checkboxes = wrapper.findAllComponents({ name: 'Checkbox' })
    // Index 1 is 'May', which is in use
    expect(checkboxes[1]!.props('disabled')).toBe(true)
    // Index 2 is 'Cat', which is not in use
    expect(checkboxes[2]!.props('disabled')).toBe(false)
  })

  it('renders formatted label code (name) when availableOperations are objects', () => {
    const wrapper = mount(OperationManager, {
      props: {
        operations: ['CUT-1'],
        existingFactory: null,
        availableOperations: [
          { code: 'CUT-1', name: 'Cắt' },
          { code: 'SEW-1', name: 'May' },
        ],
      },
    })

    expect(wrapper.text()).toContain('CUT-1 (Cắt)')
    expect(wrapper.text()).toContain('SEW-1 (May)')

    const checkboxes = wrapper.findAllComponents({ name: 'Checkbox' })
    expect(checkboxes).toHaveLength(3) // Select all + 2 ops
    expect(checkboxes[1]!.props('modelValue')).toBe(true)
    expect(checkboxes[2]!.props('modelValue')).toBe(false)
  })
})
