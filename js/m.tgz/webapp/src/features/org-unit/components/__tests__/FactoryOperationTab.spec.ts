import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'
import { ref } from 'vue'
import FactoryOperationTab from '../FactoryOperationTab.vue'

const mockOperations = ref([
  {
    id: 'op-1',
    factoryId: 'fact-1',
    factoryCode: 'FACT-01',
    factoryName: 'Xí nghiệp 1',
    operationCode: 'CUT-1',
    operationName: 'Cắt 1',
    materialDispatchWarehouseId: 'wh-1',
    materialDispatchWarehouseCode: 'WH-NPL-01',
    btpReceiveWarehouseId: 'wh-2',
    btpReceiveWarehouseCode: 'WH-BTP-01',
    isActive: true,
  },
])

const mockCompanies = ref([
  {
    id: 'comp-1',
    code: 'COMP-01',
    name: 'Công ty May 1',
    type: 'COMPANY',
    isActive: true,
    operations: [],
    children: [
      {
        id: 'fact-1',
        code: 'FACT-01',
        name: 'Xí nghiệp 1',
        type: 'FACTORY',
        isActive: true,
        operations: [],
        children: [],
      },
    ],
  },
])

const mockWarehouses = ref([
  {
    id: 'wh-1',
    code: 'WH-NPL-01',
    name: 'Kho NPL 1',
    siteCode: 'SITE-NPL',
    isActive: true,
  },
  {
    id: 'wh-2',
    code: 'WH-BTP-01',
    name: 'Kho BTP 1',
    siteCode: 'SITE-BTP',
    isActive: true,
  },
])

vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({
    hasPermission: () => true,
  }),
}))

vi.mock('@/features/org-unit/composables/useFactoryOperations', () => ({
  useFactoryOperations: () => ({
    selectedCompanyId: ref(null),
    selectedFactoryId: ref(null),
    searchQuery: ref(''),
    companies: mockCompanies,
    factories: ref([]),
    warehouses: mockWarehouses,
    operations: mockOperations,
    loading: ref(false),
    isMutating: ref(false),
    createMutate: vi.fn(),
    updateMutate: vi.fn(),
    invalidate: vi.fn(),
  }),
}))

describe('FactoryOperationTab', () => {
  it('renders factory operations table with factory, codes, and warehouses', () => {
    const wrapper = mount(FactoryOperationTab)

    expect(wrapper.text()).toContain('Xí nghiệp 1')
    expect(wrapper.text()).toContain('CUT-1')
    expect(wrapper.text()).toContain('Cắt 1')
    expect(wrapper.text()).toContain('WH-NPL-01')
    expect(wrapper.text()).toContain('WH-BTP-01')
    expect(wrapper.text()).toContain('Kho xuất NPL')
    expect(wrapper.text()).toContain('Kho nhập BTP')
    expect(wrapper.text()).not.toContain('Kho xuất BTP')
  })
})
