<script setup lang="ts">
import type { UnitVm } from '@/api'
import { useOrganization } from '@/features/org-unit/composables/useOrganization'
import { computed } from 'vue'

export interface OperationOption {
  code: string
  name?: string
}

interface Props {
  factoryId?: string | null
  operations: string[]
  existingFactory: UnitVm | null
  availableOperations?: (OperationOption | string)[]
}

const props = defineProps<Props>()

const emit = defineEmits<{
  'update:operations': [value: string[]]
}>()

const { globalOperations } = useOrganization()

const opsList = computed<OperationOption[]>(() => {
  const source = props.availableOperations ?? globalOperations.value
  return source.map((item) => {
    if (typeof item === 'string') {
      return { code: item, name: item }
    }
    return item
  })
})

const isOperationInUse = (opCode: string) => {
  if (!props.existingFactory) return false
  return (
    props.existingFactory.children?.some(
      (c) => c.type === 'TEAM' && c.operations?.includes(opCode),
    ) || false
  )
}

const isOpChecked = (opCode: string) => props.operations.includes(opCode)

const isAllSelected = computed(
  () => opsList.value.length > 0 && opsList.value.every((op) => props.operations.includes(op.code)),
)

const isPartialSelected = computed(() => {
  const selectedCount = opsList.value.filter((op) => props.operations.includes(op.code)).length
  return selectedCount > 0 && !isAllSelected.value
})

const toggleAll = (checked: boolean | 'indeterminate') => {
  if (checked === 'indeterminate') return

  if (checked) {
    const all = Array.from(new Set([...props.operations, ...opsList.value.map((op) => op.code)]))
    emit('update:operations', all)
  } else {
    emit(
      'update:operations',
      props.operations.filter((opCode) => isOperationInUse(opCode)),
    )
  }
}

const toggleOp = (opCode: string, checked: boolean | 'indeterminate') => {
  if (checked) {
    if (!props.operations.includes(opCode)) {
      emit('update:operations', [...props.operations, opCode])
    }
  } else {
    if (isOperationInUse(opCode)) return
    emit(
      'update:operations',
      props.operations.filter((item) => item !== opCode),
    )
  }
}

const formatOperationLabel = (op: OperationOption) => {
  if (op.name && op.name !== op.code) {
    return `${op.code} (${op.name})`
  }
  return op.code
}
</script>

<template>
  <div class="flex flex-col gap-2">
    <div class="flex items-center justify-between">
      <label class="text-sm font-medium">Công đoạn khả dụng</label>
      <div class="flex items-center gap-2">
        <span class="rounded-full bg-primary-50 px-2 py-0.5 text-xs font-medium text-primary-600">
          {{ operations.length }} / {{ opsList.length }}
        </span>
      </div>
    </div>

    <!-- Select All -->
    <div
      v-if="opsList.length > 0"
      class="flex cursor-pointer items-center gap-2 rounded-lg border border-surface-200 bg-surface-50 px-3 py-2 select-none"
      @click="toggleAll(!isAllSelected)"
    >
      <UCheckbox
        :model-value="isPartialSelected ? 'indeterminate' : isAllSelected"
        @click.stop
        @update:model-value="toggleAll"
      />
      <span class="text-sm font-medium">Chọn tất cả</span>
    </div>

    <!-- List -->
    <div
      class="flex max-h-48 flex-col gap-1 overflow-y-auto rounded-lg border border-surface-200 p-2"
    >
      <div
        v-for="op in opsList"
        :key="op.code"
        class="flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 transition-colors hover:bg-surface-100/50"
        :class="{ 'cursor-not-allowed opacity-70': isOperationInUse(op.code) }"
        @click="!isOperationInUse(op.code) && toggleOp(op.code, !isOpChecked(op.code))"
      >
        <UCheckbox
          :model-value="isOpChecked(op.code)"
          :disabled="isOperationInUse(op.code)"
          @click.stop
          @update:model-value="toggleOp(op.code, $event)"
        />
        <span class="flex-1 text-sm select-none">{{ formatOperationLabel(op) }}</span>
        <span v-if="isOperationInUse(op.code)" class="text-xs text-toned italic">(Đang có tổ)</span>
      </div>
      <div v-if="opsList.length === 0" class="p-4 text-center text-sm text-toned">
        Chưa có công đoạn nào
      </div>
    </div>
  </div>
</template>
