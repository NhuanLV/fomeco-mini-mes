<script setup lang="ts">
import type { UnitVm } from '@/api'
import { getFactoryOperationsByCompany } from '@/api'
import { useOrgNodeDelete } from '@/features/org-unit/composables/useOrgNodeDelete'
import { useAuthStore } from '@/shared/stores/auth'
import { showWarn } from '@/shared/utils/toast'
import type { DropdownMenuItem, TableColumn } from '@nuxt/ui'
import { computed, ref } from 'vue'
import { BUTTON_CONFIG, MAX_OPS_SHOWN, NODE_CONFIG } from '../core/org'
import type { OrgTreeNode } from '../types'

type OrgNodeType = 'CORPORATION' | 'COMPANY' | 'FACTORY' | 'TEAM' | 'WAREHOUSE'
type OrgButtonKey =
  | 'add-corporation'
  | 'add-company'
  | 'add-factory'
  | 'add-team'
  | 'add-warehouse'
  | 'edit'
  | 'delete'

const props = defineProps<{
  treeData: OrgTreeNode[]
}>()

const expandedKeys = defineModel<Record<string, boolean>>('expandedKeys', { default: () => ({}) })

const { hasPermission } = useAuthStore()
const { deleteNode } = useOrgNodeDelete()
const searchQuery = ref('')

const emit = defineEmits<{
  'add-corporation': []
  'edit-corporation': [corporation: UnitVm]
  'add-company': [parent: UnitVm]
  'edit-company': [company: UnitVm]
  'add-factory': [parent: UnitVm]
  'edit-factory': [factory: UnitVm]
  'add-team': [parent: UnitVm]
  'edit-team': [team: UnitVm, parent: UnitVm]
  'add-warehouse': [parent: UnitVm]
  'edit-warehouse': [warehouse: UnitVm]
}>()

const nodeConfig = (node: OrgTreeNode) => NODE_CONFIG[node.data.type as OrgNodeType]

const handleEdit = (node: OrgTreeNode) => {
  const { type } = node.data
  if (type === 'CORPORATION') emit('edit-corporation', node.data)
  else if (type === 'COMPANY') emit('edit-company', node.data)
  else if (type === 'FACTORY') emit('edit-factory', node.data)
  else if (type === 'TEAM' && node.parent?.data) emit('edit-team', node.data, node.parent.data)
  else if (type === 'WAREHOUSE') emit('edit-warehouse', node.data)
}

const handleButtonClick = async (btn: OrgButtonKey, node: OrgTreeNode) => {
  if (btn === 'add-corporation') emit('add-corporation')
  else if (btn === 'add-company') emit('add-company', node.data)
  else if (btn === 'add-factory') {
    try {
      const { data: ops } = await getFactoryOperationsByCompany({
        path: { companyId: node.data.id },
      })
      const hasActiveOps = (ops ?? []).some((op) => op.isActive)
      if (!hasActiveOps) {
        showWarn(
          'Công ty chưa có công đoạn hoạt động. Vui lòng cấu hình công đoạn tại Tab Cấu hình công đoạn trước khi tạo xí nghiệp.',
        )
        return
      }
    } catch {
      showWarn('Không thể tải công đoạn của công ty. Vui lòng thử lại.')
      return
    }
    emit('add-factory', node.data)
  } else if (btn === 'add-team') emit('add-team', node.data)
  else if (btn === 'add-warehouse') emit('add-warehouse', node.data)
  else if (btn === 'edit') handleEdit(node)
  else if (btn === 'delete') deleteNode(node)
}

const menuItemsFor = (node: OrgTreeNode): DropdownMenuItem[] =>
  nodeConfig(node).addButtons.map((btn) => ({
    label: BUTTON_CONFIG[btn].title,
    icon: BUTTON_CONFIG[btn].icon,
    onSelect: () => handleButtonClick(btn, node),
  }))

const columns: TableColumn<OrgTreeNode>[] = [
  { id: 'name', header: 'Tên' },
  { id: 'code', header: 'Mã đơn vị' },
  { id: 'address', header: 'Địa chỉ' },
  { id: 'operations', header: 'Công đoạn' },
  { id: 'status', header: 'Trạng thái' },
  { id: 'actions', header: 'Thao tác' },
]
const getRowId = (node: OrgTreeNode) => node.key
const getSubRows = (node: OrgTreeNode) => node.children

function filterTreeNode(node: OrgTreeNode, q: string): OrgTreeNode | null {
  const matchSelf =
    node.data.name.toLowerCase().includes(q) ||
    (node.data.code && node.data.code.toLowerCase().includes(q))
  const filteredChildren = node.children
    .map((c) => filterTreeNode(c, q))
    .filter((c): c is OrgTreeNode => c !== null)

  if (matchSelf || filteredChildren.length > 0) {
    return {
      ...node,
      children: filteredChildren,
    }
  }
  return null
}

const filteredTreeData = computed(() => {
  const q = searchQuery.value.trim().toLowerCase()
  if (!q) return props.treeData
  return props.treeData.map((n) => filterTreeNode(n, q)).filter((n): n is OrgTreeNode => n !== null)
})
</script>

<template>
  <div class="flex flex-col gap-3">
    <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
      <UInput
        v-model="searchQuery"
        icon="i-lucide-search"
        placeholder="Tìm kiếm theo Tên hoặc Mã đơn vị..."
        class="w-full sm:w-80"
      />
      <UButton
        v-if="hasPermission('MANAGE_ORG')"
        label="Thêm tổng công ty"
        icon="i-lucide-circle-plus"
        color="primary"
        @click="emit('add-corporation')"
      />
    </div>

    <UTable
      :data="filteredTreeData"
      :columns="columns"
      v-model:expanded="expandedKeys"
      :get-row-id="getRowId"
      :get-sub-rows="getSubRows"
      class="text-xs sm:text-sm"
      :ui="{ tbody: '[&>tr[data-expanded=true]+tr]:hidden' }"
    >
      <template #name-cell="{ row }">
        <div
          class="flex min-w-64 items-center gap-2"
          :style="{ paddingLeft: `${row.depth * 1.25}rem` }"
        >
          <UButton
            v-if="row.getCanExpand()"
            variant="ghost"
            color="neutral"
            size="xs"
            :icon="row.getIsExpanded() ? 'i-lucide-chevron-down' : 'i-lucide-chevron-right'"
            @click="row.toggleExpanded()"
          />
          <span v-else class="inline-block w-8" />
          <UIcon :name="nodeConfig(row.original).icon" :class="nodeConfig(row.original).color" />
          <span class="font-medium">{{ row.original.data.name }}</span>
          <UBadge
            v-if="row.original.data.type === 'CORPORATION' && row.original.data.classification"
            :color="row.original.data.classification === 'OUTSOURCE' ? 'warning' : 'info'"
            :label="row.original.data.classification === 'OUTSOURCE' ? 'Outsource' : 'Inhouse'"
            class="ml-1"
          />
        </div>
      </template>

      <template #code-cell="{ row }">
        <span class="font-mono text-xs font-semibold text-neutral-700 dark:text-neutral-300">
          {{ row.original.data.code }}
        </span>
      </template>

      <template #address-cell="{ row }">
        {{ row.original.data.address }}
      </template>

      <template #operations-cell="{ row }">
        <div v-if="row.original.data.operations?.length" class="flex flex-wrap gap-1">
          <UBadge
            v-for="op in row.original.data.operations.slice(0, MAX_OPS_SHOWN)"
            :key="op"
            :label="op"
            color="info"
          />
          <span v-if="row.original.data.operations.length > MAX_OPS_SHOWN" class="text-xs">
            +{{ row.original.data.operations.length - MAX_OPS_SHOWN }}
          </span>
        </div>
      </template>

      <template #status-cell="{ row }">
        <UBadge
          :color="row.original.data.isActive ? 'success' : 'error'"
          :label="row.original.data.isActive ? 'Active' : 'Inactive'"
        />
      </template>

      <template #actions-cell="{ row }">
        <div v-if="hasPermission('MANAGE_ORG')" class="flex items-center gap-1">
          <UDropdownMenu
            v-if="nodeConfig(row.original).addButtons.length > 1"
            :items="menuItemsFor(row.original)"
          >
            <UButton
              icon="i-lucide-circle-plus"
              color="primary"
              variant="ghost"
              size="sm"
              title="Thêm mới"
              @click.stop
            />
          </UDropdownMenu>
          <template v-else>
            <UButton
              v-for="btn in nodeConfig(row.original).addButtons"
              :key="btn"
              :icon="BUTTON_CONFIG[btn].icon"
              :color="BUTTON_CONFIG[btn].color"
              :title="BUTTON_CONFIG[btn].title"
              variant="ghost"
              size="sm"
              @click.stop="handleButtonClick(btn, row.original)"
            />
          </template>
          <UButton
            v-for="btn in nodeConfig(row.original).otherActions"
            :key="btn"
            :icon="BUTTON_CONFIG[btn].icon"
            :color="BUTTON_CONFIG[btn].color"
            :title="BUTTON_CONFIG[btn].title"
            variant="ghost"
            size="sm"
            @click.stop="handleButtonClick(btn, row.original)"
          />
        </div>
      </template>
    </UTable>
  </div>
</template>
