<script setup lang="ts">
import type { FactoryOperationVm, UnitVm } from '@/api'
import { useFactoryOperations } from '@/features/org-unit/composables/useFactoryOperations'
import { useAuthStore } from '@/shared/stores/auth'
import { showError, showSuccess } from '@/shared/utils/toast'
import type { FormSubmitEvent, TableColumn } from '@nuxt/ui'
import { computed, reactive, ref, watch } from 'vue'
import * as z from 'zod'

const { hasPermission } = useAuthStore()
const {
  selectedCompanyId,
  searchQuery,
  companies,
  factories,
  warehouses,
  operations,
  loading,
  isMutating,
  createMutate,
  updateMutate,
  invalidate,
} = useFactoryOperations()

const page = ref(1)
const pageSize = ref(10)

const paginatedOperations = computed(() => {
  const start = (page.value - 1) * pageSize.value
  return operations.value.slice(start, start + pageSize.value)
})

watch([selectedCompanyId, searchQuery, pageSize], () => {
  page.value = 1
})

const ALL_COMPANIES = '__ALL__'

const companyOptions = computed(() => [
  { label: 'Tất cả công ty', value: ALL_COMPANIES },
  ...companies.value.map((c) => ({
    label: `${c.code} (${c.name})`,
    value: c.id,
  })),
])

const columns: TableColumn<FactoryOperationVm>[] = [
  { id: 'companyCode', accessorKey: 'companyCode', header: 'Mã công ty' },
  { id: 'companyName', accessorKey: 'companyName', header: 'Tên công ty' },
  { id: 'factoryName', accessorKey: 'factoryName', header: 'Xí nghiệp' },
  { id: 'operationCode', accessorKey: 'operationCode', header: 'Mã công đoạn' },
  { id: 'operationName', accessorKey: 'operationName', header: 'Tên công đoạn' },
  {
    id: 'materialDispatchWarehouseCode',
    accessorKey: 'materialDispatchWarehouseCode',
    header: 'Kho xuất NPL',
  },
  { id: 'btpReceiveWarehouseCode', accessorKey: 'btpReceiveWarehouseCode', header: 'Kho nhập BTP' },
  { id: 'status', header: 'Trạng thái' },
  { id: 'actions', header: 'Thao tác' },
]

// ── Modal Create State & Schema ──────────────────────────────
const showCreateModal = ref(false)
const createSchema = z.object({
  companyId: z.string().min(1, 'Vui lòng chọn công ty'),
  factoryId: z.string().min(1, 'Vui lòng chọn xí nghiệp'),
  operationCode: z.string().trim().min(1, 'Vui lòng nhập mã công đoạn'),
  operationName: z.string().trim().min(1, 'Vui lòng nhập tên công đoạn'),
  materialDispatchWarehouseId: z.string().optional(),
  btpReceiveWarehouseId: z.string().optional(),
  isActive: z.boolean().default(true),
})
type CreateSchema = z.output<typeof createSchema>

const createState = reactive<CreateSchema>({
  companyId: '',
  factoryId: '',
  operationCode: '',
  operationName: '',
  materialDispatchWarehouseId: undefined,
  btpReceiveWarehouseId: undefined,
  isActive: true,
})

function openCreate() {
  const defaultCompany =
    selectedCompanyId.value && selectedCompanyId.value !== ALL_COMPANIES
      ? selectedCompanyId.value
      : (companies.value[0]?.id ?? '')
  createState.companyId = defaultCompany
  createState.factoryId = ''
  createState.operationCode = ''
  createState.operationName = ''
  createState.materialDispatchWarehouseId = undefined
  createState.btpReceiveWarehouseId = undefined
  createState.isActive = true
  showCreateModal.value = true
}

async function handleCreate(e: FormSubmitEvent<CreateSchema>) {
  const d = e.data
  try {
    await createMutate({
      body: {
        companyId: d.companyId,
        factoryId: d.factoryId,
        operationCode: d.operationCode,
        operationName: d.operationName,
        materialDispatchWarehouseId: d.materialDispatchWarehouseId || null,
        btpReceiveWarehouseId: d.btpReceiveWarehouseId || null,
        isActive: d.isActive,
      },
    })
    await invalidate()
    showSuccess('Thêm mapping công đoạn thành công')
    showCreateModal.value = false
  } catch (error: unknown) {
    showError((error as { message?: string })?.message ?? 'Không thể thêm mapping công đoạn')
  }
}

// ── Modal Edit State & Schema ────────────────────────────────
const showEditModal = ref(false)
const editingItem = ref<FactoryOperationVm | null>(null)

const editSchema = z.object({
  operationName: z.string().trim().min(1, 'Vui lòng nhập tên công đoạn'),
  materialDispatchWarehouseId: z.string().optional(),
  btpReceiveWarehouseId: z.string().optional(),
  isActive: z.boolean().default(true),
})
type EditSchema = z.output<typeof editSchema>

const editState = reactive<EditSchema>({
  operationName: '',
  materialDispatchWarehouseId: undefined,
  btpReceiveWarehouseId: undefined,
  isActive: true,
})

function openEdit(item: FactoryOperationVm) {
  editingItem.value = item
  editState.operationName = item.operationName
  editState.materialDispatchWarehouseId = item.materialDispatchWarehouseId ?? undefined
  editState.btpReceiveWarehouseId = item.btpReceiveWarehouseId ?? undefined
  editState.isActive = item.isActive
  showEditModal.value = true
}

async function handleEdit(e: FormSubmitEvent<EditSchema>) {
  if (!editingItem.value) return
  const d = e.data
  try {
    await updateMutate({
      path: { id: editingItem.value.id },
      body: {
        operationName: d.operationName,
        materialDispatchWarehouseId: d.materialDispatchWarehouseId || null,
        btpReceiveWarehouseId: d.btpReceiveWarehouseId || null,
        isActive: d.isActive,
      },
    })
    await invalidate()
    showSuccess('Cập nhật mapping công đoạn thành công')
    showEditModal.value = false
  } catch (error: unknown) {
    showError((error as { message?: string })?.message ?? 'Không thể cập nhật mapping công đoạn')
  }
}

const createFactoryOptions = computed(() =>
  factories.value
    .filter((factory) => factory.companyId === createState.companyId)
    .map((factory) => ({ label: `${factory.code} (${factory.name})`, value: factory.id })),
)

const formatWarehouseOption = (w: UnitVm) => {
  const label = w.siteCode ? `${w.code} (${w.siteCode})` : w.code
  return {
    label,
    value: w.id,
    disabled: !w.isActive,
  }
}

const warehouseOptions = computed(() => warehouses.value.map(formatWarehouseOption))

watch(
  () => createState.companyId,
  () => {
    if (!createFactoryOptions.value.some((item) => item.value === createState.factoryId)) {
      createState.factoryId = ''
    }
  },
)
</script>

<template>
  <div class="flex flex-col gap-4">
    <!-- Toolbar -->
    <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div class="flex flex-col gap-2 sm:flex-row sm:items-center">
        <USelect
          v-model="selectedCompanyId"
          :items="companyOptions"
          label-key="label"
          value-key="value"
          placeholder="Chọn công ty..."
          class="w-full sm:w-64"
        />
        <UInput
          v-model="searchQuery"
          icon="i-lucide-search"
          placeholder="Tìm theo mã/tên công đoạn..."
          class="w-full sm:w-64"
        />
      </div>
      <UButton
        v-if="hasPermission('MANAGE_ORG')"
        label="Thêm mapping"
        icon="i-lucide-circle-plus"
        color="primary"
        @click="openCreate"
      />
    </div>

    <!-- Operations Table -->
    <UTable
      :data="paginatedOperations"
      :columns="columns"
      :loading="loading"
      class="text-xs sm:text-sm"
    >
      <template #companyCode-cell="{ row }">
        <span class="font-mono font-medium">{{ row.original.companyCode }}</span>
      </template>

      <template #companyName-cell="{ row }">
        {{ row.original.companyName }}
      </template>

      <template #factoryName-cell="{ row }">
        {{ row.original.factoryName }}
      </template>

      <template #operationCode-cell="{ row }">
        <span class="font-mono font-semibold text-primary-700 dark:text-primary-400">
          {{ row.original.operationCode }}
        </span>
      </template>

      <template #operationName-cell="{ row }">
        {{ row.original.operationName }}
      </template>

      <template #materialDispatchWarehouseCode-cell="{ row }">
        <span class="font-mono text-xs">{{
          row.original.materialDispatchWarehouseCode || '-'
        }}</span>
      </template>

      <template #btpReceiveWarehouseCode-cell="{ row }">
        <span class="font-mono text-xs">{{ row.original.btpReceiveWarehouseCode || '-' }}</span>
      </template>

      <template #status-cell="{ row }">
        <UBadge
          :color="row.original.isActive ? 'success' : 'error'"
          :label="row.original.isActive ? 'Active' : 'Inactive'"
        />
      </template>

      <template #actions-cell="{ row }">
        <div v-if="hasPermission('MANAGE_ORG')" class="flex items-center gap-1">
          <UButton
            icon="i-lucide-pencil"
            color="neutral"
            variant="ghost"
            size="sm"
            title="Sửa mapping"
            @click="openEdit(row.original)"
          />
        </div>
      </template>

      <template #empty> Không có dữ liệu. </template>
    </UTable>

    <!-- Pagination -->
    <div
      v-if="operations.length > 0"
      class="flex flex-col items-center justify-between gap-3 border-t border-default px-3 py-3 sm:flex-row"
    >
      <span class="text-xs text-toned">
        Hiển thị {{ (page - 1) * pageSize + 1 }} -
        {{ Math.min(page * pageSize, operations.length) }} trong tổng số {{ operations.length }} mục
      </span>
      <div class="flex items-center gap-3">
        <UPagination v-model:page="page" :total="operations.length" :items-per-page="pageSize" />
        <USelect
          v-model="pageSize"
          :items="[10, 20, 50, 100]"
          class="w-20"
          aria-label="Số dòng mỗi trang"
        />
      </div>
    </div>

    <!-- Create Modal -->
    <UModal
      v-model:open="showCreateModal"
      :close="{ onClick: () => (showCreateModal = false) }"
      title="Thêm mapping công đoạn"
    >
      <template #body>
        <UForm
          id="create-op-form"
          :schema="createSchema"
          :state="createState"
          :validate-on="[]"
          class="flex flex-col gap-4"
          @submit="handleCreate"
        >
          <UFormField label="Công ty" name="companyId" required>
            <USelect
              v-model="createState.companyId"
              :items="companies.map((c) => ({ label: `${c.code} (${c.name})`, value: c.id }))"
              label-key="label"
              value-key="value"
              placeholder="Chọn công ty..."
              class="w-full"
            />
          </UFormField>

          <UFormField label="Xí nghiệp" name="factoryId" required>
            <USelect
              v-model="createState.factoryId"
              :items="createFactoryOptions"
              label-key="label"
              value-key="value"
              placeholder="Chọn xí nghiệp..."
              class="w-full"
            />
          </UFormField>

          <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <UFormField label="Mã công đoạn" name="operationCode" required>
              <UInput v-model="createState.operationCode" class="w-full" />
            </UFormField>
            <UFormField label="Tên công đoạn" name="operationName" required>
              <UInput v-model="createState.operationName" class="w-full" />
            </UFormField>
          </div>

          <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <UFormField label="Kho xuất NPL" name="materialDispatchWarehouseId">
              <USelectMenu
                v-model="createState.materialDispatchWarehouseId"
                :items="warehouseOptions"
                label-key="label"
                value-key="value"
                class="w-full"
              />
            </UFormField>
            <UFormField label="Kho nhập BTP" name="btpReceiveWarehouseId">
              <USelectMenu
                v-model="createState.btpReceiveWarehouseId"
                :items="warehouseOptions"
                label-key="label"
                value-key="value"
                class="w-full"
              />
            </UFormField>
          </div>

          <div class="flex flex-col gap-2">
            <label class="text-sm font-medium">Trạng thái</label>
            <URadioGroup
              v-model="createState.isActive"
              name="isActive"
              orientation="horizontal"
              :items="[
                { label: 'Hoạt động', value: true },
                { label: 'Tạm dừng', value: false },
              ]"
            />
          </div>
        </UForm>
      </template>

      <template #footer>
        <div class="flex w-full justify-end gap-2">
          <UButton
            label="Hủy"
            icon="i-lucide-x"
            color="neutral"
            variant="ghost"
            type="button"
            @click="showCreateModal = false"
          />
          <UButton
            label="Lưu"
            icon="i-lucide-check"
            type="submit"
            form="create-op-form"
            :loading="isMutating"
          />
        </div>
      </template>
    </UModal>

    <!-- Edit Modal -->
    <UModal
      v-model:open="showEditModal"
      :close="{ onClick: () => (showEditModal = false) }"
      title="Sửa mapping công đoạn"
    >
      <template #body>
        <UForm
          v-if="editingItem"
          id="edit-op-form"
          :schema="editSchema"
          :state="editState"
          :validate-on="[]"
          class="flex flex-col gap-4"
          @submit="handleEdit"
        >
          <UFormField label="Công ty">
            <UInput
              :model-value="`${editingItem.companyCode} (${editingItem.companyName})`"
              disabled
              variant="subtle"
              color="neutral"
              class="w-full font-medium"
            />
          </UFormField>

          <UFormField label="Xí nghiệp">
            <UInput
              :model-value="`${editingItem.factoryCode} (${editingItem.factoryName})`"
              disabled
              variant="subtle"
              color="neutral"
              class="w-full font-medium"
            />
          </UFormField>

          <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <UFormField label="Mã công đoạn">
              <UInput
                :model-value="editingItem.operationCode"
                disabled
                variant="subtle"
                color="neutral"
                class="w-full font-mono font-medium"
              />
            </UFormField>
            <UFormField label="Tên công đoạn" name="operationName" required>
              <UInput v-model="editState.operationName" class="w-full" />
            </UFormField>
          </div>

          <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <UFormField label="Kho xuất NPL" name="materialDispatchWarehouseId">
              <USelectMenu
                v-model="editState.materialDispatchWarehouseId"
                :items="warehouseOptions"
                label-key="label"
                value-key="value"
                class="w-full"
              />
            </UFormField>
            <UFormField label="Kho nhập BTP" name="btpReceiveWarehouseId">
              <USelectMenu
                v-model="editState.btpReceiveWarehouseId"
                :items="warehouseOptions"
                label-key="label"
                value-key="value"
                class="w-full"
              />
            </UFormField>
          </div>

          <div class="flex flex-col gap-2">
            <label class="text-sm font-medium">Trạng thái</label>
            <URadioGroup
              v-model="editState.isActive"
              name="isActive"
              orientation="horizontal"
              :items="[
                { label: 'Hoạt động', value: true },
                { label: 'Tạm dừng', value: false },
              ]"
            />
          </div>
        </UForm>
      </template>

      <template #footer>
        <div class="flex w-full justify-end gap-2">
          <UButton
            label="Hủy"
            icon="i-lucide-x"
            color="neutral"
            variant="ghost"
            type="button"
            @click="showEditModal = false"
          />
          <UButton
            label="Lưu"
            icon="i-lucide-check"
            type="submit"
            form="edit-op-form"
            :loading="isMutating"
          />
        </div>
      </template>
    </UModal>
  </div>
</template>
