<script setup lang="ts">
import { createCorporationMutation, updateCorporationMutation } from '@/api/@pinia/colada.gen'
import OrgFormShell from '@/features/org-unit/components/OrgFormShell.vue'
import { useOrganization } from '@/features/org-unit/composables/useOrganization'
import { useOrgForm } from '@/features/org-unit/composables/useOrgForm'
import type { FormSubmitEvent } from '@nuxt/ui'
import { useMutation } from '@pinia/colada'
import { computed, reactive, watch } from 'vue'
import * as z from 'zod'

const props = defineProps<{
  visible: boolean
  corporationId?: string | null
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
  saved: []
}>()

const { treeData, findNode } = useOrganization()
const { isVisible, isEditing, save, cancel } = useOrgForm(props, emit, () => props.corporationId)

const schema = z.object({
  name: z.string().trim().min(1, 'Vui lòng nhập tên tổng công ty'),
  code: z.string().trim().min(1, 'Vui lòng nhập mã đơn vị'),
  classification: z.enum(['INHOUSE', 'OUTSOURCE']),
  address: z.string().trim().default(''),
  isActive: z.boolean().default(true),
})
type Schema = z.output<typeof schema>

const initialValues = computed<Schema>(() => {
  if (props.corporationId) {
    const node = findNode(treeData.value, props.corporationId)
    if (node) {
      return {
        name: node.data.name,
        code: node.data.code,
        classification: (node.data.classification as 'INHOUSE' | 'OUTSOURCE') || 'INHOUSE',
        address: node.data.address ?? '',
        isActive: node.data.isActive,
      }
    }
  }
  return {
    name: '',
    code: '',
    classification: 'INHOUSE',
    address: '',
    isActive: true,
  }
})

const state = reactive<Schema>({ ...initialValues.value })
watch(initialValues, (values) => Object.assign(state, values), { immediate: true })

const { mutateAsync: createMutate, isLoading: isCreating } = useMutation(
  createCorporationMutation(),
)
const { mutateAsync: updateMutate, isLoading: isUpdating } = useMutation(
  updateCorporationMutation(),
)
const loading = computed(() => isCreating.value || isUpdating.value)

const handleSubmit = async (e: FormSubmitEvent<Schema>) => {
  const editing = isEditing.value
  const { name, code, classification, address, isActive } = e.data

  const result = await save(
    async () => {
      if (editing) {
        await updateMutate({
          path: { id: props.corporationId! },
          body: {
            name,
            code,
            classification,
            address: address || null,
            isActive,
          },
        })
      } else {
        await createMutate({
          body: {
            name,
            code,
            classification,
            address: address || null,
            isActive,
          },
        })
      }
    },
    editing ? 'Đã cập nhật tổng công ty' : 'Đã tạo tổng công ty',
  )
  if (result) emit('saved')
}
</script>

<template>
  <OrgFormShell
    v-model:visible="isVisible"
    :title="isEditing ? 'Sửa tổng công ty' : 'Thêm tổng công ty'"
  >
    <UForm
      id="corporation-form"
      :schema="schema"
      :state="state"
      :validate-on="[]"
      class="flex flex-col gap-4"
      @submit="handleSubmit"
    >
      <div v-if="isEditing" class="flex flex-col gap-2">
        <label class="text-sm font-medium">Trạng thái</label>
        <URadioGroup
          v-model="state.isActive"
          name="isActive"
          orientation="horizontal"
          :items="[
            { label: 'Hoạt động', value: true },
            { label: 'Tạm dừng', value: false },
          ]"
        />
      </div>

      <div class="flex flex-col gap-2">
        <label class="text-sm font-medium">Phân loại</label>
        <URadioGroup
          v-model="state.classification"
          name="classification"
          orientation="horizontal"
          :items="[
            { label: 'Inhouse (Nội bộ LGG)', value: 'INHOUSE' },
            { label: 'Outsource (Đối tác)', value: 'OUTSOURCE' },
          ]"
        />
      </div>

      <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <UFormField label="Mã đơn vị" name="code" required>
          <UInput v-model="state.code" class="w-full" />
        </UFormField>
        <UFormField label="Tên tổng công ty" name="name" required>
          <UInput v-model="state.name" class="w-full" />
        </UFormField>
      </div>

      <UFormField label="Địa chỉ" name="address">
        <UInput v-model="state.address" class="w-full" />
      </UFormField>
    </UForm>

    <template #footer>
      <div class="flex w-full justify-end gap-2">
        <UButton
          label="Hủy"
          icon="i-lucide-x"
          color="neutral"
          variant="ghost"
          type="button"
          @click="cancel"
        />
        <UButton
          label="Lưu"
          icon="i-lucide-check"
          type="submit"
          form="corporation-form"
          :loading="loading"
        />
      </div>
    </template>
  </OrgFormShell>
</template>
