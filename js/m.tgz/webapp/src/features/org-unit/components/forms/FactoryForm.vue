<script setup lang="ts">
import type { UnitVm } from '@/api'
import { createFactoryMutation, updateFactoryMutation } from '@/api/@pinia/colada.gen'
import OrgFormShell from '@/features/org-unit/components/OrgFormShell.vue'
import { useOrganization } from '@/features/org-unit/composables/useOrganization'
import { useOrgForm } from '@/features/org-unit/composables/useOrgForm'
import type { FormSubmitEvent } from '@nuxt/ui'
import { useMutation } from '@pinia/colada'
import { computed, reactive, watch } from 'vue'
import * as z from 'zod'

const props = defineProps<{
  visible: boolean
  factoryId?: string | null
  parentCompany: UnitVm | null
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
  saved: []
}>()

const { treeData, findNode } = useOrganization()
const { isVisible, isEditing, save, cancel } = useOrgForm(props, emit, () => props.factoryId)

const parentCompanyId = computed(() => {
  if (props.parentCompany?.id) return props.parentCompany.id
  if (props.factoryId) {
    return findNode(treeData.value, props.factoryId)?.parent?.data?.id
  }
  return null
})

const resolvedParentCompany = computed(() => {
  if (props.parentCompany) return props.parentCompany
  if (props.factoryId) {
    return findNode(treeData.value, props.factoryId)?.parent?.data ?? null
  }
  return null
})

const schema = z.object({
  name: z.string().trim().min(1, 'Vui lòng nhập tên xí nghiệp'),
  code: z.string().trim().min(1, 'Vui lòng nhập mã đơn vị'),
  address: z.string().trim().default(''),
  isActive: z.boolean().default(true),
})
type Schema = z.output<typeof schema>

const initialValues = computed<Schema>(() => {
  if (props.factoryId) {
    const node = findNode(treeData.value, props.factoryId)
    if (node)
      return {
        name: node.data.name,
        code: node.data.code,
        address: node.data.address ?? '',
        isActive: node.data.isActive,
      }
  }
  return { name: '', code: '', address: '', isActive: true }
})
const state = reactive<Schema>({ ...initialValues.value })
watch(initialValues, (values) => Object.assign(state, values), { immediate: true })

const { mutateAsync: createMutate, isLoading: isCreating } = useMutation(createFactoryMutation())
const { mutateAsync: updateMutate, isLoading: isUpdating } = useMutation(updateFactoryMutation())
const loading = computed(() => isCreating.value || isUpdating.value)

const handleSubmit = async (e: FormSubmitEvent<Schema>) => {
  const vals = e.data
  const editing = isEditing.value
  const result = await save(
    async () => {
      if (editing) {
        await updateMutate({
          path: { id: props.factoryId! },
          body: {
            name: vals.name,
            code: vals.code,
            address: vals.address || null,
            isActive: vals.isActive,
          },
        })
      } else {
        await createMutate({
          body: {
            name: vals.name,
            code: vals.code,
            address: vals.address || null,
            isActive: vals.isActive,
            companyId: parentCompanyId.value!,
          },
        })
      }
    },
    editing ? 'Cập nhật xí nghiệp thành công' : 'Thêm xí nghiệp thành công',
  )
  if (result) emit('saved')
}
</script>

<template>
  <OrgFormShell v-model:visible="isVisible" :title="isEditing ? 'Sửa xí nghiệp' : 'Thêm xí nghiệp'">
    <template #description>
      <div v-if="resolvedParentCompany" class="mb-1 text-sm text-toned">
        Thuộc Công ty:
        <span class="font-medium text-highlighted">{{ resolvedParentCompany.name }}</span>
      </div>
    </template>

    <UForm
      id="factory-form"
      :schema="schema"
      :state="state"
      :validate-on="[]"
      class="flex flex-col gap-4"
      @submit="handleSubmit"
    >
      <div v-if="isEditing" class="flex flex-col gap-2">
        <label class="text-sm font-medium">Trạng thái</label>
        <URadioGroup
          v-model="state.isActive"
          name="isActive"
          orientation="horizontal"
          :items="[
            { label: 'Hoạt động', value: true },
            { label: 'Tạm dừng', value: false },
          ]"
        />
      </div>
      <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <UFormField label="Mã đơn vị" name="code" required>
          <UInput v-model="state.code" class="w-full" />
        </UFormField>
        <UFormField label="Tên xí nghiệp" name="name" required>
          <UInput v-model="state.name" class="w-full" />
        </UFormField>
      </div>
      <UFormField label="Địa chỉ" name="address">
        <UInput v-model="state.address" class="w-full" />
      </UFormField>
    </UForm>

    <template #footer>
      <div class="flex w-full justify-end gap-2">
        <UButton
          label="Hủy"
          icon="i-lucide-x"
          color="neutral"
          variant="ghost"
          type="button"
          @click="cancel"
        />
        <UButton
          label="Lưu"
          icon="i-lucide-check"
          type="submit"
          form="factory-form"
          :loading="loading"
        />
      </div>
    </template>
  </OrgFormShell>
</template>
