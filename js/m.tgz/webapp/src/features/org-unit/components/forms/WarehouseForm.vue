<script setup lang="ts">
import type { UnitVm } from '@/api'
import { createWarehouseMutation, updateWarehouseMutation } from '@/api/@pinia/colada.gen'
import OrgFormShell from '@/features/org-unit/components/OrgFormShell.vue'
import { useOrganization } from '@/features/org-unit/composables/useOrganization'
import { useOrgForm } from '@/features/org-unit/composables/useOrgForm'
import type { FormSubmitEvent } from '@nuxt/ui'
import { useMutation } from '@pinia/colada'
import { computed, reactive, watch } from 'vue'
import * as z from 'zod'

const props = defineProps<{
  visible: boolean
  warehouseId?: string | null
  parentCompany: UnitVm | null
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
  saved: []
}>()

const { treeData, findNode } = useOrganization()
const { isVisible, isEditing, save, cancel } = useOrgForm(props, emit, () => props.warehouseId)

const resolvedParentCompany = computed(() => {
  if (props.parentCompany) return props.parentCompany
  if (props.warehouseId) {
    return findNode(treeData.value, props.warehouseId)?.parent?.data ?? null
  }
  return null
})

const schema = z.object({
  name: z.string().trim().min(1, 'Vui lòng nhập tên kho'),
  code: z.string().trim().min(1, 'Vui lòng nhập mã đơn vị'),
  address: z.string().trim().default(''),
  siteName: z.string().trim().default(''),
  siteCode: z.string().trim().default(''),
  isActive: z.boolean().default(true),
})
type Schema = z.output<typeof schema>

const initialValues = computed<Schema>(() => {
  if (props.warehouseId) {
    const node = findNode(treeData.value, props.warehouseId)
    if (node)
      return {
        name: node.data.name,
        code: node.data.code,
        address: node.data.address ?? '',
        siteName: node.data.siteName ?? '',
        siteCode: node.data.siteCode ?? '',
        isActive: node.data.isActive,
      }
  }
  return { name: '', code: '', address: '', siteName: '', siteCode: '', isActive: true }
})
const state = reactive<Schema>(initialValues.value)
watch(initialValues, (values) => Object.assign(state, values), { immediate: true })

const { mutateAsync: createMutate, isLoading: isCreating } = useMutation(createWarehouseMutation())
const { mutateAsync: updateMutate, isLoading: isUpdating } = useMutation(updateWarehouseMutation())
const loading = computed(() => isCreating.value || isUpdating.value)

const handleSubmit = async (e: FormSubmitEvent<Schema>) => {
  const vals = e.data
  const editing = isEditing.value
  const result = await save(
    async () => {
      if (editing) {
        await updateMutate({
          path: { id: props.warehouseId! },
          body: {
            name: vals.name,
            code: vals.code,
            address: vals.address || null,
            isActive: vals.isActive,
            siteName: vals.siteName || null,
            siteCode: vals.siteCode || null,
          },
        })
      } else {
        await createMutate({
          body: {
            name: vals.name,
            code: vals.code,
            address: vals.address || null,
            isActive: vals.isActive,
            siteName: vals.siteName || null,
            siteCode: vals.siteCode || null,
            companyId: resolvedParentCompany.value!.id,
          },
        })
      }
    },
    editing ? 'Cập nhật kho thành công' : 'Thêm kho thành công',
  )
  if (result) emit('saved')
}
</script>

<template>
  <OrgFormShell v-model:visible="isVisible" :title="isEditing ? 'Sửa kho' : 'Thêm kho'">
    <template #description>
      <div v-if="resolvedParentCompany" class="mb-1 text-sm text-toned">
        Thuộc Công ty:
        <span class="font-medium text-highlighted">{{ resolvedParentCompany.name }}</span>
      </div>
    </template>

    <UForm
      id="warehouse-form"
      :schema="schema"
      :state="state"
      :validate-on="[]"
      class="flex flex-col gap-4"
      @submit="handleSubmit"
    >
      <div v-if="isEditing" class="flex flex-col gap-2">
        <label class="text-sm font-medium">Trạng thái</label>
        <URadioGroup
          v-model="state.isActive"
          name="isActive"
          orientation="horizontal"
          :items="[
            { label: 'Hoạt động', value: true },
            { label: 'Tạm dừng', value: false },
          ]"
        />
      </div>
      <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <UFormField label="Mã đơn vị" name="code" required>
          <UInput v-model="state.code" class="w-full" />
        </UFormField>
        <UFormField label="Tên kho" name="name" required>
          <UInput v-model="state.name" class="w-full" />
        </UFormField>
      </div>
      <UFormField label="Địa chỉ" name="address">
        <UInput v-model="state.address" class="w-full" />
      </UFormField>
      <fieldset class="flex flex-col gap-4 rounded-md border border-default p-4">
        <legend class="px-1 text-sm font-medium">Thông tin WFX</legend>
        <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <UFormField label="Site Name" name="siteName">
            <UInput v-model="state.siteName" class="w-full" />
          </UFormField>
          <UFormField label="Site Code" name="siteCode">
            <UInput v-model="state.siteCode" class="w-full" />
          </UFormField>
        </div>
        <p class="flex items-start gap-1 text-xs font-medium text-amber-600 dark:text-amber-400">
          <UIcon name="i-lucide-info" class="mt-0.5 size-3.5 shrink-0" />
          <span>Khai báo giống với cấu trúc trên WFX để bắn API</span>
        </p>
      </fieldset>
    </UForm>

    <template #footer>
      <div class="flex w-full justify-end gap-2">
        <UButton
          label="Hủy"
          icon="i-lucide-x"
          color="neutral"
          variant="ghost"
          type="button"
          @click="cancel"
        />
        <UButton
          label="Lưu"
          icon="i-lucide-check"
          type="submit"
          form="warehouse-form"
          :loading="loading"
        />
      </div>
    </template>
  </OrgFormShell>
</template>
