<script setup lang="ts">
import type { UnitVm } from '@/api'
import {
  createTeamMutation,
  getFactoryOperationsByFactoryQuery,
  updateTeamMutation,
} from '@/api/@pinia/colada.gen'
import OrgFormShell from '@/features/org-unit/components/OrgFormShell.vue'
import { useOrganization } from '@/features/org-unit/composables/useOrganization'
import { useOrgForm } from '@/features/org-unit/composables/useOrgForm'
import type { FormSubmitEvent } from '@nuxt/ui'
import { useMutation, useQuery } from '@pinia/colada'
import { computed, reactive, watch } from 'vue'
import * as z from 'zod'

const props = defineProps<{
  visible: boolean
  teamId?: string | null
  parentFactory: UnitVm | null
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
  saved: []
}>()

const { treeData, findNode } = useOrganization()
const { isVisible, isEditing, save, cancel } = useOrgForm(props, emit, () => props.teamId)

const resolvedParentFactory = computed(() => {
  if (props.parentFactory) return props.parentFactory
  if (props.teamId) {
    return findNode(treeData.value, props.teamId)?.parent?.data ?? null
  }
  return null
})

const parentCompanyName = computed(() => {
  if (!resolvedParentFactory.value?.id) return ''
  return findNode(treeData.value, resolvedParentFactory.value.id)?.parent?.data?.name ?? ''
})

const { data: factoryOpsData } = useQuery(() => ({
  ...getFactoryOperationsByFactoryQuery({
    path: { factoryId: resolvedParentFactory.value?.id ?? '' },
  }),
  enabled: !!resolvedParentFactory.value?.id,
}))

const schema = z.object({
  name: z.string().trim().min(1, 'Vui lòng nhập tên tổ'),
  code: z.string().trim().min(1, 'Vui lòng nhập mã đơn vị'),
  operationId: z.string().trim().min(1, 'Vui lòng chọn công đoạn'),
  isActive: z.boolean().default(true),
})
type Schema = z.output<typeof schema>

const initialValues = computed<Schema>(() => {
  if (props.teamId) {
    const node = findNode(treeData.value, props.teamId)
    if (node)
      return {
        name: node.data.name,
        code: node.data.code,
        operationId: node.data.operations?.[0] ?? '',
        isActive: node.data.isActive,
      }
  }
  return { name: '', code: '', operationId: '', isActive: true }
})
const state = reactive<Schema>({ ...initialValues.value })
watch(initialValues, (values) => Object.assign(state, values), { immediate: true })

const availableOperations = computed(() => {
  const currentOperation = props.teamId
    ? findNode(treeData.value, props.teamId)?.data.operations?.[0]
    : undefined
  return (factoryOpsData.value ?? [])
    .filter((op) => op.isActive || op.operationCode === currentOperation)
    .map((op) => ({
      label:
        op.operationName !== op.operationCode
          ? `${op.operationCode} (${op.operationName})`
          : op.operationCode,
      value: op.operationCode,
      disabled: !op.isActive,
    }))
})

const { mutateAsync: createMutate, isLoading: isCreating } = useMutation(createTeamMutation())
const { mutateAsync: updateMutate, isLoading: isUpdating } = useMutation(updateTeamMutation())
const loading = computed(() => isCreating.value || isUpdating.value)

const handleSubmit = async (e: FormSubmitEvent<Schema>) => {
  const vals = e.data
  const editing = isEditing.value
  const result = await save(
    async () => {
      if (editing) {
        await updateMutate({
          path: { id: props.teamId! },
          body: {
            name: vals.name,
            code: vals.code,
            operation: vals.operationId,
            isActive: vals.isActive,
          },
        })
      } else {
        await createMutate({
          body: {
            name: vals.name,
            code: vals.code,
            operation: vals.operationId,
            isActive: vals.isActive,
            factoryId: resolvedParentFactory.value!.id,
          },
        })
      }
    },
    editing ? 'Cập nhật tổ thành công' : 'Thêm tổ thành công',
  )
  if (result) emit('saved')
}
</script>

<template>
  <OrgFormShell
    v-model:visible="isVisible"
    :title="isEditing ? 'Cập nhật thông tin tổ' : 'Thêm tổ'"
  >
    <template #description>
      <div v-if="resolvedParentFactory" class="mb-1 text-sm text-toned">
        Thuộc: <span class="font-medium text-highlighted">{{ resolvedParentFactory.name }}</span>
        <span v-if="parentCompanyName">
          - <span class="font-medium text-highlighted">{{ parentCompanyName }}</span></span
        >
      </div>
    </template>

    <UForm
      id="team-form"
      :schema="schema"
      :state="state"
      :validate-on="[]"
      class="flex flex-col gap-4"
      @submit="handleSubmit"
    >
      <div v-if="isEditing" class="flex flex-col gap-2">
        <label class="text-sm font-medium">Trạng thái</label>
        <URadioGroup
          v-model="state.isActive"
          name="isActive"
          orientation="horizontal"
          :items="[
            { label: 'Hoạt động', value: true },
            { label: 'Tạm dừng', value: false },
          ]"
        />
      </div>
      <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <UFormField label="Mã đơn vị" name="code" required>
          <UInput v-model="state.code" class="w-full" />
        </UFormField>
        <UFormField label="Tên tổ" name="name" required>
          <UInput v-model="state.name" class="w-full" />
        </UFormField>
      </div>
      <UFormField label="Công đoạn" name="operationId" required>
        <USelect
          v-model="state.operationId"
          name="operationId"
          :items="availableOperations"
          label-key="label"
          value-key="value"
          placeholder="Chọn công đoạn"
          empty-message="Xí nghiệp chưa có công đoạn"
          class="w-full"
        />
      </UFormField>
    </UForm>

    <template #footer>
      <div class="flex w-full justify-end gap-2">
        <UButton
          label="Hủy"
          icon="i-lucide-x"
          color="neutral"
          variant="ghost"
          type="button"
          @click="cancel"
        />
        <UButton
          label="Lưu"
          icon="i-lucide-check"
          type="submit"
          form="team-form"
          :loading="loading"
        />
      </div>
    </template>
  </OrgFormShell>
</template>
