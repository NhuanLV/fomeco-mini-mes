<script setup lang="ts">
import type { UnitVm } from '@/api'
import {
  createCompanyMutation,
  getSuppliersQuery,
  getSuppliersQueryKey,
  syncMutation,
  updateCompanyMutation,
} from '@/api/@pinia/colada.gen'
import OrgFormShell from '@/features/org-unit/components/OrgFormShell.vue'
import { useOrganization } from '@/features/org-unit/composables/useOrganization'
import { useOrgForm } from '@/features/org-unit/composables/useOrgForm'
import { showError, showSuccess } from '@/shared/utils/toast'
import type { FormSubmitEvent } from '@nuxt/ui'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import { computed, reactive, watch } from 'vue'
import * as z from 'zod'

const props = defineProps<{
  visible: boolean
  companyId?: string | null
  parentCorporation: UnitVm | null
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
  saved: []
}>()

const { treeData, findNode } = useOrganization()
const { isVisible, isEditing, save, cancel } = useOrgForm(props, emit, () => props.companyId)
const queryCache = useQueryCache()

const isOutsource = computed(() => props.parentCorporation?.classification === 'OUTSOURCE')

const { data: rawSuppliers, isPending: suppliersPending } = useQuery(getSuppliersQuery())
const { mutateAsync: syncMutate, isLoading: isSyncing } = useMutation(syncMutation())

const supplierOptions = computed(() =>
  (rawSuppliers.value ?? []).map((s) => ({ label: s, value: s })),
)

const schema = z.object({
  name: z.string().trim().min(1, 'Vui lòng nhập tên công ty'),
  code: z.string().trim().min(1, 'Vui lòng nhập mã đơn vị'),
  address: z.string().trim().default(''),
  wfxSupplierName: z.string().nullable().default(null),
  isActive: z.boolean().default(true),
})
type Schema = z.output<typeof schema>

const initialValues = computed<Schema>(() => {
  if (props.companyId) {
    const node = findNode(treeData.value, props.companyId)
    if (node) {
      return {
        name: node.data.name,
        code: node.data.code,
        address: node.data.address ?? '',
        wfxSupplierName: node.data.wfxSupplierName ?? null,
        isActive: node.data.isActive,
      }
    }
  }
  return {
    name: '',
    code: '',
    address: '',
    wfxSupplierName: null,
    isActive: true,
  }
})

const state = reactive<Schema>({ ...initialValues.value })
watch(initialValues, (values) => Object.assign(state, values), { immediate: true })

const { mutateAsync: createMutate, isLoading: isCreating } = useMutation(createCompanyMutation())
const { mutateAsync: updateMutate, isLoading: isUpdating } = useMutation(updateCompanyMutation())
const loading = computed(() => isCreating.value || isUpdating.value)

async function handleSyncSuppliers() {
  try {
    await syncMutate({})
    await queryCache.invalidateQueries({ key: getSuppliersQueryKey() })
    showSuccess('Đã đồng bộ nhà cung cấp WFX')
  } catch {
    showError('Không thể đồng bộ nhà cung cấp WFX')
  }
}

const handleSubmit = async (e: FormSubmitEvent<Schema>) => {
  const editing = isEditing.value
  const { name, code, address, wfxSupplierName, isActive } = e.data

  const result = await save(
    async () => {
      if (editing) {
        await updateMutate({
          path: { id: props.companyId! },
          body: {
            name,
            code,
            address: address || null,
            wfxSupplierName: isOutsource.value ? wfxSupplierName || null : null,
            isActive,
          },
        })
      } else {
        await createMutate({
          body: {
            name,
            code,
            address: address || null,
            wfxSupplierName: isOutsource.value ? wfxSupplierName || null : null,
            isActive,
            corporationId: props.parentCorporation!.id,
          },
        })
      }
    },
    editing ? 'Đã cập nhật công ty' : 'Đã tạo công ty',
  )
  if (result) emit('saved')
}
</script>

<template>
  <OrgFormShell v-model:visible="isVisible" :title="isEditing ? 'Sửa công ty' : 'Thêm công ty'">
    <template #description>
      <div v-if="parentCorporation" class="mb-1 text-sm text-toned">
        Thuộc: <span class="font-medium text-highlighted">{{ parentCorporation.name }}</span>
        <UBadge
          :color="parentCorporation.classification === 'OUTSOURCE' ? 'warning' : 'info'"
          :label="parentCorporation.classification === 'OUTSOURCE' ? 'Outsource' : 'Inhouse'"
          class="ml-2"
        />
      </div>
    </template>

    <UForm
      id="company-form"
      :schema="schema"
      :state="state"
      :validate-on="[]"
      class="flex flex-col gap-4"
      @submit="handleSubmit"
    >
      <div v-if="isEditing" class="flex flex-col gap-2">
        <label class="text-sm font-medium">Trạng thái</label>
        <URadioGroup
          v-model="state.isActive"
          name="isActive"
          orientation="horizontal"
          :items="[
            { label: 'Hoạt động', value: true },
            { label: 'Tạm dừng', value: false },
          ]"
        />
      </div>

      <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <UFormField label="Mã đơn vị" name="code" required>
          <UInput v-model="state.code" class="w-full" />
          <p
            class="mt-1 flex items-start gap-1 text-xs font-medium text-amber-600 dark:text-amber-400"
          >
            <UIcon name="i-lucide-info" class="mt-0.5 size-3.5 shrink-0" />
            <span
              >Người dùng phải khai báo mã đơn vị đồng nhất với FactoryCode trên WFX để đồng bộ
              API</span
            >
          </p>
        </UFormField>
        <UFormField label="Tên công ty" name="name" required>
          <UInput v-model="state.name" class="w-full" />
        </UFormField>
      </div>

      <UFormField label="Địa chỉ" name="address">
        <UInput v-model="state.address" class="w-full" />
      </UFormField>

      <div v-if="isOutsource" class="flex flex-col gap-2">
        <div class="flex items-center justify-between">
          <label class="text-sm font-medium">Tên trên WFX</label>
          <UButton
            label="Làm mới NCC"
            icon="i-lucide-refresh-cw"
            size="xs"
            variant="ghost"
            color="primary"
            :loading="isSyncing"
            @click="handleSyncSuppliers"
          />
        </div>
        <USelect
          :model-value="state.wfxSupplierName ?? undefined"
          name="wfxSupplierName"
          :items="supplierOptions"
          label-key="label"
          value-key="value"
          placeholder="Chọn nhà cung cấp WFX..."
          :loading="suppliersPending"
          class="w-full"
          @update:model-value="(v: string | undefined) => (state.wfxSupplierName = v ?? null)"
        />
        <p class="flex items-start gap-1 text-xs font-medium text-amber-600 dark:text-amber-400">
          <UIcon name="i-lucide-info" class="mt-0.5 size-3.5 shrink-0" />
          <span>Dữ liệu phục vụ đồng bộ API, tên NCC được phép trùng nhau</span>
        </p>
      </div>
    </UForm>

    <template #footer>
      <div class="flex w-full justify-end gap-2">
        <UButton
          label="Hủy"
          icon="i-lucide-x"
          color="neutral"
          variant="ghost"
          type="button"
          @click="cancel"
        />
        <UButton
          label="Lưu"
          icon="i-lucide-check"
          type="submit"
          form="company-form"
          :loading="loading"
        />
      </div>
    </template>
  </OrgFormShell>
</template>
