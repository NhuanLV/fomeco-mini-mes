<script setup lang="ts">
defineProps<{
  visible: boolean
  title: string
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
}>()
</script>

<template>
  <UModal
    :open="visible"
    :title="title"
    :close="{ onClick: () => emit('update:visible', false) }"
    class="sm:max-w-xl"
    @update:open="emit('update:visible', $event)"
  >
    <template #body>
      <div class="flex flex-col gap-4">
        <slot name="description" />
        <slot name="subtitle" />
        <slot />
      </div>
    </template>
    <template v-if="$slots.footer" #footer>
      <slot name="footer" />
    </template>
  </UModal>
</template>
