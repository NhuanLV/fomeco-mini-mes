import { deleteCompany, deleteCorporation, deleteFactory, deleteTeam, deleteWarehouse } from '@/api'
import { getTreeQueryKey } from '@/api/@pinia/colada.gen'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useQueryCache } from '@pinia/colada'
import type { OrgTreeNode } from '../types'

type DeleteableType = 'CORPORATION' | 'COMPANY' | 'FACTORY' | 'TEAM' | 'WAREHOUSE'

const DELETE_CONFIG: Record<
  DeleteableType,
  { noun: string; api: (id: string) => Promise<unknown> }
> = {
  CORPORATION: { noun: 'tổng công ty', api: (id) => deleteCorporation({ path: { id } }) },
  COMPANY: { noun: 'công ty', api: (id) => deleteCompany({ path: { id } }) },
  FACTORY: { noun: 'xí nghiệp', api: (id) => deleteFactory({ path: { id } }) },
  TEAM: { noun: 'tổ', api: (id) => deleteTeam({ path: { id } }) },
  WAREHOUSE: { noun: 'kho', api: (id) => deleteWarehouse({ path: { id } }) },
}

export function useOrgNodeDelete() {
  const queryCache = useQueryCache()

  async function deleteNode(node: OrgTreeNode) {
    const cfg = DELETE_CONFIG[node.data.type as DeleteableType]
    if (!cfg) return
    if (!confirm(`Xóa ${cfg.noun} "${node.data.name}"?`)) return
    try {
      await cfg.api(node.data.id)
      await queryCache.invalidateQueries({ key: getTreeQueryKey() })
      showSuccess(`Xóa ${cfg.noun} thành công`)
    } catch (error: unknown) {
      showError((error as { message?: string })?.message ?? `Không thể xóa ${cfg.noun}`)
    }
  }

  return { deleteNode }
}
