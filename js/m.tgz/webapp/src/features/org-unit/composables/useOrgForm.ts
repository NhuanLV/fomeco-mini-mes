import { getTreeQueryKey } from '@/api/@pinia/colada.gen'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useQueryCache } from '@pinia/colada'
import { useVModel } from '@vueuse/core'
import { computed } from 'vue'

export function useOrgForm<P extends { visible: boolean }>(
  props: P,
  emit: (event: 'update:visible', value: boolean) => void,
  entityId: () => string | null | undefined,
) {
  const isVisible = useVModel(props, 'visible', emit)
  const isEditing = computed(() => !!entityId())
  const queryCache = useQueryCache()

  const save = async (fn: () => Promise<void>, successMsg: string): Promise<boolean> => {
    try {
      await fn()
      await queryCache.invalidateQueries({ key: getTreeQueryKey() })
      showSuccess(successMsg)
      isVisible.value = false
      return true
    } catch (error: unknown) {
      showError((error as { message?: string })?.message ?? 'Lỗi không xác định')
      return false
    }
  }

  const cancel = () => {
    isVisible.value = false
  }

  return { isVisible, isEditing, save, cancel, queryCache }
}
