import { getOperationsQuery, getTreeQuery } from '@/api/@pinia/colada.gen'
import { mapUnitToTreeNode } from '@/features/org-unit/core/org'
import { useQuery } from '@pinia/colada'
import { computed, ref } from 'vue'
import type { OrgTreeNode } from '../types'

export function useOrganization() {
  const { data: rawTree } = useQuery(getTreeQuery())
  const { data: rawOps } = useQuery(getOperationsQuery())

  // UI state — local to the instance (resets on page navigation)
  const expandedKeys = ref<Record<string, boolean>>({})

  const treeData = computed(() => {
    const data = rawTree.value
    if (!data) return []

    const nodes = Array.isArray(data)
      ? data.map((n) => mapUnitToTreeNode(n))
      : [mapUnitToTreeNode(data)]

    // Auto-expand the first node if nothing is expanded yet
    if (nodes[0] && Object.keys(expandedKeys.value).length === 0) {
      expandedKeys.value[nodes[0].key] = true
    }

    return nodes
  })

  const globalOperations = computed(() => rawOps.value ?? [])

  const findNode = (nodes: OrgTreeNode[], id: string): OrgTreeNode | null => {
    for (const node of nodes) {
      if (node.key === id) return node
      if (node.children) {
        const found = findNode(node.children, id)
        if (found) return found
      }
    }
    return null
  }

  return {
    expandedKeys,
    treeData,
    globalOperations,
    findNode,
  }
}
