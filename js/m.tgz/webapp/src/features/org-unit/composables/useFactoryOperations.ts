import type { FactoryOperationVm, UnitVm } from '@/api'
import {
  createFactoryOperationMutation,
  getFactoryOperationsQuery,
  getFactoryOperationsQueryKey,
  getTreeQuery,
  getWarehousesQuery,
  getWarehousesQueryKey,
  updateFactoryOperationMutation,
} from '@/api/@pinia/colada.gen'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import { computed, ref } from 'vue'

export function useFactoryOperations() {
  const queryCache = useQueryCache()
  const selectedCompanyId = ref<string>('__ALL__')
  const searchQuery = ref('')

  const { data: rawTree } = useQuery(getTreeQuery())
  const { data: rawWarehouses } = useQuery(getWarehousesQuery())

  // Flatten units from the multi-root tree with company associations
  const parsedUnits = computed(() => {
    const companies: UnitVm[] = []
    const factories: (UnitVm & { companyId?: string })[] = []
    const warehouses: (UnitVm & { companyId?: string })[] = []

    function traverse(units?: UnitVm[], currentCompanyId?: string) {
      if (!units) return
      for (const u of units) {
        if (u.type === 'COMPANY') {
          companies.push(u)
          traverse(u.children, u.id)
        } else if (u.type === 'FACTORY') {
          factories.push({ ...u, companyId: currentCompanyId })
          traverse(u.children, currentCompanyId)
        } else if (u.type === 'WAREHOUSE') {
          warehouses.push({ ...u, companyId: currentCompanyId })
          traverse(u.children, currentCompanyId)
        } else {
          traverse(u.children, currentCompanyId)
        }
      }
    }

    const raw = rawTree.value
    if (raw) {
      traverse(Array.isArray(raw) ? raw : [raw])
    }

    return { companies, factories, warehouses }
  })

  const companies = computed(() => parsedUnits.value.companies)
  const factories = computed(() => parsedUnits.value.factories)
  const warehouses = computed(() => {
    if (rawWarehouses.value && rawWarehouses.value.length > 0) {
      return rawWarehouses.value
    }
    return parsedUnits.value.warehouses
  })

  const { data: rawOperations, isPending: loading } = useQuery(() =>
    getFactoryOperationsQuery({
      query: {
        companyId:
          selectedCompanyId.value && selectedCompanyId.value !== '__ALL__'
            ? selectedCompanyId.value
            : undefined,
      },
    }),
  )

  const filteredOperations = computed<FactoryOperationVm[]>(() => {
    const list = rawOperations.value ?? []
    const q = searchQuery.value.trim().toLowerCase()
    if (!q) return list

    return list.filter(
      (op) =>
        op.operationCode.toLowerCase().includes(q) ||
        op.operationName.toLowerCase().includes(q) ||
        op.companyCode.toLowerCase().includes(q) ||
        op.companyName.toLowerCase().includes(q) ||
        op.factoryCode.toLowerCase().includes(q) ||
        op.factoryName.toLowerCase().includes(q),
    )
  })

  const { mutateAsync: createMutate, isLoading: isCreating } = useMutation(
    createFactoryOperationMutation(),
  )
  const { mutateAsync: updateMutate, isLoading: isUpdating } = useMutation(
    updateFactoryOperationMutation(),
  )

  async function invalidate() {
    await Promise.all([
      queryCache.invalidateQueries({ key: getFactoryOperationsQueryKey() }),
      queryCache.invalidateQueries({ key: getWarehousesQueryKey() }),
    ])
  }

  return {
    selectedCompanyId,
    searchQuery,
    companies,
    factories,
    warehouses,
    operations: filteredOperations,
    loading,
    isMutating: computed(() => isCreating.value || isUpdating.value),
    createMutate,
    updateMutate,
    invalidate,
  }
}
