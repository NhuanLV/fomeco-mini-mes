import type { UnitVm } from '@/api'
import type { ComputedRef } from 'vue'
import { ref } from 'vue'
import type { OrgTreeNode } from '../types'

type FindNodeFn = (nodes: OrgTreeNode[], id: string) => OrgTreeNode | null

export function useOrgFormState(treeData: ComputedRef<OrgTreeNode[]>, findNode: FindNodeFn) {
  const showCorporationForm = ref(false)
  const showCompanyForm = ref(false)
  const showFactoryForm = ref(false)
  const showTeamForm = ref(false)
  const showWarehouseForm = ref(false)

  const editingCorporationId = ref<string | null>(null)
  const editingCompanyId = ref<string | null>(null)
  const editingFactoryId = ref<string | null>(null)
  const editingTeamId = ref<string | null>(null)
  const editingWarehouseId = ref<string | null>(null)

  const formParentCorporation = ref<UnitVm | null>(null)
  const formParentCompany = ref<UnitVm | null>(null)
  const formParentFactory = ref<UnitVm | null>(null)

  function closeAllForms() {
    showCorporationForm.value = false
    showCompanyForm.value = false
    showFactoryForm.value = false
    showTeamForm.value = false
    showWarehouseForm.value = false
  }

  function openAddCorporation() {
    closeAllForms()
    editingCorporationId.value = null
    showCorporationForm.value = true
  }

  function openEditCorporation(corporation: UnitVm) {
    closeAllForms()
    editingCorporationId.value = corporation.id
    showCorporationForm.value = true
  }

  function openAddCompany(parent: UnitVm) {
    closeAllForms()
    editingCompanyId.value = null
    formParentCorporation.value = parent
    showCompanyForm.value = true
  }

  function openEditCompany(company: UnitVm) {
    closeAllForms()
    editingCompanyId.value = company.id
    const node = findNode(treeData.value, company.id)
    formParentCorporation.value = node?.parent?.data || null
    showCompanyForm.value = true
  }

  function openAddFactory(parent: UnitVm) {
    closeAllForms()
    editingFactoryId.value = null
    formParentCompany.value = parent
    showFactoryForm.value = true
  }

  function openEditFactory(factory: UnitVm) {
    closeAllForms()
    editingFactoryId.value = factory.id
    const node = findNode(treeData.value, factory.id)
    formParentCompany.value = node?.parent?.data || null
    showFactoryForm.value = true
  }

  function openAddTeam(parent: UnitVm) {
    closeAllForms()
    editingTeamId.value = null
    formParentFactory.value = parent
    showTeamForm.value = true
  }

  function openEditTeam(team: UnitVm, parent: UnitVm) {
    closeAllForms()
    editingTeamId.value = team.id
    formParentFactory.value = parent
    showTeamForm.value = true
  }

  function openAddWarehouse(parent: UnitVm) {
    closeAllForms()
    editingWarehouseId.value = null
    formParentCompany.value = parent
    showWarehouseForm.value = true
  }

  function openEditWarehouse(warehouse: UnitVm) {
    closeAllForms()
    editingWarehouseId.value = warehouse.id
    const node = findNode(treeData.value, warehouse.id)
    formParentCompany.value = node?.parent?.data || null
    showWarehouseForm.value = true
  }

  return {
    showCorporationForm,
    showCompanyForm,
    showFactoryForm,
    showTeamForm,
    showWarehouseForm,
    editingCorporationId,
    editingCompanyId,
    editingFactoryId,
    editingTeamId,
    editingWarehouseId,
    formParentCorporation,
    formParentCompany,
    formParentFactory,
    closeAllForms,
    openAddCorporation,
    openEditCorporation,
    openAddCompany,
    openEditCompany,
    openAddFactory,
    openEditFactory,
    openAddTeam,
    openEditTeam,
    openAddWarehouse,
    openEditWarehouse,
  }
}
