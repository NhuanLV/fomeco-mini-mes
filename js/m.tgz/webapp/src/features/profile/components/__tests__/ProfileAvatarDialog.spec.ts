import { enableAutoUnmount, mount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { Cropper } from 'vue-advanced-cropper'
import ProfileAvatarDialog from '../ProfileAvatarDialog.vue'

const { toDataURL } = vi.hoisted(() => ({ toDataURL: vi.fn() }))
vi.mock('vue-advanced-cropper', async () => {
  const { defineComponent } = await import('vue')
  return {
    Cropper: defineComponent({
      props: ['src', 'stencilProps', 'canvas'],
      emits: ['ready', 'error'],
      setup: () => ({ getResult: () => ({ canvas: { toDataURL } }) }),
      template: '<div />',
    }),
  }
})

enableAutoUnmount(afterEach)
afterEach(() => vi.restoreAllMocks())

function renderDialog() {
  return mount(ProfileAvatarDialog, {
    props: { open: true, saving: false },
    global: {
      stubs: {
        Modal: { template: '<div><slot name="body" /><slot name="footer" /></div>' },
      },
    },
  })
}

async function upload(wrapper: ReturnType<typeof renderDialog>, type = 'image/png') {
  const input = wrapper.get('input')
  Object.defineProperty(input.element, 'files', {
    configurable: true,
    value: [new File(['image'], 'avatar.png', { type })],
  })
  await input.trigger('change')
}

describe('ProfileAvatarDialog', () => {
  beforeEach(() => {
    vi.spyOn(URL, 'createObjectURL').mockReturnValue('blob:avatar')
    vi.spyOn(URL, 'revokeObjectURL').mockImplementation(() => {})
    toDataURL.mockReset().mockReturnValue('data:image/webp;base64,dGVzdA==')
  })

  it('requests square 160x160 output and emits WebP only after the image is ready', async () => {
    const wrapper = renderDialog()
    const save = wrapper.findAll('button').find((button) => button.text() === 'Lưu ảnh')!
    expect(save.attributes('disabled')).toBeDefined()
    await upload(wrapper)
    const cropper = wrapper.getComponent(Cropper)
    expect(cropper.props('stencilProps')).toEqual({ aspectRatio: 1 })
    expect(cropper.props('canvas')).toEqual({ width: 160, height: 160 })
    cropper.vm.$emit('ready')
    await wrapper.vm.$nextTick()
    await save.trigger('click')
    expect(toDataURL).toHaveBeenCalledWith('image/webp', 0.9)
    expect(wrapper.emitted('save')).toEqual([['data:image/webp;base64,dGVzdA==']])
    await wrapper.setProps({ open: false })
    expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:avatar')
    expect(wrapper.findComponent(Cropper).exists()).toBe(false)
  })

  it('rejects invalid files and prevents saving images that fail to load', async () => {
    const wrapper = renderDialog()
    await upload(wrapper, 'text/plain')
    expect(wrapper.get('[role="alert"]').text()).toContain('Vui lòng chọn ảnh')
    expect(URL.createObjectURL).not.toHaveBeenCalled()
    await upload(wrapper)
    wrapper.getComponent(Cropper).vm.$emit('error')
    await wrapper.vm.$nextTick()
    expect(wrapper.get('[role="alert"]').text()).toContain('Không đọc được ảnh')
    const save = wrapper.findAll('button').find((button) => button.text() === 'Lưu ảnh')!
    expect(save.attributes('disabled')).toBeDefined()
    expect(wrapper.emitted('save')).toBeUndefined()
  })

  it('does not emit a PNG fallback when WebP encoding is unsupported', async () => {
    toDataURL.mockReturnValue('data:image/png;base64,dGVzdA==')
    const wrapper = renderDialog()
    await upload(wrapper)
    wrapper.getComponent(Cropper).vm.$emit('ready')
    await wrapper.vm.$nextTick()
    await wrapper
      .findAll('button')
      .find((button) => button.text() === 'Lưu ảnh')!
      .trigger('click')
    expect(wrapper.get('[role="alert"]').text()).toContain('không hỗ trợ xuất ảnh WebP')
    expect(wrapper.emitted('save')).toBeUndefined()
  })
})
