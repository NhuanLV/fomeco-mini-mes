<script setup lang="ts">
import { onBeforeUnmount, ref, useTemplateRef, watch } from 'vue'
import { Cropper } from 'vue-advanced-cropper'
import 'vue-advanced-cropper/dist/style.css'

const open = defineModel<boolean>('open', { required: true })
const props = defineProps<{ saving: boolean }>()
const emit = defineEmits<{ save: [avatar: string] }>()
const cropper = useTemplateRef<InstanceType<typeof Cropper>>('cropper')
const imageUrl = ref('')
const ready = ref(false)
const error = ref('')

function resetImage() {
  if (imageUrl.value) URL.revokeObjectURL(imageUrl.value)
  imageUrl.value = ''
  ready.value = false
  error.value = ''
}

function selectImage(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  input.value = ''
  if (!file) return
  resetImage()
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    error.value = 'Vui lòng chọn ảnh JPG, PNG hoặc WebP.'
    return
  }
  imageUrl.value = URL.createObjectURL(file)
}

function imageFailed() {
  ready.value = false
  error.value = 'Không đọc được ảnh. Vui lòng chọn ảnh khác.'
}

function save() {
  if (!ready.value || props.saving) return
  try {
    const canvas = cropper.value?.getResult().canvas
    if (!canvas) throw new Error('Không thể cắt ảnh. Vui lòng chọn lại ảnh.')
    const avatar = canvas.toDataURL('image/webp', 0.9)
    if (!avatar.startsWith('data:image/webp;base64,')) {
      throw new Error('Trình duyệt không hỗ trợ xuất ảnh WebP.')
    }
    emit('save', avatar)
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : 'Không thể xử lý ảnh.'
  }
}

watch(open, (value) => {
  if (!value) resetImage()
})
onBeforeUnmount(resetImage)
</script>

<template>
  <UModal
    v-model:open="open"
    title="Đổi ảnh đại diện"
    description="Chọn ảnh và điều chỉnh vùng cắt vuông để làm ảnh đại diện."
    :dismissible="!saving"
    :close="!saving"
    :ui="{ footer: 'justify-end' }"
  >
    <template #body>
      <div class="space-y-4">
        <div class="space-y-2">
          <label for="profile-avatar-file" class="block text-sm font-medium text-default">
            Chọn ảnh JPG, PNG hoặc WebP
          </label>
          <input
            id="profile-avatar-file"
            type="file"
            accept="image/jpeg,image/png,image/webp"
            :disabled="saving"
            class="w-full rounded-md border border-default p-2 text-sm text-default file:mr-3 file:cursor-pointer"
            @change="selectImage"
          />
        </div>
        <Cropper
          v-if="imageUrl"
          :key="imageUrl"
          ref="cropper"
          :src="imageUrl"
          :stencil-props="{ aspectRatio: 1 }"
          :canvas="{ width: 160, height: 160 }"
          class="h-80 w-full overflow-hidden rounded-lg bg-muted"
          :class="{ 'pointer-events-none': saving }"
          @ready="ready = true"
          @error="imageFailed"
        />
        <p v-if="error" role="alert" class="text-sm text-error">{{ error }}</p>
      </div>
    </template>
    <template #footer>
      <UButton
        label="Hủy"
        color="neutral"
        variant="outline"
        :disabled="saving"
        @click="open = false"
      />
      <UButton
        label="Lưu ảnh"
        icon="i-lucide-check"
        :loading="saving"
        :disabled="!ready || saving"
        @click="save"
      />
    </template>
  </UModal>
</template>
