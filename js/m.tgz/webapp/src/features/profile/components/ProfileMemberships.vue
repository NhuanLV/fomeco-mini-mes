<script setup lang="ts">
import type { MembershipVm, PermissionVm } from '@/api'
import { ref } from 'vue'

defineProps<{
  memberships?: MembershipVm[]
}>()

const UNIT_TYPE_CONFIG: Record<
  string,
  {
    label: string
    icon: string
    color: 'primary' | 'info' | 'error' | 'warning' | 'success' | 'neutral'
  }
> = {
  CORPORATION: {
    label: 'Tổng công ty',
    icon: 'i-lucide-building-2',
    color: 'primary',
  },
  COMPANY: { label: 'Công ty', icon: 'i-lucide-building', color: 'info' },
  FACTORY: { label: 'Xí nghiệp', icon: 'i-lucide-factory', color: 'error' },
  TEAM: { label: 'Tổ sản xuất', icon: 'i-lucide-users', color: 'warning' },
  WAREHOUSE: { label: 'Kho', icon: 'i-lucide-warehouse', color: 'success' },
}

function getUnitTypeMeta(type: string) {
  return (
    UNIT_TYPE_CONFIG[type] || {
      label: type,
      icon: 'i-lucide-map-pin',
      color: 'neutral',
    }
  )
}

const expandedUnitIds = ref<string[]>([])

const isUnitExpanded = (unitId: string) => expandedUnitIds.value.includes(unitId)

const toggleUnit = (unitId: string) => {
  if (isUnitExpanded(unitId)) {
    expandedUnitIds.value = expandedUnitIds.value.filter((id) => id !== unitId)
  } else {
    expandedUnitIds.value.push(unitId)
  }
}

function getUnitPermissions(membership: MembershipVm): PermissionVm[] {
  const map = new Map<string, PermissionVm>()
  for (const role of membership.roles) {
    for (const p of role.permissions) {
      if (!map.has(p.code)) {
        map.set(p.code, p)
      }
    }
  }
  return [...map.values()]
}
</script>

<template>
  <div class="space-y-2">
    <label class="text-sm font-medium text-default">Đơn vị công tác</label>
    <div
      v-if="!memberships?.length"
      class="rounded-md border border-default bg-elevated/20 p-3 text-sm text-muted italic"
    >
      Chưa được phân công đơn vị nào
    </div>
    <div v-else class="space-y-2.5">
      <div
        v-for="m in memberships"
        :key="m.unitId"
        class="overflow-hidden rounded-md border border-default bg-elevated/20"
      >
        <!-- Unit Header (Clickable toggle) -->
        <button
          type="button"
          :aria-expanded="isUnitExpanded(m.unitId)"
          class="flex w-full cursor-pointer items-center justify-between gap-3 px-3.5 py-2.5 text-left transition-colors select-none hover:bg-elevated/40"
          @click="toggleUnit(m.unitId)"
        >
          <div class="flex items-center gap-2.5">
            <UIcon
              :name="getUnitTypeMeta(m.unitType).icon"
              class="size-4.5 shrink-0 text-primary-600"
            />
            <div>
              <div class="text-sm font-medium text-default">{{ m.unitName }}</div>
              <div v-if="m.companyName || m.factoryName" class="text-xs text-muted">
                {{ [m.companyName, m.factoryName].filter(Boolean).join(' • ') }}
              </div>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <UBadge
              :label="getUnitTypeMeta(m.unitType).label"
              :color="getUnitTypeMeta(m.unitType).color"
              variant="subtle"
              size="xs"
            />
            <UIcon
              :name="isUnitExpanded(m.unitId) ? 'i-lucide-chevron-up' : 'i-lucide-chevron-down'"
              class="size-4 shrink-0 text-muted transition-transform"
            />
          </div>
        </button>

        <!-- Expanded Details: Roles & Permissions -->
        <div
          v-if="isUnitExpanded(m.unitId)"
          class="space-y-3.5 border-t border-default bg-elevated/10 px-3.5 py-3"
        >
          <!-- Vai trò đảm nhiệm -->
          <div class="space-y-1.5">
            <div class="text-xs font-medium text-muted">Vai trò đảm nhiệm</div>
            <div v-if="!m.roles?.length" class="text-xs text-muted italic">
              Chưa có vai trò nào trong đơn vị này
            </div>
            <div v-else class="flex flex-wrap gap-2">
              <UBadge
                v-for="role in m.roles"
                :key="role.id"
                color="neutral"
                variant="subtle"
                size="md"
                class="flex items-center gap-1.5 px-2.5 py-1"
                :title="role.description || undefined"
              >
                <UIcon name="i-lucide-shield" class="size-3.5 text-primary-600" />
                <span class="font-medium">{{ role.name }}</span>
              </UBadge>
            </div>
          </div>

          <!-- Quyền hạn được cấp -->
          <div class="space-y-1.5">
            <div class="text-xs font-medium text-muted">Quyền hạn được cấp</div>
            <div v-if="!getUnitPermissions(m).length" class="text-xs text-muted italic">
              Chưa có quyền hạn nào
            </div>
            <div v-else class="flex flex-wrap gap-1.5">
              <UBadge
                v-for="p in getUnitPermissions(m)"
                :key="p.code"
                color="primary"
                variant="subtle"
                size="xs"
                class="font-mono text-xs"
                :title="p.description"
              >
                {{ p.displayName }}
              </UBadge>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
