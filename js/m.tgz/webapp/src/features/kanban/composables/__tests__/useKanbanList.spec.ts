import { describe, expect, it } from 'vitest'
import { toSinglePlanFilter } from '../useKanbanList'

describe('toSinglePlanFilter', () => {
  it('filters only when exactly one plan type is selected', () => {
    expect(toSinglePlanFilter([])).toBeUndefined()
    expect(toSinglePlanFilter([true])).toBe(true)
    expect(toSinglePlanFilter([false])).toBe(false)
    expect(toSinglePlanFilter([true, false])).toBeUndefined()
  })
})
