import type { KanbanContextVm, PlanItem, TeamAssignmentDetailVm, TeamBomVm } from '@/api'
import { buildColumns } from '@/features/kanban/helpers/kanbanItemsGrid'
import KanbanItemsGrid from '@/features/kanban/components/create/KanbanItemsGrid.vue'
import { useKanbanGridData } from '@/features/kanban/composables/useKanbanGridData'
import { showWarn } from '@/shared/utils/toast'
import { describe, expect, it, vi } from 'vitest'
import { defineComponent, h, ref } from 'vue'
import { shallowMount } from '@vue/test-utils'

vi.mock('@/shared/utils/toast', () => ({
  showWarn: vi.fn(),
}))

describe('Kanban reportable quantity', () => {
  it('keeps receiving demand shared when several upstream teams can supply BTP', () => {
    const context = makeContext({
      previousOperation: 'CUT-1',
      btpLines: [
        {
          color: 'Red',
          size: 'S',
          purchaseOrderId: 'po-1',
          purchaseOrderCode: 'PO-1',
          purchaseOrderType: 'REGULAR',
          allocationQty: 10,
        },
      ],
      cumulativeReported: [{ ...cumulative('BTP CUT-1', 4), purchaseOrderType: 'REGULAR' }],
    })
    const params = makeParams(context, 'INFO')
    params.supplierOptionsTeam.value = [
      { label: 'Cutting 1', value: 'cutting-1' },
      { label: 'Cutting 2', value: 'cutting-2' },
    ]

    const { tableRows } = useKanbanGridData(params)
    const rows = tableRows.value.filter((row) => row.type === 'SEMI_FINISHED_PRODUCT')

    expect(rows).toHaveLength(1)
    expect(rows[0]).toMatchObject({ totalConsumption: 10, cumulativeReported: 4, reportableQty: 6 })
    expect(rows[0]!.supplierOptions).toEqual(params.supplierOptionsTeam.value)
  })

  it('adds the reportable quantity column after cumulative received in STANDARD mode', () => {
    const columns = buildColumns('STANDARD')
    const receivedIndex = columns.findIndex(
      (column) => column.prop === 'effectiveCumulativeReceived',
    )
    const reportableColumn = columns[receivedIndex + 1]

    expect(reportableColumn).toMatchObject({
      prop: 'reportableQty',
      name: 'SL có thể báo',
      readonly: true,
      columnType: 'qty',
      cellClass: 'text-right',
    })
  })

  it('omits the reportable quantity column in EXTRA mode', () => {
    const columns = buildColumns('EXTRA')
    const hasReportableColumn = columns.some((column) => column.prop === 'reportableQty')

    expect(hasReportableColumn).toBe(false)
  })

  it('calculates reportable quantity from cumulative required for materials and BTP', () => {
    const context = makeContext({
      previousOperation: 'CUT-1',
      btpLines: [
        {
          color: 'Red',
          size: 'S',
          purchaseOrderId: 'po-1',
          purchaseOrderType: 'REGULAR',
          purchaseOrderCode: 'PO-1',
          allocationQty: 50,
        },
      ],
      cumulativeReported: [cumulative('Fabric', 20), cumulative('BTP CUT-1', 10)],
    })
    const params = makeParams(context, 'INFO')
    const { tableRows } = useKanbanGridData(params)

    expect(tableRows.value).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          articleName: 'Fabric',
          cumulativeReported: 20,
          reportableQty: 80,
        }),
        expect.objectContaining({
          articleName: 'BTP CUT-1',
          cumulativeReported: 10,
          reportableQty: 40,
        }),
      ]),
    )
  })

  it('groups BTP by PO type and keeps quantities independent for the same SKU and supplier', () => {
    const context = makeContext({
      previousOperation: 'CUT-1',
      btpLines: [60, 40, 5, 5].map((allocationQty, index) => ({
        color: 'Red',
        size: 'S',
        purchaseOrderId: `po-${index}`,
        supplierUnitId: 'cutting',
        purchaseOrderCode: `PO-${index}`,
        allocationQty,
        purchaseOrderType: index < 2 ? 'REGULAR' : 'POSITIVE',
      })),
    })
    const params = makeParams(context, 'INFO')
    params.supplierOptionsTeam.value = [{ label: 'Cutting', value: 'cutting' }]
    const { tableRows, onQtyChange } = useKanbanGridData(params)
    const btp = () => tableRows.value.filter((row) => row.type === 'SEMI_FINISHED_PRODUCT')
    expect(
      btp().map((row) => [row.purchaseOrderType, row.totalConsumption, row.supplierUnitId]),
    ).toEqual([
      ['REGULAR', 100, 'cutting'],
      ['POSITIVE', 10, 'cutting'],
    ])
    onQtyChange(btp()[0]!.lineId, 60)
    onQtyChange(btp()[1]!.lineId, 5)
    expect(btp().map((row) => row.requiredQty)).toEqual([60, 5])
  })

  it('distributes a partial plan across sources without duplicating its quantity', () => {
    const context = makeContext({
      previousOperation: 'CUT-1',
      btpLines: [
        {
          color: 'Red',
          size: 'S',
          purchaseOrderId: 'po-1',
          purchaseOrderCode: 'PO-1',
          purchaseOrderType: 'REGULAR',
          allocationQty: 60,
          supplierUnitId: 'source-1',
        },
        {
          color: 'Red',
          size: 'S',
          purchaseOrderId: 'po-1',
          purchaseOrderCode: 'PO-1',
          purchaseOrderType: 'REGULAR',
          allocationQty: 40,
          supplierUnitId: 'source-2',
        },
      ],
    })
    const params = makeParams(context, 'STANDARD', [planItem(70)])
    params.supplierOptionsTeam.value = [1, 2].map((id) => ({
      label: `Source ${id}`,
      value: `source-${id}`,
    }))
    const { tableRows } = useKanbanGridData(params)
    expect(
      tableRows.value
        .filter((row) => row.type === 'SEMI_FINISHED_PRODUCT')
        .map((row) => row.requiredQty),
    ).toEqual([60, 10])

    params.context.value = {
      ...context,
      cumulativeReported: [
        {
          ...cumulative('BTP CUT-1', 60),
          purchaseOrderType: 'REGULAR',
          supplierUnitId: 'source-1',
        },
      ],
    }
    params.planItems.value = [planItem(40)]
    expect(
      tableRows.value
        .filter((row) => row.type === 'SEMI_FINISHED_PRODUCT')
        .map((row) => [row.supplierUnitId, row.requiredQty]),
    ).toEqual([['source-2', 40]])

    params.context.value = {
      ...params.context.value,
      btpLines: context.btpLines.flatMap((line) => [
        { ...line, allocationQty: line.allocationQty / 2 },
        { ...line, purchaseOrderId: 'po-2', allocationQty: line.allocationQty / 2 },
      ]),
    }
    params.planItems.value = [planItem(20), { ...planItem(20), purchaseOrderId: 'po-2' }]
    expect(
      tableRows.value
        .filter((row) => row.type === 'SEMI_FINISHED_PRODUCT')
        .map((row) => [row.supplierUnitId, row.requiredQty]),
    ).toEqual([['source-2', 40]])
  })

  it('clamps STANDARD rows to reportable quantity and releases quantity when required is removed', () => {
    const context = makeContext({
      previousOperation: undefined,
      btpLines: [],
      cumulativeReported: [cumulative('Fabric', 20)],
      cumulativeReceivedInStandard: [cumulative('Fabric', 0)],
    })
    const params = makeParams(context, 'STANDARD', [planItem(100)])
    const { tableRows, onQtyChange } = useKanbanGridData(params)

    expect(tableRows.value[0]).toMatchObject({
      cumulativeReported: 20,
      reportableQty: 80,
      requiredQty: 80,
    })

    onQtyChange('Fabric::Red::S', 90)
    expect(tableRows.value[0]?.requiredQty).toBe(80)

    params.context.value = { ...params.context.value, cumulativeReported: [] }
    expect(tableRows.value[0]).toMatchObject({
      cumulativeReported: 0,
      reportableQty: 100,
      requiredQty: 90,
    })
  })

  it('warns and clamps an edited STANDARD quantity', async () => {
    vi.clearAllMocks()
    const context = makeContext({
      previousOperation: undefined,
      btpLines: [],
      cumulativeReported: [cumulative('Fabric', 20)],
      cumulativeReceivedInStandard: [cumulative('Fabric', 0)],
    })
    const wrapper = shallowMount(KanbanItemsGrid, {
      props: {
        mode: 'STANDARD',
        planItems: [planItem(100)],
        assignment: makeAssignment(),
        bomData: makeBom(),
        context,
      },
      global: {
        stubs: {
          BaseMatrixGrid: BaseMatrixGridStub,
          BomDetailDialog: true,
        },
      },
    })

    const grid = wrapper.findComponent(BaseMatrixGridStub)
    grid.vm.$emit('afteredit', [{ rowIndex: 0, prop: 'requiredQty', value: 90 }])

    expect(showWarn).toHaveBeenCalledWith(
      'Số lượng báo không được vượt quá số lượng còn lại có thể báo',
    )
    expect(wrapper.emitted('update:rows')?.at(-1)?.[0]).toEqual([
      expect.objectContaining({ requiredQty: 80 }),
    ])
  })

  it('preserves isRequired flag in STANDARD mode for optional materials', () => {
    const context = makeContext({
      previousOperation: undefined,
      btpLines: [],
    })
    const bom = makeBom()
    bom.lines[0].isRequired = false

    const params = makeParams(context, 'STANDARD', [planItem(50)])
    params.bomData.value = bom

    const { tableRows } = useKanbanGridData(params)

    expect(tableRows.value[0]).toMatchObject({
      articleName: 'Fabric',
      isRequired: false,
    })
  })
})

const BaseMatrixGridStub = defineComponent({
  name: 'BaseMatrixGrid',
  emits: ['afteredit', 'beforeedit'],
  setup() {
    return () => h('div')
  },
})

function cumulative(article: string, cumulativeReported: number) {
  return {
    article,
    color: 'Red',
    size: 'S',
    cumulativeReported,
  }
}

function planItem(qty: number): PlanItem {
  return {
    purchaseOrderId: 'po-1',
    color: 'Red',
    size: 'S',
    qty,
  }
}

function makeParams(
  context: KanbanContextVm,
  mode: 'INFO' | 'STANDARD' | 'EXTRA',
  planItems: PlanItem[] = [],
) {
  return {
    mode: ref(mode),
    planItems: ref(planItems),
    assignment: ref(makeAssignment()),
    bomData: ref(makeBom()),
    context: ref(context),
    supplierOptionsWarehouse: ref([{ label: 'Kho 1', value: 'warehouse-1' }]),
    supplierOptionsTeam: ref([{ label: 'Tổ 1', value: 'team-1' }]),
  }
}

function makeContext(overrides: Partial<KanbanContextVm> = {}): KanbanContextVm {
  return {
    teamAssignmentId: 'assignment-1',
    bomConsumption: [
      {
        article: 'Fabric',
        color: 'Red',
        size: 'S',
        totalQty: 100,
      },
    ],
    btpLines: [],
    cumulativeReported: [],
    cumulativeReceivedInStandard: [],
    cumulativeReceivedAll: [],
    requiredPlan: [],
    previousOperation: undefined,
    availableWarehouses: [{ id: 'warehouse-1', name: 'Kho 1' }],
    previousOperationTeams: [{ id: 'team-1', name: 'Tổ 1' }],
    ...overrides,
  }
}

function makeBom(): TeamBomVm {
  return {
    teamAssignmentId: 'assignment-1',
    lines: [
      {
        id: 'line-1',
        articleName: 'Fabric',
        alternativeName: 'Vải chính',
        isRequired: true,
        category: 'FABRIC',
        uom: 'M',
        destinationCodes: [],
        sizes: [
          {
            productSize: 'S',
            materialSize: 'S',
            consumption: 1,
          },
        ],
        colors: [
          {
            productColor: 'Red',
            materialColor: 'Red',
            consumption: 1,
          },
        ],
        cuttingColors: [],
      },
    ],
  }
}

function makeAssignment(): TeamAssignmentDetailVm {
  return {
    productionOrderStatus: 'IN_PROGRESS',
    id: 'assignment-1',
    productionOrderId: 'production-order-1',
    productionCode: 'LSX-1',
    styleName: 'STYLE-1',
    styleColorOrder: ['Red'],
    styleSizeOrder: ['S'],
    factoryName: 'Factory',
    companyName: 'Company',
    companyId: 'company-1',
    teamId: 'team-1',
    teamName: 'Tổ 1',
    operation: 'SEW-1',
    allocations: [
      {
        purchaseOrderId: 'po-1',
        color: 'Red',
        size: 'S',
        quantity: 100,
        notes: [],
      },
    ],
    outputReportTotals: [],
    inputReportTotals: [],
    metadataRows: [],
    purchaseOrderTypes: {},
    purchaseOrderCodes: { 'po-1': 'PO-1' },
    purchaseOrderDestinations: { 'po-1': '' },
    assignedAt: '2026-08-05',
    reconciliationStatus: 'NORMAL',
  }
}
