import type { MaybeRefOrGetter } from 'vue'
import { computed, ref, toValue, watch } from 'vue'
import type { TeamMaterialRequirement } from '@/features/production/team-material/teamMaterialCalculation'

export type RowKind = 'parent' | 'child' | 'leaf'

export interface LineRow {
  lineId: string
  groupKey: string

  articleName: string
  articleCode?: string | null
  alternativeName?: string | null
  isRequired?: boolean
  poCode: string | null
  color: string
  materialSize: string
  requiredQty: number | null
  uom: string
  recipientId: string
  sourceOperation?: string
  rowKind: RowKind
  poId: string | null
}

export interface LineRequirementRow {
  articleName: string
  articleCode?: string | null
  alternativeName?: string | null
  isRequired?: boolean
  materialColor: string
  materialSize: string
  qty: number
  uom: string
  sourceOperation?: string
}

interface PoChildRow {
  poId: string | null
  poCode: string

  articleName: string
  articleCode?: string | null
  alternativeName?: string | null
  isRequired?: boolean
  materialColor: string
  materialSize: string
  uom: string
  qty: number
  lineType?: 'NPL' | 'BTP'
  sourceOperation?: string
}

function buildPoBreakdownMap(
  planEntries: TeamMaterialRequirement[],
  purchaseOrderCodes: Record<string, string>,
): Map<string, Map<string, PoChildRow>> {
  const map = new Map<string, Map<string, PoChildRow>>()
  for (const e of planEntries) {
    const parentKey = `${e.articleName}::${e.materialColor}::${e.materialSize}`
    if (!map.has(parentKey)) map.set(parentKey, new Map())
    const children = map.get(parentKey)!
    const existing = children.get(e.poId)
    if (existing) {
      existing.qty = parseFloat((existing.qty + e.qty).toFixed(2))
    } else {
      children.set(e.poId, {
        poId: e.poId,
        poCode: purchaseOrderCodes[e.poId] ?? e.poId,
        articleName: e.articleName,
        articleCode: e.articleCode,
        alternativeName: e.alternativeName,
        isRequired: e.isRequired,
        materialColor: e.materialColor,
        materialSize: e.materialSize,
        uom: e.uom,
        qty: e.qty,
        lineType: e.lineType,
        sourceOperation: e.sourceOperation,
      })
    }
  }
  return map
}

function resolveRecipientId(
  existingRows: Map<string, LineRow>,
  lineId: string,
  groupKey: string,
): string {
  const prev = existingRows.get(lineId)
  if (prev?.recipientId) return prev.recipientId

  for (const [, l] of existingRows) {
    if (l.groupKey === groupKey && l.rowKind === 'child' && l.recipientId) {
      return l.recipientId
    }
  }

  return ''
}

export function useKanbanLineRows(options: {
  planRequirements: MaybeRefOrGetter<LineRequirementRow[]>
  planEntries: MaybeRefOrGetter<TeamMaterialRequirement[]>
  purchaseOrderCodes: MaybeRefOrGetter<Record<string, string>>
}) {
  const planRequirements = computed(() => toValue(options.planRequirements))
  const planEntries = computed(() => toValue(options.planEntries))
  const purchaseOrderCodes = computed(() => toValue(options.purchaseOrderCodes))

  const poBreakdownMap = computed(() =>
    buildPoBreakdownMap(planEntries.value, purchaseOrderCodes.value),
  )

  const lineRows = ref<LineRow[]>([])
  const expandedKeys = ref(new Set<string>())

  function toggleExpand(key: string) {
    const s = new Set(expandedKeys.value)
    if (s.has(key)) s.delete(key)
    else s.add(key)
    expandedKeys.value = s
  }

  function buildLineRows() {
    const existing = new Map(lineRows.value.map((l) => [l.lineId, l]))
    const rows: LineRow[] = []

    for (const r of planRequirements.value) {
      const parentKey = `${r.articleName}::${r.materialColor}::${r.materialSize}`
      const isExpanded = expandedKeys.value.has(parentKey)

      if (!isExpanded) {
        const lineId = parentKey
        rows.push({
          lineId,
          groupKey: parentKey,
          articleName: r.articleName,
          articleCode: r.articleCode,
          alternativeName: r.alternativeName,
          isRequired: r.isRequired,
          poCode: null,
          color: r.materialColor || '-',
          materialSize: r.materialSize || '-',
          requiredQty: r.qty,
          uom: r.uom,
          recipientId: resolveRecipientId(existing, lineId, parentKey),
          sourceOperation: r.sourceOperation,
          rowKind: 'leaf',
          poId: null,
        })
      } else {
        rows.push({
          lineId: parentKey,
          groupKey: parentKey,
          articleName: r.articleName,
          articleCode: r.articleCode,
          alternativeName: r.alternativeName,
          isRequired: r.isRequired,
          poCode: null,
          color: r.materialColor || '-',
          materialSize: r.materialSize || '-',
          requiredQty: null,
          uom: r.uom,
          recipientId: '',
          sourceOperation: r.sourceOperation,
          rowKind: 'parent',
          poId: null,
        })

        const children = poBreakdownMap.value.get(parentKey)
        if (children) {
          for (const [, child] of children) {
            const childLineId = `${parentKey}::${child.poId}`
            const prev = existing.get(childLineId)
            rows.push({
              lineId: childLineId,
              groupKey: parentKey,
              articleName: child.articleName,
              articleCode: child.articleCode,
              alternativeName: child.alternativeName,
              isRequired: child.isRequired,
              poCode: child.poCode,
              color: child.materialColor || '-',
              materialSize: child.materialSize || '-',
              requiredQty: child.qty,
              uom: child.uom,
              recipientId: prev?.recipientId ?? '',
              sourceOperation: child.sourceOperation,
              rowKind: 'child',
              poId: child.poId,
            })
          }
        }
      }
    }

    lineRows.value = rows
  }

  watch(
    () => [planRequirements.value, expandedKeys.value] as const,
    () => buildLineRows(),
    { immediate: true },
  )

  return { lineRows, expandedKeys, toggleExpand }
}
