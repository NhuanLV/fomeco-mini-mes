import type {
  KanbanContextVm,
  PlanItem,
  TeamAssignmentDetailVm,
  TeamBomVm,
  TeamBomLineVm,
} from '@/api/types.gen'

import {
  calculateTeamMaterialRequirements,
  type TeamMaterialProduct,
  type TeamMaterialRequirement,
} from '@/features/production/team-material/teamMaterialCalculation'
import {
  useKanbanLineRows,
  type LineRequirementRow,
  type LineRow,
} from '@/features/kanban/composables/useKanbanLineRows'
import { computed, ref, watch, type Ref } from 'vue'

type SupplierOption = { label: string; value: string }

export interface TableRow extends Omit<LineRow, 'requiredQty' | 'recipientId'> {
  type: 'MATERIAL' | 'SEMI_FINISHED_PRODUCT'
  purchaseOrderType?: 'REGULAR' | 'POSITIVE'
  totalConsumption: number
  cumulativeReported: number
  reportableQty: number
  cumulativeReceivedInStandard: number
  cumulativeReceivedAll: number
  effectiveCumulativeReceived: number
  requiredQty: number
  supplierUnitId: string
  supplierOptions: SupplierOption[]
  creatorNote: string
  isEdited: boolean
  mode: 'INFO' | 'STANDARD' | 'EXTRA'
}

export interface UseKanbanGridDataParams {
  mode: Ref<'INFO' | 'STANDARD' | 'EXTRA'>
  planItems: Ref<PlanItem[]>
  assignment: Ref<TeamAssignmentDetailVm>
  bomData: Ref<TeamBomVm>
  context: Ref<KanbanContextVm>
  supplierOptionsWarehouse: Ref<{ label: string; value: string }[]>
  supplierOptionsTeam: Ref<{ label: string; value: string }[]>
}

type CumulativeEntryLike = {
  article: string
  color: string
  size: string
  cumulativeReported?: number
  purchaseOrderType?: 'REGULAR' | 'POSITIVE' | null
  supplierUnitId?: string | null
}

function findCumulative(
  entries: CumulativeEntryLike[] | undefined,
  article: string,
  color: string,
  size: string,
  purchaseOrderType?: 'REGULAR' | 'POSITIVE',
  supplierUnitId?: string | null,
): number {
  if (!entries?.length) return 0
  const found = entries.find(
    (c) =>
      c.article === article &&
      c.color === color &&
      c.size === size &&
      (!purchaseOrderType || (c.purchaseOrderType ?? 'REGULAR') === purchaseOrderType) &&
      (!supplierUnitId || c.supplierUnitId === supplierUnitId),
  )
  return found?.cumulativeReported ?? 0
}

function getContextCumulativeBuckets(context: KanbanContextVm): {
  inStandard: CumulativeEntryLike[]
  all: CumulativeEntryLike[]
} {
  const ctx = context as KanbanContextVm & {
    cumulativeReceivedInStandard?: CumulativeEntryLike[]
    cumulativeReceivedAll?: CumulativeEntryLike[]
  }
  return {
    inStandard: ctx.cumulativeReceivedInStandard ?? [],
    all: ctx.cumulativeReceivedAll ?? [],
  }
}

function pickDefaultSupplierId(
  explicitSupplierId: string | undefined,
  defaultSupplierId: string | undefined,
  supplierOptions: SupplierOption[],
): string {
  if (explicitSupplierId !== undefined) {
    if (
      explicitSupplierId === '' ||
      supplierOptions.some((opt) => opt.value === explicitSupplierId)
    ) {
      return explicitSupplierId
    }
  }
  if (defaultSupplierId && supplierOptions.some((opt) => opt.value === defaultSupplierId)) {
    return defaultSupplierId
  }
  if (supplierOptions.length === 1) return supplierOptions[0]!.value
  return ''
}

/**
 * Pure helper to build the initial scaffold for material rows
 */
function buildMaterialScaffold(
  context: KanbanContextVm,
  overrides: Record<string, { qty?: number; supplierId?: string; creatorNote?: string }>,
  bomLineByArticle: Record<string, TeamBomLineVm>,
  supplierOptions: SupplierOption[],
  mode: 'INFO' | 'STANDARD' | 'EXTRA',
): TableRow[] {
  const rowSupplierOptions = supplierOptions
  const cumulativeBuckets = getContextCumulativeBuckets(context)

  return context.bomConsumption.map((bc) => {
    const key = `${bc.article}::${bc.color}::${bc.size}`
    const ov = overrides[key]
    let qty = ov?.qty ?? 0
    const supplierId = pickDefaultSupplierId(ov?.supplierId, undefined, rowSupplierOptions)
    const creatorNote = ov?.creatorNote ?? ''
    const cumRequired = findCumulative(context.cumulativeReported, bc.article, bc.color, bc.size)
    const reportableQty = Math.max(0, bc.totalQty - cumRequired)
    const cumInStandard = findCumulative(
      cumulativeBuckets.inStandard,
      bc.article,
      bc.color,
      bc.size,
    )
    const cumAll = findCumulative(cumulativeBuckets.all, bc.article, bc.color, bc.size)
    const effectiveCum = mode === 'EXTRA' ? cumAll : cumInStandard
    if (mode === 'STANDARD') {
      qty = Math.max(0, Math.min(qty, reportableQty))
    }

    return {
      lineId: key,
      groupKey: key,
      articleName: bc.article,
      articleCode: bomLineByArticle[bc.article]?.articleCode ?? null,
      alternativeName: bomLineByArticle[bc.article]?.alternativeName ?? null,
      isRequired: bomLineByArticle[bc.article]?.isRequired ?? true,
      poCode: null,
      color: bc.color,
      materialSize: bc.size,
      uom: bomLineByArticle[bc.article]?.uom ?? '',
      sourceOperation: undefined,
      rowKind: 'leaf' as const,
      poId: null,
      type: 'MATERIAL' as const,
      totalConsumption: bc.totalQty,
      cumulativeReported: cumRequired,
      reportableQty,
      cumulativeReceivedInStandard: cumInStandard,
      cumulativeReceivedAll: cumAll,
      effectiveCumulativeReceived: effectiveCum,
      requiredQty: qty,
      supplierUnitId: supplierId,
      supplierOptions: rowSupplierOptions,
      creatorNote,
      isEdited: ov?.qty !== undefined || (ov?.creatorNote ?? '') !== '',
      mode,
    }
  })
}

/**
 * Pure helper to build the initial scaffold for BTP (semi-finished) rows
 */
function buildBtpScaffold(
  context: KanbanContextVm,
  overrides: Record<string, { qty?: number; supplierId?: string; creatorNote?: string }>,
  supplierOptions: SupplierOption[],
  mode: 'INFO' | 'STANDARD' | 'EXTRA',
  planItems: PlanItem[],
): TableRow[] {
  const cumulativeBuckets = getContextCumulativeBuckets(context)
  const btpMap = new Map<
    string,
    {
      color: string
      size: string
      totalQty: number
      purchaseOrderType: 'REGULAR' | 'POSITIVE'
      supplierUnitId?: string | null
    }
  >()
  context.btpLines.forEach((bl) => {
    const purchaseOrderType = bl.purchaseOrderType ?? 'REGULAR'
    const key = `${bl.color}::${bl.size}::${purchaseOrderType}::${bl.supplierUnitId ?? ''}`
    if (!btpMap.has(key)) {
      btpMap.set(key, {
        color: bl.color,
        size: bl.size,
        totalQty: 0,
        purchaseOrderType,
        supplierUnitId: bl.supplierUnitId,
      })
    }
    btpMap.get(key)!.totalQty += bl.allocationQty
  })

  const articleName = `BTP ${context.previousOperation}`
  const plannedByKey = new Map<string, number>()
  if (mode === 'STANDARD') {
    for (const item of planItems) {
      let remainingQty = item.qty
      for (const line of context.btpLines) {
        if (
          line.purchaseOrderId !== item.purchaseOrderId ||
          line.color !== item.color ||
          line.size !== item.size
        )
          continue
        const type = line.purchaseOrderType ?? 'REGULAR'
        const key = `${line.color}::${line.size}::${type}::${line.supplierUnitId ?? ''}`
        const allocatedQty = btpMap.get(key)!.totalQty
        const cumulativeQty = findCumulative(
          context.cumulativeReported,
          articleName,
          line.color,
          line.size,
          type,
          line.supplierUnitId,
        )
        const plannedQty = plannedByKey.get(key) ?? 0
        const qty = Math.min(
          remainingQty,
          line.allocationQty,
          Math.max(0, allocatedQty - cumulativeQty - plannedQty),
        )
        plannedByKey.set(key, plannedQty + qty)
        remainingQty -= qty
      }
    }
  }
  return Array.from(btpMap.values()).map((data) => {
    const key = `${articleName}::${data.color}::${data.size}::${data.purchaseOrderType}::${data.supplierUnitId ?? ''}`
    const ov = overrides[key]
    const rowSupplierOptions = data.supplierUnitId
      ? supplierOptions.filter((option) => option.value === data.supplierUnitId)
      : supplierOptions
    const plannedQty =
      plannedByKey.get(
        `${data.color}::${data.size}::${data.purchaseOrderType}::${data.supplierUnitId ?? ''}`,
      ) ?? 0
    let qty = ov?.qty ?? plannedQty
    const supplierId = pickDefaultSupplierId(
      ov?.supplierId,
      data.supplierUnitId ?? undefined,
      rowSupplierOptions,
    )
    const creatorNote = ov?.creatorNote ?? ''
    const cumRequired = findCumulative(
      context.cumulativeReported,
      articleName,
      data.color,
      data.size,
      data.purchaseOrderType,
      data.supplierUnitId,
    )
    const reportableQty = Math.max(0, data.totalQty - cumRequired)
    const cumInStandard = findCumulative(
      cumulativeBuckets.inStandard,
      articleName,
      data.color,
      data.size,
      data.purchaseOrderType,
      data.supplierUnitId,
    )
    const cumAll = findCumulative(
      cumulativeBuckets.all,
      articleName,
      data.color,
      data.size,
      data.purchaseOrderType,
      data.supplierUnitId,
    )
    const effectiveCum = mode === 'EXTRA' ? cumAll : cumInStandard
    if (mode === 'STANDARD') {
      qty = Math.max(0, Math.min(qty, reportableQty))
    }

    return {
      lineId: key,
      groupKey: key,
      articleName,
      articleCode: null,
      alternativeName: null,
      isRequired: true,
      poCode: null,
      color: data.color,
      materialSize: data.size,
      uom: 'PCS',
      sourceOperation: context.previousOperation ?? undefined,
      rowKind: 'leaf' as const,
      poId: null,
      type: 'SEMI_FINISHED_PRODUCT' as const,
      purchaseOrderType: data.purchaseOrderType,
      totalConsumption: data.totalQty,
      cumulativeReported: cumRequired,
      reportableQty,
      cumulativeReceivedInStandard: cumInStandard,
      cumulativeReceivedAll: cumAll,
      effectiveCumulativeReceived: effectiveCum,
      requiredQty: qty,
      supplierUnitId: supplierId,
      supplierOptions: rowSupplierOptions,
      creatorNote,
      isEdited: ov?.qty !== undefined || (ov?.creatorNote ?? '') !== '',
      mode,
    }
  })
}

/**
 * Merges lineRows with overrides and context data to build the final list of rows
 */
function buildFinalRows(
  lineRows: LineRow[],
  overrides: Record<string, { qty?: number; supplierId?: string; creatorNote?: string }>,
  context: KanbanContextVm,
  supplierOptionsWarehouse: SupplierOption[],
  mode: 'INFO' | 'STANDARD' | 'EXTRA',
): TableRow[] {
  const cumulativeBuckets = getContextCumulativeBuckets(context)
  const rows: TableRow[] = []

  lineRows.forEach((lr) => {
    const ov = overrides[lr.lineId]

    const totalCons =
      context.bomConsumption.find(
        (c) => c.article === lr.articleName && c.color === lr.color && c.size === lr.materialSize,
      )?.totalQty ?? 0

    const cumInStandard = findCumulative(
      cumulativeBuckets.inStandard,
      lr.articleName,
      lr.color,
      lr.materialSize,
    )
    const cumRequired = findCumulative(
      context.cumulativeReported,
      lr.articleName,
      lr.color,
      lr.materialSize,
    )
    const reportableQty = Math.max(0, totalCons - cumRequired)
    const cumAll = findCumulative(cumulativeBuckets.all, lr.articleName, lr.color, lr.materialSize)
    const effectiveCum = mode === 'EXTRA' ? cumAll : cumInStandard

    let qty: number
    if (lr.rowKind === 'parent') {
      qty = 0
    } else {
      qty = ov?.qty !== undefined ? ov.qty : (lr.requiredQty ?? 0)
      if (mode === 'STANDARD') {
        qty = Math.max(0, Math.min(qty, reportableQty))
      }
    }

    const rowSupplierOptions = supplierOptionsWarehouse
    const supplierId = pickDefaultSupplierId(
      ov?.supplierId,
      lr.recipientId ?? undefined,
      rowSupplierOptions,
    )
    const creatorNote = ov?.creatorNote ?? ''

    rows.push({
      ...lr,
      type: 'MATERIAL',
      totalConsumption: totalCons,
      cumulativeReported: cumRequired,
      reportableQty,
      cumulativeReceivedInStandard: cumInStandard,
      cumulativeReceivedAll: cumAll,
      effectiveCumulativeReceived: effectiveCum,
      requiredQty: qty,
      supplierUnitId: supplierId,
      supplierOptions: rowSupplierOptions,
      creatorNote,
      isEdited: ov?.qty !== undefined || (ov?.creatorNote ?? '') !== '',
      mode,
    })
  })

  return rows
}

function groupKanbanRequirements(entries: TeamMaterialRequirement[]): LineRequirementRow[] {
  const map = new Map<string, LineRequirementRow>()

  for (const entry of entries) {
    const key = `${entry.articleName}::${entry.materialColor}::${entry.materialSize}`
    const existing = map.get(key)

    if (existing) {
      existing.qty += entry.qty
      continue
    }

    map.set(key, {
      articleName: entry.articleName,
      articleCode: entry.articleCode,
      alternativeName: entry.alternativeName,
      isRequired: entry.isRequired,
      materialColor: entry.materialColor,
      materialSize: entry.materialSize,
      qty: entry.qty,
      uom: entry.uom,
      sourceOperation: entry.sourceOperation,
    })
  }

  return Array.from(map.values())
}

export function useKanbanGridData({
  mode,
  planItems,
  assignment,
  bomData,
  context,
  supplierOptionsWarehouse,
  supplierOptionsTeam,
}: UseKanbanGridDataParams) {
  const isCutting = computed(() => assignment.value.operation === 'CUT-1')

  const planEntries = computed<TeamMaterialRequirement[]>(() => {
    if (mode.value === 'EXTRA' || mode.value === 'INFO') return []

    const products: TeamMaterialProduct[] = planItems.value.map((p) => ({
      poId: p.purchaseOrderId,
      destination: assignment.value.purchaseOrderDestinations[p.purchaseOrderId] ?? '',
      color: p.color,
      size: p.size,
      qty: p.qty,
    }))

    const materialEntries = calculateTeamMaterialRequirements(
      products,
      bomData.value,
      isCutting.value ? 'color' : 'size',
    )

    materialEntries.forEach((e) => {
      e.lineType = 'NPL'
    })

    return materialEntries
  })

  const planRequirements = computed(() => groupKanbanRequirements(planEntries.value))
  const purchaseOrderCodes = computed(() => assignment.value.purchaseOrderCodes)

  const bomLineByArticle = computed(() =>
    Object.fromEntries(bomData.value.lines.map((l) => [l.articleName, l])),
  )

  const { lineRows, toggleExpand } = useKanbanLineRows({
    planRequirements,
    planEntries,
    purchaseOrderCodes,
  })

  const overrides = ref<
    Record<string, { qty?: number; supplierId?: string; creatorNote?: string }>
  >({})

  watch(
    planItems,
    () => {
      const newOverrides: Record<
        string,
        { qty?: number; supplierId?: string; creatorNote?: string }
      > = {}
      for (const [key, val] of Object.entries(overrides.value)) {
        newOverrides[key] = {
          ...(val.qty !== undefined ? { qty: val.qty } : {}),
          ...(val.supplierId ? { supplierId: val.supplierId } : {}),
          ...(val.creatorNote !== undefined ? { creatorNote: val.creatorNote } : {}),
        }
      }
      overrides.value = newOverrides
    },
    { deep: true },
  )

  const tableRows = computed<TableRow[]>(() => {
    const materialScaffold = buildMaterialScaffold(
      context.value,
      overrides.value,
      bomLineByArticle.value,
      supplierOptionsWarehouse.value,
      mode.value,
    )

    const btpScaffold = buildBtpScaffold(
      context.value,
      overrides.value,
      supplierOptionsTeam.value,
      mode.value,
      planItems.value,
    )

    const scaffoldRows = [...materialScaffold, ...btpScaffold]

    if (mode.value === 'EXTRA' || mode.value === 'INFO') {
      return scaffoldRows
    }

    const rows = buildFinalRows(
      lineRows.value.filter((row) => !row.articleName.startsWith('BTP ')),
      overrides.value,
      context.value,
      supplierOptionsWarehouse.value,
      mode.value,
    )

    // In STANDARD mode, we show items that either still have qty > 0
    // or were explicitly edited by the user. This keeps rows visible after
    // the user changes a value from > 0 to 0, while still hiding rows that
    // were never populated and remain at 0.
    const activeGroupKeys = new Set(
      lineRows.value
        .filter((lr) => {
          if (lr.rowKind === 'parent') return false
          const ov = overrides.value[lr.lineId]
          const isEdited = ov?.qty !== undefined || (ov?.creatorNote ?? '') !== ''
          const originalQty = lr.requiredQty ?? 0
          return originalQty > 0 || isEdited
        })
        .map((lr) => lr.groupKey),
    )

    return [
      ...rows.filter((r) => activeGroupKeys.has(r.groupKey)),
      ...btpScaffold.filter((row) => row.requiredQty > 0 || row.isEdited),
    ]
  })

  function onQtyChange(lineId: string, val: number | null) {
    const current = overrides.value[lineId] || {}
    overrides.value = {
      ...overrides.value,
      [lineId]: { ...current, qty: val ?? 0 },
    }
  }

  function onSupplierChange(lineId: string, val: string) {
    const current = overrides.value[lineId] || {}
    overrides.value = {
      ...overrides.value,
      [lineId]: { ...current, supplierId: val },
    }
  }

  function onCreatorNoteChange(lineId: string, val: string) {
    const current = overrides.value[lineId] || {}
    overrides.value = {
      ...overrides.value,
      [lineId]: { ...current, creatorNote: val },
    }
  }

  return {
    tableRows,
    toggleExpand,
    onQtyChange,
    onSupplierChange,
    onCreatorNoteChange,
  }
}
