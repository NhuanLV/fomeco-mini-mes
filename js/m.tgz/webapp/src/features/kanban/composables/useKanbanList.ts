import { computed, onMounted, reactive, shallowRef, watch } from 'vue'
import { useQuery } from '@pinia/colada'
import {
  findCreatedKanbansQuery,
  findEvaluateKanbansQuery,
  findIssueMaterialKanbansQuery,
  findPrepareMaterialKanbansQuery,
} from '@/api/@pinia/colada.gen'
import type { FindCreatedKanbansData, PermissionVm } from '@/api'
import type { TablePageEvent } from '@/shared/types/table'
import { client } from '@/api/client.gen'

type PermissionCode = PermissionVm['code']
type TabValue = 'created' | 'evaluate' | 'prepare' | 'issue' | 'pending_receive' | 'completed'
type KanbanQuery = NonNullable<FindCreatedKanbansData['query']> & {
  styleName?: string[]
  productionOrderCode?: string[]
  kanbanCode?: string[]
  hasPlan?: boolean
  statuses?: string[]
  teamIds?: string[]
  pendingReceiveOnly?: boolean
}

import { useRoute, useRouter } from 'vue-router'

export const toSinglePlanFilter = (values: boolean[]) =>
  values.length === 1 ? values[0] : undefined

const VALID_KANBAN_TABS: TabValue[] = [
  'created',
  'evaluate',
  'prepare',
  'issue',
  'pending_receive',
  'completed',
]

export function useKanbanList(hasPermission: (code: PermissionCode, unitId?: string) => boolean) {
  const route = useRoute()
  const router = useRouter()

  const initialTab = route?.query?.tab as TabValue | undefined
  const activeTab = shallowRef<TabValue>(
    initialTab && VALID_KANBAN_TABS.includes(initialTab) ? initialTab : 'created',
  )

  watch(activeTab, (newTab) => {
    if (route?.query?.tab !== newTab) {
      void router?.replace({ query: { ...route.query, tab: newTab } })
    }
  })

  if (route) {
    watch(
      () => route.query.tab,
      (newTabQuery) => {
        const tabVal = newTabQuery as TabValue
        if (VALID_KANBAN_TABS.includes(tabVal) && tabVal !== activeTab.value) {
          activeTab.value = tabVal
        }
      },
    )
  }
  const filters = reactive({
    page: 0,
    size: 20,
    styleName: [] as string[],
    productionOrderCode: [] as string[],
    kanbanCode: [] as string[],
    hasPlan: [] as boolean[],
    statuses: [] as string[],
    teamIds: [] as string[],
  })

  const counters = reactive({
    created: 0,
    pending_receive: 0,
    completed: 0,
    evaluate: 0,
    prepare: 0,
    issue: 0,
  })

  const filterOptions = reactive({
    styleNames: [] as string[],
    productionOrderCodes: [] as string[],
    kanbanCodes: [] as string[],
    teams: [] as { id: string; name: string }[],
  })

  const fetchFilterOptions = async () => {
    try {
      const res = await client.get({
        url: '/api/kanban/filter-options',
        query: { tab: activeTab.value },
      })
      if (res.data) {
        Object.assign(filterOptions, res.data)
      }
    } catch (e) {
      console.error('Failed to fetch filter options', e)
    }
  }

  // Watch filters (except page) to reset page to 0
  watch(
    () => [
      filters.styleName,
      filters.productionOrderCode,
      filters.kanbanCode,
      filters.hasPlan,
      filters.statuses,
      filters.teamIds,
    ],
    () => {
      filters.page = 0
    },
  )

  const fetchCounters = async () => {
    try {
      const res = await client.get({
        url: '/api/kanban/created/counters',
        query: {
          styleName: filters.styleName?.length ? filters.styleName : undefined,
          productionOrderCode: filters.productionOrderCode?.length
            ? filters.productionOrderCode
            : undefined,
          kanbanCode: filters.kanbanCode?.length ? filters.kanbanCode : undefined,
          hasPlan: toSinglePlanFilter(filters.hasPlan),
          statuses: filters.statuses?.length ? filters.statuses : undefined,
          teamIds: filters.teamIds?.length ? filters.teamIds : undefined,
        },
      })
      if (res.data) {
        Object.assign(counters, res.data)
      }
    } catch (e) {
      console.error('Failed to fetch counters', e)
    }
  }

  watch(
    () => [
      filters.styleName,
      filters.productionOrderCode,
      filters.kanbanCode,
      filters.hasPlan,
      filters.statuses,
      filters.teamIds,
    ],
    () => {
      void fetchCounters()
    },
    { deep: true },
  )

  const queryParams = computed(() => {
    return {
      page: filters.page,
      size: filters.size,
      styleName: filters.styleName?.length ? filters.styleName : undefined,
      productionOrderCode: filters.productionOrderCode?.length
        ? filters.productionOrderCode
        : undefined,
      kanbanCode: filters.kanbanCode?.length ? filters.kanbanCode : undefined,
      hasPlan: toSinglePlanFilter(filters.hasPlan),
      statuses: filters.statuses?.length ? filters.statuses : undefined,
      teamIds: filters.teamIds?.length ? filters.teamIds : undefined,
      pendingReceiveOnly: activeTab.value === 'pending_receive' ? true : undefined,
    } as KanbanQuery
  })

  const queryStatuses = computed(() => {
    if (activeTab.value === 'completed') return ['COMPLETED'] as KanbanQuery['statuses']
    return queryParams.value.statuses
  })

  const createdQueryParams = computed<KanbanQuery>(() => ({
    ...queryParams.value,
    statuses: queryStatuses.value,
  }))

  const completedWarehouseQueryParams = computed<KanbanQuery>(() => ({
    ...queryParams.value,
    statuses: ['COMPLETED'],
  }))

  const { data: createdResponse, isPending: createdPending } = useQuery(() => ({
    ...findCreatedKanbansQuery({
      query: createdQueryParams.value,
    }),
    enabled:
      ['created', 'pending_receive', 'completed'].includes(activeTab.value) &&
      hasPermission('CREATE_KANBAN'),
  }))

  const { data: evaluateResponse, isPending: evaluatePending } = useQuery(() => ({
    ...findEvaluateKanbansQuery({ query: queryParams.value }),
    enabled:
      activeTab.value === 'evaluate' &&
      (hasPermission('EVALUATE_KANBAN') || hasPermission('EVALUATE_EXTRA_KANBAN')),
  }))

  const { data: issueResponse, isPending: issuePending } = useQuery(() => ({
    ...findIssueMaterialKanbansQuery({ query: queryParams.value }),
    enabled: activeTab.value === 'issue' && hasPermission('ISSUE_MATERIAL'),
  }))

  const { data: warehouseCompletedResponse, isPending: warehouseCompletedPending } = useQuery(
    () => ({
      ...findIssueMaterialKanbansQuery({
        query: completedWarehouseQueryParams.value,
      }),
      enabled:
        activeTab.value === 'completed' &&
        !hasPermission('CREATE_KANBAN') &&
        (hasPermission('ISSUE_MATERIAL') || hasPermission('PREPARE_MATERIAL')),
    }),
  )

  const { data: prepareResponse, isPending: preparePending } = useQuery(() => ({
    ...findPrepareMaterialKanbansQuery({ query: queryParams.value }),
    enabled: activeTab.value === 'prepare' && hasPermission('PREPARE_MATERIAL'),
  }))

  const currentResponse = computed(() => {
    switch (activeTab.value) {
      case 'created':
      case 'pending_receive':
      case 'completed':
        if (!hasPermission('CREATE_KANBAN')) return warehouseCompletedResponse.value
        return createdResponse.value
      case 'evaluate':
        return evaluateResponse.value
      case 'prepare':
        return prepareResponse.value
      case 'issue':
        return issueResponse.value
      default:
        return null
    }
  })

  const kanbans = computed(() => currentResponse.value?.content ?? [])
  const totalRecords = computed(() => currentResponse.value?.page?.totalElements ?? 0)
  const loading = computed(() => {
    switch (activeTab.value) {
      case 'created':
      case 'pending_receive':
      case 'completed':
        if (!hasPermission('CREATE_KANBAN')) return warehouseCompletedPending.value
        return createdPending.value
      case 'evaluate':
        return evaluatePending.value
      case 'prepare':
        return preparePending.value
      case 'issue':
        return issuePending.value
      default:
        return false
    }
  })

  watch(activeTab, () => {
    filters.page = 0
    void fetchFilterOptions()
  })

  function handlePageChange(event: TablePageEvent) {
    filters.page = event.page || 0
    filters.size = event.rows
  }

  function clearFilters() {
    filters.styleName = []
    filters.productionOrderCode = []
    filters.kanbanCode = []
    filters.hasPlan = []
    filters.statuses = []
    filters.teamIds = []
  }

  const planOptions = [
    { label: 'Trong định mức', value: true },
    { label: 'Ngoài định mức', value: false },
  ]

  const statusOptions = [
    { label: 'Chờ duyệt', value: 'PENDING_EVALUATION' },
    { label: 'Chờ duyệt bổ sung', value: 'PENDING_EXTRA_EVALUATION' },
    { label: 'Đã duyệt', value: 'APPROVED' },
    { label: 'Đã từ chối', value: 'REJECTED' },
    { label: 'Đã cấp phát một phần', value: 'PARTIALLY_ISSUED' },
    { label: 'Hoàn tất', value: 'COMPLETED' },
  ]

  onMounted(() => {
    const tabFromQuery = route?.query?.tab as TabValue | undefined
    if (tabFromQuery && VALID_KANBAN_TABS.includes(tabFromQuery)) {
      activeTab.value = tabFromQuery
    } else if (!hasPermission('CREATE_KANBAN')) {
      if (hasPermission('EVALUATE_KANBAN') || hasPermission('EVALUATE_EXTRA_KANBAN')) {
        activeTab.value = 'evaluate'
      } else if (hasPermission('PREPARE_MATERIAL')) activeTab.value = 'prepare'
      else if (hasPermission('ISSUE_MATERIAL')) activeTab.value = 'issue'
    }
    void fetchCounters()
    void fetchFilterOptions()
  })

  return {
    activeTab,
    filters,
    kanbans,
    totalRecords,
    loading,
    handlePageChange,
    counters,
    filterOptions,
    planOptions,
    statusOptions,
    clearFilters,
  }
}
