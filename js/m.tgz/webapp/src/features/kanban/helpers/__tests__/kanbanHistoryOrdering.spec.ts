import { expect, it } from 'vitest'
import { sortKanbanHistoryDetail } from '../kanbanHistoryOrdering'

it('orders history quantities by material name and BTP API variants, including old SKUs', () => {
  const detail = {
    'Vải / Blue / M': '1',
    'BTP CUT-1 / Blue / S / Hàng thường': '2',
    'BTP CUT-1 / Red / M / Hàng dương': '3',
    'BTP CUT-1 / Red / S': '4',
    'Chỉ / Red / S': '5',
  }
  const rows = sortKanbanHistoryDetail(detail, [], ['Red', 'Blue'], ['S', 'M'])
  expect(rows.map((row) => row.label)).toEqual([
    'BTP CUT-1 / Red / S',
    'BTP CUT-1 / Red / M / Hàng dương',
    'BTP CUT-1 / Blue / S / Hàng thường',
    'Chỉ / Red / S',
    'Vải / Blue / M',
  ])
  expect(rows.map((row) => row.quantity)).toEqual(['4', '3', '2', '5', '1'])
  expect(Object.keys(detail)[0]).toBe('Vải / Blue / M')
})

it('uses structured items for labels containing separators and alphabet for unstructured labels', () => {
  const items = [
    { article: 'BTP CUT-1', color: 'Red / White', size: 'S' },
    { article: 'BTP CUT-1', color: 'Blue', size: 'S' },
  ]
  const rows = sortKanbanHistoryDetail(
    {
      'BTP CUT-1 / Blue / S': '1',
      'BTP CUT-1 / Red / White / S': '2',
      Z: '3',
      A: '4',
    },
    items,
    ['Red / White', 'Blue'],
    ['S'],
  )
  expect(rows.map((row) => row.quantity)).toEqual(['4', '2', '1', '3'])
})
