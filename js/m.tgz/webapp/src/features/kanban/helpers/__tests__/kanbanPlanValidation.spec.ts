import type { KanbanContextVm } from '@/api/types.gen'
import {
  hasInvalidStandardPlanDemand,
  isOutOfReportableQty,
} from '@/features/kanban/helpers/kanbanPlanValidation'
import { describe, expect, it } from 'vitest'

function makeContext(overrides?: Partial<KanbanContextVm>): KanbanContextVm {
  return {
    teamAssignmentId: 'assignment-1',
    bomConsumption: [
      {
        article: 'Fabric',
        color: 'Red',
        size: 'S',
        totalQty: 100,
      },
    ],
    btpLines: [],
    cumulativeReported: [],
    cumulativeReceivedInStandard: [],
    cumulativeReceivedAll: [],
    requiredPlan: [],
    previousOperation: undefined,
    availableWarehouses: [],
    previousOperationTeams: [],
    ...overrides,
  }
}

describe('isOutOfReportableQty', () => {
  it('checks exhausted BTP demand separately by type and supplier', () => {
    const context = makeContext({
      bomConsumption: [],
      previousOperation: 'CUT-1',
      btpLines: [
        {
          color: 'Red',
          size: 'S',
          purchaseOrderId: 'po-1',
          purchaseOrderCode: 'PO-1',
          purchaseOrderType: 'REGULAR',
          supplierUnitId: 'team-a',
          allocationQty: 60,
        },
        {
          color: 'Red',
          size: 'S',
          purchaseOrderId: 'po-2',
          purchaseOrderCode: 'PO-2',
          purchaseOrderType: 'REGULAR',
          supplierUnitId: 'team-b',
          allocationQty: 40,
        },
        {
          color: 'Red',
          size: 'S',
          purchaseOrderId: 'po-3',
          purchaseOrderCode: 'PO-3',
          purchaseOrderType: 'POSITIVE',
          supplierUnitId: 'team-a',
          allocationQty: 10,
        },
      ],
      cumulativeReported: [
        {
          article: 'BTP CUT-1',
          color: 'Red',
          size: 'S',
          purchaseOrderType: 'REGULAR',
          supplierUnitId: 'team-a',
          cumulativeReported: 60,
        },
        {
          article: 'BTP CUT-1',
          color: 'Red',
          size: 'S',
          purchaseOrderType: 'REGULAR',
          supplierUnitId: 'team-b',
          cumulativeReported: 40,
        },
        {
          article: 'BTP CUT-1',
          color: 'Red',
          size: 'S',
          purchaseOrderType: 'POSITIVE',
          supplierUnitId: 'team-a',
          cumulativeReported: 10,
        },
      ],
    })
    expect(isOutOfReportableQty(context)).toBe(true)
    context.cumulativeReported[0]!.cumulativeReported = 70
    context.cumulativeReported[2]!.cumulativeReported = 0
    expect(isOutOfReportableQty(context)).toBe(false)
    context.cumulativeReported[0]!.cumulativeReported = 100
    context.cumulativeReported[1]!.cumulativeReported = 0
    context.cumulativeReported[2]!.cumulativeReported = 10
    expect(isOutOfReportableQty(context)).toBe(false)
  })

  it('returns false when context is null or undefined', () => {
    expect(isOutOfReportableQty(null)).toBe(false)
    expect(isOutOfReportableQty(undefined)).toBe(false)
  })

  it('returns false when there are no materials and no BTP lines', () => {
    const context = makeContext({
      bomConsumption: [],
      btpLines: [],
      previousOperation: undefined,
    })
    expect(isOutOfReportableQty(context)).toBe(false)
  })

  it('returns false when some materials still have reportable quantity', () => {
    const context = makeContext({
      bomConsumption: [
        { article: 'Fabric', color: 'Red', size: 'S', totalQty: 100 },
        { article: 'Button', color: 'White', size: 'S', totalQty: 50 },
      ],
      cumulativeReported: [
        { article: 'Fabric', color: 'Red', size: 'S', cumulativeReported: 100 },
        { article: 'Button', color: 'White', size: 'S', cumulativeReported: 30 },
      ],
    })
    expect(isOutOfReportableQty(context)).toBe(false)
  })

  it('returns true when all materials have reportable quantity exhausted', () => {
    const context = makeContext({
      bomConsumption: [
        { article: 'Fabric', color: 'Red', size: 'S', totalQty: 100 },
        { article: 'Button', color: 'White', size: 'S', totalQty: 50 },
      ],
      cumulativeReported: [
        { article: 'Fabric', color: 'Red', size: 'S', cumulativeReported: 100 },
        { article: 'Button', color: 'White', size: 'S', cumulativeReported: 50 },
      ],
    })
    expect(isOutOfReportableQty(context)).toBe(true)
  })

  it('returns false when materials are exhausted but BTP still has reportable quantity', () => {
    const context = makeContext({
      previousOperation: 'CUT-1',
      bomConsumption: [{ article: 'Fabric', color: 'Red', size: 'S', totalQty: 100 }],
      btpLines: [
        {
          color: 'Red',
          size: 'S',
          purchaseOrderId: 'po-1',
          purchaseOrderType: 'REGULAR',
          purchaseOrderCode: 'PO-1',
          allocationQty: 40,
        },
      ],
      cumulativeReported: [
        { article: 'Fabric', color: 'Red', size: 'S', cumulativeReported: 100 },
        { article: 'BTP CUT-1', color: 'Red', size: 'S', cumulativeReported: 20 },
      ],
    })
    expect(isOutOfReportableQty(context)).toBe(false)
  })

  it('returns true when both materials and BTP have reportable quantity exhausted', () => {
    const context = makeContext({
      previousOperation: 'CUT-1',
      bomConsumption: [{ article: 'Fabric', color: 'Red', size: 'S', totalQty: 100 }],
      btpLines: [
        {
          color: 'Red',
          size: 'S',
          purchaseOrderId: 'po-1',
          purchaseOrderType: 'REGULAR',
          purchaseOrderCode: 'PO-1',
          allocationQty: 40,
        },
      ],
      cumulativeReported: [
        { article: 'Fabric', color: 'Red', size: 'S', cumulativeReported: 100 },
        { article: 'BTP CUT-1', color: 'Red', size: 'S', cumulativeReported: 40 },
      ],
    })
    expect(isOutOfReportableQty(context)).toBe(true)
  })
})

describe('hasInvalidStandardPlanDemand', () => {
  it('returns false if planItems is empty', () => {
    expect(hasInvalidStandardPlanDemand([], [], [])).toBe(false)
  })

  it('validates plan demand against matrix rows remaining capacity', () => {
    const matrixRows = [
      {
        purchaseOrderId: 'po-1',
        color: 'Red',
        data: {
          S: { current: 30, limit: 100 },
        },
      },
    ]

    expect(
      hasInvalidStandardPlanDemand(
        [{ purchaseOrderId: 'po-1', color: 'Red', size: 'S', qty: 70 }],
        matrixRows,
        ['S'],
      ),
    ).toBe(false)

    expect(
      hasInvalidStandardPlanDemand(
        [{ purchaseOrderId: 'po-1', color: 'Red', size: 'S', qty: 71 }],
        matrixRows,
        ['S'],
      ),
    ).toBe(true)
  })
})
