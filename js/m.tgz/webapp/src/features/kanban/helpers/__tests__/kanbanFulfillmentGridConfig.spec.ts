import { buildColumns } from '@/features/kanban/helpers/kanbanFulfillmentGridConfig'
import { describe, expect, it } from 'vitest'

const options = {
  reviseMode: false,
  canShowPrepare: false,
  canShowIssue: false,
  canShowReceive: false,
  canEditSupplierNote: false,
  receiveOnlyMode: false,
  showStockColumn: false,
}

describe('Kanban fulfillment columns', () => {
  it.each(['APPROVED', 'PARTIALLY_ISSUED', 'COMPLETED'])(
    'keeps actual issued quantity in %s when no fulfillment actions remain',
    (kanbanStatus) => {
      const columns = buildColumns({ ...options, kanbanStatus })

      expect(columns.find((column) => column.prop === 'actualIssuedQty')).toMatchObject({
        name: 'SL thực xuất',
        columnType: 'status',
        readonly: true,
      })
      expect(columns.some((column) => column.prop === 'receive')).toBe(false)
    },
  )

  it.each(['PENDING_EVALUATION', 'PENDING_EXTRA_EVALUATION', 'REJECTED'])(
    'does not show actual issued quantity before fulfillment in %s',
    (kanbanStatus) => {
      const columns = buildColumns({ ...options, kanbanStatus })

      expect(columns.some((column) => column.prop === 'actualIssuedQty')).toBe(false)
    },
  )
})
