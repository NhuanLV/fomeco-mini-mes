import type { GridColumn, GridRow } from '@/shared/composables/useGridLayout'

export type KanbanGridMode = 'INFO' | 'STANDARD' | 'EXTRA'

export function buildColumns(mode: KanbanGridMode = 'STANDARD'): GridColumn[] {
  const columns: GridColumn[] = [
    {
      prop: 'articleName',
      name: 'Tên NPL / BTP',
      columnType: 'article',
      readonly: true,
    },
    {
      prop: 'purchaseOrderType',
      name: 'Loại PO',
      readonly: true,
      cellTemplate: (h, { model }) =>
        model.purchaseOrderType
          ? h(
              'span',
              {
                class: [
                  'rounded px-2 py-1 text-xs',
                  model.purchaseOrderType === 'POSITIVE'
                    ? 'bg-info/10 text-info'
                    : 'bg-success/10 text-success',
                ],
              },
              model.purchaseOrderType === 'POSITIVE' ? 'Hàng dương' : 'Hàng thường',
            )
          : '',
    },
    {
      prop: 'alternativeName',
      name: 'Tên thay thế',
      readonly: true,
    },
    {
      prop: 'uom',
      name: 'ĐVT',
      readonly: true,
    },
    {
      prop: 'color',
      name: 'Màu',
      readonly: true,
    },
    {
      prop: 'materialSize',
      name: 'Cỡ',
      readonly: true,
    },
    {
      prop: 'bom',
      name: 'Định mức',
      columnType: 'bom',
      readonly: true,
      size: 100,
    },
    {
      prop: 'totalConsumption',
      name: 'Tổng nhu cầu',
      readonly: true,
      columnType: 'qty',
      cellClass: 'text-right',
    },
    {
      prop: 'effectiveCumulativeReceived',
      name: 'Lũy kế thực nhận',
      readonly: true,
      columnType: 'qty',
    },
  ]

  if (mode !== 'EXTRA') {
    columns.push({
      prop: 'reportableQty',
      name: 'SL có thể báo',
      readonly: true,
      columnType: 'qty',
      cellClass: 'text-right',
    })
  }

  if (mode !== 'INFO') {
    columns.push(
      {
        prop: 'requiredQty',
        name: 'SL nhu cầu',
        columnType: 'qty',
      },
      {
        prop: 'creatorNote',
        name: 'Ghi chú (nơi tạo)',
        columnType: 'note',
      },
      {
        prop: 'supplierUnitId',
        name: 'Nơi cấp phát',
        columnType: 'supplier',
      },
    )
  }

  columns.push({
    prop: 'isRequired',
    name: 'NPL bắt buộc',
    columnType: 'required',
    readonly: true,
    size: 120,
  })

  columns.push({
    prop: 'articleCode',
    name: 'Mã NPL',
    readonly: true,
  })

  return columns
}

export function buildDisplayRows(
  allSupplierOptions: Array<{ label: string; value: string }>,
): (rows: GridRow[]) => GridRow[] {
  return (rows) =>
    rows.map((row) => ({
      ...row,
      supplierUnitId:
        allSupplierOptions.find((o) => String(o.value) === String(row.supplierUnitId))?.label ??
        String(row.supplierUnitId ?? ''),
    }))
}
