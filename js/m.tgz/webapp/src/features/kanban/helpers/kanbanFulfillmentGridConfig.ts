import type { GridColumn } from '@/shared/composables/useGridLayout'

export function buildColumns({
  reviseMode,
  kanbanStatus,
  canShowPrepare,
  canShowIssue,
  canShowReceive,
  canEditSupplierNote,
  receiveOnlyMode,
  showStockColumn,
}: {
  reviseMode: boolean
  kanbanStatus?: string
  canShowPrepare: boolean
  canShowIssue: boolean
  canShowReceive: boolean
  canEditSupplierNote: boolean
  receiveOnlyMode: boolean
  showStockColumn: boolean
}): GridColumn[] {
  const isPreApproval =
    kanbanStatus === 'PENDING_EVALUATION' ||
    kanbanStatus === 'PENDING_EXTRA_EVALUATION' ||
    kanbanStatus === 'REJECTED' ||
    reviseMode

  const showSupplierNote = !isPreApproval && (canShowReceive || canEditSupplierNote)

  const cols: GridColumn[] = [
    { prop: 'article', name: 'NPL / BTP', readonly: true },
    {
      prop: 'purchaseOrderType',
      name: 'Loại PO',
      readonly: true,
      cellTemplate: (h, { model }) =>
        model.purchaseOrderType
          ? h(
              'span',
              {
                class: [
                  'rounded px-2 py-1 text-xs',
                  model.purchaseOrderType === 'POSITIVE'
                    ? 'bg-info/10 text-info'
                    : 'bg-success/10 text-success',
                ],
              },
              model.purchaseOrderType === 'POSITIVE' ? 'Hàng dương' : 'Hàng thường',
            )
          : '',
    },
    { prop: 'alternativeName', name: 'Tên thay thế', readonly: true },
    { prop: 'uom', name: 'ĐVT', readonly: true },
    {
      prop: 'purchaseOrderCode',
      name: 'Mã PO',
      readonly: true,
    },
    { prop: 'color', name: 'Màu', readonly: true },
    { prop: 'size', name: 'Cỡ', readonly: true },
    {
      prop: 'totalConsumption',
      name: 'Tổng nhu cầu',
      columnType: 'qty',
      readonly: true,
    },
  ]

  if (reviseMode) {
    cols.push({
      prop: 'reviseQty',
      name: 'SL nhu cầu',
      columnType: 'reviseQty',
      readonly: false,
    })
  } else {
    if (showStockColumn) {
      cols.push({
        prop: 'stockQty',
        name: 'SL tồn',
        columnType: 'qty',
        readonly: true,
        cellClass: 'font-bold',
      })
    }
    cols.push({
      prop: 'requiredQty',
      name: 'SL nhu cầu',
      columnType: 'qty',
      readonly: true,
      cellClass: 'font-bold',
    })
    if (!isPreApproval || receiveOnlyMode || canShowPrepare || canShowIssue) {
      cols.push({
        prop: 'actualIssuedQty',
        name: 'SL thực xuất',
        columnType: 'status',
        readonly: true,
      })
    }
    if (canShowPrepare) {
      cols.push({
        prop: 'prepareInput',
        name: 'Chuẩn bị thêm',
        columnType: 'prepare',
        readonly: false,
      })
    }
    if (canShowIssue) {
      cols.push({ prop: 'issue', name: 'Xuất kho', columnType: 'issue', readonly: true })
    }
    if (canShowReceive) {
      cols.push({
        prop: 'receive',
        name: 'Đã nhận',
        columnType: 'receive',
        readonly: false,
      })
    }
  }

  cols.push({
    prop: 'creatorNote',
    name: 'Ghi chú (nơi tạo)',
    columnType: reviseMode ? 'note' : undefined,
    readonly: !reviseMode,
  })
  if (showSupplierNote) {
    cols.push({
      prop: 'supplierNote',
      name: 'Ghi chú (nơi cấp)',
      columnType: reviseMode ? undefined : canEditSupplierNote ? 'note' : undefined,
      readonly: reviseMode ? true : !canEditSupplierNote,
    })
  }

  cols.push({
    prop: 'supplierName',
    name: 'Đơn vị cung cấp',
    readonly: true,
  })

  cols.push({
    prop: 'articleCode',
    name: 'Mã NPL',
    readonly: true,
  })

  return cols
}
