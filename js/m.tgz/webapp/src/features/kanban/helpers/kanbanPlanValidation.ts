import type { KanbanContextVm, PlanItem } from '@/api/types.gen'
import type { MatrixData, MatrixRow } from '@/shared/types'

export function hasInvalidStandardPlanDemand(
  planItems: PlanItem[],
  matrixRows: MatrixRow[],
  allSizes: string[],
): boolean {
  if (!planItems.length) return false

  const remainingByKey = new Map<string, number>()
  matrixRows.forEach((row) => {
    allSizes.forEach((size) => {
      const val = row.data[size]
      const matrixData =
        typeof val === 'object' && val !== null
          ? (val as MatrixData)
          : ({ current: 0, limit: 0 } as MatrixData)
      const remaining = Math.max(0, matrixData.limit - matrixData.current)
      remainingByKey.set(`${row.purchaseOrderId}|${row.color}|${size}`, remaining)
    })
  })

  return planItems.some((item) => {
    const key = `${item.purchaseOrderId}|${item.color}|${item.size}`
    const remaining = remainingByKey.get(key) ?? 0
    return item.qty > remaining
  })
}

export function isOutOfReportableQty(context?: KanbanContextVm | null): boolean {
  if (!context) return false

  const hasMaterials = (context.bomConsumption?.length ?? 0) > 0
  const hasBtp = Boolean(context.previousOperation && (context.btpLines?.length ?? 0) > 0)

  if (!hasMaterials && !hasBtp) return false

  const findCumulative = (
    article: string,
    color: string,
    size: string,
    purchaseOrderType?: 'REGULAR' | 'POSITIVE',
    supplierUnitId?: string | null,
  ): number => {
    if (!context.cumulativeReported?.length) return 0
    return context.cumulativeReported
      .filter(
        (c) =>
          c.article === article &&
          c.color === color &&
          c.size === size &&
          (!purchaseOrderType || (c.purchaseOrderType ?? 'REGULAR') === purchaseOrderType) &&
          (!supplierUnitId || c.supplierUnitId === supplierUnitId),
      )
      .reduce((sum, entry) => sum + entry.cumulativeReported, 0)
  }

  const hasReportableMaterial = context.bomConsumption?.some((bc) => {
    const cum = findCumulative(bc.article, bc.color, bc.size)
    return bc.totalQty - cum > 0.0001
  })

  if (hasReportableMaterial) return false

  if (hasBtp) {
    const btpMap = new Map<string, KanbanContextVm['btpLines'][number]>()
    context.btpLines.forEach((bl) => {
      const key = `${bl.color}::${bl.size}::${bl.purchaseOrderType ?? 'REGULAR'}::${bl.supplierUnitId ?? ''}`
      const existing = btpMap.get(key)
      if (existing) {
        existing.allocationQty += bl.allocationQty
      } else {
        btpMap.set(key, { ...bl })
      }
    })

    const articleName = `BTP ${context.previousOperation}`
    for (const btp of btpMap.values()) {
      const cum = findCumulative(
        articleName,
        btp.color,
        btp.size,
        btp.purchaseOrderType ?? 'REGULAR',
        btp.supplierUnitId,
      )
      if (btp.allocationQty - cum > 0.0001) {
        return false
      }
    }
  }

  return true
}
