import { makeArticleVariantComparator } from '@/shared/utils/orderedValues'

type Variant = { article: string; color: string; size: string }

export function sortKanbanHistoryDetail(
  detail: Record<string, string>,
  items: readonly Variant[],
  colorOrder: readonly string[] = [],
  sizeOrder: readonly string[] = [],
) {
  const variants = new Map(
    items.map((item) => [`${item.article} / ${item.color} / ${item.size}`, item]),
  )
  const cmp = makeArticleVariantComparator(colorOrder, sizeOrder)
  function variant(label: string): Variant {
    const base = label.replace(/ \/ Hàng (dương|thường)$/, '')
    const known = variants.get(base)
    if (known) return known
    // The history API formats old SKU labels as article / color / size.
    const parts = base.split(' / ')
    if (parts.length < 3) return { article: base, color: '', size: '' }
    const size = parts.pop()!
    const color = parts.pop()!
    return { article: parts.join(' / '), color, size }
  }
  return Object.entries(detail)
    .map(([label, quantity]) => ({ label, quantity, variant: variant(label) }))
    .sort(
      (left, right) => cmp(left.variant, right.variant) || left.label.localeCompare(right.label),
    )
    .map(({ label, quantity }) => ({ label, quantity }))
}
