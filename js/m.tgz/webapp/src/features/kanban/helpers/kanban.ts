export type KanbanStatus =
  | 'PENDING_EVALUATION'
  | 'PENDING_EXTRA_EVALUATION'
  | 'APPROVED'
  | 'REJECTED'
  | 'PARTIALLY_ISSUED'
  | 'COMPLETED'
  | 'CANCELLED'

export const getStatusLabel = (status: KanbanStatus | string): string => {
  switch (status) {
    case 'PENDING_EVALUATION':
      return 'Chờ duyệt'
    case 'PENDING_EXTRA_EVALUATION':
      return 'Chờ duyệt (bước 2)'
    case 'APPROVED':
      return 'Đã duyệt'
    case 'REJECTED':
      return 'Từ chối'
    case 'PARTIALLY_ISSUED':
      return 'Đã cấp phát một phần'
    case 'COMPLETED':
      return 'Hoàn tất'
    case 'CANCELLED':
      return 'Đã huỷ'
    default:
      return status
  }
}

export const getStatusSeverity = (status: KanbanStatus | string): string => {
  switch (status) {
    case 'PENDING_EVALUATION':
      return 'warning'
    case 'PENDING_EXTRA_EVALUATION':
      return 'warning'
    case 'APPROVED':
      return 'success'
    case 'REJECTED':
      return 'error'
    case 'PARTIALLY_ISSUED':
      return 'info'
    case 'COMPLETED':
      return 'success'
    default:
      return 'neutral'
  }
}

export const allKanbanStatuses: Array<{ value: KanbanStatus; label: string }> = [
  { value: 'PENDING_EVALUATION', label: 'Chờ duyệt' },
  { value: 'PENDING_EXTRA_EVALUATION', label: 'Chờ duyệt (bước 2)' },
  { value: 'APPROVED', label: 'Đã duyệt' },
  { value: 'REJECTED', label: 'Từ chối' },
  { value: 'PARTIALLY_ISSUED', label: 'Đã cấp phát một phần' },
  { value: 'COMPLETED', label: 'Hoàn tất' },
  { value: 'CANCELLED', label: 'Đã huỷ' },
]
