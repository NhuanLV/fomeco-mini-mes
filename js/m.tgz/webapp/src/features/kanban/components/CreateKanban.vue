<script setup lang="ts">
import {
  getKanbanContextQuery,
  getTeamAssignmentDetailQuery,
  getTeamBomQuery,
} from '@/api/@pinia/colada.gen'
import { transformToMatrix } from '@/shared/composables/useColorSizeMatrix'
import type { MatrixInputItem } from '@/shared/types'
import { createKanban } from '@/api/sdk.gen'
import type { KanbanItem, PlanItem } from '@/api/types.gen'
import { ROUTE_PATH } from '@/app/router/path'
import { useQuery } from '@pinia/colada'
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { showError, showSuccess } from '@/shared/utils/toast'
import { sortValuesByOrder } from '@/shared/utils/orderedValues'
import {
  hasInvalidStandardPlanDemand,
  isOutOfReportableQty,
} from '@/features/kanban/helpers/kanbanPlanValidation'
import type { KanbanMode } from './create/KanbanModeSelector.vue'
import KanbanItemsGrid from './create/KanbanItemsGrid.vue'
import KanbanModeSelector from './create/KanbanModeSelector.vue'
import KanbanPlanGrid from './create/KanbanPlanGrid.vue'

const props = defineProps<{
  id: string
}>()

const router = useRouter()

const { data: assignment, isLoading: loadingAssignment } = useQuery(() =>
  getTeamAssignmentDetailQuery({ path: { id: props.id } }),
)
const { data: bomData, isLoading: loadingBom } = useQuery(() =>
  getTeamBomQuery({ path: { id: props.id } }),
)
const { data: context, isLoading: loadingContext } = useQuery(() =>
  getKanbanContextQuery({ path: { teamAssignmentId: props.id } }),
)

const isLoading = computed(
  () => loadingAssignment.value || loadingBom.value || loadingContext.value,
)
const isInitialLoading = computed(
  () => isLoading.value && (!assignment.value || !bomData.value || !context.value),
)

const mode = ref<KanbanMode>('INFO')
const planItems = ref<PlanItem[]>([])
const kanbanRows = ref<KanbanItem[]>([])
const reason = ref('')

const hasPlan = computed(() => planItems.value.some((p) => p.qty > 0))

const isFullyReported = computed(() => isOutOfReportableQty(context.value))

const allSizes = computed(() => {
  if (!assignment.value) return []
  return sortValuesByOrder(
    assignment.value.allocations.map((a) => a.size),
    assignment.value.styleSizeOrder,
  )
})

// ...
const matrixRows = computed(() => {
  if (!assignment.value) return []

  const items: MatrixInputItem[] = [
    ...assignment.value.allocations.map((a) => ({ ...a, kind: 'alloc' as const })),
    ...assignment.value.outputReportTotals.map((t) => ({ ...t, kind: 'progress' as const })),
  ]

  const purchaseOrderCodes = assignment.value.purchaseOrderCodes
  return transformToMatrix(items, allSizes.value, {
    getColor: (i) => i.color,
    getSize: (i) => i.size,
    getQuantity: (i) => {
      if (i.kind === 'alloc') {
        return { current: 0, limit: i.quantity || 0 }
      }
      if (i.kind === 'progress') return { current: i.completedQty || 0, limit: 0 }
      return { current: 0, limit: 0 }
    },
    groupBy: (i) => `${i.purchaseOrderId}|${i.color}`,
    getExtra: (i) => ({
      purchaseOrderId: i.purchaseOrderId,
      poCode:
        (i.kind === 'planned' ? (i.purchaseOrderCode as string | null) : null) ||
        purchaseOrderCodes[i.purchaseOrderId!] ||
        i.purchaseOrderId,
    }),
  })
})

const isSubmitting = ref(false)

async function submit() {
  if (assignment.value?.productionOrderStatus === 'CANCELLED') return
  if (!kanbanRows.value.length) {
    showError('Không có dữ liệu Kanban để tạo')
    return
  }

  const requestedItems = kanbanRows.value.filter((r) => r.supplierUnitId)
  if (!requestedItems.length) {
    showError('Không có dữ liệu Kanban để tạo')
    return
  }

  const zeroQtyItems = requestedItems.filter((r) => r.requiredQty <= 0)
  if (zeroQtyItems.length > 0) {
    showError('Số lượng yêu cầu của các vật tư đã chọn phải lớn hơn 0')
    return
  }

  if (
    mode.value === 'STANDARD' &&
    hasInvalidStandardPlanDemand(planItems.value, matrixRows.value, allSizes.value)
  ) {
    showError('Kế hoạch vượt tiến độ còn lại. Vui lòng sửa lại SL kế hoạch trước khi báo Kanban')
    return
  }

  if (mode.value === 'EXTRA' && !reason.value.trim()) {
    showError('Vui lòng nhập lý do báo Kanban ngoài định mức')
    return
  }

  isSubmitting.value = true
  try {
    await createKanban({
      body: {
        teamAssignmentId: props.id,
        plan: mode.value === 'STANDARD' ? planItems.value : [],
        items: requestedItems,
        reason: reason.value.trim(),
      },
    })
    showSuccess('Đã tạo Kanban')
    planItems.value = []
    reason.value = ''
    await router.push(ROUTE_PATH.KANBAN)
  } catch (e: unknown) {
    showError((e as Error)?.message || 'Có lỗi xảy ra')
  } finally {
    isSubmitting.value = false
  }
}
</script>

<template>
  <div class="flex flex-col gap-4" :class="{ 'pb-16': mode !== 'INFO' }">
    <div v-if="isInitialLoading" class="flex justify-center p-12">
      <UIcon name="i-lucide-loader-circle" class="animate-spin text-4xl text-primary" />
    </div>

    <template v-else-if="assignment?.productionOrderStatus !== 'CANCELLED'">
      <div class="flex items-center justify-between">
        <KanbanModeSelector v-model="mode" />
      </div>

      <div v-if="mode === 'INFO'" class="mt-4 rounded-lg bg-surface-0 p-4 shadow-sm">
        <h3 class="mb-4 text-lg font-semibold">Danh sách vật tư / BTP</h3>
        <KanbanItemsGrid
          v-if="assignment && context && bomData"
          mode="INFO"
          :plan-items="planItems"
          :assignment="assignment"
          :bom-data="bomData"
          :context="context"
        />
      </div>

      <div
        v-else-if="mode === 'STANDARD' && isFullyReported"
        class="mt-4 flex flex-col items-center justify-center rounded-lg bg-orange-50 py-16 text-orange-600 shadow-sm"
      >
        <UIcon name="i-lucide-triangle-alert" class="mb-4 text-5xl" />
        <p class="text-center text-xl font-semibold">
          Đã báo hết toàn bộ sản lượng,<br />vui lòng chọn báo kanban ngoài định mức
        </p>
      </div>

      <template v-else>
        <template v-if="mode === 'STANDARD'">
          <div v-if="assignment" class="rounded-lg bg-surface-0 p-4 shadow-sm">
            <h3 class="mb-4 text-lg font-semibold">Kế hoạch</h3>
            <KanbanPlanGrid v-model="planItems" :rows="matrixRows" :all-sizes="allSizes" />
          </div>
        </template>

        <div class="mt-4 rounded-lg bg-surface-0 p-4 shadow-sm">
          <h3 class="mb-4 text-lg font-semibold">Danh sách vật tư / BTP yêu cầu</h3>
          <div
            v-if="mode === 'STANDARD' && !hasPlan"
            class="flex flex-col items-center justify-center rounded-lg bg-surface-50 py-12 text-toned"
          >
            <UIcon name="i-lucide-info" class="mb-2 text-3xl" />
            <p class="text-lg">Vui lòng nhập sản lượng kế hoạch</p>
          </div>
          <KanbanItemsGrid
            v-else-if="assignment && context && bomData"
            :mode="mode"
            :plan-items="planItems"
            :assignment="assignment"
            :bom-data="bomData"
            :context="context"
            @update:rows="kanbanRows = $event"
          />

          <div class="mt-4">
            <label for="extra-note" class="mb-2 block text-sm font-medium">Ghi chú</label>
            <UTextarea
              id="extra-note"
              v-model="reason"
              :rows="4"
              class="w-full"
              autoresize
              :placeholder="mode === 'EXTRA' ? 'Nhập lý do báo Kanban ngoài định mức' : undefined"
            />
          </div>
        </div>
      </template>
    </template>
  </div>

  <div
    v-if="!isInitialLoading && mode !== 'INFO' && assignment?.productionOrderStatus !== 'CANCELLED'"
    class="fixed right-0 bottom-0 left-0 z-10 border-t border-surface-200 bg-surface-0 px-4 py-3 shadow-lg"
  >
    <div class="flex justify-end gap-3">
      <UButton label="Báo Kanban" icon="i-lucide-send" :loading="isSubmitting" @click="submit" />
    </div>
  </div>
</template>
