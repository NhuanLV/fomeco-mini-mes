<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import { rejectComma } from '@/shared/utils/numberInput'

const props = defineProps<{
  val: string | number | null | undefined
  save: (val: number | null, preventFocus?: boolean) => void
  close: (isCancel?: boolean) => void
}>()

const inputRef = ref<{ $el?: HTMLElement } | null>(null)
const val = ref<number | null>(props.val == null ? 0 : Number(props.val))
const isClosing = ref(false)

onMounted(() => {
  setTimeout(() => {
    const input = (inputRef.value as unknown as { $el: HTMLElement })?.$el?.querySelector('input')
    if (input instanceof HTMLInputElement) {
      input.focus()
    }
  }, 50)
})

function handleSave(focusNext = false) {
  if (isClosing.value) return
  isClosing.value = true
  props.save(val.value, true)
  props.close(focusNext)
}

function handleCancel() {
  if (isClosing.value) return
  isClosing.value = true
  props.close(true)
}

function handleBlur() {
  handleSave()
}

function handleKeyDown(e: KeyboardEvent) {
  if (e.key === 'Enter') {
    e.preventDefault()
    e.stopPropagation()
    handleSave(true)
  } else if (e.key === 'Escape') {
    e.preventDefault()
    e.stopPropagation()
    handleCancel()
  }
}
</script>

<template>
  <div class="flex h-full w-full items-center bg-white px-1">
    <UInput
      ref="inputRef"
      v-model.number="val"
      type="text"
      inputmode="decimal"
      min="0"
      step="0.0001"
      autofocus
      class="h-8 w-full border-none bg-transparent shadow-none"
      size="sm"
      @blur="handleBlur"
      @keydown="handleKeyDown"
      @beforeinput="rejectComma"
    />
  </div>
</template>
