<script setup lang="ts">
import { onMounted, ref, useTemplateRef } from 'vue'
import { rejectComma } from '@/shared/utils/numberInput'

const props = defineProps<{
  val: string | number | null | undefined
  save: (val: number | null, preventFocus?: boolean) => void
  close: (isCancel?: boolean) => void
}>()

const inputRef = useTemplateRef<{ $el: HTMLElement }>('inputRef')
const val = ref<number | null>(props.val == null ? 0 : Number(props.val))
const isClosing = ref(false)

onMounted(() => {
  setTimeout(() => {
    const el = inputRef.value as unknown as { $el: HTMLElement }
    el?.$el.querySelector('input')?.focus()
  }, 10)
})

function handleSave(focusNext = false) {
  if (isClosing.value) return
  isClosing.value = true
  props.save(val.value, true)
  props.close(focusNext)
}

function handleKeyDown(e: KeyboardEvent) {
  if (e.key === 'Enter') {
    e.preventDefault()
    e.stopPropagation()
    handleSave(true)
  } else if (e.key === 'Escape') {
    e.preventDefault()
    e.stopPropagation()
    if (isClosing.value) return
    isClosing.value = true
    props.close(true)
  }
}

function handleBlur() {
  handleSave()
}
</script>

<template>
  <div class="flex h-full w-full items-center bg-white px-1">
    <UInput
      ref="inputRef"
      v-model.number="val"
      type="text"
      inputmode="decimal"
      min="0"
      step="0.0001"
      size="sm"
      class="h-8 w-full border-none bg-transparent shadow-none"
      @keydown="handleKeyDown"
      @blur="handleBlur"
      @beforeinput="rejectComma"
    />
  </div>
</template>
