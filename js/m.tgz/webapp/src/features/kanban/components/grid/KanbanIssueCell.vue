<script setup lang="ts">
import type { FlatKanbanItem } from '@/features/kanban/types'
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { useAuthStore } from '@/shared/stores/auth'
import { computed } from 'vue'

import { kanbanItemKey } from '@/features/kanban/fulfillment/kanbanFulfillment'

interface Addition {
  selectedToIssue: FlatKanbanItem[]
  prepareInputs?: Record<string, number>
  onToggle: (item: FlatKanbanItem) => void
}

const props = defineProps<MatrixGridCellProps & { addition?: Addition }>()

const { hasPermission } = useAuthStore()
const model = computed(() => props.model as FlatKanbanItem)
const selectedToIssue = computed(() => props.addition?.selectedToIssue || [])

const isSelected = computed(() =>
  selectedToIssue.value.some((item) => kanbanItemKey(item) === kanbanItemKey(model.value)),
)

const isDisabled = computed(() => {
  if (!model.value) return true
  if (model.value.issued) return true
  if (!hasPermission('ISSUE_MATERIAL', model.value.supplierId)) return true
  const key = kanbanItemKey(model.value)
  const preparedQty = props.addition?.prepareInputs?.[key] || 0
  return model.value.actualIssuedQty <= 0 && preparedQty <= 0
})

function handleToggle() {
  props.addition?.onToggle(model.value)
}
</script>

<template>
  <div class="flex h-full items-center justify-center">
    <UIcon v-if="model.issued" name="i-lucide-circle-check" class="text-xl text-green-500" />
    <UCheckbox v-else :model-value="isSelected" :disabled="isDisabled" @change="handleToggle" />
  </div>
</template>
