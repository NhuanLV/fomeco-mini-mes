<script setup lang="ts">
import type { FlatKanbanItem } from '@/features/kanban/types'
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { useAuthStore } from '@/shared/stores/auth'
import { computed } from 'vue'
import { kanbanItemKey } from '@/features/kanban/fulfillment/kanbanFulfillment'

interface Addition {
  teamId: string
  selectedToReceive: FlatKanbanItem[]
  onToggleReceive: (item: FlatKanbanItem) => void
  blockedReceiveKeys: Set<string>
}

const props = defineProps<MatrixGridCellProps & { addition?: Addition }>()

const { hasPermission } = useAuthStore()
const model = computed(() => props.model as FlatKanbanItem)

const isSelected = computed(() =>
  (props.addition?.selectedToReceive ?? []).some(
    (item) =>
      item.article === model.value.article &&
      item.color === model.value.color &&
      item.size === model.value.size &&
      item.purchaseOrderId === model.value.purchaseOrderId,
  ),
)

const isDisabled = computed(
  () =>
    !model.value ||
    !model.value.issued ||
    model.value.received ||
    (props.addition?.blockedReceiveKeys?.has(kanbanItemKey(model.value)) ?? false) ||
    !hasPermission('CREATE_KANBAN', props.addition?.teamId ?? ''),
)

function handleToggle() {
  props.addition?.onToggleReceive(model.value)
}
</script>

<template>
  <div class="flex h-full items-center justify-center">
    <UIcon v-if="model.received" name="i-lucide-circle-check" class="text-xl text-green-500" />
    <UCheckbox v-else :model-value="isSelected" :disabled="isDisabled" @change="handleToggle" />
  </div>
</template>
