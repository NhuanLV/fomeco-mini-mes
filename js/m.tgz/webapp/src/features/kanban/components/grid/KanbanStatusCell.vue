<script setup lang="ts">
import type { FlatKanbanItem } from '@/features/kanban/types'
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { useAuthStore } from '@/shared/stores/auth'
import { computed } from 'vue'
import { fmtQty } from '@/shared/utils/fmtQty.ts'

interface Addition {
  receiveOnlyMode?: boolean
}

const props = defineProps<MatrixGridCellProps & { addition?: Addition }>()

const { hasPermission } = useAuthStore()
const model = computed(() => props.model as FlatKanbanItem)
const receiveOnlyMode = computed(() => !!props.addition?.receiveOnlyMode)

const showPrepared = computed(() => {
  if (!model.value) return false
  return (
    hasPermission('PREPARE_MATERIAL', model.value.supplierId) ||
    hasPermission('ISSUE_MATERIAL', model.value.supplierId) ||
    hasPermission('EVALUATE_KANBAN') ||
    hasPermission('EVALUATE_EXTRA_KANBAN') ||
    hasPermission('CREATE_KANBAN')
  )
})

const isWarehouseRole = computed(() => {
  if (!model.value) return false
  return (
    hasPermission('PREPARE_MATERIAL', model.value.supplierId) ||
    hasPermission('ISSUE_MATERIAL', model.value.supplierId)
  )
})

const isWarehouseView = computed(() => isWarehouseRole.value && !receiveOnlyMode.value)

const displayQty = computed(() => {
  if (!model.value) return 0
  if (isWarehouseView.value) {
    return model.value.actualIssuedQty
  }
  // Bên nhận: khi Kho đã xuất kho thì thấy số lượng cấp phát, chưa xuất thì là 0
  return model.value.issued ? model.value.actualIssuedQty : 0
})

const statusClass = computed(() => {
  if (!model.value) return ''
  if (isWarehouseView.value) {
    if (model.value.issued) {
      return 'font-bold text-green-600'
    }
    if (model.value.actualIssuedQty > 0) {
      return 'font-medium text-sky-600 dark:text-sky-400'
    }
    return ''
  }
  // Bên nhận: khi đã nhận thì xanh lá in đậm, khi mới xuất (chờ nhận) là chữ thường
  if (model.value.received) {
    return 'font-bold text-green-600'
  }
  return ''
})
</script>

<template>
  <div class="flex h-full items-center">
    <span v-if="showPrepared && model" :class="statusClass">
      {{ fmtQty(displayQty) }} / {{ fmtQty(model.requiredQty) }}
    </span>
    <span v-else>***</span>
  </div>
</template>
