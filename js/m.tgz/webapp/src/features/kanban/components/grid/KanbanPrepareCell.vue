<script setup lang="ts">
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { fmtQty } from '@/shared/utils/fmtQty'
import { computed } from 'vue'

const props = defineProps<MatrixGridCellProps>()

const inputVal = computed(() => {
  const val = props.model?.[props.prop as string]
  return val === undefined || val === null || val === '' ? 0 : Number(val)
})
</script>

<template>
  <div class="flex h-full items-center">
    <div class="text-sm">
      <span v-if="inputVal == 0"> - </span>
      <span v-else>{{ fmtQty(inputVal) }}</span>
    </div>
  </div>
</template>
