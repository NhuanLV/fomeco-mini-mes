<script setup lang="ts">
import { ref } from 'vue'
import { showWarn } from '@/shared/utils/toast'

defineProps<{
  visible: boolean
  isRejecting: boolean
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
  reject: [reason: string]
}>()

const reason = ref('')

function handleReject() {
  if (!reason.value.trim()) {
    showWarn('Vui lòng nhập lý do từ chối')
    return
  }
  emit('reject', reason.value.trim())
  reason.value = ''
}
</script>

<template>
  <UModal
    :open="visible"
    @update:open="emit('update:visible', $event)"
    title="Từ chối Kanban"
    class="sm:max-w-[30rem]"
  >
    <template #body>
      <div class="flex flex-col gap-4 pt-4">
        <div class="flex flex-col gap-2">
          <label for="reason" class="font-medium"
            >Lý do từ chối <span class="text-red-500">*</span></label
          >
          <UTextarea
            id="reason"
            v-model="reason"
            :rows="4"
            autoresize
            class="w-full"
            placeholder="Nhập lý do từ chối Kanban này..."
          />
        </div>
      </div>
    </template>
    <template #footer>
      <UButton
        label="Hủy"
        icon="i-lucide-x"
        variant="ghost"
        color="neutral"
        @click="emit('update:visible', false)"
      />
      <UButton
        label="Xác nhận"
        icon="i-lucide-check"
        color="error"
        :loading="isRejecting"
        @click="handleReject"
      />
    </template>
  </UModal>
</template>
