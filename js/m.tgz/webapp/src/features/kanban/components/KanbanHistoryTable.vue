<script setup lang="ts">
import { getKanbanHistoryQuery, getKanbanHistoryQueryKey } from '@/api/@pinia/colada.gen'
import { client } from '@/api/client.gen'
import type { KanbanHistoryEventVm } from '@/api/types.gen'
import ColumnDateFilter from '@/shared/components/ColumnDateFilter.vue'
import ColumnMultiSelectFilter from '@/shared/components/ColumnMultiSelectFilter.vue'
import { getGdnAttempts, type GdnDisplayAttempt } from './kanbanGdnDisplay'
import { useAuthStore } from '@/shared/stores/auth'
import { showError, showSuccess } from '@/shared/utils/toast'
import type { TableColumn } from '@nuxt/ui'
import { useQuery, useQueryCache } from '@pinia/colada'
import { useIntervalFn } from '@vueuse/core'
import dayjs from 'dayjs'
import { computed, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { sortKanbanHistoryDetail } from '@/features/kanban/helpers/kanbanHistoryOrdering'

type HistoryDetailRow = { label: string; quantity: string }

const props = defineProps<{
  kanbanId: string
  teamId: string
  readOnly?: boolean
  items?: { article: string; color: string; size: string }[]
  styleColorOrder?: string[]
  styleSizeOrder?: string[]
}>()

const route = useRoute()
const { hasPermission } = useAuthStore()

const isExpanded = ref(false)
const cardRef = ref<HTMLElement | null>(null)
const isHighlighted = ref(false)

watch(
  () => route?.query?.highlight,
  (highlight) => {
    if (highlight === 'gdn') {
      isExpanded.value = true
      isHighlighted.value = true
      setTimeout(() => {
        cardRef.value?.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }, 300)
      setTimeout(() => {
        isHighlighted.value = false
      }, 4000)
    }
  },
  { immediate: true },
)

const {
  data: history,
  isLoading,
  refetch,
} = useQuery(() => ({
  ...getKanbanHistoryQuery({ path: { id: props.kanbanId } }),
  enabled: isExpanded.value && !!props.kanbanId,
}))

const hasPendingGdn = computed(
  () =>
    isExpanded.value &&
    (history.value?.some(
      (event) =>
        event.gdnStatus === 'PENDING' ||
        getGdnAttempts(event).some((attempt) => attempt.status === 'PENDING'),
    ) ??
      false),
)

const { pause: pauseGdnPolling, resume: resumeGdnPolling } = useIntervalFn(
  () => {
    void refetch()
  },
  3000,
  { immediate: false },
)

watch(
  hasPendingGdn,
  (pending) => {
    if (pending) {
      resumeGdnPolling()
    } else {
      pauseGdnPolling()
    }
  },
  { immediate: true },
)

const queryCache = useQueryCache()
const events = computed<KanbanHistoryEventVm[]>(() => history.value ?? [])
const detailItem = ref<KanbanHistoryEventVm | null>(null)
const detailDialogVisible = ref(false)
const retryingKeys = ref(new Set<string>())
const canManageGdn = computed(() => hasPermission('CREATE_KANBAN', props.teamId))

const actionTypeFilter = ref<string[]>([])
const actorFilter = ref<string[]>([])
const dateRangeFilter = ref<Date[] | null>(null)

const ACTION_TYPE_OPTIONS = [
  { label: 'Tạo mới', value: 'KanbanCreated' },
  { label: 'Phê duyệt', value: 'KanbanApproved' },
  { label: 'Từ chối', value: 'KanbanRejected' },
  { label: 'Sửa đổi', value: 'KanbanRevised' },
  { label: 'Chuẩn bị', value: 'KanbanMaterialPrepared' },
  { label: 'Xuất kho', value: 'KanbanMaterialIssued' },
  { label: 'Xác nhận', value: 'KanbanMaterialReceived' },
  { label: 'Hoàn thành', value: 'KanbanCompleted' },
  { label: 'Huỷ Kanban', value: 'KanbanCancelled' },
]

const actorOptions = computed(() => {
  const actorNames = new Set<string>()
  events.value.forEach((e) => {
    actorNames.add(e.actor?.name ?? 'Hệ thống')
  })
  return Array.from(actorNames)
    .sort((left, right) => left.localeCompare(right, 'vi'))
    .map((name) => ({ label: name, value: name }))
})

const filteredEvents = computed(() => {
  return events.value.filter((event) => {
    if (actionTypeFilter.value.length > 0) {
      const matchesType = actionTypeFilter.value.some((selectedType) => {
        if (selectedType === 'KanbanApproved') {
          return event.type === 'KanbanApproved' || event.type === 'ExtraKanbanApproved'
        }
        return event.type === selectedType
      })
      if (!matchesType) {
        return false
      }
    }

    if (actorFilter.value.length > 0) {
      const actorName = event.actor?.name ?? 'Hệ thống'
      if (!actorFilter.value.includes(actorName)) {
        return false
      }
    }

    if (
      dateRangeFilter.value &&
      dateRangeFilter.value.length === 2 &&
      dateRangeFilter.value[0] &&
      dateRangeFilter.value[1]
    ) {
      const eventDate = dayjs(event.occurredAt)
      const startDate = dayjs(dateRangeFilter.value[0]).startOf('day')
      const endDate = dayjs(dateRangeFilter.value[1]).endOf('day')
      if (eventDate.isBefore(startDate) || eventDate.isAfter(endDate)) {
        return false
      }
    }

    return true
  })
})

const columns: TableColumn<KanbanHistoryEventVm>[] = [
  { accessorKey: 'productionOrderCode', header: 'Mã LSX' },
  { id: 'actionType', meta: { class: { th: 'p-0!' } } },
  { id: 'quantities', header: 'SL báo cáo' },
  { id: 'actor', meta: { class: { th: 'p-0!' } } },
  { id: 'occurredAt', meta: { class: { th: 'p-0!' } } },
  {
    id: 'gdn',
    header: 'Phiếu GDI/GDN',
    meta: {
      class: {
        th: 'min-w-[500px] max-w-[650px]',
        td: 'min-w-[500px] max-w-[650px] whitespace-normal break-words',
      },
    },
  },
  { id: 'reason', header: 'Ghi chú' },
]

const detailColumns: TableColumn<HistoryDetailRow>[] = [
  { accessorKey: 'label', header: 'Vật tư/BTP' },
  { accessorKey: 'quantity', header: 'Số lượng' },
]

const detailRows = computed<HistoryDetailRow[]>(() =>
  detailItem.value ? orderedDetail(detailItem.value) : [],
)

function orderedDetail(row: KanbanHistoryEventVm) {
  return sortKanbanHistoryDetail(
    row.detail,
    [...(props.items ?? []), ...getGdnAttempts(row).flatMap((attempt) => attempt.items)],
    props.styleColorOrder,
    props.styleSizeOrder,
  )
}

function formatDate(dateString: string) {
  return dayjs(dateString).format('DD/MM/YYYY HH:mm:ss')
}

function getActionLabel(type: KanbanHistoryEventVm['type']) {
  switch (type) {
    case 'KanbanCreated':
      return 'Tạo mới'
    case 'KanbanApproved':
    case 'ExtraKanbanApproved':
      return 'Phê duyệt'
    case 'KanbanRejected':
      return 'Từ chối'
    case 'KanbanRevised':
      return 'Sửa đổi'
    case 'KanbanMaterialPrepared':
      return 'Chuẩn bị'
    case 'KanbanMaterialIssued':
      return 'Xuất kho'
    case 'KanbanMaterialReceived':
      return 'Xác nhận'
    case 'KanbanCompleted':
      return 'Hoàn thành'
    case 'KanbanCancelled':
      return 'Huỷ Kanban'
    default:
      return type
  }
}

function getActionSeverity(type: KanbanHistoryEventVm['type']) {
  switch (type) {
    case 'KanbanCreated':
      return 'primary'
    case 'KanbanApproved':
    case 'ExtraKanbanApproved':
      return 'secondary'
    case 'KanbanRejected':
      return 'error'
    case 'KanbanRevised':
      return 'warning'
    case 'KanbanMaterialPrepared':
      return 'info'
    case 'KanbanMaterialIssued':
      return 'neutral'
    case 'KanbanMaterialReceived':
      return 'success'
    case 'KanbanCompleted':
      return 'warning'
    default:
      return 'neutral'
  }
}

function getSummary(row: KanbanHistoryEventVm) {
  const items = orderedDetail(row).map(({ label, quantity }) => `${label}: ${quantity}`)
  return {
    visibleItems: items.slice(0, 2),
    remaining: Math.max(items.length - 2, 0),
  }
}

function getGdnLabel(attempt: GdnDisplayAttempt) {
  switch (attempt.status) {
    case 'PENDING':
      return 'Đang tạo'
    case 'SUCCESS':
      return 'Thành công'
    case 'FAILED':
      return 'Thất bại'
    case 'NOT_APPLICABLE':
      return 'Không áp dụng'
    default:
      return 'Chưa tạo'
  }
}

function getGdnColor(attempt: GdnDisplayAttempt) {
  switch (attempt.status) {
    case 'PENDING':
      return 'warning'
    case 'SUCCESS':
      return 'success'
    case 'FAILED':
      return 'error'
    case 'NOT_APPLICABLE':
      return 'neutral'
    default:
      return 'neutral'
  }
}

function isReceiveEvent(row: KanbanHistoryEventVm) {
  return row.type === 'KanbanMaterialReceived'
}

function getGdnTypeLabel(attempt: GdnDisplayAttempt) {
  return attempt.materialType === 'ALL' ? null : attempt.materialType
}

function canRetryGdn(row: KanbanHistoryEventVm, attempt: GdnDisplayAttempt) {
  if (props.readOnly) return false
  if (attempt.status === 'NOT_APPLICABLE') return false
  if (!canManageGdn.value || !row.supplierUnitId) return false
  return attempt.canRetry || attempt.status === 'FAILED' || attempt.status === 'NOT_READY'
}

function getGdnMessageLines(message: string, isSuccess = false) {
  if (!message) return []
  const text = message.trim()

  if (isSuccess) {
    const match = text.match(/\(([^()]+)\)/)
    const extracted = match && match[1].trim() ? match[1].trim() : text
    return extracted
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)
      .filter((line) => !line.startsWith('Tạo phiếu GDN thành công'))
  }

  const rawLines = text
    .split('\n')
    .map((s) => s.trim())
    .filter(Boolean)
  const result: string[] = []

  rawLines.forEach((line) => {
    const colonIndex = line.indexOf(': ')
    if (colonIndex !== -1) {
      const prefix = line.slice(0, colonIndex + 1).trim()
      const rest = line.slice(colonIndex + 2).trim()
      if (prefix) result.push(prefix)
      if (rest) result.push(rest)
    } else {
      result.push(line)
    }
  })

  return result
}

function openDetail(row: KanbanHistoryEventVm) {
  detailItem.value = row
  detailDialogVisible.value = true
}

async function retryGdn(event: KanbanHistoryEventVm, attempt: GdnDisplayAttempt, key: string) {
  if (!event.supplierUnitId) {
    showError('Không xác định được nơi cấp phát để tạo lại phiếu xuất kho')
    return
  }

  retryingKeys.value.add(key)
  retryingKeys.value = new Set(retryingKeys.value)
  try {
    await client.post({
      url: '/api/kanbans/{kanbanId}/assignments/{supplierId}/gdn/retry',
      path: {
        kanbanId: props.kanbanId,
        supplierId: event.supplierUnitId,
      },
      query: { occurredAt: event.occurredAt, materialType: attempt.materialType },
      throwOnError: true,
    })
    showSuccess('Đang tạo lại phiếu xuất kho trên WFX')
    setTimeout(() => {
      void queryCache.invalidateQueries({
        key: getKanbanHistoryQueryKey({ path: { id: props.kanbanId } }),
      })
    }, 1000)
  } catch (error: unknown) {
    showError((error as { message?: string })?.message || 'Không thể tạo lại phiếu xuất kho')
  } finally {
    retryingKeys.value.delete(key)
    retryingKeys.value = new Set(retryingKeys.value)
  }
}
</script>

<template>
  <div
    ref="cardRef"
    :class="{ 'rounded-xl ring-2 ring-rose-500 transition-all duration-300': isHighlighted }"
  >
    <UCard>
      <template #title>
        <div
          class="flex cursor-pointer items-center justify-between gap-2 select-none"
          @click="isExpanded = !isExpanded"
        >
          <div class="flex items-center gap-2">
            <UIcon name="i-lucide-history" class="size-5 text-primary" />
            <span class="font-semibold">Lịch sử hoạt động</span>
          </div>
          <UButton
            :label="isExpanded ? 'Thu gọn' : 'Xem lịch sử'"
            :icon="isExpanded ? 'i-lucide-chevron-up' : 'i-lucide-chevron-down'"
            color="primary"
            variant="subtle"
            size="xs"
            class="font-medium"
            @click.stop="isExpanded = !isExpanded"
          />
        </div>
      </template>

      <template #default v-if="isExpanded">
        <UTable :data="filteredEvents" :columns="columns" :loading="isLoading" class="text-sm">
          <template #empty>
            <div class="py-4 text-center text-sm text-toned">Chưa có hoạt động nào.</div>
          </template>

          <template #productionOrderCode-cell="{ row }">
            {{ row.original.productionOrderCode || '-' }}
          </template>

          <template #actionType-header>
            <ColumnMultiSelectFilter
              v-model="actionTypeFilter"
              :items="ACTION_TYPE_OPTIONS"
              placeholder="Loại thao tác"
            />
          </template>

          <template #actionType-cell="{ row }">
            <UBadge
              :label="getActionLabel(row.original.type)"
              :color="getActionSeverity(row.original.type)"
              class="text-xs"
            />
          </template>

          <template #quantities-cell="{ row }">
            <div class="flex flex-col items-start gap-1">
              <template v-if="getSummary(row.original).visibleItems.length > 0">
                <span
                  v-for="(item, index) in getSummary(row.original).visibleItems"
                  :key="`${item}-${index}`"
                  class="whitespace-nowrap"
                >
                  {{ item }}
                </span>
              </template>
              <span v-else>-</span>
              <div
                v-if="
                  getSummary(row.original).remaining > 0 ||
                  Object.keys(row.original.detail).length > 0
                "
                class="flex items-center gap-2"
              >
                <span
                  v-if="getSummary(row.original).remaining > 0"
                  class="rounded-full bg-sky-100 px-2 py-0.5 text-xs font-semibold text-sky-700"
                >
                  +{{ getSummary(row.original).remaining }}
                </span>
                <UButton
                  v-if="Object.keys(row.original.detail).length > 0"
                  label="Xem chi tiết"
                  variant="link"
                  size="sm"
                  class="px-0!"
                  @click="openDetail(row.original)"
                />
              </div>
            </div>
          </template>

          <template #actor-header>
            <ColumnMultiSelectFilter
              v-model="actorFilter"
              :items="actorOptions"
              placeholder="Người thực hiện"
            />
          </template>

          <template #actor-cell="{ row }">
            {{ row.original.actor?.name ?? 'Hệ thống' }}
          </template>

          <template #occurredAt-header>
            <ColumnDateFilter v-model="dateRangeFilter" label="Thời gian" />
          </template>

          <template #occurredAt-cell="{ row }">
            {{ formatDate(row.original.occurredAt) }}
          </template>

          <template #gdn-cell="{ row }">
            <template v-if="isReceiveEvent(row.original)">
              <div
                class="flex max-w-[650px] min-w-[500px] flex-col items-start gap-2 font-normal break-words whitespace-normal"
              >
                <div
                  v-for="attempt in getGdnAttempts(row.original)"
                  :key="attempt.materialType"
                  class="flex w-full flex-col items-start gap-1"
                >
                  <div class="flex flex-wrap items-center gap-2">
                    <span
                      v-if="getGdnAttempts(row.original).length > 1"
                      class="text-xs font-semibold"
                    >
                      {{ getGdnTypeLabel(attempt) }}:
                    </span>
                    <UBadge
                      :label="getGdnLabel(attempt)"
                      :color="getGdnColor(attempt)"
                      class="text-xs"
                    />
                    <UButton
                      v-if="canRetryGdn(row.original, attempt)"
                      :label="attempt.status === 'FAILED' ? 'Tạo lại GDN' : 'Tạo GDN'"
                      :icon="
                        attempt.status === 'FAILED'
                          ? 'i-lucide-refresh-cw'
                          : 'i-lucide-package-plus'
                      "
                      color="primary"
                      size="xs"
                      variant="outline"
                      :loading="retryingKeys.has(`${row.index}-${attempt.materialType}`)"
                      @click="
                        retryGdn(row.original, attempt, `${row.index}-${attempt.materialType}`)
                      "
                    />
                  </div>
                  <div
                    v-if="attempt.message"
                    :class="[
                      'max-w-[650px] min-w-[500px] space-y-0.5 text-xs font-normal break-all whitespace-normal',
                      attempt.status === 'FAILED' ? 'text-error' : 'text-toned',
                    ]"
                  >
                    <div
                      v-for="(line, idx) in getGdnMessageLines(
                        attempt.message,
                        attempt.status === 'SUCCESS',
                      )"
                      :key="`${attempt.materialType}-${line}-${idx}`"
                      class="break-all whitespace-normal"
                    >
                      {{ line }}
                    </div>
                  </div>
                </div>
              </div>
            </template>
            <span v-else>-</span>
          </template>

          <template #reason-cell="{ row }">
            {{ row.original.subtitle || '-' }}
          </template>
        </UTable>
      </template>
    </UCard>
  </div>

  <UModal
    v-model:open="detailDialogVisible"
    title="Chi tiết số lượng thao tác"
    class="max-w-[95vw] sm:max-w-3xl"
  >
    <template #body>
      <div v-if="detailItem" class="flex flex-col gap-3">
        <div class="text-sm text-default">
          {{ detailItem.productionOrderCode || '-' }} · {{ getActionLabel(detailItem.type) }} ·
          {{ formatDate(detailItem.occurredAt) }}
        </div>
        <UTable :data="detailRows" :columns="detailColumns" class="text-sm" />
      </div>
    </template>
  </UModal>
</template>
