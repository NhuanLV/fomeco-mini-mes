<script setup lang="ts">
import type { PlanItemVm } from '@/api'
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import { matrixGridCell, type MatrixGridColumnTypes } from '@/shared/components/grid/matrixGrid'
import type { GridColumn } from '@/shared/composables/useGridLayout'
import { computed } from 'vue'
import { makeOrderComparator, sortValuesByOrder } from '@/shared/utils/orderedValues'

const props = defineProps<{
  plan: PlanItemVm[]
  styleColorOrder?: string[]
  styleSizeOrder?: string[]
}>()

type PlanGridRow = {
  purchaseOrderId: string
  poCode: string
  color: string
  total: number | string
  [sizeKey: string]: string | number
}

const QTY_CELL = matrixGridCell(MatrixQtyCell)
const COLUMN_TYPES: MatrixGridColumnTypes = {
  qty: { cellTemplate: QTY_CELL },
}

const allSizes = computed(() =>
  sortValuesByOrder(
    props.plan.map((item) => item.size),
    props.styleSizeOrder ?? [],
  ),
)

const source = computed<PlanGridRow[]>(() => {
  const rowMap = new Map<string, PlanGridRow>()

  props.plan.forEach((item) => {
    const key = `${item.purchaseOrderId}|${item.color}`
    const existing =
      rowMap.get(key) ??
      (() => {
        const row: PlanGridRow = {
          purchaseOrderId: item.purchaseOrderId,
          poCode: item.purchaseOrderCode || item.purchaseOrderId,
          color: item.color,
          total: '',
        }
        allSizes.value.forEach((size) => {
          row[size] = ''
        })
        rowMap.set(key, row)
        return row
      })()

    existing[item.size] = item.qty > 0 ? item.qty : ''
  })

  const cmpColor = makeOrderComparator(props.styleColorOrder ?? [])
  return Array.from(rowMap.values())
    .sort(
      (left, right) =>
        left.poCode.localeCompare(right.poCode) ||
        left.purchaseOrderId.localeCompare(right.purchaseOrderId) ||
        cmpColor(left.color, right.color),
    )
    .map((row) => {
      const totalQty = allSizes.value.reduce((sum, size) => {
        const qty = Number(row[size] || 0)
        return sum + (Number.isFinite(qty) ? qty : 0)
      }, 0)
      row.total = totalQty > 0 ? totalQty : ''
      return row
    })
})

const columns = computed<GridColumn[]>(() => [
  {
    prop: 'poCode',
    name: 'PO',
    pin: 'colPinStart',
    readonly: true,
  },
  {
    prop: 'color',
    name: 'Màu',
    pin: 'colPinStart',
    readonly: true,
  },
  ...allSizes.value.map((size): GridColumn => ({
    prop: size,
    name: size,
    readonly: true,
    columnType: 'qty',
  })),
  {
    prop: 'total',
    name: 'Tổng',
    pin: 'colPinEnd',
    readonly: true,
    columnType: 'qty',
  },
])
</script>

<template>
  <UCard v-if="plan && plan.length > 0">
    <template #title> Kế hoạch sản xuất</template>
    <template #default>
      <BaseMatrixGrid :source="source" :columns="columns" :column-types="COLUMN_TYPES" />
    </template>
  </UCard>
</template>
