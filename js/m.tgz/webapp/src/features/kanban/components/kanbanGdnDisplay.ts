import type { KanbanGdnAttemptVm, KanbanHistoryEventVm } from '@/api/types.gen'

export type GdnDisplayStatus = 'NOT_READY' | KanbanGdnAttemptVm['status']

export type GdnDisplayAttempt = Omit<KanbanGdnAttemptVm, 'status'> & {
  status: GdnDisplayStatus
}

export function getGdnAttempts(row: KanbanHistoryEventVm): GdnDisplayAttempt[] {
  if (row.gdnAttempts?.length) return row.gdnAttempts

  return [
    {
      materialType: 'ALL',
      status: row.gdnStatus ?? 'NOT_READY',
      mode: row.gdnMode,
      message: row.gdnMessage,
      gdnNo: row.gdnNo,
      items: [],
      canRetry:
        row.gdnStatus === 'NOT_APPLICABLE'
          ? false
          : row.canRetryGdn || row.gdnStatus == null || row.gdnStatus === 'FAILED',
    },
  ]
}
