<script setup lang="ts">
import type { PlanItem } from '@/api'
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import { matrixGridCell, type MatrixGridEdit } from '@/shared/components/grid/matrixGrid'
import type { GridColumn } from '@/shared/composables/useGridLayout'
import { computed, ref } from 'vue'

import type { MatrixData, MatrixRow } from '@/shared/types'

interface Props {
  rows: MatrixRow[]
  allSizes: string[]
  modelValue: PlanItem[]
}

const props = defineProps<Props>()
const emit = defineEmits<{
  (e: 'update:modelValue', val: PlanItem[]): void
}>()

const ALLOC_CELL = matrixGridCell(MatrixQtyCell)

const bulkMap = computed(() => {
  const map: Record<string, Record<string, number | null>> = {}
  props.modelValue.forEach((item) => {
    const key = `${item.purchaseOrderId}|${item.color}`
    if (!map[key]) map[key] = {}
    map[key]![item.size] = item.qty
  })
  return map
})

interface BulkGridRow {
  purchaseOrderId: string
  poCode: string
  color: string
  colorKey: string
  limit: number | string
  total_demand?: number
  [sizeKey: string]: string | number | undefined
}

const source = computed((): BulkGridRow[] =>
  props.rows.map((row) => {
    const colorKey = `${row.purchaseOrderId!}|${row.color}`
    const flat: BulkGridRow = {
      purchaseOrderId: row.purchaseOrderId!,
      poCode: row.poCode!,
      color: row.color,
      colorKey,
      limit: '',
    }
    let totalIncrement = 0
    let totalRemaining = 0

    for (const size of props.allSizes) {
      const dVal = row.data[size]
      const d = (
        typeof dVal === 'object' && dVal !== null ? dVal : { current: 0, limit: 0 }
      ) as MatrixData
      const increment = bulkMap.value[colorKey]?.[size] ?? null
      const remainingQty = Math.max(0, d.limit - d.current)

      flat[size] = increment || ''
      flat[`${size}_demand`] = remainingQty

      if (increment) totalIncrement += increment
      totalRemaining += remainingQty
    }

    flat.limit = totalIncrement || ''
    flat.total_demand = totalRemaining

    return flat
  }),
)

const poFilter = ref<string[]>([])
const colorFilter = ref<string[]>([])
const sizeFilter = ref<string[]>([])

const poOptions = computed(() => {
  return Array.from(
    new Set(props.rows.map((row) => row.poCode).filter((value): value is string => !!value)),
  ).sort()
})

const colorOptions = computed(() => {
  return Array.from(
    new Set(props.rows.map((row) => row.color).filter((value): value is string => !!value)),
  ).sort()
})

const sizeOptions = computed(() => props.allSizes)

const filteredSource = computed(() => {
  return source.value.filter((row) => {
    if (poFilter.value.length > 0 && !poFilter.value.includes(row.poCode)) return false
    return !(colorFilter.value.length > 0 && !colorFilter.value.includes(row.color))
  })
})

const filteredSizes = computed(() => {
  if (sizeFilter.value.length === 0) return props.allSizes
  return props.allSizes.filter((s) => sizeFilter.value.includes(s))
})

function clearFilters() {
  poFilter.value = []
  colorFilter.value = []
  sizeFilter.value = []
}

// ─── Column definitions ───────────────────────────────────────────────────────
const columns = computed((): GridColumn[] => [
  {
    prop: 'poCode',
    name: 'PO',
    pin: 'colPinStart',
    readonly: true,
  },
  {
    prop: 'color',
    name: 'Màu',
    pin: 'colPinStart',
    readonly: true,
  },
  ...filteredSizes.value.map((size): GridColumn => ({
    prop: size,
    name: size,
    readonly: false,
    cellTemplate: ALLOC_CELL,
  })),
  {
    prop: 'limit',
    name: 'Tổng',
    pin: 'colPinEnd',
    readonly: true,
    cellTemplate: ALLOC_CELL,
    cellProperties: () => ({
      class: 'font-mono text-primary',
    }),
  },
])

function applyRowData(
  updatedMap: { [colorKey: string]: { [size: string]: number | null } },
  rowIndex: number,
  prop: string,
  val: string | number | null,
) {
  const row = filteredSource.value[rowIndex]
  if (!row) return

  if (props.allSizes.includes(prop)) {
    let parsed = parseInt(String(val), 10)
    if (isNaN(parsed) || parsed < 0) {
      parsed = 0
    }

    const demand = Number(row[`${prop}_demand`]) || 0

    if (parsed > demand) {
      parsed = demand
    }

    const colorKey = row.colorKey as string
    if (!updatedMap[colorKey]) updatedMap[colorKey] = {}
    updatedMap[colorKey]![prop] = parsed > 0 ? parsed : null
  }
}

function handleAfterEdit(edits: MatrixGridEdit[]) {
  const updatedMap: { [colorKey: string]: { [size: string]: number | null } } = {}
  Object.keys(bulkMap.value).forEach((ck) => {
    updatedMap[ck] = { ...bulkMap.value[ck] }
  })

  for (const edit of edits) {
    applyRowData(updatedMap, edit.rowIndex, edit.prop, edit.value as string | number | null)
  }

  const newModelValue: PlanItem[] = []
  Object.keys(updatedMap).forEach((ck) => {
    const parts = ck.split('|')
    const purchaseOrderId = parts[0]!
    const color = parts[1]!
    const colorSizeMap = updatedMap[ck]
    if (colorSizeMap) {
      Object.keys(colorSizeMap).forEach((s) => {
        const qty = colorSizeMap[s]
        if (qty != null && qty > 0) {
          newModelValue.push({
            purchaseOrderId,
            color,
            size: s,
            qty,
          })
        }
      })
    }
  })

  emit('update:modelValue', newModelValue)
}

const bulkQty = ref<number | null>(null)

function handleBulkFill() {
  const qty = bulkQty.value
  if (qty == null || qty < 0) return

  const updatedMap: { [colorKey: string]: { [size: string]: number | null } } = {}
  Object.keys(bulkMap.value).forEach((ck) => {
    updatedMap[ck] = { ...bulkMap.value[ck] }
  })

  filteredSource.value.forEach((row) => {
    const colorKey = row.colorKey as string
    if (!updatedMap[colorKey]) updatedMap[colorKey] = {}

    filteredSizes.value.forEach((size) => {
      const demand = Number(row[`${size}_demand`]) || 0
      let parsed = qty
      if (parsed > demand) parsed = demand
      updatedMap[colorKey]![size] = parsed > 0 ? parsed : null
    })
  })

  const newModelValue: PlanItem[] = []
  Object.keys(updatedMap).forEach((ck) => {
    const parts = ck.split('|')
    const purchaseOrderId = parts[0]!
    const color = parts[1]!
    const colorSizeMap = updatedMap[ck]
    if (colorSizeMap) {
      Object.keys(colorSizeMap).forEach((s) => {
        const qty = colorSizeMap[s]
        if (qty != null && qty > 0) {
          newModelValue.push({
            purchaseOrderId,
            color,
            size: s,
            qty,
          })
        }
      })
    }
  })

  emit('update:modelValue', newModelValue)
  bulkQty.value = null
}
</script>

<template>
  <div class="flex flex-col gap-3">
    <div class="flex flex-wrap items-center gap-2">
      <USelectMenu
        multiple
        v-model="poFilter"
        :items="poOptions"
        placeholder="Mã PO"
        search-input
        class="w-48"
      />
      <USelectMenu
        multiple
        v-model="colorFilter"
        :items="colorOptions"
        placeholder="Màu"
        search-input
        class="w-48"
      />
      <USelectMenu
        multiple
        v-model="sizeFilter"
        :items="sizeOptions"
        placeholder="Size"
        search-input
        class="w-48"
      />
      <UButton
        v-if="poFilter.length > 0 || colorFilter.length > 0 || sizeFilter.length > 0"
        variant="ghost"
        color="neutral"
        @click="clearFilters"
        icon="i-lucide-filter-x"
      />
      <div class="ml-auto flex items-center gap-2">
        <UInput
          v-model.number="bulkQty"
          type="number"
          placeholder="Số lượng..."
          class="w-32"
          min="0"
          step="1"
        />
        <UButton
          label="Điền tất cả"
          color="info"
          variant="outline"
          class="flex-shrink-0 whitespace-nowrap"
          @click="handleBulkFill"
        />
      </div>
    </div>
    <BaseMatrixGrid :source="filteredSource" :columns="columns" @afteredit="handleAfterEdit" />
  </div>
</template>
