<script setup lang="ts">
import { ref } from 'vue'

const props = defineProps<{
  value: string | null | undefined
  model: { supplierOptions?: Array<{ label: string; value: string }> }
  save: (val: string, preventFocus?: boolean) => void
  close: (isCancel?: boolean) => void
}>()

const selectRef = ref()
const open = ref(true)
const selectedValue = ref(props.value)
// Access the row-specific options calculated in KanbanItemTable
const options = ref(props.model?.supplierOptions || [])

function handleSave() {
  props.save(selectedValue.value || '', true)
  props.close()
}

function handleCancel() {
  props.close(true)
}
</script>

<template>
  <div class="flex h-full w-full items-center bg-white px-1">
    <USelectMenu
      ref="selectRef"
      v-model:open="open"
      v-model="selectedValue"
      :items="options"
      label-key="label"
      value-key="value"
      placeholder="Chọn nơi nhận..."
      clear
      @update:model-value="handleSave"
      @blur="handleCancel"
      autofocus
      class="h-8! w-full"
      :ui="{
        base: 'border-none shadow-none bg-transparent focus:ring-0 h-8',
        value: 'text-[13px] py-1 px-2',
      }"
    >
      <template #item="slotProps">
        <span class="text-highlighted">{{ slotProps.item.label }}</span>
      </template>
    </USelectMenu>
  </div>
</template>
