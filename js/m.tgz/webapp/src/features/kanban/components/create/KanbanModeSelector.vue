<script setup lang="ts">
export type KanbanMode = 'INFO' | 'STANDARD' | 'EXTRA'

defineProps<{
  modelValue: KanbanMode
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: KanbanMode): void
}>()

const options = [
  { label: 'Thông tin', value: 'INFO' },
  { label: 'Trong định mức', value: 'STANDARD' },
  { label: 'Ngoài định mức', value: 'EXTRA' },
]

function onChange(value: string | number) {
  if (value) {
    emit('update:modelValue', value as KanbanMode)
  }
}
</script>

<template>
  <UTabs
    :model-value="modelValue"
    :items="options"
    :content="false"
    variant="link"
    @update:model-value="onChange"
  />
</template>
