<script setup lang="ts">
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { computed } from 'vue'

interface KanbanRowData {
  articleName: string
  poCode: string | null
  rowKind: 'parent' | 'child' | 'leaf'
  groupKey: string
  mode: 'STANDARD' | 'EXTRA'
}

interface Addition {
  onSplit: (groupKey: string) => void
}

const props = defineProps<MatrixGridCellProps & { addition?: Addition }>()
const rowData = computed(() => props.model as KanbanRowData)

const displayName = computed(() =>
  rowData.value?.rowKind === 'child'
    ? (rowData.value?.poCode ?? rowData.value?.articleName ?? '')
    : (rowData.value?.articleName ?? ''),
)
const rowKind = computed(() => rowData.value?.rowKind ?? 'leaf')
const groupKey = computed(() => rowData.value?.groupKey ?? '')
const mode = computed(() => rowData.value?.mode ?? 'STANDARD')

function handleSplit() {
  if (groupKey.value) {
    props.addition?.onSplit(groupKey.value)
  }
}
</script>

<template>
  <div class="flex h-full w-full items-center justify-between gap-2 px-2">
    <div class="flex items-center gap-1 overflow-hidden">
      <span v-if="rowKind === 'child'" class="text-toned select-none">↳</span>
      <span class="truncate" :class="{ 'font-semibold': rowKind === 'parent' }">
        {{ displayName }}
      </span>
    </div>

    <UButton
      v-if="
        mode === 'STANDARD' &&
        !rowData.articleName.startsWith('BTP ') &&
        (rowKind === 'leaf' || rowKind === 'parent')
      "
      :icon="rowKind === 'parent' ? 'i-lucide-circle-minus' : 'i-lucide-circle-plus'"
      :outlined="rowKind === 'leaf'"
      :title="rowKind === 'parent' ? 'Thu gọn theo PO' : 'Tách theo PO'"
      @click.stop="handleSplit"
      variant="ghost"
      size="sm"
      class="h-7! w-7! p-0!"
    />
  </div>
</template>
