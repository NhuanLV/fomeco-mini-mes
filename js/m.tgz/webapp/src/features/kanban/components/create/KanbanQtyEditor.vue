<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { rejectComma } from '@/shared/utils/numberInput'

const props = defineProps<{
  val: string | number | null | undefined
  save: (val: number | null, preventFocus?: boolean) => void
  close: (isCancel?: boolean) => void
}>()

const inputRef = ref(null)
const qtyValue = ref<number | null>(props.val == null ? 0 : Number(props.val))
const isClosing = ref(false)

function handleSave(focusNext = false) {
  if (isClosing.value) return
  isClosing.value = true
  props.save(qtyValue.value, true)
  props.close(focusNext)
}

function handleCancel() {
  if (isClosing.value) return
  isClosing.value = true
  props.close(true)
}

function handleKeyDown(event: KeyboardEvent) {
  if (event.key === 'Enter') {
    event.preventDefault()
    event.stopPropagation()
    handleSave(true)
  } else if (event.key === 'Escape') {
    event.preventDefault()
    event.stopPropagation()
    handleCancel()
  }
}

onMounted(() => {
  setTimeout(() => {
    const input = (inputRef.value as unknown as { $el: HTMLElement })?.$el?.querySelector('input')
    if (input) {
      input.focus()
    }
  }, 50)
})
</script>

<template>
  <div class="flex h-full w-full items-center bg-white px-1">
    <UInput
      ref="inputRef"
      v-model.number="qtyValue"
      type="text"
      inputmode="decimal"
      @keydown="handleKeyDown"
      @blur="handleSave()"
      @beforeinput="rejectComma"
      min="0"
      step="0.0001"
      autofocus
      class="h-8 w-full border-none bg-transparent shadow-none"
    />
  </div>
</template>
