<script setup lang="ts">
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { computed } from 'vue'

const props = defineProps<MatrixGridCellProps>()
const isRequired = computed(() => props.model?.isRequired !== false)
const isBtp = computed(() => props.model?.type === 'SEMI_FINISHED_PRODUCT')
</script>

<template>
  <div class="flex h-full w-full items-center justify-center">
    <UBadge
      v-if="!isBtp"
      :label="isRequired ? 'Bắt buộc' : 'Không bắt buộc'"
      :color="isRequired ? 'neutral' : 'warning'"
      variant="subtle"
      size="xs"
    />
    <span v-else class="text-xs text-toned">-</span>
  </div>
</template>
