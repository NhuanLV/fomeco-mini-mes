<script setup lang="ts">
import type {
  KanbanContextVm,
  KanbanItem,
  PlanItem,
  TeamAssignmentDetailVm,
  TeamBomVm,
} from '@/api/types.gen'
import { useKanbanGridData } from '@/features/kanban/composables/useKanbanGridData'
import type { BomLine } from '@/shared/components/bom/types'
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import type { MatrixGridBeforeEdit, MatrixGridEdit } from '@/shared/components/grid/matrixGrid'
import { matrixGridCell, matrixGridEditor } from '@/shared/components/grid/matrixGrid'
import BomDetailDialog from '@/shared/components/bom/BomDetailDialog.vue'
import { showWarn } from '@/shared/utils/toast'
import { computed, nextTick, ref, toRef } from 'vue'

import { buildColumns, buildDisplayRows } from '@/features/kanban/helpers/kanbanItemsGrid'
import KanbanArticleCell from './KanbanArticleCell.vue'
import KanbanBomCell from './KanbanBomCell.vue'
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import NoteEditor from '@/shared/components/grid/NoteEditor.vue'
import KanbanQtyEditor from './KanbanQtyEditor.vue'
import KanbanRequiredCell from './KanbanRequiredCell.vue'
import KanbanSupplierCell from './KanbanSupplierCell.vue'
import KanbanSupplierEditor from './KanbanSupplierEditor.vue'
import type { GridRow } from '@/shared/composables/useGridLayout'
import { makeArticleVariantComparator } from '@/shared/utils/orderedValues'

const props = defineProps<{
  mode: 'INFO' | 'STANDARD' | 'EXTRA'
  planItems: PlanItem[]
  assignment: TeamAssignmentDetailVm
  bomData: TeamBomVm
  context: KanbanContextVm
}>()

const emit = defineEmits<{
  'update:rows': [val: KanbanItem[]]
}>()

const isBomDialogOpen = ref(false)
const selectedBomLine = ref<BomLine | null>(null)

const COLUMN_TYPES = {
  article: { cellTemplate: matrixGridCell(KanbanArticleCell) },
  bom: { cellTemplate: matrixGridCell(KanbanBomCell) },
  qty: {
    cellTemplate: matrixGridCell(MatrixQtyCell),
    editor: matrixGridEditor(KanbanQtyEditor),
  },
  note: { editor: matrixGridEditor(NoteEditor) },
  supplier: {
    cellTemplate: matrixGridCell(KanbanSupplierCell),
    editor: matrixGridEditor(KanbanSupplierEditor),
  },
  required: { cellTemplate: matrixGridCell(KanbanRequiredCell) },
}
const supplierOptionsWarehouse = computed(() =>
  props.context.availableWarehouses.map((w) => ({ label: w.name, value: w.id })),
)
const supplierOptionsTeam = computed(() =>
  props.context.previousOperationTeams.map((t) => ({ label: t.name, value: t.id })),
)

const { tableRows, toggleExpand, onQtyChange, onSupplierChange, onCreatorNoteChange } =
  useKanbanGridData({
    mode: toRef(props, 'mode'),
    planItems: toRef(props, 'planItems'),
    assignment: toRef(props, 'assignment'),
    bomData: toRef(props, 'bomData'),
    context: toRef(props, 'context'),
    supplierOptionsWarehouse,
    supplierOptionsTeam,
  })

const allSupplierOptions = computed(() => [
  ...supplierOptionsWarehouse.value,
  ...supplierOptionsTeam.value,
])

const columns = computed(() => buildColumns(props.mode))

const displayRows = computed(() => buildDisplayRows(allSupplierOptions.value))
const viewRows = computed(() => {
  const cmp = makeArticleVariantComparator(
    props.assignment.styleColorOrder,
    props.assignment.styleSizeOrder,
  )
  return [...tableRows.value].sort((left, right) =>
    cmp(
      { article: left.articleName, color: left.color, size: left.materialSize },
      { article: right.articleName, color: right.color, size: right.materialSize },
    ),
  )
})

function handleBeforeEdit(edit: MatrixGridBeforeEdit) {
  if (props.mode === 'INFO') {
    edit.preventDefault()
    return
  }
  const { rowIndex } = edit
  const row = viewRows.value[rowIndex]
  if (row?.rowKind === 'parent') {
    edit.preventDefault()
  }
}

function updateRowData(rowIndex: number, prop: string, val: unknown) {
  const row = viewRows.value[rowIndex]
  if (!row) return

  if (prop === 'requiredQty') {
    let nextQty = Number(val)
    if (isNaN(nextQty) || nextQty < 0) nextQty = 0

    if (props.mode === 'STANDARD') {
      const maxAllowed = Math.max(0, row.reportableQty)
      if (nextQty > maxAllowed) {
        nextQty = maxAllowed
        showWarn('Số lượng báo không được vượt quá số lượng còn lại có thể báo')
      }
    }

    onQtyChange(row.lineId, nextQty)
  } else if (prop === 'creatorNote') {
    onCreatorNoteChange(row.lineId, String(val ?? ''))
  } else if (prop === 'supplierUnitId') {
    const supplierId = String(val ?? '')
    if (!supplierId) {
      onSupplierChange(row.lineId, '')
      return
    }

    const isMaterial = row.type === 'MATERIAL'
    const validOptions = isMaterial ? supplierOptionsWarehouse.value : supplierOptionsTeam.value
    const isValid = validOptions.some((opt) => opt.value === supplierId)

    if (isValid) {
      onSupplierChange(row.lineId, supplierId)
    }
  }
}

function emitRows() {
  const validRows = tableRows.value.filter((r) => r.rowKind !== 'parent')
  const kanbanItems: KanbanItem[] = validRows.map((r) => {
    const clampedQty =
      props.mode === 'STANDARD'
        ? Math.max(0, Math.min(r.requiredQty, r.reportableQty))
        : Math.max(0, r.requiredQty)

    return {
      article: r.articleName,
      color: r.color,
      size: r.materialSize,
      purchaseOrderId: r.poId,
      type: r.type,
      purchaseOrderType: r.purchaseOrderType,
      requiredQty: clampedQty,
      supplierUnitId: r.supplierUnitId,
      creatorNote: r.creatorNote,
    }
  })

  emit('update:rows', kanbanItems)
}

function handleAfterEdit(edits: MatrixGridEdit[]) {
  for (const edit of edits) updateRowData(edit.rowIndex, edit.prop, edit.value)
  emitRows()
}

async function handleSplit(groupKey: string) {
  toggleExpand(groupKey)
  await nextTick()
  emitRows()
}

const isCutting = computed(() => props.assignment.operation === 'CUT-1')

function handleViewBom(rowIndex: number) {
  const gridRow = viewRows.value[rowIndex]
  const bomLine = props.bomData.lines.find((line) => line.articleName === gridRow.articleName)

  if (bomLine) {
    selectedBomLine.value = {
      id: bomLine.id,
      articleName: bomLine.articleName,
      alternativeName: bomLine.alternativeName,
      isRequired: bomLine.isRequired,
      uom: bomLine.uom,
      sizes: bomLine.sizes.map((s) => ({
        productSize: s.productSize,
        materialSize: s.materialSize || '',
        consumption: s.consumption,
      })),
      colors: bomLine.colors.map((c) => {
        const cut = bomLine.cuttingColors?.find((cc) => cc.productColor === c.productColor)
        return {
          productColor: c.productColor,
          materialColor: c.materialColor || '',
          consumption: c.consumption ?? 0,
          cuttingConsumption: cut?.consumption ?? null,
        }
      }),
      destinationCodes: bomLine.destinationCodes,
    }
    isBomDialogOpen.value = true
  } else {
    showWarn(`Không tìm thấy định mức cho: ${gridRow.articleName}`)
  }
}

emitRows()
</script>

<template>
  <div>
    <BaseMatrixGrid
      :source="viewRows as unknown as GridRow[]"
      :columns="columns"
      :column-types="COLUMN_TYPES"
      :display-rows="displayRows"
      :additional-data="{
        onSplit: handleSplit,
        onViewBom: handleViewBom,
      }"
      @beforeedit="handleBeforeEdit"
      @afteredit="handleAfterEdit"
    />

    <BomDetailDialog
      v-model:visible="isBomDialogOpen"
      :bom-line="selectedBomLine"
      :is-cutting="isCutting"
      :style-color-order="assignment.styleColorOrder"
      :style-size-order="assignment.styleSizeOrder"
    />
  </div>
</template>
