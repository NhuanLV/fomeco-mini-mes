<script setup lang="ts">
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { computed } from 'vue'

const props = defineProps<MatrixGridCellProps>()

const value = computed(() => props.model?.[props.prop as string])
const options = computed(
  () => (props.model?.supplierOptions as Array<{ label: string; value: string }>) || [],
)

const label = computed(() => {
  const option = options.value.find((o) => o.value === value.value)
  return option?.label ?? value.value ?? ''
})

const rowKind = computed(() => props.model?.rowKind)
</script>

<template>
  <div class="flex h-full w-full items-center justify-start px-2">
    <span v-if="rowKind === 'parent'" class="text-toned">-</span>
    <span v-else-if="!value" class="text-toned italic">Chọn đơn vị...</span>
    <span v-else class="truncate">{{ label }}</span>
  </div>
</template>
