<script setup lang="ts">
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'

interface Addition {
  onViewBom: (rowIndex: number) => void
}

const props = defineProps<MatrixGridCellProps & { addition?: Addition }>()

function handleClick() {
  props.addition?.onViewBom(props.rowIndex)
}
</script>
<template>
  <div class="flex h-full items-center justify-center">
    <UButton
      v-if="props.model.type !== 'SEMI_FINISHED_PRODUCT'"
      label="Xem"
      variant="ghost"
      size="sm"
      @click.stop.prevent="handleClick"
    />
  </div>
</template>
