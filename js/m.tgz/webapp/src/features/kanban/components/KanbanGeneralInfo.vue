<script setup lang="ts">
import type { KanbanDetailVm } from '@/api'
import { getStatusLabel, getStatusSeverity } from '@/features/kanban/helpers/kanban'
import { useAuthStore } from '@/shared/stores/auth'
import dayjs from 'dayjs'

defineProps<{
  kanban: KanbanDetailVm
  isRejecting?: boolean
  isApproving?: boolean
  isLoading?: boolean
  isCancelling?: boolean
}>()

const emit = defineEmits<{
  approve: []
  reject: []
  cancel: []
}>()

const { hasPermission } = useAuthStore()
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-wrap items-center gap-2">
          <span class="text-lg">Thông tin chung</span>
          <UBadge
            :label="kanban.kanbanType === 'EXTRA' ? 'Ngoài định mức' : 'Trong định mức'"
            :color="kanban.kanbanType === 'EXTRA' ? 'warning' : 'info'"
            size="md"
          />
          <UBadge
            :label="getStatusLabel(kanban.status)"
            :color="getStatusSeverity(kanban.status)"
            size="md"
          />
        </div>
        <div class="ml-auto flex items-center gap-2">
          <div
            v-if="kanban.status === 'CANCELLED'"
            class="flex items-center gap-2 text-sm font-normal whitespace-nowrap text-error"
          >
            <span v-if="kanban.cancelledByName" class="font-semibold"
              >Đã huỷ bởi {{ kanban.cancelledByName }}
              <template v-if="kanban.cancelledAt">
                · {{ dayjs(kanban.cancelledAt).format('DD/MM/YYYY HH:mm') }}</template
              >
            </span>
            <span>Lý do huỷ: {{ kanban.cancellationReason }}</span>
          </div>
          <UButton
            v-if="kanban.canCancel && !kanban.cancellationBlocked"
            label="Huỷ Kanban"
            icon="i-lucide-ban"
            color="error"
            variant="subtle"
            :loading="isCancelling"
            @click="emit('cancel')"
          />
          <template
            v-if="
              (kanban.status === 'PENDING_EVALUATION' && hasPermission('EVALUATE_KANBAN')) ||
              (kanban.status === 'PENDING_EXTRA_EVALUATION' &&
                hasPermission('EVALUATE_EXTRA_KANBAN'))
            "
          >
            <UButton
              label="Từ chối"
              icon="i-lucide-x"
              color="error"
              variant="outline"
              :loading="isRejecting"
              @click="emit('reject')"
            />
            <UButton
              label="Phê duyệt"
              icon="i-lucide-check"
              color="success"
              :loading="isApproving"
              @click="emit('approve')"
            />
          </template>
        </div>
      </div>
    </template>
    <template #default>
      <div
        class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5"
        :class="{ 'pointer-events-none opacity-50': isLoading }"
      >
        <div class="flex flex-col gap-1">
          <span class="text-sm font-medium text-toned">Mã Kanban</span>
          <span class="text-base font-semibold text-highlighted">{{
            kanban.id.slice(-6).toUpperCase()
          }}</span>
        </div>
        <div class="flex flex-col gap-1">
          <span class="text-sm font-medium text-toned">Mã hàng</span>
          <span class="text-base font-semibold text-highlighted">{{
            kanban.styleName || '-'
          }}</span>
        </div>
        <div class="flex flex-col gap-1">
          <span class="text-sm font-medium text-toned">Số lệnh</span>
          <span class="text-base font-semibold text-highlighted">
            {{ kanban.productionOrderCode || '-' }}
          </span>
        </div>
        <div class="flex flex-col gap-1">
          <span class="text-sm font-medium text-toned">Tổ yêu cầu</span>
          <span class="text-base font-semibold text-highlighted">{{ kanban.teamName }}</span>
        </div>
        <div class="flex flex-col gap-1">
          <span class="text-sm font-medium text-toned">Người tạo</span>
          <span class="text-base font-medium text-highlighted">
            {{ kanban.createdByName }}
            <span class="ml-1 text-sm text-toned">
              ({{ dayjs(kanban.createdAt).format('DD/MM/YYYY HH:mm') }})
            </span>
          </span>
        </div>
      </div>
    </template>
  </UCard>
</template>
