<script setup lang="ts">
import { ref, watch } from 'vue'
import { showWarn } from '@/shared/utils/toast'

const props = defineProps<{ visible: boolean; isCancelling: boolean }>()
const emit = defineEmits<{
  'update:visible': [value: boolean]
  cancel: [reason: string]
}>()
const reason = ref('')
watch(
  () => props.visible,
  (visible) => {
    if (visible) reason.value = ''
  },
)

function confirm() {
  if (props.isCancelling) return
  if (!reason.value.trim()) {
    showWarn('Vui lòng nhập lý do huỷ')
    return
  }
  emit('cancel', reason.value.trim())
}
</script>

<template>
  <UModal
    :open="visible"
    title="Huỷ Kanban"
    class="sm:max-w-[30rem]"
    @update:open="!isCancelling && emit('update:visible', $event)"
  >
    <template #body>
      <div class="flex flex-col gap-4">
        <p>Bạn có chắc chắn muốn huỷ Kanban này không?</p>
        <div class="flex flex-col gap-2">
          <label for="kanban-cancel-reason" class="font-medium"
            >Lý do huỷ <span class="text-error">*</span></label
          >
          <UTextarea
            id="kanban-cancel-reason"
            v-model="reason"
            :rows="4"
            autoresize
            required
            :disabled="isCancelling"
            class="w-full"
            placeholder="Nhập lý do huỷ Kanban..."
          />
        </div>
      </div>
    </template>
    <template #footer>
      <UButton
        label="Không"
        variant="ghost"
        color="neutral"
        :disabled="isCancelling"
        @click="emit('update:visible', false)"
      />
      <UButton label="Xác nhận huỷ" color="error" :loading="isCancelling" @click="confirm" />
    </template>
  </UModal>
</template>
