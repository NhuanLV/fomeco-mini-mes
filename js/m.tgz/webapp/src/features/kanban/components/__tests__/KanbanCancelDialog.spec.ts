import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'
import KanbanCancelDialog from '../KanbanCancelDialog.vue'

const showWarn = vi.fn()
vi.mock('@/shared/utils/toast', () => ({ showWarn: (...args: unknown[]) => showWarn(...args) }))

function dialog(isCancelling = false) {
  return mount(KanbanCancelDialog, {
    props: { visible: true, isCancelling },
    global: {
      stubs: {
        Modal: { template: '<div><slot name="body"/><slot name="footer"/></div>' },
        Textarea: {
          props: ['modelValue'],
          emits: ['update:modelValue'],
          template:
            '<textarea :value="modelValue" @input="$emit(\'update:modelValue\', $event.target.value)" />',
        },
        Button: {
          props: ['label', 'disabled'],
          template: '<button :disabled="disabled">{{ label }}</button>',
        },
      },
    },
  })
}

describe('Huỷ Kanban dialog', () => {
  it('requires a nonblank reason and emits the trimmed reason', async () => {
    const wrapper = dialog()
    await wrapper.find('textarea').setValue('   ')
    await wrapper.findAll('button')[1]!.trigger('click')
    expect(wrapper.emitted('cancel')).toBeUndefined()
    expect(showWarn).toHaveBeenCalledWith('Vui lòng nhập lý do huỷ')
    await wrapper.find('textarea').setValue(' Đổi kế hoạch ')
    await wrapper.findAll('button')[1]!.trigger('click')
    expect(wrapper.emitted('cancel')).toEqual([['Đổi kế hoạch']])
  })

  it('closing does not cancel and submitting twice while loading is blocked', async () => {
    const wrapper = dialog()
    await wrapper.findAll('button')[0]!.trigger('click')
    expect(wrapper.emitted('update:visible')).toEqual([[false]])
    expect(wrapper.emitted('cancel')).toBeUndefined()
    await wrapper.setProps({ isCancelling: true })
    await wrapper.find('textarea').setValue('Đổi')
    await wrapper.findAll('button')[1]!.trigger('click')
    expect(wrapper.emitted('cancel')).toBeUndefined()
  })
})
