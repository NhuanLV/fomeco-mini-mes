import type { KanbanHistoryEventVm } from '@/api/types.gen'
import { describe, expect, it } from 'vitest'
import { getGdnAttempts } from '../kanbanGdnDisplay'

describe('kanban GDN display data', () => {
  it('keeps independent NPL and BTP attempts for a mixed receive event', () => {
    const row = {
      gdnAttempts: [
        { materialType: 'NPL', status: 'SUCCESS', canRetry: false, message: 'NPL done' },
        { materialType: 'BTP', status: 'FAILED', canRetry: true, message: 'BTP failed' },
      ],
    } as unknown as KanbanHistoryEventVm

    expect(getGdnAttempts(row)).toEqual(row.gdnAttempts)
  })

  it('falls back to the legacy single-GDN fields', () => {
    const row = {
      gdnStatus: 'FAILED',
      gdnMessage: 'WFX failed',
      canRetryGdn: true,
      gdnAttempts: [],
    } as unknown as KanbanHistoryEventVm

    expect(getGdnAttempts(row)).toEqual([
      expect.objectContaining({
        materialType: 'ALL',
        status: 'FAILED',
        message: 'WFX failed',
        canRetry: true,
      }),
    ])
  })

  it('disables retry when legacy gdnStatus is NOT_APPLICABLE', () => {
    const row = {
      gdnStatus: 'NOT_APPLICABLE',
      gdnMessage: null,
      canRetryGdn: false,
      gdnAttempts: [],
    } as unknown as KanbanHistoryEventVm

    expect(getGdnAttempts(row)).toEqual([
      expect.objectContaining({
        materialType: 'ALL',
        status: 'NOT_APPLICABLE',
        canRetry: false,
      }),
    ])
  })
})
