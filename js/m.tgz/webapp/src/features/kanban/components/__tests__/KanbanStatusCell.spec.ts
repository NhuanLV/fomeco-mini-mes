import KanbanStatusCell from '@/features/kanban/components/grid/KanbanStatusCell.vue'
import type { FlatKanbanItem } from '@/features/kanban/types'
import type { MatrixGridCellProps } from '@/shared/components/grid/matrixGrid'
import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'

const mockHasPermission = vi.fn()
vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({
    hasPermission: (...args: unknown[]) => mockHasPermission(...args),
  }),
}))

describe('KanbanStatusCell', () => {
  const baseItem: FlatKanbanItem = {
    article: 'ART-01',
    alternativeName: 'Art 01',
    color: 'Red',
    size: 'M',
    uom: 'PCS',
    totalConsumption: 1000,
    cumulativeReported: 400,
    creatorNote: '',
    supplierNote: '',
    purchaseOrderId: 'po-1',
    purchaseOrderCode: 'PO-01',
    requiredQty: 400,
    actualIssuedQty: 400,
    stockQty: 500,
    issued: false,
    received: false,
    supplierId: 'wh-1',
    supplierName: 'Warehouse 1',
  }

  const createProps = (
    model: FlatKanbanItem,
    addition?: { receiveOnlyMode?: boolean },
  ): MatrixGridCellProps & { addition?: { receiveOnlyMode?: boolean } } =>
    ({
      model,
      prop: 'actualIssuedQty',
      rowIndex: 0,
      colIndex: 0,
      colType: 'rgRow',
      type: 'rgRow',
      data: [],
      column: { prop: 'actualIssuedQty' },
      addition,
    }) as unknown as MatrixGridCellProps & { addition?: { receiveOnlyMode?: boolean } }

  describe('Warehouse role (PREPARE / ISSUE)', () => {
    it('displays prepared quantity (400 / 400) in soft blue when prepared but not yet issued', () => {
      mockHasPermission.mockImplementation((perm: string) => perm === 'PREPARE_MATERIAL')
      const wrapper = mount(KanbanStatusCell, {
        props: createProps(
          { ...baseItem, actualIssuedQty: 400, issued: false },
          { receiveOnlyMode: false },
        ),
      })

      expect(wrapper.text()).toBe('400 / 400')
      expect(wrapper.find('.text-sky-600').exists()).toBe(true)
      expect(wrapper.find('.font-bold.text-green-600').exists()).toBe(false)
    })

    it('displays 400 / 400 in green when issued', () => {
      mockHasPermission.mockImplementation((perm: string) => perm === 'ISSUE_MATERIAL')
      const wrapper = mount(KanbanStatusCell, {
        props: createProps(
          { ...baseItem, actualIssuedQty: 400, issued: true },
          { receiveOnlyMode: false },
        ),
      })

      expect(wrapper.text()).toBe('400 / 400')
      expect(wrapper.find('.font-bold.text-green-600').exists()).toBe(true)
      expect(wrapper.find('.text-sky-600').exists()).toBe(false)
    })
  })

  describe('Team Leader / Receiver role (receiveOnlyMode)', () => {
    it('keeps the partial issued quantity visible after receipt actions end', () => {
      mockHasPermission.mockImplementation((perm: string) => perm === 'CREATE_KANBAN')
      const wrapper = mount(KanbanStatusCell, {
        props: createProps(
          { ...baseItem, actualIssuedQty: 200, issued: true, received: true },
          { receiveOnlyMode: false },
        ),
      })

      expect(wrapper.text()).toBe('200 / 400')
      expect(wrapper.find('.font-bold.text-green-600').exists()).toBe(true)
    })

    it('displays 0 / requiredQty in normal text when warehouse has only prepared (not yet issued)', () => {
      mockHasPermission.mockImplementation((perm: string) => perm === 'CREATE_KANBAN')
      const wrapper = mount(KanbanStatusCell, {
        props: createProps(
          { ...baseItem, actualIssuedQty: 400, issued: false, received: false },
          { receiveOnlyMode: true },
        ),
      })

      expect(wrapper.text()).toBe('0 / 400')
      expect(wrapper.find('.text-green-600').exists()).toBe(false)
      expect(wrapper.find('.text-sky-600').exists()).toBe(false)
    })

    it('displays actualIssuedQty / requiredQty in normal text when warehouse has issued but not yet received', () => {
      mockHasPermission.mockImplementation((perm: string) => perm === 'CREATE_KANBAN')
      const wrapper = mount(KanbanStatusCell, {
        props: createProps(
          { ...baseItem, actualIssuedQty: 400, issued: true, received: false },
          { receiveOnlyMode: true },
        ),
      })

      expect(wrapper.text()).toBe('400 / 400')
      expect(wrapper.find('.text-green-600').exists()).toBe(false)
      expect(wrapper.find('.text-sky-600').exists()).toBe(false)
    })

    it('displays actualIssuedQty / requiredQty in bold green when received', () => {
      mockHasPermission.mockImplementation((perm: string) => perm === 'CREATE_KANBAN')
      const wrapper = mount(KanbanStatusCell, {
        props: createProps(
          { ...baseItem, actualIssuedQty: 400, issued: true, received: true },
          { receiveOnlyMode: true },
        ),
      })

      expect(wrapper.text()).toBe('400 / 400')
      expect(wrapper.find('.font-bold.text-green-600').exists()).toBe(true)
    })
  })
})
