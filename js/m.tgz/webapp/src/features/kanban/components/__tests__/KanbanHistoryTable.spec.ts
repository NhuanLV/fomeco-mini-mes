import { config, mount } from '@vue/test-utils'
import { ref } from 'vue'
import { describe, expect, it, vi } from 'vitest'
import KanbanHistoryTable from '../KanbanHistoryTable.vue'

// Icons are unrelated to history behavior; avoid external icon requests in unit tests.
config.global.stubs = { ...config.global.stubs, Icon: true }

import type { KanbanHistoryEventVm } from '@/api'

const mockHistory = ref<KanbanHistoryEventVm[]>([
  {
    type: 'KanbanMaterialReceived' as const,
    occurredAt: '2026-08-05T10:00:00Z',
    productionOrderCode: 'PO-001',
    actor: { id: 'u1', name: 'Nguyễn Văn A' },
    detail: { 'Vải A': '10' },
    gdnStatus: 'PENDING',
    canRetryGdn: false,
    gdnAttempts: [{ materialType: 'ALL', status: 'PENDING', canRetry: false, items: [] }],
  },
])

const mockRefetch = vi.fn()

vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({
    hasPermission: () => true,
  }),
}))

vi.mock('@pinia/colada', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@pinia/colada')>()),
  useQuery: () => ({ data: mockHistory, isLoading: ref(false), refetch: mockRefetch }),
  useQueryCache: () => ({ invalidateQueries: vi.fn() }),
}))

describe('KanbanHistoryTable.vue', () => {
  it('hides GDN retry on a cancelled kanban even when the attempt failed', async () => {
    const original = mockHistory.value
    mockHistory.value = [
      {
        type: 'KanbanMaterialReceived',
        occurredAt: '2026-08-05T10:00:00Z',
        actor: null,
        detail: {},
        canRetryGdn: false,
        supplierUnitId: 'warehouse',
        gdnAttempts: [{ materialType: 'NPL', status: 'FAILED', canRetry: false, items: [] }],
      },
    ]
    const wrapper = mount(KanbanHistoryTable, {
      props: { kanbanId: 'kb-1', teamId: 'team-1', readOnly: true },
    })
    await wrapper.find('button').trigger('click')
    expect(wrapper.text()).toContain('Thất bại')
    expect(wrapper.text()).not.toContain('Tạo lại GDN')
    wrapper.unmount()
    mockHistory.value = original
  })

  it('is collapsed by default and expands when clicked', async () => {
    const wrapper = mount(KanbanHistoryTable, {
      props: {
        kanbanId: 'kb-1',
        teamId: 'team-1',
      },
    })

    expect(wrapper.text()).toContain('Lịch sử hoạt động')
    expect(wrapper.text()).toContain('Xem lịch sử')
    expect(wrapper.text()).not.toContain('PO-001')

    await wrapper.find('button').trigger('click')
    expect(wrapper.text()).toContain('Thu gọn')
    expect(wrapper.text()).toContain('PO-001')
    expect(wrapper.text()).toContain('Đang tạo')
  })

  it('renders "Không áp dụng" for NOT_APPLICABLE status and no retry button', async () => {
    mockHistory.value = [
      {
        type: 'KanbanMaterialReceived' as const,
        occurredAt: '2026-08-05T10:00:00Z',
        productionOrderCode: 'PO-001',
        actor: { id: 'u1', name: 'Nguyễn Văn A' },
        detail: { 'Vải A': '10' },
        gdnStatus: 'NOT_APPLICABLE',
        canRetryGdn: false,
        gdnAttempts: [
          { materialType: 'ALL', status: 'NOT_APPLICABLE', canRetry: false, items: [] },
        ],
      },
    ]

    const wrapper = mount(KanbanHistoryTable, {
      props: {
        kanbanId: 'kb-1',
        teamId: 'team-1',
      },
    })

    await wrapper.find('button').trigger('click')
    expect(wrapper.text()).toContain('Không áp dụng')
    expect(wrapper.text()).not.toContain('Thử lại')
  })

  it('renders a failed badge and retry action for a failed GDN', async () => {
    mockHistory.value = [
      {
        type: 'KanbanMaterialReceived',
        occurredAt: '2026-08-05T10:00:00Z',
        productionOrderCode: 'PO-001',
        actor: null,
        detail: { 'BTP CUT / RED / M': '10' },
        gdnStatus: 'FAILED',
        canRetryGdn: true,
        supplierUnitId: 'supplier-1',
        gdnAttempts: [
          {
            materialType: 'BTP',
            status: 'FAILED',
            canRetry: true,
            message: 'WFX failed',
            items: [],
          },
        ],
      },
    ]
    const wrapper = mount(KanbanHistoryTable, {
      props: { kanbanId: 'kb-1', teamId: 'team-1' },
    })

    await wrapper.find('button').trigger('click')

    expect(wrapper.text()).toContain('Thất bại')
    expect(wrapper.text()).toContain('Tạo lại GDN')
  })
})
