import { mount } from '@vue/test-utils'
import { expect, it } from 'vitest'
import KanbanPlanTable from '../KanbanPlanTable.vue'

it('keeps PO groups alphabetical and uses API color/size order with alphabet fallback', async () => {
  const plan = [
    { purchaseOrderId: 'b', purchaseOrderCode: 'PO-B', color: 'Blue', size: 'L', qty: 2 },
    { purchaseOrderId: 'a', purchaseOrderCode: 'PO-A', color: 'Blue', size: 'M', qty: 3 },
    { purchaseOrderId: 'a', purchaseOrderCode: 'PO-A', color: 'Red', size: 'S', qty: 4 },
    { purchaseOrderId: 'a', purchaseOrderCode: 'PO-A', color: 'Red', size: 'Z', qty: 5 },
  ]
  const wrapper = mount(KanbanPlanTable, {
    props: { plan },
    attrs: { styleColorOrder: ['Red', 'Blue'], styleSizeOrder: ['S', 'M', 'L'] },
    global: { stubs: { BaseMatrixGrid: true, UCard: { template: '<div><slot /></div>' } } },
  })
  const grid = () => wrapper.findComponent({ name: 'BaseMatrixGrid' })
  expect(
    grid()
      .props('columns')
      .map((col: { prop: string }) => col.prop),
  ).toEqual(['poCode', 'color', 'S', 'M', 'L', 'Z', 'total'])
  expect(
    grid()
      .props('source')
      .map((row: { poCode: string; color: string }) => `${row.poCode}/${row.color}`),
  ).toEqual(['PO-A/Red', 'PO-A/Blue', 'PO-B/Blue'])
  expect(grid().props('source')[0].total).toBe(9)
  expect(plan[0]!.purchaseOrderCode).toBe('PO-B')
  await wrapper.setProps({ plan: [...plan].reverse() })
  expect(grid().props('source')[0].color).toBe('Red')
  wrapper.unmount()
})
