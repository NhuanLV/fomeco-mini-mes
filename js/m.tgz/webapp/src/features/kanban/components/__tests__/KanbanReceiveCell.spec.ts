import KanbanReceiveCell from '@/features/kanban/components/grid/KanbanReceiveCell.vue'
import type { FlatKanbanItem } from '@/features/kanban/types'
import { kanbanItemKey } from '@/features/kanban/fulfillment/kanbanFulfillment'
import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'

vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({ hasPermission: () => true }),
}))

describe('KanbanReceiveCell', () => {
  const item = {
    article: 'MAT-1',
    color: 'RED',
    size: 'M',
    purchaseOrderId: 'po-1',
    issued: true,
    received: false,
  } as FlatKanbanItem

  it('disables receive while the item has a pending or failed GDN', () => {
    const wrapper = mount(KanbanReceiveCell, {
      props: {
        model: item,
        addition: {
          teamId: 'team-1',
          selectedToReceive: [],
          blockedReceiveKeys: new Set([kanbanItemKey(item)]),
          onToggleReceive: vi.fn(),
        },
      } as never,
    })

    expect(wrapper.find('button').attributes('disabled')).toBeDefined()
  })
})
