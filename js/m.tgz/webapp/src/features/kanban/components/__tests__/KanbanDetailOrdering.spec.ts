import { mount } from '@vue/test-utils'
import { expect, it, vi } from 'vitest'
import KanbanDetailGrid from '../KanbanDetailGrid.vue'
import { kanbanItemKey } from '@/features/kanban/fulfillment/kanbanFulfillment'
import type { FlatKanbanItem } from '@/features/kanban/types'

vi.mock('@/shared/stores/auth', () => ({ useAuthStore: () => ({ hasPermission: () => false }) }))
vi.mock('@/shared/composables/useConfirm', () => ({ useConfirm: () => ({ require: vi.fn() }) }))

it('keeps sorted row indices attached to the matching item while editing', async () => {
  const items: FlatKanbanItem[] = ['Blue', 'Red'].map((color) => ({
    article: 'BTP CUT-1',
    color,
    size: 'M',
    uom: 'PCS',
    totalConsumption: 10,
    cumulativeReported: 0,
    creatorNote: '',
    supplierNote: '',
    purchaseOrderId: null,
    purchaseOrderCode: null,
    requiredQty: 10,
    actualIssuedQty: 0,
    stockQty: 0,
    issued: false,
    received: false,
    supplierId: 'supplier',
    supplierName: 'Supplier',
  }))
  const wrapper = mount(KanbanDetailGrid, {
    props: {
      items,
      teamId: 'team',
      kanbanStatus: 'APPROVED',
      reviseMode: false,
      isPreparing: false,
      isIssuing: false,
      isReceiving: false,
      isRevising: false,
      prepareInputs: {},
      supplierNotes: {},
      creatorNotes: {},
      selectedToIssue: {},
      selectedToReceive: {},
      reviseInputs: {},
    },
    attrs: { styleColorOrder: ['Red', 'Blue'], styleSizeOrder: ['S', 'M'] },
    global: { stubs: { BaseMatrixGrid: true, UIcon: true } },
  })
  const grid = () => wrapper.findComponent({ name: 'BaseMatrixGrid' })
  expect(
    grid()
      .props('source')
      .map((row: FlatKanbanItem) => row.color),
  ).toEqual(['Red', 'Blue'])
  await wrapper.setProps({ reviseMode: true })
  expect(
    grid()
      .props('source')
      .map((row: FlatKanbanItem) => row.color),
  ).toEqual(['Red', 'Blue'])
  grid().vm.$emit('afteredit', [{ rowIndex: 0, prop: 'reviseQty', value: 7 }])
  expect(wrapper.emitted('update:reviseInputs')!.at(-1)).toEqual([
    { [kanbanItemKey(items[1]!)]: 7 },
  ])
  expect(items.map((item) => item.color)).toEqual(['Blue', 'Red'])
  wrapper.unmount()
})
