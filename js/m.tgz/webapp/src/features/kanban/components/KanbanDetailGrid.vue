<script setup lang="ts">
import { useKanbanFulfillmentGrid } from '@/features/kanban/fulfillment/useKanbanFulfillmentGrid'
import {
  exceedsRequiredQtyAfterPrepare,
  fillAllPrepareInputs,
  kanbanItemKey,
  type KanbanStatus,
} from '@/features/kanban/fulfillment/kanbanFulfillment'
import { buildColumns } from '@/features/kanban/helpers/kanbanFulfillmentGridConfig'
import type { FlatKanbanItem } from '@/features/kanban/types'
import BaseMatrixGrid from '@/shared/components/grid/BaseMatrixGrid.vue'
import {
  matrixGridCell,
  type MatrixGridColumnTypes,
  matrixGridEditor,
} from '@/shared/components/grid/matrixGrid'
import { useAuthStore } from '@/shared/stores/auth'
import { useConfirm } from '@/shared/composables/useConfirm'
import { computed, toRef } from 'vue'
import KanbanIssueCell from './grid/KanbanIssueCell.vue'
import KanbanPrepareCell from './grid/KanbanPrepareCell.vue'
import KanbanPrepareEditor from './grid/KanbanPrepareEditor.vue'
import MatrixQtyCell from '@/shared/components/grid/MatrixQtyCell.vue'
import NoteEditor from '@/shared/components/grid/NoteEditor.vue'
import KanbanReceiveCell from './grid/KanbanReceiveCell.vue'
import KanbanReviseQtyEditor from './grid/KanbanReviseQtyEditor.vue'
import KanbanStatusCell from './grid/KanbanStatusCell.vue'
import type { GridRow } from '@/shared/composables/useGridLayout'
import { makeArticleVariantComparator } from '@/shared/utils/orderedValues'

const props = defineProps<{
  items: FlatKanbanItem[]
  teamId: string
  isPreparing: boolean
  isIssuing: boolean
  isReceiving: boolean
  isRevising: boolean
  isLoading?: boolean
  reviseMode: boolean
  kanbanStatus?: KanbanStatus
  blockedReceiveKeys?: Set<string>
  styleColorOrder?: string[]
  styleSizeOrder?: string[]
}>()

const COLUMN_TYPES: MatrixGridColumnTypes = {
  qty: { cellTemplate: matrixGridCell(MatrixQtyCell) },
  status: { cellTemplate: matrixGridCell(KanbanStatusCell) },
  prepare: {
    cellTemplate: matrixGridCell(KanbanPrepareCell),
    editor: matrixGridEditor(KanbanPrepareEditor),
  },
  issue: { cellTemplate: matrixGridCell(KanbanIssueCell) },
  receive: { cellTemplate: matrixGridCell(KanbanReceiveCell) },
  note: { editor: matrixGridEditor(NoteEditor) },
  reviseQty: { editor: matrixGridEditor(KanbanReviseQtyEditor) },
}
const prepareInputs = defineModel<Record<string, number>>('prepareInputs', { required: true })
const supplierNotes = defineModel<Record<string, string>>('supplierNotes', { required: true })
const creatorNotes = defineModel<Record<string, string>>('creatorNotes', { required: true })
const selectedToIssue = defineModel<Record<string, FlatKanbanItem[]>>('selectedToIssue', {
  required: true,
})
const selectedToReceive = defineModel<Record<string, FlatKanbanItem[]>>('selectedToReceive', {
  required: true,
})
const reviseInputs = defineModel<Record<string, number>>('reviseInputs', { required: true })

const emit = defineEmits<{
  prepare: [supplierId: string]
  issue: [supplierId: string]
  receive: [supplierId: string]
  revise: []
}>()

const { hasPermission } = useAuthStore()
const confirm = useConfirm()
const orderedItems = computed(() => {
  const cmpArticleVariant = makeArticleVariantComparator(
    props.styleColorOrder,
    props.styleSizeOrder,
  )
  return [...props.items].sort(
    (left, right) =>
      cmpArticleVariant(left, right) ||
      (left.purchaseOrderCode ?? '').localeCompare(right.purchaseOrderCode ?? '') ||
      left.supplierName.localeCompare(right.supplierName, 'vi'),
  )
})

const {
  enrichedItems,
  canShowIssue,
  canShowPrepare,
  canShowReceive,
  canEditSupplierNote,
  receiveOnlyMode,
  showStockColumn,
  prepareSuppliers,
  issueSuppliers,
  receiveSuppliers,
  hasReviseChanges,
  reviseQtyDisplay,
  handleBeforeEdit,
  handleAfterEdit,
  handleToggleIssue,
  handleToggleReceive,
} = useKanbanFulfillmentGrid({
  items: orderedItems,
  teamId: toRef(props, 'teamId'),
  kanbanStatus: toRef(props, 'kanbanStatus'),
  reviseMode: toRef(props, 'reviseMode'),
  prepareInputs,
  supplierNotes,
  creatorNotes,
  selectedToIssue,
  selectedToReceive,
  reviseInputs,
  blockedReceiveKeys: computed(() => props.blockedReceiveKeys ?? new Set()),
  hasPermission,
})

const columns = computed(() =>
  buildColumns({
    reviseMode: props.reviseMode,
    kanbanStatus: props.kanbanStatus,
    canShowPrepare: canShowPrepare.value,
    canShowIssue: canShowIssue.value,
    canShowReceive: canShowReceive.value,
    canEditSupplierNote: canEditSupplierNote.value,
    receiveOnlyMode: receiveOnlyMode.value,
    showStockColumn: showStockColumn.value,
  }),
)

const canFillAllPrepare = computed(() =>
  props.items.some((item) => !item.issued && hasPermission('PREPARE_MATERIAL', item.supplierId)),
)
function handleFillAllPrepare() {
  prepareInputs.value = fillAllPrepareInputs(props.items, prepareInputs.value, hasPermission)
}

function handleSavePrepare() {
  const suppliers = [...prepareSuppliers.value]
  const exceedsDemand = props.items.some(
    (item) =>
      suppliers.includes(item.supplierId) &&
      !item.issued &&
      (prepareInputs.value[kanbanItemKey(item)] ?? 0) > 0 &&
      exceedsRequiredQtyAfterPrepare(item, prepareInputs.value[kanbanItemKey(item)] ?? 0),
  )

  if (!exceedsDemand) {
    suppliers.forEach((sid) => emit('prepare', sid))
    return
  }

  confirm.require({
    message:
      'Số lượng chuẩn bị thêm đang vượt quá SL nhu cầu của Kanban. Bạn có chắc chắn muốn lưu không?',
    acceptLabel: 'Xác nhận',
    rejectLabel: 'Hủy',
    accept: () => suppliers.forEach((sid) => emit('prepare', sid)),
  })
}
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span>Danh sách vật tư / BTP</span>
          <span v-if="reviseMode" class="text-warn text-sm font-normal text-orange-600">
            — Đang chỉnh sửa {{ reviseQtyDisplay }}
          </span>
        </div>
        <div class="flex items-center gap-2">
          <template v-if="!reviseMode">
            <UButton
              v-if="canShowPrepare"
              label="Phát toàn bộ"
              icon="i-lucide-paint-bucket"
              color="neutral"
              variant="subtle"
              :disabled="!canFillAllPrepare"
              title="Tự động điền số lượng còn lại cần chuẩn bị"
              @click="handleFillAllPrepare"
            />
            <UButton
              v-if="canShowPrepare"
              label="Lưu chuẩn bị"
              icon="i-lucide-save"
              color="info"
              variant="subtle"
              :loading="isPreparing"
              :disabled="prepareSuppliers.length === 0"
              @click="handleSavePrepare"
            />
            <UButton
              v-if="canShowIssue"
              label="Xuất kho"
              icon="i-lucide-package-minus"
              color="success"
              variant="solid"
              :loading="isIssuing"
              :disabled="issueSuppliers.length === 0"
              @click="issueSuppliers.forEach((sid) => emit('issue', sid))"
            />
            <UButton
              v-if="canShowReceive"
              :label="receiveOnlyMode ? 'Xác nhận' : 'Xác nhận nhận'"
              icon="i-lucide-circle-check"
              color="success"
              variant="solid"
              :loading="isReceiving"
              :disabled="receiveSuppliers.length === 0"
              @click="receiveSuppliers.forEach((sid) => emit('receive', sid))"
            />
          </template>
          <template v-else>
            <UButton
              label="Lưu và gửi lại"
              icon="i-lucide-send"
              color="warning"
              :loading="isRevising"
              :disabled="!hasReviseChanges"
              @click="emit('revise')"
            />
          </template>
        </div>
      </div>
    </template>
    <template #default>
      <div :class="{ 'pointer-events-none opacity-50': isLoading }">
        <BaseMatrixGrid
          :source="enrichedItems as unknown as GridRow[]"
          :columns="columns"
          :column-types="COLUMN_TYPES"
          :additional-data="{
            teamId,
            prepareInputs,
            supplierNotes,
            creatorNotes,
            reviseInputs,
            selectedToIssue: Object.values(selectedToIssue).flat(),
            selectedToReceive: Object.values(selectedToReceive).flat(),
            receiveOnlyMode,
            blockedReceiveKeys: blockedReceiveKeys ?? new Set(),
            onToggle: handleToggleIssue,
            onToggleReceive: handleToggleReceive,
          }"
          @beforeedit="handleBeforeEdit"
          @afteredit="handleAfterEdit"
        />
      </div>
      <p v-if="reviseMode && !hasReviseChanges" class="mt-2 text-xs text-toned italic">
        Chưa có thay đổi — nhấp vào cột SL nhu cầu để sửa
      </p>
    </template>
  </UCard>
</template>
