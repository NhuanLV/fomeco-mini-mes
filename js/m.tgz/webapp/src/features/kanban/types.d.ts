export interface FlatKanbanItem {
  purchaseOrderType?: 'REGULAR' | 'POSITIVE' | null
  article: string
  articleCode?: string | null
  alternativeName?: string | null
  color: string
  size: string
  uom: string
  totalConsumption: number
  cumulativeReported: number
  creatorNote: string
  supplierNote: string
  purchaseOrderId: string | null
  purchaseOrderCode: string | null
  requiredQty: number
  actualIssuedQty: number
  stockQty: number | null
  issued: boolean
  received: boolean
  supplierId: string
  supplierName: string
}

export interface SupplierAssignment {
  id: string
  name: string
  items: FlatKanbanItem[]
}
