import {
  approveExtraKanbanMutation,
  approveKanbanMutation,
  cancelKanbanMutation,
  getKanbanHistoryQueryKey,
  getKanbanQuery,
  getKanbanQueryKey,
  issueMaterialMutation,
  prepareMaterialMutation,
  receiveMaterialMutation,
  rejectKanbanMutation,
  reviseKanbanMutation,
} from '@/api/@pinia/colada.gen'
import type { FlatKanbanItem } from '@/features/kanban/types'
import { useAuthStore } from '@/shared/stores/auth'
import { showError, showSuccess, showWarn } from '@/shared/utils/toast'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import { computed, ref } from 'vue'
import {
  autoSelectIssueableItems,
  buildFulfillmentPolicy,
  buildIssueCommand,
  buildPrepareCommand,
  buildReceiveCommand,
  buildReviseCommand,
  flattenKanbanItems,
  groupSupplierAssignments,
  type KanbanNoteMap,
} from './kanbanFulfillment'

export function useKanbanFulfillment(kanbanId: string) {
  const queryCache = useQueryCache()
  const { hasPermission } = useAuthStore()
  const {
    data: kanban,
    isLoading,
    refetch,
  } = useQuery(() => getKanbanQuery({ path: { id: kanbanId } }))

  const prepareInputs = ref<Record<string, number>>({})
  const prepareIdempotency = new Map<string, string>()
  const supplierNotes = ref<KanbanNoteMap>({})
  const creatorNotes = ref<KanbanNoteMap>({})
  const selectedToIssue = ref<Record<string, FlatKanbanItem[]>>({})
  const selectedToReceive = ref<Record<string, FlatKanbanItem[]>>({})
  const reviseInputs = ref<Record<string, number>>({})
  const rejectDialogVisible = ref(false)
  const cancelDialogVisible = ref(false)

  const flatItems = computed(() =>
    kanban.value ? flattenKanbanItems(kanban.value, supplierNotes.value) : [],
  )
  const assignments = computed(() => groupSupplierAssignments(flatItems.value))
  const policy = computed(() =>
    kanban.value
      ? buildFulfillmentPolicy({
          status: kanban.value.status,
          teamId: kanban.value.teamId,
          items: flatItems.value,
          hasPermission,
        })
      : null,
  )
  const isReviseMode = computed(() => policy.value?.isReviseMode ?? false)

  const { mutateAsync: prepareMaterial, isLoading: isPreparing } =
    useMutation(prepareMaterialMutation())
  const { mutateAsync: issueMaterial, isLoading: isIssuing } = useMutation(issueMaterialMutation())
  const { mutateAsync: receiveMaterial, isLoading: isReceiving } =
    useMutation(receiveMaterialMutation())
  const { mutateAsync: reviseKanban, isLoading: isRevising } = useMutation(reviseKanbanMutation())
  const { mutateAsync: approveKanban, isLoading: isApproving } =
    useMutation(approveKanbanMutation())
  const { mutateAsync: approveExtraKanban, isLoading: isApprovingExtra } = useMutation(
    approveExtraKanbanMutation(),
  )
  const { mutateAsync: rejectKanban, isLoading: isRejecting } = useMutation(rejectKanbanMutation())
  const { mutateAsync: cancelKanban, isLoading: isCancelling } = useMutation(cancelKanbanMutation())

  async function openCancelDialog() {
    try {
      await refetch()
      if (!kanban.value?.canCancel) return
      if (kanban.value.cancellationBlocked) {
        showWarn('Không thể huỷ Kanban do đã có hành động nhận NPL/BTP được thực hiện.')
        return
      }
      cancelDialogVisible.value = true
    } catch (error) {
      showError(error instanceof Error ? error.message : 'Không thể kiểm tra điều kiện huỷ Kanban')
    }
  }

  async function handleCancel(reason: string) {
    await runMutation({
      mutate: () => cancelKanban({ path: { id: kanbanId }, body: { reason } }),
      onSuccess: () => {
        cancelDialogVisible.value = false
        // Khóa UI ngay, không chờ các projection async hoàn tất.
        if (kanban.value) {
          queryCache.setQueryData(getKanbanQueryKey({ path: { id: kanbanId } }), {
            ...kanban.value,
            status: 'CANCELLED',
            canCancel: false,
            cancellationReason: reason,
          })
        }
      },
      success: 'Đã huỷ Kanban',
      fallbackError: 'Không thể huỷ Kanban',
    })
  }

  function scheduleRefresh() {
    setTimeout(() => {
      void queryCache.invalidateQueries({
        key: getKanbanQueryKey({ path: { id: kanbanId } }),
      })
      void queryCache.invalidateQueries({
        key: getKanbanHistoryQueryKey({ path: { id: kanbanId } }),
      })
    }, 1000)
  }

  async function runMutation(options: {
    mutate: () => Promise<unknown>
    onSuccess?: () => void
    success: string
    fallbackError: string
  }) {
    try {
      await options.mutate()
      showSuccess(options.success)
      options.onSuccess?.()
      scheduleRefresh()
    } catch (error) {
      showError(error instanceof Error ? error.message : options.fallbackError)
    }
  }

  async function handlePrepare(supplierId: string) {
    const assignment = assignments.value.find((candidate) => candidate.id === supplierId)
    const command = buildPrepareCommand(
      assignment?.items ?? [],
      prepareInputs.value,
      supplierNotes.value,
    )
    if (!command.ok) {
      showWarn(command.error)
      return
    }
    const fingerprint = JSON.stringify(command.body)
    const operation = `${supplierId}:${fingerprint}`
    const idempotencyKey = prepareIdempotency.get(operation) ?? crypto.randomUUID()
    prepareIdempotency.set(operation, idempotencyKey)

    await runMutation({
      mutate: () =>
        prepareMaterial({
          path: { kanbanId, supplierId },
          headers: { 'Idempotency-Key': idempotencyKey },
          body: command.body,
        }),
      onSuccess: () => {
        if (prepareIdempotency.get(operation) === idempotencyKey) {
          prepareIdempotency.delete(operation)
        }
        selectedToIssue.value = {
          ...selectedToIssue.value,
          [supplierId]: autoSelectIssueableItems(
            assignment?.items ?? [],
            selectedToIssue.value[supplierId] ?? [],
            command.preparedKeys,
          ),
        }
        prepareInputs.value = {}
      },
      success: 'Đã cập nhật chuẩn bị vật tư',
      fallbackError: 'Không thể cập nhật chuẩn bị',
    })
  }

  async function handleIssue(supplierId: string) {
    const command = buildIssueCommand(
      selectedToIssue.value[supplierId] ?? [],
      flatItems.value,
      supplierNotes.value,
    )
    if (!command.ok) {
      showWarn(command.error)
      return
    }

    await runMutation({
      mutate: () =>
        issueMaterial({
          path: { kanbanId, supplierId },
          body: command.body,
        }),
      onSuccess: () => {
        selectedToIssue.value = {
          ...selectedToIssue.value,
          [supplierId]: [],
        }
      },
      success: 'Đã xuất kho vật tư',
      fallbackError: 'Không thể xuất kho',
    })
  }

  async function handleReceive(supplierId: string) {
    const command = buildReceiveCommand(selectedToReceive.value[supplierId] ?? [], flatItems.value)
    if (!command.ok) {
      showWarn(command.error)
      return
    }

    await runMutation({
      mutate: () =>
        receiveMaterial({
          path: { kanbanId, supplierId },
          body: command.body,
        }),
      onSuccess: () => {
        selectedToReceive.value = {
          ...selectedToReceive.value,
          [supplierId]: [],
        }
      },
      success: 'Đã xác nhận nhận vật tư',
      fallbackError: 'Không thể xác nhận nhận',
    })
  }

  async function handleRevise() {
    await runMutation({
      mutate: () =>
        reviseKanban({
          path: { id: kanbanId },
          body: buildReviseCommand(flatItems.value, reviseInputs.value, creatorNotes.value),
        }),
      onSuccess: () => {
        reviseInputs.value = {}
      },
      success: 'Đã gửi lại Kanban để duyệt',
      fallbackError: 'Không thể sửa Kanban',
    })
  }

  async function handleApprove() {
    if (!kanban.value) return

    await runMutation({
      mutate: () => {
        if (kanban.value?.status === 'PENDING_EVALUATION') {
          return approveKanban({ path: { id: kanbanId } })
        }
        if (kanban.value?.status === 'PENDING_EXTRA_EVALUATION') {
          return approveExtraKanban({ path: { id: kanbanId } })
        }
        return Promise.reject(new Error('Kanban không ở trạng thái có thể duyệt'))
      },
      success: 'Đã duyệt Kanban',
      fallbackError: 'Không thể duyệt Kanban',
    })
  }

  async function handleReject(reason: string) {
    await runMutation({
      mutate: () => rejectKanban({ path: { id: kanbanId }, body: { reason } }),
      onSuccess: () => {
        rejectDialogVisible.value = false
      },
      success: 'Đã từ chối Kanban',
      fallbackError: 'Không thể từ chối Kanban',
    })
  }

  return {
    kanban,
    isLoading,
    flatItems,
    prepareInputs,
    supplierNotes,
    creatorNotes,
    selectedToIssue,
    selectedToReceive,
    reviseInputs,
    rejectDialogVisible,
    cancelDialogVisible,
    isCancelling,
    openCancelDialog,
    handleCancel,
    isReviseMode,
    isPreparing,
    isIssuing,
    isReceiving,
    isRevising,
    isApproving,
    isApprovingExtra,
    isRejecting,
    handlePrepare,
    handleIssue,
    handleReceive,
    handleRevise,
    handleApprove,
    handleReject,
  }
}
