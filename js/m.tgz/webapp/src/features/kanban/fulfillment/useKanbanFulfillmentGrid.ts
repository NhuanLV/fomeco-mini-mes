import type { PermissionVm } from '@/api'
import type { FlatKanbanItem } from '@/features/kanban/types'
import type { MatrixGridBeforeEdit, MatrixGridEdit } from '@/shared/components/grid/matrixGrid'
import { showWarn } from '@/shared/utils/toast'
import { computed, ref, type Ref, watch } from 'vue'
import {
  autoSelectIssueableMap,
  autoSelectReceivableItems,
  buildFulfillmentPolicy,
  clampPrepareQuantity,
  kanbanItemKey,
  resolveKanbanNote,
  setKanbanNote,
  type KanbanStatus,
} from './kanbanFulfillment'

export interface EnrichedItem extends FlatKanbanItem {
  reviseQty: number
  prepareInput?: number
}

export interface UseKanbanFulfillmentGridParams {
  items: Readonly<Ref<FlatKanbanItem[]>>
  teamId: Ref<string>
  kanbanStatus: Ref<KanbanStatus | undefined>
  reviseMode: Ref<boolean>
  prepareInputs: Ref<Record<string, number>>
  supplierNotes: Ref<Record<string, string>>
  creatorNotes: Ref<Record<string, string>>
  selectedToIssue: Ref<Record<string, FlatKanbanItem[]>>
  selectedToReceive: Ref<Record<string, FlatKanbanItem[]>>
  reviseInputs: Ref<Record<string, number>>
  blockedReceiveKeys: Ref<Set<string>>
  hasPermission: (permission: PermissionVm['code'], targetId?: string) => boolean
}

export function useKanbanFulfillmentGrid({
  items,
  teamId,
  kanbanStatus,
  reviseMode,
  prepareInputs,
  supplierNotes,
  creatorNotes,
  selectedToIssue,
  selectedToReceive,
  reviseInputs,
  blockedReceiveKeys,
  hasPermission,
}: UseKanbanFulfillmentGridParams) {
  const enrichedItems = computed<EnrichedItem[]>(() =>
    items.value.map((item) => ({
      ...item,
      reviseQty: reviseInputs.value[kanbanItemKey(item)] ?? item.requiredQty,
      prepareInput: prepareInputs.value[kanbanItemKey(item)] || 0,
      supplierNote: resolveKanbanNote(supplierNotes.value, item, item.supplierNote),
      creatorNote: resolveKanbanNote(creatorNotes.value, item, item.creatorNote),
    })),
  )
  const policy = computed(() =>
    buildFulfillmentPolicy({
      status: kanbanStatus.value ?? 'APPROVED',
      teamId: teamId.value,
      items: items.value,
      hasPermission,
    }),
  )
  const canShowIssue = computed(() => policy.value.canShowIssue)
  const canShowPrepare = computed(() => policy.value.canShowPrepare)
  const canShowReceive = computed(() => policy.value.canShowReceive)
  const canEditSupplierNote = computed(() => policy.value.canEditSupplierNote)
  const receiveOnlyMode = computed(() => policy.value.receiveOnlyMode)
  const showStockColumn = computed(() => policy.value.showStockColumn)
  const hasAutoSelectedReceive = ref(false)
  const hasAutoSelectedIssue = ref(false)

  watch(
    [items, blockedReceiveKeys],
    ([newItems, blocked]) => {
      if (newItems.length === 0 || hasAutoSelectedReceive.value || !canShowReceive.value) {
        selectedToReceive.value = Object.fromEntries(
          Object.entries(selectedToReceive.value).map(([supplierId, selected]) => [
            supplierId,
            selected.filter((item) => !blocked.has(kanbanItemKey(item))),
          ]),
        )
        return
      }
      selectedToReceive.value = autoSelectReceivableItems(
        newItems.filter((item) => !blocked.has(kanbanItemKey(item))),
        selectedToReceive.value,
        true,
      )
      hasAutoSelectedReceive.value = true
    },
    { immediate: true, deep: true },
  )

  watch(
    items,
    (newItems) => {
      if (newItems.length === 0 || hasAutoSelectedIssue.value || !canShowIssue.value) {
        return
      }
      selectedToIssue.value = autoSelectIssueableMap(newItems, selectedToIssue.value, hasPermission)
      hasAutoSelectedIssue.value = true
    },
    { immediate: true, deep: true },
  )

  function handleBeforeEdit(edit: MatrixGridBeforeEdit) {
    const { rowIndex, prop } = edit
    const item = items.value[rowIndex]
    if (!item) return

    if (prop === 'prepareInput') {
      const canPrepare = hasPermission('PREPARE_MATERIAL', item.supplierId)
      if (!canPrepare || item.issued) edit.preventDefault()
    }
    if (prop === 'supplierNote' && (!canEditSupplierNote.value || item.received)) {
      edit.preventDefault()
    }
    if ((prop === 'creatorNote' || prop === 'reviseQty') && !reviseMode.value) {
      edit.preventDefault()
    }
  }

  function handleAfterEdit(edits: MatrixGridEdit[]) {
    const nextPrepare = { ...prepareInputs.value }
    const nextSupplier = { ...supplierNotes.value }
    const nextCreator = { ...creatorNotes.value }
    const nextRevise = { ...reviseInputs.value }
    let prepareChanged = false
    let supplierChanged = false
    let creatorChanged = false
    let reviseChanged = false

    for (const edit of edits) {
      const item = items.value[edit.rowIndex]
      if (!item) continue

      if (edit.prop === 'prepareInput') {
        const canPrepare = hasPermission('PREPARE_MATERIAL', item.supplierId)
        if (!canPrepare) continue
        const result = clampPrepareQuantity(item, edit.value)
        nextPrepare[kanbanItemKey(item)] = result.value
        prepareChanged = true
        if (result.clamped) {
          showWarn('Chuẩn bị thêm vượt SL tồn. Đã tự điều chỉnh về mức tối đa.')
        }
      }
      if (edit.prop === 'supplierNote' && canEditSupplierNote.value && !item.received) {
        setKanbanNote(nextSupplier, item, String(edit.value ?? ''))
        supplierChanged = true
      }
      if (edit.prop === 'creatorNote' && reviseMode.value) {
        setKanbanNote(nextCreator, item, String(edit.value ?? ''))
        creatorChanged = true
      }
      if (edit.prop === 'reviseQty' && reviseMode.value) {
        const value = Math.max(0, Number(edit.value) || 0)
        const key = kanbanItemKey(item)
        if (value === item.requiredQty) delete nextRevise[key]
        else nextRevise[key] = value
        reviseChanged = true
      }
    }

    if (prepareChanged) prepareInputs.value = nextPrepare
    if (supplierChanged) supplierNotes.value = nextSupplier
    if (creatorChanged) creatorNotes.value = nextCreator
    if (reviseChanged) reviseInputs.value = nextRevise
  }

  function handleToggleIssue(item: FlatKanbanItem) {
    if (!hasPermission('ISSUE_MATERIAL', item.supplierId)) return
    const selected = selectedToIssue.value[item.supplierId] ?? []
    const key = kanbanItemKey(item)
    const exists = selected.some((c) => kanbanItemKey(c) === key)
    selectedToIssue.value = {
      ...selectedToIssue.value,
      [item.supplierId]: exists
        ? selected.filter((c) => kanbanItemKey(c) !== key)
        : [...selected, item],
    }
  }

  function handleToggleReceive(item: FlatKanbanItem) {
    if (!hasPermission('CREATE_KANBAN', teamId.value)) return
    if (blockedReceiveKeys.value.has(kanbanItemKey(item))) return
    const selected = selectedToReceive.value[item.supplierId] ?? []
    const key = kanbanItemKey(item)
    const exists = selected.some((c) => kanbanItemKey(c) === key)
    selectedToReceive.value = {
      ...selectedToReceive.value,
      [item.supplierId]: exists
        ? selected.filter((c) => kanbanItemKey(c) !== key)
        : [...selected, item],
    }
  }

  const prepareSuppliers = computed(() => {
    const suppliers = new Set<string>()
    for (const [key, value] of Object.entries(prepareInputs.value)) {
      if (value <= 0) continue
      const item = items.value.find((candidate) => kanbanItemKey(candidate) === key)
      if (item && !item.issued && hasPermission('PREPARE_MATERIAL', item.supplierId)) {
        suppliers.add(item.supplierId)
      }
    }
    return [...suppliers]
  })
  const issueSuppliers = computed(() =>
    Object.keys(selectedToIssue.value).filter(
      (supplierId) => selectedToIssue.value[supplierId].length > 0,
    ),
  )
  const receiveSuppliers = computed(() =>
    Object.keys(selectedToReceive.value).filter(
      (supplierId) => selectedToReceive.value[supplierId].length > 0,
    ),
  )
  const hasReviseChanges = computed(() => Object.keys(reviseInputs.value).length > 0)
  const reviseQtyDisplay = computed(() => {
    if (!reviseMode.value) return ''
    const changed = Object.keys(reviseInputs.value).length
    return changed > 0 ? `(${changed} dòng đã sửa)` : ''
  })

  return {
    enrichedItems,
    canShowIssue,
    canShowPrepare,
    canShowReceive,
    canEditSupplierNote,
    receiveOnlyMode,
    showStockColumn,
    prepareSuppliers,
    issueSuppliers,
    receiveSuppliers,
    hasReviseChanges,
    reviseQtyDisplay,
    handleBeforeEdit,
    handleAfterEdit,
    handleToggleIssue,
    handleToggleReceive,
  }
}
