import type { KanbanDetailVm } from '@/api'
import {
  autoSelectIssueableItems,
  autoSelectIssueableMap,
  autoSelectReceivableItems,
  buildFulfillmentPolicy,
  buildIssueCommand,
  buildPrepareCommand,
  buildReceiveCommand,
  buildReviseCommand,
  clampPrepareQuantity,
  exceedsRequiredQtyAfterPrepare,
  fillAllPrepareInputs,
  flattenKanbanItems,
  groupSupplierAssignments,
  kanbanItemKey,
  setKanbanNote,
  resolveKanbanNote,
} from '@/features/kanban/fulfillment/kanbanFulfillment'
import type { FlatKanbanItem } from '@/features/kanban/types'
import { describe, expect, it } from 'vitest'

describe('Kanban fulfillment rules', () => {
  it('keeps separate BTP supplier notes and falls back only for legacy parts', () => {
    const kanban = makeKanban()
    const item = kanban.items[0]!
    item.article = 'BTP CUT-1'
    item.parts = [
      { ...item.parts[0]!, purchaseOrderType: 'REGULAR', supplierNote: 'Ghi chú thường' },
      { ...item.parts[0]!, purchaseOrderType: 'POSITIVE', supplierNote: 'Ghi chú dương' },
    ]
    const rows = flattenKanbanItems(kanban)
    expect(rows.map((row) => row.supplierNote)).toEqual(['Ghi chú thường', 'Ghi chú dương'])
    const command = buildIssueCommand(rows, rows, {})
    expect(command.ok).toBe(true)
    if (command.ok)
      expect(command.body.items.map((part) => part.note)).toEqual([
        'Ghi chú thường',
        'Ghi chú dương',
      ])

    item.parts[0]!.supplierNote = null
    item.parts[1]!.supplierNote = ''
    expect(flattenKanbanItems(kanban).map((row) => row.supplierNote)).toEqual(['Ghi chú gốc', ''])
  })

  it('preserves both BTP types with the same SKU, PO and supplier in fulfillment commands', () => {
    const items = (['REGULAR', 'POSITIVE'] as const).map((purchaseOrderType) =>
      makeItem({ article: 'BTP CUT-1', purchaseOrderType }),
    )
    const result = buildReceiveCommand(items, items)
    expect(result.ok).toBe(true)
    if (result.ok)
      expect(result.body.items.map((item) => item.purchaseOrderType)).toEqual([
        'REGULAR',
        'POSITIVE',
      ])
  })

  it('keeps quantities, revisions and notes separate for two suppliers of the same BTP', () => {
    const items = ['team-a', 'team-b'].map((supplierId, index) =>
      makeItem({
        article: 'BTP CUT-1',
        purchaseOrderType: 'REGULAR',
        supplierId,
        requiredQty: (index + 1) * 10,
      }),
    )
    const inputs = fillAllPrepareInputs(items, {}, () => true)
    expect(Object.values(inputs)).toEqual([10, 20])
    const revised = buildReviseCommand(items, { [kanbanItemKey(items[0]!)]: 12 }, {})
    expect(revised.items.map((item) => item.requiredQty)).toEqual([12, 20])
    const notes = {}
    setKanbanNote(notes, items[0]!, 'Giao sáng')
    setKanbanNote(notes, items[1]!, 'Giao chiều')
    expect(items.map((item) => resolveKanbanNote(notes, item, ''))).toEqual([
      'Giao sáng',
      'Giao chiều',
    ])
  })

  it('flattens item parts and groups them by supplier', () => {
    const items = flattenKanbanItems(makeKanban(), {
      [itemKey('PO-1')]: 'Ghi chú vừa sửa',
    })

    expect(items).toEqual([
      expect.objectContaining({
        article: 'Fabric',
        purchaseOrderId: 'PO-1',
        requiredQty: 10,
        supplierId: 'warehouse-1',
        supplierNote: 'Ghi chú vừa sửa',
      }),
      expect.objectContaining({
        article: 'Fabric',
        purchaseOrderId: 'PO-2',
        requiredQty: 5,
        supplierId: 'warehouse-2',
        supplierNote: 'Ghi chú gốc',
      }),
    ])
    expect(groupSupplierAssignments(items)).toEqual([
      expect.objectContaining({ id: 'warehouse-1', items: [items[0]] }),
      expect.objectContaining({ id: 'warehouse-2', items: [items[1]] }),
    ])
  })

  it('derives revise and fulfillment visibility from status and scoped permissions', () => {
    const unissuedItems = [
      makeItem({ article: 'BTP BODY', stockQty: 20, issued: false, received: false }),
    ]
    const issuedItems = [
      makeItem({ article: 'BTP BODY', stockQty: 20, issued: true, received: false }),
    ]
    const allPermissions = (permission: string, unitId?: string) =>
      (permission === 'CREATE_KANBAN' && unitId === 'team-1') ||
      (permission === 'ISSUE_MATERIAL' && unitId === 'warehouse-1') ||
      (permission === 'PREPARE_MATERIAL' && unitId === 'warehouse-1')

    // REJECTED: only reviseMode is active
    expect(
      buildFulfillmentPolicy({
        status: 'REJECTED',
        teamId: 'team-1',
        items: unissuedItems,
        hasPermission: allPermissions,
      }),
    ).toEqual({
      isReviseMode: true,
      canShowIssue: false,
      canShowPrepare: false,
      canShowReceive: false,
      canEditSupplierNote: false,
      receiveOnlyMode: false,
      showStockColumn: false,
    })

    // PENDING_EVALUATION: actions hidden
    expect(
      buildFulfillmentPolicy({
        status: 'PENDING_EVALUATION',
        teamId: 'team-1',
        items: unissuedItems,
        hasPermission: allPermissions,
      }),
    ).toEqual({
      isReviseMode: false,
      canShowIssue: false,
      canShowPrepare: false,
      canShowReceive: false,
      canEditSupplierNote: false,
      receiveOnlyMode: false,
      showStockColumn: false,
    })

    // APPROVED with unissued items: prepare & issue available
    expect(
      buildFulfillmentPolicy({
        status: 'APPROVED',
        teamId: 'team-1',
        items: unissuedItems,
        hasPermission: allPermissions,
      }),
    ).toEqual({
      isReviseMode: false,
      canShowIssue: true,
      canShowPrepare: true,
      canShowReceive: false,
      canEditSupplierNote: true,
      receiveOnlyMode: false,
      showStockColumn: true,
    })

    // APPROVED with issued items: receive available
    expect(
      buildFulfillmentPolicy({
        status: 'APPROVED',
        teamId: 'team-1',
        items: issuedItems,
        hasPermission: allPermissions,
      }),
    ).toEqual({
      isReviseMode: false,
      canShowIssue: false,
      canShowPrepare: false,
      canShowReceive: true,
      canEditSupplierNote: false,
      receiveOnlyMode: true,
      showStockColumn: false,
    })

    // COMPLETED: everything hidden
    expect(
      buildFulfillmentPolicy({
        status: 'COMPLETED',
        teamId: 'team-1',
        items: [makeItem({ issued: true, received: true })],
        hasPermission: allPermissions,
      }),
    ).toEqual({
      isReviseMode: false,
      canShowIssue: false,
      canShowPrepare: false,
      canShowReceive: false,
      canEditSupplierNote: false,
      receiveOnlyMode: false,
      showStockColumn: false,
    })
  })

  it('validates and builds a prepare command with current notes', () => {
    const item = makeItem()

    expect(buildPrepareCommand([item], {}, {})).toEqual({
      ok: false,
      error: 'Chưa nhập số lượng chuẩn bị',
    })
    expect(
      buildPrepareCommand([item], { [itemKey('PO-1')]: 4 }, { [itemKey('PO-1')]: 'Đủ hàng' }),
    ).toEqual({
      ok: true,
      body: {
        items: [
          {
            article: 'Fabric',
            color: 'Red',
            size: 'S',
            poId: 'PO-1',
            qty: 4,
            note: 'Đủ hàng',
          },
        ],
      },
      preparedKeys: new Set([itemKey('PO-1')]),
    })

    const issuedItem = makeItem({ issued: true })
    expect(buildPrepareCommand([issuedItem], { [itemKey('PO-1')]: 4 }, {})).toEqual({
      ok: false,
      error: 'Chưa nhập số lượng chuẩn bị',
    })
  })

  it('validates and builds issue and receive commands from selected rows', () => {
    const item = makeItem({ supplierNote: 'Từ kho' })

    expect(buildIssueCommand([], [item], {})).toEqual({
      ok: false,
      error: 'Chưa chọn mặt hàng để xuất',
    })
    expect(buildIssueCommand([item], [item], {})).toEqual({
      ok: true,
      body: {
        items: [
          {
            article: 'Fabric',
            color: 'Red',
            size: 'S',
            poId: 'PO-1',
            qty: 0,
            note: 'Từ kho',
          },
        ],
      },
    })
    expect(buildReceiveCommand([item], [item])).toEqual({
      ok: true,
      body: {
        items: [
          {
            article: 'Fabric',
            color: 'Red',
            size: 'S',
            poId: 'PO-1',
            qty: 0,
          },
        ],
      },
    })
  })

  it('builds revision items from quantity and creator-note drafts', () => {
    const item = makeItem()

    expect(
      buildReviseCommand(
        [item],
        { [itemKey('PO-1')]: 12 },
        { [itemKey('PO-1')]: 'Điều chỉnh nhu cầu' },
      ),
    ).toEqual({
      items: [
        {
          article: 'Fabric',
          color: 'Red',
          size: 'S',
          purchaseOrderId: 'PO-1',
          type: 'MATERIAL',
          requiredQty: 12,
          supplierUnitId: 'warehouse-1',
          creatorNote: 'Điều chỉnh nhu cầu',
        },
      ],
    })
  })

  it('auto-selects eligible issue and receive rows without duplicates', () => {
    const prepared = makeItem({ actualIssuedQty: 0 })
    const issued = makeItem({
      purchaseOrderId: 'PO-2',
      actualIssuedQty: 5,
      issued: true,
      received: false,
    })

    expect(
      autoSelectIssueableItems([prepared, issued], [prepared], new Set([itemKey('PO-1')])),
    ).toEqual([prepared])
    expect(
      autoSelectIssueableMap(
        [
          makeItem({ purchaseOrderId: 'PO-1', actualIssuedQty: 5, supplierId: 'warehouse-1' }),
          makeItem({ purchaseOrderId: 'PO-2', actualIssuedQty: 0, supplierId: 'warehouse-1' }),
          makeItem({
            purchaseOrderId: 'PO-3',
            actualIssuedQty: 3,
            supplierId: 'warehouse-2',
            issued: true,
          }),
        ],
        {},
        (perm, targetId) => perm === 'ISSUE_MATERIAL' && targetId === 'warehouse-1',
      ),
    ).toEqual({
      'warehouse-1': [
        makeItem({ purchaseOrderId: 'PO-1', actualIssuedQty: 5, supplierId: 'warehouse-1' }),
      ],
    })
    expect(autoSelectReceivableItems([issued], { 'warehouse-1': [issued] }, true)).toEqual({
      'warehouse-1': [issued],
    })
    expect(autoSelectReceivableItems([issued], {}, false)).toEqual({})
  })

  it('clamps stock edits', () => {
    expect(clampPrepareQuantity(makeItem({ stockQty: 10, actualIssuedQty: 4 }), 20)).toEqual({
      value: 6,
      clamped: true,
    })
    expect(clampPrepareQuantity(makeItem(), -2)).toEqual({ value: 0, clamped: false })
  })

  it('fills unissued prepare inputs with the remaining required quantity', () => {
    const issued = makeItem({ purchaseOrderId: 'PO-3', issued: true })

    expect(
      fillAllPrepareInputs(
        [
          makeItem({ purchaseOrderId: 'PO-1', actualIssuedQty: 0 }),
          makeItem({ purchaseOrderId: 'PO-2', actualIssuedQty: 5 }),
          issued,
        ],
        { [itemKey('PO-3')]: 3 },
        (permission, supplierId) =>
          permission === 'PREPARE_MATERIAL' && supplierId === 'warehouse-1',
      ),
    ).toEqual({
      [itemKey('PO-1')]: 10,
      [itemKey('PO-2')]: 5,
      [itemKey('PO-3')]: 3,
    })
  })

  it('warns only when issued plus newly prepared quantity exceeds demand', () => {
    const partiallyIssued = makeItem({ actualIssuedQty: 5, requiredQty: 10 })

    expect(exceedsRequiredQtyAfterPrepare(partiallyIssued, 10)).toBe(true)
    expect(exceedsRequiredQtyAfterPrepare(partiallyIssued, 5)).toBe(false)
    expect(exceedsRequiredQtyAfterPrepare(partiallyIssued, 0)).toBe(false)
  })
})

function itemKey(purchaseOrderId: string) {
  return `Fabric-Red-S-${purchaseOrderId}-warehouse-1`
}

function makeItem(overrides: Partial<FlatKanbanItem> = {}): FlatKanbanItem {
  return {
    article: 'Fabric',
    alternativeName: null,
    color: 'Red',
    size: 'S',
    uom: 'M',
    totalConsumption: 20,
    cumulativeReported: 10,
    creatorNote: 'Nhu cầu gốc',
    supplierNote: 'Từ kho',
    purchaseOrderId: 'PO-1',
    purchaseOrderCode: 'PO-1',
    requiredQty: 10,
    actualIssuedQty: 0,
    stockQty: null,
    issued: false,
    received: false,
    supplierId: 'warehouse-1',
    supplierName: 'Kho 1',
    ...overrides,
  }
}

function makeKanban(): KanbanDetailVm {
  return {
    id: 'kanban-1',
    teamAssignmentId: 'assignment-1',
    teamId: 'team-1',
    teamName: 'Tổ 1',
    styleName: 'STYLE-1',
    styleColorOrder: [],
    styleSizeOrder: [],
    productionOrderCode: 'LSX-1',
    kanbanType: 'STANDARD',
    status: 'APPROVED',
    canCancel: false,
    cancellationBlocked: false,
    plan: [],
    createdAt: '2026-07-26',
    createdById: 'user-1',
    createdByName: 'User',
    items: [
      {
        article: 'Fabric',
        alternativeName: null,
        color: 'Red',
        size: 'S',
        uom: 'M',
        totalConsumption: 20,
        cumulativeReported: 15,
        creatorNote: 'Nhu cầu gốc',
        supplierNote: 'Ghi chú gốc',
        parts: [
          {
            purchaseOrderId: 'PO-1',
            purchaseOrderCode: 'PO-1',
            requiredQty: 10,
            actualIssuedQty: 0,
            stockQty: 20,
            issued: false,
            received: false,
            supplierId: 'warehouse-1',
            supplierName: 'Kho 1',
          },
          {
            purchaseOrderId: 'PO-2',
            purchaseOrderCode: 'PO-2',
            requiredQty: 5,
            actualIssuedQty: 0,
            stockQty: null,
            issued: false,
            received: false,
            supplierId: 'warehouse-2',
            supplierName: 'Kho 2',
          },
        ],
      },
    ],
  }
}
