import type {
  IssueMaterialBody,
  KanbanDetailVm,
  PermissionVm,
  PrepareMaterialBody,
  ReceiveMaterialBody,
  ReviseKanbanCommand,
} from '@/api'
import type { FlatKanbanItem, SupplierAssignment } from '@/features/kanban/types'

export type KanbanNoteMap = Record<string, string>
export type KanbanStatus = KanbanDetailVm['status']
export type HasPermission = (permission: PermissionVm['code'], targetId?: string) => boolean

type CommandResult<T> = { ok: true; body: T } | { ok: false; error: string }
type PrepareCommandResult =
  | { ok: true; body: PrepareMaterialBody; preparedKeys: Set<string> }
  | { ok: false; error: string }

export function kanbanItemKey(
  item: Pick<
    FlatKanbanItem,
    'article' | 'color' | 'size' | 'purchaseOrderId' | 'purchaseOrderType' | 'supplierId'
  >,
): string {
  return `${item.article}-${item.color}-${item.size}-${item.purchaseOrderId}${item.purchaseOrderType ? `-${item.purchaseOrderType}` : ''}-${item.supplierId}`
}

export function resolveKanbanNote(
  noteMap: KanbanNoteMap,
  item: FlatKanbanItem,
  fallback: string,
): string {
  const key = kanbanItemKey(item)
  return Object.prototype.hasOwnProperty.call(noteMap, key) ? noteMap[key] : fallback
}

export function setKanbanNote(noteMap: KanbanNoteMap, item: FlatKanbanItem, value: string) {
  noteMap[kanbanItemKey(item)] = value
}

export function flattenKanbanItems(
  kanban: KanbanDetailVm,
  supplierNotes: KanbanNoteMap = {},
): FlatKanbanItem[] {
  return kanban.items.flatMap((item) =>
    item.parts.map((part) => {
      const row: FlatKanbanItem = {
        purchaseOrderType: part.purchaseOrderType,
        article: item.article,
        articleCode: item.articleCode,
        alternativeName: item.alternativeName,
        color: item.color,
        size: item.size,
        uom: item.uom,
        totalConsumption: item.totalConsumption,
        cumulativeReported: item.cumulativeReported,
        creatorNote: item.creatorNote,
        supplierNote: part.supplierNote ?? item.supplierNote,
        purchaseOrderId: part.purchaseOrderId ?? null,
        purchaseOrderCode: part.purchaseOrderCode ?? null,
        requiredQty: part.requiredQty,
        actualIssuedQty: part.actualIssuedQty,
        stockQty: part.stockQty ?? null,
        issued: part.issued,
        received: part.received,
        supplierId: part.supplierId,
        supplierName: part.supplierName,
      }
      return {
        ...row,
        supplierNote: resolveKanbanNote(supplierNotes, row, row.supplierNote),
      }
    }),
  )
}

export function groupSupplierAssignments(items: FlatKanbanItem[]): SupplierAssignment[] {
  const groups = new Map<string, SupplierAssignment>()
  for (const item of items) {
    const assignment = groups.get(item.supplierId) ?? {
      id: item.supplierId,
      name: item.supplierName,
      items: [],
    }
    assignment.items.push(item)
    groups.set(item.supplierId, assignment)
  }
  return [...groups.values()]
}

export function buildFulfillmentPolicy(params: {
  status: KanbanStatus
  teamId: string
  items: FlatKanbanItem[]
  hasPermission: HasPermission
}) {
  // Chỉ cho phép thao tác cấp phát khi Kanban đã duyệt hoặc đang xuất dở
  const isFulfillmentActive = params.status === 'APPROVED' || params.status === 'PARTIALLY_ISSUED'

  const hasUnissuedItems = params.items.some((item) => !item.issued)
  const hasUnreceivedIssuedItems = params.items.some((item) => item.issued && !item.received)

  // Chuẩn bị & Xuất kho: chỉ hiện khi đã duyệt và còn vật tư chưa xuất
  const canShowPrepare =
    isFulfillmentActive &&
    hasUnissuedItems &&
    params.items.some(
      (item) => !item.issued && params.hasPermission('PREPARE_MATERIAL', item.supplierId),
    )
  const canShowIssue =
    isFulfillmentActive &&
    hasUnissuedItems &&
    params.items.some(
      (item) => !item.issued && params.hasPermission('ISSUE_MATERIAL', item.supplierId),
    )

  // Xác nhận nhận: chỉ hiện khi đã duyệt và có vật tư đã xuất đang chờ nhận
  const canShowReceive =
    isFulfillmentActive &&
    hasUnreceivedIssuedItems &&
    params.hasPermission('CREATE_KANBAN', params.teamId)

  const canEditSupplierNote = isFulfillmentActive && (canShowIssue || canShowPrepare)

  return {
    isReviseMode:
      params.status === 'REJECTED' && params.hasPermission('CREATE_KANBAN', params.teamId),
    canShowIssue,
    canShowPrepare,
    canShowReceive,
    canEditSupplierNote,
    receiveOnlyMode: canShowReceive && !canShowIssue && !canShowPrepare,
    showStockColumn:
      canShowPrepare &&
      params.items.length > 0 &&
      params.items.every((item) => item.article.startsWith('BTP ')),
  }
}

export function buildPrepareCommand(
  items: FlatKanbanItem[],
  prepareInputs: Record<string, number>,
  supplierNotes: KanbanNoteMap,
): PrepareCommandResult {
  const preparedKeys = new Set<string>()
  const preparedItems = items
    .filter((item) => !item.issued && (prepareInputs[kanbanItemKey(item)] || 0) > 0)
    .map((item) => {
      const key = kanbanItemKey(item)
      preparedKeys.add(key)
      return {
        article: item.article,
        color: item.color,
        size: item.size,
        poId: item.purchaseOrderId ?? undefined,
        purchaseOrderType: item.purchaseOrderType ?? undefined,
        qty: prepareInputs[key],
        note: resolveKanbanNote(supplierNotes, item, item.supplierNote),
      }
    })

  if (preparedItems.length === 0) {
    return { ok: false, error: 'Chưa nhập số lượng chuẩn bị' }
  }
  return { ok: true, body: { items: preparedItems }, preparedKeys }
}

export function buildIssueCommand(
  selectedItems: FlatKanbanItem[],
  currentItems: FlatKanbanItem[],
  supplierNotes: KanbanNoteMap,
): CommandResult<IssueMaterialBody> {
  if (selectedItems.length === 0) {
    return { ok: false, error: 'Chưa chọn mặt hàng để xuất' }
  }
  const currentByKey = new Map(currentItems.map((item) => [kanbanItemKey(item), item]))
  return {
    ok: true,
    body: {
      items: selectedItems.map((selected) => {
        const item = currentByKey.get(kanbanItemKey(selected)) ?? selected
        return {
          article: item.article,
          color: item.color,
          size: item.size,
          poId: item.purchaseOrderId ?? undefined,
          purchaseOrderType: item.purchaseOrderType ?? undefined,
          qty: 0,
          note: resolveKanbanNote(supplierNotes, item, item.supplierNote),
        }
      }),
    },
  }
}

export function buildReceiveCommand(
  selectedItems: FlatKanbanItem[],
  currentItems: FlatKanbanItem[],
): CommandResult<ReceiveMaterialBody> {
  if (selectedItems.length === 0) {
    return { ok: false, error: 'Chưa chọn mặt hàng để xác nhận nhận' }
  }
  const currentByKey = new Map(currentItems.map((item) => [kanbanItemKey(item), item]))
  return {
    ok: true,
    body: {
      items: selectedItems.map((selected) => {
        const item = currentByKey.get(kanbanItemKey(selected)) ?? selected
        return {
          article: item.article,
          color: item.color,
          size: item.size,
          poId: item.purchaseOrderId ?? undefined,
          purchaseOrderType: item.purchaseOrderType ?? undefined,
          qty: 0,
        }
      }),
    },
  }
}

export function buildReviseCommand(
  items: FlatKanbanItem[],
  reviseInputs: Record<string, number>,
  creatorNotes: KanbanNoteMap,
): ReviseKanbanCommand {
  return {
    items: items.map((item) => ({
      article: item.article,
      color: item.color,
      size: item.size,
      purchaseOrderId: item.purchaseOrderId ?? undefined,
      purchaseOrderType: item.purchaseOrderType ?? undefined,
      type: item.article.startsWith('BTP ') ? 'SEMI_FINISHED_PRODUCT' : 'MATERIAL',
      requiredQty: reviseInputs[kanbanItemKey(item)] ?? item.requiredQty,
      supplierUnitId: item.supplierId,
      creatorNote: resolveKanbanNote(creatorNotes, item, item.creatorNote),
    })),
  }
}

export function autoSelectIssueableItems(
  assignmentItems: FlatKanbanItem[],
  currentSelection: FlatKanbanItem[],
  preparedKeys: Set<string>,
) {
  const result = [...currentSelection]
  const seen = new Set(result.map(kanbanItemKey))
  for (const item of assignmentItems) {
    const key = kanbanItemKey(item)
    if (item.issued || (item.actualIssuedQty <= 0 && !preparedKeys.has(key)) || seen.has(key)) {
      continue
    }
    result.push(item)
    seen.add(key)
  }
  return result
}

export function autoSelectIssueableMap(
  items: FlatKanbanItem[],
  currentSelection: Record<string, FlatKanbanItem[]>,
  hasPermission: (permission: PermissionVm['code'], targetId?: string) => boolean,
  preparedKeys: Set<string> = new Set(),
): Record<string, FlatKanbanItem[]> {
  const result = Object.fromEntries(
    Object.entries(currentSelection).map(([key, value]) => [key, [...value]]),
  )
  for (const item of items) {
    const key = kanbanItemKey(item)
    if (item.issued) continue
    if (item.actualIssuedQty <= 0 && !preparedKeys.has(key)) continue
    if (!hasPermission('ISSUE_MATERIAL', item.supplierId)) continue

    const selected = result[item.supplierId] ?? []
    if (!selected.some((current) => kanbanItemKey(current) === key)) {
      selected.push(item)
      result[item.supplierId] = selected
    }
  }
  return result
}

export function autoSelectReceivableItems(
  items: FlatKanbanItem[],
  currentSelection: Record<string, FlatKanbanItem[]>,
  canReceive: boolean,
) {
  if (!canReceive) return currentSelection
  const result = Object.fromEntries(
    Object.entries(currentSelection).map(([key, value]) => [key, [...value]]),
  )
  for (const item of items) {
    if (!item.issued || item.received) continue
    const selected = result[item.supplierId] ?? []
    if (!selected.some((current) => kanbanItemKey(current) === kanbanItemKey(item))) {
      selected.push(item)
      result[item.supplierId] = selected
    }
  }
  return result
}

export function clampPrepareQuantity(
  item: FlatKanbanItem,
  input: unknown,
): { value: number; clamped: boolean } {
  let value = Number(input)
  if (Number.isNaN(value) || value < 0) value = 0
  if (item.stockQty === null || item.stockQty === undefined) {
    return { value, clamped: false }
  }
  const max = Math.max(0, Number(item.stockQty) - Number(item.actualIssuedQty ?? 0))
  return value > max ? { value: max, clamped: true } : { value, clamped: false }
}

export function exceedsRequiredQtyAfterPrepare(item: FlatKanbanItem, prepareQty: number): boolean {
  return item.actualIssuedQty + prepareQty > item.requiredQty
}

export function fillAllPrepareInputs(
  items: FlatKanbanItem[],
  prepareInputs: Record<string, number>,
  hasPermission: HasPermission,
): Record<string, number> {
  const updated = { ...prepareInputs }
  for (const item of items) {
    if (item.issued || !hasPermission('PREPARE_MATERIAL', item.supplierId)) continue
    updated[kanbanItemKey(item)] = clampPrepareQuantity(
      item,
      Math.max(0, item.requiredQty - item.actualIssuedQty),
    ).value
  }
  return updated
}
