import { createGlobalState } from '@vueuse/core'
import dayjs from 'dayjs'
import { computed, ref, watch } from 'vue'
import { useAuthStore } from '@/shared/stores/auth'
import { getTreeQuery, getTreeQueryKey } from '@/api/@pinia/colada.gen'
import { useQuery, useQueryState } from '@pinia/colada'
import type { UnitVm } from '@/api'

export type DatePreset = 'today' | 'this_week' | 'this_month' | 'custom'

const FORMAT = 'YYYY-MM-DD'

const useDashboardFilterState = createGlobalState(() => {
  const todayStr = dayjs().format(FORMAT)

  const selectedPreset = ref<DatePreset>('today')
  const from = ref<string>(todayStr)
  const to = ref<string>(todayStr)

  const companyId = ref<string | undefined>(undefined)
  const factoryId = ref<string | undefined>(undefined)
  const teamId = ref<string | undefined>(undefined)
  const warehouseId = ref<string | undefined>(undefined)

  const { currentUser } = useAuthStore()
  // Giữ bộ lọc khi chuyển trang; logout thì reset toàn bộ để login mới bắt đầu lại.
  watch(
    () => currentUser.value?.id,
    (accountId) => {
      if (accountId) return
      setDatePreset('today')
      companyId.value = undefined
      factoryId.value = undefined
      teamId.value = undefined
      warehouseId.value = undefined
    },
    { flush: 'sync' },
  )
  const { data: treeData } = useQueryState<UnitVm[]>(getTreeQueryKey())

  // Flatten org tree to easily lookup unit parents and types
  const unitMap = computed(() => {
    const map = new Map<string, UnitVm>()

    function traverse(units?: UnitVm[]) {
      if (!units) return
      for (const u of units) {
        map.set(u.id, u)
        if (u.children?.length) {
          traverse(u.children)
        }
      }
    }

    const raw = treeData.value
    if (raw) {
      traverse(Array.isArray(raw) ? raw : [raw])
    }
    return map
  })

  function parentIdOf(unitId: string) {
    return [...unitMap.value.entries()].find(([, unit]) =>
      unit.children?.some((child) => child.id === unitId),
    )?.[0]
  }

  // Determine user scope restrictions from memberships
  const userScope = computed(() => {
    if (!currentUser.value?.memberships?.length) {
      return {
        isTeamUser: false,
        isFactoryUser: false,
        isWarehouseUser: false,
        lockedTeamId: undefined,
        lockedFactoryId: undefined,
        lockedWarehouseId: undefined,
        lockedCompanyId: undefined,
      }
    }

    const memberships = currentUser.value.memberships
    const map = unitMap.value

    // Check if user has membership in a Team
    const teamMembership = memberships.find((m) => map.get(m.unitId)?.type === 'TEAM')
    if (teamMembership) {
      let fId: string | undefined
      let cId: string | undefined

      for (const [id, unit] of map.entries()) {
        if (unit.children?.some((c) => c.id === teamMembership.unitId)) {
          fId = id
          for (const [pId, pUnit] of map.entries()) {
            if (pUnit.children?.some((c) => c.id === fId)) {
              cId = pId
              break
            }
          }
          break
        }
      }

      return {
        isTeamUser: true,
        isFactoryUser: false,
        isWarehouseUser: false,
        lockedTeamId: teamMembership.unitId,
        lockedFactoryId: fId,
        lockedWarehouseId: undefined,
        lockedCompanyId: cId,
      }
    }

    // Check if user has membership in a Factory
    const factoryMembership = memberships.find((m) => map.get(m.unitId)?.type === 'FACTORY')
    if (factoryMembership) {
      let cId: string | undefined
      for (const [pId, pUnit] of map.entries()) {
        if (pUnit.children?.some((c) => c.id === factoryMembership.unitId)) {
          cId = pId
          break
        }
      }
      return {
        isTeamUser: false,
        isFactoryUser: true,
        isWarehouseUser: false,
        lockedTeamId: undefined,
        lockedFactoryId: factoryMembership.unitId,
        lockedWarehouseId: undefined,
        lockedCompanyId: cId,
      }
    }

    const warehouseMembership = memberships.find((m) => map.get(m.unitId)?.type === 'WAREHOUSE')
    if (warehouseMembership) {
      let cId: string | undefined
      for (const [id, unit] of map.entries()) {
        if (unit.children?.some((c) => c.id === warehouseMembership.unitId)) {
          cId = id
          break
        }
      }
      return {
        isTeamUser: false,
        isFactoryUser: false,
        isWarehouseUser: true,
        lockedTeamId: undefined,
        lockedFactoryId: undefined,
        lockedWarehouseId: warehouseMembership.unitId,
        lockedCompanyId: cId,
      }
    }

    return {
      isTeamUser: false,
      isFactoryUser: false,
      isWarehouseUser: false,
      lockedTeamId: undefined,
      lockedFactoryId: undefined,
      lockedWarehouseId: undefined,
      lockedCompanyId: undefined,
    }
  })

  // Initialize and apply unit lockings
  watch(
    userScope,
    (scope) => {
      if (scope.isTeamUser) {
        teamId.value = scope.lockedTeamId
        factoryId.value = scope.lockedFactoryId
        companyId.value = scope.lockedCompanyId
      } else if (scope.isFactoryUser) {
        factoryId.value = scope.lockedFactoryId
        companyId.value = scope.lockedCompanyId
      } else if (scope.isWarehouseUser) {
        warehouseId.value = scope.lockedWarehouseId
        companyId.value = scope.lockedCompanyId
        factoryId.value = undefined
        teamId.value = undefined
      }
    },
    { immediate: true },
  )

  function setDatePreset(preset: DatePreset) {
    selectedPreset.value = preset
    const now = dayjs()
    const today = now.format(FORMAT)

    if (preset === 'today') {
      from.value = today
      to.value = today
    } else if (preset === 'this_week') {
      from.value = now.startOf('week').add(1, 'day').format(FORMAT)
      to.value = today
    } else if (preset === 'this_month') {
      from.value = now.startOf('month').format(FORMAT)
      to.value = today
    }
  }

  function setCustomDateRange(newFrom: string, newTo: string) {
    const today = dayjs().format(FORMAT)
    const validatedTo = newTo > today ? today : newTo

    from.value = newFrom > validatedTo ? validatedTo : newFrom
    to.value = validatedTo
    selectedPreset.value = 'custom'
  }

  function setCompany(id?: string) {
    if (
      userScope.value.isTeamUser ||
      userScope.value.isFactoryUser ||
      userScope.value.isWarehouseUser
    )
      return
    companyId.value = id || undefined
    factoryId.value = undefined
    teamId.value = undefined
    warehouseId.value = undefined
  }

  function setFactory(id?: string) {
    if (userScope.value.isTeamUser || userScope.value.isWarehouseUser) return
    factoryId.value = id || undefined
    teamId.value = undefined
    warehouseId.value = undefined
    if (id) {
      const parent = parentIdOf(id)
      if (parent) companyId.value = parent
    }
  }

  function setWarehouse(id?: string) {
    if (userScope.value.isTeamUser || userScope.value.isFactoryUser) return
    warehouseId.value = id || undefined
    factoryId.value = undefined
    teamId.value = undefined
    if (id) {
      const parent = parentIdOf(id)
      if (parent) companyId.value = parent
    }
  }

  function setTeam(id?: string) {
    if (userScope.value.isTeamUser || userScope.value.isWarehouseUser) return
    teamId.value = id || undefined
    warehouseId.value = undefined
    if (id) {
      const parentFactory = parentIdOf(id)
      if (parentFactory) {
        factoryId.value = parentFactory
        const parentCompany = parentIdOf(parentFactory)
        if (parentCompany) companyId.value = parentCompany
      }
    }
  }

  function toggleSelectTeam(targetTeamId: string) {
    if (userScope.value.isTeamUser || userScope.value.isWarehouseUser) return
    if (teamId.value === targetTeamId) {
      teamId.value = undefined
    } else {
      setTeam(targetTeamId)
    }
  }

  function resetFilter() {
    setDatePreset('today')
    if (
      !userScope.value.isTeamUser &&
      !userScope.value.isFactoryUser &&
      !userScope.value.isWarehouseUser
    ) {
      companyId.value = undefined
      factoryId.value = undefined
      teamId.value = undefined
      warehouseId.value = undefined
    } else if (userScope.value.isFactoryUser) {
      teamId.value = undefined
    }
  }

  const isCompanyLocked = computed(
    () =>
      userScope.value.isTeamUser ||
      userScope.value.isFactoryUser ||
      userScope.value.isWarehouseUser,
  )
  const isFactoryLocked = computed(
    () =>
      userScope.value.isTeamUser ||
      userScope.value.isFactoryUser ||
      userScope.value.isWarehouseUser,
  )
  const isTeamLocked = computed(
    () => userScope.value.isTeamUser || userScope.value.isWarehouseUser || !!warehouseId.value,
  )
  const unitQuery = computed(() => ({
    companyId: companyId.value,
    factoryId: factoryId.value,
    teamId: teamId.value,
    warehouseId: warehouseId.value,
  }))
  const dashboardQuery = computed(() => ({
    from: from.value,
    to: to.value,
    ...unitQuery.value,
  }))

  return {
    selectedPreset,
    from,
    to,
    companyId,
    factoryId,
    teamId,
    warehouseId,
    unitMap,
    treeData,
    isCompanyLocked,
    isFactoryLocked,
    isTeamLocked,
    unitQuery,
    dashboardQuery,
    setDatePreset,
    setCustomDateRange,
    setCompany,
    setFactory,
    setWarehouse,
    setTeam,
    toggleSelectTeam,
    resetFilter,
  }
})

export function useDashboardFilter() {
  // Mỗi lần mount đăng ký lại query; state dùng chung chỉ đọc dữ liệu trong cache.
  useQuery(getTreeQuery())
  return useDashboardFilterState()
}
