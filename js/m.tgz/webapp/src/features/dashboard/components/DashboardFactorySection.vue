<script setup lang="ts">
import type { TooltipItem } from 'chart.js'
import { computed } from 'vue'
import { useQuery } from '@pinia/colada'
import { getFactoryProgressQuery, getVisibilityQuery } from '@/api/@pinia/colada.gen'
import AppChart from '@/shared/components/AppChart.vue'
import { fmtQty } from '@/shared/utils/fmtQty'
import { useDashboardFilter } from '../composables/useDashboardFilter'
import type { DashboardFactoryProgressVm } from '@/api'
import type { TableColumn } from '@nuxt/ui'

const { dashboardQuery, unitQuery } = useDashboardFilter()
const { data: visibility } = useQuery(() => getVisibilityQuery({ query: unitQuery.value }))

const canShow = computed(() => !!visibility.value?.factories)

const { data: factories, isLoading } = useQuery(() => ({
  ...getFactoryProgressQuery({
    query: dashboardQuery.value,
  }),
  enabled: canShow.value,
}))

const CHART_COLORS = [
  '#059669',
  '#2563eb',
  '#34d399',
  '#60a5fa',
  '#047857',
  '#1d4ed8',
  '#a7f3d0',
  '#bfdbfe',
]

const totalAllocated = computed(() =>
  (factories.value ?? []).reduce((acc, f) => acc + f.allocatedQty, 0),
)

const columns: TableColumn<DashboardFactoryProgressVm>[] = [
  { accessorKey: 'factoryName', header: 'Xí nghiệp' },
  { accessorKey: 'buyerOrderCount', header: 'Số đơn hàng' },
  { accessorKey: 'purchaseOrderCount', header: 'Số PO' },
  { accessorKey: 'productionOrderCount', header: 'Số LSX' },
  { id: 'inPeriod', header: 'Phát sinh trong kỳ' },
  { id: 'progress', header: 'Lũy kế tiến độ' },
]

// ── Doughnut chart: allocation share ──────────────────────────────────────────
const donutData = computed(() => {
  const items = factories.value ?? []
  return {
    labels: items.map((f) => f.factoryName),
    datasets: [
      {
        data: items.map((f) => f.allocatedQty),
        backgroundColor: CHART_COLORS.slice(0, items.length),
        borderWidth: 1,
      },
    ],
  }
})

const donutOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false,
    },
    tooltip: {
      callbacks: {
        label: (context: TooltipItem<'doughnut'>) => {
          const val = Number(context.raw) || 0
          const total = totalAllocated.value
          const pct = total > 0 ? ((val / total) * 100).toFixed(1) : 0
          return ` ${context.label}: ${fmtQty(val)} (${pct}%)`
        },
      },
    },
  },
}
</script>

<template>
  <div v-if="canShow" class="grid grid-cols-1 gap-4 2xl:grid-cols-[3fr_2fr]">
    <UCard class="flex flex-col">
      <template #header>
        <h2 class="text-base font-semibold text-highlighted sm:text-lg">Tiến độ theo xí nghiệp</h2>
      </template>

      <UTable
        sticky
        :data="factories ?? []"
        :columns="columns"
        :loading="isLoading"
        class="max-h-80"
        :ui="{
          thead: 'sticky top-0 inset-x-0 bg-default z-10 border-b border-default',
          th: 'text-xs sm:text-sm font-semibold text-highlighted py-3 bg-default',
          td: 'text-sm py-3.5',
        }"
      >
        <template #factoryName-cell="{ row }">
          <div class="flex flex-col gap-0.5">
            <div class="text-sm font-semibold text-highlighted">{{ row.original.factoryName }}</div>
            <div class="text-xs text-toned">{{ row.original.companyName }}</div>
          </div>
        </template>
        <template #buyerOrderCount-cell="{ row }">
          <span class="font-mono text-sm font-semibold text-highlighted">{{
            row.original.buyerOrderCount
          }}</span>
        </template>
        <template #purchaseOrderCount-cell="{ row }">
          <span class="font-mono text-sm font-semibold text-highlighted">{{
            row.original.purchaseOrderCount
          }}</span>
        </template>
        <template #productionOrderCount-cell="{ row }">
          <span class="font-mono text-sm font-semibold text-highlighted">{{
            row.original.productionOrderCount
          }}</span>
        </template>
        <template #inPeriod-cell="{ row }">
          <div class="flex items-center gap-1.5 whitespace-nowrap">
            <UBadge color="info" variant="subtle" size="md" class="font-mono">
              <span>Vào:</span>
              <span class="font-bold">{{ fmtQty(row.original.inputInPeriodQty) }}</span>
            </UBadge>
            <UBadge color="success" variant="subtle" size="md" class="font-mono">
              <span>Ra:</span>
              <span class="font-bold">{{ fmtQty(row.original.outputInPeriodQty) }}</span>
            </UBadge>
          </div>
        </template>
        <template #progress-cell="{ row }">
          <div class="flex w-full min-w-[240px] flex-col gap-1.5 sm:min-w-[280px]">
            <div
              class="flex items-center justify-between font-mono text-xs font-semibold sm:text-sm"
            >
              <span>
                <span class="text-emerald-600 dark:text-emerald-400">{{
                  fmtQty(row.original.cumulativeOutputQty)
                }}</span>
                <span class="mx-1 font-normal text-toned">/</span>
                <span class="text-toned">{{ fmtQty(row.original.allocatedQty) }}</span>
              </span>
              <span class="font-bold text-emerald-600 dark:text-emerald-400">
                {{ Number(row.original.progressPercentage.toFixed(1)) }}%
              </span>
            </div>
            <UProgress
              :model-value="Math.min(100, Math.max(0, row.original.progressPercentage))"
              color="success"
              size="lg"
              class="h-3.5 w-full"
            />
          </div>
        </template>
        <template #empty>Không có dữ liệu.</template>
      </UTable>
    </UCard>

    <UCard class="flex flex-col">
      <template #header>
        <h2 class="text-base font-semibold text-highlighted sm:text-lg">
          Phân bổ sản lượng theo xí nghiệp
        </h2>
      </template>

      <div class="min-h-[280px]">
        <div v-if="isLoading" class="flex h-[280px] w-full items-center justify-center">
          <div class="flex items-center gap-2 text-sm font-medium text-toned">
            <UIcon name="i-lucide-loader-2" class="size-5 animate-spin" />
            <span>Đang tải dữ liệu phân bổ...</span>
          </div>
        </div>
        <div
          v-else-if="!factories?.length"
          class="flex h-[280px] w-full items-center justify-center text-sm font-medium text-toned"
        >
          Không có dữ liệu phân bổ
        </div>
        <div v-else class="grid grid-cols-1 items-center gap-4 sm:grid-cols-12">
          <div class="flex h-[260px] items-center justify-center sm:col-span-5">
            <AppChart type="doughnut" :data="donutData" :options="donutOptions" />
          </div>

          <div class="max-h-[280px] divide-y divide-default overflow-y-auto sm:col-span-7">
            <div
              v-for="(f, idx) in factories"
              :key="f.factoryId"
              class="flex items-center gap-2.5 py-3"
            >
              <span
                class="size-2.5 shrink-0 rounded-full"
                :style="{ backgroundColor: CHART_COLORS[idx % CHART_COLORS.length] }"
              />
              <span class="min-w-0 flex-1 truncate text-sm font-medium text-highlighted">{{
                f.factoryName
              }}</span>
              <span class="shrink-0 font-mono text-sm font-semibold">{{
                fmtQty(f.allocatedQty)
              }}</span>
            </div>
          </div>
        </div>
      </div>
    </UCard>
  </div>
</template>
