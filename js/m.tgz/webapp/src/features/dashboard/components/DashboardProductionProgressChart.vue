<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useQuery } from '@pinia/colada'
import { getProductionProgressQuery, getVisibilityQuery } from '@/api/@pinia/colada.gen'
import AppChart from '@/shared/components/AppChart.vue'
import { useDashboardFilter } from '../composables/useDashboardFilter'

const { dashboardQuery, unitQuery } = useDashboardFilter()
const { data: visibility } = useQuery(() => getVisibilityQuery({ query: unitQuery.value }))
const canShow = computed(() => !!visibility.value?.productionProgress)

type ProgressTab = 'LSX' | 'LCD'
const activeTab = ref<ProgressTab>('LCD')

const tabItems = computed(() => [
  ...(visibility.value?.productionOrders ? [{ label: 'Lệnh sản xuất', value: 'LSX' }] : []),
  { label: 'Lệnh công đoạn', value: 'LCD' },
])

// Default tab: if user can see production orders, default to LSX, else LCD
watch(
  () => visibility.value?.productionOrders,
  (canSeeLSX) => {
    if (canSeeLSX) {
      activeTab.value = 'LSX'
    } else {
      activeTab.value = 'LCD'
    }
  },
  { immediate: true },
)

const { data: progressData, isLoading } = useQuery(() => ({
  ...getProductionProgressQuery({
    query: {
      ...dashboardQuery.value,
      tab: activeTab.value,
    },
  }),
  enabled: canShow.value,
}))

const chartData = computed(() => {
  const days = progressData.value?.days ?? []
  return {
    labels: days.map((d) => d.date),
    datasets: [
      {
        label: 'Ra chuyền',
        data: days.map((d) => d.outputQty),
        borderColor: '#2563eb',
        backgroundColor: 'rgba(37, 99, 235, 0.08)',
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointRadius: 3,
        pointHoverRadius: 5,
      },
    ],
  }
})

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom' as const,
      labels: {
        usePointStyle: true,
        boxWidth: 8,
        font: { size: 12, weight: 'bold' as const },
      },
    },
    tooltip: {
      mode: 'index' as const,
      intersect: false,
    },
  },
  scales: {
    y: {
      beginAtZero: true,
      grid: { color: 'rgba(148, 163, 184, 0.18)' },
    },
    x: {
      grid: { display: false },
    },
  },
}
</script>

<template>
  <UCard v-if="canShow">
    <template #header>
      <div class="flex flex-wrap items-center justify-between gap-4">
        <h2 class="text-base font-semibold text-highlighted sm:text-lg">Sản lượng theo ngày</h2>
        <UTabs
          v-model="activeTab"
          :items="tabItems"
          :content="false"
          variant="link"
          :ui="{ trigger: 'text-sm font-medium' }"
        />
      </div>
    </template>

    <!-- Chart container -->
    <div class="h-72 w-full sm:h-80">
      <div v-if="isLoading" class="flex h-full w-full items-center justify-center">
        <div class="flex items-center gap-2 text-sm text-toned">
          <UIcon name="i-lucide-loader-2" class="size-5 animate-spin" />
          <span>Đang tải biểu đồ...</span>
        </div>
      </div>
      <div
        v-else-if="!progressData?.days?.length"
        class="flex h-full w-full items-center justify-center"
      >
        <p class="text-sm text-toned">Không có dữ liệu sản lượng trong khoảng thời gian này</p>
      </div>
      <AppChart v-else type="line" :data="chartData" :options="chartOptions" />
    </div>
  </UCard>
</template>
