<script setup lang="ts">
import { computed } from 'vue'
import dayjs from 'dayjs'
import AppDatePicker from '@/shared/components/AppDatePicker.vue'
import { useDashboardFilter, type DatePreset } from '../composables/useDashboardFilter'
import type { UnitVm } from '@/api'

const {
  selectedPreset,
  from,
  to,
  companyId,
  factoryId,
  teamId,
  warehouseId,
  treeData,
  isCompanyLocked,
  isFactoryLocked,
  isTeamLocked,
  setDatePreset,
  setCustomDateRange,
  setCompany,
  setFactory,
  setWarehouse,
  setTeam,
  resetFilter,
} = useDashboardFilter()

const today = new Date()

const presetItems: { label: string; value: DatePreset }[] = [
  { label: 'Hôm nay', value: 'today' },
  { label: 'Tuần này', value: 'this_week' },
  { label: 'Tháng này', value: 'this_month' },
]

const dateRangeModel = computed<Date[] | undefined>({
  get: () => {
    if (!from.value || !to.value) return undefined
    return [dayjs(from.value).toDate(), dayjs(to.value).toDate()]
  },
  set: (val) => {
    if (Array.isArray(val) && val[0] && val[1]) {
      setCustomDateRange(dayjs(val[0]).format('YYYY-MM-DD'), dayjs(val[1]).format('YYYY-MM-DD'))
    }
  },
})

// Collect all units by type from tree
const allUnits = computed(() => {
  const companies: UnitVm[] = []
  const factories: { unit: UnitVm; companyId?: string }[] = []
  const warehouses: { unit: UnitVm; companyId?: string }[] = []
  const teams: { unit: UnitVm; factoryId?: string; companyId?: string }[] = []

  function traverse(units?: UnitVm[], currentCompanyId?: string, currentFactoryId?: string) {
    if (!units) return
    for (const u of units) {
      if (u.type === 'COMPANY') {
        companies.push(u)
        traverse(u.children, u.id, undefined)
      } else if (u.type === 'FACTORY') {
        factories.push({ unit: u, companyId: currentCompanyId })
        traverse(u.children, currentCompanyId, u.id)
      } else if (u.type === 'WAREHOUSE') {
        warehouses.push({ unit: u, companyId: currentCompanyId })
        traverse(u.children, currentCompanyId, currentFactoryId)
      } else if (u.type === 'TEAM') {
        teams.push({ unit: u, factoryId: currentFactoryId, companyId: currentCompanyId })
        traverse(u.children, currentCompanyId, currentFactoryId)
      } else {
        traverse(u.children, currentCompanyId, currentFactoryId)
      }
    }
  }

  const raw = treeData.value
  if (raw) {
    traverse(Array.isArray(raw) ? raw : [raw])
  }

  return { companies, factories, warehouses, teams }
})

const ALL_VALUE = 'ALL'

const companyItems = computed(() => [
  { label: 'Tất cả công ty', value: ALL_VALUE },
  ...allUnits.value.companies.map((c) => ({ label: c.name, value: c.id })),
])

const factoryItems = computed(() => {
  let factories = allUnits.value.factories
  let warehouses = allUnits.value.warehouses
  if (companyId.value) {
    factories = factories.filter((f) => f.companyId === companyId.value)
    warehouses = warehouses.filter((w) => w.companyId === companyId.value)
  }
  return [
    { label: 'Tất cả xí nghiệp/kho', value: ALL_VALUE },
    ...factories.map((f) => ({ label: f.unit.name, value: f.unit.id })),
    ...warehouses.map((w) => ({ label: w.unit.name, value: w.unit.id })),
  ]
})

const teamItems = computed(() => {
  let list = allUnits.value.teams
  if (factoryId.value) {
    list = list.filter((t) => t.factoryId === factoryId.value)
  } else if (companyId.value) {
    list = list.filter((t) => t.companyId === companyId.value)
  }
  return [
    { label: 'Tất cả các tổ', value: ALL_VALUE },
    ...list.map((t) => ({ label: t.unit.name, value: t.unit.id })),
  ]
})

const selectedCompany = computed({
  get: () => companyId.value || ALL_VALUE,
  set: (val: string) => setCompany(val === ALL_VALUE ? undefined : val),
})

const selectedFactory = computed({
  get: () => factoryId.value || warehouseId.value || ALL_VALUE,
  set: (val: string) => {
    if (val === ALL_VALUE) {
      setFactory(undefined)
    } else if (allUnits.value.warehouses.some((w) => w.unit.id === val)) {
      setWarehouse(val)
    } else {
      setFactory(val)
    }
  },
})

const selectedTeam = computed({
  get: () => teamId.value || ALL_VALUE,
  set: (val: string) => setTeam(val === ALL_VALUE ? undefined : val),
})
</script>

<template>
  <UCard :ui="{ body: 'p-4 sm:p-4.5' }">
    <div class="flex flex-wrap items-center justify-between gap-3.5 sm:gap-4">
      <!-- Date Presets & Picker -->
      <div class="flex flex-wrap items-center gap-3">
        <div class="flex items-center gap-2">
          <UButton
            v-for="item in presetItems"
            :key="item.value"
            :label="item.label"
            color="primary"
            :variant="selectedPreset === item.value ? 'soft' : 'outline'"
            size="md"
            class="px-3 py-1.5 font-medium"
            @click="setDatePreset(item.value)"
          />
        </div>

        <div class="w-72 sm:w-80">
          <AppDatePicker
            v-model="dateRangeModel"
            selection-mode="range"
            :max-date="today"
            placeholder="Chọn khoảng ngày"
            class="w-full text-sm font-medium"
          />
        </div>
      </div>

      <!-- Cascade Org Unit Selects -->
      <div class="flex flex-wrap items-center gap-3">
        <div class="w-52 sm:w-56">
          <USelect
            v-model="selectedCompany"
            :items="companyItems"
            label-key="label"
            value-key="value"
            :disabled="isCompanyLocked"
            :variant="isCompanyLocked ? 'subtle' : 'outline'"
            :color="isCompanyLocked ? 'neutral' : undefined"
            size="md"
            placeholder="Công ty"
            aria-label="Công ty"
            class="w-full font-medium"
          />
        </div>

        <div class="w-52 sm:w-56">
          <USelect
            v-model="selectedFactory"
            :items="factoryItems"
            label-key="label"
            value-key="value"
            :disabled="isFactoryLocked"
            :variant="isFactoryLocked ? 'subtle' : 'outline'"
            :color="isFactoryLocked ? 'neutral' : undefined"
            size="md"
            placeholder="Xí nghiệp/kho"
            aria-label="Xí nghiệp/kho"
            class="w-full font-medium"
          />
        </div>

        <div class="w-52 sm:w-56">
          <USelect
            v-model="selectedTeam"
            :items="teamItems"
            label-key="label"
            value-key="value"
            :disabled="isTeamLocked"
            :variant="isTeamLocked ? 'subtle' : 'outline'"
            :color="isTeamLocked ? 'neutral' : undefined"
            size="md"
            placeholder="Tổ sản xuất"
            aria-label="Tổ sản xuất"
            class="w-full font-medium"
          />
        </div>

        <UButton
          icon="i-lucide-rotate-ccw"
          color="neutral"
          variant="soft"
          size="md"
          title="Đặt lại bộ lọc"
          aria-label="Đặt lại bộ lọc"
          @click="resetFilter"
        />
      </div>
    </div>
  </UCard>
</template>
