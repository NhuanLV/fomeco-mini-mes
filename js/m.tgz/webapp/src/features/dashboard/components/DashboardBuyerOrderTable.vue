<script setup lang="ts">
import { computed } from 'vue'
import { useQuery } from '@pinia/colada'
import { getBuyerOrderProgressQuery, getVisibilityQuery } from '@/api/@pinia/colada.gen'
import type { DashboardBuyerOrderProgressVm } from '@/api'
import type { TableColumn } from '@nuxt/ui'
import { fmtQty } from '@/shared/utils/fmtQty'
import { useDashboardFilter } from '../composables/useDashboardFilter'

const { dashboardQuery, unitQuery } = useDashboardFilter()
const { data: visibility } = useQuery(() => getVisibilityQuery({ query: unitQuery.value }))

const canShow = computed(() => !!visibility.value?.buyerOrders)

const { data: buyerOrders, isLoading } = useQuery(() => ({
  ...getBuyerOrderProgressQuery({
    query: dashboardQuery.value,
  }),
  enabled: canShow.value,
}))

const columns: TableColumn<DashboardBuyerOrderProgressVm>[] = [
  { accessorKey: 'buyerOrderCode', header: 'Đơn hàng' },
  { accessorKey: 'styleName', header: 'Mã hàng' },
  { accessorKey: 'customer', header: 'Khách hàng' },
  { accessorKey: 'purchaseOrderCount', header: 'Số PO' },
  { accessorKey: 'productionOrderCount', header: 'Số LSX' },
  { id: 'inPeriod', header: 'Phát sinh trong kỳ' },
  { id: 'progress', header: 'Lũy kế tiến độ' },
]
</script>

<template>
  <UCard v-if="canShow">
    <template #header>
      <h2 class="text-base font-semibold text-highlighted sm:text-lg">Tiến độ theo đơn hàng</h2>
    </template>

    <UTable
      sticky
      :data="buyerOrders ?? []"
      :columns="columns"
      :loading="isLoading"
      class="max-h-80"
      :ui="{
        thead: 'sticky top-0 inset-x-0 bg-default z-10 border-b border-default',
        th: 'text-xs sm:text-sm font-semibold text-highlighted py-3 bg-default',
        td: 'text-sm py-3.5',
      }"
    >
      <template #buyerOrderCode-cell="{ row }">
        <RouterLink
          :to="`/buyer-orders/${row.original.buyerOrderId}`"
          class="font-mono text-sm font-semibold text-primary hover:underline"
          @click.stop
        >
          {{ row.original.buyerOrderCode }}
        </RouterLink>
      </template>

      <template #styleName-cell="{ row }">
        <span class="text-sm font-medium text-highlighted">
          {{ row.original.styleName || '-' }}
        </span>
      </template>

      <template #customer-cell="{ row }">
        <span class="text-sm text-toned">
          {{ row.original.customer || '-' }}
        </span>
      </template>

      <template #purchaseOrderCount-cell="{ row }">
        <span class="font-mono text-sm font-medium text-highlighted">
          {{ row.original.purchaseOrderCount }}
        </span>
      </template>

      <template #productionOrderCount-cell="{ row }">
        <span class="font-mono text-sm font-medium text-highlighted">
          {{ row.original.productionOrderCount }}
        </span>
      </template>

      <template #inPeriod-cell="{ row }">
        <div class="flex items-center gap-1.5 whitespace-nowrap">
          <UBadge color="info" variant="subtle" size="md" class="font-mono">
            <span>Vào:</span>
            <span class="font-bold">{{ fmtQty(row.original.inputInPeriodQty) }}</span>
          </UBadge>
          <UBadge color="success" variant="subtle" size="md" class="font-mono">
            <span>Ra:</span>
            <span class="font-bold">{{ fmtQty(row.original.outputInPeriodQty) }}</span>
          </UBadge>
        </div>
      </template>

      <template #progress-cell="{ row }">
        <div class="flex w-full min-w-[260px] flex-col gap-1.5 sm:min-w-[320px] md:min-w-[360px]">
          <div class="flex items-center justify-between font-mono text-xs font-semibold sm:text-sm">
            <span>
              <span class="text-emerald-600 dark:text-emerald-400">{{
                fmtQty(row.original.cumulativeOutputQty)
              }}</span>
              <span class="mx-1 font-normal text-toned">/</span>
              <span class="text-toned">{{ fmtQty(row.original.allocatedQty) }}</span>
            </span>
            <span class="font-bold text-emerald-600 dark:text-emerald-400">
              {{ Number(row.original.progressPercentage.toFixed(1)) }}%
            </span>
          </div>
          <UProgress
            :model-value="Math.min(100, Math.max(0, row.original.progressPercentage))"
            color="success"
            size="lg"
            class="h-3.5 w-full"
          />
        </div>
      </template>
      <template #empty>Không có dữ liệu.</template>
    </UTable>
  </UCard>
</template>
