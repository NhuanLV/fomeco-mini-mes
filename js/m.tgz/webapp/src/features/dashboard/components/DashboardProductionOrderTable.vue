<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useQuery } from '@pinia/colada'
import {
  getProductionOrderProgressQuery,
  getTeamAssignmentProgressQuery,
  getVisibilityQuery,
} from '@/api/@pinia/colada.gen'
import type { DashboardProductionOrderProgressVm, DashboardTeamAssignmentProgressVm } from '@/api'
import type { TableColumn } from '@nuxt/ui'
import { fmtQty } from '@/shared/utils/fmtQty'
import {
  getStatusLabel as getProductionOrderStatusLabel,
  getStatusSeverity as getProductionOrderStatusColor,
} from '@/features/production/helpers/productionOrder'
import {
  getTeamAssignmentStatusColor,
  getTeamAssignmentStatusLabel,
} from '@/features/production/team-assignment/helpers/teamAssignmentStatus'
import { useDashboardFilter } from '../composables/useDashboardFilter'

const { dashboardQuery, unitQuery } = useDashboardFilter()
const { data: visibility } = useQuery(() => getVisibilityQuery({ query: unitQuery.value }))

type ActiveTab = 'LSX' | 'LCD'
const activeTab = ref<ActiveTab>('LCD')

watch(
  () => visibility.value?.productionOrders,
  (canSeeLSX) => {
    if (canSeeLSX) {
      activeTab.value = 'LSX'
    } else {
      activeTab.value = 'LCD'
    }
  },
  { immediate: true },
)

const canShowLSX = computed(() => !!visibility.value?.productionOrders)
const canShow = computed(() => canShowLSX.value || !!visibility.value?.teamAssignments)

const tabItems = computed(() => [
  ...(canShowLSX.value ? [{ label: 'Lệnh sản xuất', value: 'LSX' }] : []),
  { label: 'Lệnh công đoạn', value: 'LCD' },
])

// Tab 1: LSX query
const { data: productionOrders, isLoading: loadingLSX } = useQuery(() => ({
  ...getProductionOrderProgressQuery({
    query: dashboardQuery.value,
  }),
  enabled: canShowLSX.value && activeTab.value === 'LSX',
}))

// Tab 2: LCD query
const { data: teamAssignments, isLoading: loadingLCD } = useQuery(() => ({
  ...getTeamAssignmentProgressQuery({
    query: dashboardQuery.value,
  }),
  enabled: canShow.value && activeTab.value === 'LCD',
}))

const lsxColumns: TableColumn<DashboardProductionOrderProgressVm>[] = [
  { accessorKey: 'styleName', header: 'Mã hàng' },
  { accessorKey: 'productionOrderCode', header: 'Lệnh số' },
  { accessorKey: 'buyerOrderCode', header: 'Đơn hàng' },
  { id: 'inPeriod', header: 'Phát sinh trong kỳ' },
  { id: 'progress', header: 'Lũy kế tiến độ' },
  { accessorKey: 'status', header: 'Trạng thái' },
]

const lcdColumns: TableColumn<DashboardTeamAssignmentProgressVm>[] = [
  { accessorKey: 'productionOrderCode', header: 'Lệnh số' },
  { accessorKey: 'teamName', header: 'Tổ' },
  { accessorKey: 'factoryName', header: 'Xí nghiệp' },
  { accessorKey: 'operation', header: 'Công đoạn' },
  { id: 'inPeriod', header: 'Phát sinh trong kỳ' },
  { id: 'progress', header: 'Lũy kế tiến độ' },
  { accessorKey: 'status', header: 'Trạng thái' },
]
</script>

<template>
  <UCard v-if="canShow" class="dashboard-card">
    <!-- Header with Tab Switcher -->
    <template #header>
      <div class="flex flex-wrap items-center justify-between gap-4">
        <h2 class="text-base font-semibold text-highlighted sm:text-lg">Tiến độ theo LCĐ / LSX</h2>
        <UTabs
          v-model="activeTab"
          :items="tabItems"
          :content="false"
          variant="link"
          :ui="{ trigger: 'text-sm font-medium' }"
        />
      </div>
    </template>

    <!-- Tab 1: Tiến độ theo LSX -->
    <UTable
      v-if="activeTab === 'LSX'"
      sticky
      :data="productionOrders ?? []"
      :columns="lsxColumns"
      :loading="loadingLSX"
      class="max-h-80"
      :ui="{
        thead: 'sticky top-0 inset-x-0 bg-default z-10 border-b border-default',
        th: 'text-xs sm:text-sm font-semibold text-highlighted py-3 bg-default',
        td: 'text-sm py-3.5',
      }"
    >
      <template #productionOrderCode-cell="{ row }">
        <RouterLink
          :to="`/production-orders/${row.original.productionOrderId}`"
          class="font-mono text-sm font-semibold text-primary hover:underline"
          @click.stop
        >
          {{ row.original.productionOrderCode }}
        </RouterLink>
      </template>

      <template #buyerOrderCode-cell="{ row }">
        <span class="font-mono text-sm font-medium">{{ row.original.buyerOrderCode }}</span>
      </template>

      <template #styleName-cell="{ row }">
        <span class="text-sm font-medium text-highlighted">{{
          row.original.styleName || '-'
        }}</span>
      </template>

      <template #inPeriod-cell="{ row }">
        <div class="flex items-center gap-1.5 whitespace-nowrap">
          <UBadge color="info" variant="subtle" size="md" class="font-mono">
            <span>Vào:</span>
            <span class="font-bold">{{ fmtQty(row.original.inputInPeriodQty) }}</span>
          </UBadge>
          <UBadge color="success" variant="subtle" size="md" class="font-mono">
            <span>Ra:</span>
            <span class="font-bold">{{ fmtQty(row.original.outputInPeriodQty) }}</span>
          </UBadge>
        </div>
      </template>

      <template #progress-cell="{ row }">
        <div class="flex w-full min-w-65 flex-col gap-1.5 sm:min-w-[320px] md:min-w-90">
          <div class="flex items-center justify-between font-mono text-xs font-semibold sm:text-sm">
            <span>
              <span class="text-emerald-600 dark:text-emerald-400">{{
                fmtQty(row.original.cumulativeOutputQty)
              }}</span>
              <span class="mx-1 font-normal text-toned">/</span>
              <span class="text-toned">{{ fmtQty(row.original.allocatedQty) }}</span>
            </span>
            <span class="font-bold text-emerald-600 dark:text-emerald-400">
              {{ Number(row.original.progressPercentage.toFixed(1)) }}%
            </span>
          </div>
          <UProgress
            :model-value="Math.min(100, Math.max(0, row.original.progressPercentage))"
            color="success"
            size="lg"
            class="h-3.5 w-full"
          />
        </div>
      </template>

      <template #status-cell="{ row }">
        <UBadge
          size="md"
          class="font-medium"
          :color="getProductionOrderStatusColor(row.original.status)"
        >
          {{ getProductionOrderStatusLabel(row.original.status) }}
        </UBadge>
      </template>
      <template #empty>Không có dữ liệu.</template>
    </UTable>

    <!-- Tab 2: Tiến độ theo LCĐ -->
    <UTable
      v-else
      sticky
      :data="teamAssignments ?? []"
      :columns="lcdColumns"
      :loading="loadingLCD"
      class="max-h-80"
      :ui="{
        thead: 'sticky top-0 inset-x-0 bg-default z-10 border-b border-default',
        th: 'text-xs sm:text-sm font-semibold text-highlighted py-3 bg-default',
        td: 'text-sm py-3.5',
      }"
    >
      <template #productionOrderCode-cell="{ row }">
        <RouterLink
          :to="`/team-assignments/${row.original.teamAssignmentId}`"
          class="font-mono text-sm font-semibold text-primary hover:underline"
          @click.stop
        >
          {{ row.original.productionOrderCode }}
        </RouterLink>
      </template>

      <template #teamName-cell="{ row }">
        <span class="text-sm font-semibold text-highlighted">
          {{ row.original.teamName }}
        </span>
      </template>

      <template #factoryName-cell="{ row }">
        <span class="text-sm font-medium text-toned">{{ row.original.factoryName }}</span>
      </template>

      <template #operation-cell="{ row }">
        <span class="text-sm font-medium text-highlighted">
          {{ row.original.operation }}
        </span>
      </template>

      <template #inPeriod-cell="{ row }">
        <div class="flex items-center gap-1.5 whitespace-nowrap">
          <UBadge color="info" variant="subtle" size="md" class="font-mono">
            <span>Vào:</span>
            <span class="font-bold">{{ fmtQty(row.original.inputInPeriodQty) }}</span>
          </UBadge>
          <UBadge color="success" variant="subtle" size="md" class="font-mono">
            <span>Ra:</span>
            <span class="font-bold">{{ fmtQty(row.original.outputInPeriodQty) }}</span>
          </UBadge>
        </div>
      </template>

      <template #progress-cell="{ row }">
        <div class="flex w-full min-w-65 flex-col gap-1.5 sm:min-w-[320px] md:min-w-90">
          <div class="flex items-center justify-between font-mono text-xs font-semibold sm:text-sm">
            <span>
              <span class="text-emerald-600 dark:text-emerald-400">{{
                fmtQty(row.original.cumulativeOutputQty)
              }}</span>
              <span class="mx-1 font-normal text-toned">/</span>
              <span class="text-toned">{{ fmtQty(row.original.allocatedQty) }}</span>
            </span>
            <span class="font-bold text-emerald-600 dark:text-emerald-400">
              {{ Number(row.original.progressPercentage.toFixed(1)) }}%
            </span>
          </div>
          <UProgress
            :model-value="Math.min(100, Math.max(0, row.original.progressPercentage))"
            color="success"
            size="lg"
            class="h-3.5 w-full"
          />
        </div>
      </template>

      <template #status-cell="{ row }">
        <UBadge
          size="md"
          class="font-medium"
          :color="getTeamAssignmentStatusColor(row.original.status)"
        >
          {{ getTeamAssignmentStatusLabel(row.original.status) }}
        </UBadge>
      </template>
      <template #empty>Không có dữ liệu.</template>
    </UTable>
  </UCard>
</template>
