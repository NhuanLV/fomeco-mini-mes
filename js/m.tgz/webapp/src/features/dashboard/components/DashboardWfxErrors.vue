<script setup lang="ts">
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useQuery } from '@pinia/colada'
import { getVisibilityQuery, getWfxErrorsQuery } from '@/api/@pinia/colada.gen'
import type { DashboardWfxErrorVm } from '@/api'
import type { TableColumn } from '@nuxt/ui'
import dayjs from 'dayjs'
import { useDashboardFilter } from '../composables/useDashboardFilter'

const router = useRouter()
const { unitQuery } = useDashboardFilter()
const { data: visibility } = useQuery(() => getVisibilityQuery({ query: unitQuery.value }))

const canShow = computed(() => !!visibility.value?.wfxErrors)

const { data: errors, isLoading } = useQuery(() => ({
  ...getWfxErrorsQuery({ query: unitQuery.value }),
  enabled: canShow.value,
}))

function formatDate(iso?: string) {
  if (!iso) return '-'
  return dayjs(iso).format('HH:mm DD/MM/YYYY')
}

function getDocumentTypeColor(type?: string): 'info' | 'success' | 'neutral' {
  if (type === 'GDN') return 'info'
  if (type === 'GRN') return 'success'
  return 'neutral'
}

const columns: TableColumn<DashboardWfxErrorVm>[] = [
  { accessorKey: 'documentCode', header: 'Mã kanban / LSX' },
  { accessorKey: 'documentType', header: 'Loại' },
  { accessorKey: 'message', header: 'Nội dung lỗi' },
  { accessorKey: 'occurredAt', header: 'Thời gian' },
]

function handleRowClick(error: DashboardWfxErrorVm) {
  if (error.documentType === 'GDN' && error.kanbanId) {
    const target = error.gdnId ? `&targetId=${encodeURIComponent(error.gdnId)}` : ''
    void router.push(`/kanban/${error.kanbanId}?highlight=gdn${target}`)
  } else if (error.documentType === 'GRN' && error.assignmentId) {
    const dateParam = encodeURIComponent(error.occurredAt)
    void router.push(
      `/team-assignments/${error.assignmentId}?tab=output-report&highlightReportDate=${dateParam}`,
    )
  }
}
</script>

<template>
  <UCard v-if="canShow">
    <!-- Header -->
    <template #header>
      <h2 class="text-base font-semibold text-highlighted sm:text-lg">Lỗi đồng bộ WFX</h2>
    </template>

    <!-- Error list table -->
    <div class="max-h-80 overflow-y-auto">
      <UTable
        :data="errors ?? []"
        :columns="columns"
        :loading="isLoading"
        :ui="{
          th: 'text-xs sm:text-sm font-semibold text-highlighted whitespace-nowrap py-3',
          td: 'text-sm py-3.5 align-top',
        }"
        @select="
          (_e: Event, row: { original: DashboardWfxErrorVm }) => handleRowClick(row.original)
        "
      >
        <template #documentCode-cell="{ row }">
          <span class="font-mono text-sm font-semibold text-highlighted">{{
            row.original.documentCode || row.original.documentId || '-'
          }}</span>
        </template>

        <template #documentType-cell="{ row }">
          <UBadge
            v-if="row.original.documentType"
            size="md"
            class="font-medium"
            :label="row.original.documentType"
            :color="getDocumentTypeColor(row.original.documentType)"
          />
          <span v-else>-</span>
        </template>

        <template #message-cell="{ row }">
          <span
            class="block min-w-80 text-sm leading-relaxed break-words whitespace-normal text-error"
          >
            {{ row.original.message || 'Lỗi không xác định từ ERP WFX' }}
          </span>
        </template>

        <template #occurredAt-cell="{ row }">
          <span class="text-sm text-toned">{{ formatDate(row.original.occurredAt) }}</span>
        </template>
        <template #empty>Không có dữ liệu.</template>
      </UTable>
    </div>
  </UCard>
</template>
