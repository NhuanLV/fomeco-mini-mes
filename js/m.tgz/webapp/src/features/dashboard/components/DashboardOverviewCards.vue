<script setup lang="ts">
import { computed } from 'vue'
import { useQuery } from '@pinia/colada'
import { getOverviewQuery, getVisibilityQuery } from '@/api/@pinia/colada.gen'
import { useAuthStore } from '@/shared/stores/auth'
import { fmtQty } from '@/shared/utils/fmtQty'
import { useDashboardFilter } from '../composables/useDashboardFilter'

const { dashboardQuery, unitQuery } = useDashboardFilter()
const { hasPermission } = useAuthStore()

const { data: visibility } = useQuery(() => getVisibilityQuery({ query: unitQuery.value }))

const { data: overview, isLoading } = useQuery(() =>
  getOverviewQuery({
    query: dashboardQuery.value,
  }),
)

const canSeeKanban = computed(
  () =>
    visibility.value?.pendingActions !== false ||
    hasPermission('CREATE_KANBAN') ||
    hasPermission('EVALUATE_KANBAN') ||
    hasPermission('EVALUATE_EXTRA_KANBAN') ||
    hasPermission('PREPARE_MATERIAL') ||
    hasPermission('ISSUE_MATERIAL') ||
    hasPermission('REPORT_PROGRESS'),
)

const canSeeInventory = computed(
  () =>
    visibility.value?.pendingActions !== false ||
    hasPermission('EVALUATE_REQUEST') ||
    hasPermission('RECEIVE_REQUEST'),
)

const canSeeWfxErrors = computed(
  () => visibility.value?.wfxErrors !== false || hasPermission('REPORT_PROGRESS'),
)
</script>

<template>
  <div class="flex flex-wrap gap-3.5 sm:gap-4">
    <UCard
      class="min-h-28 min-w-[150px] flex-1 border-t-2 border-emerald-600 bg-emerald-50/20 sm:min-w-[180px]"
      :ui="{ body: 'p-3.5 sm:p-4 flex flex-col justify-between h-full' }"
    >
      <div class="text-sm font-semibold text-emerald-700 dark:text-emerald-400">
        Đơn hàng đang sản xuất
      </div>
      <USkeleton v-if="isLoading" class="mt-2 h-8 w-16" />
      <div
        v-else
        class="mt-2 font-mono text-2xl font-bold tracking-tight text-highlighted sm:text-3xl"
      >
        {{ overview?.inProgressBuyerOrders ?? 0 }}
      </div>
    </UCard>

    <UCard
      class="min-h-28 min-w-[150px] flex-1 border-t-2 border-emerald-600 bg-emerald-50/20 sm:min-w-[180px]"
      :ui="{ body: 'p-3.5 sm:p-4 flex flex-col justify-between h-full' }"
    >
      <div class="text-sm font-semibold text-emerald-700 dark:text-emerald-400">
        LSX đang sản xuất
      </div>
      <USkeleton v-if="isLoading" class="mt-2 h-8 w-16" />
      <div
        v-else
        class="mt-2 font-mono text-2xl font-bold tracking-tight text-highlighted sm:text-3xl"
      >
        {{ overview?.inProgressProductionOrders ?? 0 }}
      </div>
    </UCard>

    <UCard
      class="min-h-28 min-w-[150px] flex-1 border-t-2 border-blue-600 bg-blue-50/20 sm:min-w-[180px]"
      :ui="{ body: 'p-3.5 sm:p-4 flex flex-col justify-between h-full' }"
    >
      <div class="text-sm font-semibold text-blue-700 dark:text-blue-400">Tiến độ sản xuất</div>
      <USkeleton v-if="isLoading" class="mt-2 h-8 w-24" />
      <div
        v-else
        class="mt-2 truncate font-mono text-lg font-bold tracking-tight text-highlighted sm:text-2xl"
        :title="`${fmtQty(overview?.cumulativeOutputQty ?? 0)} / ${fmtQty(overview?.allocatedQty ?? 0)}`"
      >
        {{ fmtQty(overview?.cumulativeOutputQty ?? 0) }} / {{ fmtQty(overview?.allocatedQty ?? 0) }}
      </div>
    </UCard>

    <UCard
      v-if="canSeeKanban"
      class="min-h-28 min-w-[150px] flex-1 border-t-2 border-amber-500 bg-amber-50/20 sm:min-w-[180px]"
      :ui="{ body: 'p-3.5 sm:p-4 flex flex-col justify-between h-full' }"
    >
      <div class="text-sm font-semibold text-amber-700 dark:text-amber-400">Kanban chờ xử lý</div>
      <USkeleton v-if="isLoading" class="mt-2 h-8 w-16" />
      <div
        v-else
        class="mt-2 font-mono text-2xl font-bold tracking-tight text-highlighted sm:text-3xl"
      >
        {{ overview?.pendingKanbanCount ?? 0 }}
      </div>
    </UCard>

    <UCard
      v-if="canSeeInventory"
      class="min-h-28 min-w-[150px] flex-1 border-t-2 border-amber-500 bg-amber-50/20 sm:min-w-[180px]"
      :ui="{ body: 'p-3.5 sm:p-4 flex flex-col justify-between h-full' }"
    >
      <div class="text-sm font-semibold text-amber-700 dark:text-amber-400">
        Yêu cầu trả lại/điều chuyển chờ xử lý
      </div>
      <USkeleton v-if="isLoading" class="mt-2 h-8 w-16" />
      <div
        v-else
        class="mt-2 font-mono text-2xl font-bold tracking-tight text-highlighted sm:text-3xl"
      >
        {{ overview?.pendingInventoryRequestCount ?? 0 }}
      </div>
    </UCard>

    <UCard
      v-if="canSeeWfxErrors"
      class="min-h-28 min-w-[150px] flex-1 border-t-2 border-red-500 bg-red-50/20 sm:min-w-[180px]"
      :ui="{ body: 'p-3.5 sm:p-4 flex flex-col justify-between h-full' }"
    >
      <div class="text-sm font-semibold text-red-700 dark:text-red-400">Lỗi đồng bộ WFX</div>
      <USkeleton v-if="isLoading" class="mt-2 h-8 w-16" />
      <div
        v-else
        class="mt-2 font-mono text-2xl font-bold tracking-tight text-highlighted sm:text-3xl"
      >
        {{ overview?.wfxErrorCount ?? 0 }}
      </div>
    </UCard>
  </div>
</template>
