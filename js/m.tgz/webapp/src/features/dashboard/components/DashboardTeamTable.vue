<script setup lang="ts">
import { computed } from 'vue'
import { useQuery } from '@pinia/colada'
import { getTeamProgressQuery, getVisibilityQuery } from '@/api/@pinia/colada.gen'
import type { DashboardTeamProgressVm } from '@/api'
import type { TableColumn } from '@nuxt/ui'
import { fmtQty } from '@/shared/utils/fmtQty'
import { useDashboardFilter } from '../composables/useDashboardFilter'

const { dashboardQuery, unitQuery } = useDashboardFilter()
const { data: visibility } = useQuery(() => getVisibilityQuery({ query: unitQuery.value }))

const canShow = computed(() => !!visibility.value?.teams)

const { data: teams, isLoading } = useQuery(() => ({
  ...getTeamProgressQuery({
    query: dashboardQuery.value,
  }),
  enabled: canShow.value,
}))

const columns: TableColumn<DashboardTeamProgressVm>[] = [
  { accessorKey: 'teamName', header: 'Tổ' },
  { accessorKey: 'factoryName', header: 'Xí nghiệp' },
  { accessorKey: 'companyName', header: 'Công ty' },
  { accessorKey: 'operation', header: 'Công đoạn' },
  { id: 'inPeriod', header: 'Phát sinh trong kỳ' },
  { id: 'progress', header: 'Lũy kế tiến độ' },
]
</script>

<template>
  <UCard v-if="canShow">
    <template #header>
      <h2 class="text-base font-semibold text-highlighted sm:text-lg">Tiến độ theo tổ</h2>
    </template>

    <UTable
      sticky
      :data="teams ?? []"
      :columns="columns"
      :loading="isLoading"
      class="max-h-80"
      :ui="{
        thead: 'sticky top-0 inset-x-0 bg-default z-10 border-b border-default',
        th: 'text-xs sm:text-sm font-semibold text-highlighted py-3 bg-default',
        td: 'text-sm py-3.5',
      }"
    >
      <template #teamName-cell="{ row }">
        <div class="flex items-center gap-2">
          <UIcon name="i-lucide-users" class="size-4.5 shrink-0 text-toned" />
          <span class="text-sm font-semibold text-highlighted">
            {{ row.original.teamName }}
          </span>
        </div>
      </template>

      <template #factoryName-cell="{ row }">
        <span class="text-sm font-medium text-toned">{{ row.original.factoryName }}</span>
      </template>

      <template #companyName-cell="{ row }">
        <span class="text-sm font-medium text-toned">{{ row.original.companyName || '-' }}</span>
      </template>

      <template #operation-cell="{ row }">
        <span class="text-sm font-medium text-highlighted">{{ row.original.operation }}</span>
      </template>

      <template #inPeriod-cell="{ row }">
        <div class="flex items-center gap-1.5 whitespace-nowrap">
          <UBadge color="info" variant="subtle" size="md" class="font-mono">
            <span>Vào:</span>
            <span class="font-bold">{{ fmtQty(row.original.inputInPeriodQty) }}</span>
          </UBadge>
          <UBadge color="success" variant="subtle" size="md" class="font-mono">
            <span>Ra:</span>
            <span class="font-bold">{{ fmtQty(row.original.outputInPeriodQty) }}</span>
          </UBadge>
        </div>
      </template>

      <template #progress-cell="{ row }">
        <div class="flex w-full min-w-[260px] flex-col gap-1.5 sm:min-w-[320px] md:min-w-[360px]">
          <div class="flex items-center justify-between font-mono text-xs font-semibold sm:text-sm">
            <span>
              <span class="text-emerald-600 dark:text-emerald-400">{{
                fmtQty(row.original.cumulativeOutputQty)
              }}</span>
              <span class="mx-1 font-normal text-toned">/</span>
              <span class="text-toned">{{ fmtQty(row.original.allocatedQty) }}</span>
            </span>
            <span class="font-bold text-emerald-600 dark:text-emerald-400">
              {{ Number(row.original.progressPercentage.toFixed(1)) }}%
            </span>
          </div>
          <UProgress
            :model-value="Math.min(100, Math.max(0, row.original.progressPercentage))"
            color="success"
            size="lg"
            class="h-3.5 w-full"
          />
        </div>
      </template>
      <template #empty>Không có dữ liệu.</template>
    </UTable>
  </UCard>
</template>
