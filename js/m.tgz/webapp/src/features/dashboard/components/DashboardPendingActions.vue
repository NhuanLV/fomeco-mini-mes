<script setup lang="ts">
import { computed, ref } from 'vue'
import { useQuery } from '@pinia/colada'
import { getPendingActionsQuery, getVisibilityQuery } from '@/api/@pinia/colada.gen'
import type { DashboardPendingInventoryRequestVm, DashboardPendingKanbanVm } from '@/api'
import type { TableColumn } from '@nuxt/ui'
import { fmtQty } from '@/shared/utils/fmtQty'
import {
  getStatusLabel as getKanbanStatusLabel,
  getStatusSeverity as getKanbanStatusColor,
} from '@/features/kanban/helpers/kanban'
import {
  getInventoryRequestStatusLabel,
  getInventoryRequestStatusSeverity,
} from '@/features/inventory/inventory-request/inventoryRequest'
import dayjs from 'dayjs'
import { useDashboardFilter } from '../composables/useDashboardFilter'

const { unitQuery } = useDashboardFilter()
const { data: visibility } = useQuery(() => getVisibilityQuery({ query: unitQuery.value }))

const canShow = computed(() => !!visibility.value?.pendingActions)

const { data: pendingData, isLoading } = useQuery(() => ({
  ...getPendingActionsQuery({ query: unitQuery.value }),
  enabled: canShow.value,
}))

type ActionTab = 'kanban' | 'inventory'
const activeTab = ref<ActionTab>('kanban')

const tabItems = computed(() => [
  {
    label: `Kanban${pendingData.value?.kanbans.length ? ` (${pendingData.value.kanbans.length})` : ''}`,
    value: 'kanban',
  },
  {
    label: `Trả lại / Điều chuyển${pendingData.value?.inventoryRequests.length ? ` (${pendingData.value.inventoryRequests.length})` : ''}`,
    value: 'inventory',
  },
])

function formatDate(iso?: string) {
  if (!iso) return '-'
  return dayjs(iso).format('HH:mm DD/MM/YYYY')
}

function getInventoryRequestTypeLabel(type?: string) {
  if (type === 'TRANSFER') return 'Điều chuyển'
  if (type === 'RETURN') return 'Trả lại'
  return type || '-'
}

function getInventoryRequestTypeColor(type?: string): 'info' | 'success' | 'neutral' {
  if (type === 'TRANSFER') return 'info'
  if (type === 'RETURN') return 'success'
  return 'neutral'
}

const kanbanColumns: TableColumn<DashboardPendingKanbanVm>[] = [
  { accessorKey: 'kanbanCode', header: 'Mã kanban' },
  { accessorKey: 'productionOrderCode', header: 'Lệnh số' },
  { accessorKey: 'teamName', header: 'Tổ yêu cầu' },
  { accessorKey: 'pendingReceiveCount', header: 'Số NPL chờ nhận' },
  { accessorKey: 'requiredQty', header: 'SL yêu cầu' },
  { accessorKey: 'status', header: 'Trạng thái' },
  { accessorKey: 'createdAt', header: 'Ngày tạo' },
]

const inventoryColumns: TableColumn<DashboardPendingInventoryRequestVm>[] = [
  { accessorKey: 'code', header: 'Mã yêu cầu' },
  { accessorKey: 'type', header: 'Loại' },
  { accessorKey: 'sourceTeamName', header: 'Tổ yêu cầu' },
  { accessorKey: 'targetName', header: 'Nơi nhận' },
  { accessorKey: 'status', header: 'Trạng thái' },
  { accessorKey: 'createdAt', header: 'Ngày tạo' },
]
</script>

<template>
  <UCard v-if="canShow">
    <template #header>
      <div class="flex flex-wrap items-center justify-between gap-4">
        <h2 class="text-base font-semibold text-highlighted sm:text-lg">Tác vụ cần xử lý</h2>
        <UTabs
          v-model="activeTab"
          :items="tabItems"
          :content="false"
          variant="link"
          :ui="{ trigger: 'text-sm font-medium' }"
        />
      </div>
    </template>

    <!-- Tab 1: Kanban -->
    <div v-if="activeTab === 'kanban'" class="max-h-80 overflow-y-auto">
      <UTable
        :data="pendingData?.kanbans ?? []"
        :columns="kanbanColumns"
        :loading="isLoading"
        :ui="{
          th: 'text-xs sm:text-sm font-semibold text-highlighted py-3',
          td: 'text-sm py-3.5',
        }"
      >
        <template #kanbanCode-cell="{ row }">
          <RouterLink
            :to="`/kanban/${row.original.id}`"
            class="font-mono text-sm font-semibold text-primary hover:underline"
            @click.stop
          >
            {{ row.original.kanbanCode }}
          </RouterLink>
        </template>

        <template #productionOrderCode-cell="{ row }">
          <span class="font-mono text-sm font-medium">{{ row.original.productionOrderCode }}</span>
        </template>

        <template #teamName-cell="{ row }">
          <div>
            <div class="text-sm font-semibold text-highlighted">{{ row.original.teamName }}</div>
            <div class="text-xs text-toned">{{ row.original.factoryName }}</div>
          </div>
        </template>

        <template #pendingReceiveCount-cell="{ row }">
          <span class="font-mono text-sm font-medium">{{
            row.original.pendingReceiveCount || '-'
          }}</span>
        </template>

        <template #requiredQty-cell="{ row }">
          <span class="font-mono text-sm font-semibold">{{
            fmtQty(row.original.requiredQty)
          }}</span>
        </template>

        <template #status-cell="{ row }">
          <UBadge
            size="md"
            class="font-medium"
            :label="getKanbanStatusLabel(row.original.status)"
            :color="getKanbanStatusColor(row.original.status)"
          />
        </template>

        <template #createdAt-cell="{ row }">
          <span class="text-sm text-toned">{{ formatDate(row.original.createdAt) }}</span>
        </template>
        <template #empty>Không có dữ liệu.</template>
      </UTable>
    </div>

    <!-- Tab 2: Yêu cầu kho -->
    <div v-else class="max-h-80 overflow-y-auto">
      <UTable
        :data="pendingData?.inventoryRequests ?? []"
        :columns="inventoryColumns"
        :loading="isLoading"
        :ui="{
          th: 'text-xs sm:text-sm font-semibold text-highlighted py-3',
          td: 'text-sm py-3.5',
        }"
      >
        <template #code-cell="{ row }">
          <RouterLink
            :to="`/inventory/${row.original.id}`"
            class="font-mono text-sm font-semibold text-primary hover:underline"
            @click.stop
          >
            {{ row.original.code }}
          </RouterLink>
        </template>

        <template #type-cell="{ row }">
          <UBadge
            v-if="row.original.type"
            size="md"
            class="font-medium"
            :label="getInventoryRequestTypeLabel(row.original.type)"
            :color="getInventoryRequestTypeColor(row.original.type)"
          />
          <span v-else>-</span>
        </template>

        <template #sourceTeamName-cell="{ row }">
          <span class="text-sm font-medium text-highlighted">{{
            row.original.sourceTeamName
          }}</span>
        </template>

        <template #targetName-cell="{ row }">
          <span class="text-sm font-medium text-highlighted">{{ row.original.targetName }}</span>
        </template>

        <template #status-cell="{ row }">
          <UBadge
            size="md"
            class="font-medium"
            :label="getInventoryRequestStatusLabel(row.original.status)"
            :color="getInventoryRequestStatusSeverity(row.original.status)"
          />
        </template>

        <template #createdAt-cell="{ row }">
          <span class="text-sm text-toned">{{ formatDate(row.original.createdAt) }}</span>
        </template>
        <template #empty>Không có dữ liệu.</template>
      </UTable>
    </div>
  </UCard>
</template>
