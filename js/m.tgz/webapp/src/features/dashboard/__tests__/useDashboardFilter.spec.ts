import { beforeEach, describe, expect, it } from 'vitest'
import dayjs from 'dayjs'
import { createApp, nextTick } from 'vue'
import { createPinia, setActivePinia } from 'pinia'
import { PiniaColada, useQueryCache } from '@pinia/colada'
import type { AccountVm, UnitVm } from '@/api'
import { useAuthStore } from '@/shared/stores/auth'
import { useDashboardFilter } from '../composables/useDashboardFilter'
import { getTreeQueryKey } from '@/api/@pinia/colada.gen'

describe('useDashboardFilter', () => {
  const app = createApp({})
  const pinia = createPinia()
  app.use(pinia)
  app.use(PiniaColada)

  beforeEach(() => {
    setActivePinia(pinia)
  })

  it('initializes with today as default range', () => {
    const filter = useDashboardFilter()
    const today = dayjs().format('YYYY-MM-DD')

    expect(filter.selectedPreset.value).toBe('today')
    expect(filter.from.value).toBe(today)
    expect(filter.to.value).toBe(today)
  })

  it('updates dates on preset change', () => {
    const filter = useDashboardFilter()
    const today = dayjs().format('YYYY-MM-DD')

    filter.setDatePreset('this_month')
    expect(filter.selectedPreset.value).toBe('this_month')
    expect(filter.to.value).toBe(today)
    expect(filter.from.value).toBe(dayjs().startOf('month').format('YYYY-MM-DD'))

    filter.setDatePreset('today')
    expect(filter.selectedPreset.value).toBe('today')
    expect(filter.from.value).toBe(today)
    expect(filter.to.value).toBe(today)
  })

  it('sets custom date range without exceeding today', () => {
    const filter = useDashboardFilter()
    const today = dayjs().format('YYYY-MM-DD')
    const pastDate = dayjs().subtract(5, 'day').format('YYYY-MM-DD')
    const futureDate = dayjs().add(5, 'day').format('YYYY-MM-DD')

    filter.setCustomDateRange(pastDate, futureDate)
    expect(filter.selectedPreset.value).toBe('custom')
    expect(filter.to.value).toBe(today) // clamped to today
    expect(filter.from.value).toBe(pastDate)
  })

  it('supports toggleSelectTeam for master-detail interaction', () => {
    const filter = useDashboardFilter()
    filter.toggleSelectTeam('team-123')
    expect(filter.teamId.value).toBe('team-123')

    filter.toggleSelectTeam('team-123')
    expect(filter.teamId.value).toBeUndefined()
  })

  it('builds shared dashboard and unit query parameters', () => {
    const filter = useDashboardFilter()
    filter.setCompany('company-1')
    filter.setFactory('factory-1')
    filter.setTeam('team-1')

    expect(filter.unitQuery.value).toEqual({
      companyId: 'company-1',
      factoryId: 'factory-1',
      teamId: 'team-1',
      warehouseId: undefined,
    })
    expect(filter.dashboardQuery.value).toEqual({
      from: filter.from.value,
      to: filter.to.value,
      companyId: 'company-1',
      factoryId: 'factory-1',
      teamId: 'team-1',
      warehouseId: undefined,
    })
  })

  it('selecting a warehouse clears production unit filters', () => {
    const filter = useDashboardFilter()
    filter.setFactory('factory-1')
    filter.setTeam('team-1')

    filter.setWarehouse('warehouse-1')

    expect(filter.factoryId.value).toBeUndefined()
    expect(filter.teamId.value).toBeUndefined()
    expect(filter.warehouseId.value).toBe('warehouse-1')
    expect(filter.isTeamLocked.value).toBe(true)
  })

  it('selecting a warehouse or team also selects its ancestors', () => {
    const filter = useDashboardFilter()
    useQueryCache().setQueryData(getTreeQueryKey(), [
      {
        id: 'company-1',
        name: 'Company',
        code: '',
        type: 'COMPANY',
        operations: [],
        isActive: true,
        children: [
          {
            id: 'factory-1',
            name: 'Factory',
            code: '',
            type: 'FACTORY',
            operations: [],
            isActive: true,
            children: [
              {
                id: 'team-1',
                name: 'Team',
                code: '',
                type: 'TEAM',
                operations: [],
                isActive: true,
                children: [],
              },
            ],
          },
          {
            id: 'warehouse-1',
            name: 'Warehouse',
            code: '',
            type: 'WAREHOUSE',
            operations: [],
            isActive: true,
            children: [],
          },
        ],
      },
    ] satisfies UnitVm[])

    filter.setTeam('team-1')
    expect(filter.companyId.value).toBe('company-1')
    expect(filter.factoryId.value).toBe('factory-1')

    filter.setWarehouse('warehouse-1')
    expect(filter.companyId.value).toBe('company-1')
    expect(filter.factoryId.value).toBeUndefined()
  })

  it('clears the previous account filters and applies the new account scope', async () => {
    const auth = useAuthStore()
    const filter = useDashboardFilter()
    useQueryCache().setQueryData(getTreeQueryKey(), [
      {
        id: 'cutting-team',
        name: 'Cutting',
        code: '',
        type: 'TEAM',
        operations: [],
        isActive: true,
        children: [],
      },
    ] satisfies UnitVm[])
    const cuttingUser = {
      id: 'cutting-user',
      memberships: [{ unitId: 'cutting-team', roles: [] }],
    } as unknown as AccountVm
    auth.currentUser.value = cuttingUser
    await nextTick()
    expect(filter.teamId.value).toBe('cutting-team')

    filter.setCustomDateRange(
      dayjs().subtract(5, 'day').format('YYYY-MM-DD'),
      dayjs().format('YYYY-MM-DD'),
    )
    auth.logout()
    expect(filter.selectedPreset.value).toBe('today')
    expect(filter.from.value).toBe(dayjs().format('YYYY-MM-DD'))
    expect(filter.to.value).toBe(dayjs().format('YYYY-MM-DD'))
    expect(filter.teamId.value).toBeUndefined()
    auth.currentUser.value = { id: 'admin', memberships: [] } as unknown as AccountVm
    await nextTick()
    expect(filter.unitQuery.value).toEqual({
      companyId: undefined,
      factoryId: undefined,
      teamId: undefined,
      warehouseId: undefined,
    })

    filter.setWarehouse('warehouse-1')
    // Refresh cùng account giữ lựa chọn hiện tại.
    auth.currentUser.value = { id: 'admin', memberships: [] } as unknown as AccountVm
    await nextTick()
    expect(filter.warehouseId.value).toBe('warehouse-1')

    auth.logout()
    auth.currentUser.value = cuttingUser
    await nextTick()
    expect(filter.warehouseId.value).toBeUndefined()
    expect(filter.teamId.value).toBe('cutting-team')
    auth.logout()
  })
})
