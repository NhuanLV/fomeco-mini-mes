import { createApp, defineComponent, h, nextTick, ref } from 'vue'
import { flushPromises } from '@vue/test-utils'
import { createPinia } from 'pinia'
import { PiniaColada } from '@pinia/colada'
import { expect, it, vi } from 'vitest'
import { getTree } from '@/api/sdk.gen'
import type { AccountVm, UnitVm } from '@/api'
import { useAuthStore } from '@/shared/stores/auth'
import { installSessionCache } from '@/shared/stores/sessionCache'
import { useDashboardFilter } from '../composables/useDashboardFilter'

vi.mock('@/api/sdk.gen', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@/api/sdk.gen')>()),
  getTree: vi.fn(),
}))

it('reloads the organization tree after switching from admin to a team account', async () => {
  const tree: UnitVm[] = [
    {
      id: 'cutting-team',
      name: 'Cutting',
      code: '',
      type: 'TEAM',
      operations: [],
      isActive: true,
      children: [],
    },
  ]
  const response = {
    data: tree,
    error: undefined,
    request: new Request('http://localhost/api/tree'),
    response: new Response(),
  }
  let resolve!: (value: typeof response) => void
  vi.mocked(getTree)
    .mockResolvedValueOnce(response)
    .mockImplementationOnce(
      () =>
        new Promise<typeof response>((done) => {
          resolve = done
        }),
    )
  const visible = ref(true)
  let filter!: ReturnType<typeof useDashboardFilter>
  const dashboard = defineComponent({
    setup() {
      filter = useDashboardFilter()
      return () => null
    },
  })
  const app = createApp({ setup: () => () => (visible.value ? h(dashboard) : null) })
  app.use(createPinia())
  app.use(PiniaColada)
  const auth = useAuthStore()
  auth.currentUser.value = { id: 'admin', memberships: [] } as unknown as AccountVm
  auth.isAuthenticated.value = true
  const stop = app.runWithContext(() => installSessionCache(() => auth.isAuthenticated.value))
  app.mount(document.createElement('div'))
  try {
    await flushPromises()
    expect(filter.teamId.value).toBeUndefined()

    filter.setCompany('company-1')
    filter.setDatePreset('this_month')
    const selectedFrom = filter.from.value
    visible.value = false
    await nextTick()
    visible.value = true
    await flushPromises()
    expect(filter.companyId.value).toBe('company-1')
    expect(filter.selectedPreset.value).toBe('this_month')
    expect(filter.from.value).toBe(selectedFrom)
    expect(getTree).toHaveBeenCalledTimes(1)

    auth.logout()
    expect(filter.companyId.value).toBeUndefined()
    expect(filter.selectedPreset.value).toBe('today')
    visible.value = false
    await nextTick()
    auth.currentUser.value = {
      id: 'cutting-user',
      memberships: [{ unitId: 'cutting-team', roles: [] }],
    } as unknown as AccountVm
    auth.isAuthenticated.value = true
    await nextTick()
    visible.value = true
    await flushPromises()
    expect(getTree).toHaveBeenCalledTimes(2)

    // Giả lập cây tổ chức trả về chậm sau khi dashboard đã mount lại.
    resolve(response)
    await flushPromises()
    expect(filter.teamId.value).toBe('cutting-team')
    expect(filter.isTeamLocked.value).toBe(true)
  } finally {
    app.unmount()
    stop()
    auth.logout()
  }
})
