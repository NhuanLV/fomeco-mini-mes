<script setup lang="ts">
import { computed } from 'vue'
import type { PermissionVm } from '@/api'

const props = defineProps<{
  modelValue: string[]
  permissions: PermissionVm[]
  disabled?: boolean
}>()

const emit = defineEmits<{
  'update:modelValue': [value: string[]]
}>()

const selectedCodes = computed({
  get: () => props.modelValue,
  set: (value: string[]) => emit('update:modelValue', [...new Set(value)]),
})

const isAllSelected = computed(
  () =>
    props.permissions.length > 0 &&
    props.permissions.every((p) => props.modelValue.includes(p.code)),
)

const isPartialSelected = computed(() => {
  const count = props.modelValue.length
  return count > 0 && count < props.permissions.length
})

const permissionGroups = computed(() => {
  const groups = new Map<
    PermissionVm['groupCode'],
    {
      code: PermissionVm['groupCode']
      displayName: string
      permissions: PermissionVm[]
    }
  >()

  for (const permission of props.permissions) {
    const group = groups.get(permission.groupCode)
    if (group) group.permissions.push(permission)
    else {
      groups.set(permission.groupCode, {
        code: permission.groupCode,
        displayName: permission.groupDisplayName,
        permissions: [permission],
      })
    }
  }

  return [...groups.values()].map((group) => ({
    ...group,
    selectedCount: group.permissions.filter((permission) =>
      props.modelValue.includes(permission.code),
    ).length,
  }))
})

const toggleAll = (checked: boolean | 'indeterminate') => {
  if (checked === 'indeterminate') return
  emit('update:modelValue', checked ? props.permissions.map((p) => p.code) : [])
}

const isSelected = (code: string) => props.modelValue.includes(code)

const togglePermission = (code: string, checked: boolean | 'indeterminate') => {
  if (checked === 'indeterminate') return

  if (checked) {
    selectedCodes.value = [...selectedCodes.value, code]
    return
  }

  selectedCodes.value = selectedCodes.value.filter((item) => item !== code)
}
</script>

<template>
  <div class="flex flex-col gap-2">
    <!-- Header with select all and counter -->
    <div class="flex flex-wrap items-center justify-between gap-2">
      <div class="flex items-center gap-4">
        <span class="text-sm font-medium">Quyền hạn</span>
        <UCheckbox
          label="Chọn tất cả"
          :model-value="isPartialSelected ? 'indeterminate' : isAllSelected"
          :disabled="disabled"
          @update:model-value="toggleAll"
        />
      </div>
      <span class="rounded-full bg-primary-50 px-2 py-0.5 text-xs font-medium text-primary-600">
        {{ modelValue.length }} / {{ permissions.length }}
      </span>
    </div>

    <!-- Permission List -->
    <div class="min-h-0 flex-1 overflow-y-auto p-2">
      <section
        v-for="group in permissionGroups"
        :key="group.code"
        :aria-labelledby="`permission-group-${group.code}`"
        class="py-2 first:pt-0 last:pb-0"
      >
        <div class="mb-1 flex items-center gap-2 px-2">
          <h3 :id="`permission-group-${group.code}`" class="text-sm font-semibold">
            {{ group.displayName }}
          </h3>
          <span class="rounded-full bg-surface-100 px-2 py-0.5 text-xs text-toned">
            {{ group.selectedCount }} / {{ group.permissions.length }}
          </span>
        </div>

        <div class="grid grid-cols-1 gap-1 md:grid-cols-2">
          <UCheckbox
            v-for="perm in group.permissions"
            :key="perm.code"
            variant="card"
            class="w-full cursor-pointer border-0 hover:bg-surface-50 has-data-[state=checked]:bg-primary-50"
            :label="perm.displayName"
            :description="perm.description"
            :model-value="isSelected(perm.code)"
            :disabled="disabled"
            @update:model-value="togglePermission(perm.code, $event)"
          />
        </div>
      </section>
    </div>
  </div>
</template>
