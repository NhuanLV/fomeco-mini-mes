import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import RolePermissionSelector from '../RolePermissionSelector.vue'

describe('RolePermissionSelector', () => {
  it('keeps rendering after selecting a permission', async () => {
    const wrapper = mount(RolePermissionSelector, {
      props: {
        modelValue: [],
        permissions: [
          {
            code: 'MANAGE_ACCOUNT',
            displayName: 'Quản lý tài khoản',
            description: 'Tạo, sửa, xóa tài khoản và vai trò',
            groupCode: 'ADMIN',
            groupDisplayName: 'Quản trị hệ thống',
          },
        ],
      },
      global: {
        stubs: {
          Checkbox: {
            props: ['modelValue', 'label'],
            emits: ['update:modelValue'],
            template:
              '<label><input type="checkbox" :checked="modelValue" @change="$emit(\'update:modelValue\', true)">{{ label }}</label>',
          },
        },
      },
    })

    await wrapper.findAll('input')[1]!.trigger('change')
    const selected = wrapper.emitted('update:modelValue')![0]![0] as string[]
    await wrapper.setProps({ modelValue: selected })

    expect(wrapper.text()).toContain('Quản lý tài khoản')
    expect(selected).toEqual(['MANAGE_ACCOUNT'])
  })

  it('renders permissions in groups provided by the API', () => {
    const wrapper = mount(RolePermissionSelector, {
      props: {
        modelValue: ['MANAGE_ACCOUNT'],
        permissions: [
          {
            code: 'MANAGE_ACCOUNT',
            displayName: 'Quản lý tài khoản',
            description: 'Tạo, sửa, xóa tài khoản và vai trò',
            groupCode: 'ADMIN',
            groupDisplayName: 'Quản trị hệ thống',
          },
          {
            code: 'REPORT_PROGRESS',
            displayName: 'Báo cáo tiến độ',
            description: 'Tổ trưởng nhập sản lượng hoàn thành theo màu/size',
            groupCode: 'PROGRESS_REPORTING',
            groupDisplayName: 'Tiến độ & báo cáo',
          },
        ],
      },
    })

    const groups = wrapper.findAll('section')
    const checkboxes = wrapper.findAllComponents({ name: 'Checkbox' })

    expect(groups).toHaveLength(2)
    expect(checkboxes[0]!.props('modelValue')).toBe('indeterminate')
    expect(checkboxes[1]!.props('variant')).toBe('card')
    expect(checkboxes[1]!.props('label')).toBe('Quản lý tài khoản')
    expect(groups[0]!.text()).toContain('Quản trị hệ thống')
    expect(groups[0]!.text()).toContain('Quản lý tài khoản')
    expect(groups[0]!.text()).toContain('1 / 1')
    expect(groups[1]!.text()).toContain('Tiến độ & báo cáo')
    expect(groups[1]!.text()).toContain('Báo cáo tiến độ')
    expect(groups[1]!.text()).toContain('0 / 1')
  })
})
