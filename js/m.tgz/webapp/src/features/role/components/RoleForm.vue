<script setup lang="ts">
import type { PermissionVm, RoleVm } from '@/api'
import {
  createRoleMutation,
  getPermissionsQuery,
  updateRoleMutation,
} from '@/api/@pinia/colada.gen'
import RolePermissionSelector from '@/features/role/components/RolePermissionSelector.vue'
import { showError, showSuccess } from '@/shared/utils/toast'
import { useMutation, useQuery } from '@pinia/colada'
import type { FormSubmitEvent } from '@nuxt/ui'
import { computed, reactive, ref, watch } from 'vue'
import * as z from 'zod'

const props = defineProps<{
  visible: boolean
  role?: RoleVm | null
  viewOnly?: boolean
}>()

const emit = defineEmits<{
  'update:visible': [value: boolean]
  created: []
  updated: []
}>()

const isViewMode = computed(() => props.viewOnly)

const dialogTitle = computed(() => {
  if (isViewMode.value) return 'Chi tiết vai trò'
  if (props.role) return 'Chỉnh sửa vai trò'
  return 'Tạo vai trò mới'
})

// Queries
const { data: permissionsResult } = useQuery(getPermissionsQuery())
const permissions = computed<PermissionVm[]>(() => permissionsResult.value ?? [])

// Validation Schema — only validates name/description; permissions is a local ref
const schema = z.object({
  name: z.string().trim().min(1, 'Vui lòng nhập tên vai trò'),
  description: z.string().trim().default(''),
})
type Schema = z.output<typeof schema>

// formKey forces Form to remount with fresh initialValues when the edited role changes
const formKey = computed(() => `${props.role?.id ?? 'new'}-${props.visible}`)

const initialValues = computed(() => {
  if (props.role) {
    return {
      name: props.role.name,
      description: props.role.description || '',
    }
  }
  return { name: '', description: '' }
})
const state = reactive<Schema>(initialValues.value)
watch(initialValues, (values) => Object.assign(state, values), { immediate: true })

// permissions is managed as a local ref (Checkbox array)
const rolePermissions = ref<string[]>([])

watch(
  () => props.role,
  (role) => {
    rolePermissions.value = role ? role.permissions.map((p) => p.code) : []
  },
  { immediate: true },
)

// Mutations
const { mutateAsync: createMutate, isLoading: isCreating } = useMutation(createRoleMutation())
const { mutateAsync: updateMutate, isLoading: isUpdating } = useMutation(updateRoleMutation())
const loading = computed(() => isCreating.value || isUpdating.value)

// Form ref to trigger submit from Dialog footer
const formRef = ref<{ $el: HTMLFormElement } | null>(null)
const triggerSubmit = () => formRef.value?.$el?.requestSubmit()

const save = async (e: FormSubmitEvent<Schema>) => {
  const values = e.data
  try {
    const payload = {
      name: values.name,
      description: values.description,
      permissions: rolePermissions.value,
    }

    if (props.role) {
      await updateMutate({
        path: { id: props.role.id },
        body: payload,
      })
      showSuccess('Cập nhật vai trò thành công')
      emit('updated')
    } else {
      await createMutate({
        body: payload,
      })
      showSuccess('Tạo vai trò thành công')
      Object.assign(state, { name: '', description: '' })
      rolePermissions.value = []
      emit('created')
    }
    emit('update:visible', false)
  } catch (error: unknown) {
    const message = (error as { message?: string })?.message || 'Không thể lưu vai trò'
    showError(message)
  }
}

const cancel = () => {
  emit('update:visible', false)
}
</script>

<template>
  <UModal
    :open="visible"
    @update:open="emit('update:visible', $event)"
    :title="dialogTitle"
    fullscreen
    :ui="{ body: 'min-h-0 overflow-hidden' }"
  >
    <template #body>
      <UForm
        ref="formRef"
        :key="formKey"
        :schema
        :state
        class="flex h-full min-h-0 flex-col gap-4"
        @submit="save"
      >
        <!-- Warning for view mode -->
        <UAlert
          v-if="isViewMode"
          color="warning"
          class="m-0"
          :ui="{ description: 'font-bold' }"
          description="Đây là vai trò hệ thống, không thể chỉnh sửa hoặc xóa."
        />

        <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <!-- Name -->
          <UFormField label="Tên vai trò" name="name" :required="!isViewMode">
            <UInput
              v-model="state.name"
              class="w-full"
              placeholder="VD: Quản lý sản xuất"
              :disabled="isViewMode"
            />
          </UFormField>

          <!-- Description -->
          <UFormField label="Mô tả" name="description">
            <UTextarea
              v-model="state.description"
              class="w-full"
              placeholder="Mô tả ngắn gọn về vai trò này..."
              :rows="2"
              :disabled="isViewMode"
            />
          </UFormField>
        </div>

        <!-- Permissions -->
        <RolePermissionSelector
          v-model="rolePermissions"
          :permissions
          :disabled="isViewMode"
          class="min-h-0 flex-1"
        />
      </UForm>
    </template>

    <template #footer>
      <div class="flex w-full justify-end gap-2">
        <template v-if="isViewMode">
          <UButton color="neutral" type="button" @click="cancel" icon="i-lucide-x" label="Đóng" />
        </template>
        <template v-else>
          <UButton
            color="neutral"
            variant="ghost"
            type="button"
            @click="cancel"
            icon="i-lucide-x"
            label="Hủy"
          />
          <UButton
            :loading="loading"
            type="button"
            @click="triggerSubmit"
            icon="i-lucide-check"
            label="Lưu"
          />
        </template>
      </div>
    </template>
  </UModal>
</template>
