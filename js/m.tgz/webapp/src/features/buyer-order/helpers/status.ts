import type { BOStatus } from '../types'

export const getStatusSeverity = (status: BOStatus | string) => {
  switch (status) {
    case 'NEW':
      return 'info'
    case 'RELEASED':
      return 'warning'
    case 'PROCESSING':
      return 'neutral'
    case 'COMPLETED':
      return 'success'
    default:
      return undefined
  }
}

export const getStatusLabel = (status: BOStatus | string) => {
  switch (status) {
    case 'NEW':
      return 'Mới'
    case 'RELEASED':
      return 'Đã phát hết lệnh'
    case 'PROCESSING':
      return 'Đang SX'
    case 'COMPLETED':
      return 'Hoàn thành'
    default:
      return status
  }
}
