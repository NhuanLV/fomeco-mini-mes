import type { BuyerOrderListVm } from '@/api'

// Alias for backward compatibility
export type { BuyerOrderListVm as BuyerOrderVm }

export type BOStatus = BuyerOrderListVm['status']
