<script setup lang="ts">
import AppDatePicker from '@/shared/components/AppDatePicker.vue'
import { useTemplateRef } from 'vue'

defineProps<{
  modelValue: Date | Date[] | (Date | null)[] | null | undefined
  placeholder: string
}>()

const emit = defineEmits<{
  'update:modelValue': [value: Date | Date[] | (Date | null)[] | null | undefined]
}>()

const datepicker = useTemplateRef<InstanceType<typeof AppDatePicker>>('datepicker')

const handleUpdate = (value: Date | Date[] | (Date | null)[] | null | undefined) => {
  emit('update:modelValue', value)
}

function showPicker() {
  datepicker.value?.show()
}
</script>

<template>
  <div class="flex w-full cursor-pointer items-center gap-1 px-4 py-3.5" @click="showPicker">
    <span
      class="text-sm font-semibold whitespace-nowrap"
      :class="modelValue ? 'text-primary' : 'text-highlighted'"
    >
      {{ placeholder }}:
    </span>
    <AppDatePicker
      ref="datepicker"
      :model-value="modelValue"
      selection-mode="range"
      input-class="hidden"
      @update:model-value="handleUpdate"
    >
      <template #inputicon>
        <UButton
          icon="i-lucide-calendar"
          variant="ghost"
          class="h-6! w-6! p-0!"
          :class="modelValue ? 'text-primary!' : 'text-toned!'"
        />
      </template>
    </AppDatePicker>
  </div>
</template>
