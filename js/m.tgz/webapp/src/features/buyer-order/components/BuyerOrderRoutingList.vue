<script setup lang="ts">
import type { BomRoutingVm } from '@/api'
defineProps<{
  routings: BomRoutingVm[]
}>()
</script>

<template>
  <UCard class="mb-4">
    <template #title>
      <div class="flex items-center gap-2">
        <UIcon name="i-lucide-workflow" class="text-xl text-primary" />
        <span>Quy trình sản xuất (Routing)</span>
      </div>
    </template>
    <template #default>
      <div
        v-if="routings.length === 0"
        class="flex flex-col items-center justify-center p-6 text-toned"
      >
        <UIcon name="i-lucide-inbox" class="mb-2 text-4xl text-toned" />
        <p>Đơn hàng chưa có dữ liệu quy trình sản xuất.</p>
        <p class="text-sm">Thử đồng bộ lại từ WFX.</p>
      </div>

      <div v-else class="flex flex-col gap-4">
        <div v-for="(routing, index) in routings" :key="index">
          <div class="mb-2 font-semibold text-default">{{ index + 1 }}. {{ routing.title }}</div>
          <div v-if="routing.operations.length === 0" class="text-sm text-toned italic">
            Chưa có công đoạn.
          </div>
          <div v-else class="flex flex-wrap items-center gap-2">
            <template v-for="(op, opIndex) in routing.operations" :key="`${opIndex}-${op}`">
              <UBadge :label="op" color="neutral" />
              <UIcon
                v-if="opIndex < routing.operations.length - 1"
                name="i-lucide-arrow-right"
                class="text-xs text-toned"
              />
            </template>
          </div>
        </div>
      </div>
    </template>
  </UCard>
</template>
