<script setup lang="ts">
import { getStatusLabel, getStatusSeverity } from '@/features/buyer-order/helpers/status'
import { formatDate } from '@/shared/utils/date'
import { fmtQty } from '@/shared/utils/fmtQty'
import { handleRowNavigation, handleTableAuxClick } from '@/shared/utils/navigation'
import type { TablePageEvent, TableSortEvent } from '@/shared/types/table'
import type { TableColumn, TableRow } from '@nuxt/ui'
import { computed, h, ref, resolveComponent } from 'vue'
import { useRouter } from 'vue-router'
import BuyerOrderFilterDate from './BuyerOrderFilterDate.vue'
import BuyerOrderFilterSelect from './BuyerOrderFilterSelect.vue'
import type { BuyerOrderListVm } from '@/api'
import type { SelectOption } from '@/shared/types'

const router = useRouter()

const props = defineProps<{
  orders: BuyerOrderListVm[]
  loading: boolean
  totalRecords: number
  rows: number
  first: number
  wfxIdOptions: SelectOption[]
  customerOptions: SelectOption[]
  brandOptions: SelectOption[]
  seasonOptions: SelectOption[]
  styleOptions: SelectOption[]
  statusOptions: SelectOption[]
}>()

// Filter models
const wfxIdFilter = defineModel<string | null>('wfxIdFilter', { required: true })
const customerFilter = defineModel<string | null>('customerFilter', { required: true })
const brandFilter = defineModel<string | null>('brandFilter', { required: true })
const seasonFilter = defineModel<string | null>('seasonFilter', { required: true })
const styleFilter = defineModel<string | null>('styleFilter', { required: true })
const statusFilter = defineModel<string | null>('statusFilter', { required: true })
const dateFilter = defineModel<Date[] | null>('dateFilter', { required: true })

const emit = defineEmits<{
  filterChange: [field: string, value: string | null]
  pageChange: [event: TablePageEvent]
  sortChange: [event: TableSortEvent]
}>()

const displayOrders = computed(() => (props.loading ? [] : props.orders))
const columns: TableColumn<BuyerOrderListVm>[] = [
  { accessorKey: 'customer', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'brand', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'season', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'styleName', meta: { class: { th: 'p-0!' } } },
  { accessorKey: 'summaryBuyerOrderRef', header: 'Summary BO Ref' },
  { accessorKey: 'wfxId', meta: { class: { th: 'p-0!' } } },
  { id: 'progress', header: 'Tiến độ' },
  { accessorKey: 'earliestDeliveryDate', meta: { class: { th: 'p-0!' } } },
  {
    id: 'orderStatus',
    meta: { class: { th: 'p-0!' } },
    cell: ({ row }) =>
      h(resolveComponent('UBadge'), {
        label: getStatusLabel(row.original.status),
        color: getStatusSeverity(row.original.status),
      }),
  },
]
const page = computed({
  get: () => Math.floor(props.first / props.rows) + 1,
  set: (value: number) => emitPage(value - 1, props.rows),
})
const pageSize = computed({
  get: () => props.rows,
  set: (value: number) => emitPage(0, value),
})
const deliverySortOrder = ref<0 | 1 | -1>(0)

const handleFilter = (field: string, value: string | null) => emit('filterChange', field, value)

function emitPage(pageIndex: number, rows: number) {
  emit('pageChange', {
    first: pageIndex * rows,
    rows,
    page: pageIndex,
    pageCount: Math.ceil(props.totalRecords / rows),
  })
}

function toggleDeliverySort() {
  deliverySortOrder.value = deliverySortOrder.value === 1 ? -1 : 1
  emit('sortChange', {
    first: 0,
    rows: props.rows,
    page: 0,
    pageCount: Math.ceil(props.totalRecords / props.rows),
    sortField: 'earliestDeliveryDate',
    sortOrder: deliverySortOrder.value,
  })
}

function selectOrder(event: Event, row: TableRow<BuyerOrderListVm>) {
  handleRowNavigation(event, router, `/buyer-orders/${row.original.id}`)
}

function handleAuxClick(event: MouseEvent) {
  handleTableAuxClick(event, router, displayOrders.value, (row) => `/buyer-orders/${row.id}`)
}
</script>

<template>
  <div class="flex h-full flex-col">
    <UTable
      :data="displayOrders"
      :columns="columns"
      :loading="loading"
      class="min-h-0 flex-1 text-xs sm:text-sm"
      :ui="{ tr: 'cursor-pointer' }"
      @select="selectOrder"
      @auxclick="handleAuxClick"
    >
      <template #empty>
        <div v-if="loading" class="flex flex-col gap-2 p-2">
          <USkeleton v-for="i in 8" :key="i" height="2.5rem" />
        </div>
        <div v-else class="py-12 text-center text-toned">
          <UIcon name="i-lucide-inbox" class="mx-auto mb-2 text-4xl" />
          <p>Không tìm thấy đơn hàng nào.</p>
        </div>
      </template>

      <template #customer-header>
        <BuyerOrderFilterSelect
          v-model="customerFilter"
          :options="customerOptions"
          placeholder="Khách hàng"
          @change="(val) => handleFilter('customer', val)"
        />
      </template>
      <template #customer-cell="{ row }">
        <span class="font-semibold">{{ row.original.customer }}</span>
      </template>

      <template #brand-header>
        <BuyerOrderFilterSelect
          v-model="brandFilter"
          :options="brandOptions"
          placeholder="Brand"
          @change="(val) => handleFilter('brand', val)"
        />
      </template>
      <template #brand-cell="{ row }">
        <span>{{ row.original.brand }}</span>
      </template>

      <template #season-header>
        <BuyerOrderFilterSelect
          v-model="seasonFilter"
          :options="seasonOptions"
          placeholder="Season"
          @change="(val) => handleFilter('season', val)"
        />
      </template>
      <template #season-cell="{ row }">
        <UBadge :label="row.original.season" color="neutral" />
      </template>

      <template #styleName-header>
        <BuyerOrderFilterSelect
          v-model="styleFilter"
          :options="styleOptions"
          placeholder="Mã hàng"
          @change="(val) => handleFilter('style', val)"
        />
      </template>
      <template #styleName-cell="{ row }">
        <RouterLink
          :to="`/buyer-orders/${row.original.id}`"
          class="font-medium hover:text-primary hover:underline"
          @click.stop
        >
          {{ row.original.styleName }}
        </RouterLink>
      </template>

      <template #summaryBuyerOrderRef-cell="{ row }">
        <span class="font-mono text-default">{{ row.original.summaryBuyerOrderRef || '-' }}</span>
      </template>

      <template #wfxId-header>
        <BuyerOrderFilterSelect
          v-model="wfxIdFilter"
          :options="wfxIdOptions"
          placeholder="Mã BO"
          @change="(val) => handleFilter('wfxId', val)"
        />
      </template>
      <template #wfxId-cell="{ row }">
        <div class="flex items-center gap-2">
          <RouterLink
            :to="`/buyer-orders/${row.original.id}`"
            class="font-mono font-semibold text-default hover:text-primary hover:underline"
            @click.stop
          >
            <code>{{ row.original.wfxId }}</code>
          </RouterLink>
          <UBadge
            v-if="row.original.needsAllocationRevision"
            :title="'WFX đã đổi PO/SKU, cần chỉnh phân bổ LSX'"
            label="Cần chỉnh phân bổ"
            color="warning"
            icon="i-lucide-triangle-alert"
            class="text-[10px]"
          />
        </div>
      </template>

      <template #progress-cell="{ row }">
        <div class="flex w-full max-w-35 flex-col gap-1">
          <div class="flex justify-between text-xs font-bold sm:text-sm">
            <span>
              {{ fmtQty(row.original.completedQuantity) }} /
              {{ fmtQty(row.original.totalQuantity) }}
            </span>
            <span class="text-primary">
              {{
                row.original.totalQuantity > 0
                  ? Math.round((row.original.completedQuantity / row.original.totalQuantity) * 100)
                  : 0
              }}%
            </span>
          </div>
          <UProgress
            :model-value="
              row.original.totalQuantity > 0
                ? (row.original.completedQuantity / row.original.totalQuantity) * 100
                : 0
            "
            class="h-1.5!"
          />
        </div>
      </template>

      <template #earliestDeliveryDate-header>
        <div class="flex w-full items-center">
          <BuyerOrderFilterDate
            v-model="dateFilter"
            placeholder="Ngày giao"
            class="min-w-0 flex-1"
          />
          <UButton
            variant="ghost"
            color="neutral"
            size="xs"
            :icon="
              deliverySortOrder === 1
                ? 'i-lucide-arrow-up'
                : deliverySortOrder === -1
                  ? 'i-lucide-arrow-down'
                  : 'i-lucide-arrow-up-down'
            "
            @click.stop="toggleDeliverySort"
          />
        </div>
      </template>
      <template #earliestDeliveryDate-cell="{ row }">
        <div class="flex flex-col gap-0.5">
          <span class="font-medium text-highlighted">
            {{ formatDate(row.original.earliestDeliveryDate) }}
          </span>

          <span
            v-if="
              row.original.latestDeliveryDate &&
              row.original.earliestDeliveryDate !== row.original.latestDeliveryDate
            "
            class="text-toned italic"
          >
            {{ formatDate(row.original.latestDeliveryDate) }}
          </span>
        </div>
      </template>

      <template #orderStatus-header>
        <BuyerOrderFilterSelect
          v-model="statusFilter"
          :options="statusOptions"
          placeholder="Trạng thái"
          @change="(val) => handleFilter('status', val)"
        />
      </template>
    </UTable>

    <div class="flex items-center justify-center gap-3 border-t border-default px-3 py-3">
      <UPagination v-model:page="page" :total="totalRecords" :items-per-page="rows" />
      <USelect
        v-model="pageSize"
        :items="[2, 5, 10, 20, 50]"
        class="w-20"
        aria-label="Số dòng mỗi trang"
      />
    </div>
  </div>
</template>
