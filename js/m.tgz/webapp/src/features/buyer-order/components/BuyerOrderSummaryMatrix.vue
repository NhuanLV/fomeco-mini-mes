<script setup lang="ts">
import type { PurchaseOrderVm, SkuQuantityVm } from '@/api'
import ColorSizeMatrix from '@/shared/components/ColorSizeMatrix.vue'
import { useColorSizeMatrix } from '@/shared/composables/useColorSizeMatrix'
import { makeOrderComparator } from '@/shared/utils/orderedValues'
import { fmtQty } from '@/shared/utils/fmtQty'
import { computed } from 'vue'

interface Props {
  selectedPOs: PurchaseOrderVm[]
  allSizes: string[]
  styleColorOrder?: string[]
}

const props = withDefaults(defineProps<Props>(), {
  styleColorOrder: () => [],
})

const totalQuantity = computed(() => {
  return props.selectedPOs.reduce((sum, po) => sum + po.totalQuantity, 0)
})

const { matrixRows: summaryMatrix } = useColorSizeMatrix(
  computed(() => props.selectedPOs.flatMap((po) => po.skuQuantities)),
  computed(() => props.allSizes),
  {
    getColor: (item: SkuQuantityVm) => item.color,
    getSize: (item: SkuQuantityVm) => item.size,
    getQuantity: (item: SkuQuantityVm) => item.quantity,
  },
)

const orderedSummaryMatrix = computed(() => {
  const cmpColor = makeOrderComparator(props.styleColorOrder)
  return [...summaryMatrix.value].sort((left, right) => cmpColor(left.color, right.color))
})
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div class="flex items-center gap-2">
          <UIcon name="i-lucide-list-checks" class="size-6 text-primary" />
          <span class="text-base font-semibold sm:text-lg">Bảng Tổng Hợp PO Đang Chọn</span>
        </div>
        <div
          class="w-fit rounded-full bg-primary-50 px-4 py-1.5 text-xs font-bold text-primary sm:text-sm"
        >
          Tổng: {{ fmtQty(totalQuantity) }}
        </div>
      </div>
    </template>

    <template #default>
      <div
        v-if="summaryMatrix.length === 0"
        class="flex flex-col items-center gap-2 py-8 text-toned"
      >
        <UIcon style="font-size: 48px" name="i-lucide-inbox" />
        <span>Chưa chọn PO nào để tổng hợp</span>
      </div>
      <div v-else class="h-fit overflow-hidden">
        <ColorSizeMatrix :rows="orderedSummaryMatrix" :all-sizes="allSizes" />
      </div>
    </template>
  </UCard>
</template>
