<script setup lang="ts">
const searchQuery = defineModel<string>('searchQuery', { required: true })

const emit = defineEmits<{
  search: []
}>()
</script>

<template>
  <div class="flex w-full items-center">
    <UInput
      v-model="searchQuery"
      icon="i-lucide-search"
      placeholder="Tìm nhanh BO/Mã hàng..."
      class="w-full"
      @keyup.enter="emit('search')"
    />
  </div>
</template>
