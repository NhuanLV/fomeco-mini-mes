<script setup lang="ts">
import type { BuyerOrderDetailVm } from '@/api'
import { getStatusLabel, getStatusSeverity } from '@/features/buyer-order/helpers/status'
import dayjs from 'dayjs'

interface Props {
  order: BuyerOrderDetailVm
}

defineProps<Props>()
</script>

<template>
  <UCard>
    <template #title>
      <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div class="flex items-center gap-3">
          <UIcon name="i-lucide-clipboard-list" class="text-3xl text-primary sm:text-4xl" />
          <div>
            <div class="text-xl font-bold text-highlighted sm:text-2xl">{{ order.wfxId }}</div>
            <div class="text-xs font-normal text-toned sm:text-sm">
              Ngày nhận: {{ dayjs(order.receivedDate).format('HH:mm, DD/MM/YYYY') }}
            </div>
          </div>
        </div>
        <div class="flex flex-wrap gap-2 sm:justify-end">
          <UBadge :label="getStatusLabel(order.status)" :color="getStatusSeverity(order.status)" />
          <UBadge
            v-if="order.needsAllocationRevision"
            label="Cần chỉnh phân bổ"
            color="warning"
            icon="i-lucide-triangle-alert"
          />
        </div>
      </div>
    </template>

    <template #default>
      <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <div>
          <div class="mb-1 text-xs font-medium text-toned uppercase sm:text-sm">Summary BO Ref</div>
          <div class="font-mono font-semibold text-highlighted">
            {{ order.summaryBuyerOrderRef || '-' }}
          </div>
        </div>
        <div>
          <div class="mb-1 text-xs font-medium text-toned uppercase sm:text-sm">Khách hàng</div>
          <div class="font-semibold text-highlighted">{{ order.customer }}</div>
        </div>
        <div>
          <div class="mb-1 text-xs font-medium text-toned uppercase sm:text-sm">Brand</div>
          <div class="font-semibold text-highlighted">{{ order.brand }}</div>
        </div>
        <div>
          <div class="mb-1 text-xs font-medium text-toned uppercase sm:text-sm">Mùa</div>
          <div class="font-semibold text-highlighted">{{ order.season }}</div>
        </div>
        <div>
          <div class="mb-1 text-xs font-medium text-toned uppercase sm:text-sm">Mã hàng</div>
          <div class="flex items-center gap-2">
            <span class="font-bold text-primary">{{ order.styleName }}</span>
          </div>
        </div>
      </div>
    </template>
  </UCard>
</template>
