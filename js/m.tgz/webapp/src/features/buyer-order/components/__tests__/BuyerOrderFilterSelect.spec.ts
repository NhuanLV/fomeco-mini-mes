import { shallowMount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import BuyerOrderFilterSelect from '../BuyerOrderFilterSelect.vue'

describe('BuyerOrderFilterSelect', () => {
  it('uses a full-width trigger with a visible trailing icon', () => {
    const wrapper = shallowMount(BuyerOrderFilterSelect, {
      props: {
        modelValue: null,
        options: [],
        placeholder: 'Khách hàng',
      },
    })
    const ui = wrapper.findComponent({ name: 'SelectMenu' }).props('ui')

    expect(ui).toMatchObject({
      base: 'min-w-0! w-full! cursor-pointer px-4! py-3.5! border-0! bg-transparent! shadow-none! ring-0!',
      placeholder: 'text-highlighted! text-sm! font-semibold!',
      trailing: 'ms-2! pe-0!',
      content: 'w-72!',
      viewport: '[scrollbar-width:none] [&::-webkit-scrollbar]:hidden',
    })
  })
})
