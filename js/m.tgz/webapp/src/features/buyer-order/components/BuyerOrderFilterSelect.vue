<script setup lang="ts">
import type { SelectOption } from '@/shared/types'

defineProps<{
  modelValue: string | null
  options: SelectOption[]
  placeholder: string
}>()

const emit = defineEmits<{
  'update:modelValue': [value: string | null]
  change: [value: string | null]
}>()

// Pass-through styling for Select to look like text header
const selectPt = {
  base: 'min-w-0! w-full! cursor-pointer px-4! py-3.5! border-0! bg-transparent! shadow-none! ring-0!',
  value: 'text-highlighted! p-0! pr-1! text-sm! font-semibold!',
  placeholder: 'text-highlighted! text-sm! font-semibold!',
  trailing: 'ms-2! pe-0!',
  content: 'w-72!',
  viewport: '[scrollbar-width:none] [&::-webkit-scrollbar]:hidden',
}

const selectPtActive = {
  base: 'min-w-0! w-full! cursor-pointer px-4! py-3.5! border-0! bg-transparent! shadow-none! ring-0!',
  value: 'text-primary! p-0! pr-1! text-sm! font-semibold!',
  placeholder: 'text-primary! text-sm! font-semibold!',
  trailing: 'ms-2! pe-0!',
  content: 'w-72!',
  viewport: '[scrollbar-width:none] [&::-webkit-scrollbar]:hidden',
}

const handleChange = (value: string | null) => {
  emit('update:modelValue', value)
  emit('change', value)
}
</script>

<template>
  <USelectMenu
    :model-value="modelValue"
    :items="options"
    label-key="label"
    value-key="value"
    :placeholder="placeholder"
    :search-input="{ placeholder: `Tìm ${placeholder.toLowerCase()}...` }"
    clear
    :ui="modelValue ? selectPtActive : selectPt"
    @update:model-value="handleChange"
  />
</template>
