<script setup lang="ts">
import {
  getBomByBuyerOrderIdQuery,
  getBomByBuyerOrderIdQueryKey,
  updateBoMaterialStatesMutation,
} from '@/api/@pinia/colada.gen'
import BomTableBase from '@/shared/components/bom/BomTableBase.vue'
import type { BomLine } from '@/shared/components/bom/types'
import { makeOrderComparator } from '@/shared/utils/orderedValues'
import { useMutation, useQuery, useQueryCache } from '@pinia/colada'
import { computed, ref } from 'vue'
import { useAuthStore } from '@/shared/stores/auth'
import { showError, showSuccess } from '@/shared/utils/toast'
import type { BuyerOrderMaterial } from '@/api'

const props = defineProps<{
  boId: string
  styleSizeOrder?: string[]
  styleColorOrder?: string[]
}>()

const queryCache = useQueryCache()
const bomQueryKey = computed(() => getBomByBuyerOrderIdQueryKey({ path: { id: props.boId } }))

const { data: bomData, isLoading } = useQuery(() =>
  getBomByBuyerOrderIdQuery({ path: { id: props.boId } }),
)

const { hasPermission } = useAuthStore()
const canEdit = computed(() => hasPermission('MANAGE_BUYER_ORDER'))

type MaterialState = { alternativeName: string; isRequired: boolean }

const isEditingMaterialStates = ref(false)
const materialStateChanges = ref<Record<string, MaterialState>>({})
const hasMaterialStateChanges = computed(() => Object.keys(materialStateChanges.value).length > 0)
const { mutateAsync: saveMaterialStates, isLoading: isSavingMaterialStates } = useMutation(
  updateBoMaterialStatesMutation(),
)

// tạo định danh duy nhất cho 1 dòng bom
function getLineKey(material: BuyerOrderMaterial, index: number): string {
  return material.id ?? material.wfxBomLineId ?? `${material.material.name}__${index}`
}

function updateMaterialState(lineId: string, update: Partial<MaterialState>) {
  const original = bomData.value?.materials?.find(
    (material, index) => getLineKey(material, index) === lineId,
  )
  if (!original) return

  const next = {
    ...(materialStateChanges.value[lineId] ?? {
      alternativeName: original.material.alternativeName ?? '',
      isRequired: original.material.isRequired,
    }),
    ...update,
  }
  const changes = { ...materialStateChanges.value }
  if (
    next.alternativeName === (original.material.alternativeName ?? '') &&
    next.isRequired === original.material.isRequired
  ) {
    delete changes[lineId]
  } else {
    changes[lineId] = next
  }
  materialStateChanges.value = changes
}

function handleUpdateAltName(lineId: string, alternativeName: string) {
  updateMaterialState(lineId, { alternativeName })
}

function handleUpdateRequiredState(lineId: string, isRequired: boolean) {
  updateMaterialState(lineId, { isRequired })
}

async function handleSaveMaterialStates() {
  try {
    const updates = Object.entries(materialStateChanges.value).map(([id, state]) => ({
      lineId: id,
      alternativeName: state.alternativeName || null,
      isRequired: state.isRequired,
    }))
    await saveMaterialStates({
      path: { id: props.boId },
      body: { updates },
    })
    await queryCache.invalidateQueries({ key: bomQueryKey.value })
    showSuccess('Đã lưu trạng thái NPL thành công')
    materialStateChanges.value = {}
    isEditingMaterialStates.value = false
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Lỗi khi lưu trạng thái NPL'
    showError(message)
  }
}

function startMaterialStateEdit() {
  isEditingMaterialStates.value = true
}

function cancelMaterialStateEdit() {
  if (
    hasMaterialStateChanges.value &&
    !window.confirm('Bạn có thay đổi chưa lưu. Bạn có chắc muốn hủy chỉnh sửa?')
  ) {
    return
  }
  materialStateChanges.value = {}
  isEditingMaterialStates.value = false
}

function confirmDiscardMaterialStateChanges() {
  return (
    !hasMaterialStateChanges.value ||
    window.confirm('Bạn có thay đổi chưa lưu. Bạn có chắc muốn rời trang?')
  )
}

defineExpose({
  confirmDiscardMaterialStateChanges,
  hasUnsavedMaterialStateChanges: hasMaterialStateChanges,
})

const mappedLines = computed<BomLine[]>(() => {
  const cmpSize = makeOrderComparator(props.styleSizeOrder ?? [])
  return (bomData.value?.materials || []).map((m, index) => {
    const lineId = getLineKey(m, index)
    return {
      id: lineId,
      articleName: m.material.name,
      articleCode: m.material.articleCode,
      alternativeName:
        materialStateChanges.value[lineId]?.alternativeName ?? m.material.alternativeName,
      isRequired: materialStateChanges.value[lineId]?.isRequired ?? m.material.isRequired,
      uom: m.material.uom,
      category: m.material.category,
      sizes: m.sizeDeps
        .map((s) => ({
          productSize: s.productSize,
          materialSize: s.materialSize || '',
          consumption: s.consumption || 0,
        }))
        .sort(
          (left, right) =>
            cmpSize(left.productSize, right.productSize) ||
            left.materialSize.localeCompare(right.materialSize),
        ),
      colors: m.colorDeps.map((c) => ({
        productColor: c.productColor,
        materialColor: c.materialColor || '',
        consumption: c.consumption || 0,
        cuttingConsumption: null,
      })),
      destinationCodes: m.usedForDestinations || [],
      operations: m.usedForOperations.map((op) => op.operation),
    }
  })
})
</script>

<template>
  <BomTableBase
    title="Bảng định mức (BOM)"
    :lines="mappedLines"
    :style-color-order="styleColorOrder"
    :style-size-order="styleSizeOrder"
    :loading="isLoading"
    :can-edit="canEdit"
    :can-edit-material-state="canEdit"
    :editing-material-state="isEditingMaterialStates"
    :has-material-state-changes="hasMaterialStateChanges"
    :saving-material-state="isSavingMaterialStates"
    @update:alt-name="handleUpdateAltName"
    @update:required="handleUpdateRequiredState"
    @start-material-state-edit="startMaterialStateEdit"
    @cancel-material-state-edit="cancelMaterialStateEdit"
    @save-material-state="handleSaveMaterialStates"
  />
</template>
