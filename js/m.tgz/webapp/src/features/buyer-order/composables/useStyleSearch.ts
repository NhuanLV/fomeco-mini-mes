import { computed, type Ref } from 'vue'
import { useInfiniteQuery } from '@pinia/colada'
import { getStyles } from '@/api'

export function useStyleSearch(search: Ref<string>) {
  const { data, isLoading, asyncStatus, error, loadNextPage, hasNextPage } = useInfiniteQuery({
    key: computed(() => ['styles', search.value]),
    initialPageParam: 0,
    query: async ({ pageParam }) => {
      const { data } = await getStyles({
        query: {
          search: search.value || undefined,
          page: pageParam,
          size: 20,
        },
      })
      return data
    },
    getNextPageParam: (lastPage) => {
      if (!lastPage) return null
      const pageInfo = lastPage.page
      if (!pageInfo) return null
      const isLast = (pageInfo.number ?? 0) + 1 >= (pageInfo.totalPages ?? 0)
      return isLast ? null : (pageInfo.number ?? 0) + 1
    },
  })

  const allStyles = computed(() => data.value?.pages.flatMap((p) => p?.content ?? []) ?? [])

  const fetchNextPage = () => {
    if (hasNextPage.value && asyncStatus.value !== 'loading') {
      void loadNextPage()
    }
  }

  const exposedIsLoading = computed(() => isLoading.value && allStyles.value.length === 0)

  return {
    allStyles,
    isLoading: exposedIsLoading,
    isFetchingNextPage: computed(
      () => asyncStatus.value === 'loading' && allStyles.value.length > 0,
    ),
    hasMore: hasNextPage,
    fetchNextPage,
    error,
  }
}
