import { config } from '@vue/test-utils'
import { beforeEach } from 'vitest'

beforeEach(() => {
  // Reset any mocks or document state before each test
})

// Configure Vue Test Utils global settings if needed
config.global.mocks = {
  // Add global mocks here if required
}
