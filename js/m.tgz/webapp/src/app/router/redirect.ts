import { ROUTE_PATH } from './path'

export function getSafeRedirect(value: unknown): string {
  if (typeof value !== 'string' || !value) return ROUTE_PATH.DASHBOARD

  try {
    const origin = window.location.origin
    const target = new URL(value, origin)

    if (target.origin !== origin) return ROUTE_PATH.DASHBOARD

    return `${target.pathname}${target.search}${target.hash}`
  } catch {
    return ROUTE_PATH.DASHBOARD
  }
}
