import type { PermissionVm } from '@/api'
import { ROUTE_PATH } from '@/app/router/path'
import { getSafeRedirect } from '@/app/router/redirect'
import { useAuthStore } from '@/shared/stores/auth'
import { createRouter, createWebHistory } from 'vue-router'
import { handleHotUpdate, routes } from 'vue-router/auto-routes'

type PermissionCode = PermissionVm['code']

declare module 'vue-router' {
  interface RouteMeta {
    requiredPermission?: PermissionCode
    requiredAnyPermission?: PermissionCode[]
  }
}

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

if (import.meta.hot) {
  handleHotUpdate(router)
}

router.beforeEach(async (to) => {
  const { isInitialized, isAuthenticated, hasPermission, checkAuth } = useAuthStore()

  if (!isInitialized.value) {
    await checkAuth()
  }

  if (to.path !== ROUTE_PATH.LOGIN && !isAuthenticated.value) {
    return { path: ROUTE_PATH.LOGIN, query: { redirect: to.fullPath } }
  }

  if (to.path === ROUTE_PATH.LOGIN && isAuthenticated.value) {
    return getSafeRedirect(to.query.redirect)
  }

  const required = to.meta.requiredPermission
  if (required && !hasPermission(required)) {
    return { path: '/forbidden' }
  }

  const requiredAny = to.meta.requiredAnyPermission
  if (requiredAny && !requiredAny.some((p) => hasPermission(p))) {
    return { path: '/forbidden' }
  }
})

export default router
