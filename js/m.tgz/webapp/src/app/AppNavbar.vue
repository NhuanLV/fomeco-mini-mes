<script setup lang="ts">
import type { PermissionVm } from '@/api'
import { ROUTE_PATH } from '@/app/router/path'
import logoUrl from '@/assets/logo.png'
import NotificationMenu from '@/features/notification/components/NotificationMenu.vue'
import { useAuthStore } from '@/shared/stores/auth'
import type { DropdownMenuItem } from '@nuxt/ui'
import { computed } from 'vue'
import { useRouter } from 'vue-router'

interface NavbarItem {
  label: string
  icon: string
  to?: string
  children?: DropdownMenuItem[]
}

const router = useRouter()
const { hasPermission, logout, currentUser } = useAuthStore()

const navItems = computed<NavbarItem[]>(() => {
  const can = (p: PermissionVm['code']) => hasPermission(p)

  const buyerOrderItem = can('MANAGE_BUYER_ORDER') && {
    label: 'Đơn hàng',
    icon: 'i-lucide-clipboard-list',
    to: ROUTE_PATH.BUYER_ORDERS,
  }

  const lenhSanXuatItems = [
    can('VIEW_PRODUCTION_ORDER') && {
      label: 'Danh sách LSX',
      icon: 'i-lucide-clipboard-pen',
      to: ROUTE_PATH.PRODUCTION_ORDERS,
    },
    can('ISSUE_PRODUCTION_ORDER') && {
      label: 'Tạo lệnh sản xuất',
      icon: 'i-lucide-file-plus-2',
      to: ROUTE_PATH.PRODUCTION_ORDER_ISSUE,
    },
  ].filter(Boolean) as DropdownMenuItem[]

  const productionItems = [
    can('REPORT_PROGRESS') && {
      label: 'Danh sách lệnh công đoạn',
      icon: 'i-lucide-workflow',
      to: ROUTE_PATH.TEAM_ASSIGNMENTS,
    },
  ].filter(Boolean) as DropdownMenuItem[]

  const materialItems = [
    (can('CREATE_KANBAN') ||
      can('EVALUATE_KANBAN') ||
      can('EVALUATE_EXTRA_KANBAN') ||
      can('PREPARE_MATERIAL') ||
      can('ISSUE_MATERIAL')) && {
      label: 'Kanban',
      icon: 'i-lucide-columns-3',
      to: ROUTE_PATH.KANBAN,
    },
    (can('CREATE_REQUEST') || can('EVALUATE_REQUEST') || can('RECEIVE_REQUEST')) && {
      label: 'Trả lại / Điều chuyển',
      icon: 'i-lucide-arrow-right-left',
      to: ROUTE_PATH.INVENTORY,
    },
  ].filter(Boolean) as DropdownMenuItem[]

  const adminItems = [
    can('MANAGE_ORG') && {
      label: 'Quản trị tổ chức',
      icon: 'i-lucide-building-2',
      to: ROUTE_PATH.ORGANIZATION,
    },
    can('MANAGE_ACCOUNT') && {
      label: 'Vai trò',
      icon: 'i-lucide-shield',
      to: ROUTE_PATH.ROLES,
    },
    can('MANAGE_ACCOUNT') && {
      label: 'Tài khoản',
      icon: 'i-lucide-id-card',
      to: ROUTE_PATH.ACCOUNTS,
    },
  ].filter(Boolean) as DropdownMenuItem[]

  return [
    adminItems.length > 0 && {
      label: 'Quản trị',
      icon: 'i-lucide-settings-2',
      children: adminItems,
    },
    buyerOrderItem,
    lenhSanXuatItems.length > 0 && {
      label: 'Lệnh sản xuất',
      icon: 'i-lucide-clipboard-pen-line',
      children: lenhSanXuatItems,
    },
    productionItems.length > 0 && {
      label: 'Sản xuất',
      icon: 'i-lucide-factory',
      children: productionItems,
    },
    materialItems.length > 0 && {
      label: 'Vật tư',
      icon: 'i-lucide-boxes',
      children: materialItems,
    },
  ].filter(Boolean) as NavbarItem[]
})

const mobileNavItems = computed(() =>
  navItems.value.map((item) => ({
    ...item,
    children: item.children?.filter((child) => child.type !== 'separator'),
  })),
)

const userMenuItems: DropdownMenuItem[] = [
  { label: 'Hồ sơ', icon: 'i-lucide-user', to: ROUTE_PATH.PROFILE },
  { type: 'separator' },
  {
    label: 'Đăng xuất',
    icon: 'i-lucide-log-out',
    class: 'logout-item',
    onSelect: () => handleLogout(),
  },
]

const handleLogout = async () => {
  try {
    await fetch('/api/logout', { method: 'POST' })
  } catch (e) {
    console.error('Logout failed', e)
  } finally {
    logout()
    await router.push(ROUTE_PATH.LOGIN)
  }
}
</script>

<template>
  <UHeader
    :to="ROUTE_PATH.DASHBOARD"
    title="MES+"
    class="relative z-50 shrink-0 shadow-md"
    :ui="{
      root: 'bg-default',
      container: 'h-16 max-w-none px-2 sm:px-4',
      center: 'hidden lg:flex',
      body: 'p-4',
    }"
  >
    <template #title>
      <div class="flex shrink-0 cursor-pointer items-center gap-2">
        <img :src="logoUrl" alt="MES+" class="h-8 w-auto" />
        <span class="hidden text-lg font-bold text-primary-600 sm:inline">MES+</span>
      </div>
    </template>

    <div class="flex items-center gap-1">
      <template v-for="item in navItems" :key="item.label">
        <UButton
          v-if="item.to"
          :label="item.label"
          :icon="item.icon"
          :to="item.to"
          color="neutral"
          variant="ghost"
          class="text-base"
        />

        <UDropdownMenu
          v-else-if="item.children?.length"
          :items="item.children"
          :ui="{
            content: 'min-w-56',
            viewport: '[scrollbar-width:none] [&::-webkit-scrollbar]:hidden',
            itemWrapper: 'min-w-max',
            itemLabel: 'whitespace-nowrap',
          }"
        >
          <template #default="{ open }">
            <UButton
              :label="item.label"
              :icon="item.icon"
              :trailing-icon="open ? 'i-lucide-chevron-up' : 'i-lucide-chevron-down'"
              color="neutral"
              variant="ghost"
              class="text-base"
              :class="{ 'bg-elevated': open }"
            />
          </template>
        </UDropdownMenu>
      </template>
    </div>

    <template #right>
      <div class="z-10 flex shrink-0 items-center justify-end gap-1 sm:gap-3">
        <NotificationMenu />

        <div class="relative">
          <UDropdownMenu :items="userMenuItems">
            <button
              class="flex items-center gap-2 rounded-full p-1.5 transition-colors hover:bg-elevated"
            >
              <span class="flex items-center gap-2">
                <UAvatar
                  :src="currentUser?.avatar || undefined"
                  :text="currentUser?.name?.split(' ')?.pop()?.charAt(0)?.toUpperCase() || 'U'"
                />
                <span
                  class="hidden flex-col items-start px-1 sm:flex"
                  :title="
                    currentUser?.memberships?.map((m) => m.unitName).join(', ') || 'System Admin'
                  "
                >
                  <span class="text-sm leading-tight font-semibold text-default">{{
                    currentUser?.name?.trim().split(' ').pop() || 'User'
                  }}</span>
                </span>
                <UIcon name="i-lucide-chevron-down" class="size-4 text-toned" />
              </span>
            </button>
          </UDropdownMenu>
        </div>
      </div>
    </template>

    <template #body>
      <UNavigationMenu :items="mobileNavItems" orientation="vertical" class="-mx-2.5" />
    </template>
  </UHeader>
</template>
