import { shallowMount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'
import AppNavbar from '../AppNavbar.vue'

vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({
    currentUser: null,
    hasPermission: () => true,
    logout: vi.fn(),
  }),
}))

vi.mock('vue-router', async (importOriginal) => ({
  ...(await importOriginal<typeof import('vue-router')>()),
  useRouter: () => ({ push: vi.fn() }),
}))

describe('AppNavbar', () => {
  const mountNavbar = () =>
    shallowMount(AppNavbar, {
      global: {
        stubs: {
          Header: {
            name: 'Header',
            props: ['to'],
            template:
              '<header><slot name="title" /><slot /><slot name="right" /><slot name="body" /></header>',
          },
        },
      },
    })

  it('uses the Nuxt UI header with mobile navigation', () => {
    const wrapper = mountNavbar()

    expect(wrapper.findComponent({ name: 'Header' }).exists()).toBe(true)
    expect(wrapper.findComponent({ name: 'NavigationMenu' }).props('orientation')).toBe('vertical')
    expect(wrapper.findComponent({ name: 'NotificationMenu' }).exists()).toBe(true)
  })

  it('renders separate buyer-order link and production-order dropdown', () => {
    const wrapper = mountNavbar()
    expect(wrapper.findComponent({ name: 'Header' }).props('to')).toBe('/')

    const buttons = wrapper.findAllComponents({ name: 'Button' })
    const buyerOrderButton = buttons.find((b) => b.props('to') === '/buyer-orders')
    expect(buyerOrderButton?.props('label')).toBe('Đơn hàng')
    expect(buttons.some((b) => b.props('label') === 'Tổng quan')).toBe(false)

    const menus = wrapper.findAllComponents({ name: 'DropdownMenu' })
    const adminItems = menus[0]?.props('items')
    expect(adminItems?.map((item: { label?: string }) => item.label)).toEqual([
      'Quản trị tổ chức',
      'Vai trò',
      'Tài khoản',
    ])

    const productionOrderItems = menus[1]?.props('items')
    expect(productionOrderItems?.map((item: { label?: string }) => item.label)).toEqual([
      'Danh sách LSX',
      'Tạo lệnh sản xuất',
    ])

    const productionItems = menus[2]?.props('items')
    expect(productionItems?.map((item: { label?: string }) => item.label)).toEqual([
      'Danh sách lệnh công đoạn',
    ])

    const materialItems = menus[3]?.props('items')
    expect(materialItems?.map((item: { label?: string }) => item.label)).toEqual([
      'Kanban',
      'Trả lại / Điều chuyển',
    ])

    const mobileNav = wrapper.findComponent({ name: 'NavigationMenu' })
    const mobileItems = mobileNav.props('items') as Array<{
      label?: string
      to?: string
      children?: Array<{ label?: string }>
    }>
    expect(mobileItems.find((item) => item.label === 'Đơn hàng')?.to).toBe('/buyer-orders')
    expect(
      mobileItems
        .find((item) => item.label === 'Lệnh sản xuất')
        ?.children?.map((item) => item.label),
    ).toEqual(['Danh sách LSX', 'Tạo lệnh sản xuất'])
    expect(
      mobileItems.find((item) => item.label === 'Sản xuất')?.children?.map((item) => item.label),
    ).toEqual(['Danh sách lệnh công đoạn'])
  })
})
