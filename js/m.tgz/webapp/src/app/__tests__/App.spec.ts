import { shallowMount } from '@vue/test-utils'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { nextTick } from 'vue'
import App from '../App.vue'
import { setToastInstance, showToast } from '@/shared/utils/toast'

const toastState = vi.hoisted(() => ({ mutateOnFirstShow: true }))
const networkState = vi.hoisted(() => ({ isOnline: { value: true } }))

vi.mock('@/shared/stores/auth', () => ({
  useAuthStore: () => ({ checkAuth: vi.fn() }),
}))

vi.mock('@/shared/utils/toast', async () => {
  const { shallowRef } = await import('vue')
  const revision = shallowRef(0)

  return {
    clearToastGroup: vi.fn(() => revision.value),
    setToastInstance: vi.fn(),
    showToast: vi.fn(() => {
      if (!toastState.mutateOnFirstShow) return
      toastState.mutateOnFirstShow = false
      revision.value++
    }),
  }
})

vi.mock('@nuxt/ui/composables', () => ({
  useToast: () => ({ add: vi.fn(), remove: vi.fn(), toasts: { value: [] } }),
}))

vi.mock('@vueuse/core', async (importOriginal) => {
  const { shallowRef } = await import('vue')
  networkState.isOnline = shallowRef(true)

  return {
    ...(await importOriginal<typeof import('@vueuse/core')>()),
    useNetwork: () => ({ isOnline: networkState.isOnline }),
  }
})

describe('App', () => {
  let wrapper: ReturnType<typeof shallowMount>

  beforeEach(() => {
    vi.clearAllMocks()
    toastState.mutateOnFirstShow = true
    networkState.isOnline.value = true
  })

  afterEach(() => wrapper.unmount())

  it('registers the toast service before showing the initial offline status', () => {
    networkState.isOnline.value = false
    wrapper = shallowMount(App)

    expect(vi.mocked(setToastInstance).mock.invocationCallOrder[0]).toBeLessThan(
      vi.mocked(showToast).mock.invocationCallOrder[0],
    )
  })

  it('does not show a restored connection toast when the app starts online', () => {
    wrapper = shallowMount(App)

    expect(showToast).not.toHaveBeenCalled()
  })

  it('shows network status changes once with matching icons', async () => {
    wrapper = shallowMount(App)

    networkState.isOnline.value = false
    await nextTick()
    expect(showToast).toHaveBeenLastCalledWith(
      expect.objectContaining({
        summary: 'Mất kết nối internet',
        icon: 'i-lucide-wifi-off',
      }),
    )

    networkState.isOnline.value = true
    await nextTick()
    expect(showToast).toHaveBeenLastCalledWith(
      expect.objectContaining({
        summary: 'Đã khôi phục kết nối internet',
        icon: 'i-lucide-wifi',
      }),
    )
    expect(showToast).toHaveBeenCalledTimes(2)
  })
})
