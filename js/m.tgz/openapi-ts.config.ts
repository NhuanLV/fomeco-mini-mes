import { defineConfig } from '@hey-api/openapi-ts'

export default defineConfig({
  input: './openapi.json',
  output: './webapp/src/api',
  plugins: [
    {
      name: '@pinia/colada',
      queryOptions: true,
      queryKeys: true,
      mutationOptions: true,
    },
    '@hey-api/client-ofetch',
    {
      name: 'zod',
      requests: true,
      definitions: true,
      dates: {
        local: true,
        offset: true,
      },
      types: {
        infer: false,
      },
      responses: {
        types: {
          infer: true,
        },
      },
    },
    {
      name: '@hey-api/sdk',
      validator: false,
    },
  ],
})
