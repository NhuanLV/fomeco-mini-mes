# LGG MES+

## 1. Tổng quan dự án

- **Tên hệ thống:** MES+ (Manufacturing Execution System Plus)
- **Khách hàng:** Tổng công ty LGG (Sản xuất may mặc)
- **Mục tiêu:** Hệ thống điều hành sản xuất may mặc độc lập với khả năng theo dõi sản xuất ở **cấp
  độ Tổ (Team-level)**.
  Hỗ trợ nhiều nguồn dữ liệu (nhập thủ công qua UI, import từ Excel, đồng bộ từ WFX, v.v.).
- Mô tả nghiệp vụ: các file CONTEXT.md trong các module

## 2. Các lệnh Xây dựng & Phát triển (Build & Development)

Dự án sử dụng cấu trúc Monorepo quản lý bởi `pnpm`. Tất cả các lệnh được chạy từ thư mục gốc.

```bash
# Cài đặt dependencies (cả frontend và backend scripts)
pnpm install

# Backend (Kotlin/Spring Boot)
pnpm backend:dev            # Chạy backend dev local (dùng Mock WFX, yêu cầu Docker cho PostgreSQL)
pnpm backend:dev:wfx-real   # Chạy backend kết nối trực tiếp với server WFX thật (tắt mock)
pnpm backend:dev:wfx-error  # Chạy backend giả lập lỗi WFX (mô phỏng GDN/GRN thất bại)
pnpm backend:clean          # Dọn dẹp các tệp build thừa

# Frontend (Vue 3)
pnpm frontend:dev           # Dev server (proxy /api tới localhost:8081)
pnpm frontend:fmt           # Định dạng code (oxfmt) & sửa lỗi lint (oxlint --fix)
pnpm frontend:lint          # Kiểm tra types (vue-tsc -b) & lint code (oxlint)
pnpm frontend:test          # Chạy unit tests (vitest)
pnpm frontend:test:e2e      # Chạy e2e tests (playwright)
pnpm frontend:build         # Build production (chạy frontend:lint trước)
pnpm openapi:gen            # Tạo lại API client (server phải đang chạy tại :8081)

# Deployment
pnpm deploy:staging         # Triển khai tới môi trường staging qua Ansible
```

## 3. Ngôn ngữ & Công nghệ (Tech Stack)

| Tầng (Layer)  | Công nghệ                                          |
| ------------- | -------------------------------------------------- |
| Ngôn ngữ      | Kotlin 2.3 + Java 25                               |
| Framework     | Spring Boot 4.0                                    |
| Cơ sở dữ liệu | PostgreSQL + JetBrains Exposed (v1.0.0)            |
| Frontend      | Vue 3.5 + Nuxt UI 4 + TailwindCSS 4 + Pinia Colada |
| Build tool    | Gradle + Vite 8 + pnpm                             |

## 4. Kiến trúc hệ thống (Architecture)

### Modular Monolith với Hexagonal Architecture (Ports & Adapters)

Mã nguồn được tổ chức theo **vertical slice** — mỗi module là một bounded context độc lập theo mô
hình
Hexagonal Architecture với 4 layer rõ ràng:

```
src/main/kotlin/vn/lgg/mesplus/
├── app/          Cross-cutting: SecurityConfig, GlobalExceptionHandler, filters, dashboard
├── shared/       Shared kernel: DomainEvent, DomainAggregate, Actor, PermissionService, BomCalculator...
├── iam/          Identity & Access: accounts, roles, org units (company/factory/team/warehouse)
├── order/        Orders: buyer orders, purchase orders, BOM, routing, styles, WFX sync
├── kanban/       Kanban: kanban CRUD, material/btp issuance (event-sourced)
└── production/   Production: production orders, team assignments, team BOMs, progress reporting

Mỗi module/              Hexagonal layers:
├── presentation/         REST endpoints (controller), request/response DTOs, view models
│   ├── controller/
│   └── viewmodel/
├── application/          Use cases (@Service + @Transactional) và event handlers
│   ├── usecase/
│   └── eventhandler/
├── domain/               Domain aggregates, entities, value objects, enums, domain events
│   ├── model/
│   ├── event/
│   └── service/          (một số module có domain service)
└── infrastructure/       Persistence cụ thể (Exposed DSL), external integrations (WFX)
    ├── repository/
    └── wfx/              (chỉ module order)
```

### Các nguyên tắc cốt lõi

- **Hướng phụ thuộc (Dependency direction):**
  `presentation → application → domain ← infrastructure`.
  `shared` là shared kernel được import bởi các module, không phụ thuộc ngược lại.
  `app` là application shell lắp ráp toàn bộ module (SecurityConfig, GlobalExceptionHandler, v.v.).
- **Vertical slices, không chia theo Layer truyền thống** — mã nguồn cho một tính năng nằm gọn trong
  một module, tránh
  việc phải nhảy qua lại giữa nhiều package.
- **Use Case nắm giữ transaction** — `@Transactional` chỉ đặt trên use case (
  `application/usecase/`), không đặt ở
  controller.
- **Tính thuần khiết của Domain aggregate** — `domain/model/` không phụ thuộc vào thư viện hay
  framework. Các model
  cần lưu lại đầy đủ lịch sử thì áp dụng **Event Sourcing** (`DomainAggregate.apply()` /
  `loadFromHistory()`), ví dụ
  module `kanban` và `production`.
- **Repository là các lớp cụ thể (concrete class)** — không dùng chia tách interface/impl. Method
  signature sử dụng
  kiểu domain thuần túy (String, domain model), method body chứa impl cụ thể (Exposed DSL).
- **CQRS-lite** — tách biệt write repository (event store + aggregate) và read repository (view
  repository) trong
  `infrastructure/repository/`.
- **Domain Events sau khi commit** — `SpringEventPublisher` trì hoãn việc publish cho đến
  `TransactionSynchronization.afterCommit()` để đảm bảo event handler chỉ chạy sau khi transaction
  thành công.
- **Không dùng Exposed trong controller** — `presentation/controller/` chỉ inject use case và view
  repository, không
  truy vấn table trực tiếp.

### Cấu trúc Frontend

```
webapp/src/
├── pages/              # File-based routing (vue-router/auto-routes)
│   ├── (main)/         # Layout group: các trang chính
│   │   ├── index.vue, accounts.vue, roles.vue, org-units.vue
│   │   ├── buyer-orders/, kanban/, production-orders/, team-assignments/
│   ├── login.vue
│   └── forbidden.vue
├── features/           # Feature modules — mỗi tính năng là một vertical slice
│   ├── account/        ├── components/, composable/, helpers/
│   ├── buyer-order/    ├── components/, composables/, helpers/, utils/, types.d.ts
│   ├── kanban/         ├── components/{create,grid}/, composables/, helpers/, types.d.ts
│   ├── org-unit/       ├── components/, composables/
│   ├── production/     ├── components/, composables/, helpers/, types.d.ts
│   ├── role/           ├── components/, composables/
│   └── team-assignment/├── components/{costing,progress}/, composable/
├── shared/             # Dùng chung toàn app
│   ├── components/     # UI components dùng chung
│   ├── composables/    # Logic dùng chung (Composition API)
│   ├── stores/         # Pinia — CHỈ chứa trạng thái giao diện (UI state)
│   ├── utils/          # Các hàm tiện ích thuần túy
│   └── types.d.ts
├── app/                # App shell
│   ├── App.vue, AppNavbar.vue
│   └── router/         # Cấu hình vue-router
├── api/                # Generated client + Pinia Colada hooks (KHÔNG sửa thủ công)
└── assets/
```

- **Pinia** -> Quản lý trạng thái giao diện (UI state).
- **Pinia Colada** -> Quản lý trạng thái từ máy chủ (Server state: caching, fetching). KHÔNG gọi
  `useQuery` /
  `useMutation` bên trong các Pinia stores.

## 5. Các quy tắc (Rules)

### Backend

- Luôn thực hiện import ở đầu tệp — không sử dụng tên đầy đủ (FQN) trong mã nguồn.
- Không sử dụng các inner class DTO bên trong Controllers.
- `@Transactional` chỉ nằm ở lớp Application (tầng Use Case).

### Frontend

- **TailwindCSS 4:** Ưu tiên sử dụng các utility classes, hạn chế tối đa việc dùng thẻ `<style>`.
- **Nuxt UI 4:** Sử dụng các props có sẵn (`color`, `size`, `variant`) trước khi dùng Tailwind để
  ghi đè.
- **pnpm only:** Tuyệt đối không sử dụng npm/yarn.
- **Imports:** Không thêm phần mở rộng `.ts` trong các câu lệnh import.

## 6. Quy trình thêm tính năng mới (New Feature Checklist)

1. Cập nhật Backend (Entity, Repository, UseCase, Controller).
2. Chạy `pnpm openapi:gen` để đồng bộ API client.
3. Tạo Page tại `webapp/src/pages/`.
4. Tạo các Components bổ trợ tại `webapp/src/components/{feature}/`.

## 7. Kiểm thử (Testing)

Sử dụng Playwright cho việc kiểm thử đầu cuối (E2E testing).
