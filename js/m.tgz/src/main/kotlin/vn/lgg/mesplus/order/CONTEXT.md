# Order Context

Đồng bộ, quản lý đơn hàng WFX, master data (Style, BOM, Routing) và cache master data nhà cung cấp WFX. Cơ sở phân bổ sản xuất.

## Language

**BuyerOrder** (BO):
Đơn gốc từ WFX. Chứa style, revision, qty, status.
_Avoid_: Đơn khách

**Trạng thái BuyerOrder**:
Trong code: `BuyerOrderStatus`.
Trạng thái BO. Gồm NEW, PROCESSING, RELEASED, COMPLETED.

**PO**:
Trong code: `PurchaseOrder`.
Đơn vị giao hàng của BO. Có mã thị trường, ngày giao hàng, số lượng theo màu/cỡ.
`type = REGULAR` cho PO của luồng đồng bộ/nhập BO hiện có; `type = POSITIVE` cho PO hàng dương
được BP Kế hoạch thêm trực tiếp trong BO trên MES+. PO hàng dương có metadata người/thời gian tạo,
không có mã PO WFX và được giữ nguyên qua các lần đồng bộ BO. Tạo/sửa PO yêu cầu quyền độc lập
`CREATE_POSITIVE_PURCHASE_ORDER` và quyền xem BO hiện tại (`MANAGE_BUYER_ORDER`); admin chủ động
cấp, không tự thêm quyền vào role hiện có. PO thường/dương được phân bổ chung LSX và phân công tổ.
Người đủ quyền được sửa mọi PO dương, kể cả BO hoàn thành: chỉ đổi quantity và bổ sung màu/cỡ
có trong BO, giữ thông tin PO và metadata tạo; ô được về 0 nhưng tổng PO > 0. Không xóa/chuyển loại PO.
Sửa quantity cập nhật tổng BO, đưa BO RELEASED/COMPLETED về PROCESSING; cho lưu dù phát sinh
xung đột phân bổ. User dùng điều chỉnh LSX/PO sản lượng hiện tại, tự tạo PO dương nhận nếu cần.
Sửa không tự đổi LSX, report, Kanban hoặc tồn kho; bản sửa được giữ khi sync WFX.
API sửa: `PUT /api/buyer-orders/{id}/positive-purchase-orders/{poId}`, body chỉ gồm `skuQuantities`.
`id` là định danh tham chiếu nội bộ MES; `wfxId` là định danh ổn định của PO WFX, duy nhất trong BO.
`code` chỉ là mã hiển thị, có thể đổi và trùng: một PO thực tế có thể được tách thành nhiều PO WFX
cùng mã nhưng khác `wfxId`. Đồng bộ chỉ nhận diện REGULAR PO bằng `wfxId`, không fallback theo `code`.

**Số lượng màu/cỡ**:
Trong code: `SkuQuantity` / `SkuAllocation`.
Số lượng của một bộ màu/cỡ trong PO hoặc trong phân bổ sản xuất.

**Mã hàng**:
Trong code: `Style`.
Thiết kế sản phẩm gắn BO. Định nghĩa thứ tự màu/cỡ.

**Định mức nguyên phụ liệu**:
Trong code: `BillOfMaterial` (BOM) / `BuyerOrderMaterial`.
Định mức NPL style / NPL thực tế BO. Dùng tính nhu cầu vật tư.

Mã NPL gửi WFX không lấy từ tên hiển thị BOM; `wfx_articles.code` và `uom` là nguồn canonical.
`style_Code` của đơn hàng WFX được lưu ở `buyer_orders.article_code` làm mã thành phẩm gốc duy nhất
của BO. Khi đồng bộ BOM, `article_id` của WFX được giữ trong `bo_material_lines.wfx_article_id` để
tra chính xác article master cho NPL. BTP không tra `wfx_articles`; MES ghép mã thành phẩm gốc với
hậu tố `ouputitem` (`outputItemSuffix`) lấy từ Routing của đơn hàng và dùng UOM `PCS`.

**Quy trình**:
Trong code: `Routing`.
Danh sách công đoạn cho style.

**Công đoạn**:
Trong code: `Operation`.
Bước sản xuất trong quy trình, ví dụ CUT, SEW, PRT.

**Màu**:
Trong code: `color`.
Màu sản phẩm trên WFX và trong phân bổ sản xuất.

**Cỡ**:
Trong code: `size`.
Cỡ sản phẩm trên WFX và trong phân bổ sản xuất.

**Mã WFX**:
Trong code: `wfxId`.
Mã BO từ WFX.

**Mã thị trường**:
Trong code: `destination`.
Mã thị trường (e.g. "US"), chuyển từ country name của WFX.

**Mã revision**:
Trong code: `revisionCode`.
Mã phiên bản BO, kèm revisionDate.

**WFX supplier**:
Trong code: `WfxSupplierSyncService` và `wfx_suppliers`.
Danh sách `SupplierCompanyName` lấy từ WFX được lưu cache để IAM dùng khi cấu hình Company outsource.
Cache được đọc qua `GET /api/wfx/suppliers`. Khi Admin mở trang Quản lý Đơn vị, FE tự gọi sync tối đa
một lần mỗi ngày cho từng tài khoản/browser (lưu mốc ngày trong `localStorage`); không có scheduled job
ở backend. Vẫn có thể trigger thủ công qua `POST /api/wfx/suppliers/sync`.

**Factory operation mapping**:
Mapping `factory_operations` thuộc IAM quản lý theo cấp Xí nghiệp `(factoryId, operationCode)`. `operationCode`
được chốt khi tạo mapping; tên công đoạn, hai kho liên kết và trạng thái có thể sửa, mapping không được xóa.
GDN dùng kho xuất NPL (`materialDispatchWarehouseId -> Warehouse.siteName`) và GRN dùng kho nhập BTP
(`btpReceiveWarehouseId -> Warehouse.siteName`) của công đoạn hiện tại.

## Rules

- **Qty**: totalQuantity BO = tổng SKU từ các PO.
- **PO hàng dương**: Mã PO được phép trùng; màu/cỡ và thị trường lấy từ
  BO hiện tại; tổng SKU dương. Thêm PO vào BO `RELEASED`/`COMPLETED` đưa BO về `PROCESSING` ngay.
- **Unallocated qty**: PO trừ allocations đã gán tổ (team assignment).
- **Sync**: BOM, Routing ghi đè (upsert), không event-source. State cục bộ do MES nhập cho NPL
  (`alternativeName`, `isRequired`) được lưu độc lập theo `(BO, wfxArticleId)` và được ghép lại khi
  NPL xuất hiện trong BOM WFX; vì vậy NPL tạm thời biến mất rồi xuất hiện lại vẫn khôi phục được
  state đó. NPL mới mặc định `isRequired = true`.
- **Revision SKU total**: WFX revision chỉ phân phối lại SKU giữa các PO; tổng quantity từng `(color, size)` trong một BO không đổi.
- **PO removed by revision**: Giữ PO cũ để tham chiếu lịch sử, nhưng đồng bộ SKU quantities thành danh sách rỗng.
- **SKU removed by revision**: Bỏ `(color, size)` khỏi SKU quantities; khi tra không có thì quantity là 0, không lưu dòng quantity 0.
- **Update**: WFX sync tạo BO. Event handler cập nhật progress.
- **BO cần điều chỉnh**: Khi ít nhất một TeamAssignment cần đối soát, hoặc tổng allocation theo
  `(PO, màu, cỡ)` của mọi LSX vượt quantity WFX. Sync/revision chỉ phát
  `BuyerOrderAdjustmentRequired` trên cạnh từ bình thường sang cần điều chỉnh; listener sau commit
  thông báo một lần theo BO cho các tài khoản có `ISSUE_PRODUCTION_ORDER` bao phủ ít nhất một tổ.

Quyền tạo/sửa PO dương được kiểm tra tại `BuyerOrderController`, bằng hai kiểm tra riêng yêu cầu đủ cả hai quyền. Usecase giữ validation nghiệp vụ; caller mới gọi trực tiếp usecase phải tự kiểm tra quyền.
