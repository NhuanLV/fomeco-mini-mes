package vn.lgg.mesplus.order.infrastructure.repository.mapping

import org.jetbrains.exposed.v1.core.ResultRow
import vn.lgg.mesplus.order.domain.model.Style
import vn.lgg.mesplus.order.infrastructure.repository.exposed.StylesTable.brand
import vn.lgg.mesplus.order.infrastructure.repository.exposed.StylesTable.customer
import vn.lgg.mesplus.order.infrastructure.repository.exposed.StylesTable.name
import vn.lgg.mesplus.order.infrastructure.repository.exposed.StylesTable.season

fun ResultRow.toStyle(): Style {
  return Style(
    name = this[name],
    customer = this[customer],
    brand = this[brand],
    season = this[season],
  )
}
