package vn.lgg.mesplus.order.application.usecase

import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import vn.lgg.mesplus.order.domain.model.BuyerOrderAdjustmentRequired
import vn.lgg.mesplus.order.domain.model.BuyerOrderStatus
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor

data class UpdatePositivePurchaseOrderCommand(val skuQuantities: List<PositiveSkuQuantityCommand>)

@Service
class UpdatePositivePurchaseOrderUseCase(
  private val buyerOrderRepository: BuyerOrderRepository,
  private val purchaseOrderRepository: PurchaseOrderRepository,
  private val allocationQueryService: AllocationQueryService,
  private val eventPublisher: DomainEventPublisher,
) {
  @Transactional
  fun execute(boId: String, poId: String, command: UpdatePositivePurchaseOrderCommand, actor: Actor) {
    val buyerOrder = buyerOrderRepository.lockById(boId)
      ?: throw NoSuchElementException("Không tìm thấy Đơn hàng: $boId")
    val purchaseOrders = purchaseOrderRepository.findByBuyerOrderId(boId)
    val po = purchaseOrders.find { it.id == poId }
      ?: throw NoSuchElementException("Không tìm thấy PO trong Đơn hàng: $poId")
    require(po.type == PurchaseOrderType.POSITIVE) { "Chỉ được sửa PO hàng dương" }
    val quantities = validatePositiveSkuQuantities(command.skuQuantities, purchaseOrders)
    if (quantities.toSet() == po.skuQties.toSet()) return

    val boTotal = purchaseOrders.filter { it.id != poId }.sumOf { it.totalQuantity.toLong() } +
      quantities.sumOf { it.quantity.toLong() }
    require(boTotal <= Int.MAX_VALUE) { "Tổng sản lượng BO vượt giới hạn" }
    val wasNeedsAdjustment = allocationQueryService.needsAdjustment(boId, purchaseOrders)
    purchaseOrderRepository.updateSkuQuantities(poId, quantities)
    buyerOrder.totalQuantity = boTotal.toInt()
    if (buyerOrder.status == BuyerOrderStatus.RELEASED || buyerOrder.status == BuyerOrderStatus.COMPLETED) {
      buyerOrder.status = BuyerOrderStatus.PROCESSING
    }
    buyerOrderRepository.save(buyerOrder)
    if (!wasNeedsAdjustment && allocationQueryService.needsAdjustment(
        boId, purchaseOrderRepository.findByBuyerOrderId(boId),
      )) {
      eventPublisher.publish(BuyerOrderAdjustmentRequired(
        buyerOrderId = boId,
        buyerOrderCode = buyerOrder.wfxId ?: boId,
        actor = actor.ref,
      ))
    }
  }
}
