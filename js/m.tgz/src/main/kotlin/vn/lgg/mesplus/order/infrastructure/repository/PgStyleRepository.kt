package vn.lgg.mesplus.order.infrastructure.repository

import org.jetbrains.exposed.v1.core.eq
import org.jetbrains.exposed.v1.core.inList
import org.jetbrains.exposed.v1.core.like
import org.jetbrains.exposed.v1.core.lowerCase
import org.jetbrains.exposed.v1.jdbc.batchInsert
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.upsert
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Repository
import vn.lgg.mesplus.order.domain.model.Style
import vn.lgg.mesplus.order.domain.model.StyleColorOrder
import vn.lgg.mesplus.order.domain.model.StyleSizeOrder
import vn.lgg.mesplus.order.domain.repository.StyleRepository
import vn.lgg.mesplus.order.infrastructure.repository.exposed.StyleColorOrdersTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.StyleSizeOrdersTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.StylesTable
import vn.lgg.mesplus.order.infrastructure.repository.mapping.toStyle
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size

@Repository
class PgStyleRepository : StyleRepository {
  override fun findByName(name: String): Style? {
    val styleRow =
      StylesTable.selectAll().where { StylesTable.name eq name }.singleOrNull() ?: return null

    return styleRow.toStyle().withOrders()
  }

  fun findStyles(search: String?, pageable: Pageable): Page<Style> {
    var query = StylesTable.selectAll()
    if (!search.isNullOrBlank()) {
      query = query.where { StylesTable.name.lowerCase() like "%${search.lowercase()}%" }
    }
    val total = query.count()
    val limit = pageable.pageSize
    val offset = pageable.offset
    val rows = query.limit(limit).offset(offset).map { it.toStyle() }
    return PageImpl(rows, pageable, total)
  }

  override fun findAll(): List<Style> {
    val styles = StylesTable.selectAll().map { it.toStyle() }
    if (styles.isEmpty()) return emptyList()

    val styleNames = styles.map { it.id }
    val colorOrdersByStyle =
      StyleColorOrdersTable.selectAll()
        .where { StyleColorOrdersTable.styleName inList styleNames }
        .groupBy { it[StyleColorOrdersTable.styleName] }
    val sizeOrdersByStyle =
      StyleSizeOrdersTable.selectAll()
        .where { StyleSizeOrdersTable.styleName inList styleNames }
        .groupBy { it[StyleSizeOrdersTable.styleName] }

    return styles.map { style ->
      style.apply {
        colorOrders = colorOrdersByStyle[style.id].toColorOrders()
        sizeOrders = sizeOrdersByStyle[style.id].toSizeOrders()
      }
    }
  }

  override fun save(style: Style) {
    StylesTable.upsert {
      it[name] = style.id
      it[customer] = style.customer
      it[brand] = style.brand
      it[season] = style.season
    }

    StyleColorOrdersTable.deleteWhere { styleName eq style.id }
    if (style.colorOrders.isNotEmpty()) {
      StyleColorOrdersTable.batchInsert(style.colorOrders) { colorOrder ->
        this[StyleColorOrdersTable.styleName] = style.id
        this[StyleColorOrdersTable.colorValue] = colorOrder.color.value
        this[StyleColorOrdersTable.sortOrder] = colorOrder.sortOrder
      }
    }

    StyleSizeOrdersTable.deleteWhere { styleName eq style.id }
    if (style.sizeOrders.isNotEmpty()) {
      StyleSizeOrdersTable.batchInsert(style.sizeOrders) { sizeOrder ->
        this[StyleSizeOrdersTable.styleName] = style.id
        this[StyleSizeOrdersTable.sizeValue] = sizeOrder.size.value
        this[StyleSizeOrdersTable.sortOrder] = sizeOrder.sortOrder
      }
    }
  }

  override fun existsByName(name: String): Boolean {
    return StylesTable.selectAll().where { StylesTable.name eq name }.count() > 0
  }

  private fun Style.withOrders(): Style =
    apply {
      colorOrders =
        StyleColorOrdersTable.selectAll()
          .where { StyleColorOrdersTable.styleName eq id }
          .toList()
          .toColorOrders()
      sizeOrders =
        StyleSizeOrdersTable.selectAll()
          .where { StyleSizeOrdersTable.styleName eq id }
          .toList()
          .toSizeOrders()
    }

  private fun List<org.jetbrains.exposed.v1.core.ResultRow>?.toColorOrders(): List<StyleColorOrder> {
    return this.orEmpty().map {
      StyleColorOrder(
        color = Color.of(it[StyleColorOrdersTable.colorValue]),
        sortOrder = it[StyleColorOrdersTable.sortOrder],
      )
    }
  }

  private fun List<org.jetbrains.exposed.v1.core.ResultRow>?.toSizeOrders(): List<StyleSizeOrder> {
    return this.orEmpty().map {
      StyleSizeOrder(
        size = Size.of(it[StyleSizeOrdersTable.sizeValue]),
        sortOrder = it[StyleSizeOrdersTable.sortOrder],
      )
    }
  }
}
