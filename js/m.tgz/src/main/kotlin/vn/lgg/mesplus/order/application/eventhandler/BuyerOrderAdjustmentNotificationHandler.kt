package vn.lgg.mesplus.order.application.eventhandler

import io.github.oshai.kotlinlogging.KotlinLogging
import org.springframework.context.event.EventListener
import org.springframework.scheduling.annotation.Async
import org.springframework.stereotype.Component
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import vn.lgg.mesplus.order.domain.model.BuyerOrderAdjustmentRequired
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.Activity
import vn.lgg.mesplus.shared.NotificationTarget
import vn.lgg.mesplus.shared.Notifier
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

@Component
class BuyerOrderAdjustmentNotificationHandler(
  private val creator: BuyerOrderAdjustmentNotificationCreator
) {
  private val log = KotlinLogging.logger {}

  @Async
  @EventListener
  fun handle(event: BuyerOrderAdjustmentRequired) {
    try {
      creator.create(event)
    } catch (exception: Exception) {
      log.warn(exception) {
        "Không thể tạo notification điều chỉnh BuyerOrder ${event.buyerOrderId}"
      }
    }
  }
}

@Service
class BuyerOrderAdjustmentNotificationCreator(
  private val assignmentRepository: TeamAssignmentRepository,
  private val permissionService: PermissionService,
  private val notifier: Notifier,
) {
  @Transactional(readOnly = true)
  fun create(event: BuyerOrderAdjustmentRequired) {
    val recipients =
      assignmentRepository
        .findByBuyerOrderId(event.buyerOrderId)
        .map { it.teamId }
        .distinct()
        .flatMap { permissionService.lookupAccountIds(Permission.ISSUE_PRODUCTION_ORDER, it) }
        .distinct()

    notifier.notify(
      recipients,
      Activity(
        actor = event.actor,
        title = "Đơn hàng cần điều chỉnh",
        body = "đã thay đổi BO ${event.buyerOrderCode}, cần điều chỉnh",
        target = NotificationTarget(ResourceType.BUYER_ORDER, event.buyerOrderId),
      ),
    )
  }
}
