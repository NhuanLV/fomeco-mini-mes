package vn.lgg.mesplus.order.infrastructure.repository

import io.github.oshai.kotlinlogging.KotlinLogging
import java.time.LocalDate
import java.util.UUID
import org.jetbrains.exposed.v1.core.JoinType
import org.jetbrains.exposed.v1.core.and
import org.jetbrains.exposed.v1.core.eq
import org.jetbrains.exposed.v1.core.inList
import org.jetbrains.exposed.v1.core.or
import org.jetbrains.exposed.v1.jdbc.batchInsert
import org.jetbrains.exposed.v1.jdbc.select
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.upsert
import org.springframework.stereotype.Repository
import org.springframework.transaction.annotation.Transactional
import vn.lgg.mesplus.order.infrastructure.from
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLinesTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.WfxArticleTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.WfxColorTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.WfxCountryTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.WfxSizeTable
import vn.lgg.mesplus.order.infrastructure.wfx.client.WfxClient
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.WfxArticleDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.WfxColorDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.WfxSizeDto
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

@Repository
class WfxRepository(private val wfxClient: WfxClient) {
  private val log = KotlinLogging.logger {}

  fun findColorsByIds(colorIds: Set<String>): Map<String, Color> {
    val result =
      WfxColorTable.selectAll()
        .where { WfxColorTable.id inList colorIds }
        .associate {
          it[WfxColorTable.id] to Color.from(it[WfxColorTable.code], it[WfxColorTable.desc])
        }
    if (result.size == colorIds.size) return result
    val missingIds = colorIds - result.keys
    log.debug { "Missing ${missingIds.size} colors, resync from wfx..." }
    batchInsertColors(wfxClient.getAllColors(MASTER_SYNC_FROM))
    val refreshed =
      WfxColorTable.selectAll()
        .where { WfxColorTable.id inList colorIds }
        .associate {
          it[WfxColorTable.id] to Color.from(it[WfxColorTable.code], it[WfxColorTable.desc])
        }
    val unresolvedIds = colorIds - refreshed.keys
    if (unresolvedIds.isNotEmpty()) {
      log.warn { "WFX master data không chứa color IDs: $unresolvedIds" }
    }
    return refreshed
  }

  fun findSizesByIds(sizeIds: Set<String>): Map<String, Size> {
    val result =
      WfxSizeTable.selectAll()
        .where { WfxSizeTable.id inList sizeIds }
        .associate {
          it[WfxSizeTable.id] to Size.from(it[WfxSizeTable.code], it[WfxSizeTable.desc])
        }
    if (result.size == sizeIds.size) return result
    val missingSizeIds = sizeIds - result.keys
    log.debug { "Missing ${missingSizeIds.size} size, sync from wfx..." }
    batchInsertSizes(wfxClient.getAllSizes(MASTER_SYNC_FROM))
    val refreshed =
      WfxSizeTable.selectAll()
        .where { WfxSizeTable.id inList sizeIds }
        .associate {
          it[WfxSizeTable.id] to Size.from(
            it[WfxSizeTable.code],
            it[WfxSizeTable.desc],
          )
        }
    val unresolvedIds = sizeIds - refreshed.keys
    if (unresolvedIds.isNotEmpty()) {
      log.warn { "WFX master data không chứa size IDs: $unresolvedIds" }
    }
    return refreshed
  }

  @Transactional(readOnly = true)
  fun isArticlesEmpty(): Boolean =
    WfxArticleTable.selectAll().count() <= SEEDED_OPERATION_COUNT

  @Transactional(readOnly = true)
  fun isColorsEmpty(): Boolean =
    WfxColorTable.selectAll().count() == 0L

  @Transactional(readOnly = true)
  fun isSizesEmpty(): Boolean =
    WfxSizeTable.selectAll().count() == 0L

  @Transactional
  fun insertColors(colors: List<WfxColorDto>) {
    batchInsertColors(colors)
  }

  @Transactional
  fun insertSizes(sizes: List<WfxSizeDto>) {
    batchInsertSizes(sizes)
  }

  private fun batchInsertColors(colors: List<WfxColorDto>) {
    WfxColorTable.batchInsert(colors, ignore = true) { c ->
      this[WfxColorTable.id] = c.colorId
      this[WfxColorTable.code] = c.colorCode.orEmpty()
      this[WfxColorTable.desc] = c.colorName.orEmpty()
    }
  }

  private fun batchInsertSizes(sizes: List<WfxSizeDto>) {
    WfxSizeTable.batchInsert(sizes, ignore = true) { s ->
      this[WfxSizeTable.id] = s.sizeId
      this[WfxSizeTable.code] = s.sizeCode.orEmpty()
      this[WfxSizeTable.desc] = s.sizeName.orEmpty()
    }
  }

  fun findOperationByProcessId(processId: String): Operation? =
    WfxArticleTable.selectAll()
      .where { WfxArticleTable.id eq processId }
      .singleOrNull()
      ?.let { Operation(it[WfxArticleTable.code]) }

  fun findCountryCodesByNames(names: List<String>): Map<String, String> {
    if (names.isEmpty()) return emptyMap()
    return WfxCountryTable.selectAll()
      .where { WfxCountryTable.name inList names }
      .associate { it[WfxCountryTable.name] to it[WfxCountryTable.code] }
  }

  fun findCountryNamesByCodes(codes: List<String>): Map<String, String> {
    if (codes.isEmpty()) return emptyMap()
    return WfxCountryTable.selectAll()
      .where { WfxCountryTable.code inList codes }
      .associate { it[WfxCountryTable.code] to it[WfxCountryTable.name] }
  }

  @Transactional
  fun upsertArticles(articles: List<WfxArticleDto>) {
    articles
      .filter { it.articleId.isNotBlank() }
      .distinctBy { it.articleId }
      .forEach { article ->
        WfxArticleTable.upsert(keys = arrayOf(WfxArticleTable.id)) {
          it[WfxArticleTable.id] = article.articleId
          it[WfxArticleTable.code] = article.articleCode
          it[WfxArticleTable.name] = article.articleName
          it[WfxArticleTable.uom] = article.storingUom
        }
      }
  }

  fun queryArticles(articleIds: List<String>): Map<String, ArticleInfo> {
    if (articleIds.isEmpty()) return emptyMap()
    return WfxArticleTable.selectAll()
      .where { WfxArticleTable.id inList articleIds }
      .associate {
        it[WfxArticleTable.id] to
          ArticleInfo(
            name = it[WfxArticleTable.name],
            uom = it[WfxArticleTable.uom],
            code = it[WfxArticleTable.code],
          )
      }
  }

  fun findCodesByBomLineIds(buyerOrderId: UUID, bomLineIds: List<String>): Map<String, String> {
    if (bomLineIds.isEmpty()) return emptyMap()
    return BoMaterialLinesTable
      .join(
        WfxArticleTable,
        JoinType.INNER,
        onColumn = BoMaterialLinesTable.wfxArticleId,
        otherColumn = WfxArticleTable.id,
      )
      .select(listOf(BoMaterialLinesTable.wfxBomLineId, WfxArticleTable.code))
      .where {
        (BoMaterialLinesTable.boId eq buyerOrderId) and
          (BoMaterialLinesTable.wfxBomLineId inList bomLineIds)
      }
      .mapNotNull { row ->
        row[BoMaterialLinesTable.wfxBomLineId]?.let { it to row[WfxArticleTable.code] }
      }
      .toMap()
  }

  fun findArticleByReference(article: String): ArticleInfo? {
    if (article.isBlank()) return null
    return WfxArticleTable.selectAll()
      .where {
        (WfxArticleTable.name eq article) or
          (WfxArticleTable.code eq article) or
          (WfxArticleTable.id eq article)
      }
      .firstOrNull()
      ?.let {
        ArticleInfo(
          name = it[WfxArticleTable.name],
          uom = it[WfxArticleTable.uom],
          code = it[WfxArticleTable.code],
        )
      }
  }

  data class ArticleInfo(
    val name: String,
    val uom: String,
    val code: String = "",
  )

  private companion object {
    // Keep in sync with the operation rows in R__4_seed_wfx_master_data.sql.
    const val SEEDED_OPERATION_COUNT = 15L
    val MASTER_SYNC_FROM = LocalDate.of(2024, 1, 1)
  }
}
