package vn.lgg.mesplus.order.application.usecase

import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import vn.lgg.mesplus.order.domain.model.BoMaterialStateUpdate
import vn.lgg.mesplus.order.domain.repository.BoMaterialStateRepository
import vn.lgg.mesplus.production.domain.repository.TeamMaterialRepository
import vn.lgg.mesplus.shared.model.Actor

data class UpdateBoMaterialStatesCommand(
  val updates: List<BoMaterialStateUpdate>
)

@Service
class UpdateBoMaterialStatesUseCase(
  private val boMaterialStateRepository: BoMaterialStateRepository,
  private val teamMaterialRepository: TeamMaterialRepository,
) {

  @Transactional
  fun execute(
    boId: String,
    command: UpdateBoMaterialStatesCommand,
    actor: Actor
  ) {
    boMaterialStateRepository.updateMaterialStates(boId, command.updates)
    teamMaterialRepository.updateMaterialStatesByBoId(boId, command.updates, actor)
  }
}
