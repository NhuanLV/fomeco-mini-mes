package vn.lgg.mesplus.order.application.usecase

import java.time.Instant
import java.util.*
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.util.IdGenerator
import vn.lgg.mesplus.order.application.usecase.command.UpsertBuyerOrderCommand
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderAdjustmentRequired
import vn.lgg.mesplus.order.domain.model.BuyerOrderStatus
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.repository.StyleRepository
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.SkuQuantity

@Service
@Transactional
class UpsertBuyerOrderUseCase(
  private val styleRepo: StyleRepository,
  private val boRepo: BuyerOrderRepository,
  private val poRepo: PurchaseOrderRepository,
  private val idGenerator: IdGenerator,
  private val allocationQueryService: AllocationQueryService,
  private val eventPublisher: DomainEventPublisher,
) {
  fun execute(command: UpsertBuyerOrderCommand) {
    require(command.purchaseOrders.all { !it.wfxId.isNullOrBlank() }) {
      "PO đồng bộ phải có WFX ID"
    }
    require(command.purchaseOrders.map { it.wfxId }.distinct().size == command.purchaseOrders.size) {
      "WFX ID của PO không được trùng trong BO"
    }
    require(styleRepo.existsByName(command.styleName))
    val existingBuyerOrder = command.wfxId?.let { boRepo.findByWfxId(it) }?.let {
      boRepo.lockById(it.id)
    }
    val oldPurchaseOrders =
      existingBuyerOrder?.let { poRepo.findByBuyerOrderId(it.id) }.orEmpty()
    val wasNeedsAdjustment =
      existingBuyerOrder?.let { allocationQueryService.needsAdjustment(it.id, oldPurchaseOrders) }
        ?: false
    val (buyerOrder, purchaseOrders) =
      if (existingBuyerOrder == null) createNewBuyerOrder(command)
      else updateBuyerOrder(existingBuyerOrder, command, oldPurchaseOrders)

    boRepo.save(buyerOrder)
    poRepo.saveAll(buyerOrder.id, purchaseOrders.filter { it.type == PurchaseOrderType.REGULAR })
    if (
      !wasNeedsAdjustment &&
        existingBuyerOrder != null &&
        allocationQueryService.needsAdjustment(buyerOrder.id, purchaseOrders)
    ) {
      eventPublisher.publish(
        BuyerOrderAdjustmentRequired(
          buyerOrderId = buyerOrder.id,
          buyerOrderCode = buyerOrder.wfxId ?: buyerOrder.id,
          actor = null,
        )
      )
    }
  }

  private fun createNewBuyerOrder(
    cmd: UpsertBuyerOrderCommand
  ): Pair<BuyerOrder, List<PurchaseOrder>> {
    val boId = idGenerator.generateId().toString()

    val purchaseOrders =
      cmd.purchaseOrders.map { po ->
        PurchaseOrder(
          id = idGenerator.generateId().toString(),
          wfxId = po.wfxId,
          code = po.code,
          destination = po.destination,
          deliveryDate = po.deliveryDate,
          skuQties =
            po.skuQuantities.map { SkuQuantity(color = it.color, size = it.size, it.quantity) },
          buyerOrderId = boId,
        )
      }

    val totalQuantity = purchaseOrders.sumOf { it.totalQuantity }
    return BuyerOrder(
      id = boId,
      wfxId = cmd.wfxId,
      styleName = cmd.styleName,
      articleCode = cmd.articleCode,
      revisionCode = cmd.revisionCode ?: "1",
      revisionDate = cmd.revisionDate ?: Instant.now(),
      lastSyncedAt = Instant.now(),
      status = BuyerOrderStatus.NEW,
      totalQuantity = totalQuantity,
      summaryBuyerOrderRef = cmd.summaryBuyerOrderRef,
    ) to purchaseOrders
  }

  private fun updateBuyerOrder(
    existingBuyerOrder: BuyerOrder,
    command: UpsertBuyerOrderCommand,
    existingPos: List<PurchaseOrder>,
  ): Pair<BuyerOrder, List<PurchaseOrder>> {
    existingBuyerOrder.lastSyncedAt = Instant.now()
    command.articleCode?.trim()?.takeIf { it.isNotBlank() }?.let {
      existingBuyerOrder.articleCode = it
    }
    command.summaryBuyerOrderRef?.trim()?.takeIf { it.isNotBlank() }?.let {
      existingBuyerOrder.summaryBuyerOrderRef = it
    }

    val purchaseOrders =
      command.purchaseOrders.map { po ->
        val existingPo = existingPos.find {
          it.type == PurchaseOrderType.REGULAR && it.wfxId == po.wfxId
        }
        PurchaseOrder(
          id = existingPo?.id ?: UUID.randomUUID().toString(),
          wfxId = po.wfxId,
          code = po.code,
          destination = po.destination,
          deliveryDate = po.deliveryDate,
          skuQties =
            po.skuQuantities.map { sku ->
              SkuQuantity(color = sku.color, size = sku.size, quantity = sku.quantity)
            },
          buyerOrderId = existingBuyerOrder.id,
        )
      }
    val positiveOrders = existingPos.filter { it.type == PurchaseOrderType.POSITIVE }
    existingBuyerOrder.totalQuantity = (purchaseOrders + positiveOrders).sumOf { it.totalQuantity }
    return existingBuyerOrder to (purchaseOrders + positiveOrders)
  }
}
