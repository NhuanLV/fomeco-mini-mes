package vn.lgg.mesplus.order.application.usecase

import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import vn.lgg.mesplus.order.domain.model.BillOfMaterial
import vn.lgg.mesplus.order.domain.repository.BillOfMaterialRepository

@Service
class UpsertBomUseCase(private val bomRepo: BillOfMaterialRepository) {
  @Transactional
  fun execute(command: BillOfMaterial) {
    bomRepo.save(command)
  }
}
