package vn.lgg.mesplus.order.infrastructure.repository

import java.util.*
import org.jetbrains.exposed.v1.core.eq
import org.jetbrains.exposed.v1.core.inList
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.insertAndGetId
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.springframework.stereotype.Repository
import vn.lgg.mesplus.order.domain.model.BillOfMaterial
import vn.lgg.mesplus.order.domain.model.BuyerOrderMaterial
import vn.lgg.mesplus.order.domain.model.OperationUsage
import vn.lgg.mesplus.order.domain.repository.BillOfMaterialRepository
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLineColorsTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLineColorsTable.materialColor
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLineColorsTable.productColor
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLineDestinationsTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLineDestinationsTable.destinationCode
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLineOperationsTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLineOperationsTable.operation
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLineSizesTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLineSizesTable.materialSize
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLineSizesTable.productSize
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLinesTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLinesTable.boId
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLinesTable.category
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLinesTable.id
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLinesTable.name
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLinesTable.uom
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Material
import vn.lgg.mesplus.shared.model.MaterialColorDep
import vn.lgg.mesplus.shared.model.MaterialSizeDep
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLinesTable.alternativeName
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLinesTable.isRequired
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BoMaterialLinesTable.wfxArticleId
import vn.lgg.mesplus.order.infrastructure.repository.exposed.WfxArticleTable

@Repository
class PgBillOfMaterialRepository : BillOfMaterialRepository {
  override fun findByBuyerOrderId(buyerOrderId: String): BillOfMaterial? {
    val boUuid = UUID.fromString(buyerOrderId)

    val mlRows = BoMaterialLinesTable.selectAll().where { boId eq boUuid }.toList()

    if (mlRows.isEmpty()) {
      return null
    }

    val mlIds = mlRows.map { it[id].value }
    val wfxArticleIds = mlRows.mapNotNull { it[wfxArticleId] }.distinct()
    val articleRows =
      if (wfxArticleIds.isEmpty()) emptyList()
      else WfxArticleTable.selectAll().where { WfxArticleTable.id inList wfxArticleIds }.toList()
    val articleCodeById = articleRows.associate { it[WfxArticleTable.id] to it[WfxArticleTable.code] }

    val mlSizes =
      if (mlIds.isEmpty()) emptyMap()
      else {
        BoMaterialLineSizesTable.selectAll()
          .where { BoMaterialLineSizesTable.boMaterialLineId inList mlIds }
          .toList()
          .groupBy { it[BoMaterialLineSizesTable.boMaterialLineId] }
      }
    val mlColors =
      if (mlIds.isEmpty()) emptyMap()
      else {
        BoMaterialLineColorsTable.selectAll()
          .where { BoMaterialLineColorsTable.boMaterialLineId inList mlIds }
          .toList()
          .groupBy { it[BoMaterialLineColorsTable.boMaterialLineId] }
      }
    val mlOps =
      if (mlIds.isEmpty()) emptyMap()
      else {
        BoMaterialLineOperationsTable.selectAll()
          .where { BoMaterialLineOperationsTable.boMaterialLineId inList mlIds }
          .toList()
          .groupBy { it[BoMaterialLineOperationsTable.boMaterialLineId] }
      }
    val mlDestinations =
      if (mlIds.isEmpty()) emptyMap()
      else {
        BoMaterialLineDestinationsTable.selectAll()
          .where { BoMaterialLineDestinationsTable.boMaterialLineId inList mlIds }
          .toList()
          .groupBy { it[BoMaterialLineDestinationsTable.boMaterialLineId] }
      }

    val materialLines = mlRows.map { row ->
      val mlId = row[id].value

      val sizes =
        mlSizes[mlId]?.map { sr ->
          MaterialSizeDep(
            materialSize = Size(sr[materialSize]),
            productSize = Size(sr[productSize]),
            consumption = sr[BoMaterialLineSizesTable.consumption],
          )
        } ?: emptyList()

      val colors =
        mlColors[mlId]?.map { cr ->
          MaterialColorDep(
            materialColor = Color(cr[materialColor]),
            productColor = Color(cr[productColor]),
            consumption = cr[BoMaterialLineColorsTable.consumption],
          )
        } ?: emptyList()

      val operations =
        mlOps[mlId]?.map { or ->
          OperationUsage(
            operation = Operation(or[operation]),
            consumption = or[BoMaterialLineOperationsTable.consumption],
          )
        } ?: emptyList()

      BuyerOrderMaterial(
        id = mlId.toString(),
        wfxBomLineId = row[BoMaterialLinesTable.wfxBomLineId],
        material = Material(
          name = row[name], 
          category = row[category], 
          uom = row[uom], 
          alternativeName = row[alternativeName],
          isRequired = row[isRequired],
          wfxArticleId = row[wfxArticleId],
          articleCode = row[wfxArticleId]?.let { articleCodeById[it] },
        ),
        sizeDeps = sizes,
        colorDeps = colors,
        usedForOperations = operations,
        usedForDestinations = mlDestinations[mlId]?.map { it[destinationCode] } ?: emptyList(),
      )
    }

    return BillOfMaterial(buyerOrderId = buyerOrderId, materials = materialLines)
  }

  override fun save(bom: BillOfMaterial) {
    val boUuid = UUID.fromString(bom.buyerOrderId)

    val existingIds = BoMaterialLinesTable.selectAll().where { boId eq boUuid }.map { it[id].value }

    if (existingIds.isNotEmpty()) {
      BoMaterialLineSizesTable.deleteWhere { boMaterialLineId inList existingIds }
      BoMaterialLineColorsTable.deleteWhere { boMaterialLineId inList existingIds }
      BoMaterialLineOperationsTable.deleteWhere { boMaterialLineId inList existingIds }
      BoMaterialLineDestinationsTable.deleteWhere { boMaterialLineId inList existingIds }
      BoMaterialLinesTable.deleteWhere { BoMaterialLinesTable.id inList existingIds }
    }

    bom.materials.forEach { line ->
      val lineId =
        BoMaterialLinesTable.insertAndGetId {
            it[boId] = boUuid
            it[name] = line.material.name
            it[alternativeName] = line.material.alternativeName
            it[isRequired] = line.material.isRequired
            it[wfxArticleId] = line.material.wfxArticleId
            it[wfxBomLineId] = line.wfxBomLineId
            it[category] = line.material.category
            it[uom] = line.material.uom
          }
          .value

      line.sizeDeps.distinctBy { it.productSize.value }.forEach { size ->
        BoMaterialLineSizesTable.insert {
          it[boMaterialLineId] = lineId
          it[materialSize] = size.materialSize.value
          it[productSize] = size.productSize.value
          it[consumption] = size.consumption
        }
      }
      line.colorDeps.distinctBy { it.productColor.value }.forEach { color ->
        BoMaterialLineColorsTable.insert {
          it[boMaterialLineId] = lineId
          it[materialColor] = color.materialColor.value
          it[productColor] = color.productColor.value
          it[consumption] = color.consumption
        }
      }
      line.usedForOperations.forEach { op ->
        BoMaterialLineOperationsTable.insert {
          it[boMaterialLineId] = lineId
          it[operation] = op.operation.name
          it[consumption] = op.consumption
        }
      }
      line.usedForDestinations.forEach { code ->
        BoMaterialLineDestinationsTable.insert {
          it[boMaterialLineId] = lineId
          it[destinationCode] = code
        }
      }
    }
  }
}
