package vn.lgg.mesplus.order.application.usecase

import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import vn.lgg.mesplus.order.domain.model.BuyerOrderRouting
import vn.lgg.mesplus.order.domain.model.Routing
import vn.lgg.mesplus.order.domain.model.RoutingProcess
import vn.lgg.mesplus.order.domain.repository.RoutingRepository
import vn.lgg.mesplus.shared.model.Operation

@Service
class UpsertRoutingUseCase(private val routingRepo: RoutingRepository) {
  @Transactional
  fun execute(command: UpsertRoutingCommand) {
    val domainRoutings =
      command.routings.map { item ->
        Routing(
          title = item.title,
          processes =
            item.processes.map { proc ->
              RoutingProcess(
                operation = Operation(proc.operationName),
                outputItemSuffix = proc.outputItemSuffix,
              )
            },
        )
      }
    val buyerOrderRouting =
      BuyerOrderRouting(buyerOrderId = command.buyerOrderId, routings = domainRoutings)
    routingRepo.save(buyerOrderRouting)
  }
}

data class UpsertRoutingCommand(val buyerOrderId: String, val routings: List<RoutingItemCommand>)

data class RoutingProcessCommand(
  val operationName: String,
  val outputItemSuffix: String? = null,
)

data class RoutingItemCommand(
  val title: String,
  val processes: List<RoutingProcessCommand>,
)
