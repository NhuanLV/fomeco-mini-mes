package vn.lgg.mesplus.order.application.usecase

import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import java.util.UUID
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import vn.lgg.mesplus.order.domain.model.BuyerOrderStatus
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.SkuQuantity

data class AddPositivePurchaseOrderCommand(
  val code: String,
  val destination: String,
  val deliveryDate: LocalDate,
  val skuQuantities: List<PositiveSkuQuantityCommand>,
)

data class PositiveSkuQuantityCommand(
  val color: Color,
  val size: Size,
  val quantity: BigDecimal,
)

data class AddPositivePurchaseOrderResult(val id: String)

@Service
class AddPositivePurchaseOrderUseCase(
  private val buyerOrderRepository: BuyerOrderRepository,
  private val purchaseOrderRepository: PurchaseOrderRepository,
) {
  @Transactional
  fun execute(boId: String, command: AddPositivePurchaseOrderCommand, actor: Actor): AddPositivePurchaseOrderResult {
    val buyerOrder = buyerOrderRepository.lockById(boId)
      ?: throw NoSuchElementException("Không tìm thấy Đơn hàng: $boId")
    val existingOrders = purchaseOrderRepository.findByBuyerOrderId(boId)
    val markets = existingOrders.map { it.destination }.filter { it.isNotBlank() }.toSet()
    val colors = existingOrders.flatMap { it.skuQties }.map { it.color }.toSet()
    val sizes = existingOrders.flatMap { it.skuQties }.map { it.size }.toSet()

    require(existingOrders.isNotEmpty() && markets.isNotEmpty() && colors.isNotEmpty() && sizes.isNotEmpty()) {
      "Đơn hàng chưa có đủ PO, màu/cỡ và thị trường để thêm PO hàng dương"
    }
    require(command.code.isNotBlank()) { "Vui lòng nhập Mã PO" }
    require(command.destination in markets) { "Vui lòng chọn Thị trường thuộc BO này" }
    val quantities = validatePositiveSkuQuantities(command.skuQuantities, existingOrders)
    val total = quantities.sumOf { it.quantity.toLong() }
    val po = PurchaseOrder(
      id = UUID.randomUUID().toString(),
      wfxId = null,
      code = command.code,
      destination = command.destination,
      deliveryDate = command.deliveryDate,
      skuQties = quantities.filter { it.quantity > 0 },
      buyerOrderId = boId,
      type = PurchaseOrderType.POSITIVE,
      createdBy = actor.ref,
      createdAt = Instant.now(),
    )
    purchaseOrderRepository.save(po)
    val boTotal = existingOrders.sumOf { it.totalQuantity.toLong() } + total
    require(boTotal <= Int.MAX_VALUE) { "Tổng sản lượng BO vượt giới hạn" }
    buyerOrder.totalQuantity = boTotal.toInt()
    if (buyerOrder.status == BuyerOrderStatus.RELEASED || buyerOrder.status == BuyerOrderStatus.COMPLETED) {
      buyerOrder.status = BuyerOrderStatus.PROCESSING
    }
    buyerOrderRepository.save(buyerOrder)
    return AddPositivePurchaseOrderResult(po.id)
  }
}

internal fun validatePositiveSkuQuantities(
  items: List<PositiveSkuQuantityCommand>,
  purchaseOrders: List<PurchaseOrder>,
): List<SkuQuantity> {
  val colors = purchaseOrders.flatMap { it.skuQties }.map { it.color }.toSet()
  val sizes = purchaseOrders.flatMap { it.skuQties }.map { it.size }.toSet()
  require(items.isNotEmpty()) { "Vui lòng nhập Ma trận màu/cỡ" }
  require(items.map { it.color to it.size }.distinct().size == items.size) {
    "Ma trận màu/cỡ có ô trùng lặp"
  }
  val quantities = items.map { item ->
    require(item.color in colors && item.size in sizes) { "Màu/cỡ không thuộc BO này" }
    require(item.quantity >= BigDecimal.ZERO && item.quantity.stripTrailingZeros().scale() <= 0) {
      "Số lượng màu/cỡ phải là số nguyên không âm"
    }
    require(item.quantity <= BigDecimal.valueOf(Int.MAX_VALUE.toLong())) {
      "Số lượng màu/cỡ vượt giới hạn"
    }
    SkuQuantity(item.color, item.size, item.quantity.toInt())
  }
  val total = quantities.sumOf { it.quantity.toLong() }
  require(total > 0) { "Tổng sản lượng PO phải lớn hơn 0" }
  require(total <= Int.MAX_VALUE) { "Tổng sản lượng PO vượt giới hạn" }
  return quantities.filter { it.quantity > 0 }
}
