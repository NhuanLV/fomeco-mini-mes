package vn.lgg.mesplus.order.infrastructure.repository.mapping

import org.jetbrains.exposed.v1.core.ResultRow
import org.jetbrains.exposed.v1.core.eq
import org.jetbrains.exposed.v1.jdbc.selectAll
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PoSkuQuantitiesTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PoSkuQuantitiesTable.color
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PoSkuQuantitiesTable.poId
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PoSkuQuantitiesTable.quantity
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PoSkuQuantitiesTable.size
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PurchaseOrdersTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PurchaseOrdersTable.boId
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PurchaseOrdersTable.code
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PurchaseOrdersTable.deliveryDate
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PurchaseOrdersTable.market
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.SkuQuantity

fun ResultRow.toPurchaseOrder(): PurchaseOrder {
  val poUuid = this[PurchaseOrdersTable.id].value

  val skuQties =
    PoSkuQuantitiesTable.selectAll()
      .where { poId eq poUuid }
      .map { skuRow ->
        SkuQuantity(
          color = Color(skuRow[color]),
          size = Size(skuRow[size]),
          quantity = skuRow[quantity],
        )
      }

  return PurchaseOrder(
    id = poUuid.toString(),
    wfxId = this[PurchaseOrdersTable.wfxId],
    code = this[code],
    destination = this[market],
    deliveryDate = this[deliveryDate],
    skuQties = skuQties,
    buyerOrderId = this[boId].toString(),
    type = PurchaseOrderType.valueOf(this[PurchaseOrdersTable.type]),
    createdBy = this[PurchaseOrdersTable.createdById]?.let { actorId ->
      ActorRef(actorId, this[PurchaseOrdersTable.createdByName] ?: "")
    },
    createdAt = this[PurchaseOrdersTable.createdAt],
  )
}
