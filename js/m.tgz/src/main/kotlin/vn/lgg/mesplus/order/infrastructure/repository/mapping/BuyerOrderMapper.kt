package vn.lgg.mesplus.order.infrastructure.repository.mapping

import org.jetbrains.exposed.v1.core.ResultRow
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderStatus
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BuyerOrdersTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BuyerOrdersTable.lastSyncedAt
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BuyerOrdersTable.articleCode
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BuyerOrdersTable.revisionCode
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BuyerOrdersTable.revisionDate
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BuyerOrdersTable.status
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BuyerOrdersTable.styleName

fun ResultRow.toBuyerOrder(): BuyerOrder {
  val boId = this[BuyerOrdersTable.id].value

  return BuyerOrder(
    id = boId.toString(),
    wfxId = this[BuyerOrdersTable.wfxId],
    styleName = this[styleName],
    articleCode = this[articleCode],
    revisionCode = this[revisionCode],
    revisionDate = this[revisionDate],
    lastSyncedAt = this[lastSyncedAt],
    status = BuyerOrderStatus.valueOf(this[status]),
    totalQuantity = this[BuyerOrdersTable.totalQuantity],
    completedQuantity = this[BuyerOrdersTable.completedQuantity],
    summaryBuyerOrderRef = this[BuyerOrdersTable.summaryBuyerOrderRef],
  )
}
