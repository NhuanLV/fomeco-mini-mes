package vn.lgg.mesplus.order.infrastructure.repository

import java.util.*
import org.jetbrains.exposed.v1.core.and
import org.jetbrains.exposed.v1.core.eq
import org.jetbrains.exposed.v1.core.inList
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.upsert
import org.springframework.stereotype.Repository
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PoSkuQuantitiesTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PurchaseOrdersTable
import vn.lgg.mesplus.order.infrastructure.repository.mapping.toPurchaseOrder
import vn.lgg.mesplus.shared.model.SkuQuantity

@Repository
class PgPurchaseOrderRepository : PurchaseOrderRepository {
  override fun findById(id: String): PurchaseOrder? {
    val poRow =
      PurchaseOrdersTable.selectAll()
        .where { PurchaseOrdersTable.id eq UUID.fromString(id) }
        .singleOrNull() ?: return null
    return poRow.toPurchaseOrder()
  }

  override fun findByBuyerOrderId(boId: String): List<PurchaseOrder> {
    val boUuid = UUID.fromString(boId)
    val poRows =
      PurchaseOrdersTable.selectAll().where { PurchaseOrdersTable.boId eq boUuid }.toList()
    return poRows.map { it.toPurchaseOrder() }
  }

  override fun findCodesByIds(ids: List<String>): Map<String, String> {
    if (ids.isEmpty()) return emptyMap()
    val uuids = ids.map { UUID.fromString(it) }
    return PurchaseOrdersTable.selectAll()
      .where { PurchaseOrdersTable.id inList uuids }
      .associate { it[PurchaseOrdersTable.id].value.toString() to it[PurchaseOrdersTable.code] }
  }

  override fun findDestinationsByIds(ids: List<String>): Map<String, String> {
    if (ids.isEmpty()) return emptyMap()
    val uuids = ids.map { UUID.fromString(it) }
    return PurchaseOrdersTable.selectAll()
      .where { PurchaseOrdersTable.id inList uuids }
      .associate { it[PurchaseOrdersTable.id].value.toString() to it[PurchaseOrdersTable.market] }
  }

  override fun saveAll(boId: String, purchaseOrders: List<PurchaseOrder>) {
    val boUuid = UUID.fromString(boId)

    val existingPoIds =
      PurchaseOrdersTable.selectAll()
        .where { (PurchaseOrdersTable.boId eq boUuid) and (PurchaseOrdersTable.type eq PurchaseOrderType.REGULAR.name) }
        .map { it[PurchaseOrdersTable.id].value }
        .toSet()

    val currentPoIds = mutableSetOf<UUID>()

    purchaseOrders.forEach { po ->
      require(po.type == PurchaseOrderType.REGULAR)
      require(po.buyerOrderId == boId)
      val poUuid = UUID.fromString(po.id)
      currentPoIds.add(poUuid)

      PurchaseOrdersTable.upsert(keys = arrayOf(PurchaseOrdersTable.id)) {
        it[PurchaseOrdersTable.id] = poUuid
        it[PurchaseOrdersTable.wfxId] = po.wfxId
        it[code] = po.code
        it[market] = po.destination
        it[deliveryDate] = po.deliveryDate
        it[PurchaseOrdersTable.boId] = boUuid
        it[type] = PurchaseOrderType.REGULAR.name
      }

      PoSkuQuantitiesTable.deleteWhere { PoSkuQuantitiesTable.poId eq poUuid }

      po.skuQties
        .groupBy { it.color to it.size }
        .forEach { (key, group) ->
          val totalQty = group.sumOf { it.quantity }
          if (totalQty > 0) {
            PoSkuQuantitiesTable.insert {
              it[poId] = poUuid
              it[color] = key.first.value
              it[size] = key.second.value
              it[quantity] = totalQty
            }
          }
        }
    }

    val deletedPoIds = existingPoIds - currentPoIds
    deletedPoIds.forEach { deletedId ->
      PoSkuQuantitiesTable.deleteWhere { PoSkuQuantitiesTable.poId eq deletedId }
      // Do not delete from PurchaseOrdersTable to retain historical identity
    }
  }

  override fun save(purchaseOrder: PurchaseOrder) {
    val poUuid = UUID.fromString(purchaseOrder.id)
    PurchaseOrdersTable.insert {
      it[id] = poUuid
      it[wfxId] = purchaseOrder.wfxId
      it[code] = purchaseOrder.code
      it[market] = purchaseOrder.destination
      it[deliveryDate] = purchaseOrder.deliveryDate
      it[boId] = UUID.fromString(purchaseOrder.buyerOrderId)
      it[type] = purchaseOrder.type.name
      it[createdById] = purchaseOrder.createdBy?.id
      it[createdByName] = purchaseOrder.createdBy?.name
      it[createdAt] = purchaseOrder.createdAt
    }
    purchaseOrder.skuQties.forEach { sku ->
      PoSkuQuantitiesTable.insert {
        it[poId] = poUuid
        it[color] = sku.color.value
        it[size] = sku.size.value
        it[quantity] = sku.quantity
      }
    }
  }

  override fun updateSkuQuantities(id: String, quantities: List<SkuQuantity>) {
    val poUuid = UUID.fromString(id)
    PoSkuQuantitiesTable.deleteWhere { PoSkuQuantitiesTable.poId eq poUuid }
    quantities.forEach { sku ->
      PoSkuQuantitiesTable.insert {
        it[poId] = poUuid
        it[color] = sku.color.value
        it[size] = sku.size.value
        it[quantity] = sku.quantity
      }
    }
  }
}
