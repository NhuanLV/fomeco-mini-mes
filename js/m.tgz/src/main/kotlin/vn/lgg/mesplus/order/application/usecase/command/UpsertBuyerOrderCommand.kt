package vn.lgg.mesplus.order.application.usecase.command

import java.time.Instant
import java.time.LocalDate
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size

data class UpsertBuyerOrderCommand(
  val wfxId: String? = null,
  val revisionCode: String? = null,
  val revisionDate: Instant? = null,
  val styleName: String,
  val articleCode: String? = null,
  val summaryBuyerOrderRef: String? = null,
  val purchaseOrders: List<PoItem>,
)

data class PoItem(
  val wfxId: String? = null,
  val code: String,
  val destination: String,
  val deliveryDate: LocalDate,
  val skuQuantities: List<SkuQuantity>,
)

data class SkuQuantity(val color: Color, val size: Size, val quantity: Int)
