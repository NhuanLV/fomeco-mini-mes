package vn.lgg.mesplus.order.application.usecase

import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Propagation
import org.springframework.transaction.annotation.Transactional
import vn.lgg.mesplus.order.domain.model.Style
import vn.lgg.mesplus.order.domain.model.StyleColorOrder
import vn.lgg.mesplus.order.domain.model.StyleSizeOrder
import vn.lgg.mesplus.order.domain.repository.StyleRepository

@Service
class UpsertStyleUseCase(private val styleRepo: StyleRepository) {
  @Transactional(propagation = Propagation.REQUIRES_NEW)
  fun execute(command: UpsertStyleCommand) {
    val existing = styleRepo.findByName(command.styleName)
    if (existing == null) {
      styleRepo.save(
        Style(
          name = command.styleName,
          customer = command.customerName ?: "",
          brand = command.brand ?: "",
          season = command.season ?: "",
          colorOrders = command.colorOrders ?: emptyList(),
          sizeOrders = command.sizeOrders ?: emptyList(),
        )
      )
    } else {
      command.customerName?.let { existing.customer = it }
      command.brand?.let { existing.brand = it }
      command.season?.let { existing.season = it }
      command.colorOrders?.let { existing.colorOrders = it }
      command.sizeOrders?.let { existing.sizeOrders = it }
      styleRepo.save(existing)
    }
  }
}

data class UpsertStyleCommand(
  val styleName: String,
  val customerName: String? = null,
  val brand: String? = null,
  val season: String? = null,
  val colorOrders: List<StyleColorOrder>? = null,
  val sizeOrders: List<StyleSizeOrder>? = null,
)
