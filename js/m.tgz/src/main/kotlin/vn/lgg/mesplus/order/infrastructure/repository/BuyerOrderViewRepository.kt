package vn.lgg.mesplus.order.infrastructure.repository

import org.jetbrains.exposed.v1.core.SortOrder
import org.jetbrains.exposed.v1.core.eq
import org.jetbrains.exposed.v1.core.greaterEq
import org.jetbrains.exposed.v1.core.leftJoin
import org.jetbrains.exposed.v1.core.lessEq
import org.jetbrains.exposed.v1.core.like
import org.jetbrains.exposed.v1.core.max
import org.jetbrains.exposed.v1.core.min
import org.jetbrains.exposed.v1.core.or
import org.jetbrains.exposed.v1.jdbc.Query
import org.jetbrains.exposed.v1.jdbc.andWhere
import org.jetbrains.exposed.v1.jdbc.select
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Repository
import org.springframework.transaction.annotation.Transactional
import vn.lgg.mesplus.order.domain.model.BuyerOrderStatus
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.repository.StyleRepository
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BuyerOrdersTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BuyerOrdersTable.status
import vn.lgg.mesplus.order.infrastructure.repository.exposed.BuyerOrdersTable.styleName
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PurchaseOrdersTable
import vn.lgg.mesplus.order.infrastructure.repository.exposed.PurchaseOrdersTable.deliveryDate
import vn.lgg.mesplus.order.infrastructure.repository.exposed.StylesTable
import vn.lgg.mesplus.order.presentation.controller.request.BuyerOrderFilter
import vn.lgg.mesplus.order.presentation.viewmodel.BuyerOrderFilterOptionsVm
import vn.lgg.mesplus.order.presentation.viewmodel.BuyerOrderListVm

@Repository
class BuyerOrderViewRepository(
  private val styleRepo: StyleRepository,
  private val purchaseOrderRepo: PurchaseOrderRepository,
  private val allocationQueryService: AllocationQueryService,
) {

  @Transactional(readOnly = true)
  fun findAllVm(criteria: BuyerOrderFilter, pageable: Pageable): Page<BuyerOrderListVm> {
    val minDel = deliveryDate.min()
    val maxDel = deliveryDate.max()

    val baseJoin =
      BuyerOrdersTable.leftJoin(StylesTable, { BuyerOrdersTable.styleName }, { StylesTable.name })
        .leftJoin(PurchaseOrdersTable, { BuyerOrdersTable.id }, { PurchaseOrdersTable.boId })

    val totalElements =
      baseJoin
        .select(BuyerOrdersTable.id)
        .applyCriteria(criteria)
        .groupBy(BuyerOrdersTable.id)
        .applyDateFilter(criteria)
        .count()

    if (totalElements == 0L) return PageImpl(emptyList(), pageable, 0L)

    val fetchSlice = BuyerOrdersTable.columns + StylesTable.columns + listOf(minDel, maxDel)

    val query =
      baseJoin
        .select(fetchSlice)
        .applyCriteria(criteria)
        .groupBy(*(BuyerOrdersTable.columns + StylesTable.columns).toTypedArray())
        .applyDateFilter(criteria)

    val sortOrder = pageable.sort.firstOrNull()
    val columnToSort =
      when (sortOrder?.property) {
        "styleName" -> styleName
        "totalQuantity" -> BuyerOrdersTable.totalQuantity
        "completedQuantity" -> BuyerOrdersTable.completedQuantity
        "status" -> status
        "wfxId" -> BuyerOrdersTable.wfxId
        "summaryBuyerOrderRef" -> BuyerOrdersTable.summaryBuyerOrderRef
        "earliestDeliveryDate" -> minDel
        "latestDeliveryDate" -> maxDel
        else -> BuyerOrdersTable.id
      }

    val direction = if (sortOrder?.isDescending == true) SortOrder.DESC else SortOrder.ASC
    query.orderBy(columnToSort to direction)

    val rows = query.limit(pageable.pageSize).offset(pageable.offset).toList()

    val content = rows.map { row ->
      val buyerOrderId = row[BuyerOrdersTable.id].value.toString()
      val purchaseOrders = purchaseOrderRepo.findByBuyerOrderId(buyerOrderId)

      BuyerOrderListVm(
        id = buyerOrderId,
        wfxId = row[BuyerOrdersTable.wfxId] ?: "",
        styleName = row[styleName],
        customer = row.getOrNull(StylesTable.customer) ?: "Unknown",
        brand = row.getOrNull(StylesTable.brand) ?: "Unknown",
        season = row.getOrNull(StylesTable.season) ?: "Unknown",
        status = BuyerOrderStatus.valueOf(row[status]),
        totalQuantity = row[BuyerOrdersTable.totalQuantity],
        completedQuantity = row[BuyerOrdersTable.completedQuantity],
        earliestDeliveryDate = row.getOrNull(minDel),
        latestDeliveryDate = row.getOrNull(maxDel),
        needsAllocationRevision =
          allocationQueryService.needsAllocationRevision(buyerOrderId, purchaseOrders),
        summaryBuyerOrderRef = row[BuyerOrdersTable.summaryBuyerOrderRef],
      )
    }

    return PageImpl(content, pageable, totalElements)
  }

  private fun Query.applyDateFilter(criteria: BuyerOrderFilter): Query {
    criteria.deliveryDateFrom?.let { andWhere { deliveryDate greaterEq it } }
    criteria.deliveryDateTo?.let { andWhere { deliveryDate lessEq it } }
    return this
  }

  @Transactional(readOnly = true)
  fun findFilterOptions(): BuyerOrderFilterOptionsVm {
    val wfxIds =
      BuyerOrdersTable.select(BuyerOrdersTable.wfxId)
        .withDistinct()
        .mapNotNull { it[BuyerOrdersTable.wfxId] }
        .sorted()

    val styleNames =
      BuyerOrdersTable.select(styleName).withDistinct().map { it[styleName] }.sorted()

    val styles = styleRepo.findAll()

    return BuyerOrderFilterOptionsVm(
      wfxIds = wfxIds,
      customers = styles.map { it.customer }.filter { it.isNotBlank() }.distinct().sorted(),
      brands = styles.map { it.brand }.filter { it.isNotBlank() }.distinct().sorted(),
      seasons = styles.map { it.season }.filter { it.isNotBlank() }.distinct().sorted(),
      styles = styleNames,
      statuses = BuyerOrderStatus.entries.map { it.name }.sorted(),
    )
  }

  private fun Query.applyCriteria(criteria: BuyerOrderFilter): Query {
    criteria.wfxId?.takeIf { it.isNotBlank() }?.let { andWhere { BuyerOrdersTable.wfxId eq it } }
    criteria.style?.takeIf { it.isNotBlank() }?.let { andWhere { styleName eq it } }
    criteria.customer?.takeIf { it.isNotBlank() }?.let { andWhere { StylesTable.customer eq it } }
    criteria.brand?.takeIf { it.isNotBlank() }?.let { andWhere { StylesTable.brand eq it } }
    criteria.season?.takeIf { it.isNotBlank() }?.let { andWhere { StylesTable.season eq it } }
    criteria.status?.takeIf { it.isNotBlank() }?.let { andWhere { status eq it } }

    criteria.search
      ?.takeIf { it.isNotBlank() }
      ?.let { s ->
        andWhere {
          (BuyerOrdersTable.wfxId like "%$s%") or
            (BuyerOrdersTable.summaryBuyerOrderRef like "%$s%") or
            (styleName like "%$s%") or
            (StylesTable.customer like "%$s%")
        }
      }
    return this
  }
}
