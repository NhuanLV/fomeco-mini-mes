package vn.lgg.mesplus.order.application.eventhandler

import org.springframework.context.event.EventListener
import org.springframework.scheduling.annotation.Async
import org.springframework.stereotype.Component
import vn.lgg.mesplus.production.application.usecase.UpdateBuyerOrderStatusUseCase
import vn.lgg.mesplus.production.domain.event.LastReportDeleted
import vn.lgg.mesplus.production.domain.event.LastReportUpdated
import vn.lgg.mesplus.production.domain.event.ProductionOrderIssued
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.PurchaseOrderQuantityAdjusted
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.event.TeamAssignmentEvent
import vn.lgg.mesplus.production.infrastructure.repository.TeamAssignmentStatusLookupRepository
import vn.lgg.mesplus.shared.DomainEventSubscriber
import vn.lgg.mesplus.production.domain.event.TeamAssignmentAllocationRevised

@Component
class OnProductionOrderIssued(
  private val updateBuyerOrderStatusUseCase: UpdateBuyerOrderStatusUseCase
) : DomainEventSubscriber<ProductionOrderIssued> {

  @EventListener
  @Async
  override fun handle(event: ProductionOrderIssued) {
    updateBuyerOrderStatusUseCase.execute(event.buyerOrderId)
  }
}

@Component
class UpdateBoStatusHandler(
  private val updateBuyerOrderStatusUseCase: UpdateBuyerOrderStatusUseCase,
  private val statusLookupRepository: TeamAssignmentStatusLookupRepository,
) : DomainEventSubscriber<TeamAssignmentEvent> {

  @EventListener
  @Async
  override fun handle(event: TeamAssignmentEvent) {
    when (event) {
      is TeamAssignmentCreated -> return
      is TeamAssignmentAllocationRevised,
      is PurchaseOrderQuantityAdjusted,
      is ProgressReported,
      is LastReportUpdated,
      is LastReportDeleted -> recalculateBuyerOrderStatus(event.assignmentId)
    }
  }

  private fun recalculateBuyerOrderStatus(assignmentId: String) {
    val refs = statusLookupRepository.findOrderRefsByAssignmentId(assignmentId) ?: return
    updateBuyerOrderStatusUseCase.execute(refs.buyerOrderId)
  }
}
