ALTER TABLE buyer_orders ADD COLUMN IF NOT EXISTS summary_buyer_order_ref TEXT;
