-- IAM + Organization schema
-- Roles
CREATE TABLE IF NOT EXISTS roles (
    id UUID NOT NULL,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    is_system BOOLEAN NOT NULL,
    CONSTRAINT pk_roles PRIMARY KEY (id)
);

-- Role Permissions
CREATE TABLE IF NOT EXISTS role_permissions (
    role_id UUID NOT NULL,
    permission TEXT NOT NULL,
    CONSTRAINT pk_role_permissions PRIMARY KEY (role_id, permission)
);

-- Accounts
CREATE TABLE IF NOT EXISTS accounts (
    id UUID NOT NULL,
    name TEXT NOT NULL,
    username TEXT NOT NULL,
    password TEXT NOT NULL,
    CONSTRAINT pk_accounts PRIMARY KEY (id),
    CONSTRAINT uq_accounts_username UNIQUE (username)
);

-- Unit Membership (account_roles)
CREATE TABLE IF NOT EXISTS account_roles (
    account_id UUID NOT NULL,
    unit_id UUID NOT NULL,
    role_id UUID NOT NULL,
    CONSTRAINT pk_account_roles PRIMARY KEY (account_id, unit_id, role_id)
);
CREATE INDEX IF NOT EXISTS idx_account_roles_account_id ON account_roles (account_id);
CREATE INDEX IF NOT EXISTS idx_account_roles_unit_id ON account_roles (unit_id);

-- Org Units
CREATE TABLE IF NOT EXISTS org_units (
    id UUID NOT NULL,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    code TEXT NOT NULL,
    parent_id UUID,
    address TEXT,
    is_active BOOLEAN NOT NULL,
    classification TEXT NOT NULL,
    wfx_id TEXT,
    wfx_supplier_name TEXT,
    CONSTRAINT pk_org_units PRIMARY KEY (id),
    CONSTRAINT uq_org_units_code UNIQUE (code)
);

-- Unit Operations
CREATE TABLE IF NOT EXISTS unit_operations (
    unit_id UUID NOT NULL,
    operation TEXT NOT NULL,
    CONSTRAINT pk_unit_operations PRIMARY KEY (unit_id, operation)
);

-- Operations
CREATE TABLE IF NOT EXISTS operations (
    name TEXT NOT NULL,
    CONSTRAINT pk_operations PRIMARY KEY (name)
);

-- Operations mapping for a company
CREATE TABLE IF NOT EXISTS company_operations (
    id UUID NOT NULL,
    company_id UUID NOT NULL,
    operation_code TEXT NOT NULL,
    operation_name TEXT NOT NULL,
    material_dispatch_site TEXT,
    btp_dispatch_site TEXT,
    btp_receive_site TEXT,
    is_active BOOLEAN NOT NULL,
    CONSTRAINT pk_company_operations PRIMARY KEY (id),
    CONSTRAINT fk_company_operations_company_id FOREIGN KEY (company_id) REFERENCES org_units(id),
    CONSTRAINT uq_company_operations_company_operation UNIQUE (company_id, operation_code)
);

-- Suppliers data from wfx
CREATE TABLE IF NOT EXISTS wfx_suppliers (
    name TEXT NOT NULL,
    CONSTRAINT pk_wfx_suppliers PRIMARY KEY (name)
);
