-- Event store
CREATE TABLE return_request_events (
    id                 BIGSERIAL   PRIMARY KEY,
    return_request_id  UUID        NOT NULL,
    payload            JSONB       NOT NULL,
    occurred_at        TIMESTAMPTZ NOT NULL,
    version            INT         NOT NULL
);
CREATE INDEX ON return_request_events (return_request_id);

-- View: header
CREATE TABLE return_request_view (
    id                 UUID        PRIMARY KEY,
    return_code        TEXT        NOT NULL,
    team_assignment_id UUID        NOT NULL,
    status             TEXT        NOT NULL, -- PENDING_APPROVAL, APPROVED, REJECTED, COMPLETED
    created_at         TIMESTAMPTZ NOT NULL,
    created_by_id      TEXT        NOT NULL,
    created_by_name    TEXT        NOT NULL,
    reject_reason      TEXT        NULL
);
CREATE INDEX ON return_request_view (team_assignment_id);

-- View: items
CREATE TABLE return_request_item_view (
    return_request_id  UUID          NOT NULL REFERENCES return_request_view(id),
    article            TEXT          NOT NULL,
    color              TEXT          NOT NULL,
    size               TEXT          NOT NULL,
    uom                TEXT          NOT NULL DEFAULT '',
    quantity           NUMERIC(12,4) NOT NULL,
    receiver_id        TEXT          NOT NULL,
    receiver_name      TEXT          NOT NULL,
    PRIMARY KEY (return_request_id, receiver_id, article, color, size)
);

-- Assignment Events
CREATE TABLE return_request_assignment_events (
    id                 BIGSERIAL   PRIMARY KEY,
    return_request_id  UUID        NOT NULL,
    receiver_id        TEXT        NOT NULL,
    payload            JSONB       NOT NULL,
    occurred_at        TIMESTAMPTZ NOT NULL,
    version            INT         NOT NULL
);
CREATE INDEX ON return_request_assignment_events (return_request_id, receiver_id);

-- Assignment View
CREATE TABLE return_request_assignment_view (
    return_request_id  UUID        NOT NULL,
    receiver_id        TEXT        NOT NULL,
    receiver_name      TEXT        NOT NULL,
    status             TEXT        NOT NULL,
    PRIMARY KEY (return_request_id, receiver_id)
);

-- Assignment Items View
CREATE TABLE return_request_assignment_item_view (
    return_request_id  UUID          NOT NULL,
    receiver_id        TEXT          NOT NULL,
    article            TEXT          NOT NULL,
    color              TEXT          NOT NULL,
    size               TEXT          NOT NULL,
    uom                TEXT          NOT NULL DEFAULT '',
    quantity           NUMERIC(12,4) NOT NULL,
    received           BOOLEAN       NOT NULL DEFAULT FALSE,
    PRIMARY KEY (return_request_id, receiver_id, article, color, size)
);
