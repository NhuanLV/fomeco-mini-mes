-- Seed minimal admin data: system role, corporation org unit, admin account

-- Admin role (system)
INSERT INTO roles (id, name, description, is_system)
VALUES ('ffffffff-ffff-ffff-ffff-ffffffffffff', 'Super Admin', 'Kiểm soát truy cập', true)
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions (role_id, permission)
VALUES ('ffffffff-ffff-ffff-ffff-ffffffffffff', 'MANAGE_ACCOUNT'),
       ('ffffffff-ffff-ffff-ffff-ffffffffffff', 'MANAGE_ORG')
ON CONFLICT DO NOTHING;

-- Corporation org unit
INSERT INTO org_units (id, name, type, code, parent_id, address, is_active, classification, wfx_id)
VALUES ('00000000-0000-0000-0000-000000000000', 'Tổng Công Ty LGG', 'CORPORATION', 'LGG-CORP', NULL, NULL, true, 'INHOUSE', NULL)
ON CONFLICT DO NOTHING;

-- Admin account (password = bcrypt hash of "1234")
INSERT INTO accounts (id, name, username, password)
VALUES ('11111111-1111-1111-1111-111111111111', 'Admin', 'admin',
        '$2a$12$6NrEtmJ7g5ftTfdCxz7PPOT7/ddXbN0q5nbbYKkX6VRwRWSX3tz.q')
ON CONFLICT DO NOTHING;

-- Admin unit membership
INSERT INTO account_roles (account_id, unit_id, role_id)
VALUES ('11111111-1111-1111-1111-111111111111', '00000000-0000-0000-0000-000000000000',
        'ffffffff-ffff-ffff-ffff-ffffffffffff')
ON CONFLICT DO NOTHING;
