ALTER TABLE purchase_orders
    ADD COLUMN IF NOT EXISTS type TEXT NOT NULL DEFAULT 'REGULAR',
    ADD COLUMN IF NOT EXISTS created_by_id TEXT,
    ADD COLUMN IF NOT EXISTS created_by_name TEXT,
    ADD COLUMN IF NOT EXISTS created_at TIMESTAMP;

DELETE FROM po_sku_quantities
WHERE po_id IN (
    SELECT id FROM (
        SELECT id, ROW_NUMBER() OVER (PARTITION BY bo_id, code ORDER BY id) AS rn
        FROM purchase_orders
    ) duplicates
    WHERE rn > 1
);

DELETE FROM purchase_orders
WHERE id IN (
    SELECT id FROM (
        SELECT id, ROW_NUMBER() OVER (PARTITION BY bo_id, code ORDER BY id) AS rn
        FROM purchase_orders
    ) duplicates
    WHERE rn > 1
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_purchase_orders_bo_code ON purchase_orders (bo_id, code);
