-- Add completed_at to production_orders
ALTER TABLE production_orders ADD COLUMN IF NOT EXISTS completed_at TIMESTAMP;
