-- Legacy parts keep NULL and fall back to the shared item note. No backfill.
ALTER TABLE kanban_item_part_view ADD COLUMN supplier_note text;
