-- Transfer Request Events
CREATE TABLE transfer_request_events (
    id                       BIGSERIAL   PRIMARY KEY,
    transfer_request_id      UUID        NOT NULL,
    payload                  JSONB       NOT NULL,
    occurred_at              TIMESTAMPTZ NOT NULL,
    version                  INT         NOT NULL
);
CREATE INDEX ON transfer_request_events (transfer_request_id);

-- Transfer Request View
CREATE TABLE transfer_request_view (
    id                        UUID        PRIMARY KEY,
    transfer_code             TEXT        NOT NULL,
    source_team_assignment_id UUID        NOT NULL,
    status                    TEXT        NOT NULL,
    created_at                TIMESTAMPTZ NOT NULL,
    created_by_id             TEXT        NOT NULL,
    created_by_name           TEXT        NOT NULL,
    reject_reason             TEXT        NULL
);
CREATE INDEX ON transfer_request_view (source_team_assignment_id);

-- Transfer Request Items View
CREATE TABLE transfer_request_item_view (
    transfer_request_id       UUID          NOT NULL REFERENCES transfer_request_view(id),
    target_team_assignment_id UUID          NOT NULL,
    target_team_name          TEXT          NOT NULL,
    article                   TEXT          NOT NULL,
    color                     TEXT          NOT NULL,
    size                      TEXT          NOT NULL,
    uom                       TEXT          NOT NULL DEFAULT '',
    quantity                  NUMERIC(12,4) NOT NULL,
    PRIMARY KEY (transfer_request_id, target_team_assignment_id, article, color, size)
);

-- Transfer Request Assignment Events
CREATE TABLE transfer_request_assignment_events (
    id                        BIGSERIAL   PRIMARY KEY,
    transfer_request_id       UUID        NOT NULL,
    target_team_assignment_id UUID        NOT NULL,
    payload                   JSONB       NOT NULL,
    occurred_at               TIMESTAMPTZ NOT NULL,
    version                   INT         NOT NULL
);
CREATE INDEX ON transfer_request_assignment_events (transfer_request_id, target_team_assignment_id);

-- Transfer Request Assignment View
CREATE TABLE transfer_request_assignment_view (
    transfer_request_id       UUID        NOT NULL,
    target_team_assignment_id UUID        NOT NULL,
    target_team_name          TEXT        NOT NULL,
    status                    TEXT        NOT NULL,
    PRIMARY KEY (transfer_request_id, target_team_assignment_id)
);

-- Transfer Request Assignment Items View
CREATE TABLE transfer_request_assignment_item_view (
    transfer_request_id       UUID          NOT NULL,
    target_team_assignment_id UUID          NOT NULL,
    article                   TEXT          NOT NULL,
    color                     TEXT          NOT NULL,
    size                      TEXT          NOT NULL,
    uom                       TEXT          NOT NULL DEFAULT '',
    quantity                  NUMERIC(12,4) NOT NULL,
    received                  BOOLEAN       NOT NULL DEFAULT FALSE,
    PRIMARY KEY (transfer_request_id, target_team_assignment_id, article, color, size)
);
