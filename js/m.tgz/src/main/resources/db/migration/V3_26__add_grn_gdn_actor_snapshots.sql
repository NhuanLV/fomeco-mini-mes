ALTER TABLE team_assignment_report_grns ADD COLUMN reported_by JSONB;
ALTER TABLE kanban_gdns ADD COLUMN received_by JSONB;
