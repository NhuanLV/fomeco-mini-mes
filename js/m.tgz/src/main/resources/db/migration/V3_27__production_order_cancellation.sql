ALTER TABLE production_orders
    ADD COLUMN cancelled_at timestamptz,
    ADD COLUMN cancelled_by text,
    ADD COLUMN cancellation_reason text;

-- Preserve the order in which cancellation requests were accepted.
ALTER TABLE production_order_activity_log ADD COLUMN request_sequence bigserial;
CREATE INDEX production_order_activity_request_idx
    ON production_order_activity_log (production_order_id, request_sequence DESC);
