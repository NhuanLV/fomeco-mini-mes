-- Old events contain no role or WFX result; leave those snapshots unknown.
WITH sources AS (
    SELECT DISTINCT ON (payload ->> 'productionOrderId')
           payload ->> 'productionOrderId' AS production_order_id, id, payload, occurred_at
    FROM team_assignment_events
    WHERE payload ->> 'eventName' = 'TeamAssignmentCreated'
    ORDER BY payload ->> 'productionOrderId', occurred_at, id
)
INSERT INTO production_order_activity_log (id, production_order_id, activity_type, actor, occurred_at, source_event_id)
SELECT md5('production-order-create:' || po.id::text)::uuid, po.id, 'CREATE',
       NULLIF(source.payload -> 'actor', 'null'::jsonb),
       COALESCE(source.occurred_at, po.created_at AT TIME ZONE 'UTC'), source.id
FROM production_orders po
LEFT JOIN sources source ON source.production_order_id = po.id::text
WHERE NOT EXISTS (
    SELECT 1 FROM production_order_activity_log activity
    WHERE activity.production_order_id = po.id AND activity.activity_type = 'CREATE'
)
ON CONFLICT DO NOTHING;
