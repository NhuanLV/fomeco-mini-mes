CREATE TABLE wfx_fpos (
    fpo_num TEXT PRIMARY KEY,
    buyer_order_id TEXT NOT NULL,
    main_company_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'RELEASED',
    released_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_wfx_fpos_bo_company ON wfx_fpos (buyer_order_id, main_company_code);

CREATE TABLE wfx_fppos (
    fppo_num TEXT PRIMARY KEY,
    fpo_num TEXT NOT NULL,
    process_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'RELEASED',
    released_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_wfx_fppos_fpo ON wfx_fppos (fpo_num);
