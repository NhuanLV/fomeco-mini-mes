-- Before BTP had its own inventory, Kanban receipts also entered Material Inventory.
-- V3_20 has copied those receipts to BTP Inventory; remove only the matching legacy entries.
CREATE TEMP TABLE _legacy_btp_receipts ON COMMIT DROP AS
SELECT DISTINCT team_assignment_id,
       payload->'sku'->>'article' AS article,
       payload->'sku'->>'color' AS color,
       payload->'sku'->>'size' AS size,
       split_part(payload->>'referenceId', ':', 1) AS kanban_id
FROM btp_inventory_events
WHERE payload->>'eventName' = 'BtpKanbanReceived';

-- Do not leave other historical BTP movements hidden in the NPL ledger.
DO $$
DECLARE problem TEXT;
BEGIN
    SELECT format('Material Inventory event %s, %s (%s/%s), reference %s',
                  e.id, line.item->>'article', line.item->>'color', line.item->>'size', e.payload->>'referenceId')
    INTO problem
    FROM inventory_events e
    CROSS JOIN LATERAL jsonb_array_elements(COALESCE(e.payload->'items', '[]'::jsonb)) AS line(item)
    WHERE line.item->>'article' LIKE 'BTP %'
      AND NOT (e.payload->>'eventName' = 'InventoryMaterialReceived' AND EXISTS (
          SELECT 1 FROM _legacy_btp_receipts b
          WHERE b.team_assignment_id = e.team_assignment_id
            AND b.kanban_id = e.payload->>'referenceId'
            AND b.article = line.item->>'article'
            AND b.color = line.item->>'color'
            AND b.size = line.item->>'size'
      ))
    LIMIT 1;
    IF problem IS NOT NULL THEN
        RAISE EXCEPTION 'Unmatched historical BTP in Material Inventory: %', problem;
    END IF;
END $$;

UPDATE inventory_events e
SET payload = jsonb_set(
    e.payload,
    '{items}',
    (SELECT COALESCE(jsonb_agg(line.item ORDER BY line.ordinality), '[]'::jsonb)
     FROM jsonb_array_elements(e.payload->'items') WITH ORDINALITY AS line(item, ordinality)
     WHERE NOT EXISTS (
         SELECT 1 FROM _legacy_btp_receipts b
         WHERE b.team_assignment_id = e.team_assignment_id
           AND b.kanban_id = e.payload->>'referenceId'
           AND b.article = line.item->>'article'
           AND b.color = line.item->>'color'
           AND b.size = line.item->>'size'
     )),
    false
)
WHERE e.payload->>'eventName' = 'InventoryMaterialReceived'
  AND EXISTS (
      SELECT 1
      FROM jsonb_array_elements(e.payload->'items') AS line(item)
      JOIN _legacy_btp_receipts b
        ON b.team_assignment_id = e.team_assignment_id
       AND b.kanban_id = e.payload->>'referenceId'
       AND b.article = line.item->>'article'
       AND b.color = line.item->>'color'
       AND b.size = line.item->>'size'
  );

DELETE FROM inventory_transaction_view t
USING _legacy_btp_receipts b
WHERE t.team_assignment_id = b.team_assignment_id
  AND t.reference_id = b.kanban_id
  AND t.article = b.article
  AND t.color = b.color
  AND t.size = b.size
  AND t.transaction_type = 'RECEIVED';

DELETE FROM inventory_balance_view balance
USING _legacy_btp_receipts b
WHERE balance.team_assignment_id = b.team_assignment_id
  AND balance.article = b.article
  AND balance.color = b.color
  AND balance.size = b.size;

INSERT INTO inventory_balance_view
    (team_assignment_id, article, color, size, uom, total_received, total_issued, balance)
SELECT t.team_assignment_id, t.article, t.color, t.size, MAX(t.uom),
       COALESCE(SUM(t.quantity) FILTER (WHERE t.transaction_type = 'RECEIVED'), 0),
       COALESCE(SUM(t.quantity) FILTER (WHERE t.transaction_type = 'ISSUED'), 0),
       SUM(CASE WHEN t.transaction_type = 'RECEIVED' THEN t.quantity ELSE -t.quantity END)
FROM inventory_transaction_view t
WHERE EXISTS (
    SELECT 1 FROM _legacy_btp_receipts b
    WHERE b.team_assignment_id = t.team_assignment_id
      AND b.article = t.article AND b.color = t.color AND b.size = t.size
)
GROUP BY t.team_assignment_id, t.article, t.color, t.size;

DO $$
DECLARE problem TEXT;
BEGIN
    SELECT format('transaction %s, %s', id, article) INTO problem
    FROM inventory_transaction_view WHERE article LIKE 'BTP %' LIMIT 1;
    IF problem IS NOT NULL THEN
        RAISE EXCEPTION 'BTP transaction remains in Material Inventory: %', problem;
    END IF;

    SELECT format('Team Assignment %s, %s', team_assignment_id, article) INTO problem
    FROM inventory_balance_view WHERE article LIKE 'BTP %' LIMIT 1;
    IF problem IS NOT NULL THEN
        RAISE EXCEPTION 'BTP balance remains in Material Inventory: %', problem;
    END IF;
END $$;
