-- Event store for Inventory
CREATE TABLE inventory_events (
    id                 BIGSERIAL   PRIMARY KEY,
    team_assignment_id UUID        NOT NULL,
    payload            JSONB       NOT NULL,
    occurred_at        TIMESTAMPTZ NOT NULL,
    version            INT         NOT NULL
);
CREATE INDEX ON inventory_events (team_assignment_id);

-- Read-model: detailed transaction history
CREATE TABLE inventory_transaction_view (
    id                 UUID        PRIMARY KEY,
    team_assignment_id UUID        NOT NULL,
    article            TEXT        NOT NULL,
    color              TEXT        NOT NULL,
    size               TEXT        NOT NULL,
    uom                TEXT        NOT NULL DEFAULT '',
    transaction_type   TEXT        NOT NULL, -- 'RECEIVED' or 'ISSUED'
    transaction_category VARCHAR(100) NULL,
    quantity           NUMERIC(12,4) NOT NULL,
    reference_id       TEXT        NULL, -- kanban_id, return_request_id, transfer_request_id
    counterparty_name  TEXT        NULL,
    occurred_at        TIMESTAMPTZ NOT NULL
);
CREATE INDEX ON inventory_transaction_view (team_assignment_id, article, color, size);
CREATE INDEX ON inventory_transaction_view (occurred_at);

-- Read-model: current balance
CREATE TABLE inventory_balance_view (
    team_assignment_id UUID          NOT NULL,
    article            TEXT          NOT NULL,
    color              TEXT          NOT NULL,
    size               TEXT          NOT NULL,
    uom                TEXT          NOT NULL DEFAULT '',
    total_received     NUMERIC(12,4) NOT NULL DEFAULT 0,
    total_issued       NUMERIC(12,4) NOT NULL DEFAULT 0,
    balance            NUMERIC(12,4) NOT NULL DEFAULT 0,
    PRIMARY KEY (team_assignment_id, article, color, size)
);
