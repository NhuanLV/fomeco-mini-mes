-- Legacy lines keep NULL; new BTP lines snapshot their PO type. No history backfill.
ALTER TABLE kanban_item_part_view ADD COLUMN purchase_order_type text;
