-- Notification schema
CREATE TABLE notifications (
    id UUID NOT NULL,
    recipient_id UUID NOT NULL,
    actor_id TEXT,
    actor_name TEXT,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL,
    CONSTRAINT pk_notifications PRIMARY KEY (id),
    CONSTRAINT ck_notifications_actor_snapshot
        CHECK ((actor_id IS NULL) = (actor_name IS NULL))
);

CREATE INDEX idx_notifications_recipient_created
    ON notifications (recipient_id, created_at DESC, id DESC);

CREATE INDEX idx_notifications_recipient_unread_created
    ON notifications (recipient_id, is_read, created_at DESC, id DESC);
