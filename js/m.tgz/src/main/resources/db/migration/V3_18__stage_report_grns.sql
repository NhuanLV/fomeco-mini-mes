ALTER TABLE team_assignment_report_grns
    ADD COLUMN report_snapshot JSONB NOT NULL DEFAULT '[]'::JSONB,
    ADD COLUMN cancelled_by UUID,
    ADD COLUMN cancelled_at TIMESTAMPTZ;
