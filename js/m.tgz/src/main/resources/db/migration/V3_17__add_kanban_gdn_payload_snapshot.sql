ALTER TABLE kanban_gdns
    ADD COLUMN payload_snapshot JSONB NOT NULL DEFAULT '[]'::jsonb;
