CREATE TABLE production_order_activity_log (
    id UUID PRIMARY KEY,
    production_order_id UUID NOT NULL REFERENCES production_orders(id),
    activity_type TEXT NOT NULL,
    actor JSONB,
    occurred_at TIMESTAMPTZ NOT NULL,
    note TEXT,
    changes JSONB NOT NULL DEFAULT '[]',
    sync_status TEXT,
    sync_message TEXT,
    sync_attempted_at TIMESTAMPTZ,
    source_event_id BIGINT REFERENCES team_assignment_events(id)
);

CREATE INDEX idx_production_order_activity_order ON production_order_activity_log(production_order_id, occurred_at DESC, id DESC);
CREATE UNIQUE INDEX ux_production_order_activity_create ON production_order_activity_log(production_order_id) WHERE activity_type = 'CREATE';
