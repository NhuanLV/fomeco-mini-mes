-- WFX Master Data schema

CREATE TABLE IF NOT EXISTS wfx_articles (
    id TEXT NOT NULL,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    uom TEXT NOT NULL,
    CONSTRAINT pk_wfx_articles PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS wfx_colors (
    id TEXT NOT NULL,
    code TEXT NOT NULL,
    "desc" TEXT NOT NULL,
    CONSTRAINT pk_wfx_colors PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS wfx_sizes (
    id TEXT NOT NULL,
    code TEXT NOT NULL,
    "desc" TEXT NOT NULL,
    CONSTRAINT pk_wfx_sizes PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS wfx_countries (
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    CONSTRAINT pk_wfx_countries PRIMARY KEY (code)
);
