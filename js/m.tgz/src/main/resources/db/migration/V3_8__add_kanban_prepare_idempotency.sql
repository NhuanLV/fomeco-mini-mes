CREATE TABLE kanban_prepare_idempotency_keys (
    kanban_id       UUID        NOT NULL,
    supplier_unit_id TEXT       NOT NULL,
    idempotency_key UUID        NOT NULL,
    PRIMARY KEY (kanban_id, supplier_unit_id, idempotency_key)
);
