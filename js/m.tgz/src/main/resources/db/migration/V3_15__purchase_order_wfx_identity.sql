DROP INDEX IF EXISTS uq_purchase_orders_bo_code;

CREATE UNIQUE INDEX uq_purchase_orders_bo_wfx_id
    ON purchase_orders (bo_id, wfx_id)
    WHERE type = 'REGULAR';
