-- Team BOM persistence must not depend on the asynchronous assignment projection.
ALTER TABLE team_bom_lines
    DROP CONSTRAINT fk_team_bom_lines_team_assignment_id;
