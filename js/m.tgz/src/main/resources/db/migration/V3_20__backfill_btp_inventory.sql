-- PostgreSQL/Flyway runs this migration in one transaction. Any exception rolls it all back.
CREATE TEMP TABLE _btp_backfill_events (
    source_event_id BIGINT NOT NULL,
    item_ordinal BIGINT NOT NULL,
    priority INT NOT NULL,
    team_assignment_id UUID NOT NULL,
    event_type TEXT NOT NULL,
    article TEXT NOT NULL,
    color TEXT NOT NULL,
    size TEXT NOT NULL,
    quantity NUMERIC NOT NULL,
    reference_id TEXT NOT NULL,
    counterparty_id TEXT,
    actor_id TEXT,
    actor_name TEXT,
    occurred_at TIMESTAMPTZ NOT NULL
) ON COMMIT DROP;

-- ProgressReported is the source of truth. Legacy versions persisted OUTPUT before GRN sync,
-- so a valid historical OUTPUT can have a FAILED GRN.
DO $$
DECLARE problem TEXT;
BEGIN
    SELECT format('OUTPUT %s of Team Assignment %s has no assignment or items', e.id, e.assignment_id)
    INTO problem
    FROM team_assignment_events e
    LEFT JOIN team_assignments ta ON ta.id = e.assignment_id
    WHERE e.payload->>'eventName' = 'ProgressReported'
      AND COALESCE(e.payload->>'type', 'OUTPUT') = 'OUTPUT'
      AND (ta.id IS NULL OR jsonb_array_length(COALESCE(e.payload->'items', '[]'::jsonb)) = 0)
    LIMIT 1;
    IF problem IS NOT NULL THEN RAISE EXCEPTION '%', problem; END IF;

END $$;

INSERT INTO _btp_backfill_events
    (source_event_id, item_ordinal, priority, team_assignment_id, event_type, article,
     color, size, quantity, reference_id, actor_id, actor_name, occurred_at)
SELECT e.id, 1, 0, e.assignment_id, 'PRODUCED', 'BTP ' || ta.operation,
       item->>'color', item->>'size', SUM((item->>'quantity')::numeric),
       e.assignment_id::text || ':' || (e.payload->>'occurredAt'),
       e.payload->'actor'->>'id', e.payload->'actor'->>'name', e.occurred_at
FROM team_assignment_events e
JOIN team_assignments ta ON ta.id = e.assignment_id
LEFT JOIN LATERAL (
    SELECT u.payload->'items' AS items
    FROM team_assignment_events u
    WHERE u.assignment_id = e.assignment_id
      AND u.version > e.version
      AND u.payload->>'eventName' = 'LastReportUpdated'
      AND u.payload->>'targetReportedAt' = e.payload->>'occurredAt'
    ORDER BY u.version DESC
    LIMIT 1
) updated ON true
CROSS JOIN LATERAL jsonb_array_elements(COALESCE(updated.items, e.payload->'items')) AS report_item(item)
WHERE e.payload->>'eventName' = 'ProgressReported'
  AND COALESCE(e.payload->>'type', 'OUTPUT') = 'OUTPUT'
  AND NOT EXISTS (
      SELECT 1 FROM team_assignment_events d
      WHERE d.assignment_id = e.assignment_id AND d.version > e.version
        AND d.payload->>'eventName' = 'LastReportDeleted'
        AND d.payload->>'targetReportedAt' = e.payload->>'occurredAt'
  )
GROUP BY e.id, e.assignment_id, ta.operation, item->>'color', item->>'size',
         e.payload->>'occurredAt', e.payload->'actor'->>'id', e.payload->'actor'->>'name', e.occurred_at;

CREATE TEMP TABLE _btp_backfill_kanban ON COMMIT DROP AS
WITH raw AS (
    SELECT e.id AS source_event_id, item_ordinal, e.kanban_id, e.supplier_unit_id,
           e.payload->>'eventName' AS event_name, item->>'article' AS article,
           item->>'color' AS color, item->>'size' AS size, item->>'poId' AS po_id,
           (item->>'qty')::numeric AS quantity,
           e.payload->'actor'->>'id' AS actor_id,
           e.payload->'actor'->>'name' AS actor_name, e.occurred_at
    FROM kanban_assignment_events e
    CROSS JOIN LATERAL jsonb_array_elements(e.payload->'items') WITH ORDINALITY AS items(item, item_ordinal)
    WHERE e.payload->>'eventName' IN ('KanbanMaterialIssued', 'KanbanMaterialReceived')
)
SELECT raw.*, (raw.article LIKE 'BTP %' OR matched.btp_count > 0) AS is_btp,
       matched.btp_count, target.id AS target_id, source.source_count, source.source_id
FROM raw
LEFT JOIN LATERAL (
    SELECT k.payload
    FROM kanban_events k
    WHERE k.kanban_id = raw.kanban_id AND k.payload->>'eventName' = 'KanbanCreated'
    ORDER BY k.id LIMIT 1
) created ON true
LEFT JOIN LATERAL (
    SELECT COUNT(*) FILTER (WHERE line->>'type' = 'SEMI_FINISHED_PRODUCT') AS btp_count
    FROM jsonb_array_elements(COALESCE(created.payload->'items', '[]'::jsonb)) AS lines(line)
    WHERE line->>'article' = raw.article AND line->>'color' = raw.color
      AND line->>'size' = raw.size AND line->>'purchaseOrderId' IS NOT DISTINCT FROM raw.po_id
      AND line->>'supplierUnitId' = raw.supplier_unit_id
) matched ON true
LEFT JOIN team_assignments target ON target.id = CASE
    WHEN raw.article LIKE 'BTP %' OR matched.btp_count > 0
    THEN (created.payload->>'teamAssignmentId')::uuid ELSE NULL END
LEFT JOIN production_orders po ON po.id = target.production_order_id
LEFT JOIN LATERAL (
    SELECT po.routing::jsonb ->> (route.ordinality::int - 2) AS operation
    FROM jsonb_array_elements_text(COALESCE(po.routing::jsonb, '[]'::jsonb))
         WITH ORDINALITY AS route(operation, ordinality)
    WHERE route.operation = target.operation AND route.ordinality > 1
) previous_operation ON true
LEFT JOIN LATERAL (
    SELECT COUNT(DISTINCT upstream.id) AS source_count, MAX(upstream.id::text)::uuid AS source_id
    FROM team_assignments upstream
    JOIN sku_allocations allocation ON allocation.team_assignment_id = upstream.id
    JOIN sku_allocations target_allocation
      ON target_allocation.team_assignment_id = target.id
     AND target_allocation.purchase_order_id = allocation.purchase_order_id
     AND target_allocation.color = allocation.color AND target_allocation.size = allocation.size
    WHERE upstream.production_order_id = target.production_order_id
      AND upstream.team_id::text = raw.supplier_unit_id
      AND upstream.operation = previous_operation.operation
      AND (raw.po_id IS NULL OR allocation.purchase_order_id::text = raw.po_id)
      AND allocation.color = raw.color AND allocation.size = raw.size
) source ON true;

DO $$
DECLARE problem TEXT;
BEGIN
    SELECT format('Kanban event %s item %s has missing article/color/size/quantity', source_event_id, item_ordinal)
    INTO problem
    FROM _btp_backfill_kanban
    WHERE article IS NULL OR color IS NULL OR size IS NULL OR quantity IS NULL
    LIMIT 1;
    IF problem IS NOT NULL THEN RAISE EXCEPTION 'BTP backfill invalid event: %', problem; END IF;

    SELECT format('Kanban %s event %s item %s (%s/%s, PO %s): BTP line matches %s, source assignments %s, target %s',
                  kanban_id, source_event_id, article, color, size, po_id,
                  btp_count, source_count, target_id)
    INTO problem
    FROM _btp_backfill_kanban
    WHERE is_btp AND (btp_count <> 1 OR source_count <> 1 OR target_id IS NULL OR quantity IS NULL OR quantity <= 0)
    ORDER BY source_event_id, item_ordinal
    LIMIT 1;
    IF problem IS NOT NULL THEN RAISE EXCEPTION 'BTP backfill unresolved: %', problem; END IF;
END $$;

INSERT INTO _btp_backfill_events
    (source_event_id, item_ordinal, priority, team_assignment_id, event_type, article,
     color, size, quantity, reference_id, counterparty_id, actor_id, actor_name, occurred_at)
SELECT source_event_id, item_ordinal,
       CASE WHEN event_name = 'KanbanMaterialIssued' THEN 1 ELSE 2 END,
       CASE WHEN event_name = 'KanbanMaterialIssued' THEN source_id ELSE target_id END,
       CASE WHEN event_name = 'KanbanMaterialIssued' THEN 'KANBAN_ISSUED' ELSE 'KANBAN_RECEIVED' END,
       article, color, size, quantity,
       kanban_id::text || ':' || supplier_unit_id || ':' || COALESCE(po_id, 'null'),
       CASE WHEN event_name = 'KanbanMaterialIssued' THEN target_id::text ELSE source_id::text END,
       actor_id, actor_name, occurred_at
FROM _btp_backfill_kanban
WHERE is_btp;

DO $$
DECLARE problem TEXT;
BEGIN
    SELECT format('%s %s (%s/%s), event %s: quantity %s', event_type, article, color, size, source_event_id, quantity)
    INTO problem FROM _btp_backfill_events
    WHERE article IS NULL OR color IS NULL OR size IS NULL OR quantity <= 0 OR reference_id IS NULL
    LIMIT 1;
    IF problem IS NOT NULL THEN RAISE EXCEPTION 'BTP backfill invalid: %', problem; END IF;

    SELECT event_type || ':' || reference_id || ':' || article || ':' || color || ':' || size
    INTO problem FROM _btp_backfill_events
    GROUP BY event_type, reference_id, article, color, size HAVING COUNT(*) > 1 LIMIT 1;
    IF problem IS NOT NULL THEN RAISE EXCEPTION 'BTP backfill duplicate reference: %', problem; END IF;

    SELECT format('event %s has incomplete actor', source_event_id)
    INTO problem FROM _btp_backfill_events
    WHERE (actor_id IS NULL) <> (actor_name IS NULL)
    LIMIT 1;
    IF problem IS NOT NULL THEN RAISE EXCEPTION 'BTP backfill invalid: %', problem; END IF;

    SELECT format('%s %s (%s/%s), reference %s', r.event_type, r.article, r.color, r.size, r.reference_id)
    INTO problem FROM _btp_backfill_events r
    WHERE r.event_type = 'KANBAN_RECEIVED' AND NOT EXISTS (
        SELECT 1 FROM _btp_backfill_events i
        WHERE i.event_type = 'KANBAN_ISSUED' AND i.reference_id = r.reference_id
          AND i.article = r.article AND i.color = r.color AND i.size = r.size
          AND i.quantity = r.quantity
    ) LIMIT 1;
    IF problem IS NOT NULL THEN RAISE EXCEPTION 'BTP backfill receipt without matching issue: %', problem; END IF;

END $$;

INSERT INTO btp_inventory_events
    (team_assignment_id, payload, occurred_at, version)
SELECT team_assignment_id,
       jsonb_build_object(
           'eventName', CASE event_type
               WHEN 'PRODUCED' THEN 'BtpProduced'
               WHEN 'KANBAN_ISSUED' THEN 'BtpKanbanIssued'
               ELSE 'BtpKanbanReceived' END,
           'teamAssignmentId', team_assignment_id::text,
           'sku', jsonb_build_object('article', article, 'color', color, 'size', size),
           'quantity', quantity,
           'referenceId', reference_id,
           'counterpartyId', counterparty_id,
           'actor', CASE WHEN actor_id IS NULL THEN NULL
               ELSE jsonb_build_object('id', actor_id, 'name', actor_name) END,
           'occurredAt', occurred_at
       ),
       occurred_at,
       row_number() OVER (
           PARTITION BY team_assignment_id
           ORDER BY occurred_at, priority, source_event_id, item_ordinal, article, color, size
       )
FROM _btp_backfill_events
ORDER BY team_assignment_id, occurred_at, priority, source_event_id, item_ordinal, article, color, size;

INSERT INTO btp_inventory_locks (team_assignment_id)
SELECT DISTINCT team_assignment_id FROM btp_inventory_events
ON CONFLICT DO NOTHING;

INSERT INTO btp_inventory_transaction_view
    (event_id, team_assignment_id, event_type, article, color, size, quantity,
     reference_id, counterparty_id, occurred_at)
SELECT id, team_assignment_id,
       CASE payload->>'eventName'
           WHEN 'BtpProduced' THEN 'PRODUCED'
           WHEN 'BtpKanbanIssued' THEN 'KANBAN_ISSUED'
           ELSE 'KANBAN_RECEIVED' END,
       payload->'sku'->>'article', payload->'sku'->>'color', payload->'sku'->>'size',
       (payload->>'quantity')::numeric, payload->>'referenceId', payload->>'counterpartyId', occurred_at
FROM btp_inventory_events
ORDER BY id;

INSERT INTO btp_inventory_balance_view
    (team_assignment_id, article, color, size, total_received, total_issued, balance)
SELECT team_assignment_id, article, color, size,
       COALESCE(SUM(quantity) FILTER (WHERE event_type <> 'KANBAN_ISSUED'), 0),
       COALESCE(SUM(quantity) FILTER (WHERE event_type = 'KANBAN_ISSUED'), 0),
       SUM(CASE WHEN event_type = 'KANBAN_ISSUED' THEN -quantity ELSE quantity END)
FROM btp_inventory_transaction_view
GROUP BY team_assignment_id, article, color, size
ORDER BY team_assignment_id, article, color, size;

DO $$
DECLARE negative_count BIGINT;
BEGIN
    SELECT COUNT(*) INTO negative_count FROM btp_inventory_balance_view WHERE balance < 0;
    IF negative_count > 0 THEN
        RAISE WARNING 'BTP backfill preserved % negative historical balances; review these assignments', negative_count;
    END IF;
END $$;
