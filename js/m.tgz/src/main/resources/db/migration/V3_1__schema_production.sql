-- Production schema

CREATE TABLE IF NOT EXISTS production_orders
(
    id              UUID      NOT NULL,
    buyer_order_id  UUID      NOT NULL,
    production_code TEXT      NOT NULL UNIQUE,
    status          TEXT      NOT NULL,
    created_at      TIMESTAMP NOT NULL,
    updated_at      TIMESTAMP NOT NULL,
    sync_date       DATE,
    product_date    DATE,
    first_sku       TEXT,
    routing         TEXT,
    main_company_code TEXT NOT NULL,
    CONSTRAINT pk_production_orders PRIMARY KEY (id),
    CONSTRAINT fk_production_orders_buyer_order_id FOREIGN KEY (buyer_order_id) REFERENCES buyer_orders (id)
);

CREATE UNIQUE INDEX ux_production_orders_production_code
    ON production_orders (production_code);

CREATE TABLE IF NOT EXISTS production_order_factories
(
    production_order_id UUID NOT NULL,
    factory_id          UUID NOT NULL,
    CONSTRAINT pk_production_order_factories PRIMARY KEY (production_order_id, factory_id),
    CONSTRAINT fk_production_order_factories_po_id FOREIGN KEY (production_order_id) REFERENCES production_orders (id)
);

CREATE TABLE IF NOT EXISTS team_assignments
(
    id                  UUID      NOT NULL,
    production_order_id UUID      NOT NULL,
    team_id             UUID      NOT NULL,
    operation           TEXT      NOT NULL,
    assigned_at         TIMESTAMP NOT NULL,
    planned_start_date  DATE      NOT NULL,
    planned_end_date    DATE      NOT NULL,
    CONSTRAINT pk_team_assignments PRIMARY KEY (id),
    CONSTRAINT fk_team_assignments_production_order_id FOREIGN KEY (production_order_id) REFERENCES production_orders (id)
);

CREATE TABLE IF NOT EXISTS team_assignment_events
(
    id            BIGSERIAL   PRIMARY KEY,
    assignment_id UUID        NOT NULL,
    version       INT         NOT NULL,
    occurred_at   TIMESTAMPTZ NOT NULL,
    payload       JSONB       NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_team_assignment_events_assignment_id
    ON team_assignment_events (assignment_id);

CREATE TABLE IF NOT EXISTS sku_allocations
(
    team_assignment_id UUID NOT NULL,
    purchase_order_id  UUID NOT NULL,
    color              TEXT NOT NULL,
    size               TEXT NOT NULL,
    quantity           INT  NOT NULL,
    check_date         DATE,
    delivery_date      DATE,
    notes              TEXT NOT NULL,
    CONSTRAINT pk_sku_allocations PRIMARY KEY (team_assignment_id, purchase_order_id, color, size),
    CONSTRAINT fk_sku_allocations_team_assignment_id FOREIGN KEY (team_assignment_id) REFERENCES team_assignments (id),
    CONSTRAINT fk_sku_allocations_purchase_order_id FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders (id)
);

CREATE TABLE IF NOT EXISTS team_bom_lines
(
    id                   UUID      NOT NULL,
    team_assignment_id   UUID      NOT NULL,
    article_name         TEXT      NOT NULL,
    alternative_name     TEXT,
    category             TEXT      NOT NULL,
    uom                  TEXT      NOT NULL,
    is_required          BOOLEAN   NOT NULL,
    last_updated_at      TIMESTAMP NOT NULL,
    last_updated_by_id   TEXT      NOT NULL,
    last_updated_by_name TEXT      NOT NULL,
    CONSTRAINT pk_team_bom_lines PRIMARY KEY (id),
    CONSTRAINT fk_team_bom_lines_team_assignment_id FOREIGN KEY (team_assignment_id) REFERENCES team_assignments (id)
);

CREATE TABLE IF NOT EXISTS team_bom_line_sizes
(
    team_bom_line_id UUID           NOT NULL,
    material_size    TEXT           NOT NULL,
    product_size     TEXT           NOT NULL,
    consumption      DECIMAL(14, 8) NOT NULL,
    CONSTRAINT pk_team_bom_line_sizes PRIMARY KEY (team_bom_line_id, product_size),
    CONSTRAINT fk_team_bom_line_sizes_line_id FOREIGN KEY (team_bom_line_id) REFERENCES team_bom_lines (id)
);

CREATE TABLE IF NOT EXISTS team_bom_line_colors
(
    team_bom_line_id UUID NOT NULL,
    material_color   TEXT NOT NULL,
    product_color    TEXT NOT NULL,
    consumption      DECIMAL(14, 8),
    CONSTRAINT pk_team_bom_line_colors PRIMARY KEY (team_bom_line_id, product_color),
    CONSTRAINT fk_team_bom_line_colors_line_id FOREIGN KEY (team_bom_line_id) REFERENCES team_bom_lines (id)
);

CREATE TABLE IF NOT EXISTS team_bom_line_destinations
(
    team_bom_line_id UUID NOT NULL,
    destination_code TEXT NOT NULL,
    CONSTRAINT pk_team_bom_line_destinations PRIMARY KEY (team_bom_line_id, destination_code),
    CONSTRAINT fk_team_bom_line_destinations_line_id FOREIGN KEY (team_bom_line_id) REFERENCES team_bom_lines (id)
);

CREATE TABLE IF NOT EXISTS team_bom_line_cutting_colors
(
    team_bom_line_id UUID NOT NULL,
    material_color   TEXT NOT NULL,
    product_color    TEXT NOT NULL,
    consumption      DECIMAL(14, 8),
    CONSTRAINT pk_team_bom_line_cutting_colors PRIMARY KEY (team_bom_line_id, product_color),
    CONSTRAINT fk_team_bom_line_cutting_colors_line_id FOREIGN KEY (team_bom_line_id) REFERENCES team_bom_lines (id) ON DELETE CASCADE
);

-- Goods Receipt Note
CREATE TABLE team_assignment_report_grns (
    assignment_id UUID NOT NULL,
    reported_at TIMESTAMPTZ NOT NULL,
    status VARCHAR(32) NOT NULL,
    mode VARCHAR(16),
    message TEXT,
    grn_no TEXT,
    last_attempted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (assignment_id, reported_at)
);
