-- Order schema

CREATE TABLE IF NOT EXISTS styles (
    name TEXT NOT NULL,
    customer TEXT NOT NULL,
    brand TEXT NOT NULL,
    season TEXT NOT NULL,
    CONSTRAINT pk_styles PRIMARY KEY (name)
);

CREATE TABLE IF NOT EXISTS buyer_orders (
    id UUID NOT NULL,
    wfx_id TEXT,
    style_name TEXT NOT NULL,
    revision_code TEXT NOT NULL,
    revision_date TIMESTAMP NOT NULL,
    status TEXT NOT NULL,
    last_synced_at TIMESTAMP,
    total_quantity INT NOT NULL DEFAULT 0,
    completed_quantity INT NOT NULL DEFAULT 0,
    article_code TEXT,
    CONSTRAINT pk_buyer_orders PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS purchase_orders (
    id UUID NOT NULL,
    wfx_id TEXT,
    code TEXT NOT NULL,
    market TEXT NOT NULL,
    delivery_date DATE NOT NULL,
    bo_id UUID NOT NULL,
    CONSTRAINT pk_purchase_orders PRIMARY KEY (id),
    CONSTRAINT fk_purchase_orders_bo_id FOREIGN KEY (bo_id) REFERENCES buyer_orders(id)
);

CREATE TABLE IF NOT EXISTS po_sku_quantities (
    po_id UUID NOT NULL,
    color TEXT NOT NULL,
    size TEXT NOT NULL,
    quantity INT NOT NULL,
    CONSTRAINT pk_po_sku_quantities PRIMARY KEY (po_id, color, size),
    CONSTRAINT fk_po_sku_quantities_po_id FOREIGN KEY (po_id) REFERENCES purchase_orders(id)
);

CREATE TABLE IF NOT EXISTS bo_routings (
    bo_id UUID NOT NULL,
    routing_index INT NOT NULL,
    title TEXT NOT NULL,
    operations TEXT NOT NULL,
    CONSTRAINT pk_bo_routings PRIMARY KEY (bo_id, routing_index),
    CONSTRAINT fk_bo_routings_bo_id FOREIGN KEY (bo_id) REFERENCES buyer_orders(id)
);

CREATE TABLE IF NOT EXISTS bo_material_lines (
    id SERIAL PRIMARY KEY,
    bo_id UUID NOT NULL,
    material_name TEXT NOT NULL,
    alternative_name TEXT,
    wfx_article_id TEXT,
    category TEXT NOT NULL,
    uom TEXT NOT NULL,
    is_required BOOLEAN NOT NULL,
    CONSTRAINT fk_bo_material_lines_bo_id FOREIGN KEY (bo_id) REFERENCES buyer_orders(id)
);

CREATE TABLE IF NOT EXISTS bo_material_line_sizes (
    bo_material_line_id INT NOT NULL,
    material_size TEXT NOT NULL,
    product_size TEXT NOT NULL,
    consumption DECIMAL(14, 8) NOT NULL,
    CONSTRAINT pk_bo_material_line_sizes PRIMARY KEY (bo_material_line_id, product_size),
    CONSTRAINT fk_bo_material_line_sizes_line_id FOREIGN KEY (bo_material_line_id) REFERENCES bo_material_lines(id)
);

CREATE TABLE IF NOT EXISTS bo_material_line_colors (
    bo_material_line_id INT NOT NULL,
    material_color TEXT NOT NULL,
    product_color TEXT NOT NULL,
    consumption DECIMAL(14, 8),
    CONSTRAINT pk_bo_material_line_colors PRIMARY KEY (bo_material_line_id, product_color),
    CONSTRAINT fk_bo_material_line_colors_line_id FOREIGN KEY (bo_material_line_id) REFERENCES bo_material_lines(id)
);

CREATE TABLE IF NOT EXISTS bo_material_line_operations (
    bo_material_line_id INT NOT NULL,
    operation TEXT NOT NULL,
    consumption DECIMAL(14, 8) NOT NULL,
    CONSTRAINT pk_bo_material_line_operations PRIMARY KEY (bo_material_line_id, operation),
    CONSTRAINT fk_bo_material_line_operations_line_id FOREIGN KEY (bo_material_line_id) REFERENCES bo_material_lines(id)
);

CREATE TABLE IF NOT EXISTS bo_material_line_destinations (
    bo_material_line_id INT NOT NULL,
    destination_code TEXT NOT NULL,
    CONSTRAINT pk_bo_material_line_destinations PRIMARY KEY (bo_material_line_id, destination_code),
    CONSTRAINT fk_bo_material_line_destinations_line_id FOREIGN KEY (bo_material_line_id) REFERENCES bo_material_lines(id)
);

CREATE TABLE IF NOT EXISTS style_color_orders (
    style_name TEXT NOT NULL,
    color_value TEXT NOT NULL,
    sort_order INT NOT NULL,
    CONSTRAINT pk_style_color_orders PRIMARY KEY (style_name, color_value),
    CONSTRAINT fk_style_color_orders_style_name FOREIGN KEY (style_name) REFERENCES styles(name)
);

CREATE TABLE IF NOT EXISTS style_size_orders (
    style_name TEXT NOT NULL,
    size_value TEXT NOT NULL,
    sort_order INT NOT NULL,
    CONSTRAINT pk_style_size_orders PRIMARY KEY (style_name, size_value),
    CONSTRAINT fk_style_size_orders_style_name FOREIGN KEY (style_name) REFERENCES styles(name)
);

-- User settings, not sync from wfx
CREATE TABLE bo_material_states (
    bo_id UUID NOT NULL,
    wfx_article_id TEXT NOT NULL,
    alternative_name TEXT,
    is_required BOOLEAN NOT NULL,
    PRIMARY KEY (bo_id, wfx_article_id),
    CONSTRAINT fk_bo_material_states_bo_id FOREIGN KEY (bo_id) REFERENCES buyer_orders(id)
);
