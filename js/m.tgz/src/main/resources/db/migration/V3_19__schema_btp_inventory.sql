CREATE TABLE btp_inventory_locks (
    team_assignment_id UUID PRIMARY KEY
);

CREATE TABLE btp_inventory_events (
    id BIGSERIAL PRIMARY KEY,
    team_assignment_id UUID NOT NULL,
    payload JSONB NOT NULL,
    occurred_at TIMESTAMPTZ NOT NULL,
    version INT NOT NULL,
    UNIQUE (team_assignment_id, version)
);

CREATE TABLE btp_inventory_balance_view (
    team_assignment_id UUID NOT NULL,
    article TEXT NOT NULL,
    color TEXT NOT NULL,
    size TEXT NOT NULL,
    uom TEXT NOT NULL DEFAULT 'PCS',
    total_received NUMERIC(12,4) NOT NULL DEFAULT 0,
    total_issued NUMERIC(12,4) NOT NULL DEFAULT 0,
    balance NUMERIC(12,4) NOT NULL DEFAULT 0,
    PRIMARY KEY (team_assignment_id, article, color, size)
);

CREATE TABLE btp_inventory_transaction_view (
    event_id BIGINT PRIMARY KEY REFERENCES btp_inventory_events(id),
    team_assignment_id UUID NOT NULL,
    event_type TEXT NOT NULL,
    article TEXT NOT NULL,
    color TEXT NOT NULL,
    size TEXT NOT NULL,
    uom TEXT NOT NULL DEFAULT 'PCS',
    quantity NUMERIC(12,4) NOT NULL,
    reference_id TEXT NOT NULL,
    counterparty_id TEXT,
    occurred_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX ON btp_inventory_transaction_view (team_assignment_id, occurred_at);
