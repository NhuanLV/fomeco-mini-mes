-- Event store
CREATE TABLE kanban_events (
    id              BIGSERIAL   PRIMARY KEY,
    kanban_id       UUID        NOT NULL,
    payload         JSONB       NOT NULL,
    occurred_at     TIMESTAMPTZ NOT NULL,
    kanban_version  INT         NOT NULL
);
CREATE INDEX ON kanban_events (kanban_id);

CREATE TABLE kanban_assignment_events (
    id               BIGSERIAL   PRIMARY KEY,
    kanban_id        UUID        NOT NULL,
    supplier_unit_id TEXT        NOT NULL,
    version          INT         NOT NULL,
    occurred_at      TIMESTAMPTZ NOT NULL,
    payload          JSONB       NOT NULL
);
CREATE INDEX ON kanban_assignment_events (kanban_id, supplier_unit_id);

-- View: header
CREATE TABLE kanban_view (
    id                  UUID PRIMARY KEY,
    kanban_code         TEXT NOT NULL,
    team_assignment_id  UUID NOT NULL,
    team_id             UUID NOT NULL,
    status              TEXT NOT NULL,
    plan                JSONB NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL,
    created_by_id       TEXT NOT NULL,
    created_by_name     TEXT NOT NULL
);

-- View: items (1 row per article+color+size)
CREATE TABLE kanban_item_view (
    kanban_id           UUID          NOT NULL REFERENCES kanban_view(id),
    article             TEXT          NOT NULL,
    color               TEXT          NOT NULL,
    size                TEXT          NOT NULL,
    uom                 TEXT          NOT NULL DEFAULT '',
    total_consumption   NUMERIC(12,4) NOT NULL,
    cumulative_required NUMERIC(12,4) NOT NULL,
    creator_note        TEXT          NOT NULL DEFAULT '',
    supplier_note       TEXT          NOT NULL DEFAULT '',
    PRIMARY KEY (kanban_id, article, color, size)
);

-- View: parts (1 row per PO breakdown)
CREATE TABLE kanban_item_part_view (
    kanban_id     UUID          NOT NULL REFERENCES kanban_view(id),
    article       TEXT          NOT NULL,
    color         TEXT          NOT NULL,
    size          TEXT          NOT NULL,
    po_id         UUID          NULL,
    po_code       TEXT          NULL,
    required_qty  NUMERIC(12,4) NOT NULL,
    actual_issued_qty NUMERIC(12,4) NOT NULL DEFAULT 0,
    issued        BOOLEAN       NOT NULL DEFAULT FALSE,
    received      BOOLEAN       NOT NULL DEFAULT FALSE,
    supplier_id   TEXT          NOT NULL,
    supplier_name TEXT          NOT NULL
);
CREATE INDEX ON kanban_item_part_view (kanban_id, article, color, size);

-- Goods Dispatch Note
CREATE TABLE kanban_gdns (
    kanban_id UUID NOT NULL,
    supplier_unit_id UUID NOT NULL,
    occurred_at TIMESTAMP WITH TIME ZONE NOT NULL,
    material_type VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    mode VARCHAR(50),
    message TEXT,
    gdn_no VARCHAR(100),
    last_attempted_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    CONSTRAINT pk_kanban_gdns PRIMARY KEY (kanban_id, supplier_unit_id, occurred_at, material_type)
);
