-- 1. Bổ sung wfx_bom_line_id vào bo_material_lines để định danh duy nhất từng dòng BOM của đơn hàng
ALTER TABLE bo_material_lines ADD COLUMN IF NOT EXISTS wfx_bom_line_id TEXT;

-- 2. Bổ sung wfx_bom_line_id vào team_bom_lines để định danh duy nhất từng dòng BOM của tổ sản xuất
ALTER TABLE team_bom_lines ADD COLUMN IF NOT EXISTS wfx_bom_line_id TEXT;

-- 3. Cập nhật bo_material_states để hỗ trợ wfx_bom_line_id đồng thời bảo toàn dữ liệu cũ
ALTER TABLE bo_material_states ADD COLUMN IF NOT EXISTS wfx_bom_line_id TEXT;
ALTER TABLE bo_material_states DROP CONSTRAINT IF EXISTS bo_material_states_pkey;
ALTER TABLE bo_material_states ADD COLUMN IF NOT EXISTS id BIGSERIAL;

-- Thiết lập cột id tự tăng làm Khóa chính (PRIMARY KEY) mới cho bảng bo_material_states.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'pk_bo_material_states'
    ) THEN
        ALTER TABLE bo_material_states ADD CONSTRAINT pk_bo_material_states PRIMARY KEY (id);
    END IF;
END $$;

-- Đảm bảo tính duy nhất cho DỮ LIỆU MỚI (đã có wfx_bom_line_id).
CREATE UNIQUE INDEX IF NOT EXISTS uq_bo_material_states_line
    ON bo_material_states (bo_id, wfx_bom_line_id)
    WHERE wfx_bom_line_id IS NOT NULL;

-- Bảo toàn tính duy nhất và toàn vẹn cho DỮ LIỆU CŨ trên server (chưa có wfx_bom_line_id).
CREATE UNIQUE INDEX IF NOT EXISTS uq_bo_material_states_article
    ON bo_material_states (bo_id, wfx_article_id)
    WHERE wfx_bom_line_id IS NULL;
