ALTER TABLE org_units
    ADD COLUMN site_name TEXT,
    ADD COLUMN site_code TEXT;

DROP TABLE IF EXISTS company_operations CASCADE;

CREATE TABLE factory_operations (
    id UUID PRIMARY KEY,
    company_id UUID NOT NULL REFERENCES org_units(id),
    factory_id UUID NOT NULL REFERENCES org_units(id),
    operation_code TEXT NOT NULL,
    operation_name TEXT NOT NULL,
    material_dispatch_warehouse_id UUID REFERENCES org_units(id),
    btp_receive_warehouse_id UUID REFERENCES org_units(id),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_factory_operations_factory_operation UNIQUE (factory_id, operation_code)
);

INSERT INTO factory_operations (
    id,
    company_id,
    factory_id,
    operation_code,
    operation_name,
    is_active
)
SELECT
    md5(factory.id::TEXT || operation.code)::UUID,
    factory.parent_id,
    factory.id,
    operation.code,
    operation.name,
    TRUE
FROM org_units factory
CROSS JOIN (VALUES
    ('CUT-1', 'Cắt'),
    ('SEW-1', 'May'),
    ('FIN-1', 'Hoàn thiện')
) AS operation(code, name)
WHERE factory.type = 'FACTORY' AND factory.parent_id IS NOT NULL;

DELETE FROM unit_operations
WHERE unit_id IN (SELECT id FROM org_units WHERE type = 'FACTORY');
