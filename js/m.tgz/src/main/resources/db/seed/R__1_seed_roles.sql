-- Seed test roles (non-system) and permissions for dev

INSERT INTO roles (id, name, description, is_system) VALUES
    ('3e13338d-6e08-45ea-8c55-cad63a62e865', 'Tổ trưởng', 'Nhập tiến độ và kanban', false),
    ('925569cd-1199-40ea-93f3-c50b471619f9', 'Phòng kế hoạch', 'Quản lý đơn hàng và lệnh sản xuất', false),
    ('6886fcf1-a70c-40d4-bade-585cc6937f3d', 'Phòng kỹ thuật', 'Cập nhật định mức và thêm tên thay thế cho từng NPL', false),
    ('4c8d86f8-5a7d-4a0e-8e9e-7f9b0fbb8d62', 'Kho', 'Chuẩn bị vật tư', false),
    ('0892cf77-a48f-4b04-97fa-d944a6f41819', 'Phó giám đốc', 'Duyệt Kanban', false)
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions (role_id, permission) VALUES
    ('3e13338d-6e08-45ea-8c55-cad63a62e865', 'REPORT_PROGRESS'),
    ('3e13338d-6e08-45ea-8c55-cad63a62e865', 'CREATE_KANBAN'),
    ('3e13338d-6e08-45ea-8c55-cad63a62e865', 'PREPARE_MATERIAL'),
    ('3e13338d-6e08-45ea-8c55-cad63a62e865', 'ISSUE_MATERIAL'),
    ('925569cd-1199-40ea-93f3-c50b471619f9', 'MANAGE_BUYER_ORDER'),
    ('925569cd-1199-40ea-93f3-c50b471619f9', 'ISSUE_PRODUCTION_ORDER'),
    ('925569cd-1199-40ea-93f3-c50b471619f9', 'VIEW_PRODUCTION_ORDER'),
    ('925569cd-1199-40ea-93f3-c50b471619f9', 'EVALUATE_EXTRA_KANBAN'),
    ('6886fcf1-a70c-40d4-bade-585cc6937f3d', 'UPDATE_COSTING'),
    ('6886fcf1-a70c-40d4-bade-585cc6937f3d', 'VIEW_PRODUCTION_ORDER'),
    ('4c8d86f8-5a7d-4a0e-8e9e-7f9b0fbb8d62', 'PREPARE_MATERIAL'),
    ('4c8d86f8-5a7d-4a0e-8e9e-7f9b0fbb8d62', 'ISSUE_MATERIAL'),
    ('0892cf77-a48f-4b04-97fa-d944a6f41819', 'EVALUATE_KANBAN'),
    ('0892cf77-a48f-4b04-97fa-d944a6f41819', 'ISSUE_MATERIAL'),
    ('3e13338d-6e08-45ea-8c55-cad63a62e865', 'CREATE_REQUEST'),
    ('3e13338d-6e08-45ea-8c55-cad63a62e865', 'RECEIVE_REQUEST'),
    ('0892cf77-a48f-4b04-97fa-d944a6f41819', 'EVALUATE_REQUEST'),
    ('4c8d86f8-5a7d-4a0e-8e9e-7f9b0fbb8d62', 'RECEIVE_REQUEST')
ON CONFLICT DO NOTHING;
