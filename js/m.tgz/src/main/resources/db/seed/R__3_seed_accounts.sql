-- Seed test accounts for dev

INSERT INTO accounts (id, name, username, password)
VALUES ('2422b38f-63da-4608-a6cd-bf978b45425f', 'Kế hoạch', 'kehoach',
        '$2a$12$6NrEtmJ7g5ftTfdCxz7PPOT7/ddXbN0q5nbbYKkX6VRwRWSX3tz.q'),
       ('00d36dec-373f-4622-a3e9-9f624d854937', 'Kỹ thuật', 'kythuat',
        '$2a$12$6NrEtmJ7g5ftTfdCxz7PPOT7/ddXbN0q5nbbYKkX6VRwRWSX3tz.q'),
       ('081e6a1f-ca1d-4726-a046-b2407c705a0b', 'Tổ trưởng Cắt', 'cat1',
        '$2a$12$6NrEtmJ7g5ftTfdCxz7PPOT7/ddXbN0q5nbbYKkX6VRwRWSX3tz.q'),
       ('58412013-e57b-4907-b364-e561dc6c8127', 'Tổ trưởng May 1', 'may1',
        '$2a$12$6NrEtmJ7g5ftTfdCxz7PPOT7/ddXbN0q5nbbYKkX6VRwRWSX3tz.q'),
       ('019eaf8a-8153-733b-b4ea-b65357ae8fc1', 'Tổ trưởng May 2', 'may2',
        '$2a$12$6NrEtmJ7g5ftTfdCxz7PPOT7/ddXbN0q5nbbYKkX6VRwRWSX3tz.q'),
       ('9fdd5ce3-168f-48b0-9041-daa932137ca7', 'Tổ trưởng Hoàn thiện', 'hoanthien1',
        '$2a$12$6NrEtmJ7g5ftTfdCxz7PPOT7/ddXbN0q5nbbYKkX6VRwRWSX3tz.q'),
       ('9a3a87e1-7368-4a41-b038-7c808130ef85', 'Kho 1', 'kho1',
        '$2a$12$6NrEtmJ7g5ftTfdCxz7PPOT7/ddXbN0q5nbbYKkX6VRwRWSX3tz.q'),
       ('4c96209a-a763-4e12-8b3f-6eacd53dad76', 'Phó giám đốc', 'pgd',
        '$2a$12$6NrEtmJ7g5ftTfdCxz7PPOT7/ddXbN0q5nbbYKkX6VRwRWSX3tz.q')
ON CONFLICT DO NOTHING;

-- Unit memberships
-- Admin: Corporation, roles Super Admin, Phòng kế hoạch, Phòng kỹ thuật
INSERT INTO account_roles (account_id, unit_id, role_id)
VALUES ('11111111-1111-1111-1111-111111111111', '00000000-0000-0000-0000-000000000000',
        'ffffffff-ffff-ffff-ffff-ffffffffffff'),
       ('11111111-1111-1111-1111-111111111111', '00000000-0000-0000-0000-000000000000',
        '925569cd-1199-40ea-93f3-c50b471619f9'),
       ('11111111-1111-1111-1111-111111111111', '00000000-0000-0000-0000-000000000000',
        '6886fcf1-a70c-40d4-bade-585cc6937f3d')
ON CONFLICT DO NOTHING;

-- kehoach: Corporation, role Phòng kế hoạch
INSERT INTO account_roles (account_id, unit_id, role_id)
VALUES ('2422b38f-63da-4608-a6cd-bf978b45425f', '00000000-0000-0000-0000-000000000000',
        '925569cd-1199-40ea-93f3-c50b471619f9')
ON CONFLICT DO NOTHING;

-- kythuat: Corporation, role Phòng kỹ thuật
INSERT INTO account_roles (account_id, unit_id, role_id)
VALUES ('00d36dec-373f-4622-a3e9-9f624d854937', '00000000-0000-0000-0000-000000000000',
        '6886fcf1-a70c-40d4-bade-585cc6937f3d')
ON CONFLICT DO NOTHING;

-- cat1: Tổ cắt (Xí nghiệp 1), role Tổ trưởng
INSERT INTO account_roles (account_id, unit_id, role_id)
VALUES ('081e6a1f-ca1d-4726-a046-b2407c705a0b', '4d37f30d-e93f-4feb-9b4a-efe3c0509f28',
        '3e13338d-6e08-45ea-8c55-cad63a62e865')
ON CONFLICT DO NOTHING;

-- may1: Tổ may 1 (Xí nghiệp 1), role Tổ trưởng
INSERT INTO account_roles (account_id, unit_id, role_id)
VALUES ('58412013-e57b-4907-b364-e561dc6c8127', 'a97c749d-a238-431c-8d13-e9021802c66d',
        '3e13338d-6e08-45ea-8c55-cad63a62e865')
ON CONFLICT DO NOTHING;

-- may2: Tổ may 2 (Xí nghiệp 1), role Tổ trưởng
INSERT INTO account_roles (account_id, unit_id, role_id)
VALUES ('019eaf8a-8153-733b-b4ea-b65357ae8fc1', '78ff9303-5631-4279-b210-23f1660db8f2',
        '3e13338d-6e08-45ea-8c55-cad63a62e865')
ON CONFLICT DO NOTHING;

-- hoanthien1: Tổ hoàn thiện (Xí nghiệp 1), role Tổ trưởng
INSERT INTO account_roles (account_id, unit_id, role_id)
VALUES ('9fdd5ce3-168f-48b0-9041-daa932137ca7', '186439ca-177d-4979-8893-fbf4bab9e54a',
        '3e13338d-6e08-45ea-8c55-cad63a62e865')
ON CONFLICT DO NOTHING;

-- kho1: Kho 1 (LGG Bắc Giang), role Kho
INSERT INTO account_roles (account_id, unit_id, role_id)
VALUES ('9a3a87e1-7368-4a41-b038-7c808130ef85', '677178b8-1696-46ca-9c8d-7ddb76b7b3b0',
        '4c8d86f8-5a7d-4a0e-8e9e-7f9b0fbb8d62')
ON CONFLICT DO NOTHING;

-- pgd: Xí nghiệp 1 (LGG Bắc Giang), role Phó giám đốc
INSERT INTO account_roles (account_id, unit_id, role_id)
VALUES ('4c96209a-a763-4e12-8b3f-6eacd53dad76', '85b23ffc-d406-4cc7-91a2-754f786e032a',
        '0892cf77-a48f-4b04-97fa-d944a6f41819')
ON CONFLICT DO NOTHING;
