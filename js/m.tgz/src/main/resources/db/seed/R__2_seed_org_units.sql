-- Seed operations and org units for dev

-- Operations
INSERT INTO operations (name) VALUES
    ('CUT-1'),
    ('FIN-1'),
    ('SEW-1')
ON CONFLICT DO NOTHING;

-- Org Units
INSERT INTO org_units (id, name, type, code, parent_id, address, is_active, classification, wfx_id) VALUES
    ('4ee279f1-6602-4051-99bd-df495e0d8110', 'LGG Bắc Giang', 'COMPANY', 'LGG-BG', '00000000-0000-0000-0000-000000000000', 'Lạng Giang', true, 'INHOUSE', NULL),
    ('b4dc3241-963a-4a04-8cb4-7ca7145a181a', 'LGG Tuyên Quang', 'COMPANY', 'LGG-TQ', '00000000-0000-0000-0000-000000000000', 'Tuyên Quang', true, 'INHOUSE', NULL),
    ('85b23ffc-d406-4cc7-91a2-754f786e032a', 'Xí nghiệp 1', 'FACTORY', 'XN-BG-01', '4ee279f1-6602-4051-99bd-df495e0d8110', ' Khu A', true, 'INHOUSE', NULL),
    ('8fc92c32-9ccb-490b-9730-fc84e424a7eb', 'Xí nghiệp 2', 'FACTORY', 'XN-BG-02', '4ee279f1-6602-4051-99bd-df495e0d8110', ' Khu B', true, 'INHOUSE', NULL),
    ('a97c749d-a238-431c-8d13-e9021802c66d', 'Tổ may 1', 'TEAM', 'TO-MAY-01', '85b23ffc-d406-4cc7-91a2-754f786e032a', NULL, true, 'INHOUSE', NULL),
    ('78ff9303-5631-4279-b210-23f1660db8f2', 'Tổ may 2', 'TEAM', 'TO-MAY-02', '85b23ffc-d406-4cc7-91a2-754f786e032a', NULL, true, 'INHOUSE', NULL),
    ('74164804-ded1-479e-b5cd-da5214b59006', 'Tổ may 3', 'TEAM', 'TO-MAY-03', '85b23ffc-d406-4cc7-91a2-754f786e032a', NULL, true, 'INHOUSE', NULL),
    ('4d37f30d-e93f-4feb-9b4a-efe3c0509f28', 'Tổ cắt', 'TEAM', 'TO-CAT-01', '85b23ffc-d406-4cc7-91a2-754f786e032a', NULL, true, 'INHOUSE', NULL),
    ('186439ca-177d-4979-8893-fbf4bab9e54a', 'Tổ hoàn thiện', 'TEAM', 'TO-HT-01', '85b23ffc-d406-4cc7-91a2-754f786e032a', NULL, true, 'INHOUSE', NULL),
    ('43044368-561b-441f-a4c8-c5b5fb9de26b', 'Tổ may 1', 'TEAM', 'TO-MAY-04', '8fc92c32-9ccb-490b-9730-fc84e424a7eb', NULL, true, 'INHOUSE', NULL),
    ('deebe3d3-569c-4944-8ec4-1dac24633ca0', 'Tổ cắt', 'TEAM', 'TO-CAT-02', '8fc92c32-9ccb-490b-9730-fc84e424a7eb', NULL, true, 'INHOUSE', NULL),
    ('677178b8-1696-46ca-9c8d-7ddb76b7b3b0', 'Kho 1', 'WAREHOUSE', 'KHO-BG-01', '4ee279f1-6602-4051-99bd-df495e0d8110', NULL, true, 'INHOUSE', NULL),
    ('bb6e04c4-a269-44cf-9124-bc3f6d676177', 'Kho 2', 'WAREHOUSE', 'KHO-BG-02', '4ee279f1-6602-4051-99bd-df495e0d8110', NULL, true, 'INHOUSE', NULL)
ON CONFLICT DO NOTHING;

-- Factory operation mappings used by the development seed.
INSERT INTO factory_operations (id, company_id, factory_id, operation_code, operation_name, is_active) VALUES
    ('10000000-0000-0000-0000-000000000001', '4ee279f1-6602-4051-99bd-df495e0d8110', '85b23ffc-d406-4cc7-91a2-754f786e032a', 'CUT-1', 'Cắt', true),
    ('10000000-0000-0000-0000-000000000002', '4ee279f1-6602-4051-99bd-df495e0d8110', '85b23ffc-d406-4cc7-91a2-754f786e032a', 'SEW-1', 'May', true),
    ('10000000-0000-0000-0000-000000000003', '4ee279f1-6602-4051-99bd-df495e0d8110', '85b23ffc-d406-4cc7-91a2-754f786e032a', 'FIN-1', 'Hoàn thiện', true),
    ('10000000-0000-0000-0000-000000000004', '4ee279f1-6602-4051-99bd-df495e0d8110', '8fc92c32-9ccb-490b-9730-fc84e424a7eb', 'CUT-1', 'Cắt', true),
    ('10000000-0000-0000-0000-000000000005', '4ee279f1-6602-4051-99bd-df495e0d8110', '8fc92c32-9ccb-490b-9730-fc84e424a7eb', 'SEW-1', 'May', true),
    ('10000000-0000-0000-0000-000000000006', '4ee279f1-6602-4051-99bd-df495e0d8110', '8fc92c32-9ccb-490b-9730-fc84e424a7eb', 'FIN-1', 'Hoàn thiện', true)
ON CONFLICT DO NOTHING;

-- Unit Operations for teams
INSERT INTO unit_operations (unit_id, operation) VALUES
    ('a97c749d-a238-431c-8d13-e9021802c66d', 'SEW-1'),
    ('78ff9303-5631-4279-b210-23f1660db8f2', 'SEW-1'),
    ('74164804-ded1-479e-b5cd-da5214b59006', 'SEW-1'),
    ('4d37f30d-e93f-4feb-9b4a-efe3c0509f28', 'CUT-1'),
    ('186439ca-177d-4979-8893-fbf4bab9e54a', 'FIN-1'),
    ('43044368-561b-441f-a4c8-c5b5fb9de26b', 'SEW-1'),
    ('deebe3d3-569c-4944-8ec4-1dac24633ca0', 'CUT-1')
ON CONFLICT DO NOTHING;
