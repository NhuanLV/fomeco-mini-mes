package vn.lgg.mesplus.kanban.application.usecase

import io.kotest.matchers.collections.shouldHaveSize
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.just
import io.mockk.mockk
import io.mockk.runs
import io.mockk.slot
import io.mockk.verify
import java.math.BigDecimal
import java.time.Instant
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Factory
import vn.lgg.mesplus.iam.domain.model.FactoryOperation
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.model.Warehouse
import vn.lgg.mesplus.iam.domain.repository.FactoryOperationRepository
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.kanban.domain.event.KanbanAssignmentInitialized
import vn.lgg.mesplus.kanban.domain.event.KanbanCreated
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialIssued
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialPrepared
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialReceived
import vn.lgg.mesplus.kanban.domain.model.GdnMaterialType
import vn.lgg.mesplus.kanban.domain.model.GdnMode
import vn.lgg.mesplus.kanban.domain.model.GdnStatus
import vn.lgg.mesplus.kanban.domain.model.Kanban
import vn.lgg.mesplus.kanban.domain.model.KanbanAssignment
import vn.lgg.mesplus.kanban.domain.model.KanbanGdn
import vn.lgg.mesplus.kanban.domain.model.KanbanItem
import vn.lgg.mesplus.kanban.domain.model.PlanItem
import vn.lgg.mesplus.kanban.domain.repository.KanbanAssignmentRepository
import vn.lgg.mesplus.kanban.domain.repository.KanbanGdnRepository
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderRouting
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BillOfMaterialRepository
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.RoutingRepository
import vn.lgg.mesplus.order.infrastructure.wfx.ResolvedWfxArticle
import vn.lgg.mesplus.order.infrastructure.wfx.WfxArticleCodeResolver
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.WfxSyncResponse
import vn.lgg.mesplus.production.application.service.ProductionOrderTypeQuery
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Operation

class KanbanGdnSyncServiceTest {
  private val kanbanRepository = mockk<KanbanRepository> {
    every { lockAndLoad(any()) } answers { kanban() }
  }
  private val kanbanAssignmentRepository = mockk<KanbanAssignmentRepository>()
  private val teamAssignmentRepository = mockk<TeamAssignmentRepository>()
  private val productionOrderRepository = mockk<ProductionOrderRepository>()
  private val buyerOrderRepository = mockk<BuyerOrderRepository>()
  private val productionOrderTypeQuery = mockk<ProductionOrderTypeQuery>()
  private val billOfMaterialRepository = mockk<BillOfMaterialRepository>()
  private val routingRepository = mockk<RoutingRepository>()
  private val kanbanGdnRepository = mockk<KanbanGdnRepository>(relaxed = true)
  private val articleCodeResolver = mockk<WfxArticleCodeResolver>()
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val factoryOperationRepository = mockk<FactoryOperationRepository>()
  private val eventPublisher = mockk<DomainEventPublisher>(relaxed = true)
  private val executor = mockk<KanbanGdnSyncExecutor>()

  @Test
  fun `cancelled kanban blocks retry and ignores late success callbacks`() {
    val cancelled = Kanban("kanban-1").apply {
      loadFromHistory(kanban().history)
      cancel("Đổi kế hoạch", ActorRef("actor-1", "Actor"))
    }
    every { kanbanRepository.lockAndLoad("kanban-1") } returns cancelled
    io.kotest.assertions.throwables.shouldThrow<IllegalStateException> {
      service().retryReceive("kanban-1", "supplier-1", Instant.EPOCH)
    }
    val event = receivedEvent()
    val command = KanbanGdnSyncCommand(event, GdnMode.AUTO, event.occurredAt,
      "BO-WFX-1", Operation("CAT-1"), "BTP-OUT", emptyList(), GdnMaterialType.BTP)
    service().markSuccess(command, WfxSyncResponse(responseType = "Pass", status = "200"))
    verify(exactly = 0) { kanbanAssignmentRepository.save(any()) }
    verify(exactly = 0) { kanbanGdnRepository.save(any()) }
    verify(exactly = 0) { executor.executeAll(any()) }
  }

  @Test
  fun `only positive BTP bypasses WFX while NPL always requires GDN`() {
    every { kanbanRepository.findById("kanban-1") } returns kanban()
    val original = receivedEvent()
    val regular = original.items.first().copy(purchaseOrderType = PurchaseOrderType.REGULAR)
    val positive = regular.copy(purchaseOrderType = PurchaseOrderType.POSITIVE)
    val npl = original.items.last()
    service().positiveBtpItems(original.copy(items = listOf(npl, regular, positive))) shouldBe listOf(positive)
    service().positiveBtpItems(original.copy(items = listOf(npl, positive))) shouldBe listOf(positive)
  }

  @Test
  fun `resolves legacy BTP PO types with one lookup per receive`() {
    every { kanbanRepository.findById("kanban-1") } returns kanban()
    every { productionOrderTypeQuery.typesByPo("ta-1") } returns mapOf("po-a" to PurchaseOrderType.POSITIVE)
    val original = receivedEvent()
    val btp = original.items.first()
    val otherSize = btp.copy(size = "L")

    service().positiveBtpItems(original.copy(items = listOf(btp, otherSize, original.items.last()))) shouldBe listOf(btp, otherSize)

    verify(exactly = 1) { productionOrderTypeQuery.typesByPo("ta-1") }
    verify(exactly = 0) { productionOrderTypeQuery.legacyTypeAt(any(), any()) }
  }

  @Test
  fun `snapshots receive event before executing GDN asynchronously`() {
    val commands = slot<List<KanbanGdnSyncCommand>>()
    val pending = slot<KanbanGdn>()
    every { kanbanGdnRepository.findById(any(), any(), any(), any()) } returns null
    every { kanbanRepository.findById("kanban-1") } returns kanban()
    every { teamAssignmentRepository.findById("ta-1") } returns teamAssignment()
    every { buyerOrderRepository.findById("bo-1") } returns buyerOrder()
    every { billOfMaterialRepository.findByBuyerOrderId("bo-1") } returns null
    every { articleCodeResolver.resolveBtpFromLabel("LGG11ARTICLE", "BTP CAT", null) } returns
      ResolvedWfxArticle("LGG11BSDSGWWN2N1J112btpcat", "PCS")
    every { articleCodeResolver.resolve("MAT-001") } returns ResolvedWfxArticle("MAT-001-CODE", "M")
    every { kanbanGdnRepository.save(capture(pending)) } just runs
    every { executor.executeAll(capture(commands)) } just runs

    service().stageReceive(receivedEvent())

    commands.captured shouldHaveSize 2
    commands.captured.map { it.event.items.single().article }.toSet() shouldBe
      setOf("BTP CAT", "MAT-001")
    val btpCommand = commands.captured.single { it.materialType == GdnMaterialType.BTP }
    btpCommand.dispatchedSite shouldBe "BTP-OUT"
    btpCommand.items.single().articleCode shouldBe "LGG11BSDSGWWN2N1J112btpcat"
    btpCommand.items.single().quantity shouldBe "3.5"
    btpCommand.items.single().uom shouldBe "PCS"
    btpCommand.docNoSuffix shouldBe "BTP"
    val nplCommand = commands.captured.single { it.materialType == GdnMaterialType.NPL }
    nplCommand.dispatchedSite shouldBe "NPL-OUT"
    nplCommand.items.single().articleCode shouldBe "MAT-001-CODE"
    nplCommand.items.single().uom shouldBe "M"
    nplCommand.docNoSuffix shouldBe "NPL"
    pending.captured.status shouldBe GdnStatus.PENDING
    pending.captured.mode shouldBe GdnMode.AUTO
    pending.captured.payloadSnapshot.map { it.article } shouldBe listOf("MAT-001")
  }

  @Test
  fun `records failed status when warehouse site name is blank`() {
    val saved = mutableListOf<KanbanGdn>()
    val service = service(btpSiteName = "")
    every { kanbanGdnRepository.findById(any(), any(), any(), any()) } returns null
    every { kanbanRepository.findById("kanban-1") } returns kanban()
    every { teamAssignmentRepository.findById("ta-1") } returns teamAssignment()
    every { buyerOrderRepository.findById("bo-1") } returns buyerOrder()
    every { billOfMaterialRepository.findByBuyerOrderId("bo-1") } returns null
    every { articleCodeResolver.resolveBtpFromLabel("LGG11ARTICLE", "BTP CAT", null) } returns
      ResolvedWfxArticle("LGG11BSDSGWWN2N1J112btpcat", "PCS")
    every { articleCodeResolver.resolve("MAT-001") } returns ResolvedWfxArticle("MAT-001-CODE", "M")
    every { kanbanGdnRepository.save(capture(saved)) } just runs
    every { executor.executeAll(any()) } just runs

    service.stageReceive(receivedEvent())

    saved.last { it.materialType == GdnMaterialType.BTP }.status shouldBe GdnStatus.FAILED
    saved.last { it.materialType == GdnMaterialType.BTP }.message shouldBe
      "Kho WH-BTP chưa có Site Name"
    saved.last { it.materialType == GdnMaterialType.NPL }.status shouldBe GdnStatus.PENDING
  }

  @Test
  fun `records failed status when source team does not match previous routing operation`() {
    val saved = mutableListOf<KanbanGdn>()
    val service = service()
    val wrongSourceTeam = Team("supplier-1", "Tổ Sai", "factory-source", "factory-source", Operation("FIN-1"), true, "SUPP-1")
    every { orgUnitRepository.findById("supplier-1") } returns wrongSourceTeam
    every { kanbanGdnRepository.findById(any(), any(), any(), any()) } returns null
    every { kanbanRepository.findById("kanban-1") } returns kanban()
    every { teamAssignmentRepository.findById("ta-1") } returns teamAssignment()
    every { buyerOrderRepository.findById("bo-1") } returns buyerOrder()
    every { billOfMaterialRepository.findByBuyerOrderId("bo-1") } returns null
    every { articleCodeResolver.resolveBtpFromLabel("LGG11ARTICLE", "BTP CAT", null) } returns
      ResolvedWfxArticle("LGG11BSDSGWWN2N1J112btpcat", "PCS")
    every { articleCodeResolver.resolve("MAT-001") } returns ResolvedWfxArticle("MAT-001-CODE", "M")
    every { kanbanGdnRepository.save(capture(saved)) } just runs
    every { executor.executeAll(any()) } just runs

    service.stageReceive(receivedEvent())

    saved.last { it.materialType == GdnMaterialType.BTP }.status shouldBe GdnStatus.FAILED
    saved.last { it.materialType == GdnMaterialType.BTP }.message shouldBe
      "Tổ nguồn Tổ Sai không thuộc công đoạn ngay trước CAT-1"
  }

  @Test
  fun `records failed status when snapshot fails`() {
    val saved = mutableListOf<KanbanGdn>()
    every { kanbanGdnRepository.findById(any(), any(), any(), any()) } returns null
    every { kanbanRepository.findById("kanban-1") } returns kanban()
    every { teamAssignmentRepository.findById("ta-1") } returns teamAssignment()
    every { buyerOrderRepository.findById("bo-1") } returns buyerOrder()
    every { billOfMaterialRepository.findByBuyerOrderId("bo-1") } returns null
    every { articleCodeResolver.resolveBtpFromLabel("LGG11ARTICLE", "BTP CAT", any()) } throws
      IllegalStateException("Snapshot failed")
    every { articleCodeResolver.resolve("MAT-001") } returns ResolvedWfxArticle("MAT-001-CODE", "M")
    every { kanbanGdnRepository.save(capture(saved)) } just runs
    every { executor.executeAll(any()) } just runs

    service().stageReceive(receivedEvent())

    saved.last { it.materialType == GdnMaterialType.BTP }.status shouldBe GdnStatus.FAILED
    saved.last { it.materialType == GdnMaterialType.BTP }.message shouldBe "Snapshot failed"
    saved.last { it.materialType == GdnMaterialType.NPL }.status shouldBe GdnStatus.PENDING
  }

  @Test
  fun `receives only the successful material type after WFX succeeds`() {
    val event = receivedEvent().copy(items = receivedEvent().items.take(1))
    val command =
      KanbanGdnSyncCommand(
        event = event,
        mode = GdnMode.AUTO,
        createdAt = event.occurredAt,
        buyerOrderWfxId = "BO-WFX-1",
        operation = Operation("CAT-1"),
        dispatchedSite = "BTP-OUT",
        items = emptyList(),
        materialType = GdnMaterialType.BTP,
      )
    val assignment = issuedAssignment()
    val published = slot<List<DomainEvent>>()
    every { kanbanGdnRepository.findById(any(), any(), any(), any()) } returns
      KanbanGdn(
        "kanban-1",
        "supplier-1",
        event.occurredAt,
        event.actor,
        GdnMaterialType.BTP,
        GdnStatus.PENDING,
        payloadSnapshot = event.items,
        createdAt = event.occurredAt,
        updatedAt = event.occurredAt,
      )
    every { kanbanAssignmentRepository.findById("kanban-1", "supplier-1") } returns assignment
    every { kanbanAssignmentRepository.save(assignment) } just runs
    every { eventPublisher.publish(capture(published)) } just runs

    service().markSuccess(command, WfxSyncResponse(responseType = "Pass", status = "200"))

    val received = published.captured.single() as KanbanMaterialReceived
    received.items.map { it.article } shouldBe listOf("BTP CAT")
    verify(exactly = 1) { kanbanAssignmentRepository.save(assignment) }
  }

  @Test
  fun `retry failed BTP subgroup retains DocNo suffix and successful NPL receipt`() {
    val syncService = service()
    val assignment = issuedAssignment()
    val records = mutableMapOf<GdnMaterialType, KanbanGdn>()
    val attempts = mutableListOf<List<KanbanGdnSyncCommand>>()
    every { kanbanGdnRepository.findById(any(), any(), any(), any()) } answers { records[arg(3)] }
    every { kanbanGdnRepository.findAllByEvent(any(), any(), any()) } answers { records.values.toList() }
    every { kanbanGdnRepository.findAllByKanbanId("kanban-1") } answers { records.values.toList() }
    every { kanbanGdnRepository.save(any()) } answers {
      val record = firstArg<KanbanGdn>()
      records[record.materialType] = record
    }
    every { kanbanRepository.findById("kanban-1") } returns kanban()
    every { kanbanAssignmentRepository.findById("kanban-1", "supplier-1") } returns assignment
    every { kanbanAssignmentRepository.save(assignment) } just runs
    every { teamAssignmentRepository.findById("ta-1") } returns teamAssignment()
    every { buyerOrderRepository.findById("bo-1") } returns buyerOrder()
    every { billOfMaterialRepository.findByBuyerOrderId("bo-1") } returns null
    every { articleCodeResolver.resolveBtpFromLabel("LGG11ARTICLE", "BTP CAT", null) } returns
      ResolvedWfxArticle("LGG11BSDSGWWN2N1J112btpcat", "PCS")
    every { articleCodeResolver.resolve("MAT-001") } returns ResolvedWfxArticle("MAT-001-CODE", "M")
    every { executor.executeAll(capture(attempts)) } just runs
    val event = receivedEvent()
    syncService.stageReceive(event)
    val originalBtp = attempts.single().single { it.materialType == GdnMaterialType.BTP }
    val npl = attempts.single().single { it.materialType == GdnMaterialType.NPL }

    syncService.markSuccess(npl, WfxSyncResponse(status = "Success"))
    syncService.markFailed(originalBtp, "WFX unavailable")
    assignment.changes.filterIsInstance<KanbanMaterialReceived>().single().items.map { it.article } shouldBe
      listOf("MAT-001")
    assignment.allItemsDone() shouldBe false
    val retryActor = ActorRef("actor-2", "Retry user")
    syncService.retryReceive(
      event.kanbanId,
      event.supplierUnitId,
      event.occurredAt,
      GdnMaterialType.BTP,
      retryActor,
    )
    val retry = attempts.last().single()

    retry.docNoSuffix shouldBe originalBtp.docNoSuffix
    retry.docNoSuffix shouldBe "BTP"
    retry.event.occurredAt shouldBe originalBtp.event.occurredAt
    retry.event.items shouldBe originalBtp.event.items
    retry.event.actor shouldBe event.actor
    records.getValue(GdnMaterialType.BTP).receivedBy shouldBe event.actor
    records.getValue(GdnMaterialType.NPL).status shouldBe GdnStatus.SUCCESS
    syncService.markSuccess(retry, WfxSyncResponse(status = "Success"))
    syncService.markSuccess(retry, WfxSyncResponse(status = "Success"))
    assignment.allItemsDone() shouldBe true
    syncService.markFailed(retry, "Late failure")
    records.getValue(GdnMaterialType.BTP).status shouldBe GdnStatus.SUCCESS
    verify(exactly = 2) { kanbanAssignmentRepository.save(assignment) }
  }

  private fun service(btpSiteName: String? = "BTP-OUT", nplSiteName: String? = "NPL-OUT"): KanbanGdnSyncService {
    every { routingRepository.findByBuyerOrderId(any()) } returns BuyerOrderRouting("bo-1", emptyList())
    every { productionOrderRepository.findById("po-1") } returns
      ProductionOrder(
        id = "po-1",
        buyerOrderId = "bo-1",
        productionCode = "PO-01",
        factoryIds = listOf("factory-1"),
        mainCompanyCode = "COMP-1",
        status = ProductionOrderStatus.IN_PROGRESS,
        routing = listOf("CUT-1", "CAT-1"),
      )

    // Current team and factory
    every { orgUnitRepository.findById("team-1") } returns
      Team("team-1", "Team", "factory-1", "factory-1", Operation("CAT-1"), true, "TEAM-1")
    every { orgUnitRepository.findById("factory-1") } returns
      Factory("factory-1", "Factory 1", "company-1", "", "company-1", emptyList(), true, "FACT-1")

    // Source team and factory for BTP
    every { orgUnitRepository.findById("supplier-1") } returns
      Team("supplier-1", "Tổ Nguồn", "factory-source", "factory-source", Operation("CUT-1"), true, "SUPP-1")
    every { orgUnitRepository.findById("factory-source") } returns
      Factory("factory-source", "Factory Nguồn", "company-1", "", "company-1", emptyList(), true, "FACT-SOURCE")

    // Warehouses
    every { orgUnitRepository.findById("wh-npl") } returns
      Warehouse("wh-npl", "Kho NPL", "company-1", "", "company-1", true, "WH-NPL", siteName = nplSiteName)
    every { orgUnitRepository.findById("wh-btp") } returns
      Warehouse("wh-btp", "Kho BTP", "company-1", "", "company-1", true, "WH-BTP", siteName = btpSiteName)

    // Factory Operations
    every {
      factoryOperationRepository.findByFactoryIdAndOperationCode("factory-1", "CAT-1")
    } returns FactoryOperation(
      id = "op-cat-1",
      companyId = "company-1",
      companyCode = "COMPANY-1",
      factoryId = "factory-1",
      operationCode = "CAT-1",
      operationName = "Cắt",
      materialDispatchWarehouseId = "wh-npl",
    )

    every {
      factoryOperationRepository.findByFactoryIdAndOperationCode("factory-source", "CUT-1")
    } returns FactoryOperation(
      id = "op-cut-1",
      companyId = "company-1",
      companyCode = "COMPANY-1",
      factoryId = "factory-source",
      operationCode = "CUT-1",
      operationName = "Cắt Nguồn",
      btpReceiveWarehouseId = "wh-btp",
    )

    return KanbanGdnSyncService(
      kanbanRepository = kanbanRepository,
      kanbanAssignmentRepository = kanbanAssignmentRepository,
      teamAssignmentRepository = teamAssignmentRepository,
      productionOrderRepository = productionOrderRepository,
      buyerOrderRepository = buyerOrderRepository,
      productionOrderTypeQuery = productionOrderTypeQuery,
      billOfMaterialRepository = billOfMaterialRepository,
      routingRepository = routingRepository,
      kanbanGdnRepository = kanbanGdnRepository,
      articleCodeResolver = articleCodeResolver,
      orgUnitRepository = orgUnitRepository,
      factoryOperationRepository = factoryOperationRepository,
      eventPublisher = eventPublisher,
      executor = executor,
      recordBtpKanbanReceipt = mockk(relaxed = true),
    )
  }

  private fun kanban(reason: String = "") =
      mockk<Kanban> {
      every { status } returns vn.lgg.mesplus.kanban.domain.model.KanbanStatus.APPROVED
      every { ensureNotCancelled() } just runs
      every { teamAssignmentId } returns "ta-1"
      every { history } returns listOf(
        KanbanCreated(
          kanbanId = "kanban-1",
          teamAssignmentId = "ta-1",
          plan = emptyList<PlanItem>(),
          items = emptyList<KanbanItem>(),
          reason = reason,
          actor = ActorRef("actor-1", "Actor"),
        )
      )
    }

  private fun teamAssignment() =
    mockk<TeamAssignment> {
      every { buyerOrderId } returns "bo-1"
      every { productionOrderId } returns "po-1"
      every { teamId } returns "team-1"
      every { operation } returns Operation("CAT-1")
      every { allocations } returns emptyList()
    }

  private fun buyerOrder() =
    BuyerOrder(
      id = "bo-1",
      wfxId = "BO-WFX-1",
      styleName = "STYLE-1",
      revisionCode = "R1",
      revisionDate = Instant.parse("2024-07-01T00:00:00Z"),
      articleCode = "LGG11ARTICLE",
    )

  private fun receivedEvent() =
    KanbanMaterialReceived(
      kanbanId = "kanban-1",
      supplierUnitId = "supplier-1",
      items =
        listOf(
          KanbanMaterialReceived.ReceivedItem("BTP CAT", "RED", "M", "po-a", BigDecimal("3.5000")),
          KanbanMaterialReceived.ReceivedItem("MAT-001", "BLUE", "L", "po-b", BigDecimal("2.0000")),
        ),
      actor = ActorRef("actor-1", "Actor"),
      occurredAt = Instant.parse("2024-07-05T00:00:00Z"),
    )

  private fun issuedAssignment() =
    KanbanAssignment("kanban-1", "supplier-1").apply {
      loadFromHistory(
        listOf(
          KanbanAssignmentInitialized(
            "kanban-1",
            "supplier-1",
            listOf(
              KanbanAssignmentInitialized.AssignmentItem("BTP CAT", "RED", "M", "po-a", BigDecimal("3.5")),
              KanbanAssignmentInitialized.AssignmentItem("MAT-001", "BLUE", "L", "po-b", BigDecimal("2")),
            ),
            ActorRef("actor-1", "Actor"),
          ),
          KanbanMaterialPrepared(
            "kanban-1",
            "supplier-1",
            listOf(
              KanbanMaterialPrepared.PreparedItem("BTP CAT", "RED", "M", "po-a", BigDecimal("3.5"), ""),
              KanbanMaterialPrepared.PreparedItem("MAT-001", "BLUE", "L", "po-b", BigDecimal("2"), ""),
            ),
            ActorRef("actor-1", "Actor"),
          ),
          KanbanMaterialIssued(
            "kanban-1",
            "supplier-1",
            listOf(
              KanbanMaterialIssued.IssuedItem("BTP CAT", "RED", "M", "po-a", BigDecimal("3.5"), ""),
              KanbanMaterialIssued.IssuedItem("MAT-001", "BLUE", "L", "po-b", BigDecimal("2"), ""),
            ),
            ActorRef("actor-1", "Actor"),
          ),
        ),
      )
    }
}
