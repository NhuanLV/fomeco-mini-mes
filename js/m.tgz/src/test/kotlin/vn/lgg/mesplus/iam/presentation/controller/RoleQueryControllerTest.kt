package vn.lgg.mesplus.iam.presentation.controller

import io.kotest.matchers.maps.shouldContainAll
import io.mockk.mockk
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.model.PermissionGroup

class RoleQueryControllerTest {

  @Test
  fun `returns grouping metadata for every permission`() {
    val controller = RoleQueryController(mockk(), mockk())
    val permissions = controller.getPermissions()

    permissions.associate { it.code to it.groupCode } shouldContainAll
      mapOf(
        Permission.MANAGE_ACCOUNT to PermissionGroup.ADMIN,
        Permission.MANAGE_ORG to PermissionGroup.ADMIN,
        Permission.MANAGE_BUYER_ORDER to PermissionGroup.PRODUCTION_PLANNING,
        Permission.ISSUE_PRODUCTION_ORDER to PermissionGroup.PRODUCTION_PLANNING,
        Permission.VIEW_PRODUCTION_ORDER to PermissionGroup.PRODUCTION_PLANNING,
        Permission.UPDATE_COSTING to PermissionGroup.PRODUCTION_PLANNING,
        Permission.REPORT_PROGRESS to PermissionGroup.PROGRESS_REPORTING,
        Permission.VIEW_STATISTIC to PermissionGroup.PROGRESS_REPORTING,
        Permission.CREATE_KANBAN to PermissionGroup.MATERIAL_ISSUANCE,
        Permission.EVALUATE_KANBAN to PermissionGroup.MATERIAL_ISSUANCE,
        Permission.EVALUATE_EXTRA_KANBAN to PermissionGroup.MATERIAL_ISSUANCE,
        Permission.PREPARE_MATERIAL to PermissionGroup.MATERIAL_ISSUANCE,
        Permission.ISSUE_MATERIAL to PermissionGroup.MATERIAL_ISSUANCE,
        Permission.CREATE_REQUEST to PermissionGroup.INVENTORY_REQUEST,
        Permission.EVALUATE_REQUEST to PermissionGroup.INVENTORY_REQUEST,
        Permission.RECEIVE_REQUEST to PermissionGroup.INVENTORY_REQUEST,
      )

    permissions
      .associate { it.groupCode to it.groupDisplayName }
      .shouldContainAll(
        mapOf(
          PermissionGroup.ADMIN to "Quản trị hệ thống",
          PermissionGroup.PRODUCTION_PLANNING to "Đơn hàng & kế hoạch sản xuất",
          PermissionGroup.PROGRESS_REPORTING to "Tiến độ & báo cáo",
          PermissionGroup.MATERIAL_ISSUANCE to "Kanban & cấp phát vật tư",
          PermissionGroup.INVENTORY_REQUEST to "Trả lại & điều chuyển NPL",
        ),
      )
  }
}
