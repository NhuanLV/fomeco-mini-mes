package vn.lgg.mesplus.kanban.application.usecase

import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import java.math.BigDecimal
import vn.lgg.mesplus.kanban.presentation.viewmodel.BomConsumptionEntryVm
import vn.lgg.mesplus.kanban.presentation.viewmodel.CumulativeEntryVm
import vn.lgg.mesplus.iam.presentation.viewmodel.UnitRefVm
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size

class KanbanContextDslTest : StringSpec({
  "builds named context sections with collection operators" {
    val bom = BomConsumptionEntryVm("FABRIC", Color("RED"), Size("M"), BigDecimal.ONE)
    val cumulative =
      CumulativeEntryVm("FABRIC", Color("RED"), Size("M"), BigDecimal("2"))

    val context =
      kanbanContext("assignment-1") {
        this.bom += bom
        cumulative {
          required += cumulative
          receivedInStandard += cumulative
          receivedAll += cumulative
        }
        upstream("CUT-1") {
          teams += UnitRefVm("team-1", "Cut Team")
        }
        warehouses += UnitRefVm("warehouse-1", "Warehouse")
      }

    context.teamAssignmentId shouldBe "assignment-1"
    context.bomConsumption.shouldContainExactly(bom)
    context.cumulativeReported.shouldContainExactly(cumulative)
    context.cumulativeReceivedInStandard.shouldContainExactly(cumulative)
    context.cumulativeReceivedAll.shouldContainExactly(cumulative)
    context.previousOperation shouldBe "CUT-1"
    context.previousOperationTeams.shouldContainExactly(UnitRefVm("team-1", "Cut Team"))
    context.availableWarehouses.shouldContainExactly(UnitRefVm("warehouse-1", "Warehouse"))
  }
})
