package vn.lgg.mesplus.production.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.*
import java.util.UUID
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.security.access.AccessDeniedException
import org.springframework.transaction.support.TransactionSynchronizationManager
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.infrastructure.wfx.client.WfxClient
import vn.lgg.mesplus.production.application.service.*
import vn.lgg.mesplus.production.domain.model.*
import vn.lgg.mesplus.production.domain.repository.*
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size
import java.net.SocketTimeoutException
import vn.lgg.mesplus.order.infrastructure.wfx.WfxSyncException
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.service.PermissionService

class CancelProductionOrderUseCaseTest {
  private val orders = mockk<ProductionOrderRepository>()
  private val bos = mockk<BuyerOrderRepository>()
  private val assignments = mockk<TeamAssignmentRepository>()
  private val pos = mockk<PurchaseOrderRepository>()
  private val kanbans = mockk<KanbanRepository>()
  private val history = mockk<ProductionOrderActivityLog>()
  private val permissions = mockk<PermissionService>()
  private val sync = mockk<FppoSyncService>(relaxed = true)
  private val wfx = mockk<WfxClient>()
  private val updateBo = mockk<UpdateBuyerOrderStatusUseCase>(relaxed = true)
  private val events = mockk<DomainEventPublisher>(relaxed = true)
  private val executor = mockk<ProductionOrderCancellationExecutor>(relaxed = true)
  private val rows = mutableListOf<ProductionOrderActivity>()
  private val actor = Actor("actor", "Planner", "planner", "", emptyList(), emptySet())
  private val order = ProductionOrder("lsx", "bo", "LSX-1", listOf("f1", "f2"), "MAIN", ProductionOrderStatus.IN_PROGRESS)
  private val useCase = CancelProductionOrderUseCase(orders, bos, assignments, pos, kanbans, history,
    permissions, { UUID.randomUUID() }, sync, wfx, updateBo, events, executor)

  @BeforeEach
  fun setup() {
    TransactionSynchronizationManager.initSynchronization()
    every { orders.findById("lsx") } returns order
    every { orders.lockById("lsx") } returns order
    every { orders.save(any()) } answers { firstArg() }
    val bo = mockk<BuyerOrder> { every { wfxId } returns "WFX-BO" }
    every { bos.lockById("bo") } returns bo
    every { bos.findById("bo") } returns bo
    every { permissions.requirePermission(any(), any(), any()) } just Runs
    every { history.findByProductionOrderId("lsx") } answers { rows.reversed() }
    every { history.append(any()) } answers { rows.add(firstArg()); Unit }
    every { history.updateSync(any()) } answers {
      val row = firstArg<ProductionOrderActivity>()
      rows[rows.indexOfFirst { it.id == row.id }] = row
    }
    every { kanbans.countNotCancelled(any()) } returns 0
    every { assignments.findByProductionOrderId("lsx") } returns listOf(assignment("lsx"))
    every { assignments.findByBuyerOrderId("bo") } returns listOf(assignment("lsx"))
    every { pos.findByBuyerOrderId("bo") } returns listOf(mockk<PurchaseOrder> {
      every { id } returns "po"
      every { type } returns PurchaseOrderType.REGULAR
    })
    every { wfx.checkFppoCancellation("WFX-BO", "MAIN") } returns "Không còn FPPO phù hợp"
  }

  @AfterEach
  fun cleanup() { TransactionSynchronizationManager.clearSynchronization() }

  @Test
  fun `stage commits pending before scheduling and success cancels last order without SaveData`() {
    val request = useCase.execute("lsx", " Đổi kế hoạch ", actor)
    request.syncStatus shouldBe ProductionOrderActivitySyncStatus.PENDING
    request.note shouldBe "Đổi kế hoạch"
    order.status shouldBe ProductionOrderStatus.IN_PROGRESS
    shouldThrow<IllegalStateException> { useCase.execute("lsx", "Bấm đôi", actor) }
    rows.size shouldBe 1
    verify(exactly = 0) { events.publish(any<DomainEvent>()) }
    verify(exactly = 0) { executor.execute(any(), any()) }
    TransactionSynchronizationManager.getSynchronizations().forEach { it.afterCommit() }
    verify(exactly = 1) { executor.execute("lsx", request.id) }
    useCase.process("lsx", request.id)
    order.status shouldBe ProductionOrderStatus.CANCELLED
    rows.single().syncStatus shouldBe ProductionOrderActivitySyncStatus.SUCCESS
    rows.single().syncMessage shouldBe "Không còn FPPO phù hợp"
    verify(exactly = 0) { sync.syncFppo(any(), any(), any(), any(), any()) }
    verify(exactly = 1) { updateBo.execute("bo") }
  }

  @Test
  fun `failed cancellation accepts a new request and preserves previous failures`() {
    val first = useCase.execute("lsx", "Sai kế hoạch", actor)
    every { wfx.checkFppoCancellation(any(), any()) } throws IllegalStateException("FPPO 123 (Completed)")
    shouldThrow<IllegalStateException> { useCase.process("lsx", first.id) }
    useCase.markFailed("lsx", first.id, "FPPO 123 (Completed)")
    order.status shouldBe ProductionOrderStatus.IN_PROGRESS
    rows.single().syncStatus shouldBe ProductionOrderActivitySyncStatus.FAILED
    val second = useCase.execute("lsx", "Yêu cầu mới", actor)
    useCase.process("lsx", first.id)
    order.status shouldBe ProductionOrderStatus.IN_PROGRESS
    (second.id != first.id) shouldBe true
    second.note shouldBe "Yêu cầu mới"
    shouldThrow<IllegalStateException> { useCase.execute("lsx", "Bấm đôi", actor) }
    useCase.markFailed("lsx", second.id, "WFX lỗi")
    val third = useCase.execute("lsx", "Đã xử lý WFX", actor)
    every { wfx.checkFppoCancellation(any(), any()) } returns "Không còn FPPO phù hợp"
    useCase.process("lsx", third.id)
    rows.size shouldBe 3
    rows.first().syncMessage shouldBe "FPPO 123 (Completed)"
    rows[1].syncMessage shouldBe "WFX lỗi"
    rows.last().syncStatus shouldBe ProductionOrderActivitySyncStatus.SUCCESS
    order.status shouldBe ProductionOrderStatus.CANCELLED
  }

  @Test
  fun `new kanban between staging and worker prevents WFX and cancellation`() {
    val row = useCase.execute("lsx", "Đổi kế hoạch", actor)
    every { kanbans.countNotCancelled(any()) } returns 3
    shouldThrow<IllegalStateException> { useCase.process("lsx", row.id) }.message!!
      .contains("3 kanban") shouldBe true
    verify(exactly = 0) { wfx.checkFppoCancellation(any(), any()) }
    order.status shouldBe ProductionOrderStatus.IN_PROGRESS
  }

  @Test
  fun `positive only cancels immediately without WFX or worker`() {
    every { pos.findByBuyerOrderId("bo") } returns listOf(mockk {
      every { id } returns "po"
      every { type } returns PurchaseOrderType.POSITIVE
    })
    val row = useCase.execute("lsx", "Dừng", actor)
    row.syncStatus shouldBe ProductionOrderActivitySyncStatus.NOT_APPLICABLE
    order.status shouldBe ProductionOrderStatus.CANCELLED
    TransactionSynchronizationManager.getSynchronizations().size shouldBe 0
    verify(exactly = 0) { wfx.checkFppoCancellation(any(), any()) }
  }

  @Test
  fun `executor records timeout failure without cancelling or notifying`() {
    val row = useCase.execute("lsx", "Dừng", actor)
    every { wfx.checkFppoCancellation(any(), any()) } throws
      WfxSyncException.infrastructure(SocketTimeoutException("read timed out"))
    ProductionOrderCancellationExecutor(useCase).execute("lsx", row.id)
    order.status shouldBe ProductionOrderStatus.IN_PROGRESS
    rows.single().syncStatus shouldBe ProductionOrderActivitySyncStatus.FAILED
    rows.single().syncMessage!!.contains("read timed out") shouldBe true
    verify(exactly = 0) { events.publish(any<DomainEvent>()) }
  }

  @Test
  fun `new request recomputes branch and completed sibling still contributes`() {
    val row = useCase.execute("lsx", "Dừng", actor)
    useCase.markFailed("lsx", row.id, "WFX lỗi")
    val sibling = ProductionOrder("other", "bo", "LSX-2", listOf("f1"), "MAIN", ProductionOrderStatus.COMPLETED)
    every { orders.findById("other") } returns sibling
    every { assignments.findByBuyerOrderId("bo") } returns listOf(assignment("lsx"), assignment("other"))
    val next = useCase.execute("lsx", "Hủy lại", actor)
    useCase.process("lsx", next.id)
    verify(exactly = 1) { sync.syncFppo("bo", "MAIN", emptyList(), null, "lsx") }
    verify(exactly = 0) { wfx.checkFppoCancellation(any(), any()) }
    order.status shouldBe ProductionOrderStatus.CANCELLED
  }

  @Test
  fun `new cancellation checks every factory and blank reason never adds history`() {
    val row = useCase.execute("lsx", "Dừng", actor)
    useCase.markFailed("lsx", row.id, "Lỗi")
    shouldThrow<IllegalArgumentException> { useCase.execute("lsx", " ", actor) }
    rows.single().id shouldBe row.id
    every { permissions.requirePermission(any(), any(), any()) } answers {
      if (thirdArg<() -> List<String>>().invoke() == listOf("f2")) throw AccessDeniedException("Không có quyền")
    }
    shouldThrow<AccessDeniedException> { useCase.execute("lsx", "Hủy lại", actor) }
    rows.size shouldBe 1
    rows.single().syncStatus shouldBe ProductionOrderActivitySyncStatus.FAILED
  }

  private fun assignment(orderId: String) = mockk<TeamAssignment> {
    every { id } returns "ta-$orderId"
    every { productionOrderId } returns orderId
    every { allocations } returns listOf(SkuAllocation("po", Color("Red"), Size("S"), 10))
  }
}
