package vn.lgg.mesplus.app.exception

import io.kotest.matchers.shouldBe
import org.junit.jupiter.api.Test
import org.springframework.http.HttpStatus
import vn.lgg.mesplus.order.infrastructure.wfx.WfxSyncException

class GlobalExceptionHandlerTest {
  @Test
  fun `returns WFX error message to the client`() {
    val response = GlobalExceptionHandler().handleWfxSync(
      WfxSyncException.business("Invalid FPPO"),
    )

    response.statusCode shouldBe HttpStatus.BAD_GATEWAY
    response.body?.message shouldBe "WFX từ chối tạo phiếu: Invalid FPPO"
  }
}
