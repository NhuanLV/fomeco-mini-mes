package vn.lgg.mesplus.notification

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import java.time.Instant
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.shared.Activity
import vn.lgg.mesplus.shared.NotificationTarget
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.ActorRef

class NotificationServiceTest {
  private val repository = FakeNotificationRepository()
  private val service = NotificationService(repository)

  @Test
  fun `lists ten notifications and returns a cursor when another item exists`() {
    val notifications = (1..11).map { notification(it) }
    repository.notifications.addAll(notifications)

    val page = service.list("recipient-1", unreadOnly = false, cursor = null, size = 10)

    page.items shouldContainExactly notifications.take(10)
    page.nextCursor shouldBe NotificationCursor.encode(notifications[9])
    page.unreadCount shouldBe 11
  }

  @Test
  fun `passes a decoded cursor to the repository`() {
    val cursorNotification = notification(10)
    val cursor = NotificationCursor.encode(cursorNotification)

    service.list("recipient-1", unreadOnly = true, cursor = cursor, size = 10)

    repository.lastQuery shouldBe
      NotificationQuery("recipient-1", unreadOnly = true, NotificationCursor.decode(cursor), 11)
  }

  @Test
  fun `does not return a cursor on the final page`() {
    repository.notifications += notification(1)

    val page = service.list("recipient-1", unreadOnly = false, cursor = null, size = 10)

    page.nextCursor shouldBe null
  }

  @Test
  fun `rejects malformed cursors`() {
    shouldThrow<IllegalArgumentException> {
      service.list("recipient-1", unreadOnly = false, cursor = "not-a-cursor", size = 10)
    }
  }

  @Test
  fun `rejects page sizes outside one to ten`() {
    shouldThrow<IllegalArgumentException> {
      service.list("recipient-1", unreadOnly = false, cursor = null, size = 11)
    }
  }

  @Test
  fun `marks the current recipients notification read idempotently`() {
    repository.notifications += notification(1)

    service.markAsRead("notification-1", "recipient-1")
    service.markAsRead("notification-1", "recipient-1")

    repository.notifications.single().isRead shouldBe true
  }

  @Test
  fun `marks every notification for the same recipient and target read`() {
    repository.notifications += notification(1)
    repository.notifications += notification(2, resourceId = "assignment-1")
    repository.notifications += notification(3)
    repository.notifications += notification(4, recipientId = "recipient-2", resourceId = "assignment-1")

    service.markAsRead("notification-1", "recipient-1")

    repository.notifications.map { it.isRead } shouldContainExactly
      listOf(true, true, false, false)
  }

  @Test
  fun `does not reveal another recipients notification`() {
    repository.notifications += notification(1)

    shouldThrow<NoSuchElementException> {
      service.markAsRead("notification-1", "recipient-2")
    }
  }

  @Test
  fun `marks notifications by target without requiring a notification id`() {
    repository.notifications += notification(1, resourceId = "assignment-1")
    repository.notifications += notification(2, resourceId = "assignment-1")
    repository.notifications += notification(3, resourceId = "assignment-2")

    service.markTargetAsRead(
      NotificationTarget(ResourceType.TEAM_ASSIGNMENT, "assignment-1"),
      "recipient-1",
    )

    repository.notifications.map { it.isRead } shouldContainExactly listOf(true, true, false)
  }

  @Test
  fun `marking a target without notifications is idempotent`() {
    service.markTargetAsRead(
      NotificationTarget(ResourceType.PRODUCTION_ORDER, "production-order-1"),
      "recipient-1",
    )
  }

  @Test
  fun `marks all notifications read only for the current recipient`() {
    repository.notifications += notification(1)
    repository.notifications += notification(2)
    repository.notifications += notification(3, recipientId = "recipient-2")

    service.markAllAsRead("recipient-1")

    repository.notifications.map { it.isRead } shouldContainExactly listOf(true, true, false)
  }

  private fun notification(
    index: Int,
    recipientId: String = "recipient-1",
    resourceId: String = "assignment-$index",
  ) =
    Notification(
      id = "notification-$index",
      recipientId = recipientId,
      activity =
        Activity(
          actor = ActorRef("actor-1", "Planner"),
          title = "LSX mới",
          body = "đã giao LSX LSX-$index cho tổ của bạn",
          target = NotificationTarget(ResourceType.TEAM_ASSIGNMENT, resourceId),
        ),
      isRead = false,
      createdAt = Instant.parse("2026-01-${index.toString().padStart(2, '0')}T00:00:00Z"),
    )
}

private class FakeNotificationRepository : NotificationRepository {
  val notifications = mutableListOf<Notification>()
  var lastQuery: NotificationQuery? = null

  override fun saveAll(notifications: List<Notification>): List<Notification> {
    this.notifications += notifications
    return notifications
  }

  override fun find(query: NotificationQuery): List<Notification> {
    lastQuery = query
    return notifications.take(query.limit)
  }

  override fun countUnread(recipientId: String): Long =
    notifications.count { it.recipientId == recipientId && !it.isRead }.toLong()

  override fun markAsRead(id: String, recipientId: String): Boolean {
    val target =
      notifications.find { it.id == id && it.recipientId == recipientId }?.activity?.target
        ?: return false
    notifications.replaceAll {
      if (it.recipientId == recipientId && it.activity.target == target) it.copy(isRead = true)
      else it
    }
    return true
  }

  override fun markTargetAsRead(target: NotificationTarget, recipientId: String) {
    notifications.replaceAll {
      if (it.recipientId == recipientId && it.activity.target == target) it.copy(isRead = true)
      else it
    }
  }

  override fun markAllAsRead(recipientId: String) {
    notifications.replaceAll {
      if (it.recipientId == recipientId) it.copy(isRead = true) else it
    }
  }
}
