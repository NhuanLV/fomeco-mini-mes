package vn.lgg.mesplus.kanban.application.usecase

import io.kotest.matchers.collections.shouldHaveSize
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.time.Instant
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.app.config.property.WfxProperties
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialReceived
import vn.lgg.mesplus.kanban.domain.model.GdnMode
import vn.lgg.mesplus.kanban.domain.model.GdnMaterialType
import vn.lgg.mesplus.order.infrastructure.wfx.FppoResolver
import vn.lgg.mesplus.order.infrastructure.wfx.WfxSyncException
import vn.lgg.mesplus.order.infrastructure.wfx.client.WfxClient
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.GdnRequest
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.FppoDetailDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.WfxSyncResponse
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Operation

class KanbanGdnSyncExecutorTest {
  private val service = mockk<KanbanGdnSyncService>(relaxed = true)
  private val fppoResolver = mockk<FppoResolver>()
  private val wfxClient = mockk<WfxClient>()
  private val executor =
    KanbanGdnSyncExecutor(
      service,
      fppoResolver,
      wfxClient,
      WfxProperties(
        baseUrl = "https://example.com",
        apiKey = "api-key",
        secretKey = "secret-key",
        companyName = "LGG",
        companyCode = "54400",
        gdnName = "admin",
        gdnPassword = "secret",
        fpoName = "fpo-user",
        fpoPassword = "fpo-secret",
        fpoCompanyId = "fpo-company",
      ),
    )

  @Test
  fun `maps GDN snapshot to WFX payload`() {
    val payload = slot<GdnRequest>()
    every { fppoResolver.resolve("BO-WFX-1", Operation("SEW-1")) } returns
      FppoDetailDto(
        fppoNo = "6840",
        dispatchSiteName = "LGG - CUT3",
        uom = "Pcs",
      )
    every { wfxClient.createGdn(capture(payload)) } returns WfxSyncResponse(wfxStatus = "Success")

    executor.execute(command())

    payload.captured.data.single().docNo shouldBe "KB-kanban-1-supplier-1-1720137600000"
    payload.captured.data.single().docDate shouldBe "2024/07/05"
    payload.captured.data.single().companyId shouldBe "lggbg"
    payload.captured.data.single().toFppoNo shouldBe "6840"
    payload.captured.data.single().dispatchedSite shouldBe "CONFIGURED-BTP"
    payload.captured.data.single().location shouldBe ""
    payload.captured.data.single().materialType shouldBe "ALL"
    payload.captured.data.single().articleData shouldHaveSize 2
    payload.captured.data.single().articleData[0].articleCode shouldBe "LGG11ARTICLEbtpcat"
    payload.captured.data.single().articleData[0].dispatchedQty shouldBe "3.5"
    payload.captured.data.single().articleData[0].uom shouldBe "Pcs"
    payload.captured.data.single().articleData[1].uom shouldBe "M"
    verify { service.markSuccess(any(), any()) }
  }

  @Test
  fun `uses configured material dispatch site for an NPL-only GDN`() {
    val payload = slot<GdnRequest>()
    every { fppoResolver.resolve("BO-WFX-1", Operation("SEW-1")) } returns
      FppoDetailDto(
        fppoNo = "6840",
        dispatchSiteName = "LGG - CUT3",
        uom = "Pcs",
      )
    every { wfxClient.createGdn(capture(payload)) } returns WfxSyncResponse(wfxStatus = "Success")

    executor.execute(
      command().copy(
        materialType = GdnMaterialType.ALL,
        items = listOf(command().items.last()),
        dispatchedSite = "CONFIGURED-NPL",
      ),
    )

    payload.captured.data.single().dispatchedSite shouldBe "CONFIGURED-NPL"
    payload.captured.data.single().articleData.single().articleCode shouldBe "MAT-001-CODE"
  }

  @Test
  fun `adds material suffix to DocNo for a split GDN`() {
    val payload = slot<GdnRequest>()
    every { fppoResolver.resolve("BO-WFX-1", Operation("SEW-1")) } returns
      FppoDetailDto(
        fppoNo = "6840",
        dispatchSiteName = "LGG - CUT3",
        uom = "Pcs",
      )
    every { wfxClient.createGdn(capture(payload)) } returns WfxSyncResponse(wfxStatus = "Success")

    executor.execute(command().copy(materialType = GdnMaterialType.BTP, docNoSuffix = "BTP"))

    payload.captured.data.single().docNo shouldBe "KB-kanban-1-supplier-1-1720137600000-BTP"
    payload.captured.data.single().dispatchedSite shouldBe "CONFIGURED-BTP"
  }

  @Test
  fun `uses configured site for finishing team receiving BTP`() {
    val payload = slot<GdnRequest>()
    every { fppoResolver.resolve("BO-WFX-1", Operation("FIN-1")) } returns
      FppoDetailDto(
        fppoNo = "6842",
        dispatchSiteName = "LGG - SEW1",
        uom = "Pcs",
      )
    every { wfxClient.createGdn(capture(payload)) } returns WfxSyncResponse(wfxStatus = "Success")

    executor.execute(
      command().copy(operation = Operation("FIN-1"), dispatchedSite = "CONFIGURED-FIN-BTP"),
    )

    payload.captured.data.single().dispatchedSite shouldBe "CONFIGURED-FIN-BTP"
  }

  @Test
  fun `uses source operation FPPO UOM for BTP item in GDN payload`() {
    val payload = slot<GdnRequest>()
    every { fppoResolver.resolve("BO-WFX-1", Operation("SEW-1")) } returns
      FppoDetailDto(
        fppoNo = "6841",
        dispatchSiteName = "LGG - SEW1",
        uom = "Sets",
      )
    every { fppoResolver.resolve("BO-WFX-1", Operation("CUT-1")) } returns
      FppoDetailDto(
        fppoNo = "6840",
        dispatchSiteName = "LGG - CUT1",
        uom = "Pcs",
      )
    every { wfxClient.createGdn(capture(payload)) } returns WfxSyncResponse(wfxStatus = "Success")

    val cmd = KanbanGdnSyncCommand(
      event =
        KanbanMaterialReceived(
          kanbanId = "kanban-1",
          supplierUnitId = "supplier-1",
          items = emptyList(),
          actor = ActorRef("actor-1", "Actor"),
          occurredAt = Instant.parse("2024-07-05T00:00:00Z"),
        ),
      mode = GdnMode.AUTO,
      createdAt = Instant.parse("2024-07-05T00:00:00Z"),
      buyerOrderWfxId = "BO-WFX-1",
      operation = Operation("SEW-1"),
      dispatchedSite = "CONFIGURED-BTP",
      materialType = GdnMaterialType.BTP,
      items =
        listOf(
          KanbanGdnItem("LGG11ARTICLEbtpcat", "RED", "M", "PCS", "3.5", isBtp = true, sourceOperation = Operation("CUT-1")),
        ),
    )

    executor.execute(cmd)

    payload.captured.data.single().toFppoNo shouldBe "6841"
    payload.captured.data.single().dispatchedSite shouldBe "CONFIGURED-BTP"
    payload.captured.data.single().articleData[0].uom shouldBe "Pcs"
  }

  @Test
  fun `marks GDN failed when WFX rejects the request`() {
    every { fppoResolver.resolve("BO-WFX-1", Operation("SEW-1")) } returns
      FppoDetailDto(
        fppoNo = "6840",
        dispatchSiteName = "LGG - CUT3",
        uom = "Pcs",
      )
    every { wfxClient.createGdn(any()) } throws WfxSyncException.business("WFX failed")

    executor.execute(command())

    verify { service.markFailed(any(), "WFX từ chối tạo phiếu: WFX failed") }
  }

  private fun command() =
    KanbanGdnSyncCommand(
      event =
        KanbanMaterialReceived(
          kanbanId = "kanban-1",
          supplierUnitId = "supplier-1",
          items = emptyList(),
          actor = ActorRef("actor-1", "Actor"),
          occurredAt = Instant.parse("2024-07-05T00:00:00Z"),
        ),
      mode = GdnMode.AUTO,
      createdAt = Instant.parse("2024-07-05T00:00:00Z"),
      buyerOrderWfxId = "BO-WFX-1",
      operation = Operation("SEW-1"),
      dispatchedSite = "CONFIGURED-BTP",
      materialType = GdnMaterialType.ALL,
      items =
        listOf(
          KanbanGdnItem("LGG11ARTICLEbtpcat", "RED", "M", "PCS", "3.5", isBtp = true),
          KanbanGdnItem("MAT-001-CODE", "BLUE", "L", "M", "2", isBtp = false),
        ),
    )
}
