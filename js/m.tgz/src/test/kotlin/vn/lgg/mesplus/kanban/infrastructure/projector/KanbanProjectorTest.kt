package vn.lgg.mesplus.kanban.infrastructure.projector

import io.mockk.Runs
import io.mockk.every
import io.mockk.just
import io.mockk.mockk
import io.mockk.verify
import java.time.Instant
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.application.UpstreamBtpResolver
import vn.lgg.mesplus.kanban.domain.event.ExtraKanbanApproved
import vn.lgg.mesplus.kanban.domain.event.KanbanApproved
import vn.lgg.mesplus.kanban.domain.event.KanbanCompleted
import vn.lgg.mesplus.kanban.domain.event.KanbanRejected
import vn.lgg.mesplus.kanban.domain.model.KanbanStatus
import vn.lgg.mesplus.kanban.infrastructure.repository.KanbanViewRepository
import vn.lgg.mesplus.kanban.presentation.viewmodel.KanbanDetailVm
import vn.lgg.mesplus.kanban.presentation.viewmodel.PlanItemVm
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.production.domain.service.BomCalculationService
import vn.lgg.mesplus.shared.model.ActorRef

import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size
import java.math.BigDecimal
import org.junit.jupiter.api.Assertions.assertEquals
import vn.lgg.mesplus.kanban.application.ResolvedUpstreamBtp
import vn.lgg.mesplus.kanban.domain.event.KanbanCreated
import vn.lgg.mesplus.kanban.domain.event.KanbanRevised
import vn.lgg.mesplus.kanban.domain.model.KanbanItem
import vn.lgg.mesplus.kanban.domain.model.KanbanItemType
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.model.SkuAllocation

class KanbanProjectorTest {
  private val kanbanViewRepository = mockk<KanbanViewRepository>()
  private val bomCalculationService = mockk<BomCalculationService>()
  private val buyerOrderRepository = mockk<BuyerOrderRepository>()
  private val purchaseOrderRepository = mockk<PurchaseOrderRepository>()
  private val teamAssignmentRepository = mockk<TeamAssignmentRepository>()
  private val productionOrderRepository = mockk<ProductionOrderRepository>()
  private val upstreamBtpResolver = mockk<UpstreamBtpResolver>()

  private val projector =
    KanbanProjector(
      kanbanViewRepository = kanbanViewRepository,
      bomCalculationService = bomCalculationService,
      buyerOrderRepository = buyerOrderRepository,
      purchaseOrderRepository = purchaseOrderRepository,
      teamAssignmentRepository = teamAssignmentRepository,
      productionOrderRepository = productionOrderRepository,
      upstreamBtpResolver = upstreamBtpResolver,
      kanbanRepository = mockk {
        every { lockAndLoad(any()) } returns mockk(relaxed = true)
        every { findById(any()) } returns null
      },
    )

  @Test
  fun `cancellation projects cancelled status and ignores late approval`() {
    val repository = mockk<vn.lgg.mesplus.kanban.domain.repository.KanbanRepository>()
    every { repository.lockAndLoad("kb-1") } returns mockk {
      every { status } returns KanbanStatus.CANCELLED
    }
    every { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.CANCELLED) } just Runs
    val cancelledProjector = KanbanProjector(kanbanViewRepository, bomCalculationService,
      buyerOrderRepository, purchaseOrderRepository, teamAssignmentRepository,
      productionOrderRepository, upstreamBtpResolver, repository)

    cancelledProjector.handle(vn.lgg.mesplus.kanban.domain.event.KanbanCancelled(
      "kb-1", "Đổi kế hoạch", KanbanStatus.APPROVED, ActorRef("actor-1", "Actor")))
    cancelledProjector.handle(KanbanApproved("kb-1", ActorRef("actor-1", "Actor")))

    verify(exactly = 1) { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.CANCELLED) }
    verify(exactly = 0) { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.APPROVED) }
  }

  @Test
  fun `BTP only kanban is projected and revised when there are no NPL materials`() {
    val assignment = mockk<TeamAssignment>()
    every { assignment.productionOrderId } returns "production-1"
    every { assignment.buyerOrderId } returns "buyer-1"
    every { assignment.teamId } returns "team-1"
    every { teamAssignmentRepository.findById("ta-1") } returns assignment
    every { bomCalculationService.calculateRaw("ta-1") } returns null
    every { bomCalculationService.getUomByArticle("ta-1") } returns emptyMap()
    every { productionOrderRepository.findById("production-1") } returns null
    every { buyerOrderRepository.findById("buyer-1") } returns null
    every { upstreamBtpResolver.resolve(assignment, null) } returns ResolvedUpstreamBtp(
      "CUT-1", emptyList(), listOf(SkuAllocation("po-1", Color("RED"), Size("M"), 100)),
    )
    every { kanbanViewRepository.sumRequiredByTeamAssignment("ta-1") } returns emptyMap()
    var saved: KanbanDetailVm? = null
    every { kanbanViewRepository.save(any()) } answers { saved = firstArg() }
    val item = KanbanItem(
      "BTP CUT-1", Color("RED"), Size("M"), null,
      KanbanItemType.SEMI_FINISHED_PRODUCT, BigDecimal.TEN, "supplier-1", "",
    )

    projector.handle(KanbanCreated("kb-1", "ta-1", emptyList(), listOf(item), "Xin BTP", actor = ActorRef("user-1", "User")))

    val created = requireNotNull(saved) { "BTP-only Kanban must be visible in the read model" }
    assertEquals(BigDecimal("100.0000"), created.items.single().totalConsumption)
    assertEquals(BigDecimal("10.0000"), created.items.single().parts.single().requiredQty)

    every { kanbanViewRepository.findById("kb-1") } returns created.copy(status = KanbanStatus.REJECTED)
    saved = null
    projector.handle(KanbanRevised("kb-1", actor = ActorRef("user-1", "User"), changedItems = listOf(item.copy(requiredQty = BigDecimal("20")))))

    val revised = requireNotNull(saved) { "BTP-only Kanban revision must update the read model" }
    assertEquals(KanbanStatus.PENDING_EVALUATION, revised.status)
    assertEquals(BigDecimal("20.0000"), revised.items.single().parts.single().requiredQty)
  }

  @Test
  fun `onKanbanCompleted updates status only without wiping child view tables`() {
    every { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.COMPLETED) } just Runs

    projector.handle(KanbanCompleted(kanbanId = "kb-1", actor = ActorRef("actor-1", "Actor")))

    verify(exactly = 1) { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.COMPLETED) }
    verify(exactly = 0) { kanbanViewRepository.save(any()) }
  }

  @Test
  fun `onKanbanApproved for standard kanban updates status to APPROVED without saving whole vm`() {
    val vm = createDummyVm(hasPlan = true)
    every { kanbanViewRepository.findById("kb-1") } returns vm
    every { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.APPROVED) } just Runs

    projector.handle(KanbanApproved(kanbanId = "kb-1", actor = ActorRef("actor-1", "Actor")))

    verify(exactly = 1) { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.APPROVED) }
    verify(exactly = 0) { kanbanViewRepository.save(any()) }
  }

  @Test
  fun `onKanbanApproved for extra kanban updates status to PENDING_EXTRA_EVALUATION`() {
    val vm = createDummyVm(hasPlan = false)
    every { kanbanViewRepository.findById("kb-1") } returns vm
    every { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.PENDING_EXTRA_EVALUATION) } just Runs

    projector.handle(KanbanApproved(kanbanId = "kb-1", actor = ActorRef("actor-1", "Actor")))

    verify(exactly = 1) { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.PENDING_EXTRA_EVALUATION) }
    verify(exactly = 0) { kanbanViewRepository.save(any()) }
  }

  @Test
  fun `onExtraKanbanApproved updates status to APPROVED without saving whole vm`() {
    every { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.APPROVED) } just Runs

    projector.handle(ExtraKanbanApproved(kanbanId = "kb-1", actor = ActorRef("actor-1", "Actor")))

    verify(exactly = 1) { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.APPROVED) }
    verify(exactly = 0) { kanbanViewRepository.save(any()) }
  }

  @Test
  fun `onKanbanRejected updates status to REJECTED without saving whole vm`() {
    every { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.REJECTED) } just Runs

    projector.handle(KanbanRejected(kanbanId = "kb-1", actor = ActorRef("actor-1", "Actor"), reason = "Rejected"))

    verify(exactly = 1) { kanbanViewRepository.updateStatus("kb-1", KanbanStatus.REJECTED) }
    verify(exactly = 0) { kanbanViewRepository.save(any()) }
  }

  private fun createDummyVm(hasPlan: Boolean) =
    KanbanDetailVm(
      id = "kb-1",
      teamAssignmentId = "ta-1",
      teamId = "team-1",
      teamName = "Team 1",
      styleName = "Style 1",
      productionOrderCode = "PO-01",
      kanbanType = if (hasPlan) "STANDARD" else "EXTRA",
      status = KanbanStatus.PENDING_EVALUATION,
      plan =
        if (hasPlan) listOf(PlanItemVm(purchaseOrderId = "po-1", purchaseOrderCode = "PO1", color = Color("RED"), size = Size("M"), qty = 10))
        else emptyList(),
      items = emptyList(),
      createdAt = Instant.now(),
      createdById = "user-1",
      createdByName = "User 1",
    )
}
