package vn.lgg.mesplus.iam.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.kotest.matchers.string.shouldContain
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import org.springframework.security.crypto.password.PasswordEncoder
import vn.lgg.mesplus.iam.domain.model.Account
import vn.lgg.mesplus.iam.domain.repository.AccountRepository
import vn.lgg.mesplus.shared.model.Actor

class ProfileUseCasesTest {
  private val accountRepo = mockk<AccountRepository>(relaxed = true)
  private val passwordEncoder = mockk<PasswordEncoder>()

  private val actor =
    Actor(
      id = "user-123",
      name = "Nguyễn Văn A",
      _username = "user_a",
      _password = "",
      memberships = emptyList(),
      permissions = emptySet(),
    )

  @Test
  fun `change password successfully when current password matches`() {
    val account = Account(id = "user-123", name = "Nguyễn Văn A", username = "user_a", password = "hashed_old_pwd")
    every { accountRepo.findById("user-123") } returns account
    every { passwordEncoder.matches("old_password_123", "hashed_old_pwd") } returns true
    every { passwordEncoder.encode("new_password_456") } returns "hashed_new_pwd"

    val useCase = ChangeMyPasswordUseCase(accountRepo, passwordEncoder)
    useCase.execute(
      ChangeMyPasswordCommand(currentPassword = "old_password_123", newPassword = "new_password_456"),
      actor,
    )

    account.password shouldBe "hashed_new_pwd"
    verify { accountRepo.save(account) }
  }

  @Test
  fun `change password fails when current password is incorrect`() {
    val account = Account(id = "user-123", name = "Nguyễn Văn A", username = "user_a", password = "hashed_old_pwd")
    every { accountRepo.findById("user-123") } returns account
    every { passwordEncoder.matches("wrong_pwd", "hashed_old_pwd") } returns false

    val useCase = ChangeMyPasswordUseCase(accountRepo, passwordEncoder)
    val ex = shouldThrow<IllegalArgumentException> {
      useCase.execute(
        ChangeMyPasswordCommand(currentPassword = "wrong_pwd", newPassword = "new_password_456"),
        actor,
      )
    }

    ex.message shouldContain "Mật khẩu hiện tại không chính xác"
  }

  @Test
  fun `change password fails when new password has less than 6 chars`() {
    val useCase = ChangeMyPasswordUseCase(accountRepo, passwordEncoder)
    val ex = shouldThrow<IllegalArgumentException> {
      useCase.execute(
        ChangeMyPasswordCommand(currentPassword = "old_password_123", newPassword = "12345"),
        actor,
      )
    }

    ex.message shouldContain "Mật khẩu mới phải có ít nhất 6 ký tự"
  }

  @Test
  fun `change password fails when new password matches current password`() {
    val useCase = ChangeMyPasswordUseCase(accountRepo, passwordEncoder)
    val ex = shouldThrow<IllegalArgumentException> {
      useCase.execute(
        ChangeMyPasswordCommand(currentPassword = "same_password_123", newPassword = "same_password_123"),
        actor,
      )
    }

    ex.message shouldContain "Mật khẩu mới không được trùng với mật khẩu hiện tại"
  }
}
