package vn.lgg.mesplus.inventory.application.eventhandler

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.clearMocks
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.math.BigDecimal
import java.time.LocalDate
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestApproved
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestCreated
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestRejected
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestUpdated
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestApproved
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestCreated
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestRejected
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestUpdated
import vn.lgg.mesplus.inventory.domain.model.returnrequest.ReturnRequest
import vn.lgg.mesplus.inventory.domain.model.returnrequest.ReturnRequestItem
import vn.lgg.mesplus.inventory.domain.model.transferrequest.TransferRequest
import vn.lgg.mesplus.inventory.domain.model.transferrequest.TransferRequestItem
import vn.lgg.mesplus.inventory.domain.repository.ReturnRequestRepository
import vn.lgg.mesplus.inventory.domain.repository.TransferRequestRepository
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.Activity
import vn.lgg.mesplus.shared.Notifier
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.PermissionService

class InventoryRequestNotificationTest {
  private val returnRepository = mockk<ReturnRequestRepository>()
  private val transferRepository = mockk<TransferRequestRepository>()
  private val assignmentRepository = mockk<TeamAssignmentRepository>()
  private val permissionService = mockk<PermissionService>()
  private val notifier = mockk<Notifier>(relaxed = true)
  private val creator =
    InventoryRequestNotificationCreator(
      returnRepository,
      transferRepository,
      assignmentRepository,
      permissionService,
      notifier,
    )
  private val requester = ActorRef("requester-1", "Tổ trưởng")
  private val approver = ActorRef("approver-1", "Quản đốc")

  @BeforeEach
  fun setUp() {
    clearMocks(notifier)
    every { assignmentRepository.findById("source-assignment") } returns
      assignment("source-assignment", "source-team")
    every { permissionService.lookupAccountIds(Permission.EVALUATE_REQUEST, "source-team") } returns
      listOf("evaluator-1")
  }

  @Test
  fun `return create and resubmit notify source team evaluators`() {
    val request = returnRequest()
    every { returnRepository.findById("return-1") } returns request

    creator.create(request.allEvents.filterIsInstance<ReturnRequestCreated>().single())
    request.reject("Sai", approver)
    request.update(returnItems(), requester)
    creator.create(request.changes.filterIsInstance<ReturnRequestUpdated>().single())

    verify(exactly = 2) {
      notifier.notify(match<Collection<String>> { it.toList() == listOf("evaluator-1") }, any())
    }
  }

  @Test
  fun `return approval groups receiver permissions and rejection targets creator`() {
    val approved = returnRequest().apply { approve(approver) }
    every { returnRepository.findById("return-1") } returns approved
    every { permissionService.lookupAccountIds(Permission.RECEIVE_REQUEST, "receiver-1") } returns
      listOf("receiver-shared", "receiver-1")
    every { permissionService.lookupAccountIds(Permission.RECEIVE_REQUEST, "receiver-2") } returns
      listOf("receiver-shared", "receiver-2")
    val recipients = slot<Collection<String>>()
    val activity = slot<Activity>()

    creator.create(approved.changes.filterIsInstance<ReturnRequestApproved>().single())

    verify { notifier.notify(capture(recipients), capture(activity)) }
    recipients.captured.shouldContainExactly("receiver-shared", "receiver-1", "receiver-2")
    activity.captured.target.resourceType shouldBe ResourceType.RETURN_REQUEST
    activity.captured.body shouldBe "đã duyệt yêu cầu trả lại TURN-1, cần nhận vật tư"

    clearMocks(notifier)
    val rejected = returnRequest().apply { reject("Sai nơi nhận", approver) }
    every { returnRepository.findById("return-1") } returns rejected
    creator.create(rejected.changes.filterIsInstance<ReturnRequestRejected>().single())
    verify { notifier.notify(listOf("requester-1"), match { it.body.contains("Sai nơi nhận") }) }
  }

  @Test
  fun `transfer create and resubmit notify source team evaluators`() {
    val request = transferRequest()
    every { transferRepository.findById("transfer-1") } returns request

    creator.create(request.allEvents.filterIsInstance<TransferRequestCreated>().single())
    request.reject("Sai", approver)
    request.update(transferItems(), requester)
    creator.create(request.changes.filterIsInstance<TransferRequestUpdated>().single())

    verify(exactly = 2) {
      notifier.notify(match<Collection<String>> { it.toList() == listOf("evaluator-1") }, any())
    }
  }

  @Test
  fun `transfer approval groups target teams and rejection targets creator`() {
    val approved = transferRequest().apply { approve(approver) }
    every { transferRepository.findById("transfer-1") } returns approved
    every { assignmentRepository.findById("target-assignment-1") } returns
      assignment("target-assignment-1", "target-team-1")
    every { assignmentRepository.findById("target-assignment-2") } returns
      assignment("target-assignment-2", "target-team-2")
    every { permissionService.lookupAccountIds(Permission.RECEIVE_REQUEST, "target-team-1") } returns
      listOf("receiver-shared", "receiver-1")
    every { permissionService.lookupAccountIds(Permission.RECEIVE_REQUEST, "target-team-2") } returns
      listOf("receiver-shared", "receiver-2")
    val recipients = slot<Collection<String>>()
    val activity = slot<Activity>()

    creator.create(approved.changes.filterIsInstance<TransferRequestApproved>().single())

    verify { notifier.notify(capture(recipients), capture(activity)) }
    recipients.captured.shouldContainExactly("receiver-shared", "receiver-1", "receiver-2")
    activity.captured.target.resourceType shouldBe ResourceType.TRANSFER_REQUEST
    activity.captured.body shouldBe "đã duyệt yêu cầu điều chuyển SFER-1, cần nhận vật tư"

    clearMocks(notifier)
    val rejected = transferRequest().apply { reject("Sai tổ nhận", approver) }
    every { transferRepository.findById("transfer-1") } returns rejected
    creator.create(rejected.changes.filterIsInstance<TransferRequestRejected>().single())
    verify { notifier.notify(listOf("requester-1"), match { it.body.contains("Sai tổ nhận") }) }
  }

  private fun returnRequest(): ReturnRequest {
    val created = ReturnRequest.create("return-1", "source-assignment", returnItems(), requester)
    return ReturnRequest("return-1").apply { loadFromHistory(created.changes) }
  }

  private fun transferRequest(): TransferRequest {
    val created =
      TransferRequest.create("transfer-1", "source-assignment", transferItems(), requester)
    return TransferRequest("transfer-1").apply { loadFromHistory(created.changes) }
  }

  private fun returnItems() =
    listOf(
      ReturnRequestItem("MAT-1", "Red", "S", "M", BigDecimal.ONE, "receiver-1"),
      ReturnRequestItem("MAT-2", "Red", "S", "M", BigDecimal.ONE, "receiver-2"),
    )

  private fun transferItems() =
    listOf(
      TransferRequestItem("target-assignment-1", "MAT-1", "Red", "S", "M", BigDecimal.ONE),
      TransferRequestItem("target-assignment-2", "MAT-2", "Red", "S", "M", BigDecimal.ONE),
    )

  private fun assignment(id: String, teamId: String) =
    TeamAssignment.create(
      id = id,
      productionOrderId = "lsx-1",
      buyerOrderId = "bo-1",
      teamId = teamId,
      operation = Operation("Cut"),
      allocations = listOf(SkuAllocation("po-1", Color("Red"), Size("S"), 1)),
      plannedStartDate = LocalDate.of(2026, 1, 1),
      plannedEndDate = LocalDate.of(2026, 1, 10),
    )
}
