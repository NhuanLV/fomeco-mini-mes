package vn.lgg.mesplus.shared.query

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.maps.shouldContainExactly
import io.kotest.matchers.shouldBe
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Permission

class QueryTabPolicyTest {
  private val actor = Actor("actor-1", "Planner", "planner", "", emptyList(), emptySet())

  @Test
  fun `catalog rejects duplicate tabs and supports typed and wire lookup`() {
    val tabs = tabs()

    tabs[DemoTab.CREATED].wireName shouldBe "created"
    tabs["created"]?.key shouldBe DemoTab.CREATED
    tabs["unknown"] shouldBe null

    shouldThrow<IllegalArgumentException> {
      queryTabs<DemoTab, String, String, String> {
        tab(DemoTab.CREATED, "created") {}
        tab(DemoTab.CREATED, "duplicate") {}
      }
    }
    shouldThrow<IllegalArgumentException> {
      queryTabs<DemoTab, String, String, String> {
        tab(DemoTab.CREATED, "same") {}
        tab(DemoTab.EVALUATE, "same") {}
      }
    }
  }

  @Test
  fun `permission set and fallback keep their domain semantics`() {
    val context =
      queryTabContext(actor, "request") {
        when (it) {
          Permission.EVALUATE_KANBAN -> emptyList()
          Permission.EVALUATE_EXTRA_KANBAN -> listOf("team-extra")
          Permission.ISSUE_MATERIAL -> listOf("warehouse-issue")
          Permission.PREPARE_MATERIAL -> listOf("warehouse-prepare")
          else -> emptyList()
        }
      }

    context.hasUnitsFor(
      Permission.EVALUATE_KANBAN + Permission.EVALUATE_EXTRA_KANBAN
    ) shouldBe true
    context.firstAvailable(
      Permission.CREATE_KANBAN orElse
        Permission.ISSUE_MATERIAL orElse
        Permission.PREPARE_MATERIAL
    ) shouldBe GrantedUnits(Permission.ISSUE_MATERIAL, listOf("warehouse-issue"))
  }

  @Test
  fun `counters omit or zero hidden tabs and execute visible callbacks`() {
    val tabs = tabs()
    val context =
      queryTabContext(actor, "request") {
        if (it == Permission.CREATE_REQUEST) listOf("team-1") else emptyList()
      }

    tabs.counters(context).shouldContainExactly(
      mapOf("created" to 1, "evaluate" to 0)
    )
  }

  @Test
  fun `list and options callbacks receive the same typed context`() {
    val tabs = tabs()
    val context = queryTabContext(actor, "needle") { emptyList() }

    tabs.listFilter(DemoTab.CREATED, context) shouldBe "filter:needle"
    tabs.options(DemoTab.CREATED, context) shouldBe "options:needle"
  }

  private fun tabs() =
    queryTabs<DemoTab, String, String, String> {
      tab(DemoTab.CREATED, "created") {
        visibility requiresUnitsFor Permission.CREATE_REQUEST
        counter hiddenAs HiddenCounter.OMIT
        listFilterWith { "filter:$request" }
        optionsWith { "options:$request" }
        countWith { unitsFor(Permission.CREATE_REQUEST).size }
      }
      tab(DemoTab.EVALUATE, "evaluate") {
        visibility requiresUnitsFor Permission.EVALUATE_REQUEST
        counter hiddenAs HiddenCounter.ZERO
        countWith { 99 }
      }
      tab(DemoTab.RECEIVE, "receive") {
        visibility requiresUnitsFor Permission.RECEIVE_REQUEST
        counter hiddenAs HiddenCounter.OMIT
        countWith { 1 }
      }
    }

  private enum class DemoTab {
    CREATED,
    EVALUATE,
    RECEIVE,
  }
}
