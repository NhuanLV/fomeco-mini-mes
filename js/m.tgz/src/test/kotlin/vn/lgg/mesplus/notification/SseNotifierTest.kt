package vn.lgg.mesplus.notification

import io.kotest.matchers.collections.shouldContain
import io.kotest.matchers.collections.shouldContainExactlyInAnyOrder
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.shared.Activity
import vn.lgg.mesplus.shared.NotificationTarget
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.ActorRef

class SseNotifierTest {
  private val emitters = mockk<SseEmitters>(relaxed = true)

  @Test
  fun `persists one notification per distinct recipient before sending SSE`() {
    val repository = FakeNotifierRepository()
    every { emitters.send(any(), any()) } answers {
      repository.saved shouldContain secondArg<Notification>()
    }
    val notifier = SseNotifier(repository, emitters)

    notifier.notify(listOf("recipient-1", "recipient-1", "recipient-2"), activity())

    repository.saved.map { it.recipientId } shouldContainExactlyInAnyOrder
      listOf("recipient-1", "recipient-2")
    repository.saved.all { !it.isRead } shouldBe true
    verify(exactly = 1) { emitters.send("recipient-1", repository.saved[0]) }
    verify(exactly = 1) { emitters.send("recipient-2", repository.saved[1]) }
  }

  @Test
  fun `does not send transient SSE when persistence fails`() {
    val repository = FakeNotifierRepository(failure = IllegalStateException("database unavailable"))
    val notifier = SseNotifier(repository, emitters)

    notifier.notify(listOf("recipient-1"), activity())

    verify(exactly = 0) { emitters.send(any(), any()) }
  }

  @Test
  fun `excludes the actor from recipients`() {
    val repository = FakeNotifierRepository()
    val notifier = SseNotifier(repository, emitters)

    notifier.notify(listOf("actor-1", "recipient-1"), activity())

    repository.saved.map { it.recipientId } shouldContainExactlyInAnyOrder listOf("recipient-1")
    verify(exactly = 0) { emitters.send("actor-1", any()) }
  }

  @Test
  fun `includes actor when explicitly requested and still deduplicates recipients`() {
    val repository = FakeNotifierRepository()
    SseNotifier(repository, emitters).notify(listOf("actor-1", "actor-1", "recipient-1"),
      activity(), includeActor = true)

    repository.saved.map { it.recipientId } shouldContainExactlyInAnyOrder
      listOf("actor-1", "recipient-1")
    repository.saved.all { it.activity.actor?.id == "actor-1" } shouldBe true
  }

  private fun activity() =
    Activity(
      actor = ActorRef("actor-1", "Planner"),
      title = "LSX mới",
      body = "đã giao LSX LSX-1 cho tổ của bạn",
      target = NotificationTarget(ResourceType.TEAM_ASSIGNMENT, "assignment-1"),
    )
}

private class FakeNotifierRepository(private val failure: Exception? = null) :
  NotificationRepository {
  val saved = mutableListOf<Notification>()

  override fun saveAll(notifications: List<Notification>): List<Notification> {
    failure?.let { throw it }
    saved += notifications
    return notifications
  }

  override fun find(query: NotificationQuery): List<Notification> = emptyList()

  override fun countUnread(recipientId: String): Long = 0

  override fun markAsRead(id: String, recipientId: String): Boolean = false

  override fun markTargetAsRead(target: NotificationTarget, recipientId: String) = Unit

  override fun markAllAsRead(recipientId: String) = Unit
}
