package vn.lgg.mesplus.kanban.application.usecase

import io.mockk.every
import io.mockk.just
import io.mockk.mockk
import io.mockk.Runs
import io.mockk.verify
import java.math.BigDecimal
import java.util.UUID
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.domain.event.KanbanAssignmentInitialized.AssignmentItem
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialPrepared.PreparedItem
import vn.lgg.mesplus.kanban.domain.model.KanbanAssignment
import vn.lgg.mesplus.kanban.domain.repository.KanbanAssignmentRepository
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.ActorRef

class PrepareMaterialUseCaseTest {
  private val kanbanRepository = mockk<vn.lgg.mesplus.kanban.domain.repository.KanbanRepository> {
    every { lockAndLoad(any()) } returns mockk(relaxed = true)
  }
  private val repository = mockk<KanbanAssignmentRepository>()
  private val eventPublisher = mockk<DomainEventPublisher>()
  private val actor = ActorRef("actor-1", "Warehouse")
  private val idempotencyKey = UUID.randomUUID()

  @Test
  fun `duplicate idempotency key does not prepare material again`() {
    every {
      repository.claimPrepareIdempotencyKey("kanban-1", "supplier-1", idempotencyKey)
    } returns false

    PrepareMaterialUseCase(repository, eventPublisher, kanbanRepository).execute(command())

    verify(exactly = 0) { repository.findById(any(), any()) }
    verify(exactly = 0) { repository.save(any()) }
    verify(exactly = 0) { eventPublisher.publish(any<List<DomainEvent>>()) }
  }

  @Test
  fun `new idempotency key prepares material once`() {
    val assignment = assignment()
    every {
      repository.claimPrepareIdempotencyKey("kanban-1", "supplier-1", idempotencyKey)
    } returns true
    every { repository.findById("kanban-1", "supplier-1") } returns assignment
    every { repository.save(assignment) } just Runs
    every { eventPublisher.publish(any<List<DomainEvent>>()) } just Runs

    PrepareMaterialUseCase(repository, eventPublisher, kanbanRepository).execute(command())

    verify(exactly = 1) { repository.save(assignment) }
    verify(exactly = 1) { eventPublisher.publish(assignment.changes) }
  }

  private fun command() =
    PrepareMaterialCommand(
      kanbanId = "kanban-1",
      supplierUnitId = "supplier-1",
      idempotencyKey = idempotencyKey,
      items = listOf(PreparedItem("MAT-1", "RED", "M", null, BigDecimal("2"), "")),
      actor = actor,
    )

  private fun assignment() =
    KanbanAssignment.init(
      kanbanId = "kanban-1",
      supplierUnitId = "supplier-1",
      items = listOf(AssignmentItem("MAT-1", "RED", "M", null, BigDecimal("10"))),
      actor = actor,
    )
}
