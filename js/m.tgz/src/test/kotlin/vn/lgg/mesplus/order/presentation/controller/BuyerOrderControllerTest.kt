package vn.lgg.mesplus.order.presentation.controller

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import java.time.LocalDate
import org.junit.jupiter.api.Test
import org.springframework.security.access.AccessDeniedException
import vn.lgg.mesplus.iam.domain.model.Corporation
import vn.lgg.mesplus.order.application.usecase.AddPositivePurchaseOrderCommand
import vn.lgg.mesplus.order.application.usecase.AddPositivePurchaseOrderResult
import vn.lgg.mesplus.order.application.usecase.AddPositivePurchaseOrderUseCase
import vn.lgg.mesplus.order.application.usecase.UpdatePositivePurchaseOrderCommand
import vn.lgg.mesplus.order.application.usecase.UpdatePositivePurchaseOrderUseCase
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

class BuyerOrderControllerTest {
  private val permissions = mockk<PermissionService>()
  private val add = mockk<AddPositivePurchaseOrderUseCase>()
  private val update = mockk<UpdatePositivePurchaseOrderUseCase>()
  private val actor = mockk<Actor>()
  private val controller = BuyerOrderController(mockk(), mockk(), permissions, add, update)
  private val addCommand = AddPositivePurchaseOrderCommand("POS", "US", LocalDate.of(2026, 9, 1), emptyList())
  private val updateCommand = UpdatePositivePurchaseOrderCommand(emptyList())

  @Test
  fun `add and update require both permissions before delegating`() {
    for (missing in listOf(Permission.CREATE_POSITIVE_PURCHASE_ORDER, Permission.MANAGE_BUYER_ORDER)) {
      every { permissions.requirePermission(actor, any(), any()) } answers {
        thirdArg<() -> List<String>>().invoke() shouldBe listOf(Corporation.DEFAULT_ID)
        if (missing in secondArg<List<Permission>>()) throw AccessDeniedException("Denied")
      }
      shouldThrow<AccessDeniedException> { controller.addPositivePurchaseOrder("bo", addCommand, actor) }
      shouldThrow<AccessDeniedException> { controller.updatePositivePurchaseOrder("bo", "po", updateCommand, actor) }
    }
    verify(exactly = 0) { add.execute(any(), any(), any()) }
    verify(exactly = 0) { update.execute(any(), any(), any(), any()) }
  }

  @Test
  fun `authorized requests delegate to usecases`() {
    every { permissions.requirePermission(actor, any(), any()) } returns Unit
    every { add.execute("bo", addCommand, actor) } returns AddPositivePurchaseOrderResult("po")
    every { update.execute("bo", "po", updateCommand, actor) } returns Unit

    controller.addPositivePurchaseOrder("bo", addCommand, actor).id shouldBe "po"
    controller.updatePositivePurchaseOrder("bo", "po", updateCommand, actor)

    verify(exactly = 2) { permissions.requirePermission(actor, listOf(Permission.CREATE_POSITIVE_PURCHASE_ORDER), any()) }
    verify(exactly = 2) { permissions.requirePermission(actor, listOf(Permission.MANAGE_BUYER_ORDER), any()) }
    verify(exactly = 1) { update.execute("bo", "po", updateCommand, actor) }
  }
}
