package vn.lgg.mesplus.kanban.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.math.BigDecimal
import java.util.UUID
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.domain.model.Kanban
import vn.lgg.mesplus.kanban.domain.model.KanbanItem
import vn.lgg.mesplus.kanban.domain.model.KanbanItemType
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.production.application.service.ProductionOrderTypeQuery
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository

class CreateKanbanUseCaseTest {
  private val repository = mockk<KanbanRepository>(relaxed = true)
  private val assignments = mockk<TeamAssignmentRepository>()
  private val types = mockk<ProductionOrderTypeQuery>()
  private val assignment = mockk<TeamAssignment>()
  private val actor = Actor("planner", "Planner", "planner", "", emptyList(), emptySet())
  private val useCase = CreateKanbanUseCase(repository, mockk<DomainEventPublisher>(relaxed = true),
    { UUID.randomUUID() }, assignments, types,
    mockk<ProductionOrderRepository>(relaxed = true))
  private val item = KanbanItem("BTP CUT-1", Color("Red"), Size("M"), null,
    KanbanItemType.SEMI_FINISHED_PRODUCT, BigDecimal.TEN, "cutting", "")

  @Test
  fun `mixed BTP requires explicit type and saves both snapshots without merging`() {
    every { assignments.findById("assignment") } returns assignment
    every { assignment.productionOrderId } returns "lsx-1"
    every { assignment.allocations } returns listOf(
      SkuAllocation("regular", item.color, item.size, 100),
      SkuAllocation("positive", item.color, item.size, 10),
    )
    every { types.typesByPo(assignment) } returns mapOf(
      "regular" to PurchaseOrderType.REGULAR, "positive" to PurchaseOrderType.POSITIVE,
    )
    shouldThrow<IllegalArgumentException> {
      useCase.execute(CreateKanbanCommand("assignment", emptyList(), listOf(item), "Extra"), actor)
    }
    verify(exactly = 0) { repository.save(any()) }
    val saved = slot<Kanban>()
    every { repository.save(capture(saved)) } returns Unit
    val items = listOf(item.copy(purchaseOrderType = PurchaseOrderType.REGULAR),
      item.copy(purchaseOrderType = PurchaseOrderType.POSITIVE))
    useCase.execute(CreateKanbanCommand("assignment", emptyList(), items, "Extra"), actor)
    saved.captured.items shouldBe items.map { it.copy(requiredQty = BigDecimal("10.0000")) }
  }
}
