package vn.lgg.mesplus.iam.presentation.controller

import io.kotest.matchers.collections.shouldHaveSize
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.CorporationClassification
import vn.lgg.mesplus.iam.domain.model.OrgUnitType
import vn.lgg.mesplus.iam.domain.repository.FactoryOperationRepository
import vn.lgg.mesplus.iam.domain.repository.OperationRepository
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.iam.infrastructure.repository.view.OrgUnitViewRepository
import vn.lgg.mesplus.iam.presentation.viewmodel.UnitFlatVm

class OrganizationQueryControllerTest {
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val viewRepository = mockk<OrgUnitViewRepository>()
  private val operationRepository = mockk<OperationRepository>()
  private val factoryOperationRepository = mockk<FactoryOperationRepository>()
  private val controller =
    OrganizationQueryController(
      orgUnitRepository,
      viewRepository,
      operationRepository,
      factoryOperationRepository,
    )

  @Test
  fun `returns every corporation as a separate tree root`() {
    every { viewRepository.findAllUnitsFlat() } returns
      listOf(
        UnitFlatVm(
          id = "corp-1",
          name = "LGG",
          code = "LGG",
          type = OrgUnitType.CORPORATION,
          address = null,
          operations = emptyList(),
          isActive = true,
          parentId = null,
          classification = CorporationClassification.INHOUSE,
        ),
        UnitFlatVm(
          id = "corp-2",
          name = "Partner",
          code = "PARTNER",
          type = OrgUnitType.CORPORATION,
          address = null,
          operations = emptyList(),
          isActive = true,
          parentId = null,
          classification = CorporationClassification.OUTSOURCE,
        ),
        UnitFlatVm(
          id = "company-1",
          name = "Factory Co",
          code = "FC",
          type = OrgUnitType.COMPANY,
          address = null,
          operations = emptyList(),
          isActive = true,
          parentId = "corp-1",
        ),
      )

    val trees = controller.getTree()

    trees shouldHaveSize 2
    trees.map { it.id } shouldBe listOf("corp-1", "corp-2")
    trees.first().children.single().code shouldBe "FC"
  }
}
