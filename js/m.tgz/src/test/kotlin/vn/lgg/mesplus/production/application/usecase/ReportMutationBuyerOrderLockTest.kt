package vn.lgg.mesplus.production.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.application.usecase.GetMaterialInventoryBalanceUseCase
import vn.lgg.mesplus.inventory.application.usecase.RecordBtpProducedUseCase
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.service.BomCalculationService
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.production.domain.repository.TeamMaterialRepository
import vn.lgg.mesplus.shared.service.PermissionService

class ReportMutationBuyerOrderLockTest {
  private val repository = mockk<TeamAssignmentRepository>()
  private val teamMaterialRepository = mockk<TeamMaterialRepository>()
  private val permissionService = mockk<PermissionService>()
  private val allocationQueryService = mockk<AllocationQueryService>()
  private val eventPublisher = mockk<DomainEventPublisher>()
  private val bomCalculationService = mockk<BomCalculationService>()
  private val getMaterialInventoryBalance = mockk<GetMaterialInventoryBalanceUseCase>()
  private val reportGrnSyncService = mockk<ReportGrnSyncService>()
  private val actor = Actor("actor-1", "Reporter", "reporter", "", emptyList(), emptySet())

  @BeforeEach
  fun setUp() {
    justRun { allocationQueryService.requireActive("lsx-1") }
    every { repository.findById("ta-1") } returns assignment()
    every { teamMaterialRepository.findByTeamAssignmentId("ta-1") } returns emptyList()
    justRun { permissionService.requirePermission(actor, any(), any()) }
    every {
      allocationQueryService.requireWithinBuyerOrderQuantity("bo-1")
    } throws IllegalStateException("locked")
  }

  @Test
  fun `blocks creating report`() {
    val useCase =
      ReportUseCase(
        repository,
        teamMaterialRepository,
        permissionService,
        allocationQueryService,
        eventPublisher,
        bomCalculationService,
        getMaterialInventoryBalance,
        reportGrnSyncService,
        mockk<RecordBtpProducedUseCase>(),
      )

    shouldThrow<IllegalStateException> {
      useCase.execute(
        "ta-1",
        ReportCommand(items = listOf(ReportItemCommand("po-1", Color("Red"), Size("S"), 1))),
        actor,
      )
    }
  }

  @Test
  fun `blocks updating last report`() {
    val useCase =
      UpdateLastReportUseCase(
        repository,
        permissionService,
        allocationQueryService,
        eventPublisher,
      )

    shouldThrow<IllegalStateException> {
      useCase.execute(
        "ta-1",
        ReportCommand(items = listOf(ReportItemCommand("po-1", Color("Red"), Size("S"), 1))),
        actor,
      )
    }
  }

  @Test
  fun `blocks deleting last report`() {
    val useCase =
      DeleteLastReportUseCase(
        repository,
        permissionService,
        allocationQueryService,
        eventPublisher,
      )

    shouldThrow<IllegalStateException> {
      useCase.execute("ta-1", Instant.parse("2026-01-01T00:00:00Z"), actor)
    }
  }

  private fun assignment() =
    TeamAssignment.create(
      id = "ta-1",
      productionOrderId = "lsx-1",
      buyerOrderId = "bo-1",
      teamId = "team-1",
      operation = Operation("Sew"),
      allocations = listOf(SkuAllocation("po-1", Color("Red"), Size("S"), 10)),
      plannedStartDate = LocalDate.of(2026, 1, 1),
      plannedEndDate = LocalDate.of(2026, 1, 10),
    )
}
