package vn.lgg.mesplus.order.domain.service

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.TeamAssignmentAllocationRevised
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.SkuQuantity
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository

class AllocationQueryServiceTest {
  private val repository = mockk<TeamAssignmentRepository>()
  private val orders = mockk<ProductionOrderRepository>(relaxed = true)
  private val service = AllocationQueryService(repository, mockk<PurchaseOrderRepository>(), orders)

  @Test
  fun `cancelled orders release allocation and do not require adjustment despite late projections`() {
    val cancelled = mockk<ProductionOrder> {
      every { status } returns ProductionOrderStatus.CANCELLED
    }
    every { orders.findById("lsx-1") } returns cancelled
    every { repository.findByBuyerOrderId("bo-1") } returns listOf(assignmentNeedingAdjustment())
    service.needsAdjustment("bo-1", listOf(purchaseOrder(100))) shouldBe false
    service.getRemainingSku(
      BuyerOrder("bo-1", "BO", "Style", "R1", Instant.EPOCH), listOf(purchaseOrder(100)),
    ).sumOf { it.quantity } shouldBe 100
  }

  @Test
  fun `counts each production order once across operations`() {
    every { repository.findByBuyerOrderId("bo-1") } returns
      listOf(
        assignment("ta-1", "lsx-1", "cut", 60),
        assignment("ta-2", "lsx-1", "sew", 60),
        assignment("ta-3", "lsx-2", "cut", 50),
        assignment("ta-4", "lsx-2", "sew", 50),
      )

    service.overAllocatedKeys("bo-1", listOf(purchaseOrder(100))).shouldContainExactly(key())
  }

  @Test
  fun `treats allocation for removed WFX sku as over allocated`() {
    every { repository.findByBuyerOrderId("bo-1") } returns
      listOf(assignment("ta-1", "lsx-1", "cut", 1))

    service.needsAllocationRevision("bo-1", emptyList()) shouldBe true
  }

  @Test
  fun `buyer order needs adjustment when an assignment needs reconciliation`() {
    every { repository.findByBuyerOrderId("bo-1") } returns listOf(assignmentNeedingAdjustment())

    service.needsAdjustment("bo-1", listOf(purchaseOrder(100))) shouldBe true
  }

  @Test
  fun `buyer order needs adjustment when aggregate allocation exceeds WFX quantity`() {
    every { repository.findByBuyerOrderId("bo-1") } returns
      listOf(
        assignment("ta-1", "lsx-1", "cut", 60),
        assignment("ta-2", "lsx-2", "cut", 50),
      )

    service.needsAdjustment("bo-1", listOf(purchaseOrder(100))) shouldBe true
  }

  @Test
  fun `guard rejects locked buyer order`() {
    every { repository.findByBuyerOrderId("bo-1") } returns
      listOf(assignment("ta-1", "lsx-1", "cut", 101))

    shouldThrow<IllegalStateException> {
      service.requireWithinBuyerOrderQuantity("bo-1", listOf(purchaseOrder(100)))
    }
  }

  @Test
  fun `totals multiple teams from only the first operation in first-seen sku order`() {
    val assignments =
      listOf(
        assignment("ta-1", "lsx-1", "cut", listOf(allocation(4), allocation(2, "Blue"))),
        assignment("ta-2", "lsx-1", "cut", listOf(allocation(6))),
        assignment("ta-3", "lsx-1", "sew", listOf(allocation(99))),
      )

    service.totalAllocations(assignments).shouldContainExactly(
      allocation(10),
      allocation(2, "Blue"),
    )
  }

  @Test
  fun `remaining sku keeps purchase order order and can become negative`() {
    every { repository.findByBuyerOrderId("bo-1") } returns
      listOf(
        assignment(
          "ta-1",
          "lsx-1",
          "cut",
          listOf(allocation(11), allocation(2, "Blue")),
        )
      )

    service.getRemainingSku(
      buyerOrder(),
      listOf(purchaseOrder(10, "Red"), purchaseOrder(5, "Blue")),
    ).shouldContainExactly(
      allocation(-1),
      allocation(3, "Blue"),
    )
  }

  private fun assignment(id: String, productionOrderId: String, operation: String, quantity: Int) =
    assignment(id, productionOrderId, operation, listOf(allocation(quantity)))

  private fun assignment(
    id: String,
    productionOrderId: String,
    operation: String,
    allocations: List<SkuAllocation>,
  ) =
    TeamAssignment.create(
      id = id,
      productionOrderId = productionOrderId,
      buyerOrderId = "bo-1",
      teamId = "team-$id",
      operation = Operation(operation),
      allocations = allocations,
      plannedStartDate = LocalDate.of(2026, 1, 1),
      plannedEndDate = LocalDate.of(2026, 1, 10),
    )

  private fun allocation(quantity: Int, color: String = "Red") =
    SkuAllocation("po-1", Color(color), Size("S"), quantity)

  private fun assignmentNeedingAdjustment() =
    TeamAssignment("ta-needs-adjustment").apply {
      loadFromHistory(
        listOf<DomainEvent>(
          TeamAssignmentCreated(
            assignmentId = id,
            productionOrderId = "lsx-1",
            buyerOrderId = "bo-1",
            teamId = "team-1",
            operation = Operation("cut"),
            allocations = listOf(allocation(10)),
            plannedStartDate = LocalDate.of(2026, 1, 1),
            plannedEndDate = LocalDate.of(2026, 1, 10),
            assignedAt = Instant.parse("2026-01-01T00:00:00Z"),
            actor = ActorRef("actor-1", "Planner"),
          ),
          ProgressReported(
            assignmentId = id,
            items = listOf(ReportItem("po-1", Color("Red"), Size("S"), 10)),
            actor = ActorRef("actor-1", "Planner"),
          ),
          TeamAssignmentAllocationRevised(
            assignmentId = id,
            allocations = listOf(SkuAllocation("po-2", Color("Red"), Size("S"), 10)),
            actor = ActorRef("actor-1", "Planner"),
          ),
        )
      )
    }

  private fun purchaseOrder(quantity: Int, color: String = "Red") =
    PurchaseOrder(
      id = "po-1",
      wfxId = "wfx-po-1",
      code = "PO-1",
      destination = "US",
      deliveryDate = LocalDate.of(2026, 1, 1),
      skuQties = listOf(SkuQuantity(Color(color), Size("S"), quantity)),
      buyerOrderId = "bo-1",
    )

  private fun key() = allocation(0).breakdownKey

  private fun buyerOrder() =
    BuyerOrder("bo-1", "WFX-1", "STYLE", "1", Instant.parse("2026-01-01T00:00:00Z"))
}
