package vn.lgg.mesplus.order.infrastructure.wfx

import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.infrastructure.repository.WfxRepository
import vn.lgg.mesplus.order.infrastructure.wfx.client.WfxClient

class FullWfxSyncTest {
  private val wfxRepository = mockk<WfxRepository>()
  private val wfxClient = mockk<WfxClient>()
  private val wfxService = mockk<WfxService>()
  private val wfxSupplierSyncService = mockk<WfxSupplierSyncService>()

  private val fullSync =
    FullWfxSync(wfxRepository, wfxClient, wfxService, wfxSupplierSyncService)

  @Test
  fun `syncs all master tables when empty on startup`() {
    every { wfxRepository.isArticlesEmpty() } returns true
    every { wfxRepository.isColorsEmpty() } returns true
    every { wfxRepository.isSizesEmpty() } returns true
    every { wfxSupplierSyncService.getSuppliers() } returns emptyList()

    val fullSyncDate = LocalDate.of(2024, 1, 1)
    justRun { wfxService.syncArticleMaster(fullSyncDate) }
    every { wfxClient.getAllColors(fullSyncDate) } returns emptyList()
    justRun { wfxRepository.insertColors(emptyList()) }
    every { wfxClient.getAllSizes(fullSyncDate) } returns emptyList()
    justRun { wfxRepository.insertSizes(emptyList()) }
    every { wfxSupplierSyncService.sync() } returns WfxSupplierSyncResult(emptyList(), "ok")

    fullSync.syncIfEmpty()

    verify(exactly = 1) { wfxService.syncArticleMaster(fullSyncDate) }
    verify(exactly = 1) { wfxClient.getAllColors(fullSyncDate) }
    verify(exactly = 1) { wfxRepository.insertColors(emptyList()) }
    verify(exactly = 1) { wfxClient.getAllSizes(fullSyncDate) }
    verify(exactly = 1) { wfxRepository.insertSizes(emptyList()) }
    verify(exactly = 1) { wfxSupplierSyncService.sync() }
  }

  @Test
  fun `skips sync when all master tables already have data`() {
    every { wfxRepository.isArticlesEmpty() } returns false
    every { wfxRepository.isColorsEmpty() } returns false
    every { wfxRepository.isSizesEmpty() } returns false
    every { wfxSupplierSyncService.getSuppliers() } returns listOf("Supplier 1")

    fullSync.syncIfEmpty()

    verify(exactly = 0) { wfxService.syncArticleMaster(any()) }
    verify(exactly = 0) { wfxClient.getAllColors(any()) }
    verify(exactly = 0) { wfxClient.getAllSizes(any()) }
    verify(exactly = 0) { wfxSupplierSyncService.sync() }
  }
}
