package vn.lgg.mesplus.production.application.usecase

import io.kotest.matchers.collections.shouldHaveSize
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.infrastructure.repository.view.AccountViewRepository
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.PurchaseOrderQuantityAdjusted
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.PurchaseOrderQuantityDelta
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.ReportType
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

class ReportQueryServiceTest {
  private val assignmentRepository = mockk<TeamAssignmentRepository>()
  private val accountViewRepository = mockk<AccountViewRepository>()
  private val service = ReportQueryService(assignmentRepository, accountViewRepository)

  private val reportedAt = Instant.parse("2026-04-01T00:00:00Z")
  private val actor = ActorRef("user-1", "Nguyen Van A")

  @Test
  fun `returns report vm with history and totals computed from events`() {
    every { accountViewRepository.findVmById("user-1") } returns null
    every { assignmentRepository.findEventsById("assignment-1") } returns
      listOf(
        TeamAssignmentCreated(
          assignmentId = "assignment-1",
          productionOrderId = "prod-1",
          buyerOrderId = "bo-1",
          teamId = "team-1",
          operation = Operation("SEWING"),
          allocations = listOf(SkuAllocation("po-1", Color("RED"), Size("M"), 100)),
          plannedStartDate = LocalDate.of(2026, 4, 1),
          plannedEndDate = LocalDate.of(2026, 4, 10),
          assignedAt = reportedAt,
          actor = actor,
        ),
        ProgressReported(
          assignmentId = "assignment-1",
          type = ReportType.OUTPUT,
          items = listOf(ReportItem("po-1", Color("RED"), Size("M"), 10)),
          actor = actor,
          occurredAt = reportedAt,
        ),
        PurchaseOrderQuantityAdjusted(
          assignmentId = "assignment-1",
          reason = "Adjustment",
          deltas = listOf(PurchaseOrderQuantityDelta("po-1", Color("RED"), Size("M"), 5)),
          actor = actor,
          occurredAt = reportedAt.plusSeconds(3600),
        )
      )

    val report = service.getReport("assignment-1")

    report.history shouldHaveSize 1
    report.history.first().reportedAt shouldBe reportedAt.toString()
    report.history.first().actor?.id shouldBe "user-1"
    report.totals shouldHaveSize 1
    report.totals.first().completedQty shouldBe 15 // 10 output + 5 adjustment
  }

  @Test
  fun `keeps both mixed output groups committed at the same timestamp`() {
    every { accountViewRepository.findVmById("user-1") } returns null
    every { assignmentRepository.findEventsById("assignment-1") } returns listOf(
      ProgressReported(
        "assignment-1", ReportType.OUTPUT,
        listOf(ReportItem("po-positive", Color("RED"), Size("M"), 5)), actor, reportedAt,
      ),
      ProgressReported(
        "assignment-1", ReportType.OUTPUT,
        listOf(ReportItem("po-1", Color("RED"), Size("M"), 10)), actor, reportedAt,
      ),
    )

    val report = service.getReport("assignment-1")

    report.history shouldHaveSize 1
    report.history.single().reportedAt shouldBe reportedAt.toString()
    report.history.single().quantities.associate { it.purchaseOrderId to it.quantity } shouldBe
      mapOf("po-positive" to 5, "po-1" to 10)
    report.totals.associate { it.purchaseOrderId to it.completedQty } shouldBe
      mapOf("po-positive" to 5, "po-1" to 10)
  }

}
