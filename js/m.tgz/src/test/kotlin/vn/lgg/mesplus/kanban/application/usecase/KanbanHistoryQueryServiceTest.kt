package vn.lgg.mesplus.kanban.application.usecase

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.maps.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.math.BigDecimal
import java.time.Instant
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.domain.event.KanbanAssignmentInitialized
import vn.lgg.mesplus.kanban.domain.event.KanbanAssignmentInitialized.AssignmentItem
import vn.lgg.mesplus.kanban.domain.event.KanbanCreated
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialPrepared
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialPrepared.PreparedItem
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialReceived
import vn.lgg.mesplus.kanban.domain.event.KanbanRejected
import vn.lgg.mesplus.kanban.domain.event.KanbanRevised
import vn.lgg.mesplus.kanban.domain.model.GdnMaterialType
import vn.lgg.mesplus.kanban.domain.model.GdnMode
import vn.lgg.mesplus.kanban.domain.model.GdnStatus
import vn.lgg.mesplus.kanban.domain.model.Kanban
import vn.lgg.mesplus.kanban.domain.model.KanbanAssignment
import vn.lgg.mesplus.kanban.domain.model.KanbanGdn
import vn.lgg.mesplus.kanban.domain.model.KanbanItem
import vn.lgg.mesplus.kanban.domain.model.KanbanItemType
import vn.lgg.mesplus.kanban.domain.model.KanbanStatus
import vn.lgg.mesplus.kanban.domain.repository.KanbanAssignmentRepository
import vn.lgg.mesplus.kanban.domain.repository.KanbanGdnRepository
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.kanban.infrastructure.repository.KanbanViewRepository
import vn.lgg.mesplus.kanban.presentation.viewmodel.ItemPartVm
import vn.lgg.mesplus.kanban.presentation.viewmodel.KanbanDetailVm
import vn.lgg.mesplus.kanban.presentation.viewmodel.KanbanItemVm
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.production.application.service.ProductionOrderTypeQuery
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.PermissionService

class KanbanHistoryQueryServiceTest {
  private val kanbanRepository = mockk<KanbanRepository>()
  private val assignmentRepository = mockk<KanbanAssignmentRepository>()
  private val kanbanGdnRepository = mockk<KanbanGdnRepository>()
  private val viewRepository = mockk<KanbanViewRepository>()
  private val permissionService = mockk<PermissionService>()
  private val productionOrderTypeQuery = mockk<ProductionOrderTypeQuery>()
  private val service =
    KanbanHistoryQueryService(
      kanbanRepository,
      assignmentRepository,
      kanbanGdnRepository,
      viewRepository,
      permissionService,
      productionOrderTypeQuery,
    )
  private val actor = Actor("actor-1", "Planner", "planner", "", emptyList(), emptySet())
  private val actorRef = ActorRef(actor.id, actor.name)
  private val createdAt = Instant.parse("2026-01-01T00:00:00Z")
  private val rejectedAt = Instant.parse("2026-01-02T00:00:00Z")
  private val revisedAt = Instant.parse("2026-01-03T00:00:00Z")

  @BeforeEach
  fun setUp() {
    every { productionOrderTypeQuery.legacyTypeAt(any(), any()) } returns PurchaseOrderType.REGULAR
    every { kanbanGdnRepository.findAllByKanbanId(any()) } returns emptyList()
    every { kanbanGdnRepository.findAllByEvent(any(), any(), any()) } returns emptyList()
  }

  @Test
  fun `includes pending GDN attempt before receive event exists`() {
    val attemptAt = Instant.parse("2026-01-04T00:00:00Z")
    every { viewRepository.findById("kanban-1") } returns view()
    every { kanbanRepository.findById("kanban-1") } returns Kanban("kanban-1").apply {
      loadFromHistory(
        listOf(
          KanbanCreated(
            kanbanId = "kanban-1",
            teamAssignmentId = "assignment-1",
            plan = emptyList(),
            items = listOf(item("10")),
            reason = "",
            occurredAt = createdAt,
            actor = actorRef,
          ),
        ),
      )
    }
    every { assignmentRepository.findAllByKanbanId("kanban-1") } returns emptyList()
    every { kanbanGdnRepository.findAllByKanbanId("kanban-1") } returns listOf(
      gdn(attemptAt, GdnMaterialType.NPL, GdnStatus.PENDING, "").copy(
        payloadSnapshot = listOf(
          KanbanMaterialReceived.ReceivedItem("MAT-1", "RED", "M", null, BigDecimal("10")),
        ),
      ),
    )

    val pending = service.getHistory("kanban-1", actor).single { it.gdnStatus == GdnStatus.PENDING }

    pending.type shouldBe "KanbanMaterialReceived"
    pending.actor shouldBe actorRef
    pending.detail shouldContainExactly mapOf("MAT-1 / RED / M" to "10 (kg)")
    pending.gdnAttempts.single().items.single().article shouldBe "MAT-1"
  }

  @Test
  fun `revision history preserves both PO types for the same BTP SKU`() {
    val regular = item("100").copy(article = "BTP CUT", type = KanbanItemType.SEMI_FINISHED_PRODUCT, purchaseOrderType = PurchaseOrderType.REGULAR)
    val positive = regular.copy(requiredQty = BigDecimal("10"), purchaseOrderType = PurchaseOrderType.POSITIVE)
    every { viewRepository.findById("kanban-1") } returns view()
    every { kanbanRepository.findById("kanban-1") } returns Kanban("kanban-1").apply {
      loadFromHistory(listOf(
        KanbanCreated("kanban-1", "assignment-1", emptyList(), listOf(regular, positive), "", createdAt, actorRef),
        KanbanRevised("kanban-1", revisedAt, actorRef, listOf(
          regular.copy(requiredQty = BigDecimal("90")),
          positive.copy(requiredQty = BigDecimal("15")),
        )),
      ))
    }
    every { assignmentRepository.findAllByKanbanId("kanban-1") } returns emptyList()

    service.getHistory("kanban-1", actor).first().detail shouldContainExactly mapOf(
      "BTP CUT / RED / M / Hàng thường" to "100 → 90 (-10)",
      "BTP CUT / RED / M / Hàng dương" to "10 → 15 (+5)",
    )
  }

  @Test
  fun `maps revision delta and returns newest event first`() {
    val original = item("10")
    val revised = item("12")
    val kanban =
      Kanban("kanban-1").apply {
        loadFromHistory(
          listOf(
            KanbanCreated(
              kanbanId = "kanban-1",
              teamAssignmentId = "assignment-1",
              plan = emptyList(),
              items = listOf(original),
              reason = "extra",
              occurredAt = createdAt,
              actor = actorRef,
            ),
            KanbanRejected(
              kanbanId = "kanban-1",
              actor = actorRef,
              occurredAt = rejectedAt,
              reason = "adjust",
            ),
            KanbanRevised(
              kanbanId = "kanban-1",
              occurredAt = revisedAt,
              actor = actorRef,
              changedItems = listOf(revised),
            ),
          ),
        )
      }
    every { viewRepository.findById("kanban-1") } returns view()
    every { kanbanRepository.findById("kanban-1") } returns kanban
    every { assignmentRepository.findAllByKanbanId("kanban-1") } returns emptyList()

    val history = service.getHistory("kanban-1", actor)

    history.map { it.type } shouldContainExactly
      listOf("KanbanRevised", "KanbanRejected", "KanbanCreated")
    history.map { it.productionOrderCode }.distinct() shouldBe listOf("PO-1")
    history.first().detail.shouldContainExactly(
      mapOf("MAT-1 / RED / M" to "10 → 12 (+2) (kg)"),
    )
    history[1].subtitle shouldBe "adjust"
    history.last().subtitle shouldBe "extra"
  }

  @Test
  fun `limits assignment history to permitted supplier units`() {
    val kanban =
      Kanban("kanban-1").apply {
        loadFromHistory(
          listOf(
            KanbanCreated(
              kanbanId = "kanban-1",
              teamAssignmentId = "assignment-1",
              plan = emptyList(),
              items = listOf(item("10")),
              reason = "extra",
              occurredAt = createdAt,
              actor = actorRef,
            ),
          ),
        )
      }
    every { viewRepository.findById("kanban-1") } returns view(createdById = "other")
    every { kanbanRepository.findById("kanban-1") } returns kanban
    every { permissionService.hasPermission(actor, any(), any()) } returns false
    every { permissionService.lookupUnit(actor, Permission.ISSUE_MATERIAL) } returns
      listOf("supplier-1")
    every { permissionService.lookupUnit(actor, Permission.PREPARE_MATERIAL) } returns emptyList()
    every { assignmentRepository.findAllByKanbanId("kanban-1") } returns
      listOf(assignment("supplier-1", "3"), assignment("supplier-2", "9"))

    val history = service.getHistory("kanban-1", actor)

    history.filter { it.type == "KanbanMaterialPrepared" }.single().detail.shouldContainExactly(
      mapOf("MAT-1 / RED / M" to "3 (kg)"),
    )
  }

  @Test
  fun `maps independent GDN attempts for a mixed receive event`() {
    val receivedAt = Instant.parse("2026-01-04T00:00:00Z")
    val kanban =
      Kanban("kanban-1").apply {
        loadFromHistory(
          listOf(
            KanbanCreated(
              kanbanId = "kanban-1",
              teamAssignmentId = "assignment-1",
              plan = emptyList(),
              items = listOf(item("10")),
              reason = "",
              occurredAt = createdAt,
              actor = actorRef,
            ),
          ),
        )
      }
    val assignment =
      KanbanAssignment("kanban-1", "supplier-1").apply {
        loadFromHistory(
          listOf(
            KanbanAssignmentInitialized(
              "kanban-1",
              "supplier-1",
              listOf(
                AssignmentItem("MAT-1", "RED", "M", null, BigDecimal("10")),
                AssignmentItem("BTP CUT", "RED", "M", null, BigDecimal("2")),
              ),
              actorRef,
            ),
            KanbanMaterialReceived(
              kanbanId = "kanban-1",
              supplierUnitId = "supplier-1",
              items = listOf(
                KanbanMaterialReceived.ReceivedItem("BTP CUT", "RED", "M", null, BigDecimal("2")),
              ),
              actor = actorRef,
              occurredAt = receivedAt,
            ),
          ),
        )
      }
    every { viewRepository.findById("kanban-1") } returns view()
    every { kanbanRepository.findById("kanban-1") } returns kanban
    every { assignmentRepository.findAllByKanbanId("kanban-1") } returns listOf(assignment)
    every { kanbanGdnRepository.findAllByEvent("kanban-1", "supplier-1", receivedAt) } returns
      listOf(
        gdn(receivedAt, GdnMaterialType.NPL, GdnStatus.SUCCESS, "NPL done"),
        gdn(receivedAt, GdnMaterialType.BTP, GdnStatus.FAILED, "BTP failed"),
      )

    val history = service.getHistory("kanban-1", actor)
    val received = history.single { it.type == "KanbanMaterialReceived" }

    received.gdnStatus shouldBe GdnStatus.FAILED
    received.gdnAttempts.map { it.materialType } shouldContainExactly listOf(GdnMaterialType.BTP)
    received.gdnAttempts.map { it.status } shouldContainExactly listOf(GdnStatus.FAILED)
    received.gdnAttempts.single { it.materialType == GdnMaterialType.BTP }.canRetry shouldBe true
  }

  @Test
  fun `maps NOT_APPLICABLE GDN attempts for positive LSX`() {
    val receivedAt = Instant.parse("2026-01-04T00:00:00Z")
    val kanban =
      Kanban("kanban-1").apply {
        loadFromHistory(
          listOf(
            KanbanCreated(
              kanbanId = "kanban-1",
              teamAssignmentId = "assignment-1",
              plan = emptyList(),
              items = listOf(item("10")),
              reason = "",
              occurredAt = createdAt,
              actor = actorRef,
            ),
            KanbanAssignmentInitialized(
              "kanban-1",
              "supplier-1",
              listOf(
                AssignmentItem("MAT-1", "RED", "M", null, BigDecimal("10")),
              ),
              actorRef,
            ),
            KanbanMaterialReceived(
              kanbanId = "kanban-1",
              supplierUnitId = "supplier-1",
              items = listOf(
                KanbanMaterialReceived.ReceivedItem("MAT-1", "RED", "M", null, BigDecimal("10")),
              ),
              actor = actorRef,
              occurredAt = receivedAt,
            ),
          ),
        )
      }
    val assignment =
      KanbanAssignment("kanban-1", "supplier-1").apply {
        loadFromHistory(
          listOf(
            KanbanAssignmentInitialized(
              "kanban-1",
              "supplier-1",
              listOf(
                AssignmentItem("MAT-1", "RED", "M", null, BigDecimal("10")),
              ),
              actorRef,
            ),
            KanbanMaterialReceived(
              kanbanId = "kanban-1",
              supplierUnitId = "supplier-1",
              items = listOf(
                KanbanMaterialReceived.ReceivedItem("MAT-1", "RED", "M", null, BigDecimal("10")),
              ),
              actor = actorRef,
              occurredAt = receivedAt,
            ),
          ),
        )
      }
    every { viewRepository.findById("kanban-1") } returns view()
    every { kanbanRepository.findById("kanban-1") } returns kanban
    every { assignmentRepository.findAllByKanbanId("kanban-1") } returns listOf(assignment)
    every { productionOrderTypeQuery.legacyTypeAt("assignment-1", any()) } returns PurchaseOrderType.POSITIVE

    val history = service.getHistory("kanban-1", actor)
    val received = history.single { it.type == "KanbanMaterialReceived" }

    received.gdnAttempts.map { it.status } shouldContainExactly listOf(GdnStatus.NOT_APPLICABLE)
    received.gdnAttempts.single().canRetry shouldBe false
  }

  @Test
  fun `mixed receive history keeps immediate positive and two independent GDN rows`() {
    val receivedAt = createdAt.plusSeconds(60)
    val npl = KanbanMaterialReceived.ReceivedItem("MAT-1", "RED", "M", null, BigDecimal.TEN)
    val regular = npl.copy(article = "BTP CUT", purchaseOrderType = PurchaseOrderType.REGULAR)
    val positive = regular.copy(qty = BigDecimal.ONE, purchaseOrderType = PurchaseOrderType.POSITIVE)
    val items = listOf(npl, regular, positive)
    val kanban = Kanban("kanban-1").apply {
      loadFromHistory(listOf(KanbanCreated("kanban-1", "assignment-1", emptyList(), items.map {
        item(it.qty.toPlainString()).copy(article = it.article, purchaseOrderType = it.purchaseOrderType)
      }, "", occurredAt = createdAt, actor = actorRef)))
    }
    val assignment = KanbanAssignment("kanban-1", "supplier-1").apply {
      loadFromHistory(listOf(
        KanbanAssignmentInitialized("kanban-1", "supplier-1", items.map {
          AssignmentItem(it.article, it.color, it.size, it.poId, it.qty, it.purchaseOrderType)
        }, actorRef),
        KanbanMaterialReceived("kanban-1", "supplier-1", listOf(positive), actorRef, receivedAt),
        KanbanMaterialReceived("kanban-1", "supplier-1", listOf(npl), actorRef, receivedAt),
      ))
    }
    val attempts = listOf(
      gdn(receivedAt, GdnMaterialType.NPL, GdnStatus.SUCCESS, "").copy(payloadSnapshot = listOf(npl)),
      gdn(receivedAt, GdnMaterialType.BTP, GdnStatus.FAILED, "WFX failed").copy(payloadSnapshot = listOf(regular)),
    )
    every { viewRepository.findById("kanban-1") } returns view()
    every { kanbanRepository.findById("kanban-1") } returns kanban
    every { assignmentRepository.findAllByKanbanId("kanban-1") } returns listOf(assignment)
    every { kanbanGdnRepository.findAllByKanbanId("kanban-1") } returns attempts
    every { kanbanGdnRepository.findAllByEvent("kanban-1", "supplier-1", receivedAt) } returns attempts
    val rows = service.getHistory("kanban-1", actor).filter { it.type == "KanbanMaterialReceived" }
    rows.size shouldBe 3
    rows.map { it.gdnStatus }.toSet() shouldBe setOf(GdnStatus.NOT_APPLICABLE, GdnStatus.SUCCESS, GdnStatus.FAILED)
  }

  private fun item(quantity: String) =
    KanbanItem(
      article = "MAT-1",
      color = Color("RED"),
      size = Size("M"),
      purchaseOrderId = null,
      type = KanbanItemType.MATERIAL,
      requiredQty = BigDecimal(quantity),
      supplierUnitId = "supplier-1",
      creatorNote = "",
    )

  private fun assignment(supplierId: String, quantity: String) =
    KanbanAssignment("kanban-1", supplierId).apply {
      loadFromHistory(
        listOf(
          KanbanAssignmentInitialized(
            "kanban-1",
            supplierId,
            listOf(AssignmentItem("MAT-1", "RED", "M", null, BigDecimal("10"))),
            actorRef,
          ),
          KanbanMaterialPrepared(
            "kanban-1",
            supplierId,
            listOf(PreparedItem("MAT-1", "RED", "M", null, BigDecimal(quantity), "")),
            actorRef,
          ),
        ),
      )
    }

  private fun gdn(
    occurredAt: Instant,
    materialType: GdnMaterialType,
    status: GdnStatus,
    message: String,
  ) =
    KanbanGdn(
      kanbanId = "kanban-1",
      supplierUnitId = "supplier-1",
      occurredAt = occurredAt,
      receivedBy = actorRef,
      materialType = materialType,
      status = status,
      mode = GdnMode.AUTO,
      message = message,
      payloadSnapshot = listOf(KanbanMaterialReceived.ReceivedItem(
        if (materialType == GdnMaterialType.BTP) "BTP CUT" else "MAT-1", "RED", "M", null,
        BigDecimal(if (materialType == GdnMaterialType.BTP) "2" else "10"),
      )),
      createdAt = occurredAt,
      updatedAt = occurredAt,
    )

  private fun view(createdById: String = actor.id) =
    KanbanDetailVm(
      id = "kanban-1",
      teamAssignmentId = "assignment-1",
      teamId = "team-1",
      teamName = "Team",
      styleName = "STYLE-1",
      productionOrderCode = "PO-1",
      kanbanType = "STANDARD",
      status = KanbanStatus.PENDING_EVALUATION,
      plan = emptyList(),
      items =
        listOf(
          KanbanItemVm(
            article = "MAT-1",
            alternativeName = null,
            color = Color("RED"),
            size = Size("M"),
            uom = "kg",
            totalConsumption = BigDecimal.ZERO,
            cumulativeReported = BigDecimal.ZERO,
            creatorNote = "",
            supplierNote = "",
            parts =
              listOf(
                ItemPartVm(
                  purchaseOrderId = null,
                  purchaseOrderCode = null,
                  requiredQty = BigDecimal("12"),
                  actualIssuedQty = BigDecimal.ZERO,
                  issued = false,
                  received = false,
                  supplierId = "supplier-1",
                  supplierName = "Supplier",
                ),
              ),
          ),
        ),
      createdAt = createdAt,
      createdById = createdById,
      createdByName = actor.name,
    )
}
