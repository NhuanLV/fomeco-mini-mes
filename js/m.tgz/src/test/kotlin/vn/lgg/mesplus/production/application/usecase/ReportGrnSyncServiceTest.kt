package vn.lgg.mesplus.production.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.just
import io.mockk.mockk
import io.mockk.runs
import io.mockk.slot
import io.mockk.verify
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Factory
import vn.lgg.mesplus.iam.domain.model.FactoryOperation
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.model.Warehouse
import vn.lgg.mesplus.iam.domain.repository.FactoryOperationRepository
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.inventory.application.usecase.RecordBtpProducedUseCase
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderRouting
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.repository.RoutingRepository
import vn.lgg.mesplus.order.infrastructure.repository.WfxRepository
import vn.lgg.mesplus.order.infrastructure.wfx.ResolvedWfxArticle
import vn.lgg.mesplus.order.infrastructure.wfx.WfxArticleCodeResolver
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.WfxSyncResponse
import vn.lgg.mesplus.production.application.service.ProductionOrderTypeQuery
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.GrnStatus
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.model.ReportGrn
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.ReportType
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.ReportGrnRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

class ReportGrnSyncServiceTest {
  private val assignmentRepository = mockk<TeamAssignmentRepository>()
  private val productionOrderRepository = mockk<ProductionOrderRepository>()
  private val buyerOrderRepository = mockk<BuyerOrderRepository>()
  private val purchaseOrderRepository = mockk<PurchaseOrderRepository>(relaxed = true)
  private val productionOrderTypeQuery = mockk<ProductionOrderTypeQuery>()
  private val wfxRepository = mockk<WfxRepository>(relaxed = true)
  private val routingRepository = mockk<RoutingRepository>()
  private val articleCodeResolver = mockk<WfxArticleCodeResolver>()
  private val grnRepository = mockk<ReportGrnRepository>()
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val factoryOperationRepository = mockk<FactoryOperationRepository>()
  private val eventPublisher = mockk<DomainEventPublisher>(relaxed = true)
  private val executor = mockk<ReportGrnSyncExecutor>()
  private val recordBtpProduced = mockk<RecordBtpProducedUseCase>(relaxed = true)
  private val savedGrns = mutableListOf<ReportGrn>()
  private val firstReportAt = Instant.parse("2026-07-01T00:00:00Z")

  @Test
  fun `stages output snapshot without committing progress`() {
    val assignment = assignmentWithReports()
    arrange(assignment)
    val command = slot<ReportGrnSyncCommand>()
    every { executor.execute(capture(command)) } just runs

    service().stageReport(assignment, listOf(item(10)), actor)

    assignment.rawOutputReportedTotals shouldBe emptyList()
    savedGrns.last().status shouldBe GrnStatus.PENDING
    savedGrns.last().reportSnapshot shouldBe listOf(item(10))
    command.captured.report.items shouldBe listOf(item(10))
  }

  @Test
  fun `commits progress only after WFX success`() {
    val assignment = assignmentWithReports()
    arrange(assignment)
    val command = slot<ReportGrnSyncCommand>()
    every { executor.execute(capture(command)) } just runs
    val syncService = service()

    syncService.stageReport(assignment, listOf(item(10)), actor)
    syncService.markSuccess(command.captured, WfxSyncResponse(status = "Success"))

    assignment.rawOutputReportedTotals.single().quantity shouldBe 10
    savedGrns.last().status shouldBe GrnStatus.SUCCESS
    verify(exactly = 1) { assignmentRepository.save(assignment) }
  }

  @Test
  fun `mapping failure keeps snapshot and can be cancelled`() {
    val assignment = assignmentWithReports()
    arrange(assignment, btpReceiveSite = " ")
    val syncService = service()

    syncService.stageReport(assignment, listOf(item(10)), actor)
    val failed = savedGrns.last()
    syncService.cancel("assignment-1", failed.reportedAt, actor)

    failed.status shouldBe GrnStatus.FAILED
    failed.reportSnapshot shouldBe listOf(item(10))
    savedGrns.last().status shouldBe GrnStatus.CANCELLED
    savedGrns.last().cancelledBy shouldBe actor.id
    verify(exactly = 0) { executor.execute(any()) }
  }

  @Test
  fun `markFailed ignores when status is not PENDING`() {
    val assignment = assignmentWithReports()
    arrange(assignment)
    val command = slot<ReportGrnSyncCommand>()
    every { executor.execute(capture(command)) } just runs
    val syncService = service()

    syncService.stageReport(assignment, listOf(item(10)), actor)
    syncService.markSuccess(command.captured, WfxSyncResponse(status = "Success"))
    savedGrns.last().status shouldBe GrnStatus.SUCCESS

    syncService.markFailed(command.captured, "Late failure")
    savedGrns.last().status shouldBe GrnStatus.SUCCESS
  }

  @Test
  fun `classifies report items by PO identity in a mixed assignment`() {
    val assignment = assignmentWithReports(mixed = true)
    val syncService = service()
    every { productionOrderTypeQuery.typesByPo(assignment) } returns mapOf(
      "po-1" to PurchaseOrderType.REGULAR,
      "po-positive" to PurchaseOrderType.POSITIVE,
    )

    syncService.regularItems(assignment, listOf(item(10), positiveItem(5))) shouldBe listOf(item(10))
  }

  @Test
  fun `failed regular GRN retry preserves positive output and its DocNo`() {
    val assignment = assignmentWithReports(mixed = true)
    assignment.reportProgress(ReportType.OUTPUT, listOf(positiveItem(5)), actor, firstReportAt)
    arrange(assignment)
    val commands = mutableListOf<ReportGrnSyncCommand>()
    every { executor.execute(capture(commands)) } just runs
    val syncService = service()
    syncService.stageReport(assignment, listOf(item(10)), actor, firstReportAt)
    val original = commands.single()
    shouldThrow<IllegalStateException> { syncService.requireNoActiveReport(assignment.id) }

    syncService.markFailed(original, "WFX unavailable")
    assignment.rawOutputReportedTotals.associate { it.purchaseOrderId to it.quantity } shouldBe mapOf("po-positive" to 5)
    shouldThrow<IllegalStateException> { syncService.requireNoActiveReport(assignment.id) }
    val retryActor = ActorRef("actor-2", "Retry user")
    syncService.retry(assignment.id, original.reportedAt, retryActor)
    val retried = commands.last()
    retried.docNo shouldBe original.docNo
    retried.report.items shouldBe listOf(item(10))
    retried.report.reportedBy shouldBe actor
    savedGrns.last().reportedBy shouldBe actor
    syncService.markSuccess(retried, WfxSyncResponse(status = "Success"))
    syncService.markSuccess(retried, WfxSyncResponse(status = "Success"))

    assignment.rawOutputReportedTotals.associate { it.purchaseOrderId to it.quantity } shouldBe
      mapOf("po-positive" to 5, "po-1" to 10)
    savedGrns.last().status shouldBe GrnStatus.SUCCESS
    verify(exactly = 1) { recordBtpProduced.execute(assignment, listOf(item(10)), firstReportAt, actor, "") }
    verify(exactly = 1) { assignmentRepository.save(assignment) }
  }

  @Test
  fun `cancelling failed regular GRN keeps completed positive output`() {
    val assignment = assignmentWithReports(mixed = true)
    assignment.reportProgress(ReportType.OUTPUT, listOf(positiveItem(5)), actor, firstReportAt)
    arrange(assignment, btpReceiveSite = " ")
    val syncService = service()
    syncService.stageReport(assignment, listOf(item(10)), actor, firstReportAt)

    syncService.cancel(assignment.id, firstReportAt, actor)

    assignment.rawOutputReportedTotals.associate { it.purchaseOrderId to it.quantity } shouldBe mapOf("po-positive" to 5)
    savedGrns.last().status shouldBe GrnStatus.CANCELLED
    syncService.requireNoActiveReport(assignment.id)
    verify(exactly = 0) { recordBtpProduced.execute(any(), any(), any(), any(), any()) }
  }

  @Test
  fun `editing failed GRN replaces only its regular snapshot at the original time`() {
    val assignment = assignmentWithReports(mixed = true)
    assignment.reportProgress(ReportType.OUTPUT, listOf(positiveItem(5)), actor, firstReportAt)
    arrange(assignment, btpReceiveSite = " ")
    val syncService = service()
    syncService.stageReport(assignment, listOf(item(10)), actor, firstReportAt)

    shouldThrow<IllegalStateException> {
      syncService.stageReport(assignment, listOf(item(8)), actor, firstReportAt.plusSeconds(1))
    }
    syncService.stageReport(assignment, listOf(item(8)), actor, firstReportAt)

    savedGrns.last().reportSnapshot shouldBe listOf(item(8))
    savedGrns.last().reportedAt shouldBe firstReportAt
    assignment.rawOutputReportedTotals.associate { it.purchaseOrderId to it.quantity } shouldBe
      mapOf("po-positive" to 5)
  }

  @Test
  fun `rejects positive quantities in a GRN snapshot`() {
    val assignment = assignmentWithReports(mixed = true)
    arrange(assignment)

    shouldThrow<IllegalArgumentException> {
      service().stageReport(assignment, listOf(item(10), positiveItem(5)), actor, firstReportAt)
    }

    savedGrns shouldBe emptyList()
    verify(exactly = 0) { executor.execute(any()) }
  }

  private fun arrange(
    assignment: TeamAssignment,
    routing: List<String> = listOf(assignment.operation.name),
    btpReceiveSite: String? = "BTP-IN",
  ) {
    savedGrns.clear()
    val grns = mutableMapOf<Instant, ReportGrn>()
    every { assignmentRepository.findById("assignment-1") } returns assignment
    every { assignmentRepository.save(any()) } answers { firstArg() }
    every { productionOrderRepository.findById("production-1") } returns productionOrder(routing)
    every { buyerOrderRepository.findById("bo-1") } returns buyerOrder()
    every { routingRepository.findByBuyerOrderId("bo-1") } returns BuyerOrderRouting(
      "bo-1",
      emptyList(),
    )
    every { articleCodeResolver.resolveFinishedProduct("STYLE-1") } returns
      ResolvedWfxArticle("LGG11ARTICLE", "PCS")
    every { orgUnitRepository.findById("team-1") } returns
      Team("team-1", "Team", "factory-1", "factory-1", Operation(assignment.operation.name), true)
    every { orgUnitRepository.findById("factory-1") } returns
      Factory("factory-1", "Factory", "company-1", "", "company-1", emptyList(), true)
    val warehouseId = if (btpReceiveSite != null) "wh-btp" else null
    every { orgUnitRepository.findById("wh-btp") } returns
      Warehouse(
        "wh-btp",
        "Kho BTP",
        "company-1",
        "",
        "company-1",
        true,
        "WH-BTP",
        siteName = btpReceiveSite,
      )
    every {
      factoryOperationRepository.findByFactoryIdAndOperationCode(
        "factory-1",
        assignment.operation.name,
      )
    } returns
      FactoryOperation(
        id = "operation-config-1",
        companyId = "company-1",
        companyCode = "COMPANY-1",
        factoryId = "factory-1",
        operationCode = assignment.operation.name,
        operationName = assignment.operation.name,
        btpReceiveWarehouseId = warehouseId,
      )
    every { grnRepository.findByAssignmentIdAndReportedAt("assignment-1", any()) } answers {
      grns[secondArg()]
    }
    every { grnRepository.findByAssignmentId("assignment-1") } answers { grns.values.toList() }
    every { grnRepository.save(any()) } answers {
      val record = firstArg<ReportGrn>()
      grns[record.reportedAt] = record
      savedGrns += record
    }
  }

  private fun service() =
    ReportGrnSyncService(
      assignmentRepository,
      productionOrderRepository,
      buyerOrderRepository,
      productionOrderTypeQuery.also {
        every { it.typesByPo(any<TeamAssignment>()) } returns mapOf(
          "po-1" to PurchaseOrderType.REGULAR,
          "po-positive" to PurchaseOrderType.POSITIVE,
        )
      },
      purchaseOrderRepository,
      wfxRepository,
      routingRepository,
      articleCodeResolver,
      grnRepository,
      orgUnitRepository,
      factoryOperationRepository,
      eventPublisher,
      executor,
      recordBtpProduced,
    )

  private fun assignmentWithReports(vararg reportedAts: Instant, operation: String = "CUT", mixed: Boolean = false) =
    TeamAssignment("assignment-1").apply {
      loadFromHistory(
        listOf(
          TeamAssignmentCreated(
            assignmentId = "assignment-1",
            productionOrderId = "production-1",
            buyerOrderId = "bo-1",
            teamId = "team-1",
            operation = Operation(operation),
            allocations = listOf(SkuAllocation("po-1", Color("RED"), Size("M"), 100)) +
              if (mixed) listOf(SkuAllocation("po-positive", Color("RED"), Size("M"), 100)) else emptyList(),
            plannedStartDate = LocalDate.of(2026, 1, 1),
            plannedEndDate = LocalDate.of(2026, 1, 10),
            assignedAt = firstReportAt,
            actor = actor,
            occurredAt = firstReportAt,
          ),
          ProgressReported(
            "assignment-1",
            ReportType.INPUT,
            listOf(item(100)) + if (mixed) listOf(positiveItem(100)) else emptyList(),
            actor,
            firstReportAt.minusSeconds(1),
          ),
          *reportedAts.map { event(it) }.toTypedArray(),
        ),
      )
    }

  private fun event(occurredAt: Instant) =
    ProgressReported("assignment-1", ReportType.OUTPUT, listOf(item(10)), actor, occurredAt)

  private fun productionOrder(routing: List<String>) =
    ProductionOrder(
      id = "production-1",
      buyerOrderId = "bo-1",
      productionCode = "STYLE-1",
      factoryIds = listOf("factory-1"),
      mainCompanyCode = "LGG-BG",
      status = ProductionOrderStatus.IN_PROGRESS,
      routing = routing,
    )

  private fun buyerOrder() =
    BuyerOrder(
      id = "bo-1",
      wfxId = "BO-WFX-1",
      styleName = "STYLE-1",
      revisionCode = "R1",
      revisionDate = firstReportAt,
      articleCode = "STYLE-1",
    )

  private fun positiveItem(quantity: Int) = ReportItem("po-positive", Color("RED"), Size("M"), quantity)

  private fun item(quantity: Int) = ReportItem("po-1", Color("RED"), Size("M"), quantity)

  private companion object {
    val actor = ActorRef("user-1", "User")
  }
}
