package vn.lgg.mesplus.order.infrastructure.wfx

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import io.mockk.verifyOrder
import java.io.IOException
import java.time.LocalDate
import org.junit.jupiter.api.Test
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.TransactionDefinition
import org.springframework.transaction.support.SimpleTransactionStatus
import org.springframework.transaction.support.TransactionTemplate
import vn.lgg.mesplus.order.application.usecase.UpsertBomUseCase
import vn.lgg.mesplus.order.application.usecase.UpsertBuyerOrderUseCase
import vn.lgg.mesplus.order.application.usecase.UpsertRoutingCommand
import vn.lgg.mesplus.order.application.usecase.UpsertRoutingUseCase
import vn.lgg.mesplus.order.application.usecase.UpsertStyleUseCase
import vn.lgg.mesplus.order.application.usecase.command.UpsertBuyerOrderCommand
import vn.lgg.mesplus.order.domain.model.BillOfMaterial
import vn.lgg.mesplus.app.config.property.WfxProperties
import vn.lgg.mesplus.order.infrastructure.repository.WfxRepository
import vn.lgg.mesplus.order.infrastructure.wfx.client.WfxClient
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.WfxArticleDto

class WfxServiceTest {
  private val wfxClient = mockk<WfxClient>()
  private val wfxMapper = mockk<WfxMapper>()
  private val upsertBuyerOrder = mockk<UpsertBuyerOrderUseCase>()
  private val upsertStyle = mockk<UpsertStyleUseCase>()
  private val upsertBom = mockk<UpsertBomUseCase>()
  private val upsertRouting = mockk<UpsertRoutingUseCase>()
  private val wfxRepository = mockk<WfxRepository>()
  private val transactionManager = mockk<PlatformTransactionManager>()

  @Test
  fun `syncs buyer orders sequentially in isolated transactions`() {
    val first =
      UpsertBuyerOrderCommand(
        wfxId = "first",
        styleName = "style-1",
        purchaseOrders = emptyList(),
      )
    val second =
      UpsertBuyerOrderCommand(
        wfxId = "second",
        styleName = "style-2",
        purchaseOrders = emptyList(),
      )
    val firstTransaction = SimpleTransactionStatus()
    val secondTransaction = SimpleTransactionStatus()
    val bom = mockk<BillOfMaterial>()
    val routing = mockk<UpsertRoutingCommand>()

    every { transactionManager.getTransaction(any<TransactionDefinition>()) } returnsMany
      listOf(firstTransaction, secondTransaction)
    justRun { transactionManager.rollback(firstTransaction) }
    justRun { transactionManager.commit(secondTransaction) }
    val wfxProperties = mockk<WfxProperties>()
    every { wfxProperties.resolvedCompanyNames } returns listOf("company-1")
    every { wfxClient.properties } returns wfxProperties
    every { wfxClient.getPurchaseOrders(any(), any()) } returns emptyList()
    every { wfxMapper.toSyncStyleCommands(emptyList()) } returns emptyList()
    every { wfxMapper.toBuyerOrders(emptyList()) } returns listOf(first, second)
    justRun { upsertBuyerOrder.execute(any()) }
    every { wfxClient.getBom("first") } throws IOException("failed")
    every { wfxClient.getBom("second") } returns emptyList()
    every { wfxMapper.toBom("second", emptyList()) } returns bom
    every { wfxMapper.toUpsertRoutingCommand("second", emptyList()) } returns routing
    justRun { upsertBom.execute(bom) }
    justRun { upsertRouting.execute(routing) }
    every { wfxClient.getArticles(any(), any()) } returns emptyList()
    justRun { wfxRepository.upsertArticles(emptyList()) }
    every { wfxMapper.toArticleStyleCommands(emptyList()) } returns emptyList()

    service().syncBuyerOrder(LocalDate.of(2026, 7, 20))

    verifyOrder {
      wfxClient.getArticles(LocalDate.of(2026, 7, 20), "Apparel")
      wfxClient.getArticles(LocalDate.of(2026, 7, 20), "Textiles/Fabric")
      wfxClient.getArticles(LocalDate.of(2026, 7, 20), "Trims")
      wfxRepository.upsertArticles(emptyList())
      wfxClient.getPurchaseOrders(LocalDate.of(2026, 7, 20), "company-1")
      upsertBuyerOrder.execute(first)
      wfxClient.getBom("first")
      upsertBuyerOrder.execute(second)
      wfxClient.getBom("second")
    }
    verify(exactly = 1) { transactionManager.rollback(firstTransaction) }
    verify(exactly = 1) { transactionManager.commit(secondTransaction) }
  }

  @Test
  fun `scheduled article sync uses yesterday without syncing buyer orders`() {
    every { wfxClient.getArticles(any(), any()) } returns emptyList()
    justRun { wfxRepository.upsertArticles(emptyList()) }
    every { wfxMapper.toArticleStyleCommands(emptyList()) } returns emptyList()

    service().syncArticleMasterIncrementally()

    val yesterday = LocalDate.now().minusDays(1)
    verify(exactly = 1) { wfxClient.getArticles(yesterday, "Apparel") }
    verify(exactly = 1) { wfxClient.getArticles(yesterday, "Textiles/Fabric") }
    verify(exactly = 1) { wfxClient.getArticles(yesterday, "Trims") }
    verify(exactly = 1) { wfxRepository.upsertArticles(emptyList()) }
    verify(exactly = 0) { wfxClient.getPurchaseOrders(any(), any()) }
    val scheduledAnnotation =
      WfxService::class.java
        .getDeclaredMethod("syncArticleMasterIncrementally")
        .getAnnotation(org.springframework.scheduling.annotation.Scheduled::class.java)
    scheduledAnnotation?.fixedRate shouldBe 300_000L
    scheduledAnnotation?.initialDelay shouldBe 300_000L
  }

  @Test
  fun `article sync stores all categories but updates styles from apparel only`() {
    val apparel = article("apparel")
    val fabric = article("fabric")
    val trims = article("trims")
    every { wfxClient.getArticles(LocalDate.of(2025, 1, 1), "Apparel") } returns listOf(apparel)
    every { wfxClient.getArticles(LocalDate.of(2025, 1, 1), "Textiles/Fabric") } returns listOf(fabric)
    every { wfxClient.getArticles(LocalDate.of(2025, 1, 1), "Trims") } returns listOf(trims)
    justRun { wfxRepository.upsertArticles(listOf(apparel, fabric, trims)) }
    every { wfxMapper.toArticleStyleCommands(listOf(apparel)) } returns emptyList()

    service().syncArticleMaster(LocalDate.of(2025, 1, 1))

    verify(exactly = 1) { wfxRepository.upsertArticles(listOf(apparel, fabric, trims)) }
    verify(exactly = 1) { wfxMapper.toArticleStyleCommands(listOf(apparel)) }
  }

  @Test
  fun `article category failure fails the sync before persisting partial results`() {
    every { wfxClient.getArticles(LocalDate.of(2025, 1, 1), "Apparel") } returns emptyList()
    every { wfxClient.getArticles(LocalDate.of(2025, 1, 1), "Textiles/Fabric") } throws
      IOException("fabric unavailable")

    org.junit.jupiter.api.assertThrows<IOException> {
      service().syncArticleMaster(LocalDate.of(2025, 1, 1))
    }

    verify(exactly = 0) { wfxClient.getArticles(LocalDate.of(2025, 1, 1), "Trims") }
    verify(exactly = 0) { wfxRepository.upsertArticles(any()) }
    verify(exactly = 0) { wfxMapper.toArticleStyleCommands(any()) }
  }

  private fun article(name: String) =
    WfxArticleDto(
      articleId = name,
      articleCode = "$name-code",
      articleName = name,
      storingUom = "PCS",
      baseColorList = emptyList(),
      baseSizeList = emptyList(),
    )

  private fun service() =
    WfxService(
      wfxClient,
      wfxMapper,
      upsertBuyerOrder,
      upsertStyle,
      upsertBom,
      upsertRouting,
      wfxRepository,
      TransactionTemplate(transactionManager),
    )
}
