package vn.lgg.mesplus.production.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.application.usecase.CreateKanbanCommand
import vn.lgg.mesplus.kanban.application.usecase.CreateKanbanUseCase
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.production.application.service.ProductionOrderTypeQuery
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import io.mockk.justRun
import java.time.Instant
import java.util.UUID
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderStatus
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size

class CancelledProductionOrderGuardsTest {
  private val order = ProductionOrder("lsx", "bo", "LSX", listOf("factory"), "MAIN", ProductionOrderStatus.CANCELLED)
  private val orders = mockk<ProductionOrderRepository> {
    every { lockById("lsx") } returns order
  }
  private val assignments = mockk<TeamAssignmentRepository>()

  @Test
  fun `cancelling last order resets buyer order status and effective completed quantity`() {
    val bo = BuyerOrder("bo", "BO", "Style", "R1", Instant.EPOCH)
    bo.status = BuyerOrderStatus.COMPLETED
    bo.completedQuantity = 100
    val buyerOrders = mockk<BuyerOrderRepository>()
    val purchaseOrders = mockk<PurchaseOrderRepository>()
    val allocation = mockk<AllocationQueryService>()
    every { buyerOrders.lockById("bo") } returns bo
    justRun { buyerOrders.save(any()) }
    every { orders.findById("lsx") } returns order
    every { assignments.findByBuyerOrderId("bo") } returns listOf(mockk {
      every { productionOrderId } returns "lsx"
    })
    every { purchaseOrders.findByBuyerOrderId("bo") } returns emptyList()
    every { allocation.getRemainingSku(bo, emptyList()) } returns listOf(
      SkuAllocation("po", Color("Red"),
        Size("S"), 100),
    )
    UpdateBuyerOrderStatusUseCase(buyerOrders, purchaseOrders, assignments, allocation, orders).execute("bo")
    bo.status shouldBe BuyerOrderStatus.NEW
    bo.completedQuantity shouldBe 0
  }

  @Test
  fun `late status listener locks and returns without reviving order`() {
    UpdateProductionOrderStatusUseCase(orders, assignments).execute("lsx")
    verify(exactly = 0) { orders.save(any()) }
    verify(exactly = 0) { assignments.findByProductionOrderId(any()) }
  }

  @Test
  fun `create kanban reads parent under shared lock before saving`() {
    val kanbans = mockk<KanbanRepository>()
    every { assignments.findById("ta") } returns mockk<TeamAssignment> {
      every { productionOrderId } returns "lsx"
    }
    val useCase = CreateKanbanUseCase(kanbans, mockk<DomainEventPublisher>(),
      { UUID.randomUUID() }, assignments, mockk<ProductionOrderTypeQuery>(), orders)
    shouldThrow<IllegalStateException> {
      useCase.execute(CreateKanbanCommand("ta", emptyList(), emptyList(), ""),
        Actor("actor", "Planner", "", "", emptyList(), emptySet()))
    }
    verify(exactly = 0) { kanbans.save(any()) }
  }
}
