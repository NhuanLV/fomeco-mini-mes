package vn.lgg.mesplus.kanban.application.eventhandler

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.clearMocks
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.math.BigDecimal
import java.time.LocalDate
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.domain.event.ExtraKanbanApproved
import vn.lgg.mesplus.kanban.domain.event.KanbanApproved
import vn.lgg.mesplus.kanban.domain.event.KanbanCreated
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialIssued
import vn.lgg.mesplus.kanban.domain.event.KanbanRejected
import vn.lgg.mesplus.kanban.domain.event.KanbanRevised
import vn.lgg.mesplus.kanban.domain.model.Kanban
import vn.lgg.mesplus.kanban.domain.model.KanbanItem
import vn.lgg.mesplus.kanban.domain.model.KanbanItemType
import vn.lgg.mesplus.kanban.domain.model.PlanItem
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.Activity
import vn.lgg.mesplus.shared.Notifier
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.PermissionService

class KanbanNotificationTest {
  private val kanbanRepository = mockk<KanbanRepository>()
  private val assignmentRepository = mockk<TeamAssignmentRepository>()
  private val permissionService = mockk<PermissionService>()
  private val notifier = mockk<Notifier>(relaxed = true)
  private val creator =
    KanbanNotificationCreator(
      kanbanRepository,
      assignmentRepository,
      permissionService,
      notifier,
      mockk(),
    )
  private val creatorRef = ActorRef("creator-1", "Tổ trưởng")
  private val approverRef = ActorRef("approver-1", "Phó giám đốc")

  @BeforeEach
  fun setUp() {
    clearMocks(notifier)
    every { assignmentRepository.findById("assignment-1") } returns assignment()
  }

  @Test
  fun `created and revised kanban notify first approvers for its team`() {
    val kanban = standardKanban()
    every { kanbanRepository.findById("kanban-1") } returns kanban
    every { permissionService.lookupAccountIds(Permission.EVALUATE_KANBAN, "team-1") } returns
      listOf("approver-1")

    creator.create(kanban.allEvents.filterIsInstance<KanbanCreated>().single())
    kanban.reject("Thiếu thông tin", approverRef)
    kanban.revised(listOf(item(BigDecimal("2"), "warehouse-1")), creatorRef)
    creator.create(kanban.changes.filterIsInstance<KanbanRevised>().single())

    verify(exactly = 2) {
      notifier.notify(match<Collection<String>> { it.toList() == listOf("approver-1") }, any())
    }
  }

  @Test
  fun `first approval of extra kanban notifies only second approvers`() {
    val kanban = extraKanban().apply { approve(approverRef) }
    every { kanbanRepository.findById("kanban-1") } returns kanban
    every {
      permissionService.lookupAccountIds(Permission.EVALUATE_EXTRA_KANBAN, "team-1")
    } returns listOf("extra-approver")

    creator.create(kanban.changes.filterIsInstance<KanbanApproved>().single())

    verify(exactly = 1) {
      notifier.notify(match<Collection<String>> { it.toList() == listOf("extra-approver") }, any())
    }
  }

  @Test
  fun `final approval groups warehouse recipients across suppliers`() {
    val standard = standardKanban().apply { approve(approverRef) }
    every { kanbanRepository.findById("kanban-1") } returns standard
    every { permissionService.lookupAccountIds(Permission.ISSUE_MATERIAL, "warehouse-1") } returns
      listOf("keeper-shared", "keeper-1")
    every { permissionService.lookupAccountIds(Permission.ISSUE_MATERIAL, "warehouse-2") } returns
      listOf("keeper-shared", "keeper-2")
    val recipients = slot<Collection<String>>()
    val activity = slot<Activity>()

    creator.create(standard.changes.filterIsInstance<KanbanApproved>().single())

    verify(exactly = 1) { notifier.notify(capture(recipients), capture(activity)) }
    recipients.captured.shouldContainExactly("keeper-shared", "keeper-1", "keeper-2")
    activity.captured.body shouldBe "đã duyệt Kanban NBAN-1, cần chuẩn bị vật tư"
    activity.captured.target.resourceType shouldBe ResourceType.KANBAN

    clearMocks(notifier)
    val extra = extraKanban().apply { approve(approverRef); approveExtra(approverRef) }
    every { kanbanRepository.findById("kanban-1") } returns extra
    creator.create(extra.changes.filterIsInstance<ExtraKanbanApproved>().single())
    verify(exactly = 1) { notifier.notify(any<Collection<String>>(), any()) }
  }

  @Test
  fun `rejection notifies only creator with reason`() {
    val kanban = standardKanban().apply { reject("Sai định mức", approverRef) }
    every { kanbanRepository.findById("kanban-1") } returns kanban
    val activity = slot<Activity>()

    creator.create(kanban.changes.filterIsInstance<KanbanRejected>().single())

    verify(exactly = 1) { notifier.notify(listOf("creator-1"), capture(activity)) }
    activity.captured.body shouldBe "đã từ chối Kanban NBAN-1: Sai định mức, cần điều chỉnh"
  }

  @Test
  fun `material issued notifies creator to receive materials`() {
    every { kanbanRepository.findById("kanban-1") } returns standardKanban()
    val event =
      KanbanMaterialIssued(
        kanbanId = "kanban-1",
        supplierUnitId = "warehouse-1",
        items = emptyList(),
        actor = approverRef,
      )
    val activity = slot<Activity>()

    creator.create(event)

    verify(exactly = 1) { notifier.notify(listOf("creator-1"), capture(activity)) }
    activity.captured.body shouldBe "đã cấp phát Kanban NBAN-1, cần xác nhận nhận vật tư"
  }

  private fun standardKanban(): Kanban {
    val created =
      Kanban.create(
        "kanban-1",
        "assignment-1",
        listOf(PlanItem("po-1", Color("Red"), Size("S"), 10)),
        listOf(item(BigDecimal.ONE, "warehouse-1"), item(BigDecimal.ONE, "warehouse-2", "MAT-2")),
        "",
        creatorRef,
      )
    return Kanban("kanban-1").apply { loadFromHistory(created.changes) }
  }

  private fun extraKanban(): Kanban {
    val created =
      Kanban.create(
        "kanban-1",
        "assignment-1",
        emptyList(),
        listOf(item(BigDecimal.ONE, "warehouse-1"), item(BigDecimal.ONE, "warehouse-2", "MAT-2")),
        "Ngoài định mức",
        creatorRef,
      )
    return Kanban("kanban-1").apply { loadFromHistory(created.changes) }
  }

  private fun item(quantity: BigDecimal, supplierUnitId: String, article: String = "MAT-1") =
    KanbanItem(
      article = article,
      color = Color("Red"),
      size = Size("S"),
      purchaseOrderId = "po-1",
      type = KanbanItemType.MATERIAL,
      requiredQty = quantity,
      supplierUnitId = supplierUnitId,
      creatorNote = "",
    )

  private fun assignment() =
    TeamAssignment.create(
      id = "assignment-1",
      productionOrderId = "lsx-1",
      buyerOrderId = "bo-1",
      teamId = "team-1",
      operation = Operation("Cut"),
      allocations = listOf(SkuAllocation("po-1", Color("Red"), Size("S"), 1)),
      plannedStartDate = LocalDate.of(2026, 1, 1),
      plannedEndDate = LocalDate.of(2026, 1, 10),
    )
}
