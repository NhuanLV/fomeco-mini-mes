package vn.lgg.mesplus.iam.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.util.UUID
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.util.IdGenerator
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.Factory
import vn.lgg.mesplus.iam.domain.model.FactoryOperation
import vn.lgg.mesplus.iam.domain.model.Warehouse
import vn.lgg.mesplus.iam.domain.repository.FactoryOperationRepository
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

class CreateFactoryOperationUseCaseTest {
  private val repository = mockk<FactoryOperationRepository>()
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val permissionService = mockk<PermissionService>()
  private val idGenerator = mockk<IdGenerator>()
  private val actor = Actor("actor-1", "Admin", "admin", "", emptyList(), emptySet())
  private val useCase =
    CreateFactoryOperationUseCase(repository, orgUnitRepository, permissionService, idGenerator)

  @BeforeEach
  fun setUp() {
    justRun { permissionService.requirePermission(actor, listOf(Permission.MANAGE_ORG), any()) }
    every { orgUnitRepository.findById("company-1") } returns
      Company(
        id = "company-1",
        name = "Company",
        parentId = "corporation-1",
        address = "",
        code = " comp-1 ",
      )
    every { orgUnitRepository.findById("factory-1") } returns
      Factory("factory-1", "Factory", "company-1", "", "company-1", emptyList(), true)
    every { orgUnitRepository.findById("warehouse-1") } returns
      Warehouse("warehouse-1", "Warehouse", "company-1", "", "company-1", true)
    every { orgUnitRepository.findById("warehouse-2") } returns
      Warehouse("warehouse-2", "Warehouse", "company-1", "", "company-1", true)
    every { repository.existsByFactoryIdAndOperationCode("factory-1", " cut-1 ", null) } returns false
    every { idGenerator.generateId() } returns UUID.fromString("11111111-1111-1111-1111-111111111111")
    justRun { repository.save(any()) }
  }

  @Test
  fun `keeps operation mapping input values`() {
    val saved = slot<FactoryOperation>()
    justRun { repository.save(capture(saved)) }

    useCase.execute(
      CreateFactoryOperationCommand(
        companyId = "company-1",
        factoryId = "factory-1",
        operationCode = " cut-1 ",
        operationName = " Cắt ",
        materialDispatchWarehouseId = "warehouse-1",
        btpReceiveWarehouseId = "warehouse-2",
      ),
      actor,
    )

    saved.captured.companyCode shouldBe " comp-1 "
    saved.captured.operationCode shouldBe " cut-1 "
    saved.captured.operationName shouldBe " Cắt "
    saved.captured.factoryId shouldBe "factory-1"
    saved.captured.materialDispatchWarehouseId shouldBe "warehouse-1"
    saved.captured.btpReceiveWarehouseId shouldBe "warehouse-2"
    verify(exactly = 1) { repository.save(any()) }
  }

  @Test
  fun `allows empty site fields`() {
    val saved = slot<FactoryOperation>()
    justRun { repository.save(capture(saved)) }

    useCase.execute(
      CreateFactoryOperationCommand(
        companyId = "company-1",
        factoryId = "factory-1",
        operationCode = " cut-1 ",
        operationName = "Cắt",
        materialDispatchWarehouseId = null,
        btpReceiveWarehouseId = null,
      ),
      actor,
    )

    saved.captured.materialDispatchWarehouseId shouldBe null
    saved.captured.btpReceiveWarehouseId shouldBe null
  }

  @Test
  fun `rejects duplicate factory operation mapping`() {
    every { repository.existsByFactoryIdAndOperationCode("factory-1", "CUT-1", null) } returns true

    shouldThrow<IllegalStateException> {
      useCase.execute(
        CreateFactoryOperationCommand(
          companyId = "company-1",
          factoryId = "factory-1",
          operationCode = "CUT-1",
          operationName = "Cắt",
        ),
        actor,
      )
    }

    verify(exactly = 0) { repository.save(any()) }
  }

  @Test
  fun `rejects factory not belonging to selected company`() {
    every { orgUnitRepository.findById("factory-other") } returns
      Factory("factory-other", "Factory Other", "company-2", "", "company-2", emptyList(), true)

    shouldThrow<IllegalArgumentException> {
      useCase.execute(
        CreateFactoryOperationCommand(
          companyId = "company-1",
          factoryId = "factory-other",
          operationCode = "CUT-1",
          operationName = "Cắt",
        ),
        actor,
      )
    }
  }

  @Test
  fun `rejects non-existent warehouse`() {
    every { orgUnitRepository.findById("invalid-warehouse") } returns null

    shouldThrow<IllegalArgumentException> {
      useCase.execute(
        CreateFactoryOperationCommand(
          companyId = "company-1",
          factoryId = "factory-1",
          operationCode = "CUT-1",
          operationName = "Cắt",
          materialDispatchWarehouseId = "invalid-warehouse",
        ),
        actor,
      )
    }
  }
}
