package vn.lgg.mesplus.production.application.service

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.production.domain.event.TeamAssignmentAllocationRevised
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.event.TeamAssignmentEvent
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

class ProductionOrderTypeQueryTest {
  private val assignments = mockk<TeamAssignmentRepository>()
  private val orders = mockk<PurchaseOrderRepository>()
  private val query = ProductionOrderTypeQuery(assignments, orders)

  @Test
  fun `uses sibling allocation when current assignment has none`() {
    val current = assignment(emptyList())
    val sibling = assignment(listOf(SkuAllocation("po-1", Color("RED"), Size("M"), 1)))
    every { assignments.findByProductionOrderId("lsx-1") } returns listOf(current, sibling)
    every { orders.findByBuyerOrderId("bo-1") } returns listOf(purchaseOrder())

    every { assignments.findEventsById("assignment") } returns current.allEvents.filterIsInstance<TeamAssignmentEvent>()

    query.legacyTypeAt("assignment", Instant.MAX) shouldBe PurchaseOrderType.POSITIVE
    verify(exactly = 1) { orders.findByBuyerOrderId("bo-1") }
  }

  @Test
  fun `rejects missing PO rather than treating LSX as regular`() {
    every { orders.findByBuyerOrderId("bo-1") } returns emptyList()

    every { assignments.findEventsById("assignment") } returns
      assignment(listOf(SkuAllocation("po-1", Color("RED"), Size("M"), 1))).allEvents.filterIsInstance<TeamAssignmentEvent>()

    shouldThrow<IllegalStateException> {
      query.legacyTypeAt("assignment", Instant.MAX)
    }
  }

  @Test
  fun `legacy Kanban type follows allocation at creation before a later revision`() {
    val assignments = mockk<TeamAssignmentRepository>()
    val orders = mockk<PurchaseOrderRepository>()
    val query = ProductionOrderTypeQuery(assignments, orders)
    val allocation = SkuAllocation("positive", Color("Red"), Size("M"), 10)
    val created = Instant.parse("2026-09-01T00:00:00Z")
    val revised = created.plusSeconds(60)
    every { assignments.findEventsById("assignment") } returns listOf(
      TeamAssignmentCreated("assignment", "production", "buyer", "team", Operation("SEW"),
        listOf(allocation), LocalDate.MIN, LocalDate.MAX, created, null, created),
      TeamAssignmentAllocationRevised("assignment", "Mixed", listOf(allocation,
        allocation.copy(purchaseOrderId = "regular")), null, revised),
    )
    every { orders.findByBuyerOrderId("buyer") } returns listOf(
      mockk<PurchaseOrder> { every { id } returns "positive"; every { type } returns PurchaseOrderType.POSITIVE },
      mockk<PurchaseOrder> { every { id } returns "regular"; every { type } returns PurchaseOrderType.REGULAR },
    )
    query.legacyTypeAt("assignment", created.plusSeconds(1)) shouldBe PurchaseOrderType.POSITIVE
    query.legacyTypeAt("assignment", revised) shouldBe PurchaseOrderType.REGULAR
  }

  private fun assignment(allocations: List<SkuAllocation>) = TeamAssignment("assignment").apply {
    loadFromHistory(listOf(TeamAssignmentCreated(
      "assignment", "lsx-1", "bo-1", "team", Operation("SEW"), allocations,
      LocalDate.MIN, LocalDate.MAX, Instant.EPOCH, null, Instant.EPOCH,
    )))
  }

  private fun purchaseOrder() = PurchaseOrder(
    "po-1", null, "PO-1", "US", LocalDate.of(2026, 1, 1), emptyList(), "bo-1",
    PurchaseOrderType.POSITIVE,
  )
}
