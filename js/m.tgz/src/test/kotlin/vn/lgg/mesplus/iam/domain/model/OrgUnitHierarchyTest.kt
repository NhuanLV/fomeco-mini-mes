package vn.lgg.mesplus.iam.domain.model

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository

class OrgUnitHierarchyTest {
  private val repository = mockk<OrgUnitRepository>()

  @Test
  fun `resolves the complete current team hierarchy`() {
    every { repository.findByIds(listOf("team-1")) } returns listOf(team())
    every { repository.findByIds(listOf("factory-1")) } returns listOf(factory())
    every { repository.findByIds(listOf("company-1")) } returns listOf(company())

    repository.resolveTeamHierarchies(listOf("team-1")).getValue("team-1").fullName shouldBe
      "Team - Factory - Company"
  }

  @Test
  fun `fails when a team parent relation is missing`() {
    every { repository.findByIds(listOf("team-1")) } returns listOf(team())
    every { repository.findByIds(listOf("factory-1")) } returns emptyList()

    shouldThrow<NoSuchElementException> { repository.resolveTeamHierarchies(listOf("team-1")) }
  }

  private fun team() = Team("team-1", "Team", "factory-1", "factory-1", vn.lgg.mesplus.shared.model.Operation("SEW"), true)

  private fun factory() = Factory("factory-1", "Factory", "company-1", "", "company-1", emptyList(), true)

  private fun company() = Company("company-1", "Company", "root", "", null, true)
}
