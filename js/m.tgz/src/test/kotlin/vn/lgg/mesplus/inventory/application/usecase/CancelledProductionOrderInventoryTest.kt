package vn.lgg.mesplus.inventory.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import java.math.BigDecimal
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.domain.repository.ReturnRequestRepository
import vn.lgg.mesplus.inventory.domain.repository.TransferRequestAssignmentRepository
import vn.lgg.mesplus.inventory.domain.repository.TransferRequestRepository
import vn.lgg.mesplus.production.application.service.ProductionOrderWriteGuard
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import java.util.UUID

class CancelledProductionOrderInventoryTest {
  private val assignments = mockk<TeamAssignmentRepository>()
  private val orders = mockk<ProductionOrderRepository>()
  private val guard = ProductionOrderWriteGuard(assignments, orders)
  private val actor = Actor("actor", "Planner", "", "", emptyList(), emptySet())

  init {
    for (id in listOf("source", "target")) {
      every { assignments.findById(id) } returns mockk { every { productionOrderId } returns id }
      every { orders.findById(id) } returns ProductionOrder(id, "bo", id, listOf("factory"), "MAIN",
        if (id == "source") ProductionOrderStatus.IN_PROGRESS else ProductionOrderStatus.CANCELLED)
    }
  }

  @Test
  fun `cannot create or update transfer to cancelled target`() {
    val validation = TransferRequestValidationService(mockk(), assignments, mockk(), mockk(), guard)
    shouldThrow<IllegalStateException> {
      validation.validateAndMap("source", listOf(TransferRequestItemCmd("target", "Fabric", "Red", "S", "M", BigDecimal.ONE)))
    }
  }

  @Test
  fun `cannot receive transfer after target order was cancelled`() {
    val requests = mockk<TransferRequestRepository>()
    val receipts = mockk<TransferRequestAssignmentRepository>()
    every { requests.findById("transfer") } returns mockk { every { sourceTeamAssignmentId } returns "source" }
    shouldThrow<IllegalStateException> {
      ReceiveTransferMaterialUseCase(receipts, mockk(), requests, guard)
        .execute("transfer", "target", ReceiveTransferMaterialCommand(emptyList()), actor)
    }
    verify(exactly = 0) { receipts.save(any()) }
  }

  @Test
  fun `cannot create return request from cancelled order`() {
    val requests = mockk<ReturnRequestRepository>()
    shouldThrow<IllegalStateException> {
      CreateReturnRequestUseCase(requests, mockk(), { UUID.randomUUID() }, mockk<DomainEventPublisher>(), guard)
        .execute(CreateReturnRequestCommand("target", emptyList()), actor)
    }
    verify(exactly = 0) { requests.save(any()) }
  }
}
