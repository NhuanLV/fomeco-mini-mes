package vn.lgg.mesplus.dashboard.application.service

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.collections.shouldContainExactlyInAnyOrder
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.time.LocalDate
import org.junit.jupiter.api.Test
import org.springframework.security.access.AccessDeniedException
import vn.lgg.mesplus.dashboard.application.model.DashboardDateRange
import vn.lgg.mesplus.dashboard.application.model.DashboardFilter
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.Factory
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.model.Warehouse
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.shared.model.Operation

class DashboardScopeResolverTest {
  private val company = Company("company", "Company", "corp", "")
  private val factoryOne = Factory("factory-1", "Factory 1", "company", "", "company", emptyList(), true)
  private val factoryTwo = Factory("factory-2", "Factory 2", "company", "", "company", emptyList(), true)
  private val teamOne = Team("team-1", "Team 1", "factory-1", "factory-1", Operation("SEW"), true)
  private val teamTwo = Team("team-2", "Team 2", "factory-2", "factory-2", Operation("SEW"), true)
  private val warehouse = Warehouse("warehouse-1", "Warehouse 1", "company", "", "company", true)
  private val units = listOf(company, factoryOne, factoryTwo, teamOne, teamTwo, warehouse).associateBy { it.id }
  private val repository = mockk<OrgUnitRepository> {
    every { findByIds(any()) } answers {
      firstArg<List<String>>().mapNotNull(units::get)
    }
  }
  private val resolver = DashboardScopeResolver(repository)

  @Test
  fun `factory filter keeps only descendants inside the granted hierarchy`() {
    val scope = resolver.resolve(
      allowedUnitIds = units.keys,
      filter = filter(factoryId = "factory-1"),
    )

    scope.factoryIds shouldBe setOf("factory-1")
    scope.teamIds.shouldContainExactlyInAnyOrder("team-1")
  }

  @Test
  fun `filter outside granted hierarchy is forbidden`() {
    shouldThrow<AccessDeniedException> {
      resolver.resolve(
        allowedUnitIds = listOf("factory-1", "team-1"),
        filter = filter(teamId = "team-2"),
      )
    }
  }

  @Test
  fun `factory manager can filter using ancestor company without 403`() {
    val scope = resolver.resolve(
      allowedUnitIds = listOf("factory-1", "team-1"),
      filter = filter(companyId = "company", factoryId = "factory-1", teamId = "team-1"),
    )

    scope.factoryIds shouldBe emptySet()
    scope.teamIds shouldBe setOf("team-1")
  }

  @Test
  fun `factory manager filtering company returns their factory scope`() {
    val scope = resolver.resolve(
      allowedUnitIds = listOf("factory-1", "team-1"),
      filter = filter(companyId = "company"),
    )

    scope.factoryIds shouldBe setOf("factory-1")
    scope.teamIds shouldBe setOf("team-1")
  }

  @Test
  fun `team leader can filter with ancestor company and factory without 403`() {
    val scope = resolver.resolve(
      allowedUnitIds = listOf("team-1"),
      filter = filter(companyId = "company", factoryId = "factory-1", teamId = "team-1"),
    )

    scope.factoryIds shouldBe emptySet()
    scope.teamIds shouldBe setOf("team-1")
  }

  @Test
  fun `warehouse filter selects the warehouse without a production scope`() {
    val scope = resolver.resolve(
      allowedUnitIds = listOf("warehouse-1"),
      filter = filter(companyId = "company", warehouseId = "warehouse-1"),
    )

    scope.factoryIds shouldBe emptySet()
    scope.teamIds shouldBe emptySet()
    scope.warehouseIds shouldBe setOf("warehouse-1")
  }

  @Test
  fun `filtering unit belonging to another company or factory is forbidden`() {
    shouldThrow<AccessDeniedException> {
      resolver.resolve(
        allowedUnitIds = listOf("factory-1", "team-1"),
        filter = filter(companyId = "other-company"),
      )
    }

    shouldThrow<AccessDeniedException> {
      resolver.resolve(
        allowedUnitIds = listOf("factory-1", "team-1"),
        filter = filter(factoryId = "factory-2"),
      )
    }

    shouldThrow<AccessDeniedException> {
      resolver.resolve(
        allowedUnitIds = units.keys,
        filter = filter(factoryId = "factory-1", teamId = "team-2"),
      )
    }
  }

  private fun filter(
    companyId: String? = null,
    factoryId: String? = null,
    teamId: String? = null,
    warehouseId: String? = null,
  ) = DashboardFilter(
    range = DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")),
    companyId = companyId,
    factoryId = factoryId,
    teamId = teamId,
    warehouseId = warehouseId,
  )
}
