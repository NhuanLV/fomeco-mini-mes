package vn.lgg.mesplus.kanban.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import java.math.BigDecimal
import java.time.Instant
import org.junit.jupiter.api.Test
import org.springframework.security.access.AccessDeniedException
import vn.lgg.mesplus.kanban.domain.event.KanbanAssignmentInitialized.AssignmentItem
import vn.lgg.mesplus.kanban.domain.event.KanbanCancelled
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialIssued.IssuedItem
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialPrepared.PreparedItem
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialReceived.ReceivedItem
import vn.lgg.mesplus.kanban.domain.model.*
import vn.lgg.mesplus.kanban.domain.repository.*
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.PermissionService

class CancelKanbanUseCaseTest {
  private val actor = Actor("creator", "Tổ trưởng", "creator", "", emptyList(), emptySet())
  private val repository = mockk<KanbanRepository>(relaxed = true)
  private val assignments = mockk<KanbanAssignmentRepository>(relaxed = true)
  private val gdns = mockk<KanbanGdnRepository>(relaxed = true)
  private val teams = mockk<TeamAssignmentRepository>(relaxed = true)
  private val permissions = mockk<PermissionService>(relaxed = true)
  private val publisher = mockk<DomainEventPublisher>(relaxed = true)
  private val useCase = CancelKanbanUseCase(repository, assignments, gdns, teams, permissions, publisher)

  @Test
  fun `creator can cancel a failed GDN and preserves the rejected quantity`() {
    val kanban = kanban().apply { reject("sai", actor.ref) }
    every { repository.lockAndLoad("kanban") } returns kanban
    every { gdns.findAllByKanbanId("kanban") } returns listOf(gdn(GdnStatus.FAILED))
    useCase.execute("kanban", CancelKanbanCommand("  Đổi kế hoạch  "), actor)
    kanban.status shouldBe KanbanStatus.CANCELLED
    kanban.items.single().requiredQty shouldBe BigDecimal("200.0000")
    (kanban.changes.last() as KanbanCancelled).reason shouldBe "Đổi kế hoạch"
    verify(exactly = 1) { repository.save(kanban) }
  }

  @Test
  fun `pending or successful GDN from any supplier blocks the whole kanban`() {
    for (status in listOf(GdnStatus.PENDING, GdnStatus.SUCCESS)) {
      val kanban = kanban()
      every { repository.lockAndLoad("kanban") } returns kanban
      every { gdns.findAllByKanbanId("kanban") } returns listOf(gdn(GdnStatus.FAILED), gdn(status, "other"))
      shouldThrow<IllegalStateException> {
        useCase.execute("kanban", CancelKanbanCommand("Đổi"), actor)
      }.message shouldBe CancelKanbanUseCase.BLOCKED_MESSAGE
      kanban.status shouldBe KanbanStatus.PENDING_EVALUATION
    }
    verify(exactly = 0) { repository.save(any()) }
  }

  @Test
  fun `successful receipt without GDN also blocks cancellation`() {
    val assignment = KanbanAssignment.init("kanban", "supplier",
      listOf(AssignmentItem("BTP CUT", "RED", "M", null, BigDecimal.ONE)), actor.ref)
    assignment.prepare(listOf(PreparedItem("BTP CUT", "RED", "M", null, BigDecimal.ONE, "")), actor.ref)
    assignment.issue(listOf(IssuedItem("BTP CUT", "RED", "M", null, BigDecimal.ONE, "")), actor.ref)
    assignment.receive(listOf(ReceivedItem("BTP CUT", "RED", "M", null, BigDecimal.ONE)), actor.ref)
    every { repository.lockAndLoad("kanban") } returns kanban()
    every { assignments.findAllByKanbanId("kanban") } returns listOf(assignment)
    shouldThrow<IllegalStateException> { useCase.execute("kanban", CancelKanbanCommand("Đổi"), actor) }
    verify(exactly = 0) { repository.save(any()) }
  }

  @Test
  fun `warehouse permission does not grant cancellation`() {
    every { repository.lockAndLoad("kanban") } returns kanban()
    val warehouse = Actor("warehouse", "Kho", "warehouse", "", emptyList(), setOf("ISSUE_MATERIAL"))
    shouldThrow<AccessDeniedException> { useCase.execute("kanban", CancelKanbanCommand("Đổi"), warehouse) }
    verify(exactly = 0) { repository.save(any()) }
  }

  private fun kanban() = Kanban.create("kanban", "team-assignment",
    listOf(PlanItem("po", Color("RED"), Size("M"), 10)),
    listOf(KanbanItem("MAT", Color("RED"), Size("M"), null, KanbanItemType.MATERIAL,
      BigDecimal(200), "supplier", "")), "", actor.ref)

  private fun gdn(status: GdnStatus, supplier: String = "supplier") = KanbanGdn(
    "kanban", supplier, Instant.EPOCH, actor.ref, status = status,
    createdAt = Instant.EPOCH, updatedAt = Instant.EPOCH)
}
