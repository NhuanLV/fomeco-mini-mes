package vn.lgg.mesplus.inventory.domain.model.btp

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import java.math.BigDecimal
import java.time.Instant
import org.junit.jupiter.api.Test
import tools.jackson.databind.json.JsonMapper
import tools.jackson.databind.jsontype.NamedType
import vn.lgg.mesplus.inventory.domain.event.btp.BtpKanbanIssued
import vn.lgg.mesplus.inventory.domain.event.btp.BtpKanbanReceived
import vn.lgg.mesplus.inventory.domain.event.btp.BtpProduced
import vn.lgg.mesplus.shared.DomainEvent

class BtpInventoryTest {
  @Test
  fun `cancelling an issue restores only that issue and cannot restore it twice`() {
    val inventory = BtpInventory.create("assignment")
    val sku = BtpSku("BTP CUT-1", "Đỏ", "M")
    inventory.produce(sku, BigDecimal(300), "report", null)
    inventory.issue(sku, BigDecimal(200), "kanban:supplier:po", null)
    inventory.issue(sku, BigDecimal(50), "other-kanban", null)
    inventory.cancelIssue(sku, "kanban:supplier:po", null)
    inventory.cancelIssue(sku, "kanban:supplier:po", null)
    inventory.balance(sku) shouldBe BigDecimal(250)
    val restored = BtpInventory.create("assignment").apply { loadFromHistory(inventory.allEvents) }
    restored.cancelIssue(sku, "kanban:supplier:po", null)
    restored.balance(sku) shouldBe BigDecimal(250)
    restored.changes shouldBe emptyList()
  }

  @Test
  fun `cannot issue more than produced or issue same kanban twice`() {
    val inventory = BtpInventory.create("assignment")
    val sku = BtpSku("BTP CUT-1", "Đỏ", "M")
    inventory.produce(sku, BigDecimal.TEN, "report", null)
    inventory.produce(sku, BigDecimal.TEN, "report", null)
    inventory.issue(sku, BigDecimal(3), "kanban", null)
    inventory.balance(sku) shouldBe BigDecimal(7)
    shouldThrow<IllegalStateException> {
      inventory.issue(sku, BigDecimal(8), "another-kanban", null)
    }
    inventory.issue(sku, BigDecimal(3), "kanban", null)
    inventory.balance(sku) shouldBe BigDecimal(7)
  }

  @Test
  fun `replays BTP inventory domain events through aggregate history`() {
    val sku = BtpSku("BTP CUT-1", "Đỏ", "M")
    val events: List<DomainEvent> = listOf(
      BtpProduced("assignment", sku, BigDecimal.TEN, "report", null),
      BtpKanbanIssued("assignment", sku, BigDecimal(3), "kanban", null),
    )
    val inventory = BtpInventory.create("assignment")

    inventory.loadFromHistory(events)

    inventory.balance(sku) shouldBe BigDecimal(7)
    inventory.changes shouldBe emptyList()
  }

  @Test
  fun `historical negative balance blocks issue until production covers it`() {
    val sku = BtpSku("BTP CUT-1", "Đỏ", "M")
    val inventory = BtpInventory.create("assignment")
    inventory.loadFromHistory(
            listOf(
                    BtpKanbanIssued(
                            "assignment",
                            sku,
                            BigDecimal(3),
                            "old-kanban",
                            null,
                    ),
            ),
    )

    inventory.balance(sku) shouldBe BigDecimal(-3)
    shouldThrow<IllegalStateException> { inventory.issue(sku, BigDecimal.ONE, "new-kanban", null) }
    inventory.produce(sku, BigDecimal(5), "replacement-report", null)
    inventory.issue(sku, BigDecimal(2), "new-kanban", null)
    inventory.balance(sku) shouldBe BigDecimal.ZERO
  }

  @Test
  fun `BTP events round trip through JSON as domain events`() {
    val mapper = JsonMapper.builder()
      .registerSubtypes(
        NamedType(BtpProduced::class.java, "BtpProduced"),
        NamedType(BtpKanbanIssued::class.java, "BtpKanbanIssued"),
        NamedType(BtpKanbanReceived::class.java, "BtpKanbanReceived"),
      )
      .build()
    val sku = BtpSku("BTP CUT-1", "Đỏ", "M")
    val events: List<DomainEvent> = listOf(
      BtpProduced("assignment", sku, BigDecimal.TEN, "report", null),
      BtpKanbanIssued("assignment", sku, BigDecimal.ONE, "kanban", null, "target"),
      BtpKanbanReceived("assignment", sku, BigDecimal.ONE, "kanban", null, "source"),
    )

    events.forEach { event ->
      mapper.readValue(mapper.writeValueAsString(event), DomainEvent::class.java) shouldBe event
    }
    mapper.readValue(
      """{"eventName":"BtpKanbanIssued","teamAssignmentId":"assignment","sku":{"article":"BTP CUT-1","color":"Đỏ","size":"M"},"quantity":1,"referenceId":"kanban","counterpartyId":"target","actor":null,"occurredAt":"2026-09-29T00:00:00+00:00"}""",
      DomainEvent::class.java,
    ) shouldBe BtpKanbanIssued(
            "assignment",
            sku,
            BigDecimal.ONE,
            "kanban",
            null,
            "target",
            Instant.parse("2026-09-29T00:00:00Z"),
    )
  }
}
