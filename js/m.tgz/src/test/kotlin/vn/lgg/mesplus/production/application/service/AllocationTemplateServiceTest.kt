package vn.lgg.mesplus.production.application.service

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.kotest.matchers.shouldNotBe
import io.mockk.every
import io.mockk.mockk
import java.io.ByteArrayInputStream
import java.time.Instant
import java.time.LocalDate
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.Factory
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderRouting
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.Routing
import vn.lgg.mesplus.order.domain.model.RoutingProcess
import vn.lgg.mesplus.order.domain.model.Style
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.repository.RoutingRepository
import vn.lgg.mesplus.order.infrastructure.repository.PgStyleRepository
import vn.lgg.mesplus.production.infrastructure.service.PoiAllocationTemplateService
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.SkuQuantity

class AllocationTemplateServiceTest {
  private val buyerOrderRepo = mockk<BuyerOrderRepository>()
  private val purchaseOrderRepo = mockk<PurchaseOrderRepository>()
  private val styleRepo = mockk<PgStyleRepository>()
  private val routingRepo = mockk<RoutingRepository>()
  private val orgUnitRepo = mockk<OrgUnitRepository>()

  private val service =
    PoiAllocationTemplateService(
      buyerOrderRepo,
      purchaseOrderRepo,
      styleRepo,
      routingRepo,
      orgUnitRepo,
    )

  @Test
  fun `generates valid excel template with data validation`() {
    val buyerOrder = BuyerOrder(
      id = "bo-1",
      wfxId = "WFX-BO-1",
      styleName = "STYLE-01",
      revisionCode = "R1",
      revisionDate = Instant.now(),
    )
    val style = Style(
      name = "STYLE-01",
      customer = "Customer A",
      brand = "Brand B",
      season = "SS26",
    )
    val po = PurchaseOrder(
      id = "po-1",
      wfxId = "wfx-po-1",
      code = "PO-001",
      destination = "US",
      deliveryDate = LocalDate.of(2026, 9, 30),
      skuQties = listOf(
        SkuQuantity(Color("Red"), Size("S"), 10),
        SkuQuantity(Color("Blue"), Size("M"), 20),
      ),
      buyerOrderId = "bo-1",
    )
    val routing = Routing(
      title = "Standard Routing",
      processes = listOf(
        RoutingProcess(Operation("CUT")),
        RoutingProcess(Operation("SEW")),
      ),
    )
    val factory = Factory(
      id = "fac-1",
      name = "Xí nghiệp 1",
      parentId = "com-1",
      address = "Address 1",
      companyId = "com-1",
      operations = listOf(Operation("CUT"), Operation("SEW")),
      isActive = true,
    )
    val company = Company(
      id = "com-1",
      name = "Công ty LGG",
      parentId = null,
      address = "Company address",
    )
    val team1 = Team(
      id = "team-1",
      name = "Tổ May 1",
      parentId = "fac-1",
      factoryId = "fac-1",
      operation = Operation("SEW"),
      isActive = true,
    )
    val team2 = Team(
      id = "team-2",
      name = "Tổ May 2",
      parentId = "fac-1",
      factoryId = "fac-1",
      operation = Operation("SEW"),
      isActive = true,
    )

    every { buyerOrderRepo.findById("bo-1") } returns buyerOrder
    every { styleRepo.findByName("STYLE-01") } returns style
    every { purchaseOrderRepo.findByBuyerOrderId("bo-1") } returns listOf(po)
    every { routingRepo.findByBuyerOrderId("bo-1") } returns BuyerOrderRouting("bo-1", listOf(routing))
    every { orgUnitRepo.findTeamsByFactoryIds(listOf("fac-1")) } returns listOf(team1, team2)
    every { orgUnitRepo.findByIds(listOf("fac-1")) } returns listOf(factory)
    every { orgUnitRepo.findByIds(listOf("com-1")) } returns listOf(company)

    val result = service.generateTemplate(
      buyerOrderId = "bo-1",
      routingIndex = 0,
      factoryIds = listOf("fac-1"),
      poIds = listOf("po-1"),
    )

    result shouldNotBe null
    result.fileName shouldBe "LSX_WFX-BO-1_template.xlsx"
    val workbook = XSSFWorkbook(ByteArrayInputStream(result.content))

    val mainSheet = workbook.getSheet("LSX")
    mainSheet shouldNotBe null

    workbook.getSheet("Phan_bo_San_xuat") shouldBe null
    workbook.getSheet("Danh_Muc_To") shouldBe null

    // Check metadata rows (row index 1, 2, 3)
    val metaRow1 = mainSheet.getRow(1)
    metaRow1.getCell(0).stringCellValue shouldBe "Mã hàng:"
    metaRow1.getCell(1).stringCellValue shouldBe "STYLE-01"
    metaRow1.getCell(2).stringCellValue shouldBe "LỆNH SỐ:"
    metaRow1.getCell(3).stringCellValue shouldBe "WFX-BO-1"

    val metaRow2 = mainSheet.getRow(2)
    metaRow2.getCell(0).stringCellValue shouldBe "Khách hàng:"
    metaRow2.getCell(1).stringCellValue shouldBe "Customer A"

    val metaRow3 = mainSheet.getRow(3)
    metaRow3.getCell(0).stringCellValue shouldBe "Thương hiệu:"
    metaRow3.getCell(1).stringCellValue shouldBe "Brand B"

    // Check header row (row index 5)
    val headerRow = mainSheet.getRow(5)
    headerRow.getCell(0).stringCellValue shouldBe "PO"
    headerRow.getCell(1).stringCellValue shouldBe "Thị trường"
    headerRow.getCell(8).stringCellValue shouldBe "Đơn vị"
    headerRow.getCell(13).stringCellValue shouldBe "PO ID"

    // Check hidden column
    mainSheet.isColumnHidden(13) shouldBe true

    // Check merged PO cells for 2 colors of same PO (row 6 and 7)
    val poMerge = mainSheet.mergedRegions.find { it.firstColumn == 0 && it.firstRow == 6 }
    poMerge shouldNotBe null
    poMerge!!.lastRow shouldBe 7
    poMerge.lastColumn shouldBe 0

    // Check merged Destination cells for same destination (row 6 and 7)
    val destMerge = mainSheet.mergedRegions.find { it.firstColumn == 1 && it.firstRow == 6 }
    destMerge shouldNotBe null
    destMerge!!.lastRow shouldBe 7
    destMerge.lastColumn shouldBe 1

    // Check data validation exists with explicit list
    mainSheet.dataValidations.size shouldBe 1
    val validation = mainSheet.dataValidations.first()
    validation.validationConstraint.explicitListValues.toList() shouldBe listOf(
      "Tổ May 1 - Xí nghiệp 1 - Công ty LGG",
      "Tổ May 2 - Xí nghiệp 1 - Công ty LGG",
    )

    workbook.close()
  }

  @Test
  fun `rejects invalid routingIndex or empty factoryIds`() {
    val buyerOrder = BuyerOrder(
      id = "bo-1",
      wfxId = "WFX-BO-1",
      styleName = "STYLE-01",
      revisionCode = "R1",
      revisionDate = Instant.now(),
    )
    every { buyerOrderRepo.findById("bo-1") } returns buyerOrder
    every { styleRepo.findByName("STYLE-01") } returns null
    every { purchaseOrderRepo.findByBuyerOrderId("bo-1") } returns emptyList()
    every { routingRepo.findByBuyerOrderId("bo-1") } returns BuyerOrderRouting("bo-1", emptyList())

    shouldThrow<IllegalArgumentException> {
      service.generateTemplate("bo-1", 0, listOf("fac-1"), null)
    }

    every { routingRepo.findByBuyerOrderId("bo-1") } returns BuyerOrderRouting(
      "bo-1",
      listOf(Routing("Title", emptyList())),
    )

    shouldThrow<IllegalArgumentException> {
      service.generateTemplate("bo-1", 0, emptyList(), null)
    }
  }
}
