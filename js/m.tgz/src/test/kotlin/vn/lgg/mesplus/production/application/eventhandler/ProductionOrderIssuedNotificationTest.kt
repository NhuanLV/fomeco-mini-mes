package vn.lgg.mesplus.production.application.eventhandler

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.production.domain.event.ProductionOrderIssued
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.Activity
import vn.lgg.mesplus.shared.NotificationTarget
import vn.lgg.mesplus.shared.Notifier
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.PermissionService

class ProductionOrderIssuedNotificationTest {
  private val assignmentRepository = mockk<TeamAssignmentRepository>()
  private val productionOrderRepository = mockk<ProductionOrderRepository>()
  private val buyerOrderRepository = mockk<BuyerOrderRepository>()
  private val permissionService = mockk<PermissionService>()
  private val notifier = CapturingNotifier()
  private val creator =
    ProductionOrderIssuedNotificationCreator(
      assignmentRepository,
      productionOrderRepository,
      buyerOrderRepository,
      permissionService,
      notifier,
    )

  @Test
  fun `notifies team members allowed to report progress about the assigned LSX`() {
    every { assignmentRepository.findById("assignment-1") } returns assignment()
    every { productionOrderRepository.findById("production-order-1") } returns productionOrder()
    every {
      permissionService.lookupAccountIds(Permission.REPORT_PROGRESS, "team-1")
    } returns listOf("recipient-1", "recipient-2")
    val actor = ActorRef("actor-1", "Planner")

    creator.createTeamNotification("assignment-1", actor)

    notifier.notifications.single().first shouldContainExactly listOf("recipient-1", "recipient-2")
    notifier.notifications.single().second shouldBe
      Activity(
        actor = actor,
        title = "LSX mới",
        body = "đã giao LSX LSX-001 cho tổ của bạn",
        target = NotificationTarget(ResourceType.TEAM_ASSIGNMENT, "assignment-1"),
      )
  }

  @Test
  fun `notifies each costing account once for an issued LSX`() {
    every { assignmentRepository.findById("assignment-1") } returns assignment()
    every { assignmentRepository.findById("assignment-2") } returns
      assignment(id = "assignment-2", teamId = "team-2")
    every { productionOrderRepository.findById("production-order-1") } returns productionOrder()
    every { buyerOrderRepository.findById("buyer-order-1") } returns buyerOrder()
    every { permissionService.lookupAccountIds(Permission.UPDATE_COSTING, "team-1") } returns
      listOf("technician-1", "technician-2")
    every { permissionService.lookupAccountIds(Permission.UPDATE_COSTING, "team-2") } returns
      listOf("technician-2", "technician-3")
    val actor = ActorRef("actor-1", "Planner")

    creator.createCostingNotification(
      "production-order-1",
      listOf("assignment-1", "assignment-2"),
      actor,
    )

    notifier.notifications.single().first shouldContainExactly
      listOf("technician-1", "technician-2", "technician-3")
    notifier.notifications.single().second shouldBe
      Activity(
        actor = actor,
        title = "LSX mới",
        body = "đã tạo LSX LSX-001 cho mã hàng MH-001, cần cập nhật định mức",
        target = NotificationTarget(ResourceType.PRODUCTION_ORDER, "production-order-1"),
      )
  }

  @Test
  fun `notifies reporting accounts when assignment allocation is revised`() {
    every { assignmentRepository.findById("assignment-1") } returns assignment()
    every { productionOrderRepository.findById("production-order-1") } returns productionOrder()
    every { permissionService.lookupAccountIds(Permission.REPORT_PROGRESS, "team-1") } returns
      listOf("recipient-1")
    val actor = ActorRef("actor-1", "Planner")

    creator.createAllocationRevisionNotification("assignment-1", actor)

    notifier.notifications.single() shouldBe
      (listOf("recipient-1") to
        Activity(
          actor = actor,
          title = "LSX mới",
          body = "đã điều chỉnh sản lượng LSX LSX-001, cần kiểm tra",
          target = NotificationTarget(ResourceType.TEAM_ASSIGNMENT, "assignment-1"),
        ))
  }

  @Test
  fun `continues with remaining assignments when one fails`() {
    val isolatedCreator = mockk<ProductionOrderIssuedNotificationCreator>()
    val handler = ProductionOrderIssuedNotificationHandler(isolatedCreator)
    val actor = ActorRef("actor-1", "Planner")
    every {
      isolatedCreator.createTeamNotification("assignment-1", actor)
    } throws IllegalStateException("failed")
    justRun { isolatedCreator.createTeamNotification("assignment-2", actor) }
    justRun {
      isolatedCreator.createCostingNotification(
        "production-order-1",
        listOf("assignment-1", "assignment-2"),
        actor,
      )
    }

    handler.handle(
      ProductionOrderIssued(
        productionOrderId = "production-order-1",
        buyerOrderId = "buyer-order-1",
        actor = actor,
        teamAssignments = listOf("assignment-1", "assignment-2"),
      )
    )

    verify(exactly = 1) { isolatedCreator.createTeamNotification("assignment-1", actor) }
    verify(exactly = 1) { isolatedCreator.createTeamNotification("assignment-2", actor) }
    verify(exactly = 1) {
      isolatedCreator.createCostingNotification(
        "production-order-1",
        listOf("assignment-1", "assignment-2"),
        actor,
      )
    }
  }

  private fun assignment(
    id: String = "assignment-1",
    teamId: String = "team-1",
  ) =
    TeamAssignment.create(
      id = id,
      productionOrderId = "production-order-1",
      buyerOrderId = "buyer-order-1",
      teamId = teamId,
      operation = Operation("Sew"),
      allocations = listOf(SkuAllocation("po-1", Color("Red"), Size("S"), 10)),
      plannedStartDate = LocalDate.of(2026, 1, 1),
      plannedEndDate = LocalDate.of(2026, 1, 10),
    )

  private fun productionOrder() =
    ProductionOrder(
      id = "production-order-1",
      buyerOrderId = "buyer-order-1",
      productionCode = "LSX-001",
      factoryIds = listOf("factory-1"),
      mainCompanyCode = "LGG-BG",
      status = ProductionOrderStatus.IN_PROGRESS,
      createdAt = Instant.parse("2026-01-01T00:00:00Z"),
    )

  private fun buyerOrder() =
    BuyerOrder(
      id = "buyer-order-1",
      wfxId = "BO-001",
      styleName = "Style",
      revisionCode = "1",
      revisionDate = Instant.parse("2026-01-01T00:00:00Z"),
      articleCode = "MH-001",
    )
}

private class CapturingNotifier : Notifier {
  val notifications = mutableListOf<Pair<List<String>, Activity>>()

  override fun notify(userIds: Collection<String>, activity: Activity, includeActor: Boolean) {
    notifications += userIds.toList() to activity
  }
}
