package vn.lgg.mesplus.production.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.Factory
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.order.domain.model.BillOfMaterial
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderMaterial
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BillOfMaterialRepository
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.order.infrastructure.wfx.WfxSyncException
import vn.lgg.mesplus.production.application.service.ProductionOrderActivityLog
import vn.lgg.mesplus.production.application.service.ProductionOrderActivityRecorder
import vn.lgg.mesplus.production.application.service.ProductionOrderActivitySyncStatus
import vn.lgg.mesplus.production.application.service.ProductionOrderActivityType
import vn.lgg.mesplus.production.application.service.FppoSyncService
import vn.lgg.mesplus.production.application.usecase.command.IssueProductionOrderCommand
import vn.lgg.mesplus.production.application.usecase.command.ProductionOrderMetadataCommandData
import vn.lgg.mesplus.production.application.usecase.command.TeamAssignmentCommandData
import vn.lgg.mesplus.production.application.usecase.mapping.IssueProductionOrderMapper
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import org.springframework.util.SimpleIdGenerator
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.Notifier
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Material
import vn.lgg.mesplus.shared.model.MaterialSizeDep
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.SkuQuantity
import vn.lgg.mesplus.shared.service.PermissionService

class IssueProductionOrderUseCaseTest {
  private val buyerOrderRepository = mockk<BuyerOrderRepository>()
  private val purchaseOrderRepository = mockk<PurchaseOrderRepository>()
  private val bomRepository = mockk<BillOfMaterialRepository>()
  private val productionOrderRepository = mockk<ProductionOrderRepository>()
  private val allocationQueryService = mockk<AllocationQueryService>()
  private val permissionService = mockk<PermissionService>()
  private val teamAssignmentRepository = mockk<TeamAssignmentRepository>()
  private val issueProductionOrderMapper = mockk<IssueProductionOrderMapper>()
  private val unitRepository = mockk<OrgUnitRepository>()
  private val eventPublisher = mockk<DomainEventPublisher>()
  private val fppoSyncService = mockk<FppoSyncService>()
  private val notifier = mockk<Notifier>()
  private val activityLog = mockk<ProductionOrderActivityLog>()
  private val activityRecorder = ProductionOrderActivityRecorder(
    activityLog, unitRepository, SimpleIdGenerator(),
  )
  private val actor = Actor("actor-1", "Planner", "planner", "", emptyList(), emptySet())

  private val useCase =
    IssueProductionOrderUseCase(
      buyerOrderRepository = buyerOrderRepository,
      poRepo = purchaseOrderRepository,
      bomRepository = bomRepository,
      productionOrderRepository = productionOrderRepository,
      teamAssignmentRepository = teamAssignmentRepository,
      permissionService = permissionService,
      issueProductionOrderMapper = issueProductionOrderMapper,
      unitRepo = unitRepository,
      allocationQueryService = allocationQueryService,
      eventPublisher = eventPublisher,
      fppoSyncService = fppoSyncService,
      notifier = notifier,
      activityRecorder = activityRecorder,
    )

  @BeforeEach
  fun setUp() {
    justRun { activityLog.append(any()) }
    justRun { permissionService.requirePermission(actor, any(), any()) }
    every { buyerOrderRepository.findById("bo-1") } returns buyerOrder()
    every { buyerOrderRepository.lockById("bo-1") } returns buyerOrder()
    val defaultPo = purchaseOrder("po-1", "bo-1", PurchaseOrderType.REGULAR)
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(defaultPo)
    every { bomRepository.findByBuyerOrderId("bo-1") } returns BillOfMaterial("bo-1", emptyList())
    justRun { allocationQueryService.requireWithinBuyerOrderQuantity("bo-1", any()) }
    every { productionOrderRepository.nextCodeForStyle("STYLE") } returns "STYLE-1"
    every { productionOrderRepository.save(any()) } answers { firstArg() }
    every { teamAssignmentRepository.save(any()) } answers { firstArg() }
    justRun { eventPublisher.publish(any<List<DomainEvent>>()) }
    justRun { eventPublisher.publish(any<DomainEvent>()) }
    justRun { fppoSyncService.syncFppo(any(), any(), any(), any()) }
    justRun { notifier.notify(any<Collection<String>>(), any()) }
    every { unitRepository.findById(any()) } answers {
      val id = firstArg<String>()
      Team(id, id, "factory-1", "factory-1", Operation("Cut"), true)
    }
  }

  @Test
  fun `rejects unknown BOM size before calling WFX`() {
    prepare()
    every { bomRepository.findByBuyerOrderId("bo-1") } returns BillOfMaterial("bo-1", listOf(
      BuyerOrderMaterial(
        material = Material("Fabric", "NPL", "M"),
        sizeDeps = listOf(MaterialSizeDep(Size("Unknown Size"), Size("S"), BigDecimal.ONE)),
        colorDeps = emptyList(),
        usedForOperations = emptyList(),
        usedForDestinations = emptyList(),
      ),
    ))

    val error = shouldThrow<IllegalArgumentException> { useCase.execute(command(), actor) }

    error.message shouldBe "BOM vật tư 'Fabric' còn màu/size Unknown. Cần bổ sung master WFX và đồng bộ lại BOM trước khi phát LSX."
    verify(exactly = 0) { fppoSyncService.syncFppo(any(), any(), any(), any()) }
    verify(exactly = 0) { productionOrderRepository.save(any()) }
  }

  @Test
  fun `rejects locked buyer order before generating production code`() {
    every {
      allocationQueryService.requireWithinBuyerOrderQuantity("bo-1", any())
    } throws IllegalStateException("locked")

    shouldThrow<IllegalStateException> { useCase.execute(command(), actor) }

    verify(exactly = 0) { productionOrderRepository.nextCodeForStyle(any()) }
  }

  @Test
  fun `rejects mismatched operation totals without persistence`() {
    prepare(
      assignments =
        listOf(
          assignment("ta-cut", "team-cut", "Cut", allocation("po-1", 10)),
          assignment("ta-sew", "team-sew", "Sew", allocation("po-1", 9)),
        ),
    )

    shouldThrow<IllegalArgumentException> { useCase.execute(command(), actor) }

    verify(exactly = 0) { productionOrderRepository.save(any()) }
    verify(exactly = 0) { teamAssignmentRepository.save(any()) }
    verify(exactly = 0) { eventPublisher.publish(any<List<DomainEvent>>()) }
  }

  @Test
  fun `accepts allocation equal to remaining and publishes side effects`() {
    prepare(remaining = listOf(allocation("po-1", 10)))

    useCase.execute(command(), actor)

    verify(exactly = 1) { activityLog.append(match { it.type == ProductionOrderActivityType.CREATE && it.actor == actor.ref && it.changes.isEmpty() && it.syncStatus == ProductionOrderActivitySyncStatus.SUCCESS }) }
    verify(exactly = 1) { productionOrderRepository.save(any()) }
    verify(exactly = 2) { teamAssignmentRepository.save(any()) }
    verify(exactly = 1) { eventPublisher.publish(any<List<DomainEvent>>()) }
    verify(exactly = 1) { eventPublisher.publish(any<DomainEvent>()) }
    verify(exactly = 1) { buyerOrderRepository.lockById("bo-1") }
    verify(exactly = 1) {
      fppoSyncService.syncFppo("bo-1", "LGG-BG", match { it.size == 2 }, any())
    }
    verify(exactly = 1) {
      notifier.notify(
        listOf("actor-1"),
        match {
          it.actor == null &&
            it.title == "Đồng bộ WFX thành công" &&
            it.body == "Đã đồng bộ FPO/FPPO lên WFX và phát lệnh STYLE-1 thành công." &&
            it.target.resourceType == ResourceType.PRODUCTION_ORDER &&
            it.target.resourceId == "lsx-1"
        },
      )
    }
  }

  @Test
  fun `propagates WFX failure without publishing events or notification`() {
    prepare(remaining = listOf(allocation("po-1", 10)))
    every { fppoSyncService.syncFppo("bo-1", "LGG-BG", any(), any()) } throws
      WfxSyncException.business("Invalid FPPO")

    shouldThrow<WfxSyncException> { useCase.execute(command(), actor) }

    verify(exactly = 0) { productionOrderRepository.save(any()) }
    verify(exactly = 0) { teamAssignmentRepository.save(any()) }
    verify(exactly = 0) { eventPublisher.publish(any<List<DomainEvent>>()) }
    verify(exactly = 0) { eventPublisher.publish(any<DomainEvent>()) }
    verify(exactly = 0) { activityLog.append(any()) }
    verify(exactly = 0) { notifier.notify(any<Collection<String>>(), any()) }
  }

  @Test
  fun `currently accepts a proposed key absent from remaining skus`() {
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns
      listOf(purchaseOrder("po-1"), purchaseOrder("po-2"))
    val assignments =
      listOf(
        assignment("ta-cut", "team-cut", "Cut", allocation("po-2", 10)),
        assignment("ta-sew", "team-sew", "Sew", allocation("po-2", 10)),
      )
    prepare(assignments = assignments, remaining = listOf(allocation("po-1", 10)))

    useCase.execute(command(), actor)

    verify(exactly = 1) { productionOrderRepository.save(any()) }
  }

  @Test
  fun `rejects team outside factory without persistence`() {
    prepare(factoryTeams = listOf(team("team-cut", "Cut")))

    shouldThrow<IllegalArgumentException> { useCase.execute(command(), actor) }

    verify(exactly = 0) { productionOrderRepository.save(any()) }
  }

  @Test
  fun `rejects team whose operation does not match`() {
    prepare(
      factoryTeams =
        listOf(
          team("team-cut", "Sew"),
          team("team-sew", "Sew"),
        ),
    )

    shouldThrow<IllegalArgumentException> { useCase.execute(command(), actor) }

    verify(exactly = 0) { productionOrderRepository.save(any()) }
  }

  @Test
  fun `rejects main company code not belonging to selected factories`() {
    prepare(remaining = listOf(allocation("po-1", 10)))

    shouldThrow<IllegalArgumentException> {
      useCase.execute(command(mainCompanyCode = "WRONG-COMPANY"), actor)
    }

    verify(exactly = 0) { productionOrderRepository.save(any()) }
  }

  @Test
  fun `rejects assignment with planned start date in the past`() {
    val pastDate = LocalDate.now().minusDays(1)
    val futureDate = LocalDate.now().plusDays(10)
    val assignments =
      listOf(
        assignment("ta-cut", "team-cut", "Cut", allocation("po-1", 10), plannedStartDate = pastDate, plannedEndDate = futureDate),
        assignment("ta-sew", "team-sew", "Sew", allocation("po-1", 10), plannedStartDate = pastDate, plannedEndDate = futureDate),
      )
    prepare(assignments = assignments)

    val ex = shouldThrow<IllegalArgumentException> { useCase.execute(command(), actor) }
    ex.message shouldBe "Ngày dự kiến bắt đầu của tổ Cut không được trong quá khứ"

    verify(exactly = 0) { productionOrderRepository.save(any()) }
  }

  @Test
  fun `rejects assignment with planned end date before planned start date`() {
    val startDate = LocalDate.now().plusDays(5)
    val endDate = LocalDate.now().plusDays(2)
    val assignments =
      listOf(
        assignment("ta-cut", "team-cut", "Cut", allocation("po-1", 10), plannedStartDate = startDate, plannedEndDate = endDate),
        assignment("ta-sew", "team-sew", "Sew", allocation("po-1", 10), plannedStartDate = startDate, plannedEndDate = endDate),
      )
    prepare(assignments = assignments)

    val ex = shouldThrow<IllegalArgumentException> { useCase.execute(command(), actor) }
    ex.message shouldBe "Ngày dự kiến hoàn thành của tổ Cut phải sau hoặc bằng ngày bắt đầu"

    verify(exactly = 0) { productionOrderRepository.save(any()) }
  }

  @Test
  fun `issues positive LSX without calling fppo sync and with non-wfx notification`() {
    val posPo = purchaseOrder("po-pos", "bo-1", PurchaseOrderType.POSITIVE)
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(posPo)
    val assignments =
      listOf(
        assignment("ta-cut", "team-cut", "Cut", allocation("po-pos", 10)),
        assignment("ta-sew", "team-sew", "Sew", allocation("po-pos", 10)),
      )
    prepare(assignments = assignments, remaining = listOf(allocation("po-pos", 10)))

    useCase.execute(
      command().copy(
        teamAssignments = listOf(
          TeamAssignmentCommandData(
            "team-cut",
            "Cut",
            listOf(allocation("po-pos", 10)),
            LocalDate.now().plusDays(1),
            LocalDate.now().plusDays(10),
          ),
          TeamAssignmentCommandData(
            "team-sew",
            "Sew",
            listOf(allocation("po-pos", 10)),
            LocalDate.now().plusDays(1),
            LocalDate.now().plusDays(10),
          ),
        ),
      ),
      actor,
    )

    verify(exactly = 1) { productionOrderRepository.save(any()) }
    verify(exactly = 0) { fppoSyncService.syncFppo(any(), any(), any()) }
    verify(exactly = 1) {
      notifier.notify(
        listOf("actor-1"),
        match {
          it.title == "Phát lệnh thành công" &&
            it.body == "Đã phát lệnh STYLE-1 thành công."
        },
      )
    }
  }

  @Test
  fun `mixed issuance still rejects mismatched PO allocations across operations`() {
    val regPo = purchaseOrder("po-reg", "bo-1", PurchaseOrderType.REGULAR)
    val posPo = purchaseOrder("po-pos", "bo-1", PurchaseOrderType.POSITIVE)
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(regPo, posPo)
    val assignments =
      listOf(
        assignment("ta-cut", "team-cut", "Cut", allocation("po-reg", 5)),
        assignment("ta-sew", "team-sew", "Sew", allocation("po-pos", 5)),
      )
    prepare(assignments = assignments)

    val ex = shouldThrow<IllegalArgumentException> {
      useCase.execute(
        command().copy(
          teamAssignments = listOf(
            TeamAssignmentCommandData(
              "team-cut",
              "Cut",
              listOf(allocation("po-reg", 5)),
              LocalDate.now().plusDays(1),
              LocalDate.now().plusDays(10),
            ),
            TeamAssignmentCommandData(
              "team-sew",
              "Sew",
              listOf(allocation("po-pos", 5)),
              LocalDate.now().plusDays(1),
              LocalDate.now().plusDays(10),
            ),
          ),
        ),
        actor,
      )
    }
    ex.message shouldBe "Sản lượng tổng ở các công đoạn không khớp nhau"
    verify(exactly = 0) { productionOrderRepository.save(any()) }
  }

  @Test
  fun `issues regular and positive POs together and keeps WFX sync`() {
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      purchaseOrder("po-reg", "bo-1", PurchaseOrderType.REGULAR),
      purchaseOrder("po-pos", "bo-1", PurchaseOrderType.POSITIVE),
    )
    val allocations = listOf(allocation("po-reg", 5), allocation("po-pos", 5))
    val assignments = listOf("Cut" to "team-cut", "Sew" to "team-sew").map { (operation, team) ->
      TeamAssignment.create("ta-$team", "lsx-1", "bo-1", team, Operation(operation), allocations,
        plannedStartDate = LocalDate.now().plusDays(1), plannedEndDate = LocalDate.now().plusDays(10))
    }
    prepare(assignments = assignments, remaining = allocations)
    useCase.execute(command(), actor)
    verify(exactly = 2) { teamAssignmentRepository.save(any()) }
    verify(exactly = 1) { fppoSyncService.syncFppo(any(), any(), any(), any()) }
  }

  private fun prepare(
    assignments: List<TeamAssignment> =
      listOf(
        assignment("ta-cut", "team-cut", "Cut", allocation("po-1", 10)),
        assignment("ta-sew", "team-sew", "Sew", allocation("po-1", 10)),
      ),
    remaining: List<SkuAllocation> = listOf(allocation("po-1", 10)),
    factoryTeams: List<Team> = listOf(team("team-cut", "Cut"), team("team-sew", "Sew")),
  ) {
    every { issueProductionOrderMapper.toProductionOrder(any(), "STYLE-1") } returns productionOrder()
    every { issueProductionOrderMapper.toTeamAssignments(any(), "lsx-1", actor.ref) } returns assignments
    every { unitRepository.findTeamsByFactoryIds(listOf("factory-1")) } returns factoryTeams
    factoryTeams.forEach { team ->
      every { unitRepository.findById(team.id) } returns team
    }
    every { unitRepository.findByIds(listOf("factory-1")) } returns
      listOf(
        Factory(
          id = "factory-1",
          name = "Xí nghiệp 1",
          parentId = "company-1",
          address = "",
          companyId = "company-1",
          operations = listOf(Operation("Cut"), Operation("Sew")),
          isActive = true,
          code = "XN-1",
        )
      )
    every { unitRepository.findByIds(listOf("company-1")) } returns
      listOf(
        Company(
          id = "company-1",
          name = "LGG Bắc Giang",
          parentId = "corp-1",
          address = "",
          code = "LGG-BG",
        )
      )
    every { allocationQueryService.getRemainingSku(any(), any()) } returns remaining
  }

  private fun command(mainCompanyCode: String = "LGG-BG") =
    IssueProductionOrderCommand(
      buyerOrderId = "bo-1",
      factoryIds = listOf("factory-1"),
      mainCompanyCode = mainCompanyCode,
      teamAssignments =
        listOf(
          TeamAssignmentCommandData(
            "team-cut",
            "Cut",
            listOf(allocation("po-1", 10)),
            LocalDate.now().plusDays(1),
            LocalDate.now().plusDays(10),
          ),
          TeamAssignmentCommandData(
            "team-sew",
            "Sew",
            listOf(allocation("po-1", 10)),
            LocalDate.now().plusDays(1),
            LocalDate.now().plusDays(10),
          ),
        ),
      metadata = ProductionOrderMetadataCommandData(null, null, null),
      routing = listOf("Cut", "Sew"),
    )

  private fun assignment(
    id: String,
    teamId: String,
    operation: String,
    allocation: SkuAllocation,
    plannedStartDate: LocalDate = LocalDate.now().plusDays(1),
    plannedEndDate: LocalDate = LocalDate.now().plusDays(10),
  ) =
    TeamAssignment.create(
      id = id,
      productionOrderId = "lsx-1",
      buyerOrderId = "bo-1",
      teamId = teamId,
      operation = Operation(operation),
      allocations = listOf(allocation),
      plannedStartDate = plannedStartDate,
      plannedEndDate = plannedEndDate,
    )

  private fun team(id: String, operation: String) =
    Team(id, id, "factory-1", "factory-1", Operation(operation), true)

  private fun allocation(purchaseOrderId: String, quantity: Int) =
    SkuAllocation(purchaseOrderId, Color("Red"), Size("S"), quantity)

  private fun buyerOrder() =
    BuyerOrder("bo-1", "WFX-1", "STYLE", "1", Instant.parse("2026-01-01T00:00:00Z"))

  private fun productionOrder() =
    ProductionOrder(
      id = "lsx-1",
      buyerOrderId = "bo-1",
      productionCode = "STYLE-1",
      factoryIds = listOf("factory-1"),
      mainCompanyCode = "LGG-BG",
      status = ProductionOrderStatus.IN_PROGRESS,
      routing = listOf("Cut", "Sew"),
    )

  private fun purchaseOrder(
    id: String = "po-1",
    buyerOrderId: String = "bo-1",
    type: PurchaseOrderType = PurchaseOrderType.REGULAR,
  ) =
    PurchaseOrder(
      id = id,
      wfxId = "wfx-$id",
      code = id.uppercase(),
      destination = "US",
      deliveryDate = LocalDate.now(),
      skuQties = listOf(SkuQuantity(Color("Red"), Size("S"), 100)),
      buyerOrderId = buyerOrderId,
      type = type,
    )
}
