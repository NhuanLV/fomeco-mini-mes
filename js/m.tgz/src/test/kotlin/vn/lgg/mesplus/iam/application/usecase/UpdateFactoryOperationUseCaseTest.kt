package vn.lgg.mesplus.iam.application.usecase

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.slot
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.FactoryOperation
import vn.lgg.mesplus.iam.domain.model.Warehouse
import vn.lgg.mesplus.iam.domain.repository.FactoryOperationRepository
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

class UpdateFactoryOperationUseCaseTest {
  private val repository = mockk<FactoryOperationRepository>()
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val permissionService = mockk<PermissionService>()
  private val actor = Actor("actor-1", "Admin", "admin", "", emptyList(), emptySet())
  private val useCase = UpdateFactoryOperationUseCase(repository, orgUnitRepository, permissionService)

  @Test
  fun `keeps operation code when updating a mapping`() {
    val operation =
      FactoryOperation(
        id = "operation-1",
        companyId = "company-1",
        companyCode = "COMP-1",
        factoryId = "factory-1",
        operationCode = "CUT-1",
        operationName = "Cắt",
        materialDispatchWarehouseId = "wh-1",
        btpReceiveWarehouseId = "wh-2",
      )
    val saved = slot<FactoryOperation>()
    every { repository.findById("operation-1") } returns operation
    every { orgUnitRepository.findById("company-1") } returns
      Company("company-1", "Company", "corporation-1", "", code = "COMP-1")
    every { orgUnitRepository.findById("wh-3") } returns
      Warehouse("wh-3", "Kho NPL", "company-1", "", "company-1", true, "WH-03")
    every { orgUnitRepository.findById("wh-4") } returns
      Warehouse("wh-4", "Kho BTP", "company-1", "", "company-1", true, "WH-04")
    justRun { permissionService.requirePermission(actor, listOf(Permission.MANAGE_ORG), any()) }
    justRun { repository.save(capture(saved)) }

    useCase.execute(
      "operation-1",
      UpdateFactoryOperationCommand(
        operationName = "May",
        materialDispatchWarehouseId = "wh-3",
        btpReceiveWarehouseId = "wh-4",
      ),
      actor,
    )

    saved.captured.companyId shouldBe "company-1"
    saved.captured.factoryId shouldBe "factory-1"
    saved.captured.operationCode shouldBe "CUT-1"
    saved.captured.operationName shouldBe "May"
    saved.captured.materialDispatchWarehouseId shouldBe "wh-3"
    saved.captured.btpReceiveWarehouseId shouldBe "wh-4"
  }

  @Test
  fun `allows empty warehouse fields when updating`() {
    val operation =
      FactoryOperation(
        id = "operation-1",
        companyId = "company-1",
        companyCode = "COMP-1",
        factoryId = "factory-1",
        operationCode = "CUT-1",
        operationName = "Cắt",
        materialDispatchWarehouseId = "wh-1",
        btpReceiveWarehouseId = "wh-2",
      )
    every { repository.findById("operation-1") } returns operation
    every { orgUnitRepository.findById("company-1") } returns
      Company("company-1", "Company", "corporation-1", "", code = "COMP-1")
    justRun { permissionService.requirePermission(actor, listOf(Permission.MANAGE_ORG), any()) }
    justRun { repository.save(any()) }

    useCase.execute(
      "operation-1",
      UpdateFactoryOperationCommand(
        operationName = "May",
        materialDispatchWarehouseId = null,
        btpReceiveWarehouseId = null,
      ),
      actor,
    )

    operation.materialDispatchWarehouseId shouldBe null
    operation.btpReceiveWarehouseId shouldBe null
  }
}
