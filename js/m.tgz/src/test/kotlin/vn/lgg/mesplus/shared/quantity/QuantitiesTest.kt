package vn.lgg.mesplus.shared.quantity

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.maps.shouldContainExactly
import io.kotest.matchers.shouldBe
import java.math.BigDecimal
import org.junit.jupiter.api.Test

class QuantitiesTest {
  @Test
  fun `int quantities aggregate duplicate keys and preserve first-seen order`() {
    val totals =
      quantitiesOf(
        listOf(Item("blue", 2), Item("red", 3), Item("blue", 4)),
        IntQuantityArithmetic,
      ) {
        key { it.key }
        quantity { it.quantity }
      }

    totals.keys.shouldContainExactly("blue", "red")
    totals.toMap().shouldContainExactly(linkedMapOf("blue" to 6, "red" to 3))
    totals["missing"] shouldBe 0
  }

  @Test
  fun `operators combine the union of keys and zero removal is explicit`() {
    val left = quantitiesOf(mapOf("a" to 5, "b" to 2), IntQuantityArithmetic)
    val right = quantitiesOf(mapOf("a" to 5, "c" to 3), IntQuantityArithmetic)

    (left - right).toMap().shouldContainExactly(
      linkedMapOf("a" to 0, "b" to 2, "c" to -3),
    )
    (left - right).withoutZeroes().toMap().shouldContainExactly(
      linkedMapOf("b" to 2, "c" to -3),
    )
    (left + right)["a"] shouldBe 10
  }

  @Test
  fun `comparison reports excess and negative keys using missing key as zero`() {
    val actual = quantitiesOf(mapOf("a" to 6, "b" to -1), IntQuantityArithmetic)
    val limit = quantitiesOf(mapOf("a" to 5, "c" to 2), IntQuantityArithmetic)

    actual.keysExceeding(limit).shouldContainExactly("a")
    actual.negativeKeys().shouldContainExactly("b")
  }

  @Test
  fun `equality ignores key order and builder requires both selectors`() {
    quantitiesOf(linkedMapOf("a" to 1, "b" to 2), IntQuantityArithmetic) shouldBe
      quantitiesOf(linkedMapOf("b" to 2, "a" to 1), IntQuantityArithmetic)

    shouldThrow<IllegalStateException> {
      quantitiesOf<Item, String, Int>(listOf(Item("a", 1)), IntQuantityArithmetic) {
        key { it.key }
      }
    }
    shouldThrow<IllegalStateException> {
      quantitiesOf<Item, String, Int>(listOf(Item("a", 1)), IntQuantityArithmetic) {
        quantity { it.quantity }
      }
    }
  }

  @Test
  fun `decimal quantities obey the same aggregation and arithmetic contract`() {
    val totals =
      quantitiesOf(
        listOf(DecimalItem("material", BigDecimal("1.20")), DecimalItem("material", BigDecimal("2.30"))),
        DecimalQuantityArithmetic,
      ) {
        key { it.key }
        quantity { it.quantity }
      }
    val consumed =
      quantitiesOf(mapOf("material" to BigDecimal("1.50")), DecimalQuantityArithmetic)

    totals["material"] shouldBe BigDecimal("3.50")
    (totals - consumed)["material"] shouldBe BigDecimal("2.00")
    totals.keysExceeding(consumed).shouldContainExactly("material")
  }

  private data class Item(val key: String, val quantity: Int)

  private data class DecimalItem(val key: String, val quantity: BigDecimal)
}
