package vn.lgg.mesplus.app.config

import io.kotest.matchers.collections.shouldContain
import org.junit.jupiter.api.Test

class SecurityConfigTest {
  @Test
  fun `CSP allows reading and displaying local cropper images`() {
    val directives = SecurityConfig.CONTENT_SECURITY_POLICY.split(';').map { it.trim().split(' ') }
    val connectSources = directives.single { it.first() == "connect-src" }.drop(1)
    val imageSources = directives.single { it.first() == "img-src" }.drop(1)

    connectSources shouldContain "blob:"
    imageSources shouldContain "blob:"
    imageSources shouldContain "data:"
  }
}
