package vn.lgg.mesplus.production.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

class SingleFactoryPerSkuValidationTest {
  private val orgUnitRepository = mockk<OrgUnitRepository>()

  @Test
  fun `rejects same SKU and operation across two different factories`() {
    val team1 = Team("team-1", "Tổ 1", "factory-1", "factory-1", Operation("Sew"), true, "T1")
    val team2 = Team("team-2", "Tổ 2", "factory-2", "factory-2", Operation("Sew"), true, "T2")
    every { orgUnitRepository.findById("team-1") } returns team1
    every { orgUnitRepository.findById("team-2") } returns team2

    val assignment1 = createAssignment("ta-1", "lsx-1", "team-1", "Sew", "po-1", "Red", "S", 10)
    val assignment2 = createAssignment("ta-2", "lsx-1", "team-2", "Sew", "po-1", "Red", "S", 15)

    val ex = shouldThrow<IllegalArgumentException> {
      validateSingleFactoryPerSku(listOf(assignment1, assignment2), orgUnitRepository)
    }
    ex.message shouldBe "Công đoạn Sew, SKU po-1/Red/S được phân cho nhiều xí nghiệp"
  }

  @Test
  fun `allows same SKU and operation when teams are in the same factory`() {
    val team1 = Team("team-1", "Tổ 1", "factory-1", "factory-1", Operation("Sew"), true, "T1")
    val team2 = Team("team-2", "Tổ 2", "factory-1", "factory-1", Operation("Sew"), true, "T2")
    every { orgUnitRepository.findById("team-1") } returns team1
    every { orgUnitRepository.findById("team-2") } returns team2

    val assignment1 = createAssignment("ta-1", "lsx-1", "team-1", "Sew", "po-1", "Red", "S", 10)
    val assignment2 = createAssignment("ta-2", "lsx-1", "team-2", "Sew", "po-1", "Red", "S", 15)

    validateSingleFactoryPerSku(listOf(assignment1, assignment2), orgUnitRepository)
  }

  @Test
  fun `allows same SKU across different operations in different factories`() {
    val teamCut = Team("team-cut", "Tổ Cắt", "factory-1", "factory-1", Operation("Cut"), true, "TC")
    val teamSew = Team("team-sew", "Tổ May", "factory-2", "factory-2", Operation("Sew"), true, "TS")
    every { orgUnitRepository.findById("team-cut") } returns teamCut
    every { orgUnitRepository.findById("team-sew") } returns teamSew

    val assignmentCut = createAssignment("ta-cut", "lsx-1", "team-cut", "Cut", "po-1", "Red", "S", 25)
    val assignmentSew = createAssignment("ta-sew", "lsx-1", "team-sew", "Sew", "po-1", "Red", "S", 25)

    validateSingleFactoryPerSku(listOf(assignmentCut, assignmentSew), orgUnitRepository)
  }

  @Test
  fun `allows same SKU in different factories when on different LSX`() {
    val teamFactory1 = Team("team-1", "Tổ 1", "factory-1", "factory-1", Operation("Sew"), true, "T1")
    val teamFactory2 = Team("team-2", "Tổ 2", "factory-2", "factory-2", Operation("Sew"), true, "T2")
    every { orgUnitRepository.findById("team-1") } returns teamFactory1
    every { orgUnitRepository.findById("team-2") } returns teamFactory2

    val lsx1Assignment = createAssignment("ta-1", "lsx-1", "team-1", "Sew", "po-1", "Red", "S", 10)
    val lsx2Assignment = createAssignment("ta-2", "lsx-2", "team-2", "Sew", "po-1", "Red", "S", 10)

    // Each LSX is validated independently
    validateSingleFactoryPerSku(listOf(lsx1Assignment), orgUnitRepository)
    validateSingleFactoryPerSku(listOf(lsx2Assignment), orgUnitRepository)
  }

  private fun createAssignment(
    id: String,
    lsxId: String,
    teamId: String,
    op: String,
    po: String,
    color: String,
    size: String,
    qty: Int,
  ): TeamAssignment = TeamAssignment(id).apply {
    val events = listOf<DomainEvent>(
      TeamAssignmentCreated(
        assignmentId = id,
        productionOrderId = lsxId,
        buyerOrderId = "bo-1",
        teamId = teamId,
        operation = Operation(op),
        allocations = listOf(SkuAllocation(po, Color(color), Size(size), qty)),
        plannedStartDate = LocalDate.of(2026, 1, 1),
        plannedEndDate = LocalDate.of(2026, 1, 10),
        assignedAt = Instant.parse("2026-01-01T00:00:00Z"),
        actor = ActorRef("actor-1", "Planner"),
      )
    )
    loadFromHistory(events)
  }
}
