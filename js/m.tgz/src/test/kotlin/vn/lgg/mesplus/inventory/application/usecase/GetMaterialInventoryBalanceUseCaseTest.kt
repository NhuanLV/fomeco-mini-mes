package vn.lgg.mesplus.inventory.application.usecase

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.math.BigDecimal
import java.time.Instant
import java.util.UUID
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.infrastructure.repository.MaterialInventoryBalanceRecord
import vn.lgg.mesplus.inventory.infrastructure.repository.MaterialInventoryBalanceViewRepository
import vn.lgg.mesplus.production.domain.model.TeamMaterial
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamMaterialRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.production.domain.service.BomCalculationService
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Material
import vn.lgg.mesplus.shared.model.MaterialColorDep
import vn.lgg.mesplus.shared.model.MaterialSizeDep
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.MaterialSku

class GetMaterialInventoryBalanceUseCaseTest {
  private val balanceViewRepository = mockk<MaterialInventoryBalanceViewRepository>()
  private val bomCalculationService = mockk<BomCalculationService>()
  private val teamMaterialRepository = mockk<TeamMaterialRepository>()
  private val teamAssignmentRepository = mockk<TeamAssignmentRepository>()

  private val useCase =
    GetMaterialInventoryBalanceUseCase(
      balanceViewRepository,
      bomCalculationService,
      teamMaterialRepository,
      teamAssignmentRepository,
    )

  private val assignmentId = UUID.randomUUID().toString()

  @BeforeEach
  fun setUp() {
    every { teamAssignmentRepository.findById(assignmentId) } returns null
    every { teamMaterialRepository.findByTeamAssignmentId(assignmentId) } returns emptyList()
    every { bomCalculationService.getUomByArticle(assignmentId) } returns mapOf(
      "MAT-1" to "M",
      "MAT-2" to "PCS",
    )
  }

  @Test
  fun `returns all BOM materials with zero quantities when inventory has no records`() {
    every { balanceViewRepository.findByTeamAssignmentId(UUID.fromString(assignmentId)) } returns emptyList()
    every { bomCalculationService.calculateRaw(assignmentId) } returns mapOf(
      MaterialSku("po-1", "MAT-1", Color("Black"), Size("M")) to BigDecimal("10"),
      MaterialSku("po-1", "MAT-2", Color(""), Size("")) to BigDecimal("5"),
    )

    val balances = useCase.execute(assignmentId)

    balances.size shouldBe 2
    balances[0].apply {
      article shouldBe "MAT-1"
      color shouldBe "Black"
      size shouldBe "M"
      uom shouldBe "M"
      totalReceived shouldBe BigDecimal.ZERO
      totalIssued shouldBe BigDecimal.ZERO
      balance shouldBe BigDecimal.ZERO
    }
    balances[1].apply {
      article shouldBe "MAT-2"
      color shouldBe ""
      size shouldBe ""
      uom shouldBe "PCS"
      totalReceived shouldBe BigDecimal.ZERO
      totalIssued shouldBe BigDecimal.ZERO
      balance shouldBe BigDecimal.ZERO
    }
  }

  @Test
  fun `merges existing inventory records with unreceived BOM materials`() {
    val existingRecord = MaterialInventoryBalanceRecord(
      teamAssignmentId = assignmentId,
      article = "MAT-1",
      color = "Black",
      size = "M",
      uom = "M",
      totalReceived = BigDecimal("20.00"),
      totalIssued = BigDecimal("5.00"),
      balance = BigDecimal("15.00"),
    )
    every { balanceViewRepository.findByTeamAssignmentId(UUID.fromString(assignmentId)) } returns listOf(existingRecord)
    every { bomCalculationService.calculateRaw(assignmentId) } returns mapOf(
      MaterialSku("po-1", "MAT-1", Color("Black"), Size("M")) to BigDecimal("10"),
      MaterialSku("po-1", "MAT-2", Color(""), Size("")) to BigDecimal("5"),
    )

    val balances = useCase.execute(assignmentId)

    balances.size shouldBe 2
    balances[0].apply {
      article shouldBe "MAT-1"
      color shouldBe "Black"
      size shouldBe "M"
      uom shouldBe "M"
      totalReceived shouldBe BigDecimal("20.00")
      totalIssued shouldBe BigDecimal("5.00")
      balance shouldBe BigDecimal("15.00")
    }
    balances[1].apply {
      article shouldBe "MAT-2"
      color shouldBe ""
      size shouldBe ""
      uom shouldBe "PCS"
      totalReceived shouldBe BigDecimal.ZERO
      totalIssued shouldBe BigDecimal.ZERO
      balance shouldBe BigDecimal.ZERO
    }
  }

  @Test
  fun `falls back to teamMaterialRepository when calculateRaw is null`() {
    every { balanceViewRepository.findByTeamAssignmentId(UUID.fromString(assignmentId)) } returns emptyList()
    every { bomCalculationService.calculateRaw(assignmentId) } returns null
    every { teamMaterialRepository.findByTeamAssignmentId(assignmentId) } returns listOf(
      TeamMaterial(
        id = "tm-1",
        teamAssignmentId = assignmentId,
        material = Material(name = "MAT-1", category = "FABRIC", uom = "M"),
        alternativeName = "Vải lót",
        sizeDeps = listOf(MaterialSizeDep(Size("L"), Size("L"), BigDecimal("1.5"))),
        colorDeps = listOf(MaterialColorDep(Color("Red"), Color("Red"), BigDecimal("1.5"))),
        lastUpdatedAt = Instant.now(),
        lastUpdatedBy = ActorRef("actor-1", "Admin"),
      )
    )

    val balances = useCase.execute(assignmentId)

    balances.size shouldBe 1
    balances[0].apply {
      article shouldBe "MAT-1"
      color shouldBe "Red"
      size shouldBe "L"
      uom shouldBe "M"
      totalReceived shouldBe BigDecimal.ZERO
      totalIssued shouldBe BigDecimal.ZERO
      balance shouldBe BigDecimal.ZERO
      alternativeName shouldBe "Vải lót"
    }
  }

  @Test
  fun `calculates supplement only for non-required material from cumulative output`() {
    val assignment = mockk<TeamAssignment>()
    every { teamAssignmentRepository.findById(assignmentId) } returns assignment
    every { assignment.rawOutputReportedTotals } returns emptyList()
    every { balanceViewRepository.findByTeamAssignmentId(UUID.fromString(assignmentId)) } returns emptyList()
    every { bomCalculationService.calculateRaw(assignmentId) } returns
      mapOf(MaterialSku("po-1", "MAT-1", Color("Black"), Size("M")) to BigDecimal("10"))
    every { teamMaterialRepository.findByTeamAssignmentId(assignmentId) } returns
      listOf(
        TeamMaterial(
          id = "tm-1",
          teamAssignmentId = assignmentId,
          material = Material(name = "MAT-1", category = "Fabric", uom = "M"),
          isRequired = false,
          sizeDeps = emptyList(),
          colorDeps = emptyList(),
          lastUpdatedAt = Instant.now(),
          lastUpdatedBy = ActorRef("actor-1", "Admin"),
        ),
      )
    every { bomCalculationService.calculateForItems(assignment, any()) } returns
      mapOf(MaterialSku("po-1", "MAT-1", Color("Black"), Size("M")) to BigDecimal("4"))

    val balance = useCase.execute(assignmentId).single()

    balance.isRequired shouldBe false
    balance.requiredQuantity shouldBe BigDecimal("4")
    balance.supplementQuantity shouldBe BigDecimal("4")
    balance.status shouldBe "CẦN BỔ SUNG"
  }
}
