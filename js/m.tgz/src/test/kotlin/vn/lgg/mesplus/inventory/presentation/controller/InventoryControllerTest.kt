package vn.lgg.mesplus.inventory.presentation.controller

import io.kotest.assertions.throwables.shouldThrow
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import org.springframework.security.access.AccessDeniedException
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.iam.domain.repository.RoleRepository
import vn.lgg.mesplus.iam.domain.repository.UnitMembershipRepository
import vn.lgg.mesplus.inventory.application.usecase.GetBtpInventoryBalanceUseCase
import vn.lgg.mesplus.inventory.application.usecase.GetBtpInventoryTransactionsUseCase
import vn.lgg.mesplus.inventory.application.usecase.GetExcessMaterialsUseCase
import vn.lgg.mesplus.inventory.application.usecase.GetMaterialInventoryBalanceUseCase
import vn.lgg.mesplus.inventory.application.usecase.GetMaterialInventoryTransactionsUseCase
import vn.lgg.mesplus.production.infrastructure.repository.TeamAssignmentViewRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.MembershipInfo
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

class InventoryControllerTest {
  private val orgUnits = mockk<OrgUnitRepository>()
  private val roles = mockk<RoleRepository>()
  private val assignments = mockk<TeamAssignmentViewRepository>()
  private val btpBalance = mockk<GetBtpInventoryBalanceUseCase>()
  private val btpTransactions = mockk<GetBtpInventoryTransactionsUseCase>()
  private val materialBalance = mockk<GetMaterialInventoryBalanceUseCase>()
  private val materialTransactions = mockk<GetMaterialInventoryTransactionsUseCase>()
  private val excess = mockk<GetExcessMaterialsUseCase>()
  private val controller = InventoryController(
    btpBalance, btpTransactions, materialBalance, materialTransactions, excess,
    PermissionService(orgUnits, roles, mockk<UnitMembershipRepository>()), assignments,
  )
  private val endpoints: List<(String, Actor) -> Any> = listOf(
    controller::getBtpBalance, controller::getBtpTransactions,
    controller::getMaterialBalance, controller::getMaterialTransactions, controller::getExcessMaterials,
  )

  private fun actor(unitId: String) = Actor(
    "actor", "User", "user", "", listOf(MembershipInfo(unitId, setOf("role"))), emptySet(),
  )

  private fun allow(permission: Permission) {
    every { roles.hasPermission(setOf("role"), any()) } returns false
    every { roles.hasPermission(setOf("role"), permission) } returns true
    every { assignments.findDetailVm("assignment") } returns mockk { every { teamId } returns "team-a" }
  }

  @Test
  fun `all inventory endpoints reject access to another team before reading inventory`() {
    allow(Permission.REPORT_PROGRESS)
    every { orgUnits.findById("team-a") } returns null
    endpoints.forEach { endpoint ->
      shouldThrow<AccessDeniedException> { endpoint("assignment", actor("team-b")) }
    }
    verify(exactly = 0) { btpBalance.execute(any()) }
    verify(exactly = 0) { btpTransactions.execute(any()) }
    verify(exactly = 0) { materialBalance.execute(any()) }
    verify(exactly = 0) { materialTransactions.execute(any()) }
    verify(exactly = 0) { excess.execute(any()) }
  }

  @Test
  fun `own team and parent unit can read all inventory endpoints`() {
    every { btpBalance.execute("assignment") } returns emptyList()
    every { btpTransactions.execute("assignment") } returns emptyList()
    every { materialBalance.execute("assignment") } returns emptyList()
    every { materialTransactions.execute("assignment") } returns emptyList()
    every { excess.execute("assignment") } returns emptyList()
    every { orgUnits.findById("team-a") } returns mockk { every { parentId } returns "factory-a" }
    listOf(
      Permission.VIEW_PRODUCTION_ORDER, Permission.ISSUE_PRODUCTION_ORDER,
      Permission.UPDATE_COSTING, Permission.REPORT_PROGRESS,
      Permission.CREATE_REQUEST, Permission.EVALUATE_REQUEST,
    ).forEach { permission ->
      allow(permission)
      endpoints.forEach { endpoint ->
        endpoint("assignment", actor("team-a"))
        endpoint("assignment", actor("factory-a"))
      }
    }
  }

  @Test
  fun `receipt permission alone does not grant inventory access`() {
    allow(Permission.RECEIVE_REQUEST)
    endpoints.forEach { endpoint ->
      shouldThrow<AccessDeniedException> { endpoint("assignment", actor("team-a")) }
    }
  }
}
