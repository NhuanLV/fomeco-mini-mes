package vn.lgg.mesplus.production.application.eventhandler

import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.application.eventhandler.UpdateBoStatusHandler
import vn.lgg.mesplus.production.application.usecase.UpdateBuyerOrderStatusUseCase
import vn.lgg.mesplus.production.application.usecase.UpdateProductionOrderStatusUseCase
import vn.lgg.mesplus.production.domain.event.PurchaseOrderQuantityAdjusted
import vn.lgg.mesplus.production.domain.event.TeamAssignmentAllocationRevised
import vn.lgg.mesplus.production.infrastructure.repository.AssignmentOrderRefs
import vn.lgg.mesplus.production.infrastructure.repository.TeamAssignmentStatusLookupRepository
import vn.lgg.mesplus.shared.model.ActorRef

class AllocationStatusRecalculationTest {
  private val productionOrderStatus = mockk<UpdateProductionOrderStatusUseCase>()
  private val buyerOrderStatus = mockk<UpdateBuyerOrderStatusUseCase>()
  private val lookup = mockk<TeamAssignmentStatusLookupRepository>()
  private val actor = ActorRef("actor-1", "Planner")

  @Test
  fun `revision recalculates production and buyer order status`() {
    every { lookup.findOrderRefsByAssignmentId("ta-1") } returns
      AssignmentOrderRefs("lsx-1", "bo-1")
    justRun { productionOrderStatus.execute("lsx-1") }
    justRun { buyerOrderStatus.execute("bo-1") }
    val event =
      TeamAssignmentAllocationRevised(
        assignmentId = "ta-1",
        reason = "Tăng kế hoạch",
        allocations = emptyList(),
        actor = actor,
      )

    UpdatePoStatusHandler(productionOrderStatus, lookup).handle(event)
    UpdateBoStatusHandler(buyerOrderStatus, lookup).handle(event)

    verify(exactly = 1) { productionOrderStatus.execute("lsx-1") }
    verify(exactly = 1) { buyerOrderStatus.execute("bo-1") }
  }

  @Test
  fun `purchase order quantity adjustment recalculates both statuses`() {
    every { lookup.findOrderRefsByAssignmentId("ta-1") } returns
      AssignmentOrderRefs("lsx-1", "bo-1")
    justRun { productionOrderStatus.execute("lsx-1") }
    justRun { buyerOrderStatus.execute("bo-1") }
    val event =
      PurchaseOrderQuantityAdjusted(
        assignmentId = "ta-1",
        reason = "Đối soát",
        deltas = emptyList(),
        actor = actor,
      )

    UpdatePoStatusHandler(productionOrderStatus, lookup).handle(event)
    UpdateBoStatusHandler(buyerOrderStatus, lookup).handle(event)

    verify(exactly = 1) { productionOrderStatus.execute("lsx-1") }
    verify(exactly = 1) { buyerOrderStatus.execute("bo-1") }
  }
}
