package vn.lgg.mesplus.kanban.application

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.domain.model.Kanban
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size

class BtpSourceAssignmentResolverTest {
  @Test
  fun `resolves unique source by SKU when old Kanban has no PO ID`() {
    val kanbanRepository = mockk<KanbanRepository>()
    val assignmentRepository = mockk<TeamAssignmentRepository>()
    val orderRepository = mockk<ProductionOrderRepository>()
    val upstreamResolver = mockk<UpstreamBtpResolver>()
    val kanban = mockk<Kanban> { every { teamAssignmentId } returns "target" }
    val target = mockk<TeamAssignment> { every { productionOrderId } returns "order" }
    val order = mockk<ProductionOrder>()
    val source = mockk<TeamAssignment> {
      every { teamId } returns "supplier"
      every { allocations } returns listOf(SkuAllocation("po", Color("Red"), Size("M"), 1))
    }
    every { kanbanRepository.findById("kanban") } returns kanban
    every { assignmentRepository.findById("target") } returns target
    every { orderRepository.findById("order") } returns order
    every { upstreamResolver.resolve(target, order) } returns ResolvedUpstreamBtp("CUT", listOf(source), emptyList())

    BtpSourceAssignmentResolver(kanbanRepository, assignmentRepository, orderRepository, upstreamResolver)
      .resolve("kanban", "supplier", "Red", "M", null) shouldBe source
  }
}
