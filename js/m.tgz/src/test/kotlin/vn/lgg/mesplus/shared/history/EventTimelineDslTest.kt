package vn.lgg.mesplus.shared.history

import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import java.time.Instant
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.model.ActorRef

class EventTimelineDslTest : StringSpec({
  val actor = ActorRef("actor-1", "Alice")
  val firstAt = Instant.parse("2026-01-01T00:00:00Z")

  "builds a common entry with natural detail syntax and stable insertion order" {
    val entry =
      (Created(firstAt, actor) displayedAs "Created") {
        subtitle = "reason"
        detail {
          "first" shows "1"
          "second" shows "2"
        }
      }

    entry.occurredAt shouldBe firstAt
    entry.actor shouldBe actor
    entry.type shouldBe "Created"
    entry.subtitle shouldBe "reason"
    entry.detail.keys.toList() shouldContainExactly listOf("first", "second")
  }
})

private data class Created(
  override val occurredAt: Instant,
  override val actor: ActorRef?,
) : DomainEvent {
  override val aggRootId: String = "aggregate-1"
}
