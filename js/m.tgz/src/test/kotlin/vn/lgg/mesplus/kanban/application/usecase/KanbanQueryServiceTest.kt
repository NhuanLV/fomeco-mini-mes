package vn.lgg.mesplus.kanban.application.usecase

import io.kotest.matchers.maps.shouldContainExactly
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.time.Instant
import java.time.LocalDate
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.infrastructure.repository.BtpInventoryBalanceViewRepository
import vn.lgg.mesplus.kanban.application.BtpSourceAssignmentResolver
import vn.lgg.mesplus.kanban.domain.model.KanbanStatus
import vn.lgg.mesplus.kanban.infrastructure.repository.KanbanFilter
import vn.lgg.mesplus.kanban.infrastructure.repository.KanbanViewRepository
import vn.lgg.mesplus.kanban.presentation.controller.KanbanFilterRequest
import vn.lgg.mesplus.kanban.presentation.controller.toFilter
import vn.lgg.mesplus.kanban.presentation.viewmodel.KanbanDetailVm
import vn.lgg.mesplus.kanban.presentation.viewmodel.KanbanFilterOptionsVm
import vn.lgg.mesplus.kanban.presentation.viewmodel.KanbanSummaryVm
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.Style
import vn.lgg.mesplus.order.domain.model.StyleColorOrder
import vn.lgg.mesplus.order.domain.model.StyleSizeOrder
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.StyleRepository
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.PermissionService

class KanbanQueryServiceTest {
  private val repository = mockk<KanbanViewRepository>()
  private val permissionService = mockk<PermissionService>()
  private val teamAssignmentRepository = mockk<TeamAssignmentRepository>()
  private val productionOrderRepository = mockk<ProductionOrderRepository>()
  private val buyerOrderRepository = mockk<BuyerOrderRepository>()
  private val styleRepository = mockk<StyleRepository>()
  private val actor = Actor("actor-1", "Planner", "planner", "", emptyList(), emptySet())
  private val service =
    KanbanQueryService(
      repository,
      permissionService,
      teamAssignmentRepository,
      productionOrderRepository,
      buyerOrderRepository,
      mockk<BtpSourceAssignmentResolver>(),
      mockk<BtpInventoryBalanceViewRepository>(),
      mockk(relaxed = true),
      mockk(relaxed = true),
      styleRepository,
    )
  private val options = KanbanFilterOptionsVm(listOf("STYLE"), emptyList(), emptyList(), emptyList())

  @BeforeEach
  fun setUp() {
    every { styleRepository.findByName(any()) } returns null
    every { permissionService.lookupUnit(actor, any()) } returns emptyList()
    every { repository.buildSummariesConditions(any()) } returns null
    every { repository.buildEvaluateConditions(any(), any(), any()) } returns null
    every { repository.findFilterOptions(any()) } returns options
  }

  @Test
  fun `created and pending receive options use create units`() {
    every { permissionService.lookupUnit(actor, Permission.CREATE_KANBAN) } returns listOf("team-1")
    val filters = mutableListOf<KanbanFilter>()
    every { repository.buildSummariesConditions(capture(filters)) } returns null

    service.getFilterOptions(actor, "created") shouldBe options
    service.getFilterOptions(actor, "pending_receive") shouldBe options

    filters[0].teamIds shouldBe listOf("team-1")
    filters[0].pendingReceiveOnly shouldBe null
    filters[1].teamIds shouldBe listOf("team-1")
    filters[1].pendingReceiveOnly shouldBe true
  }

  @Test
  fun `completed options prefer create then issue then prepare units`() {
    val filter = slot<KanbanFilter>()
    every { repository.buildSummariesConditions(capture(filter)) } returns null
    every { permissionService.lookupUnit(actor, Permission.CREATE_KANBAN) } returns emptyList()
    every { permissionService.lookupUnit(actor, Permission.ISSUE_MATERIAL) } returns listOf("warehouse-1")
    every { permissionService.lookupUnit(actor, Permission.PREPARE_MATERIAL) } returns listOf("warehouse-2")

    service.getFilterOptions(actor, "completed") shouldBe options

    filter.captured.teamIds shouldBe null
    filter.captured.supplierUnitIds shouldBe listOf("warehouse-1")
    filter.captured.statuses shouldBe listOf(KanbanStatus.COMPLETED)
    verify(exactly = 0) { permissionService.lookupUnit(actor, Permission.PREPARE_MATERIAL) }
  }

  @Test
  fun `completed options fall back to prepare including empty scope`() {
    val filters = mutableListOf<KanbanFilter>()
    every { repository.buildSummariesConditions(capture(filters)) } returns null
    every { permissionService.lookupUnit(actor, Permission.PREPARE_MATERIAL) } returns
      listOf("warehouse-prepare")

    service.getFilterOptions(actor, "completed") shouldBe options
    filters.last().supplierUnitIds shouldBe listOf("warehouse-prepare")

    every { permissionService.lookupUnit(actor, Permission.PREPARE_MATERIAL) } returns emptyList()
    service.getFilterOptions(actor, "completed") shouldBe options
    filters.last().supplierUnitIds shouldBe emptyList()
  }

  @Test
  fun `evaluate prepare and issue options keep their repository policies`() {
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_KANBAN) } returns listOf("team-1")
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_EXTRA_KANBAN) } returns
      listOf("team-2")
    every { permissionService.lookupUnit(actor, Permission.PREPARE_MATERIAL) } returns
      listOf("warehouse-prepare")
    every { permissionService.lookupUnit(actor, Permission.ISSUE_MATERIAL) } returns
      listOf("warehouse-issue")
    val filters = mutableListOf<KanbanFilter>()
    every { repository.buildSummariesConditions(capture(filters)) } returns null

    service.getFilterOptions(actor, "evaluate") shouldBe options
    service.getFilterOptions(actor, "prepare") shouldBe options
    service.getFilterOptions(actor, "issue") shouldBe options

    verify {
      repository.buildEvaluateConditions(listOf("team-1"), listOf("team-2"), KanbanFilter())
    }
    filters[0] shouldBe
      KanbanFilter(
        supplierUnitIds = listOf("warehouse-prepare"),
        statuses = listOf(KanbanStatus.APPROVED, KanbanStatus.PARTIALLY_ISSUED),
      )
    filters[1] shouldBe
      KanbanFilter(
        supplierUnitIds = listOf("warehouse-issue"),
        statuses = listOf(KanbanStatus.APPROVED, KanbanStatus.PARTIALLY_ISSUED),
      )
  }

  @Test
  fun `unknown options return empty result without repository query`() {
    service.getFilterOptions(actor, "unknown") shouldBe
      KanbanFilterOptionsVm(emptyList(), emptyList(), emptyList(), emptyList())

    verify(exactly = 0) { repository.findFilterOptions(any()) }
  }

  @Test
  fun `team filter is limited to the actor accessible teams`() {
    val filter = KanbanFilterRequest(teamIds = listOf("team-1", "team-2"))

    filter.toFilter(allowedTeamIds = listOf("team-2", "team-3")).teamIds shouldBe listOf("team-2")
  }

  @Test
  fun `detail metadata is enriched from production and buyer orders`() {
    val assignment =
      TeamAssignment.create(
        id = "assignment-1",
        productionOrderId = "production-1",
        buyerOrderId = "buyer-1",
        teamId = "team-1",
        operation = Operation("SEW"),
        allocations = listOf(SkuAllocation("po-1", Color("RED"), Size("M"), 1)),
        plannedStartDate = LocalDate.of(2026, 1, 1),
        plannedEndDate = LocalDate.of(2026, 1, 10),
      )
    val productionOrder =
      ProductionOrder(
        id = "production-1",
        buyerOrderId = "buyer-1",
        productionCode = "LSX-1",
        factoryIds = listOf("factory-1"),
        mainCompanyCode = "LGG-BG",
        status = ProductionOrderStatus.IN_PROGRESS,
      )
    val buyerOrder =
      BuyerOrder(
        "buyer-1",
        null,
        "STYLE-1",
        "R1",
        Instant.parse("2026-01-01T00:00:00Z"),
      )

    every { repository.findById("kanban-1") } returns detailWithoutMetadata()
    every { teamAssignmentRepository.findById("assignment-1") } returns assignment
    every { productionOrderRepository.findById("production-1") } returns productionOrder
    every { buyerOrderRepository.findById("buyer-1") } returns buyerOrder
    every { styleRepository.findByName("STYLE-1") } returns Style(
      name = "STYLE-1", customer = "", brand = "", season = "",
      colorOrders = listOf(StyleColorOrder(Color("Blue"), 2), StyleColorOrder(Color("Red"), 1)),
      sizeOrders = listOf(StyleSizeOrder(Size("M"), 2), StyleSizeOrder(Size("S"), 1)),
    )

    val detail = service.getKanbanDetail("kanban-1", actor)

    detail.styleName shouldBe "STYLE-1"
    detail.productionOrderCode shouldBe "LSX-1"
    detail.kanbanType shouldBe "EXTRA"
    detail.styleColorOrder shouldContainExactly listOf("Red", "Blue")
    detail.styleSizeOrder shouldContainExactly listOf("S", "M")
  }

  @Test
  fun `counters are sparse and preserve each tab filter`() {
    every { permissionService.lookupUnit(actor, Permission.CREATE_KANBAN) } returns listOf("team-1")
    every { permissionService.lookupUnit(actor, Permission.PREPARE_MATERIAL) } returns listOf("warehouse-1")
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_KANBAN) } returns listOf("team-2")
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_EXTRA_KANBAN) } returns emptyList()
    every { repository.findSummaries(any(), Pageable.unpaged()) } answers {
      page(
        when {
          firstArg<KanbanFilter>().pendingReceiveOnly == true -> 2
          firstArg<KanbanFilter>().statuses == listOf(KanbanStatus.COMPLETED) -> 3
          firstArg<KanbanFilter>().supplierUnitIds == listOf("warehouse-1") -> 4
          else -> 1
        }
      )
    }
    every {
      repository.findEvaluateSummaries(listOf("team-2"), emptyList(), any(), Pageable.unpaged())
    } returns page(5)

    val counters = service.getKanbanCounters(actor, KanbanFilterRequest())
    counters.shouldContainExactly(
      mapOf(
        "created" to 1,
        "pending_receive" to 2,
        "completed" to 3,
        "evaluate" to 5,
        "prepare" to 4,
      )
    )
    counters.keys.toList().shouldContainExactly(
      "created",
      "pending_receive",
      "completed",
      "evaluate",
      "prepare",
    )
  }

  @Test
  fun `completed create counter clears pending receive filter`() {
    every { permissionService.lookupUnit(actor, Permission.CREATE_KANBAN) } returns listOf("team-1")
    val filters = mutableListOf<KanbanFilter>()
    every { repository.findSummaries(capture(filters), Pageable.unpaged()) } returns page(0)

    service.getKanbanCounters(
      actor,
      KanbanFilterRequest(pendingReceiveOnly = true),
    )

    filters.single { it.statuses == listOf(KanbanStatus.COMPLETED) }
      .pendingReceiveOnly shouldBe null
  }

  @Test
  fun `prepare and issue lists keep explicit statuses and default only when absent`() {
    every { permissionService.lookupUnit(actor, Permission.PREPARE_MATERIAL) } returns
      listOf("warehouse-1")
    every { permissionService.lookupUnit(actor, Permission.ISSUE_MATERIAL) } returns
      listOf("warehouse-1")
    val filters = mutableListOf<KanbanFilter>()
    every { repository.findSummaries(capture(filters), any()) } returns page(0)

    service.findPrepareMaterialKanbans(
      actor,
      KanbanFilterRequest(statuses = listOf(KanbanStatus.REJECTED)),
      Pageable.unpaged(),
    )
    service.findPrepareMaterialKanbans(actor, KanbanFilterRequest(), Pageable.unpaged())
    service.findIssueMaterialKanbans(
      actor,
      KanbanFilterRequest(statuses = listOf(KanbanStatus.REJECTED)),
      Pageable.unpaged(),
    )
    service.findIssueMaterialKanbans(actor, KanbanFilterRequest(), Pageable.unpaged())

    filters[0].statuses shouldBe listOf(KanbanStatus.REJECTED)
    filters[1].statuses shouldBe
      listOf(KanbanStatus.APPROVED, KanbanStatus.PARTIALLY_ISSUED)
    filters[2].statuses shouldBe listOf(KanbanStatus.REJECTED)
    filters[3].statuses shouldBe
      listOf(KanbanStatus.APPROVED, KanbanStatus.PARTIALLY_ISSUED)
  }

  private fun page(total: Long): Page<KanbanSummaryVm> =
    mockk {
      every { totalElements } returns total
    }

  private fun detailWithoutMetadata() =
    KanbanDetailVm(
      id = "kanban-1",
      teamAssignmentId = "assignment-1",
      teamId = "team-1",
      teamName = "Team",
      styleName = null,
      productionOrderCode = null,
      kanbanType = "STANDARD",
      status = KanbanStatus.PENDING_EVALUATION,
      plan = emptyList(),
      items = emptyList(),
      createdAt = Instant.parse("2026-01-01T00:00:00Z"),
      createdById = actor.id,
      createdByName = actor.name,
    )
}
