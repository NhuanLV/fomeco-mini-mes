package vn.lgg.mesplus.kanban.application

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

class UpstreamBtpResolverTest {
  @Test
  fun `split receiving teams need only their allocated quantity from upstream`() {
    val cutting = assignment("cutting", "CUT", 30)
    val sewingOne = assignment("sewing-1", "SEW", 10)
    val sewingTwo = assignment("sewing-2", "SEW", 20)
    val repository = mockk<TeamAssignmentRepository>()
    every { repository.findByProductionOrderId("order") } returns listOf(cutting, sewingOne, sewingTwo)
    val order = mockk<ProductionOrder> {
      every { routing } returns listOf("CUT", "SEW")
    }
    val resolver = UpstreamBtpResolver(repository)

    resolver.resolve(sewingOne, order).allocations.sumOf { it.quantity } shouldBe 10
    resolver.resolve(sewingTwo, order).allocations.sumOf { it.quantity } shouldBe 20
    cutting.allocations.single().quantity shouldBe 30
  }

  @Test
  fun `multiple upstream teams do not multiply receiving demand`() {
    val cuttingOne = assignment("cutting-1", "CUT", 20)
    val cuttingTwo = assignment("cutting-2", "CUT", 10)
    val sewing = assignment("sewing", "SEW", 30)
    val repository = mockk<TeamAssignmentRepository>()
    every { repository.findByProductionOrderId("order") } returns listOf(cuttingOne, cuttingTwo, sewing)
    val order = mockk<ProductionOrder> {
      every { routing } returns listOf("CUT", "SEW")
    }

    val result = UpstreamBtpResolver(repository).resolve(sewing, order)

    result.allocations shouldBe sewing.allocations
    result.upstreamAssignments shouldBe listOf(cuttingOne, cuttingTwo)
  }

  private fun assignment(id: String, operation: String, quantity: Int) = TeamAssignment.create(
    id = id,
    productionOrderId = "order",
    buyerOrderId = "buyer-order",
    teamId = id,
    operation = Operation(operation),
    allocations = listOf(SkuAllocation("po", Color("RED"), Size("M"), quantity)),
    plannedStartDate = LocalDate.of(2026, 10, 20),
    plannedEndDate = LocalDate.of(2026, 10, 21),
  )
}
