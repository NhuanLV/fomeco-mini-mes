package vn.lgg.mesplus.iam.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.string.shouldContain
import io.mockk.every
import io.mockk.mockk
import org.junit.jupiter.api.Test
import org.springframework.util.IdGenerator
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.Corporation
import vn.lgg.mesplus.iam.domain.model.CorporationClassification
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.iam.domain.repository.WfxSupplierRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.service.PermissionService
import java.util.UUID

class CompanyWfxSupplierValidationTest {
  private val orgUnitRepo = mockk<OrgUnitRepository>(relaxed = true)
  private val permissionService = mockk<PermissionService>(relaxed = true)
  private val wfxSupplierRepository = mockk<WfxSupplierRepository>(relaxed = true)
  private val actor = Actor("admin", "Admin", "admin", "", emptyList(), emptySet())

  @Test
  fun `create rejects WFX supplier for an inhouse corporation`() {
    val corporation = Corporation("corp-1", "Inhouse", classification = CorporationClassification.INHOUSE)
    every { orgUnitRepo.findById(corporation.id) } returns corporation
    every { orgUnitRepo.existsByCode(any(), any()) } returns false

    val error =
      shouldThrow<IllegalArgumentException> {
        CreateCompanyUseCase(orgUnitRepo, permissionService, IdGenerator { UUID.randomUUID() }, wfxSupplierRepository)
          .execute(
            CreateCompanyCommand("Company", "COMP-1", corporation.id, wfxSupplierName = "Supplier A"),
            actor,
          )
      }

    error.message shouldContain "Outsource"
  }

  @Test
  fun `update rejects a supplier absent from the WFX cache`() {
    val corporation = Corporation("corp-1", "Outsource", classification = CorporationClassification.OUTSOURCE)
    val company = Company("company-1", "Company", corporation.id, "", code = "COMP-1")
    every { orgUnitRepo.findById(company.id) } returns company
    every { orgUnitRepo.findById(corporation.id) } returns corporation
    every { orgUnitRepo.existsByCode(any(), any()) } returns false
    every { wfxSupplierRepository.findAll() } returns listOf("Supplier A")

    val error =
      shouldThrow<IllegalArgumentException> {
        UpdateCompanyUseCase(orgUnitRepo, permissionService, wfxSupplierRepository)
          .execute(company.id, UpdateCompanyCommand("Company", "COMP-1", wfxSupplierName = "Supplier B"), actor)
      }

    error.message shouldContain "không tồn tại"
  }
}
