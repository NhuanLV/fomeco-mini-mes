package vn.lgg.mesplus.dashboard.presentation.controller

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.dashboard.application.model.DashboardDateRange
import vn.lgg.mesplus.dashboard.application.model.DashboardProgressTab

class DashboardControllerTest {
  private val fixedToday = LocalDate.of(2026, 4, 15)

  @Test
  fun `toFilter accepts valid dates within or on today`() {
    val request = DashboardRequest(
      from = LocalDate.of(2026, 4, 10),
      to = LocalDate.of(2026, 4, 15),
    )
    val filter = request.toFilter(fixedToday)
    filter.range.from shouldBe LocalDate.of(2026, 4, 10)
    filter.range.to shouldBe LocalDate.of(2026, 4, 15)
  }

  @Test
  fun `toFilter defaults null dates to today`() {
    val request = DashboardRequest()
    val filter = request.toFilter(fixedToday)
    filter.range.from shouldBe fixedToday
    filter.range.to shouldBe fixedToday
  }

  @Test
  fun `unit request carries only organization filters`() {
    val filter = DashboardUnitRequest(
      companyId = "company-1",
      factoryId = "factory-1",
      teamId = "team-1",
      warehouseId = "warehouse-1",
    ).toFilter(fixedToday)

    filter.range shouldBe DashboardDateRange(fixedToday, fixedToday)
    filter.companyId shouldBe "company-1"
    filter.factoryId shouldBe "factory-1"
    filter.teamId shouldBe "team-1"
    filter.warehouseId shouldBe "warehouse-1"
  }

  @Test
  fun `toFilter throws when to is in the future`() {
    val request = DashboardRequest(
      from = LocalDate.of(2026, 4, 10),
      to = LocalDate.of(2026, 4, 16),
    )
    val ex = shouldThrow<IllegalArgumentException> {
      request.toFilter(fixedToday)
    }
    ex.message shouldBe "Ngày kết thúc không được vượt quá ngày hiện tại"
  }

  @Test
  fun `toFilter throws when from is in the future`() {
    val request = DashboardRequest(
      from = LocalDate.of(2026, 4, 16),
      to = null,
    )
    val ex = shouldThrow<IllegalArgumentException> {
      request.toFilter(fixedToday)
    }
    ex.message shouldBe "Ngày bắt đầu không được vượt quá ngày hiện tại"
  }

  @Test
  fun `toFilter throws when from is after to`() {
    val request = DashboardRequest(
      from = LocalDate.of(2026, 4, 12),
      to = LocalDate.of(2026, 4, 10),
    )
    val ex = shouldThrow<IllegalArgumentException> {
      request.toFilter(fixedToday)
    }
    ex.message shouldBe "Ngày bắt đầu không được sau ngày kết thúc"
  }

  @Test
  fun `DashboardProgressTab fromString parses valid values case-insensitively`() {
    DashboardProgressTab.fromString("LSX") shouldBe DashboardProgressTab.LSX
    DashboardProgressTab.fromString("lsx") shouldBe DashboardProgressTab.LSX
    DashboardProgressTab.fromString("LCD") shouldBe DashboardProgressTab.LCD
    DashboardProgressTab.fromString("lcd") shouldBe DashboardProgressTab.LCD
  }

  @Test
  fun `DashboardProgressTab fromString returns null for null or blank`() {
    DashboardProgressTab.fromString(null) shouldBe null
    DashboardProgressTab.fromString("   ") shouldBe null
  }

  @Test
  fun `DashboardProgressTab fromString throws on invalid value`() {
    val ex = shouldThrow<IllegalArgumentException> {
      DashboardProgressTab.fromString("ABC")
    }
    ex.message shouldBe "Tab 'ABC' không hợp lệ. Chỉ chấp nhận LSX hoặc LCD"
  }
}
