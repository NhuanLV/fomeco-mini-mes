package vn.lgg.mesplus.kanban.domain.model

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import java.math.BigDecimal
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.domain.event.KanbanAssignmentInitialized.AssignmentItem
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialIssued
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialIssued.IssuedItem
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialPrepared.PreparedItem
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialReceived
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialReceived.ReceivedItem
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.shared.model.ActorRef

class KanbanAssignmentTest {
  private val actor = ActorRef("actor-1", "Warehouse")

  @Test
  fun `prepare issue and receive normalize quantities from assignment state`() {
    val assignment = assignment()

    assignment.prepare(listOf(prepared("2.123456")), actor)
    assignment.issue(listOf(issued("999")), actor)
    assignment.receive(listOf(received("888")), actor)

    val issuedEvent = assignment.changes.filterIsInstance<KanbanMaterialIssued>().single()
    val receivedEvent = assignment.changes.filterIsInstance<KanbanMaterialReceived>().single()
    issuedEvent.items.single().qty shouldBe BigDecimal("2.1235")
    receivedEvent.items.single().qty shouldBe BigDecimal("2.1235")
    assignment.allItemsDone() shouldBe true
  }

  @Test
  fun `issue requires preparation and cannot be repeated`() {
    val assignment = assignment()

    shouldThrow<IllegalStateException> {
      assignment.issue(listOf(issued("1")), actor)
    }.message shouldBe "Item MAT-1 is not prepared"

    assignment.prepare(listOf(prepared("1")), actor)
    assignment.issue(listOf(issued("1")), actor)

    shouldThrow<IllegalStateException> {
      assignment.issue(listOf(issued("1")), actor)
    }.message shouldBe "Item MAT-1 is already issued"
  }

  @Test
  fun `receive requires issue and cannot be repeated`() {
    val assignment = assignment()

    shouldThrow<IllegalStateException> {
      assignment.receive(listOf(received("1")), actor)
    }.message shouldBe "Item MAT-1 has not been issued yet"

    assignment.prepare(listOf(prepared("1")), actor)
    assignment.issue(listOf(issued("1")), actor)
    assignment.receive(listOf(received("1")), actor)

    shouldThrow<IllegalStateException> {
      assignment.receive(listOf(received("1")), actor)
    }.message shouldBe "Item MAT-1 is already received"
  }

  @Test
  fun `same SKU receives regular and positive independently without duplicate receipt`() {
    val regular = AssignmentItem("BTP CUT-1", "RED", "M", null, BigDecimal("100"), PurchaseOrderType.REGULAR)
    val positive = regular.copy(requiredQty = BigDecimal("10"), purchaseOrderType = PurchaseOrderType.POSITIVE)
    val assignment = KanbanAssignment.init("kanban-1", "supplier-1", listOf(regular, positive), actor)
    val prepared = listOf(regular, positive).map {
      PreparedItem(it.article, it.color, it.size, it.poId, it.requiredQty, "", it.purchaseOrderType)
    }
    assignment.prepare(prepared, actor)
    assignment.issue(prepared.map { IssuedItem(it.article, it.color, it.size, it.poId, it.qty, "", it.purchaseOrderType) }, actor)
    val received = prepared.map { ReceivedItem(it.article, it.color, it.size, it.poId, it.qty, it.purchaseOrderType) }
    assignment.receive(listOf(received[1]), actor)
    assignment.allItemsDone() shouldBe false
    assignment.receive(listOf(received[0]), actor)
    assignment.allItemsDone() shouldBe true
    assignment.changes.filterIsInstance<KanbanMaterialReceived>().map { it.items.single().qty } shouldBe
      listOf(BigDecimal("10.0000"), BigDecimal("100.0000"))
    shouldThrow<IllegalStateException> { assignment.receive(listOf(received[1]), actor) }
  }

  private fun assignment() =
    KanbanAssignment.init(
      kanbanId = "kanban-1",
      supplierUnitId = "supplier-1",
      items = listOf(AssignmentItem("MAT-1", "RED", "M", null, BigDecimal("10"))),
      actor = actor,
    )

  private fun prepared(quantity: String) =
    PreparedItem("MAT-1", "RED", "M", null, BigDecimal(quantity), "")

  private fun issued(quantity: String) =
    IssuedItem("MAT-1", "RED", "M", null, BigDecimal(quantity), "")

  private fun received(quantity: String) =
    ReceivedItem("MAT-1", "RED", "M", null, BigDecimal(quantity))
}
