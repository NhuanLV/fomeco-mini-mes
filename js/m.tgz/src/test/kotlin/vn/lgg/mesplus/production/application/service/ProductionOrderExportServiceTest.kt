package vn.lgg.mesplus.production.application.service

import io.kotest.matchers.shouldBe
import java.io.ByteArrayInputStream
import org.apache.poi.ss.usermodel.BorderStyle
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.util.CellRangeAddress
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.production.infrastructure.service.PoiProductionOrderExportService

class ProductionOrderExportServiceTest {
  @Test
  fun `exports styled workbook with separate units notes numbers metadata and merged PO cells`() {
    val row = ProductionOrderExportRow(
      poId = "po-1", poCode = "PO-1", destination = "US", color = "Red",
      notes = listOf("Ghi chú một", "", "Ghi chú ba"), quantities = listOf(10, 20),
      operation = "CUT", company = "Công ty 1", factory = "Xí nghiệp 1", team = "Tổ 1",
      checkDate = "01/09/2026", deliveryDate = "02/09/2026",
      plannedStartDate = "01/08/2026", plannedEndDate = "31/08/2026",
    )
    val data = ProductionOrderExportData(
      factoryIds = listOf("factory-1"), styleName = "STYLE-1", orderNumber = "LSX-1",
      customer = "Customer", brand = "Brand", syncDate = "01/08/2026",
      productDate = "02/08/2026", firstSku = "Red S", allSizes = listOf("S", "M"),
      noteColumnCount = 3, rows = listOf(row, row.copy(color = "Blue")),
    )
    XSSFWorkbook(ByteArrayInputStream(PoiProductionOrderExportService().exportToExcel(data))).use { workbook ->
      val sheet = workbook.getSheet("LSX")
      val header = sheet.getRow(5)
      header.getCell(5).stringCellValue shouldBe "Ghi chú 3"
      header.getCell(10).stringCellValue shouldBe "Công ty"
      header.getCell(11).stringCellValue shouldBe "Xí nghiệp"
      header.getCell(12).stringCellValue shouldBe "Tổ"
      header.getCell(0).cellStyle.fillForegroundXSSFColor.rgb.toList() shouldBe
        byteArrayOf(217.toByte(), 226.toByte(), 243.toByte()).toList()
      header.getCell(0).cellStyle.font.bold shouldBe true
      header.getCell(0).cellStyle.borderBottom shouldBe BorderStyle.THIN
      sheet.getRow(0).getCell(0).cellStyle.font.fontHeightInPoints shouldBe 16.toShort()
      sheet.getRow(1).getCell(3).stringCellValue shouldBe "LSX-1"
      sheet.getRow(2).getCell(3).stringCellValue shouldBe "01/08/2026"
      sheet.getRow(3).getCell(5).stringCellValue shouldBe "Red S"
      val first = sheet.getRow(6)
      first.getCell(5).stringCellValue shouldBe "Ghi chú ba"
      first.getCell(6).cellType shouldBe CellType.NUMERIC
      first.getCell(6).numericCellValue shouldBe 10.0
      first.getCell(8).numericCellValue shouldBe 30.0
      first.getCell(8).cellStyle.fillForegroundXSSFColor.rgb.toList() shouldBe
        byteArrayOf(242.toByte(), 242.toByte(), 242.toByte()).toList()
      first.getCell(10).stringCellValue shouldBe "Công ty 1"
      first.getCell(11).stringCellValue shouldBe "Xí nghiệp 1"
      first.getCell(12).stringCellValue shouldBe "Tổ 1"
      first.getCell(16).stringCellValue shouldBe "31/08/2026"
      sheet.isColumnHidden(17) shouldBe true
      sheet.mergedRegions.contains(CellRangeAddress(6, 7, 0, 0)) shouldBe true
      sheet.mergedRegions.contains(CellRangeAddress(6, 7, 1, 1)) shouldBe true
      sheet.dataValidations.isEmpty() shouldBe true
    }
  }
}
