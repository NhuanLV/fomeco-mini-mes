package vn.lgg.mesplus.notification

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.shared.NotificationTarget
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.Actor

class NotificationControllerTest {
  private val service = mockk<NotificationService>()
  private val emitters = mockk<SseEmitters>()
  private val controller = NotificationController(service, emitters)
  private val actor = Actor("recipient-1", "Worker", "worker", "", emptyList(), emptySet())

  @Test
  fun `lists only the authenticated recipients notifications`() {
    val expected = NotificationPage(emptyList(), null, 3)
    every { service.list("recipient-1", true, "cursor", 10) } returns expected

    val result = controller.list(actor, unreadOnly = true, cursor = "cursor", size = 10)

    result shouldBe expected.toView()
  }

  @Test
  fun `marks a notification read for the authenticated recipient`() {
    justRun { service.markAsRead("notification-1", "recipient-1") }

    controller.markAsRead("notification-1", actor)

    verify(exactly = 1) { service.markAsRead("notification-1", "recipient-1") }
  }

  @Test
  fun `marks a target read for the authenticated recipient`() {
    val target = NotificationTarget(ResourceType.KANBAN, "kanban-1")
    justRun { service.markTargetAsRead(target, "recipient-1") }

    controller.markTargetAsRead(target, actor)

    verify(exactly = 1) { service.markTargetAsRead(target, "recipient-1") }
  }

  @Test
  fun `marks all notifications read for the authenticated recipient`() {
    justRun { service.markAllAsRead("recipient-1") }

    controller.markAllAsRead(actor)

    verify(exactly = 1) { service.markAllAsRead("recipient-1") }
  }

  @Test
  fun `subscribes SSE for the authenticated recipient`() {
    every { emitters.subscribe("recipient-1") } returns mockk()

    controller.stream(actor)

    verify(exactly = 1) { emitters.subscribe("recipient-1") }
  }
}
