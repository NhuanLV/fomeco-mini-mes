package vn.lgg.mesplus.kanban.application.usecase

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.math.BigDecimal
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.Factory
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.model.Warehouse
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.iam.infrastructure.repository.view.OrgUnitViewRepository
import vn.lgg.mesplus.iam.presentation.viewmodel.UnitRefVm
import vn.lgg.mesplus.inventory.application.usecase.GetMaterialInventoryBalanceUseCase
import vn.lgg.mesplus.inventory.presentation.viewmodel.MaterialInventoryBalanceVm
import vn.lgg.mesplus.kanban.application.ResolvedUpstreamBtp
import vn.lgg.mesplus.kanban.application.UpstreamBtpResolver
import vn.lgg.mesplus.kanban.infrastructure.repository.KanbanViewRepository
import vn.lgg.mesplus.kanban.presentation.viewmodel.BomConsumptionEntryVm
import vn.lgg.mesplus.kanban.presentation.viewmodel.BtpLineVm
import vn.lgg.mesplus.kanban.presentation.viewmodel.CumulativeEntryVm
import vn.lgg.mesplus.kanban.presentation.viewmodel.PlanItemVm
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.production.domain.service.BomCalculationService
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.MaterialSku

class GetKanbanContextUseCaseTest {
  private val assignmentRepository = mockk<TeamAssignmentRepository>()
  private val productionOrderRepository = mockk<ProductionOrderRepository>()
  private val bomCalculationService = mockk<BomCalculationService>()
  private val kanbanViewRepository = mockk<KanbanViewRepository>()
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val orgUnitViewRepository = mockk<OrgUnitViewRepository>()
  private val purchaseOrderRepository = mockk<PurchaseOrderRepository>()
  private val upstreamBtpResolver = mockk<UpstreamBtpResolver>()
  private val inventoryBalanceUseCase = mockk<GetMaterialInventoryBalanceUseCase>()
  private val useCase =
    GetKanbanContextUseCase(
      assignmentRepository,
      productionOrderRepository,
      bomCalculationService,
      kanbanViewRepository,
      orgUnitRepository,
      orgUnitViewRepository,
      purchaseOrderRepository,
      upstreamBtpResolver,
      inventoryBalanceUseCase,
    )

  @Test
  fun `builds all context sections with current grouping rounding and fallbacks`() {
    val red = Color("RED")
    val medium = Size("M")
    val current =
      assignment("assignment-1", "team-1", Operation("SEW-1"), allocation(10))
    val upstream =
      assignment("upstream-1", "team-upstream", Operation("CUT-1"), allocation(4))
    val productionOrder =
      ProductionOrder(
        id = "production-1",
        buyerOrderId = "buyer-order-1",
        productionCode = "PROD-1",
        factoryIds = listOf("factory-1"),
        mainCompanyCode = "LGG-BG",
        status = ProductionOrderStatus.IN_PROGRESS,
        routing = listOf("CUT-1", "SEW-1"),
      )
    every { assignmentRepository.findById("assignment-1") } returns current
    every { productionOrderRepository.findById("production-1") } returns productionOrder
    every { bomCalculationService.calculateRaw("assignment-1") } returns
      linkedMapOf(
        MaterialSku("po-1", "FABRIC", red, medium) to BigDecimal("1.23456"),
        MaterialSku("po-2", "FABRIC", red, medium) to BigDecimal("2.34567"),
      )
    every { upstreamBtpResolver.resolve(current, productionOrder) } returns
      ResolvedUpstreamBtp(
        previousOperation = "CUT-1",
        upstreamAssignments = listOf(upstream),
        allocations = current.allocations,
      )
    every { orgUnitRepository.findByIds(listOf("team-upstream")) } returns
      listOf(team("team-upstream", "Cut Team", "factory-1", Operation("CUT-1")))
    every { purchaseOrderRepository.findCodesByIds(listOf("po-1")) } returns emptyMap()
    every { purchaseOrderRepository.findByBuyerOrderId(any()) } returns listOf(mockk {
      every { id } returns "po-1"
      every { type } returns PurchaseOrderType.REGULAR
    })
    every { kanbanViewRepository.sumRequiredByTeamAssignment("assignment-1", any(), any()) } returns emptyMap()
    every { kanbanViewRepository.sumRequiredByTeamAssignment("assignment-1", PurchaseOrderType.REGULAR, null) } returns
      mapOf(Triple("BTP CUT-1", red, medium) to BigDecimal("3"))
    every { kanbanViewRepository.sumReceivedByTeamAssignment("assignment-1", any(), any(), any()) } returns emptyMap()
    every { kanbanViewRepository.sumRequiredByTeamAssignment("assignment-1") } returns
      linkedMapOf(Triple("FABRIC", red, medium) to BigDecimal("3.45678"))
    every { inventoryBalanceUseCase.execute("assignment-1") } returns
      listOf(
        MaterialInventoryBalanceVm(
          "FABRIC",
          "RED",
          "M",
          "kg",
          BigDecimal("4.56789"),
          BigDecimal.ZERO,
          BigDecimal.ZERO,
        ),
      )
    every {
      kanbanViewRepository.sumReceivedByTeamAssignment("assignment-1")
    } returns linkedMapOf(Triple("FABRIC", red, medium) to BigDecimal("2.22222"))
    val plan = listOf(PlanItemVm("po-1", "PO-1", red, medium, 10))
    every { kanbanViewRepository.sumPlannedByTeamAssignment("assignment-1") } returns plan
    every { orgUnitRepository.findByIds(listOf("team-1")) } returns
      listOf(team("team-1", "Sew Team", "factory-1", Operation("SEW-1")))
    every { orgUnitRepository.findByIds(listOf("factory-1")) } returns
      listOf(factory())
    every { orgUnitRepository.findByIds(listOf("company-1")) } returns
      listOf(company())
    every { orgUnitViewRepository.findWarehousesByCompanyId("company-1") } returns
      listOf(warehouse())

    val result = useCase.execute("assignment-1")

    result.teamAssignmentId shouldBe "assignment-1"
    result.bomConsumption.shouldContainExactly(
      BomConsumptionEntryVm("FABRIC", red, medium, BigDecimal("3.5802")),
    )
    result.btpLines.shouldContainExactly(
      BtpLineVm(red, medium, "po-1", "po-1", 10),
    )
    result.cumulativeReported.shouldContainExactly(
      CumulativeEntryVm("FABRIC", red, medium, BigDecimal("3.4568")),
      CumulativeEntryVm("BTP CUT-1", red, medium, BigDecimal("3.0000"), PurchaseOrderType.REGULAR),
    )
    result.cumulativeReceivedInStandard.shouldContainExactly(
      CumulativeEntryVm("FABRIC", red, medium, BigDecimal("2.2222")),
    )
    result.cumulativeReceivedAll.shouldContainExactly(
      CumulativeEntryVm("FABRIC", red, medium, BigDecimal("4.5679")),
    )
    result.requiredPlan shouldBe plan
    result.previousOperation shouldBe "CUT-1"
    result.previousOperationTeams.shouldContainExactly(UnitRefVm("team-upstream", "Cut Team - Factory - Company"))
    result.availableWarehouses.shouldContainExactly(UnitRefVm("warehouse-1", "Main Warehouse"))
  }

  private fun allocation(quantity: Int) =
    SkuAllocation("po-1", Color("RED"), Size("M"), quantity)

  private fun assignment(
    id: String,
    teamId: String,
    operation: Operation,
    allocation: SkuAllocation,
  ) =
    TeamAssignment.create(
      id = id,
      productionOrderId = "production-1",
      buyerOrderId = "buyer-order-1",
      teamId = teamId,
      operation = operation,
      allocations = listOf(allocation),
      plannedStartDate = LocalDate.of(2026, 1, 1),
      plannedEndDate = LocalDate.of(2026, 1, 10),
    )

  private fun team(id: String, name: String, factoryId: String, operation: Operation) =
    Team(id, name, "parent-1", factoryId, operation, true)

  private fun factory() =
    Factory(
      "factory-1",
      "Factory",
      "company-1",
      "",
      "company-1",
      listOf(Operation("SEW-1")),
      true,
    )

  private fun company() =
    Company("company-1", "Company", "root", "", null, true)

  private fun warehouse() =
    Warehouse("warehouse-1", "Main Warehouse", "company-1", "", "company-1", true)
}
