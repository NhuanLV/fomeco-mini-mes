package vn.lgg.mesplus.production.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.ReportType
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.SkuQuantity
import vn.lgg.mesplus.shared.service.PermissionService
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository

class ReviseTeamAssignmentProcessUseCaseTest {
  private val teamAssignmentRepository = mockk<TeamAssignmentRepository>()
  private val purchaseOrderRepository = mockk<PurchaseOrderRepository>()
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val permissionService = mockk<PermissionService>()
  private val eventPublisher = mockk<DomainEventPublisher>()
  private val actor = Actor("actor-1", "Planner", "planner", "", emptyList(), emptySet())

  private val useCase =
    ReviseTeamAssignmentProcessUseCase(
      teamAssignmentRepository = teamAssignmentRepository,
      purchaseOrderRepository = purchaseOrderRepository,
      orgUnitRepository = orgUnitRepository,
      permissionService = permissionService,
      eventPublisher = eventPublisher,
      productionOrderRepository = mockk<ProductionOrderRepository>(relaxed = true),
    )

  private val team = Team("team-1", "Team 1", "factory-1", "factory-1", Operation("SEW"), true)

  @BeforeEach
  fun setUp() {
    every { orgUnitRepository.findById("team-1") } returns team
    justRun { permissionService.requirePermission(actor, any(), any()) }
    every { teamAssignmentRepository.save(any()) } answers { firstArg() }
    justRun { eventPublisher.publish(any<List<DomainEvent>>()) }
  }

  @Test
  fun `rejects delta when PO does not belong to buyer order`() {
    val assignment = createAssignment(listOf(SkuAllocation("po-1", Color("Red"), Size("M"), 10)))
    every { teamAssignmentRepository.findById("ta-1") } returns assignment
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      createPo("po-1", PurchaseOrderType.REGULAR),
    )

    val command = AdjustPurchaseOrderQuantityCommand(
      reason = "Adjust",
      deltas = listOf(
        PurchaseOrderQuantityDeltaCommand("po-unknown", Color("Red"), Size("M"), 5),
      ),
    )

    val ex = shouldThrow<IllegalArgumentException> {
      useCase.execute("ta-1", command, actor)
    }
    ex.message shouldBe "PO po-unknown không thuộc cùng BuyerOrder với phân công này"
    verify(exactly = 0) { teamAssignmentRepository.save(any()) }
  }

  @Test
  fun `rejects delta when PO type does not match LSX type`() {
    val assignment = createAssignment(listOf(SkuAllocation("po-1", Color("Red"), Size("M"), 10)))
    every { teamAssignmentRepository.findById("ta-1") } returns assignment
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      createPo("po-1", PurchaseOrderType.REGULAR),
      createPo("po-pos", PurchaseOrderType.POSITIVE),
    )

    val command = AdjustPurchaseOrderQuantityCommand(
      reason = "Adjust cross type",
      deltas = listOf(
        PurchaseOrderQuantityDeltaCommand("po-1", Color("Red"), Size("M"), -5),
        PurchaseOrderQuantityDeltaCommand("po-pos", Color("Red"), Size("M"), 5),
      ),
    )

    val ex = shouldThrow<IllegalArgumentException> {
      useCase.execute("ta-1", command, actor)
    }
    ex.message shouldBe "Chỉ được điều chỉnh sản lượng giữa các PO cùng loại"
    verify(exactly = 0) { teamAssignmentRepository.save(any()) }
  }

  @Test
  fun `successfully adjusts quantities between POs of the same LSX type`() {
    val assignment = createAssignment(
      listOf(
        SkuAllocation("po-1", Color("Red"), Size("M"), 10),
        SkuAllocation("po-2", Color("Red"), Size("M"), 10),
      ),
      needsAdjustment = true,
    )
    every { teamAssignmentRepository.findById("ta-1") } returns assignment
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      createPo("po-1", PurchaseOrderType.REGULAR),
      createPo("po-2", PurchaseOrderType.REGULAR),
    )

    val command = AdjustPurchaseOrderQuantityCommand(
      reason = "Balance line",
      deltas = listOf(
        PurchaseOrderQuantityDeltaCommand("po-1", Color("Red"), Size("M"), -2),
        PurchaseOrderQuantityDeltaCommand("po-2", Color("Red"), Size("M"), 2),
      ),
    )

    useCase.execute("ta-1", command, actor)

    verify(exactly = 1) { teamAssignmentRepository.save(assignment) }
    verify(exactly = 1) { eventPublisher.publish(any<List<DomainEvent>>()) }
  }

  private fun createAssignment(allocations: List<SkuAllocation>, needsAdjustment: Boolean = false) =
    TeamAssignment("ta-1").apply {
      val events = mutableListOf<DomainEvent>(
        TeamAssignmentCreated(
          assignmentId = "ta-1",
          productionOrderId = "lsx-1",
          buyerOrderId = "bo-1",
          teamId = "team-1",
          operation = Operation("SEW"),
          allocations = allocations,
          plannedStartDate = LocalDate.now().plusDays(1),
          plannedEndDate = LocalDate.now().plusDays(10),
          assignedAt = Instant.EPOCH,
          actor = actor.ref,
        ),
      )
      if (needsAdjustment) {
        events += ProgressReported(
          assignmentId = "ta-1",
          type = ReportType.INPUT,
          items = listOf(
            ReportItem("po-1", Color("Red"), Size("M"), 12),
            ReportItem("po-2", Color("Red"), Size("M"), 5),
          ),
          actor = actor.ref,
        )
        events += ProgressReported(
          assignmentId = "ta-1",
          type = ReportType.OUTPUT,
          items = listOf(
            ReportItem("po-1", Color("Red"), Size("M"), 12),
            ReportItem("po-2", Color("Red"), Size("M"), 5),
          ),
          actor = actor.ref,
        )
      }
      loadFromHistory(events)
    }

  private fun createPo(id: String, type: PurchaseOrderType) =
    PurchaseOrder(
      id = id,
      wfxId = "wfx-$id",
      code = id.uppercase(),
      destination = "US",
      deliveryDate = LocalDate.now(),
      skuQties = listOf(SkuQuantity(Color("Red"), Size("M"), 100)),
      buyerOrderId = "bo-1",
      type = type,
    )
}
