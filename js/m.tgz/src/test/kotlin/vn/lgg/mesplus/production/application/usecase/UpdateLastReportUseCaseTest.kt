package vn.lgg.mesplus.production.application.usecase

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.production.domain.event.LastReportUpdated
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.ReportType
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.PermissionService

class UpdateLastReportUseCaseTest {
  @Test
  fun `updates the last input report`() {
    val repository = mockk<TeamAssignmentRepository>()
    val permissionService = mockk<PermissionService>()
    val allocationQueryService = mockk<AllocationQueryService>()
    val publisher = mockk<DomainEventPublisher>(relaxed = true)
    val actor = Actor("actor-1", "Reporter", "reporter", "", emptyList(), emptySet())
    val reportedAt = Instant.parse("2026-07-15T08:00:00Z")
    val assignment = TeamAssignment("ta-1").apply {
      loadFromHistory(listOf(
        TeamAssignmentCreated("ta-1", "lsx-1", "bo-1", "team-1", Operation("CUT"),
          listOf(SkuAllocation("po-1", Color("RED"), Size("M"), 10)),
          LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 10), reportedAt.minusSeconds(60), actor.ref),
        ProgressReported("ta-1", ReportType.INPUT,
          listOf(ReportItem("po-1", Color("RED"), Size("M"), 1)), actor.ref, reportedAt),
      ))
    }
    every { repository.findById("ta-1") } returns assignment
    every { repository.save(any()) } answers { firstArg() }
    justRun { permissionService.requirePermission(actor, any(), any()) }
    justRun { allocationQueryService.requireWithinBuyerOrderQuantity("bo-1") }
    justRun { allocationQueryService.requireActive("lsx-1") }

    UpdateLastReportUseCase(repository, permissionService, allocationQueryService, publisher)
      .execute("ta-1", ReportCommand(ReportType.INPUT,
        listOf(ReportItemCommand("po-1", Color("RED"), Size("M"), 2))), actor)

    assignment.reports.last().type shouldBe ReportType.INPUT
    assignment.reports.last().items.single().quantity shouldBe 2
    assignment.changes.last()::class shouldBe LastReportUpdated::class
  }
}
