package vn.lgg.mesplus.iam.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Account
import vn.lgg.mesplus.iam.domain.repository.AccountRepository
import vn.lgg.mesplus.shared.model.Actor

class UpdateAccountAvatarUseCaseTest {
  private val repo = mockk<AccountRepository>(relaxed = true)
  private val actor = Actor("account-id", "Name", "username", "", emptyList(), emptySet())
  private val useCase = UpdateAccountAvatarUseCase(repo)

  @Test
  fun `sets and clears actor avatar without permissions or changing account credentials`() {
    val account = Account("account-id", "Name", "username", "hashed-password")
    every { repo.findById(account.id) } returns account

    useCase.execute(UpdateAccountAvatarCommand("/uploads/avatar.png"), actor)
    account.avatar shouldBe "/uploads/avatar.png"
    useCase.execute(UpdateAccountAvatarCommand(null), actor)
    account.avatar shouldBe null
    account.name shouldBe "Name"
    account.username shouldBe "username"
    account.password shouldBe "hashed-password"
    verify(exactly = 2) { repo.save(account) }
    verify(exactly = 2) { repo.findById(actor.id) }
  }

  @Test
  fun `rejects missing account`() {
    every { repo.findById(actor.id) } returns null

    shouldThrow<NoSuchElementException> {
      useCase.execute(UpdateAccountAvatarCommand("avatar"), actor)
    }
    verify(exactly = 0) { repo.save(any()) }
  }
}
