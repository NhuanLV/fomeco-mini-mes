package vn.lgg.mesplus.iam.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import java.util.UUID
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.util.IdGenerator
import vn.lgg.mesplus.iam.domain.model.Factory
import vn.lgg.mesplus.iam.domain.model.FactoryOperation
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.repository.FactoryOperationRepository
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

class TeamUseCaseTest {
  private val orgUnitRepo = mockk<OrgUnitRepository>()
  private val factoryOperationRepo = mockk<FactoryOperationRepository>()
  private val permissionService = mockk<PermissionService>()
  private val idGenerator = mockk<IdGenerator>()
  private val actor = Actor("actor-1", "Admin", "admin", "", emptyList(), emptySet())

  private val createUseCase = CreateTeamUseCase(orgUnitRepo, factoryOperationRepo, permissionService, idGenerator)
  private val updateUseCase = UpdateTeamUseCase(orgUnitRepo, factoryOperationRepo, permissionService)

  private val factory = Factory("factory-1", "Factory 1", "company-1", "", "company-1", emptyList(), true)

  @BeforeEach
  fun setUp() {
    justRun { permissionService.requirePermission(actor, listOf(Permission.MANAGE_ORG), any()) }
    every { orgUnitRepo.findById("factory-1") } returns factory
    every { orgUnitRepo.existsByCode(any()) } returns false
    every { orgUnitRepo.existsByCode(any(), any()) } returns false
    every { idGenerator.generateId() } returns UUID.fromString("11111111-1111-1111-1111-111111111111")
    justRun { orgUnitRepo.save(any()) }
  }

  @Test
  fun `create team only uses active mapping of factory`() {
    every { factoryOperationRepo.findByFactoryId("factory-1") } returns listOf(
      FactoryOperation("op-1", "company-1", "COMP-1", "factory-1", "CUT-1", "Cắt", isActive = true),
      FactoryOperation("op-2", "company-1", "COMP-1", "factory-1", "SEW-1", "May", isActive = false),
    )

    // CUT-1 is active -> succeeds
    createUseCase.execute(
      CreateTeamCommand("Tổ Cắt 1", "TEAM-CUT", "factory-1", "CUT-1", true),
      actor,
    )
    verify(exactly = 1) { orgUnitRepo.save(any()) }

    // SEW-1 is inactive -> throws
    val ex = shouldThrow<IllegalArgumentException> {
      createUseCase.execute(
        CreateTeamCommand("Tổ May 1", "TEAM-SEW", "factory-1", "SEW-1", true),
        actor,
      )
    }
    ex.message shouldBe "Công đoạn không thuộc xí nghiệp"
  }

  @Test
  fun `update team allows keeping current operation even if mapping is inactive`() {
    val team = Team(
      id = "team-1",
      name = "Tổ May 1",
      parentId = "factory-1",
      factoryId = "factory-1",
      operation = Operation("SEW-1"),
      isActive = true,
      code = "TEAM-1",
    )
    every { orgUnitRepo.findById("team-1") } returns team
    every { factoryOperationRepo.findByFactoryId("factory-1") } returns listOf(
      FactoryOperation("op-1", "company-1", "COMP-1", "factory-1", "CUT-1", "Cắt", isActive = true),
      FactoryOperation("op-2", "company-1", "COMP-1", "factory-1", "SEW-1", "May", isActive = false),
    )

    // Keeping current operation SEW-1 is allowed
    updateUseCase.execute(
      "team-1",
      UpdateTeamCommand("Tổ May 1 Mới", "TEAM-1", "SEW-1", true),
      actor,
    )
    team.name shouldBe "Tổ May 1 Mới"
    team.operation.name shouldBe "SEW-1"

    // Switching to inactive operation not matching current throws
    every { factoryOperationRepo.findByFactoryId("factory-1") } returns listOf(
      FactoryOperation("op-1", "company-1", "COMP-1", "factory-1", "CUT-1", "Cắt", isActive = true),
      FactoryOperation("op-2", "company-1", "COMP-1", "factory-1", "SEW-1", "May", isActive = false),
      FactoryOperation("op-3", "company-1", "COMP-1", "factory-1", "FIN-1", "Hoàn thiện", isActive = false),
    )
    val ex = shouldThrow<IllegalArgumentException> {
      updateUseCase.execute(
        "team-1",
        UpdateTeamCommand("Tổ May 1 Mới", "TEAM-1", "FIN-1", true),
        actor,
      )
    }
    ex.message shouldBe "Công đoạn không thuộc xí nghiệp"
  }
}
