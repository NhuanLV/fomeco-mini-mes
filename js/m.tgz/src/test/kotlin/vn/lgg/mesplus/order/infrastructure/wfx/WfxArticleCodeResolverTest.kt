package vn.lgg.mesplus.order.infrastructure.wfx

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.infrastructure.repository.WfxRepository
import vn.lgg.mesplus.shared.model.Operation

class WfxArticleCodeResolverTest {
  private val wfxRepository = mockk<WfxRepository>()
  private val resolver = WfxArticleCodeResolver(wfxRepository)

  @Test
  fun `resolves NPL from the canonical wfx article code`() {
    every { wfxRepository.findArticleByReference("NPL-001") } returns
      WfxRepository.ArticleInfo("NPL name", "M", "NPL-001-CODE")

    resolver.resolve("NPL-001") shouldBe ResolvedWfxArticle("NPL-001-CODE", "M")
  }

  @Test
  fun `explains the missing NPL reference in the error`() {
    every { wfxRepository.findArticleByReference("544006660") } returns null

    shouldThrow<IllegalArgumentException> {
      resolver.resolve("544006660")
    }.message shouldBe
      "Không tìm thấy ArticleCode trong wfx_articles cho NPL có id: '544006660'"
  }

  @Test
  fun `includes the NPL name and reference in the error`() {
    every { wfxRepository.findArticleByReference("544006660") } returns null

    shouldThrow<IllegalArgumentException> {
      resolver.resolve("544006660", "FB27-.-Semi-Synthetic-Cotton")
    }.message shouldBe
      "Không tìm thấy ArticleCode trong wfx_articles cho NPL 'FB27-.-Semi-Synthetic-Cotton', " +
      "id: '544006660'"
  }

  @Test
  fun `resolves finished product directly from buyer order article code`() {
    resolver.resolveFinishedProduct(" LGG11BSDSGWWN2N1J112 ") shouldBe
      ResolvedWfxArticle("LGG11BSDSGWWN2N1J112", "PCS")

    verify(exactly = 0) { wfxRepository.findArticleByReference(any()) }
  }

  @Test
  fun `rejects a buyer order without finished product article code`() {
    shouldThrow<IllegalArgumentException> {
      resolver.resolveFinishedProduct(" ")
    }.message shouldBe "BuyerOrder chưa có mã article thành phẩm từ WFX"
  }

  @Test
  fun `composes BTP code from base article and outputItemSuffix`() {
    resolver.resolveBtp("LGG11BSDSGWWN2N1J112", Operation("CUT-1"), "btpcat") shouldBe
      ResolvedWfxArticle("LGG11BSDSGWWN2N1J112btpcat", "PCS")

    verify(exactly = 0) { wfxRepository.findArticleByReference(any()) }
  }

  @Test
  fun `composes BTP code from source operation label and outputItemSuffix`() {
    resolver.resolveBtpFromLabel("LGG11BSDSGWWN2N1J112", "BTP CUT-1", "btpcat") shouldBe
      ResolvedWfxArticle("LGG11BSDSGWWN2N1J112btpcat", "PCS")
  }

  @Test
  fun `rejects BTP when outputItemSuffix is missing or blank`() {
    shouldThrow<IllegalArgumentException> {
      resolver.resolveBtp("LGG11BSDSGWWN2N1J112", Operation("CUT-1"), null)
    }.message shouldBe
      "Không tìm thấy hậu tố BTP (outputItemSuffix) cho công đoạn CUT-1 trong Routing của đơn hàng"

    shouldThrow<IllegalArgumentException> {
      resolver.resolveBtp("LGG11BSDSGWWN2N1J112", Operation("CUT-1"), "  ")
    }.message shouldBe
      "Không tìm thấy hậu tố BTP (outputItemSuffix) cho công đoạn CUT-1 trong Routing của đơn hàng"
  }
}
