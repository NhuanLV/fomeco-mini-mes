package vn.lgg.mesplus.inventory.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import org.springframework.security.access.AccessDeniedException
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.kotest.matchers.maps.shouldContainExactly
import io.mockk.every
import io.mockk.mockk
import java.math.BigDecimal
import java.time.Instant
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestAssignmentInitialized
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestAssignmentInitialized.AssignmentItem
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestCreated
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestMaterialReceived
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestMaterialReceived.ReceivedItem
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestRejected
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestUpdated
import vn.lgg.mesplus.inventory.domain.model.returnrequest.ReturnRequest
import vn.lgg.mesplus.inventory.domain.model.returnrequest.ReturnRequestAssignment
import vn.lgg.mesplus.inventory.domain.model.returnrequest.ReturnRequestItem
import vn.lgg.mesplus.inventory.domain.model.returnrequest.ReturnRequestStatus
import vn.lgg.mesplus.inventory.domain.repository.ReturnRequestAssignmentRepository
import vn.lgg.mesplus.inventory.domain.repository.ReturnRequestRepository
import vn.lgg.mesplus.inventory.infrastructure.repository.ReturnRequestViewRepository
import vn.lgg.mesplus.inventory.presentation.viewmodel.ReturnRequestDetailVm
import vn.lgg.mesplus.inventory.presentation.viewmodel.ReturnRequestItemVm
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

class ReturnRequestHistoryQueryServiceTest {
  private val requestRepository = mockk<ReturnRequestRepository>()
  private val assignmentRepository = mockk<ReturnRequestAssignmentRepository>()
  private val viewRepository = mockk<ReturnRequestViewRepository>()
  private val permissionService = mockk<PermissionService>()
  private val queryService = mockk<ReturnRequestQueryService>()
  private val service =
    ReturnRequestHistoryQueryService(
      requestRepository,
      assignmentRepository,
      viewRepository,
      permissionService,
      queryService,
    )
  private val actor = Actor("actor-1", "Planner", "planner", "", emptyList(), emptySet())
  private val actorRef = ActorRef(actor.id, actor.name)
  private val createdAt = Instant.parse("2026-02-01T00:00:00Z")
  private val rejectedAt = Instant.parse("2026-02-02T00:00:00Z")
  private val updatedAt = Instant.parse("2026-02-03T00:00:00Z")

  @Test
  fun `maps receiver revision delta and returns newest event first`() {
    every { queryService.hasFullAccess(actor, any(), any()) } answers { secondArg<String>() == actor.id }
    val request =
      ReturnRequest("request-1").apply {
        loadFromHistory(
          listOf(
            ReturnRequestCreated(
              returnRequestId = "request-1",
              teamAssignmentId = "assignment-1",
              items = listOf(item("5")),
              actor = actorRef,
              occurredAt = createdAt,
            ),
            ReturnRequestRejected(
              returnRequestId = "request-1",
              reason = "adjust",
              actor = actorRef,
              occurredAt = rejectedAt,
            ),
            ReturnRequestUpdated(
              returnRequestId = "request-1",
              newItems = listOf(item("8")),
              actor = actorRef,
              occurredAt = updatedAt,
            ),
          ),
        )
      }
    every { viewRepository.findById("request-1") } returns view()
    every { requestRepository.findById("request-1") } returns request
    every { assignmentRepository.findAllByReturnRequestId("request-1") } returns emptyList()

    val history = service.getHistory("request-1", actor)

    history.map { it.type } shouldContainExactly
      listOf("ReturnRequestRevised", "ReturnRequestRejected", "ReturnRequestCreated")
    history.first().detail.shouldContainExactly(
      mapOf("MAT-1 / RED / M -> Warehouse" to "5 → 8 (+3) (kg)"),
    )
    history.last().detail.shouldContainExactly(
      mapOf("MAT-1 / RED / M -> Warehouse" to "5 (kg)"),
    )
  }

  @Test
  fun `limits assignment history to permitted receiver units`() {
    every { queryService.hasFullAccess(actor, any(), any()) } answers { secondArg<String>() == actor.id }
    val request =
      ReturnRequest("request-1").apply {
        loadFromHistory(
          listOf(
            ReturnRequestCreated(
              returnRequestId = "request-1",
              teamAssignmentId = "assignment-1",
              items = listOf(item("5"), item("9").copy(receiverId = "warehouse-2")),
              actor = actorRef,
              occurredAt = createdAt,
            ),
          ),
        )
      }
    every { viewRepository.findById("request-1") } returns view(createdById = "other")
    every { requestRepository.findById("request-1") } returns request
    every { permissionService.lookupUnit(actor, Permission.CREATE_REQUEST) } returns emptyList()
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_REQUEST) } returns emptyList()
    every { permissionService.lookupUnit(actor, Permission.RECEIVE_REQUEST) } returns
      listOf("warehouse-1")
    every { assignmentRepository.findAllByReturnRequestId("request-1") } returns
      listOf(assignment("warehouse-1", "5"), assignment("warehouse-2", "9"))

    val history = service.getHistory("request-1", actor)
    history.first { it.type == "ReturnRequestCreated" }.detail.size shouldBe 1

    history.filter { it.type == "ReturnRequestMaterialReceived" }
      .single()
      .detail
      .shouldContainExactly(mapOf("MAT-1 / RED / M -> Warehouse" to "5 (kg)"))
  }

  @Test
  fun `unrelated receiver cannot read request history`() {
    every { viewRepository.findById("request-1") } returns view(createdById = "other")
    every { queryService.hasFullAccess(actor, any(), any()) } returns false
    every { permissionService.lookupUnit(actor, Permission.RECEIVE_REQUEST) } returns listOf("warehouse-2")
    shouldThrow<AccessDeniedException> { service.getHistory("request-1", actor) }
  }

  private fun item(quantity: String) =
    ReturnRequestItem(
      article = "MAT-1",
      color = "RED",
      size = "M",
      uom = "kg",
      quantity = BigDecimal(quantity),
      receiverId = "warehouse-1",
    )

  private fun assignment(receiverId: String, quantity: String) =
    ReturnRequestAssignment("request-1", receiverId).apply {
      loadFromHistory(
        listOf(
          ReturnRequestAssignmentInitialized(
            "request-1",
            receiverId,
            listOf(AssignmentItem("MAT-1", "RED", "M", "kg", BigDecimal(quantity))),
            actorRef,
          ),
          ReturnRequestMaterialReceived(
            "request-1",
            receiverId,
            listOf(ReceivedItem("MAT-1", "RED", "M", BigDecimal(quantity))),
            actorRef,
          ),
        ),
      )
    }

  private fun view(createdById: String = actor.id) =
    ReturnRequestDetailVm(
      id = "request-1",
      teamAssignmentId = "assignment-1",
      status = ReturnRequestStatus.PENDING_APPROVAL,
      items =
        listOf(
          ReturnRequestItemVm(
            article = "MAT-1",
            color = "RED",
            size = "M",
            uom = "kg",
            quantity = BigDecimal("8"),
            receiverId = "warehouse-1",
            receiverName = "Warehouse",
          ),
        ),
      rejectReason = null,
      createdAt = createdAt,
      createdById = createdById,
      createdByName = actor.name,
    )
}
