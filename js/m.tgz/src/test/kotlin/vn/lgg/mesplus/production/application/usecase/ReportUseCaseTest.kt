package vn.lgg.mesplus.production.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.application.usecase.GetMaterialInventoryBalanceUseCase
import vn.lgg.mesplus.inventory.application.usecase.RecordBtpProducedUseCase
import vn.lgg.mesplus.inventory.presentation.viewmodel.MaterialInventoryBalanceVm
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.ReportType
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.model.TeamMaterial
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.production.domain.repository.TeamMaterialRepository
import vn.lgg.mesplus.production.domain.service.BomCalculationService
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Material
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.OrderBreakdownItem
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.MaterialSku
import vn.lgg.mesplus.shared.service.PermissionService

class ReportUseCaseTest {
  private val repository = mockk<TeamAssignmentRepository>()
  private val teamMaterialRepository = mockk<TeamMaterialRepository>()
  private val permissionService = mockk<PermissionService>()
  private val allocationQueryService = mockk<AllocationQueryService>()
  private val eventPublisher = mockk<DomainEventPublisher>()
  private val bomCalculationService = mockk<BomCalculationService>()
  private val inventoryUseCase = mockk<GetMaterialInventoryBalanceUseCase>()
  private val reportGrnSyncService = mockk<ReportGrnSyncService>()
  private val recordBtpInventory = mockk<RecordBtpProducedUseCase>(relaxed = true)
  private val actor = Actor("actor-1", "Reporter", "reporter", "", emptyList(), emptySet())
  private val useCase =
    ReportUseCase(
      repository,
      teamMaterialRepository,
      permissionService,
      allocationQueryService,
      eventPublisher,
      bomCalculationService,
      inventoryUseCase,
      reportGrnSyncService,
      recordBtpInventory,
    )

  @BeforeEach
  fun setUp() {
    every { repository.findById("ta-1") } returns assignment()
    every { teamMaterialRepository.findByTeamAssignmentId("ta-1") } returns emptyList()
    justRun { permissionService.requirePermission(actor, any(), any()) }
    justRun { allocationQueryService.requireWithinBuyerOrderQuantity("bo-1") }
    justRun { allocationQueryService.requireActive("lsx-1") }
    every { repository.save(any()) } answers { firstArg() }
    justRun { eventPublisher.publish(any<List<DomainEvent>>()) }
    every { reportGrnSyncService.regularItems(any(), any()) } returns emptyList()
    justRun { reportGrnSyncService.requireNoActiveReport(any()) }
    justRun { reportGrnSyncService.stageReport(any(), any(), any(), any()) }
  }

  @Test
  fun `input report saves and publishes without checking inventory`() {
    every { repository.findById("ta-1") } returns assignment(previousInput = 10)

    useCase.execute("ta-1", command(ReportType.INPUT, 1), actor)

    verify(exactly = 1) { repository.save(any()) }
    verify(exactly = 1) { eventPublisher.publish(any<List<DomainEvent>>()) }
    verify(exactly = 0) { reportGrnSyncService.stageReport(any(), any(), any(), any()) }
    verify(exactly = 0) { bomCalculationService.calculateForItems(any(), any()) }
    verify(exactly = 0) { inventoryUseCase.execute(any()) }
  }

  @Test
  fun `output report sends cumulative quantity to bom calculation`() {
    every { repository.findById("ta-1") } returns assignment(previousInput = 10)
    val items = slot<List<OrderBreakdownItem>>()
    every { bomCalculationService.calculateForItems(any(), capture(items)) } returns requirements()
    every { inventoryUseCase.execute("ta-1") } returns listOf(balance("5"))

    useCase.execute("ta-1", command(ReportType.OUTPUT, 3), actor)

    items.captured.single().quantity shouldBe 3
    verify(exactly = 1) { repository.save(any()) }
    verify(exactly = 0) { reportGrnSyncService.stageReport(any(), any(), any(), any()) }
  }

  @Test
  fun `output report stages GRN without committing progress`() {
    every { repository.findById("ta-1") } returns assignment(previousInput = 10)
    every { reportGrnSyncService.regularItems(any(), any()) } answers { secondArg() }
    every { bomCalculationService.calculateForItems(any(), any()) } returns requirements()
    every { inventoryUseCase.execute("ta-1") } returns listOf(balance("5"))

    useCase.execute("ta-1", command(ReportType.OUTPUT, 1), actor)

    verify(exactly = 1) { reportGrnSyncService.stageReport(any(), any(), actor.ref, any()) }
    verifyNoMutation()
  }

  @Test
  fun `mixed output commits positive progress and stages only regular quantities`() {
    val assignment = assignment(previousInput = 10, mixed = true)
    every { repository.findById("ta-1") } returns assignment
    every { reportGrnSyncService.regularItems(any(), any()) } answers {
      secondArg<List<ReportItem>>().filter { it.purchaseOrderId == "po-1" }
    }
    every { bomCalculationService.calculateForItems(any(), any()) } returns requirements()
    every { inventoryUseCase.execute("ta-1") } returns listOf(balance("5"))
    val staged = slot<List<ReportItem>>()
    val stagedAt = slot<Instant>()
    justRun { reportGrnSyncService.stageReport(any(), capture(staged), actor.ref, capture(stagedAt)) }

    useCase.execute(
      "ta-1",
      ReportCommand(ReportType.OUTPUT, listOf(
        ReportItemCommand("po-1", Color("Red"), Size("S"), 3),
        ReportItemCommand("po-positive", Color("Red"), Size("S"), 2),
      )),
      actor,
    )

    assignment.rawOutputReportedTotals.associate { it.purchaseOrderId to it.quantity } shouldBe
      mapOf("po-positive" to 2)
    staged.captured shouldBe listOf(ReportItem("po-1", Color("Red"), Size("S"), 3))
    verify(exactly = 1) {
      recordBtpInventory.execute(assignment, listOf(ReportItem("po-positive", Color("Red"), Size("S"), 2)), stagedAt.captured, actor.ref, "POSITIVE")
    }
  }

  @Test
  fun `active GRN blocks a new regular only output report`() {
    every { repository.findById("ta-1") } returns assignment(previousInput = 10)
    every { reportGrnSyncService.regularItems(any(), any()) } answers { secondArg() }
    every { bomCalculationService.calculateForItems(any(), any()) } returns requirements()
    every { inventoryUseCase.execute("ta-1") } returns listOf(balance("5"))
    every { reportGrnSyncService.requireNoActiveReport("ta-1") } throws
      IllegalStateException("Phiếu nhập kho đang chờ xử lý")

    shouldThrow<IllegalStateException> {
      useCase.execute("ta-1", command(ReportType.OUTPUT, 1), actor)
    }

    verifyNoMutation()
    verify(exactly = 0) { reportGrnSyncService.stageReport(any(), any(), any(), any()) }
    verify(exactly = 0) { recordBtpInventory.execute(any(), any(), any(), any(), any()) }
  }

  @Test
  fun `output report validates domain limits before staging GRN`() {
    every { reportGrnSyncService.regularItems(any(), any()) } answers { secondArg() }
    every { bomCalculationService.calculateForItems(any(), any()) } returns requirements()
    every { inventoryUseCase.execute("ta-1") } returns listOf(balance("5"))

    shouldThrow<IllegalStateException> {
      useCase.execute("ta-1", command(ReportType.OUTPUT, 1), actor)
    }

    verify(exactly = 0) { reportGrnSyncService.stageReport(any(), any(), any(), any()) }
    verifyNoMutation()
  }

  @Test
  fun `output report rejects missing bom without side effects`() {
    every { repository.findById("ta-1") } returns assignment(previousInput = 10)
    every { bomCalculationService.calculateForItems(any(), any()) } returns null

    val ex = shouldThrow<IllegalArgumentException> {
      useCase.execute("ta-1", command(ReportType.OUTPUT, 1), actor)
    }
    ex.message shouldBe "Không thể báo Ra chuyền: Lệnh sản xuất chưa được cấu hình định mức NPL (BOM)."

    verifyNoMutation()
    verify(exactly = 0) { inventoryUseCase.execute(any()) }
  }

  @Test
  fun `output report accepts inventory exactly equal to grouped requirement`() {
    every { repository.findById("ta-1") } returns assignment(previousInput = 10)
    every { bomCalculationService.calculateForItems(any(), any()) } returns requirements()
    every { inventoryUseCase.execute("ta-1") } returns listOf(balance("5"))

    useCase.execute("ta-1", command(ReportType.OUTPUT, 1), actor)

    verify(exactly = 1) { repository.save(any()) }
  }

  @Test
  fun `output report rejects insufficient inventory without side effects`() {
    every { repository.findById("ta-1") } returns assignment(previousInput = 10)
    every { bomCalculationService.calculateForItems(any(), any()) } returns requirements()
    every { inventoryUseCase.execute("ta-1") } returns listOf(balance("4.99"))

    val ex = shouldThrow<InsufficientMaterialsException> {
      useCase.execute("ta-1", command(ReportType.OUTPUT, 1), actor)
    }
    ex.message shouldBe "Không đủ NPL để báo ra chuyền"
    ex.missingMaterials.single().apply {
      material shouldBe "MAT-1"
      required shouldBe BigDecimal("5")
      available shouldBe BigDecimal("4.99")
      shortage shouldBe BigDecimal("0.01")
      uom shouldBe "M"
    }

    verifyNoMutation()
  }

  @Test
  fun `output report allows a missing non-required material`() {
    every { repository.findById("ta-1") } returns assignment(previousInput = 10)
    every { teamMaterialRepository.findByTeamAssignmentId("ta-1") } returns
      listOf(
        TeamMaterial(
          id = "tm-1",
          teamAssignmentId = "ta-1",
          material = Material(name = "MAT-1", category = "Fabric", uom = "M"),
          isRequired = false,
          sizeDeps = emptyList(),
          colorDeps = emptyList(),
          lastUpdatedAt = Instant.now(),
          lastUpdatedBy = ActorRef("actor-1", "Reporter"),
        ),
      )
    every { bomCalculationService.calculateForItems(any(), any()) } returns requirements()
    every { inventoryUseCase.execute("ta-1") } returns listOf(balance("0"))

    useCase.execute("ta-1", command(ReportType.OUTPUT, 1), actor)

    verify(exactly = 1) { repository.save(any()) }
  }

  @Test
  fun `duplicate inventory keys keep the last balance`() {
    every { repository.findById("ta-1") } returns assignment(previousInput = 10)
    every { bomCalculationService.calculateForItems(any(), any()) } returns requirements()
    every { inventoryUseCase.execute("ta-1") } returns listOf(balance("5"), balance("0"))

    shouldThrow<IllegalArgumentException> {
      useCase.execute("ta-1", command(ReportType.OUTPUT, 1), actor)
    }

    verifyNoMutation()
  }

  @Test
  fun `output report rejects cutting operation when technical team has not set consumption`() {
    val cutAssignment = assignment(previousInput = 10).apply {
      val events = mutableListOf<DomainEvent>(
        TeamAssignmentCreated(
          assignmentId = "ta-1",
          productionOrderId = "lsx-1",
          buyerOrderId = "bo-1",
          teamId = "team-1",
          operation = Operation.CUT,
          allocations = listOf(SkuAllocation("po-1", Color("Red"), Size("S"), 10)),
          plannedStartDate = LocalDate.of(2026, 1, 1),
          plannedEndDate = LocalDate.of(2026, 1, 10),
          assignedAt = Instant.parse("2026-01-01T00:00:00Z"),
          actor = ActorRef("actor-1", "Reporter"),
        )
      )
      loadFromHistory(events)
    }
    every { repository.findById("ta-1") } returns cutAssignment
    every { teamMaterialRepository.findByTeamAssignmentId("ta-1") } returns emptyList()

    val ex = shouldThrow<IllegalArgumentException> {
      useCase.execute("ta-1", command(ReportType.OUTPUT, 1), actor)
    }
    ex.message shouldBe "Không thể báo ra chuyền do tổ kỹ thuật chưa cập nhật định mức."

    verifyNoMutation()
  }

  private fun requirements() =
    linkedMapOf(
      MaterialSku("po-1", "MAT-1", Color("Black"), Size("M")) to BigDecimal("2"),
      MaterialSku("po-2", "MAT-1", Color("Black"), Size("M")) to BigDecimal("3"),
    )

  private fun balance(quantity: String) =
    MaterialInventoryBalanceVm(
      article = "MAT-1",
      color = "Black",
      size = "M",
      uom = "M",
      totalReceived = BigDecimal(quantity),
      totalIssued = BigDecimal.ZERO,
      balance = BigDecimal(quantity),
    )

  private fun command(type: ReportType, quantity: Int) =
    ReportCommand(
      type = type,
      items = listOf(ReportItemCommand("po-1", Color("Red"), Size("S"), quantity)),
    )

  private fun assignment(previousInput: Int = 0, mixed: Boolean = false) =
    TeamAssignment("ta-1").apply {
      val events =
        mutableListOf<DomainEvent>(
          TeamAssignmentCreated(
            assignmentId = "ta-1",
            productionOrderId = "lsx-1",
            buyerOrderId = "bo-1",
            teamId = "team-1",
            operation = Operation("Sew"),
            allocations = listOf(SkuAllocation("po-1", Color("Red"), Size("S"), 10)) +
              if (mixed) listOf(SkuAllocation("po-positive", Color("Red"), Size("S"), 10)) else emptyList(),
            plannedStartDate = LocalDate.of(2026, 1, 1),
            plannedEndDate = LocalDate.of(2026, 1, 10),
            assignedAt = Instant.parse("2026-01-01T00:00:00Z"),
            actor = ActorRef("actor-1", "Reporter"),
          )
        )
      if (previousInput > 0) {
        events +=
          ProgressReported(
            assignmentId = "ta-1",
            type = ReportType.INPUT,
            items = listOf(ReportItem("po-1", Color("Red"), Size("S"), previousInput)) +
              if (mixed) listOf(ReportItem("po-positive", Color("Red"), Size("S"), previousInput)) else emptyList(),
            actor = ActorRef("actor-1", "Reporter"),
          )
      }
      loadFromHistory(events)
    }

  private fun verifyNoMutation() {
    verify(exactly = 0) { repository.save(any()) }
    verify(exactly = 0) { eventPublisher.publish(any<List<DomainEvent>>()) }
  }
}
