package vn.lgg.mesplus.app.security

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import jakarta.servlet.http.HttpServletRequest
import jakarta.servlet.http.HttpServletResponse
import jakarta.servlet.http.HttpSession
import java.io.PrintWriter
import java.io.StringWriter
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Test
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.web.context.HttpSessionSecurityContextRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.MembershipInfo

class RefreshActorFilterTest {
  private val service = mockk<AccountDetailService>()
  private val filter = RefreshActorFilter(service)
  private val request = mockk<HttpServletRequest>(relaxed = true)
  private val response = mockk<HttpServletResponse>(relaxed = true)
  private val session = mockk<HttpSession>(relaxed = true)
  private val previous = Actor("account", "User", "old-name", "", listOf(MembershipInfo("old-unit", setOf("role"))), setOf("READ"))

  @AfterEach
  fun tearDown() = SecurityContextHolder.clearContext()

  private fun authenticate() {
    SecurityContextHolder.getContext().authentication =
      UsernamePasswordAuthenticationToken.authenticated(previous, null, previous.authorities)
    every { request.getSession(any()) } returns session
    every { request.getAttribute(any()) } returns null
    every { request.dispatcherType } returns jakarta.servlet.DispatcherType.REQUEST
  }

  @Test
  fun `updates membership before downstream authorization and persists context without logout`() {
    authenticate()
    val current = Actor("account", "User", "new-name", "", listOf(MembershipInfo("new-unit", setOf("role"))), setOf("READ"))
    every { service.loadActorById("account") } returns current
    var called = false

    filter.doFilter(request, response) { _, _ ->
      called = true
      SecurityContextHolder.getContext().authentication?.principal shouldBe current
    }

    called shouldBe true
    verify { response.setHeader("X-Permissions-Changed", "true") }
    verify { session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, SecurityContextHolder.getContext()) }
    verify(exactly = 0) { session.invalidate() }
  }

  @Test
  fun `deleted account cannot reach downstream handler`() {
    authenticate()
    every { service.loadActorById("account") } returns null
    every { response.writer } returns PrintWriter(StringWriter())

    filter.doFilter(request, response) { _, _ -> error("Deleted account reached handler") }

    verify { response.status = 401 }
    verify { session.invalidate() }
    SecurityContextHolder.getContext().authentication shouldBe null
  }
}
