package vn.lgg.mesplus.production.application.service

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.collections.shouldHaveSize
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.util.UUID
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import org.springframework.transaction.support.TransactionSynchronizationManager
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.production.application.usecase.CancelProductionOrderUseCase
import vn.lgg.mesplus.production.application.usecase.ProductionOrderCancellationExecutor
import vn.lgg.mesplus.production.application.usecase.UpdateBuyerOrderStatusUseCase
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.service.PermissionService
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.Factory
import vn.lgg.mesplus.iam.domain.model.FactoryOperation
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.model.Warehouse
import vn.lgg.mesplus.iam.domain.repository.FactoryOperationRepository
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderRouting
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.Routing
import vn.lgg.mesplus.order.domain.model.RoutingProcess
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.repository.RoutingRepository
import vn.lgg.mesplus.order.infrastructure.repository.WfxRepository
import vn.lgg.mesplus.order.infrastructure.wfx.WfxSyncException
import vn.lgg.mesplus.order.infrastructure.wfx.client.WfxClient
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.CreateFppoRequest
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.CreateFppoNumberDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.CreateFppoResponse
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.CreateFppoResponseData
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.CreateFppoSuccessDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.FppoDetailDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.ReleaseFpoResponse
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.ReleaseFppoErrorDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.ReleaseFppoResponse
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.ReleaseFppoResponseData
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.ReleaseFppoSuccessDto
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.ActorRef

class FppoSyncServiceTest {
  @Test
  fun `cancelling mixed POs recomputes exact WFX payload then checks FPPO for last regular PO`() {
    arrangeCancellationScenario()
    val requests = mutableListOf<CreateFppoRequest>()
    every { wfxClient.createFppo(capture(requests)) } answers {
      // The target must be excluded before its MES status becomes CANCELLED.
      productionOrderRepository.findById("target")!!.status shouldBe ProductionOrderStatus.IN_PROGRESS
      successResponse()
    }

    cancelThroughUseCase("target").syncStatus shouldBe ProductionOrderActivitySyncStatus.SUCCESS
    requests shouldHaveSize 1
    assertRemainingPayload(requests.single(), 50)
    productionOrderRepository.findById("target")!!.status shouldBe ProductionOrderStatus.CANCELLED
    verify(exactly = 0) { wfxClient.checkFppoCancellation(any(), any()) }

    every { wfxClient.createFppo(capture(requests)) } returns successResponse()
    cancelThroughUseCase("remaining").syncStatus shouldBe ProductionOrderActivitySyncStatus.SUCCESS
    requests shouldHaveSize 2
    assertRemainingPayload(requests.last(), 20)

    every { wfxClient.checkFppoCancellation("BO-WFX-1", "MAIN") } returns "Đã kiểm tra WFX: tất cả FPPO đã Cancelled"
    cancelThroughUseCase("completed").syncStatus shouldBe ProductionOrderActivitySyncStatus.SUCCESS
    requests shouldHaveSize 2
    verify(exactly = 1) { wfxClient.checkFppoCancellation("BO-WFX-1", "MAIN") }
    verify(exactly = 0) { wfxClient.releaseFpo(any()) }
    verify(exactly = 0) { wfxClient.releaseFppo(any()) }
  }

  @Test
  fun `cancelling positive only PO never sends WFX even with regular siblings`() {
    arrangeCancellationScenario()

    cancelThroughUseCase("positive").syncStatus shouldBe ProductionOrderActivitySyncStatus.NOT_APPLICABLE

    productionOrderRepository.findById("positive")!!.status shouldBe ProductionOrderStatus.CANCELLED
    productionOrderRepository.findById("target")!!.status shouldBe ProductionOrderStatus.IN_PROGRESS
    verify(exactly = 0) { wfxClient.createFppo(any()) }
    verify(exactly = 0) { wfxClient.checkFppoCancellation(any(), any()) }
    verify(exactly = 0) { wfxClient.getFppoDetails(any()) }
  }

  @Test
  fun `release failure after SaveData keeps the mixed PO active`() {
    arrangeCancellationScenario()
    val request = slot<CreateFppoRequest>()
    every { wfxClient.createFppo(capture(request)) } returns successResponse()
    every { releaseRecordService.isFpoReleased("1495-24") } returns false
    every { wfxClient.releaseFpo("1495-24") } returns ReleaseFpoResponse(status = "Fail", errorMessage = "Release rejected")

    cancelThroughUseCase("target").syncStatus shouldBe ProductionOrderActivitySyncStatus.FAILED

    assertRemainingPayload(request.captured, 50)
    productionOrderRepository.findById("target")!!.status shouldBe ProductionOrderStatus.IN_PROGRESS
    verify(exactly = 1) { wfxClient.releaseFpo("1495-24") }
    verify(exactly = 0) { wfxClient.releaseFppo(any()) }
  }

  @Test
  fun `last regular PO stays active when FPPO is not cancelled despite positive and other-main siblings`() {
    arrangeCancellationScenario()
    listOf("target", "remaining").forEach {
      productionOrderRepository.findById(it)!!.cancel("Đã hủy trước", ActorRef("actor", "Planner"))
    }
    every { wfxClient.checkFppoCancellation("BO-WFX-1", "MAIN") } throws IllegalStateException("FPPO 8265 (Completed)")

    val failed = cancelThroughUseCase("completed")

    failed.syncStatus shouldBe ProductionOrderActivitySyncStatus.FAILED
    failed.syncMessage shouldBe "FPPO 8265 (Completed)"
    productionOrderRepository.findById("completed")!!.status shouldBe ProductionOrderStatus.COMPLETED
    verify(exactly = 1) { wfxClient.checkFppoCancellation("BO-WFX-1", "MAIN") }
    verify(exactly = 0) { wfxClient.createFppo(any()) }
  }

  @Test
  fun `WFX rejects recomputed payload and cancellation fails without changing effective quantities`() {
    arrangeCancellationScenario()
    val requests = mutableListOf<CreateFppoRequest>()
    every { wfxClient.createFppo(capture(requests)) } throws WfxSyncException.business("WFX từ chối cập nhật")

    val failed = cancelThroughUseCase("target")

    failed.syncStatus shouldBe ProductionOrderActivitySyncStatus.FAILED
    failed.syncMessage!!.contains("WFX từ chối cập nhật") shouldBe true
    productionOrderRepository.findById("target")!!.status shouldBe ProductionOrderStatus.IN_PROGRESS
    requests shouldHaveSize 1
    assertRemainingPayload(requests.single(), 50)
    verify(exactly = 0) { wfxClient.getFppoDetails(any()) }
    verify(exactly = 0) { wfxClient.releaseFpo(any()) }
    verify(exactly = 0) { wfxClient.releaseFppo(any()) }

    every { wfxClient.createFppo(capture(requests)) } returns successResponse()
    service().syncFppo("bo-1", "MAIN")
    assertRemainingPayload(requests.last(), 60)
  }

  private fun assertRemainingPayload(request: CreateFppoRequest, quantity: Int) {
    request.data shouldHaveSize 4
    request.data.associate { (it.deliveryOcNum to it.processCode) to it.qty } shouldBe mapOf(
      ("PO-WFX-1" to "CUT-1") to quantity.toString(),
      ("PO-WFX-1" to "SEW-1") to quantity.toString(),
      ("PO-WFX-2" to "CUT-1") to (quantity * 2).toString(),
      ("PO-WFX-2" to "SEW-1") to (quantity * 2).toString(),
    )
    request.data.forEach {
      it.deliveryOrderCode shouldBe "BO-WFX-1"
      it.mainFactoryCode shouldBe "MAIN"
      it.mappedProcessCode shouldBe "CUT-1"
      it.colorCode shouldBe if (it.deliveryOcNum == "PO-WFX-1") "05" else "09"
      it.sizeCode shouldBe if (it.deliveryOcNum == "PO-WFX-1") "001US" else "002US"
      it.executionFactoryCode shouldBe if (it.processCode == "CUT-1") "EXEC-1" else "EXEC-2"
      it.wipDispatchSite shouldBe if (it.processCode == "CUT-1") "F1-NPL" else "F1-CUT-BTP"
      it.wipReceivingSite shouldBe if (it.processCode == "CUT-1") "F1-CUT-BTP" else "F2-SEW-BTP"
    }
  }

  private fun arrangeCancellationScenario() {
    arrangeMultiOperation(sameFactory = false)
    val date = LocalDate.of(2026, 8, 8)
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      PurchaseOrder("po-1", "PO-WFX-1", "PO-1", "FR", date, emptyList(), "bo-1"),
      PurchaseOrder("po-2", "PO-WFX-2", "PO-2", "FR", date, emptyList(), "bo-1"),
      PurchaseOrder("po-positive", null, "PO-DUONG", "FR", date, emptyList(), "bo-1", PurchaseOrderType.POSITIVE),
    )
    val quantities = mapOf("target" to 10, "completed" to 20, "remaining" to 30,
      "cancelled" to 1000, "other-main" to 2000, "positive" to 3000)
    val allAssignments = quantities.flatMap { (poId, quantity) ->
      val po = productionOrder(poId, if (poId == "other-main") "OTHER" else "MAIN", listOf("CUT-1", "SEW-1"))
      if (poId == "completed") po.status = ProductionOrderStatus.COMPLETED
      if (poId == "cancelled") po.cancel("Đã hủy trước", ActorRef("actor", "Planner"))
      every { productionOrderRepository.findById(poId) } returns po
      listOf("CUT-1" to "team-cut", "SEW-1" to "team-sew").map { (operation, team) ->
        val regular = if (poId == "positive") emptyList() else listOf(
          SkuAllocation("po-1", Color("Gray (05)"), Size("001US"), quantity),
          SkuAllocation("po-2", Color("Black (09)"), Size("002US"), quantity * 2),
        )
        assignment("$poId-$operation", poId, quantity, date, date.plusDays(5),
          operationCode = operation, teamId = team,
          allocations = regular + SkuAllocation("po-positive", Color("Gray (05)"), Size("001US"), 9000))
      }
    }
    every { assignmentRepository.findByBuyerOrderId("bo-1") } returns allAssignments
    every { assignmentRepository.findByProductionOrderId(any()) } answers {
      allAssignments.filter { it.productionOrderId == firstArg<String>() }
    }
  }

  // Real cancellation and aggregation; only persistence, async scheduling and WFX are mocked.
  private fun cancelThroughUseCase(poId: String): ProductionOrderActivity {
    val history = mockk<ProductionOrderActivityLog>()
    val rows = mutableListOf<ProductionOrderActivity>()
    every { history.findByProductionOrderId(poId) } answers { rows.reversed() }
    every { history.append(any()) } answers { rows.add(firstArg()) }
    every { history.updateSync(any()) } answers {
      val row = firstArg<ProductionOrderActivity>()
      rows[rows.indexOfFirst { it.id == row.id }] = row
    }
    every { productionOrderRepository.lockById(poId) } answers { productionOrderRepository.findById(poId) }
    every { productionOrderRepository.save(any()) } answers { firstArg() }
    every { buyerOrderRepository.lockById("bo-1") } answers { buyerOrderRepository.findById("bo-1") }
    val useCase = CancelProductionOrderUseCase(
      productionOrderRepository, buyerOrderRepository, assignmentRepository, purchaseOrderRepository,
      mockk<KanbanRepository> { every { countNotCancelled(any()) } returns 0 }, history,
      mockk<PermissionService>(relaxed = true), { UUID.randomUUID() }, service(), wfxClient,
      mockk<UpdateBuyerOrderStatusUseCase>(relaxed = true), mockk<DomainEventPublisher>(relaxed = true),
      mockk<ProductionOrderCancellationExecutor>(relaxed = true),
    )
    TransactionSynchronizationManager.initSynchronization()
    try {
      val activity = useCase.execute(poId, "Dừng sản xuất", Actor("actor", "Planner", "planner", "", emptyList(), emptySet()))
      if (activity.syncStatus == ProductionOrderActivitySyncStatus.PENDING) {
        ProductionOrderCancellationExecutor(useCase).execute(poId, activity.id)
      }
      return rows.last()
    } finally {
      TransactionSynchronizationManager.clearSynchronization()
    }
  }

  @Test
  fun `sync excludes the cancellation target before MES changes its status`() {
    arrange()
    service().syncFppo("bo-1", "MAIN", excludedProductionOrderId = "production-1")
    verify(exactly = 0) { wfxClient.createFppo(any()) }
  }

  @Test
  fun `future sync excludes permanently cancelled orders`() {
    arrange()
    val order = productionOrder("production-1", "MAIN", routing = listOf("CUT-1"))
    order.cancel("Dừng", ActorRef("actor", "Planner"))
    every { productionOrderRepository.findById("production-1") } returns order
    service().syncFppo("bo-1", "MAIN")
    verify(exactly = 0) { wfxClient.createFppo(any()) }
  }
  private val assignmentRepository = mockk<TeamAssignmentRepository>()
  private val productionOrderRepository = mockk<ProductionOrderRepository>()
  private val buyerOrderRepository = mockk<BuyerOrderRepository>()
  private val purchaseOrderRepository = mockk<PurchaseOrderRepository>()
  private val routingRepository = mockk<RoutingRepository>()
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val factoryOperationRepository = mockk<FactoryOperationRepository>()
  private val wfxRepository = mockk<WfxRepository>()
  private val wfxClient = mockk<WfxClient>()
  private val releaseRecordService = mockk<WfxReleaseRecordService>(relaxed = true)

  init {
    every { releaseRecordService.isFpoReleased(any()) } returns true
    every { releaseRecordService.findReleasedFppoNumbers(any()) } answers { firstArg<Collection<String>>().toSet() }
    every { wfxClient.getFppoDetails(any()) } returns listOf(
      FppoDetailDto(fppoNo = "8265", processCode = "CUT-1"),
      FppoDetailDto(fppoNo = "8266", processCode = "CUT-1"),
      FppoDetailDto(fppoNo = "8267", processCode = "SEW-1"),
    )
  }

  @Test
  fun `releases only new FPO and FPPO after create and records WFX success`() {
    arrange()
    every { wfxClient.createFppo(any()) } returns successResponse()
    every { releaseRecordService.isFpoReleased("1495-24") } returns false
    every { releaseRecordService.findReleasedFppoNumbers(any()) } returns emptySet()
    every { wfxClient.releaseFpo("1495-24") } returns ReleaseFpoResponse(status = "Success")
    every { wfxClient.releaseFppo(any()) } returns ReleaseFppoResponse(
      status = "Success",
      responseData = listOf(
        ReleaseFppoResponseData(
          successMessages = listOf(
            ReleaseFppoSuccessDto("1495-24", "CUT-1", "8265", "Success"),
          ),
        ),
      ),
    )

    service().syncFppo("bo-1", "MAIN")

    verify(exactly = 1) { wfxClient.releaseFpo("1495-24") }
    verify(exactly = 1) { wfxClient.releaseFppo(match { it.single().fppoNum == "8265" && it.single().processName == "CUT-1" }) }
    verify(exactly = 1) { releaseRecordService.markFpoReleased("1495-24", "bo-1", "MAIN") }
    verify(exactly = 1) {
      releaseRecordService.markFpposReleased(
        match {
          it.single() == WfxFppoRecord(
            "8265",
            "1495-24",
            "CUT-1",
          )
        },
      )
    }
  }

  @Test
  fun `uses FPO number from WFX success message when detail omits it`() {
    arrange()
    every { wfxClient.createFppo(any()) } returns successResponse(fpoFromMessage = true)

    service().syncFppo("bo-1", "MAIN")

    verify(exactly = 1) { releaseRecordService.isFpoReleased("1495-24") }
  }

  @Test
  fun `FPO failure aborts immediately before releasing FPPOs`() {
    arrange()
    every { wfxClient.createFppo(any()) } returns successResponse()
    every { releaseRecordService.isFpoReleased("1495-24") } returns false
    every { wfxClient.releaseFpo("1495-24") } returns ReleaseFpoResponse(
      status = "Fail",
      errorMessage = "FPO rejected",
    )

    shouldThrow<WfxSyncException> { service().syncFppo("bo-1", "MAIN") }

    verify(exactly = 0) { releaseRecordService.markFpoReleased(any(), any(), any()) }
    verify(exactly = 0) { wfxClient.releaseFppo(any()) }
  }

  @Test
  fun `FPPO failure preserves released FPO in database`() {
    arrange()
    every { wfxClient.createFppo(any()) } returns successResponse()
    every { releaseRecordService.isFpoReleased("1495-24") } returns false
    every { releaseRecordService.findReleasedFppoNumbers(any()) } returns emptySet()
    every { wfxClient.releaseFpo("1495-24") } returns ReleaseFpoResponse(status = "Success")
    every { wfxClient.releaseFppo(any()) } returns ReleaseFppoResponse(
      status = "Fail",
      errorMessage = "WFX error",
    )

    shouldThrow<WfxSyncException> { service().syncFppo("bo-1", "MAIN") }

    verify(exactly = 1) { releaseRecordService.markFpoReleased("1495-24", "bo-1", "MAIN") }
    verify(exactly = 0) { releaseRecordService.markFpposReleased(any()) }
  }

  @Test
  fun `records successful FPPO in partial failure and retries via create again`() {
    arrange()
    every { wfxClient.createFppo(any()) } returns successResponse(twoFppos = true)
    every { releaseRecordService.isFpoReleased("1495-24") } returns true
    every { releaseRecordService.findReleasedFppoNumbers(any()) } returnsMany listOf(
      emptySet(),
      setOf("8265"),
    )
    every { wfxClient.releaseFppo(any()) } returnsMany listOf(
      ReleaseFppoResponse(
        status = "Success",
        responseData = listOf(
          ReleaseFppoResponseData(
            successMessages = listOf(ReleaseFppoSuccessDto("1495-24", "CUT-1", "8265", "Success")),
            errorMessages = listOf(ReleaseFppoErrorDto("1495-24", "CUT-1", "8266", "WFX rejected")),
          ),
        ),
      ),
      ReleaseFppoResponse(
        status = "Success",
        responseData = listOf(
          ReleaseFppoResponseData(
            successMessages = listOf(ReleaseFppoSuccessDto("1495-24", "CUT-1", "8266", "Success")),
          ),
        ),
      ),
    )

    shouldThrow<WfxSyncException> { service().syncFppo("bo-1", "MAIN") }
    service().syncFppo("bo-1", "MAIN")

    verify(exactly = 2) { wfxClient.createFppo(any()) }
    verify(exactly = 1) { releaseRecordService.markFpposReleased(match { it.single().fppoNum == "8265" }) }
    verify(exactly = 1) { wfxClient.releaseFppo(match { it.size == 1 && it.single().fppoNum == "8266" }) }
  }

  @Test
  fun `aggregates matching production orders and skips non-positive groups`() {
    val request = slot<CreateFppoRequest>()
    arrange()
    every { wfxClient.createFppo(capture(request)) } returns successResponse()

    service().syncFppo(
      "bo-1",
      "MAIN",
      listOf(
        assignment(
          "ta-2",
          "production-2",
          20,
          LocalDate.of(2026, 8, 16),
          LocalDate.of(2026, 8, 22),
        ),
      ),
    )

    request.captured.data shouldHaveSize 1
    request.captured.data.single().apply {
      deliveryOrderCode shouldBe "BO-WFX-1"
      deliveryOcNum shouldBe "PO-WFX-1"
      destination shouldBe "France"
      buyerDeliveryDate shouldBe "8/8/2026"
      executionFactoryCode shouldBe "EXEC"
      processCode shouldBe "CUT-1"
      colorCode shouldBe "05"
      colorName shouldBe "Gray"
      sizeCode shouldBe "001US"
      qty shouldBe "30"
      planStartDate shouldBe "8/15/2026"
      planEndDate shouldBe "8/22/2026"
      mainFactoryCode shouldBe "MAIN"
      supplier shouldBe "Supplier WFX"
      mappedProcessCode shouldBe "CUT-1"
      wipDispatchSite shouldBe "LGGMAT"
      wipReceivingSite shouldBe "LGGCUT"
    }
  }

  @Test
  fun `CUT operation uses Site Code of current material dispatch warehouse and BTP receive warehouse`() {
    val request = slot<CreateFppoRequest>()
    arrange(cutDispatchSiteCode = "SITE-NPL-CUT", btpReceiveSiteCode = "SITE-BTP-CUT")
    every { wfxClient.createFppo(capture(request)) } returns successResponse()

    service().syncFppo("bo-1", "MAIN")

    request.captured.data.single().apply {
      processCode shouldBe "CUT-1"
      wipDispatchSite shouldBe "SITE-NPL-CUT"
      wipReceivingSite shouldBe "SITE-BTP-CUT"
    }
  }

  @Test
  fun `subsequent operation in same factory uses BTP receive warehouse of previous operation`() {
    val request = slot<CreateFppoRequest>()
    arrangeMultiOperation(sameFactory = true)
    every { wfxClient.createFppo(capture(request)) } returns successResponse()

    service().syncFppo("bo-1", "MAIN")

    request.captured.data shouldHaveSize 2
    val cutItem = request.captured.data.single { it.processCode == "CUT-1" }
    cutItem.wipDispatchSite shouldBe "F1-NPL"
    cutItem.wipReceivingSite shouldBe "F1-CUT-BTP"

    val sewItem = request.captured.data.single { it.processCode == "SEW-1" }
    sewItem.wipDispatchSite shouldBe "F1-CUT-BTP"
    sewItem.wipReceivingSite shouldBe "F1-SEW-BTP"
  }

  @Test
  fun `subsequent operation in different factory and company uses previous factory BTP receive warehouse`() {
    val request = slot<CreateFppoRequest>()
    arrangeMultiOperation(sameFactory = false)
    every { wfxClient.createFppo(capture(request)) } returns successResponse()

    service().syncFppo("bo-1", "MAIN")

    request.captured.data shouldHaveSize 2
    val cutItem = request.captured.data.single { it.processCode == "CUT-1" }
    cutItem.wipDispatchSite shouldBe "F1-NPL"
    cutItem.wipReceivingSite shouldBe "F1-CUT-BTP"

    val sewItem = request.captured.data.single { it.processCode == "SEW-1" }
    sewItem.executionFactoryCode shouldBe "EXEC-2"
    sewItem.wipDispatchSite shouldBe "F1-CUT-BTP"
    sewItem.wipReceivingSite shouldBe "F2-SEW-BTP"
  }

  @Test
  fun `supports routing starting with operation other than CUT-1`() {
    val request = slot<CreateFppoRequest>()
    arrange(operationCode = "SEW-1", operationName = "May")
    every { wfxClient.createFppo(capture(request)) } returns successResponse()

    service().syncFppo("bo-1", "MAIN")

    request.captured.data.single().apply {
      processCode shouldBe "SEW-1"
      wipDispatchSite shouldBe "LGGMAT"
      wipReceivingSite shouldBe "LGGCUT"
    }
  }

  @Test
  fun `fails when previous operation assignment is missing for SKU`() {
    arrangeMultiOperation(sameFactory = true, omitCutAssignment = true)

    val ex = shouldThrow<IllegalArgumentException> {
      service().syncFppo("bo-1", "MAIN")
    }
    ex.message shouldBe "LSX production-1, công đoạn SEW-1, SKU po-1/Gray (05)/001US thiếu phân bổ duy nhất ở công đoạn trước CUT-1"
  }

  @Test
  fun `fails when warehouse or siteCode is missing`() {
    arrange(cutDispatchSiteCode = null)

    val ex = shouldThrow<IllegalArgumentException> {
      service().syncFppo("bo-1", "MAIN")
    }
    ex.message shouldBe "Xí nghiệp 'Factory', công đoạn 'CUT-1' chưa cấu hình Kho xuất NPL"
  }

  @Test
  fun `allows two mappings sharing same site code`() {
    val request = slot<CreateFppoRequest>()
    arrangeMultiOperation(sameFactory = true, sharedSiteCode = "SHARED-SITE")
    every { wfxClient.createFppo(capture(request)) } returns successResponse()

    service().syncFppo("bo-1", "MAIN")

    request.captured.data shouldHaveSize 2
    val cutItem = request.captured.data.single { it.processCode == "CUT-1" }
    val sewItem = request.captured.data.single { it.processCode == "SEW-1" }
    cutItem.wipDispatchSite shouldBe "F1-NPL"
    cutItem.wipReceivingSite shouldBe "SHARED-SITE"
    sewItem.wipDispatchSite shouldBe "SHARED-SITE"
    sewItem.wipReceivingSite shouldBe "SHARED-SITE"
  }

  private fun arrange(
    operationCode: String = "CUT-1",
    operationName: String = "Cắt",
    cutDispatchSiteCode: String? = "LGGMAT",
    btpReceiveSiteCode: String? = "LGGCUT",
  ) {
    val assignments = listOf(
      assignment(
        "ta-1",
        "production-1",
        10,
        LocalDate.of(2026, 8, 15),
        LocalDate.of(2026, 8, 20),
        operationCode = operationCode,
      ),
      assignment(
        "ta-zero",
        "production-1",
        0,
        LocalDate.of(2026, 8, 15),
        LocalDate.of(2026, 8, 20),
        purchaseOrderId = "po-zero",
        operationCode = operationCode,
      ),
    )
    every { assignmentRepository.findByProductionOrderId("production-1") } returns assignments
    every { assignmentRepository.findByBuyerOrderId("bo-1") } returns assignments
    every { productionOrderRepository.findById("production-1") } returns
      productionOrder("production-1", "MAIN", routing = listOf(operationCode))
    every { buyerOrderRepository.findById("bo-1") } returns
      BuyerOrder("bo-1", "BO-WFX-1", "Style", "R1", Instant.EPOCH, articleCode = "STYLE-1")
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns
      listOf(
        PurchaseOrder(
          "po-1",
          "PO-WFX-1",
          "PO-1",
          "FR",
          LocalDate.of(2026, 8, 8),
          emptyList(),
          "bo-1",
        ),
        PurchaseOrder(
          "po-zero",
          "PO-WFX-0",
          "PO-0",
          "FR",
          LocalDate.of(2026, 8, 8),
          emptyList(),
          "bo-1",
        ),
      )
    every { routingRepository.findByBuyerOrderId("bo-1") } returns
      BuyerOrderRouting(
        "bo-1",
        listOf(Routing("Main", listOf(RoutingProcess(Operation(operationCode))))),
      )
    every { orgUnitRepository.findById("team-1") } returns
      Team("team-1", "Team", "factory-1", "factory-1", Operation(operationCode), true)
    every { orgUnitRepository.findById("factory-1") } returns
      Factory("factory-1", "Factory", "company-1", "", "company-1", emptyList(), true)
    every { orgUnitRepository.findById("company-1") } returns
      Company(
        "company-1",
        "Execution company",
        "corp-1",
        "",
        wfxSupplierName = "Supplier WFX",
        code = "EXEC",
      )

    val nplWarehouseId = if (cutDispatchSiteCode != null) "wh-npl-1" else null
    val btpWarehouseId = if (btpReceiveSiteCode != null) "wh-btp-1" else null

    every { orgUnitRepository.findById("wh-npl-1") } returns
      Warehouse(
        "wh-npl-1",
        "Kho NPL",
        "company-1",
        "",
        "company-1",
        true,
        "WH-NPL",
        siteCode = cutDispatchSiteCode,
      )
    every { orgUnitRepository.findById("wh-btp-1") } returns
      Warehouse(
        "wh-btp-1",
        "Kho BTP",
        "company-1",
        "",
        "company-1",
        true,
        "WH-BTP",
        siteCode = btpReceiveSiteCode,
      )

    every {
      factoryOperationRepository.findByFactoryIdAndOperationCode(
        "factory-1",
        operationCode,
      )
    } returns
      FactoryOperation(
        id = "factory-operation-1",
        companyId = "company-1",
        companyCode = "EXEC",
        factoryId = "factory-1",
        operationCode = operationCode,
        operationName = operationName,
        materialDispatchWarehouseId = nplWarehouseId,
        btpReceiveWarehouseId = btpWarehouseId,
      )
    every { wfxRepository.findCountryNamesByCodes(listOf("FR")) } returns mapOf("FR" to "France")
  }

  private fun arrangeMultiOperation(
    sameFactory: Boolean,
    omitCutAssignment: Boolean = false,
    sharedSiteCode: String? = null,
  ) {
    val factory2Id = if (sameFactory) "factory-1" else "factory-2"
    val company2Id = if (sameFactory) "company-1" else "company-2"
    val cutAssignment = assignment(
      "ta-cut",
      "production-1",
      10,
      LocalDate.of(2026, 8, 15),
      LocalDate.of(2026, 8, 20),
      operationCode = "CUT-1",
      teamId = "team-cut",
    )
    val sewAssignment = assignment(
      "ta-sew",
      "production-1",
      10,
      LocalDate.of(2026, 8, 15),
      LocalDate.of(2026, 8, 20),
      operationCode = "SEW-1",
      teamId = "team-sew",
    )

    val multiAssignments =
      if (omitCutAssignment) listOf(sewAssignment) else listOf(cutAssignment, sewAssignment)
    every { assignmentRepository.findByProductionOrderId("production-1") } returns multiAssignments
    every { assignmentRepository.findByBuyerOrderId("bo-1") } returns multiAssignments

    val routing = listOf("CUT-1", "SEW-1")
    every { productionOrderRepository.findById("production-1") } returns
      productionOrder("production-1", "MAIN", routing = routing)
    every { buyerOrderRepository.findById("bo-1") } returns
      BuyerOrder("bo-1", "BO-WFX-1", "Style", "R1", Instant.EPOCH, articleCode = "STYLE-1")
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns
      listOf(
        PurchaseOrder(
          "po-1",
          "PO-WFX-1",
          "PO-1",
          "FR",
          LocalDate.of(2026, 8, 8),
          emptyList(),
          "bo-1",
        ),
      )
    every { routingRepository.findByBuyerOrderId("bo-1") } returns
      BuyerOrderRouting(
        "bo-1",
        listOf(
          Routing(
            "Main",
            listOf(RoutingProcess(Operation("CUT-1")), RoutingProcess(Operation("SEW-1"))),
          ),
        ),
      )

    // Factory 1 & Company 1
    every { orgUnitRepository.findById("team-cut") } returns
      Team("team-cut", "Team Cut", "factory-1", "factory-1", Operation("CUT-1"), true)
    every { orgUnitRepository.findById("factory-1") } returns
      Factory("factory-1", "Factory 1", "company-1", "", "company-1", emptyList(), true)
    every { orgUnitRepository.findById("company-1") } returns
      Company(
        "company-1",
        "Execution company 1",
        "corp-1",
        "",
        wfxSupplierName = "Supplier WFX",
        code = "EXEC-1",
      )

    // Factory 2 & Company 2 (if different)
    every { orgUnitRepository.findById("team-sew") } returns
      Team("team-sew", "Team Sew", factory2Id, factory2Id, Operation("SEW-1"), true)
    if (!sameFactory) {
      every { orgUnitRepository.findById("factory-2") } returns
        Factory("factory-2", "Factory 2", "company-2", "", "company-2", emptyList(), true)
      every { orgUnitRepository.findById("company-2") } returns
        Company(
          "company-2",
          "Execution company 2",
          "corp-1",
          "",
          wfxSupplierName = "Supplier WFX 2",
          code = "EXEC-2",
        )
    }

    val cutBtpSite = sharedSiteCode ?: "F1-CUT-BTP"
    val sewBtpSite = sharedSiteCode ?: if (sameFactory) "F1-SEW-BTP" else "F2-SEW-BTP"

    // Warehouses
    every { orgUnitRepository.findById("wh-f1-npl") } returns
      Warehouse(
        "wh-f1-npl",
        "Kho NPL F1",
        "company-1",
        "",
        "company-1",
        true,
        "WH-F1-NPL",
        siteCode = "F1-NPL",
      )
    every { orgUnitRepository.findById("wh-f1-cut-btp") } returns
      Warehouse(
        "wh-f1-cut-btp",
        "Kho BTP Cut F1",
        "company-1",
        "",
        "company-1",
        true,
        "WH-F1-CUT-BTP",
        siteCode = cutBtpSite,
      )
    every { orgUnitRepository.findById("wh-sew-btp") } returns
      Warehouse(
        "wh-sew-btp",
        "Kho BTP Sew",
        company2Id,
        "",
        company2Id,
        true,
        "WH-SEW-BTP",
        siteCode = sewBtpSite,
      )

    // Operations
    every {
      factoryOperationRepository.findByFactoryIdAndOperationCode(
        "factory-1",
        "CUT-1",
      )
    } returns
      FactoryOperation(
        "op-cut",
        "company-1",
        "EXEC-1",
        "factory-1",
        "CUT-1",
        "Cắt",
        materialDispatchWarehouseId = "wh-f1-npl",
        btpReceiveWarehouseId = "wh-f1-cut-btp",
      )
    every {
      factoryOperationRepository.findByFactoryIdAndOperationCode(
        factory2Id,
        "SEW-1",
      )
    } returns
      FactoryOperation(
        "op-sew",
        company2Id,
        if (sameFactory) "EXEC-1" else "EXEC-2",
        factory2Id,
        "SEW-1",
        "May",
        btpReceiveWarehouseId = "wh-sew-btp",
      )

    every { wfxRepository.findCountryNamesByCodes(listOf("FR")) } returns mapOf("FR" to "France")
  }

  private fun service() =
    FppoSyncService(
      assignmentRepository,
      productionOrderRepository,
      buyerOrderRepository,
      purchaseOrderRepository,
      routingRepository,
      orgUnitRepository,
      factoryOperationRepository,
      wfxRepository,
      wfxClient,
      releaseRecordService,
    )

  private fun assignment(
    id: String,
    productionOrderId: String,
    quantity: Int,
    start: LocalDate,
    end: LocalDate,
    purchaseOrderId: String = "po-1",
    operationCode: String = "CUT-1",
    teamId: String = "team-1",
    allocations: List<SkuAllocation> = listOf(SkuAllocation(purchaseOrderId, Color("Gray (05)"), Size("001US"), quantity)),
  ) = TeamAssignment(id).apply {
    loadFromHistory(
      listOf(
        TeamAssignmentCreated(
          assignmentId = id,
          productionOrderId = productionOrderId,
          buyerOrderId = "bo-1",
          teamId = teamId,
          operation = Operation(operationCode),
          allocations = allocations,
          plannedStartDate = start,
          plannedEndDate = end,
          assignedAt = Instant.EPOCH,
          actor = null,
          occurredAt = Instant.EPOCH,
        ),
      ),
    )
  }

  private fun productionOrder(
    id: String,
    mainCompanyCode: String,
    routing: List<String> = listOf("CUT-1")
  ) =
    ProductionOrder(
      id,
      "bo-1",
      id,
      listOf("factory-1"),
      mainCompanyCode,
      ProductionOrderStatus.IN_PROGRESS,
      routing = routing,
    )

  private fun successResponse(twoFppos: Boolean = false, fpoFromMessage: Boolean = false) =
    CreateFppoResponse(
      responseData =
        listOf(
          CreateFppoResponseData(
            successMessages = listOf(
              CreateFppoSuccessDto(
                wfxSuccessMessage = if (fpoFromMessage) "FPO:'1495-24' Successfully Created or Updated." else "Created",
                fppoNumbers = listOf(
                  CreateFppoNumberDto(
                    fpoNumber = if (fpoFromMessage) null else "1495-24",
                    fppoNumber = "8265",
                    receivingSiteCode = "LGGCUT",
                  ),
                ) +
                  if (twoFppos) listOf(
                    CreateFppoNumberDto(
                      fpoNumber = "1495-24",
                      fppoNumber = "8266",
                      receivingSiteCode = "LGGCUT",
                    ),
                  ) else emptyList(),
              ),
            ),
          ),
        ),
      status = "Success",
    )
}
