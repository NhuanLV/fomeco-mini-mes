package vn.lgg.mesplus.notification

import io.kotest.matchers.collections.shouldBeEmpty
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import java.io.IOException
import org.junit.jupiter.api.Test
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter
import vn.lgg.mesplus.shared.Activity
import vn.lgg.mesplus.shared.NotificationTarget
import vn.lgg.mesplus.shared.ResourceType

class SseEmittersTest {
  @Test
  fun `removes an emitter that fails while sending`() {
    val emitter = mockk<SseEmitter>()
    justRun { emitter.onCompletion(any()) }
    justRun { emitter.onTimeout(any()) }
    justRun { emitter.onError(any()) }
    every { emitter.send(any<SseEmitter.SseEventBuilder>()) } throws IOException("closed")
    val emitters = SseEmitters()
    emitters.register("recipient-1", emitter)

    emitters.send("recipient-1", notification())

    emitters.ofUser("recipient-1").shouldBeEmpty()
  }

  private fun notification() =
    Notification(
      id = "notification-1",
      recipientId = "recipient-1",
      activity =
        Activity(
          actor = null,
          title = "LSX mới",
          body = "đã giao LSX LSX-1 cho tổ của bạn",
          target = NotificationTarget(ResourceType.TEAM_ASSIGNMENT, "assignment-1"),
        ),
    )
}
