package vn.lgg.mesplus.production.application.usecase

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.time.Instant
import org.junit.jupiter.api.Test
import tools.jackson.databind.json.JsonMapper
import vn.lgg.mesplus.order.infrastructure.wfx.FppoResolver
import vn.lgg.mesplus.order.infrastructure.wfx.WfxSyncException
import vn.lgg.mesplus.order.infrastructure.wfx.client.WfxClient
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.GrnDataPayload
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.GrnRequest
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.FppoDetailDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.WfxSyncResponse
import vn.lgg.mesplus.production.domain.model.GrnMode
import vn.lgg.mesplus.production.domain.model.Report
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.ReportType
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

class ReportGrnSyncExecutorTest {
  private val service = mockk<ReportGrnSyncService>(relaxed = true)
  private val fppoResolver = mockk<FppoResolver>()
  private val wfxClient = mockk<WfxClient>()
  private val objectMapper = JsonMapper.builder().build()
  private val executor =
    ReportGrnSyncExecutor(
      service,
      fppoResolver,
      wfxClient,
      objectMapper,
    )

  @Test
  fun `maps report to GRN payload with deterministic document fields`() {
    val payload = slot<GrnRequest>()
    every { fppoResolver.resolve("BO-WFX-1", Operation("CUT")) } returns
      FppoDetailDto(
        fppoNo = "6840",
        receivingSiteName = "SEW SITE",
        uom = "Pcs",
      )
    every { wfxClient.createGrn(capture(payload)) } returns WfxSyncResponse(wfxStatus = "Success")

    executor.execute(command())

    val data = objectMapper.readValue(payload.captured.grnData, GrnDataPayload::class.java)
    data.headerData.single().docNo shouldBe "GRN-assignment-1-1782864000000"
    data.headerData.single().docDate shouldBe "2026-07-01"
    data.headerData.single().siteName shouldBe "BTP-IN"
    data.headerData.single().location shouldBe "KHO"
    data.articleData.single().receivedQty shouldBe "12"
    data.articleData.single().uom shouldBe "Pcs"
    data.articleData.single().destinationCountryName shouldBe "United States"
    verify { service.markSuccess(any(), any()) }
  }

  @Test
  fun `uses derived BTP article code for an intermediate operation`() {
    val payload = slot<GrnRequest>()
    every { fppoResolver.resolve("BO-WFX-1", Operation("SEW-1")) } returns
      FppoDetailDto(
        fppoNo = "8238",
        receivingSiteName = "SEW SITE",
        uom = "Pcs",
      )
    every { wfxClient.createGrn(capture(payload)) } returns WfxSyncResponse(wfxStatus = "Success")

    executor.execute(
      command().copy(
        operation = Operation("SEW-1"),
        articleCode = "LGG11BSDSGWWN2N1J112btptheu",
      ),
    )

    val data = objectMapper.readValue(payload.captured.grnData, GrnDataPayload::class.java)
    data.headerData.single().siteName shouldBe "BTP-IN"
    data.articleData.single().articleCode shouldBe "LGG11BSDSGWWN2N1J112btptheu"
    data.articleData.single().uom shouldBe "Pcs"
  }

  @Test
  fun `uses LGG - FN for finishing operation GRN`() {
    val payload = slot<GrnRequest>()
    every { fppoResolver.resolve("BO-WFX-1", Operation("FIN-1")) } returns
      FppoDetailDto(
        fppoNo = "8239",
        receivingSiteName = "FIN SITE",
        uom = "Pcs",
      )
    every { wfxClient.createGrn(capture(payload)) } returns WfxSyncResponse(wfxStatus = "Success")

    executor.execute(
      command().copy(
        operation = Operation("FIN-1"),
        articleCode = "LGG11BSDSGWWN2N1J112",
      ),
    )

    val data = objectMapper.readValue(payload.captured.grnData, GrnDataPayload::class.java)
    data.headerData.single().siteName shouldBe "BTP-IN"
  }

  @Test
  fun `marks GRN failed when WFX rejects the request`() {
    every { fppoResolver.resolve("BO-WFX-1", Operation("CUT")) } returns
      FppoDetailDto(
        fppoNo = "6840",
        receivingSiteName = "SEW SITE",
        uom = "Pcs",
      )
    every { wfxClient.createGrn(any()) } throws WfxSyncException.business("WFX failed")

    executor.execute(command())

    verify { service.markFailed(any(), "WFX từ chối tạo phiếu: WFX failed") }
  }

  private fun command() =
    ReportGrnSyncCommand(
      assignmentId = "assignment-1",
      reportedAt = Instant.parse("2026-07-01T00:00:00Z"),
      mode = GrnMode.MANUAL,
      docNo = "GRN-assignment-1-1782864000000",
      report =
        Report(
          type = ReportType.OUTPUT,
          items = listOf(ReportItem("po-1", Color("RED"), Size("M"), 12)),
          reportedAt = Instant.parse("2026-07-01T00:00:00Z"),
          reportedBy = ActorRef("user-1", "User"),
        ),
      buyerOrderWfxId = "BO-WFX-1",
      operation = Operation("CUT"),
      articleCode = "LGG11BSDSGWWN2N1J112",
      uom = "PCS",
      siteName = "BTP-IN",
      poCountryNames = mapOf("po-1" to "United States"),
    )
}
