package vn.lgg.mesplus.kanban.application.eventhandler

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.math.BigDecimal
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.domain.model.Kanban
import vn.lgg.mesplus.kanban.domain.model.KanbanItem
import vn.lgg.mesplus.kanban.domain.model.KanbanItemType
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.notification.Notification
import vn.lgg.mesplus.notification.NotificationRepository
import vn.lgg.mesplus.notification.SseEmitters
import vn.lgg.mesplus.notification.SseNotifier
import vn.lgg.mesplus.kanban.domain.event.KanbanCancelled
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.PermissionService

class KanbanCancellationNotificationTest {
  @Test
  fun `notification follows the step before cancellation`() {
    for (step in 0..2) {
      val actor = ActorRef("creator", "Tổ trưởng")
      val kanban = Kanban.create("kanban", "assignment", emptyList(),
        listOf(KanbanItem("MAT", Color("RED"), Size("M"), null, KanbanItemType.MATERIAL,
          BigDecimal.ONE, "supplier", "")), "extra", actor)
      if (step >= 1) kanban.approve(actor)
      if (step == 2) kanban.approveExtra(actor)
      kanban.cancel("Đổi kế hoạch", actor)
      val repository = mockk<KanbanRepository>(relaxed = true)
      val teams = mockk<TeamAssignmentRepository>(relaxed = true)
      val orders = mockk<ProductionOrderRepository>(relaxed = true)
      val permissions = mockk<PermissionService>()
      val notifications = mockk<NotificationRepository>()
      val sse = mockk<SseEmitters>(relaxed = true)
      var saved = emptyList<Notification>()
      every { repository.findById("kanban") } returns kanban
      every { teams.findById("assignment") } returns mockk {
        every { teamId } returns "team"
        every { productionOrderId } returns "order"
      }
      every { orders.findById("order") } returns mockk { every { productionCode } returns "LSX-1" }
      every { permissions.lookupAccountIds(any(), any()) } answers {
        listOf(when (firstArg<Permission>()) {
          Permission.EVALUATE_KANBAN -> "level-1"
          Permission.EVALUATE_EXTRA_KANBAN -> "level-2"
        else -> "warehouse"
        })
      }
      every { notifications.saveAll(any()) } answers { firstArg<List<Notification>>().also { saved = it } }
      val creator = KanbanNotificationCreator(repository, teams, permissions, SseNotifier(notifications, sse), orders)
      creator.create(kanban.allEvents.filterIsInstance<KanbanCancelled>().single())
      val expected = when (step) {
        0 -> setOf("creator", "level-1")
        1 -> setOf("creator", "level-1", "level-2")
        else -> setOf("creator", "level-1", "level-2", "warehouse")
      }
      saved.map { it.recipientId }.toSet() shouldBe expected
      saved.size shouldBe expected.size
      saved.first().activity.body shouldBe "Kanban KANBAN của lệnh LSX-1 đã bị huỷ"
      saved.first().activity.target.resourceId shouldBe "kanban"
    }
  }
}
