package vn.lgg.mesplus.production.application.usecase

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.time.Instant
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.infrastructure.repository.view.AccountViewRepository
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.production.application.service.ProductionOrderTypeQuery
import vn.lgg.mesplus.production.domain.event.LastReportDeleted
import vn.lgg.mesplus.production.domain.event.LastReportUpdated
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.model.GrnStatus
import vn.lgg.mesplus.production.domain.model.ReportGrn
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.ReportType
import vn.lgg.mesplus.production.domain.repository.ReportGrnRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.production.infrastructure.repository.TeamAssignmentViewRepository
import vn.lgg.mesplus.production.presentation.viewmodel.ReportHistoryActionTypeVm
import vn.lgg.mesplus.production.presentation.viewmodel.SkuReportVm
import vn.lgg.mesplus.production.presentation.viewmodel.TeamAssignmentDetailVm
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Size

class ReportHistoryQueryServiceTest {
  private val assignmentRepository = mockk<TeamAssignmentRepository>()
  private val accountViewRepository = mockk<AccountViewRepository>()
  private val assignmentViewRepository = mockk<TeamAssignmentViewRepository>()
  private val grnRepository = mockk<ReportGrnRepository>()
  private val productionOrderTypeQuery = mockk<ProductionOrderTypeQuery>()
  private val service =
    ReportHistoryQueryService(
      assignmentRepository,
      accountViewRepository,
      assignmentViewRepository,
      grnRepository,
      productionOrderTypeQuery,
    )
  private val reportedAt = Instant.parse("2026-04-01T00:00:00Z")
  private val updatedAt = Instant.parse("2026-04-02T00:00:00Z")

  @BeforeEach
  fun setUp() {
    every { productionOrderTypeQuery.typesByPo(any<String>()) } returns mapOf("po-1" to PurchaseOrderType.REGULAR)
  }

  @Test
  fun `tracks report snapshots and only allows modifying the latest report action`() {
    every { assignmentViewRepository.findDetailVm("assignment-1") } returns assignmentView()
    every { grnRepository.findByAssignmentId("assignment-1") } returns emptyList()
    every { assignmentRepository.findEventsById("assignment-1") } returns
      listOf(
        ProgressReported(
          assignmentId = "assignment-1",
          type = ReportType.INPUT,
          items = listOf(item(10)),
          actor = null,
          occurredAt = reportedAt,
        ),
        LastReportUpdated(
          assignmentId = "assignment-1",
          targetReportedAt = reportedAt,
          items = listOf(item(12)),
          actor = null,
          occurredAt = updatedAt,
        ),
      )

    val history = service.getHistory("assignment-1")

    history.map { it.reportType to it.actionType } shouldContainExactly
      listOf(
        ReportType.INPUT to ReportHistoryActionTypeVm.UPDATED,
        ReportType.INPUT to ReportHistoryActionTypeVm.CREATED,
      )
    history.first().actionType shouldBe ReportHistoryActionTypeVm.UPDATED
    history.first().canModify shouldBe true
    history.first().quantities shouldContainExactly
      listOf(SkuReportVm("po-1", Color("RED"), Size("M"), 12, 10))
    history.last().canModify shouldBe false
  }

  @Test
  fun `deleting a report uses the stored snapshot with negative quantities`() {
    every { assignmentViewRepository.findDetailVm("assignment-1") } returns assignmentView()
    every { grnRepository.findByAssignmentId("assignment-1") } returns emptyList()
    every { assignmentRepository.findEventsById("assignment-1") } returns
      listOf(
        ProgressReported(
          assignmentId = "assignment-1",
          type = ReportType.OUTPUT,
          items = listOf(item(7)),
          actor = null,
          occurredAt = reportedAt,
        ),
        LastReportDeleted(
          assignmentId = "assignment-1",
          targetReportedAt = reportedAt,
          actor = null,
          occurredAt = updatedAt,
        ),
      )

    val history = service.getHistory("assignment-1")

    history.first().reportType shouldBe ReportType.OUTPUT
    history.first().actionType shouldBe ReportHistoryActionTypeVm.DELETED
    history.first().targetReportedAt shouldBe reportedAt.toString()
    history.first().quantities shouldContainExactly
      listOf(SkuReportVm("po-1", Color("RED"), Size("M"), -7))
    history.first().canModify shouldBe false
  }

  @Test
  fun `maps NOT_APPLICABLE GRN for positive LSX`() {
    every { productionOrderTypeQuery.typesByPo("assignment-1") } returns mapOf("po-1" to PurchaseOrderType.POSITIVE)
    every { assignmentViewRepository.findDetailVm("assignment-1") } returns assignmentView()
    every { grnRepository.findByAssignmentId("assignment-1") } returns emptyList()
    every { assignmentRepository.findEventsById("assignment-1") } returns
      listOf(
        ProgressReported(
          assignmentId = "assignment-1",
          type = ReportType.OUTPUT,
          items = listOf(item(10)),
          actor = null,
          occurredAt = reportedAt,
        ),
      )

    val history = service.getHistory("assignment-1")

    history.first().grnStatus shouldBe GrnStatus.NOT_APPLICABLE
    history.first().canCreateGrn shouldBe false
  }

  @Test
  fun `includes failed staging snapshot without a progress event`() {
    every { assignmentViewRepository.findDetailVm("assignment-1") } returns assignmentView()
    every { assignmentRepository.findEventsById("assignment-1") } returns emptyList()
    every { accountViewRepository.findVmById("reporter-1") } returns null
    every { grnRepository.findByAssignmentId("assignment-1") } returns
      listOf(
        ReportGrn(
          assignmentId = "assignment-1",
          reportedAt = reportedAt,
          reportedBy = ActorRef("reporter-1", "Reporter"),
          status = GrnStatus.FAILED,
          message = "WFX error",
          reportSnapshot = listOf(item(7)),
          createdAt = reportedAt,
          updatedAt = updatedAt,
        ),
      )

    val history = service.getHistory("assignment-1")

    history.single().grnStatus shouldBe GrnStatus.FAILED
    history.single().actor shouldBe ActorRef("reporter-1", "Reporter")
    history.single().quantities shouldContainExactly
      listOf(SkuReportVm("po-1", Color("RED"), Size("M"), 7))
  }

  @Test
  fun `formats cancelledAt in reason for cancelled report`() {
    val cancelledTime = Instant.parse("2026-09-23T11:53:22Z")
    every { assignmentViewRepository.findDetailVm("assignment-1") } returns assignmentView()
    every { assignmentRepository.findEventsById("assignment-1") } returns emptyList()
    every { accountViewRepository.findVmById("admin-1") } returns
      mockk(relaxed = true) {
        every { id } returns "admin-1"
        every { name } returns "Admin"
      }
    every { grnRepository.findByAssignmentId("assignment-1") } returns
      listOf(
        ReportGrn(
          assignmentId = "assignment-1",
          reportedAt = reportedAt,
          reportedBy = null,
          status = GrnStatus.CANCELLED,
          reportSnapshot = listOf(item(7)),
          cancelledBy = "admin-1",
          cancelledAt = cancelledTime,
          createdAt = reportedAt,
          updatedAt = cancelledTime,
        ),
      )

    val history = service.getHistory("assignment-1")

    val single = history.single()
    single.actionType shouldBe ReportHistoryActionTypeVm.CANCELLED
    single.reason shouldBe "Báo cáo ra chuyền đã bị hủy bởi Admin vào lúc 23/09/2026 18:53:22"
  }

  @Test
  fun `does not allow modifying committed input report when an active staging GRN exists`() {
    every { assignmentViewRepository.findDetailVm("assignment-1") } returns assignmentView()
    every { assignmentRepository.findEventsById("assignment-1") } returns
      listOf(
        ProgressReported(
          assignmentId = "assignment-1",
          type = ReportType.INPUT,
          items = listOf(item(10)),
          actor = null,
          occurredAt = reportedAt,
        ),
      )
    every { grnRepository.findByAssignmentId("assignment-1") } returns
      listOf(
        ReportGrn(
          assignmentId = "assignment-1",
          reportedAt = updatedAt,
          reportedBy = null,
          status = GrnStatus.FAILED,
          message = "WFX error",
          reportSnapshot = listOf(item(5)),
          createdAt = updatedAt,
          updatedAt = updatedAt,
        ),
      )

    val history = service.getHistory("assignment-1")

    history.size shouldBe 2
    val stagedOutput = history.first { it.reportType == ReportType.OUTPUT }
    val committedInput = history.first { it.reportType == ReportType.INPUT }

    stagedOutput.grnStatus shouldBe GrnStatus.FAILED
    committedInput.canModify shouldBe false
  }

  @Test
  fun `allows modifying committed input report once the failed staging GRN is cancelled`() {
    val cancelledTime = Instant.parse("2026-09-23T11:53:22Z")
    every { assignmentViewRepository.findDetailVm("assignment-1") } returns assignmentView()
    every { accountViewRepository.findVmById("admin-1") } returns
      mockk(relaxed = true) {
        every { id } returns "admin-1"
        every { name } returns "Admin"
      }
    every { assignmentRepository.findEventsById("assignment-1") } returns
      listOf(
        ProgressReported(
          assignmentId = "assignment-1",
          type = ReportType.INPUT,
          items = listOf(item(10)),
          actor = null,
          occurredAt = reportedAt,
        ),
      )
    every { grnRepository.findByAssignmentId("assignment-1") } returns
      listOf(
        ReportGrn(
          assignmentId = "assignment-1",
          reportedAt = updatedAt,
          reportedBy = null,
          status = GrnStatus.CANCELLED,
          reportSnapshot = listOf(item(5)),
          cancelledBy = "admin-1",
          cancelledAt = cancelledTime,
          createdAt = updatedAt,
          updatedAt = cancelledTime,
        ),
      )

    val history = service.getHistory("assignment-1")

    history.size shouldBe 2
    val stagedOutput = history.first { it.reportType == ReportType.OUTPUT }
    val committedInput = history.first { it.reportType == ReportType.INPUT }

    stagedOutput.grnStatus shouldBe GrnStatus.CANCELLED
    committedInput.canModify shouldBe true
  }

  @Test
  fun `mixed input history splits by PO type with both quantities and no GRN`() {
    every { productionOrderTypeQuery.typesByPo("assignment-1") } returns mapOf(
      "po-1" to PurchaseOrderType.REGULAR,
      "po-positive" to PurchaseOrderType.POSITIVE,
    )
    every { assignmentViewRepository.findDetailVm("assignment-1") } returns assignmentView()
    every { grnRepository.findByAssignmentId("assignment-1") } returns emptyList()
    every { assignmentRepository.findEventsById("assignment-1") } returns listOf(
      ProgressReported(
        "assignment-1", ReportType.INPUT,
        listOf(item(10), item(5).copy(purchaseOrderId = "po-positive")), null, reportedAt,
      ),
    )

    val history = service.getHistory("assignment-1")

    history.size shouldBe 2
    val regular = history.single { it.purchaseOrderType == PurchaseOrderType.REGULAR }
    val positive = history.single { it.purchaseOrderType == PurchaseOrderType.POSITIVE }
    regular.quantities shouldContainExactly listOf(SkuReportVm("po-1", Color("RED"), Size("M"), 10))
    positive.quantities shouldContainExactly listOf(SkuReportVm("po-positive", Color("RED"), Size("M"), 5))
    history.map { it.reportType }.toSet() shouldBe setOf(ReportType.INPUT)
    history.map { it.grnStatus }.toSet() shouldBe setOf(null)
    history.all { it.canModify } shouldBe true
  }

  @Test
  fun `mixed output history keeps successful positive separate from failed regular GRN at the same time`() {
    every { productionOrderTypeQuery.typesByPo("assignment-1") } returns mapOf(
      "po-1" to PurchaseOrderType.REGULAR,
      "po-positive" to PurchaseOrderType.POSITIVE,
    )
    every { assignmentViewRepository.findDetailVm("assignment-1") } returns assignmentView()
    every { assignmentRepository.findEventsById("assignment-1") } returns listOf(
      ProgressReported(
        "assignment-1", ReportType.OUTPUT,
        listOf(item(5).copy(purchaseOrderId = "po-positive")), null, reportedAt,
      ),
    )
    every { grnRepository.findByAssignmentId("assignment-1") } returns listOf(
      ReportGrn(
        assignmentId = "assignment-1",
        reportedAt = reportedAt,
        reportedBy = null,
        status = GrnStatus.FAILED,
        message = "WFX error",
        reportSnapshot = listOf(item(10)),
        createdAt = reportedAt,
        updatedAt = updatedAt,
      ),
    )

    val history = service.getHistory("assignment-1")

    history.size shouldBe 2
    val regular = history.single { it.purchaseOrderType == PurchaseOrderType.REGULAR }
    val positive = history.single { it.purchaseOrderType == PurchaseOrderType.POSITIVE }
    regular.quantities shouldContainExactly listOf(SkuReportVm("po-1", Color("RED"), Size("M"), 10))
    regular.grnStatus shouldBe GrnStatus.FAILED
    regular.grnMessage shouldBe "WFX error"
    positive.quantities shouldContainExactly listOf(SkuReportVm("po-positive", Color("RED"), Size("M"), 5))
    positive.grnStatus shouldBe GrnStatus.NOT_APPLICABLE
    positive.grnMessage shouldBe null
    positive.grnMode shouldBe null
    positive.grnUpdatedAt shouldBe null
    positive.grnNo shouldBe null
    history.all { !it.canModify && !it.canCreateGrn } shouldBe true
  }

  private fun item(quantity: Int) =
    ReportItem(
      purchaseOrderId = "po-1",
      color = Color("RED"),
      size = Size("M"),
      quantity = quantity,
    )

  private fun assignmentView() =
    mockk<TeamAssignmentDetailVm> {
      every { productionCode } returns "PROD-1"
    }
}
