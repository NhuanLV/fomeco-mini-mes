package vn.lgg.mesplus.kanban.infrastructure.repository

import io.kotest.matchers.shouldBe
import io.mockk.mockk
import java.math.BigDecimal
import java.sql.DriverManager
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.SchemaUtils
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable
import tools.jackson.databind.json.JsonMapper
import tools.jackson.databind.jsontype.NamedType
import vn.lgg.mesplus.inventory.domain.event.btp.*
import vn.lgg.mesplus.inventory.domain.model.btp.BtpSku
import vn.lgg.mesplus.inventory.infrastructure.projector.BtpInventoryProjector
import vn.lgg.mesplus.inventory.infrastructure.repository.PgBtpInventoryRepository
import vn.lgg.mesplus.inventory.infrastructure.repository.exposed.*
import vn.lgg.mesplus.kanban.domain.event.*
import vn.lgg.mesplus.kanban.domain.model.*
import vn.lgg.mesplus.kanban.infrastructure.repository.exposed.*
import vn.lgg.mesplus.kanban.presentation.viewmodel.*
import vn.lgg.mesplus.production.infrastructure.repository.exposed.TeamAssignmentViewTable
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size

/** Uses a disposable schema in the compose development database; never touches public tables. */
@EnabledIfEnvironmentVariable(named = "MES_CANCEL_DB_TEST", matches = "true")
class KanbanCancellationDbTest {
  private val schema = "cancel_test_${UUID.randomUUID().toString().replace("-", "")}"
  private val url = System.getenv("MES_CANCEL_TEST_JDBC_URL") ?: "jdbc:postgresql://localhost:5433/mesplus"
  private val user = System.getenv("MES_CANCEL_TEST_DB_USER") ?: "sa"
  private val password = System.getenv("MES_CANCEL_TEST_DB_PASSWORD") ?: "1234"
  private lateinit var database: Database
  private lateinit var viewRepository: KanbanViewRepository
  private lateinit var repository: PgKanbanRepository
  private lateinit var inventoryRepository: PgBtpInventoryRepository
  private val balanceTable = BtpInventoryBalanceViewTable()
  private val transactionTable = BtpInventoryTransactionViewTable()
  private val kanbanId = UUID.randomUUID().toString()
  private val sourceId = UUID.randomUUID().toString()
  private val actor = ActorRef(UUID.randomUUID().toString(), "Tổ trưởng")

  @BeforeEach
  fun setup() {
    DriverManager.getConnection(url, user, password).use { connection ->
      connection.createStatement().use { it.execute("CREATE SCHEMA $schema") }
    }
    database = Database.connect("$url${if ('?' in url) '&' else '?'}currentSchema=$schema",
      driver = "org.postgresql.Driver", user = user, password = password)
    val mapper = JsonMapper.builder().addModule(tools.jackson.module.kotlin.KotlinModule.Builder().build()).registerSubtypes(
      NamedType(KanbanCreated::class.java, "KanbanCreated"),
      NamedType(KanbanApproved::class.java, "KanbanApproved"),
      NamedType(KanbanCancelled::class.java, "KanbanCancelled"),
      NamedType(BtpProduced::class.java, "BtpProduced"),
      NamedType(BtpKanbanIssued::class.java, "BtpKanbanIssued"),
      NamedType(BtpKanbanCancelled::class.java, "BtpKanbanCancelled"),
    ).build()
    val view = KanbanViewTable(mapper)
    val items = KanbanItemViewTable(view)
    val parts = KanbanItemPartViewTable(view)
    transaction(database) { SchemaUtils.create(view, items, parts) }
    viewRepository = KanbanViewRepository(view, items, parts, TeamAssignmentViewTable(),
      mockk(relaxed = true), mockk(relaxed = true), mockk(relaxed = true), mockk(relaxed = true))
    val events = KanbanEventsTable(mapper)
    val btpEvents = BtpInventoryEventsTable(mapper)
    val locks = BtpInventoryLocksTable()
    transaction(database) { SchemaUtils.create(events, btpEvents, locks, balanceTable, transactionTable) }
    repository = PgKanbanRepository(events)
    inventoryRepository = PgBtpInventoryRepository(locks, btpEvents, BtpInventoryProjector(balanceTable, transactionTable))
    transaction(database) {
      val kanban = Kanban.create(kanbanId, UUID.randomUUID().toString(),
        listOf(PlanItem(UUID.randomUUID().toString(), Color("RED"), Size("M"), 10)),
        listOf(KanbanItem("MAT", Color("RED"), Size("M"), null, KanbanItemType.MATERIAL,
          BigDecimal(200), "supplier", "")), "", actor)
      kanban.approve(actor)
      repository.save(kanban)
    }
  }

  @AfterEach
  fun cleanup() {
    DriverManager.getConnection(url, user, password).use { connection ->
      connection.createStatement().use { it.execute("DROP SCHEMA $schema CASCADE") }
    }
  }

  @Test
  fun `cancelling removes only its standard demand and leaves other kanbans intact`() {
    val teamAssignment = UUID.randomUUID().toString()
    val team = UUID.randomUUID().toString()
    val po = UUID.randomUUID().toString()
    val key = Triple("MAT", Color("RED"), Size("M"))
    fun save(qty: Int, status: KanbanStatus, standard: Boolean): String {
      val newId = UUID.randomUUID().toString()
      viewRepository.save(KanbanDetailVm(newId, teamAssignment, team, "", null, null,
        if (standard) "STANDARD" else "EXTRA", status,
        if (standard) listOf(PlanItemVm(po, null, key.second, key.third, qty)) else emptyList(),
        listOf(KanbanItemVm(key.first, null, key.second, key.third, "", BigDecimal(1000), BigDecimal.ZERO,
          "", "", listOf(ItemPartVm(null, null, BigDecimal(qty), BigDecimal.ZERO,
            issued = false, received = false, supplierId = "supplier", supplierName = "")))),
        java.time.Instant.now(), actor.id, actor.name))
      return newId
    }
    transaction(database) {
      val cancelledId = save(200, KanbanStatus.APPROVED, true)
      save(100, KanbanStatus.APPROVED, true)
      save(75, KanbanStatus.REJECTED, true)
      val extraId = save(50, KanbanStatus.APPROVED, false)
      viewRepository.sumRequiredByTeamAssignment(teamAssignment)[key]!!.compareTo(BigDecimal(300)) shouldBe 0
      viewRepository.updateStatus(cancelledId, KanbanStatus.CANCELLED)
      viewRepository.sumRequiredByTeamAssignment(teamAssignment)[key]!!.compareTo(BigDecimal(100)) shouldBe 0
      viewRepository.sumPlannedByTeamAssignment(teamAssignment).single().qty shouldBe 100
      viewRepository.updateStatus(extraId, KanbanStatus.CANCELLED)
      viewRepository.sumRequiredByTeamAssignment(teamAssignment)[key]!!.compareTo(BigDecimal(100)) shouldBe 0
    }
  }

  @Test
  fun `cancellation remains committed when async effects roll back and compensation is idempotent`() {
    val sku = BtpSku("BTP CUT", "RED", "M")
    val reference = "$kanbanId:supplier:po"
    transaction(database) {
      val inventory = inventoryRepository.lockAndLoad(sourceId)
      inventory.produce(sku, BigDecimal(300), "report", actor)
      inventory.issue(sku, BigDecimal(200), reference, actor)
      inventory.issue(sku, BigDecimal(50), "other:supplier:po", actor)
      inventoryRepository.save(inventory)
      repository.lockAndLoad(kanbanId)!!.also { it.cancel("Đổi kế hoạch", actor); repository.save(it) }
    }
    transaction(database) {
      inventoryRepository.findIssuedByKanban(kanbanId).single().quantity shouldBe BigDecimal(200)
      val inventory = inventoryRepository.lockAndLoad(sourceId)
      inventory.cancelIssue(sku, reference, actor)
      inventoryRepository.save(inventory)
      rollback() // Simulate a failed downstream transaction.
    }
    transaction(database) {
      repository.findById(kanbanId)!!.status shouldBe KanbanStatus.CANCELLED
      inventoryRepository.lockAndLoad(sourceId).balance(sku) shouldBe BigDecimal(50)
      val inventory = inventoryRepository.lockAndLoad(sourceId)
      inventory.cancelIssue(sku, reference, actor)
      inventoryRepository.save(inventory)
    }
    transaction(database) {
      val inventory = inventoryRepository.lockAndLoad(sourceId)
      inventory.cancelIssue(sku, reference, actor)
      inventoryRepository.save(inventory)
      inventory.balance(sku) shouldBe BigDecimal(250)
      val balance = balanceTable.selectAll().single()
      balance[balanceTable.totalReceived].compareTo(BigDecimal(300)) shouldBe 0
      balance[balanceTable.totalIssued].compareTo(BigDecimal(50)) shouldBe 0
      val history = transactionTable.selectAll().toList()
      history.count { it[transactionTable.eventType] == "KANBAN_ISSUED" } shouldBe 2
      val compensation = history.single { it[transactionTable.eventType] == "KANBAN_CANCELLED" }
      compensation[transactionTable.referenceId].substringBefore(':') shouldBe kanbanId
    }
  }

  @Test
  fun `a competing mutation loads cancelled state after waiting for the same root lock`() {
    val executor = Executors.newFixedThreadPool(2)
    val locked = CountDownLatch(1)
    val release = CountDownLatch(1)
    try {
      val cancel = executor.submit {
        transaction(database) {
          val kanban = repository.lockAndLoad(kanbanId)!!
          locked.countDown()
          check(release.await(10, TimeUnit.SECONDS))
          kanban.cancel("Đổi", actor)
          repository.save(kanban)
        }
      }
      check(locked.await(10, TimeUnit.SECONDS))
      val competing = executor.submit<KanbanStatus> {
        transaction(database) { repository.lockAndLoad(kanbanId)!!.status }
      }
      release.countDown()
      cancel.get(10, TimeUnit.SECONDS)
      competing.get(10, TimeUnit.SECONDS) shouldBe KanbanStatus.CANCELLED
    } finally {
      release.countDown()
      executor.shutdownNow()
    }
  }
}
