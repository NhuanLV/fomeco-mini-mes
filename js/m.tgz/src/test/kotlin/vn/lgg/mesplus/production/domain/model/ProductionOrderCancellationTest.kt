package vn.lgg.mesplus.production.domain.model

import org.junit.jupiter.api.Test
import org.junit.jupiter.api.Assertions.*
import vn.lgg.mesplus.shared.model.ActorRef

class ProductionOrderCancellationTest {
  @Test
  fun `cancellation is permanent and records actor reason and time`() {
    val order = ProductionOrder("id", "bo", "LSX", listOf("factory"), "MAIN", ProductionOrderStatus.COMPLETED)
    val actor = ActorRef("actor", "Planner")
    order.cancel("  Đổi kế hoạch  ", actor)
    assertEquals(ProductionOrderStatus.CANCELLED, order.status)
    assertEquals("Đổi kế hoạch", order.cancellationReason)
    assertEquals(actor, order.cancelledBy)
    assertEquals(order.updatedAt, order.cancelledAt)
    assertNull(order.completedAt)
    assertThrows(IllegalStateException::class.java) { order.requireActive() }
    assertThrows(IllegalStateException::class.java) { order.cancel("Lần hai", actor) }
  }

  @Test
  fun `blank reason leaves order active`() {
    val order = ProductionOrder("id", "bo", "LSX", listOf("factory"), "MAIN", ProductionOrderStatus.IN_PROGRESS)
    assertThrows(IllegalArgumentException::class.java) { order.cancel("  ", ActorRef("actor", "Planner")) }
    assertEquals(ProductionOrderStatus.IN_PROGRESS, order.status)
  }
}
