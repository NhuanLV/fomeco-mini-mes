package vn.lgg.mesplus.order.infrastructure.wfx

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.time.Instant
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BoMaterialState
import vn.lgg.mesplus.order.domain.repository.BoMaterialStateRepository
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.infrastructure.repository.WfxRepository
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.BomConsumptionDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.BomMaterialLineDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.BomResponseData
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.BomSectionDto

class WfxMapperMaterialStateTest {
  private val buyerOrderRepository = mockk<BuyerOrderRepository>()
  private val purchaseOrderRepository = mockk<PurchaseOrderRepository>()
  private val wfxRepository = mockk<WfxRepository>()
  private val boMaterialStateRepository = mockk<BoMaterialStateRepository>()

  @Test
  fun `restores material state when WFX material returns after being absent`() {
    val buyerOrder =
      BuyerOrder(
        id = "00000000-0000-0000-0000-000000000001",
        wfxId = "BO-1",
        styleName = "Style",
        revisionCode = "R1",
        revisionDate = Instant.parse("2026-01-01T00:00:00Z"),
      )
    every { buyerOrderRepository.findByWfxId("BO-1") } returns buyerOrder
    every { purchaseOrderRepository.findByBuyerOrderId(buyerOrder.id) } returns emptyList()
    every { boMaterialStateRepository.findByBuyerOrderId(buyerOrder.id) } returns
      mapOf("MAT-1" to BoMaterialState(buyerOrder.id, "MAT-1", "Vải chính", false))
    every { wfxRepository.queryArticles(listOf("MAT-1")) } returns emptyMap()
    every { wfxRepository.findColorsByIds(emptySet()) } returns emptyMap()
    every { wfxRepository.findSizesByIds(emptySet()) } returns emptyMap()

    val bom = mapper().toBom("BO-1", listOf(responseWithMaterial("MAT-1")))

    bom.materials.single().material.alternativeName shouldBe "Vải chính"
    bom.materials.single().material.isRequired shouldBe false
  }

  private fun mapper() =
    WfxMapper(buyerOrderRepository, purchaseOrderRepository, wfxRepository, boMaterialStateRepository)

  private fun responseWithMaterial(articleId: String) =
    BomResponseData(
      sections =
        listOf(
          BomSectionDto(
            title = "Fabric",
            category = "Fabric",
            materiallines =
              listOf(
                BomMaterialLineDto(
                  wfxBomLineId = "line-1",
                  articleId = articleId,
                  wastagepercentage = "0",
                  sizedep = "none",
                  colordep = "none",
                  consumption = listOf(BomConsumptionDto(qty = "1", uom = "MTR")),
                ),
              ),
          ),
        ),
    )
}
