package vn.lgg.mesplus.dashboard.infrastructure.repository

import io.kotest.matchers.collections.shouldContainExactlyInAnyOrder
import io.kotest.matchers.shouldBe
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.dashboard.application.model.DashboardDateRange
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus

class DashboardProductionRepositoryTest {
  private val zone = ZoneId.of("Asia/Ho_Chi_Minh")
  private val range = DashboardDateRange(LocalDate.of(2026, 4, 10), LocalDate.of(2026, 4, 12))

  @Test
  fun `selects in-progress orders and completed orders overlapping period`() {
    val orders = listOf(
      DashboardProductionOrderState("in-progress", ProductionOrderStatus.IN_PROGRESS, null),
      DashboardProductionOrderState("in-progress-created-after", ProductionOrderStatus.IN_PROGRESS, null, instant("2026-04-13")),
      DashboardProductionOrderState("completed-at-start", ProductionOrderStatus.COMPLETED, instant("2026-04-10")),
      DashboardProductionOrderState("completed-at-end", ProductionOrderStatus.COMPLETED, instant("2026-04-12")),
      DashboardProductionOrderState("completed-before", ProductionOrderStatus.COMPLETED, instant("2026-04-09")),
      DashboardProductionOrderState("completed-after", ProductionOrderStatus.COMPLETED, instant("2026-04-13")),
      DashboardProductionOrderState("completed-without-date", ProductionOrderStatus.COMPLETED, null),
    )

    selectDashboardProductionOrders(orders, range, zone) shouldContainExactlyInAnyOrder listOf(
      "in-progress",
      "completed-at-start",
      "completed-at-end",
      "completed-after",
    )
  }

  @Test
  fun `returns zero progress when nothing is allocated`() {
    dashboardProgressPercentage(cumulativeOutputQty = 12, allocatedQty = 0) shouldBe 0.0
    dashboardProgressPercentage(cumulativeOutputQty = 25, allocatedQty = 100) shouldBe 25.0
  }

  @Test
  fun `resolveProductionProgressDateRange expands to 7 days when dayCount is fewer than 7`() {
    val singleDay = DashboardDateRange(LocalDate.of(2026, 4, 10), LocalDate.of(2026, 4, 10))
    resolveProductionProgressDateRange(singleDay) shouldBe DashboardDateRange(
      LocalDate.of(2026, 4, 4),
      LocalDate.of(2026, 4, 10),
    )

    val threeDays = DashboardDateRange(LocalDate.of(2026, 4, 8), LocalDate.of(2026, 4, 10))
    resolveProductionProgressDateRange(threeDays) shouldBe DashboardDateRange(
      LocalDate.of(2026, 4, 4),
      LocalDate.of(2026, 4, 10),
    )

    val sixDays = DashboardDateRange(LocalDate.of(2026, 4, 5), LocalDate.of(2026, 4, 10))
    resolveProductionProgressDateRange(sixDays) shouldBe DashboardDateRange(
      LocalDate.of(2026, 4, 4),
      LocalDate.of(2026, 4, 10),
    )
  }

  @Test
  fun `resolveProductionProgressDateRange preserves date range when dayCount is 7 or more`() {
    val sevenDays = DashboardDateRange(LocalDate.of(2026, 4, 4), LocalDate.of(2026, 4, 10))
    resolveProductionProgressDateRange(sevenDays) shouldBe sevenDays

    val fourteenDays = DashboardDateRange(LocalDate.of(2026, 4, 1), LocalDate.of(2026, 4, 14))
    resolveProductionProgressDateRange(fourteenDays) shouldBe fourteenDays
  }

  private fun instant(date: String): Instant =
    LocalDate.parse(date).atStartOfDay(zone).toInstant()
}
