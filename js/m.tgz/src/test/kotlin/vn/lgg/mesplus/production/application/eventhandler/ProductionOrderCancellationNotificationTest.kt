package vn.lgg.mesplus.production.application.eventhandler

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.notification.Notification
import vn.lgg.mesplus.notification.NotificationRepository
import vn.lgg.mesplus.notification.SseEmitters
import vn.lgg.mesplus.notification.SseNotifier
import vn.lgg.mesplus.production.domain.event.ProductionOrderCancelled
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService
import io.mockk.verify
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.shared.Notifier

class ProductionOrderCancellationNotificationTest {
  @Test
  fun `notifies viewers once including the cancelling actor`() {
    val orders = mockk<ProductionOrderRepository>()
    val assignments = mockk<TeamAssignmentRepository>()
    val permissions = mockk<PermissionService>()
    val notifications = mockk<NotificationRepository>()
    val saved = mutableListOf<Notification>()
    val actor = ActorRef("actor", "Planner")
    val order = ProductionOrder("lsx", "bo", "LSX-1", listOf("f1", "f2"), "MAIN", ProductionOrderStatus.CANCELLED)
    every { orders.findById("lsx") } returns order
    every { assignments.findByProductionOrderId("lsx") } returns listOf(mockk {
      every { teamId } returns "team"
    })
    every { permissions.lookupAccountIds(any(), any()) } returns listOf("viewer", "actor")
    every { permissions.lookupAccountIds(Permission.REPORT_PROGRESS, "team") } returns listOf("worker", "viewer")
    every { notifications.saveAll(any()) } answers { firstArg<List<Notification>>().also { saved.addAll(it) } }
    val handler = ProductionOrderCancelledNotificationHandler(orders, assignments, permissions,
      SseNotifier(notifications, mockk<SseEmitters>(relaxed = true)))
    handler.handle(ProductionOrderCancelled("lsx", actor))
    saved.map { it.recipientId }.toSet() shouldBe setOf("viewer", "actor", "worker")
    saved.size shouldBe 3
    saved.first().activity.target.resourceType shouldBe ResourceType.PRODUCTION_ORDER
    saved.first().activity.target.resourceId shouldBe "lsx"
    saved.first().activity.body shouldBe "đã hủy LSX LSX-1"
  }

  @Test
  fun `late issue and revision notifications do not request work on cancelled orders`() {
    val orders = mockk<ProductionOrderRepository>()
    val assignments = mockk<TeamAssignmentRepository>()
    val notifier = mockk<Notifier>()
    every { orders.findById("lsx") } returns
      ProductionOrder("lsx", "bo", "LSX-1", listOf("factory"), "MAIN", ProductionOrderStatus.CANCELLED)
    every { assignments.findById("ta") } returns mockk {
      every { productionOrderId } returns "lsx"
      every { teamId } returns "team"
    }
    val creator = ProductionOrderIssuedNotificationCreator(assignments, orders,
      mockk<BuyerOrderRepository>(relaxed = true),
      mockk<PermissionService>(relaxed = true), notifier)
    creator.createTeamNotification("ta", ActorRef("actor", "Planner"))
    creator.createCostingNotification("lsx", listOf("ta"), ActorRef("actor", "Planner"))
    creator.createAllocationRevisionNotification("ta", ActorRef("actor", "Planner"))
    verify(exactly = 0) { notifier.notify(any<Collection<String>>(), any(), any()) }
  }
}
