package vn.lgg.mesplus.order.application.usecase

import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import io.mockk.slot
import io.kotest.matchers.shouldBe
import io.kotest.assertions.throwables.shouldThrow
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.util.IdGenerator
import vn.lgg.mesplus.order.application.usecase.command.PoItem
import vn.lgg.mesplus.order.application.usecase.command.SkuQuantity
import vn.lgg.mesplus.order.application.usecase.command.UpsertBuyerOrderCommand
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderAdjustmentRequired
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.repository.StyleRepository
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.SkuQuantity as DomainSkuQuantity

class UpsertBuyerOrderNotificationTest {
  private val styleRepository = mockk<StyleRepository>()
  private val buyerOrderRepository = mockk<BuyerOrderRepository>()
  private val purchaseOrderRepository = mockk<PurchaseOrderRepository>()
  private val allocationQueryService = mockk<AllocationQueryService>()
  private val eventPublisher = mockk<DomainEventPublisher>()
  private val useCase =
    UpsertBuyerOrderUseCase(
      styleRepository,
      buyerOrderRepository,
      purchaseOrderRepository,
      mockk<IdGenerator>(),
      allocationQueryService,
      eventPublisher,
    )

  @BeforeEach
  fun setUp() {
    every { styleRepository.existsByName("STYLE") } returns true
    every { buyerOrderRepository.findByWfxId("BO001") } returns buyerOrder()
    every { buyerOrderRepository.lockById("bo-1") } returns buyerOrder()
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(purchaseOrder(100))
    justRun { buyerOrderRepository.save(any()) }
    justRun { purchaseOrderRepository.saveAll(any(), any()) }
    justRun { eventPublisher.publish(any<BuyerOrderAdjustmentRequired>()) }
  }

  @Test
  fun `publishes system event when WFX sync first makes buyer order need adjustment`() {
    every { allocationQueryService.needsAdjustment("bo-1", any()) } returnsMany
      listOf(false, true)

    useCase.execute(command(80))

    verify(exactly = 1) {
      eventPublisher.publish(
        match<BuyerOrderAdjustmentRequired> {
          it.buyerOrderId == "bo-1" && it.buyerOrderCode == "BO001" && it.actor == null
        }
      )
    }
  }

  @Test
  fun `does not publish again while buyer order still needs adjustment`() {
    every { allocationQueryService.needsAdjustment("bo-1", any()) } returns true

    useCase.execute(command(80))

    verify(exactly = 0) { eventPublisher.publish(any<BuyerOrderAdjustmentRequired>()) }
  }

  @Test
  fun `keeps positive PO in BO total but excludes it from WFX snapshot save`() {
    val positive = PurchaseOrder(
      id = "po-positive", wfxId = null, code = "PO+1", destination = "US",
      deliveryDate = LocalDate.of(2026, 1, 1),
      skuQties = listOf(DomainSkuQuantity(Color("Red"), Size("S"), 5)),
      buyerOrderId = "bo-1", type = PurchaseOrderType.POSITIVE,
    )
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(purchaseOrder(100), positive)
    every { allocationQueryService.needsAdjustment("bo-1", any()) } returns false
    val savedBo = slot<BuyerOrder>()
    val syncedPos = slot<List<PurchaseOrder>>()
    every { buyerOrderRepository.save(capture(savedBo)) } returns Unit
    every { purchaseOrderRepository.saveAll("bo-1", capture(syncedPos)) } returns Unit

    useCase.execute(command(80))

    savedBo.captured.totalQuantity shouldBe 85
    syncedPos.captured.map { it.code } shouldBe listOf("PO-1")
  }

  @Test
  fun `retains po id and updates po code when WFX po code changes but wfxId remains same`() {
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(purchaseOrder(100))
    every { allocationQueryService.needsAdjustment("bo-1", any()) } returns false
    val syncedPos = slot<List<PurchaseOrder>>()
    every { purchaseOrderRepository.saveAll("bo-1", capture(syncedPos)) } returns Unit

    val updateCmd = UpsertBuyerOrderCommand(
      wfxId = "BO001",
      styleName = "STYLE",
      purchaseOrders = listOf(
        PoItem(
          wfxId = "WFX-PO-1",
          code = "PO-1-RENAMED",
          destination = "US",
          deliveryDate = LocalDate.of(2026, 1, 1),
          skuQuantities = listOf(SkuQuantity(Color("Red"), Size("S"), 100)),
        )
      ),
    )

    useCase.execute(updateCmd)

    syncedPos.captured.size shouldBe 1
    val updatedPo = syncedPos.captured.single()
    updatedPo.id shouldBe "po-1"
    updatedPo.wfxId shouldBe "WFX-PO-1"
    updatedPo.code shouldBe "PO-1-RENAMED"
  }

  @Test
  fun `keeps split POs with the same display code separate across syncs`() {
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      purchaseOrder(100, id = "po-2", wfxId = "WFX-PO-2"),
      purchaseOrder(100),
    )
    every { allocationQueryService.needsAdjustment("bo-1", any()) } returns false
    val syncedPos = slot<List<PurchaseOrder>>()
    every { purchaseOrderRepository.saveAll("bo-1", capture(syncedPos)) } returns Unit
    val item = command(100).purchaseOrders.single()

    useCase.execute(command(100).copy(purchaseOrders = listOf(
      item, item.copy(wfxId = "WFX-PO-2", skuQuantities = command(50).purchaseOrders.single().skuQuantities),
    )))

    syncedPos.captured.map { it.id } shouldBe listOf("po-1", "po-2")
    syncedPos.captured.map { it.totalQuantity } shouldBe listOf(100, 50)
  }

  @Test
  fun `does not match a legacy PO by code before the exact WFX identity`() {
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      purchaseOrder(100, id = "legacy", wfxId = null), purchaseOrder(100),
    )
    every { allocationQueryService.needsAdjustment("bo-1", any()) } returns false
    val syncedPos = slot<List<PurchaseOrder>>()
    every { purchaseOrderRepository.saveAll("bo-1", capture(syncedPos)) } returns Unit

    useCase.execute(command(100))

    syncedPos.captured.single().id shouldBe "po-1"
  }

  @Test
  fun `creates a new identity when another WFX PO reuses the display code`() {
    every { allocationQueryService.needsAdjustment("bo-1", any()) } returns false
    val syncedPos = slot<List<PurchaseOrder>>()
    every { purchaseOrderRepository.saveAll("bo-1", capture(syncedPos)) } returns Unit
    val item = command(100).purchaseOrders.single().copy(wfxId = "WFX-PO-2")

    useCase.execute(command(100).copy(purchaseOrders = listOf(item)))

    (syncedPos.captured.single().id != "po-1") shouldBe true
    syncedPos.captured.single().wfxId shouldBe "WFX-PO-2"
  }

  @Test
  fun `rejects missing or duplicate WFX identities before saving`() {
    val item = command(100).purchaseOrders.single()
    for (wfxId in listOf(null, "", " ")) {
      shouldThrow<IllegalArgumentException> {
        useCase.execute(command(100).copy(purchaseOrders = listOf(item.copy(wfxId = wfxId))))
      }
    }
    shouldThrow<IllegalArgumentException> {
      useCase.execute(command(100).copy(purchaseOrders = listOf(item, item.copy(code = "OTHER"))))
    }
    verify(exactly = 0) { purchaseOrderRepository.saveAll(any(), any()) }
  }

  private fun command(quantity: Int) =
    UpsertBuyerOrderCommand(
      wfxId = "BO001",
      styleName = "STYLE",
      purchaseOrders =
        listOf(
          PoItem(
            wfxId = "WFX-PO-1",
            code = "PO-1",
            destination = "US",
            deliveryDate = LocalDate.of(2026, 1, 1),
            skuQuantities = listOf(SkuQuantity(Color("Red"), Size("S"), quantity)),
          )
        ),
    )

  private fun buyerOrder() =
    BuyerOrder("bo-1", "BO001", "STYLE", "1", Instant.parse("2026-01-01T00:00:00Z"))

  private fun purchaseOrder(quantity: Int, id: String = "po-1", wfxId: String? = "WFX-PO-1") =
    PurchaseOrder(
      id = id,
      wfxId = wfxId,
      code = "PO-1",
      destination = "US",
      deliveryDate = LocalDate.of(2026, 1, 1),
      skuQties =
        listOf(DomainSkuQuantity(Color("Red"), Size("S"), quantity)),
      buyerOrderId = "bo-1",
    )
}
