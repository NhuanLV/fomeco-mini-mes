package vn.lgg.mesplus.iam.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.util.UUID
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.util.IdGenerator
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.Warehouse
import vn.lgg.mesplus.iam.domain.repository.FactoryOperationRepository
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

class WarehouseUseCaseTest {
  private val orgUnitRepo = mockk<OrgUnitRepository>()
  private val factoryOperationRepo = mockk<FactoryOperationRepository>()
  private val permissionService = mockk<PermissionService>()
  private val idGenerator = mockk<IdGenerator>()
  private val actor = Actor("actor-1", "Admin", "admin", "", emptyList(), emptySet())

  private val createUseCase = CreateWarehouseUseCase(orgUnitRepo, permissionService, idGenerator)
  private val updateUseCase = UpdateWarehouseUseCase(orgUnitRepo, permissionService)
  private val deleteUseCase = DeleteWarehouseUseCase(orgUnitRepo, factoryOperationRepo, permissionService)

  @BeforeEach
  fun setUp() {
    justRun { permissionService.requirePermission(actor, listOf(Permission.MANAGE_ORG), any()) }
    every { orgUnitRepo.findById("company-1") } returns
      Company("company-1", "Company", "corporation-1", "", code = "COMP-1")
    every { orgUnitRepo.existsByCode(any(), any()) } returns false
    every { orgUnitRepo.existsByCode(any()) } returns false
    every { idGenerator.generateId() } returns UUID.fromString("11111111-1111-1111-1111-111111111111")
    justRun { orgUnitRepo.save(any()) }
  }

  @Test
  fun `creates warehouse with four nullable combinations and trims whitespace`() {
    val savedSlots = mutableListOf<Warehouse>()
    justRun { orgUnitRepo.save(capture(savedSlots)) }

    // 1. Cả 2 rỗng/blank -> null
    createUseCase.execute(
      CreateWarehouseCommand("Kho 1", "WH-1", "Address", "company-1", true, "   ", null),
      actor,
    )
    savedSlots[0].siteName shouldBe null
    savedSlots[0].siteCode shouldBe null

    // 2. Chỉ có siteName
    createUseCase.execute(
      CreateWarehouseCommand("Kho 2", "WH-2", "Address", "company-1", true, "  Site Name A  ", ""),
      actor,
    )
    savedSlots[1].siteName shouldBe "Site Name A"
    savedSlots[1].siteCode shouldBe null

    // 3. Chỉ có siteCode
    createUseCase.execute(
      CreateWarehouseCommand("Kho 3", "WH-3", "Address", "company-1", true, null, "  SITE_CODE_B  "),
      actor,
    )
    savedSlots[2].siteName shouldBe null
    savedSlots[2].siteCode shouldBe "SITE_CODE_B"

    // 4. Có cả hai
    createUseCase.execute(
      CreateWarehouseCommand("Kho 4", "WH-4", "Address", "company-1", true, " Site Name ", " SITE_CODE "),
      actor,
    )
    savedSlots[3].siteName shouldBe "Site Name"
    savedSlots[3].siteCode shouldBe "SITE_CODE"
  }

  @Test
  fun `updates warehouse trimming siteName and siteCode`() {
    val warehouse = Warehouse(
      id = "wh-1",
      name = "Kho 1",
      parentId = "company-1",
      address = "Old Address",
      companyId = "company-1",
      isActive = true,
      code = "WH-1",
      siteName = "Old Site",
      siteCode = "OLD_CODE",
    )
    every { orgUnitRepo.findById("wh-1") } returns warehouse

    updateUseCase.execute(
      "wh-1",
      UpdateWarehouseCommand(
        name = "Kho 1 Moi",
        code = "WH-1",
        address = "New Address",
        isActive = true,
        siteName = "  New Site Name  ",
        siteCode = "   ",
      ),
      actor,
    )

    warehouse.siteName shouldBe "New Site Name"
    warehouse.siteCode shouldBe null
  }

  @Test
  fun `cannot delete warehouse referenced by mapping`() {
    val warehouse = Warehouse(
      id = "wh-1",
      name = "Kho Đang Dùng",
      parentId = "company-1",
      address = "",
      companyId = "company-1",
      isActive = true,
      code = "WH-1",
    )
    every { orgUnitRepo.findById("wh-1") } returns warehouse
    every { factoryOperationRepo.isWarehouseReferenced("wh-1") } returns true

    val ex = shouldThrow<IllegalStateException> {
      deleteUseCase.execute("wh-1", actor)
    }
    ex.message shouldBe "Không thể xóa kho 'Kho Đang Dùng' vì đang được dùng trong mapping công đoạn"
    verify(exactly = 0) { orgUnitRepo.delete(any()) }
  }

  @Test
  fun `deletes warehouse when not referenced by any mapping`() {
    val warehouse = Warehouse(
      id = "wh-free",
      name = "Kho Tự Do",
      parentId = "company-1",
      address = "",
      companyId = "company-1",
      isActive = true,
      code = "WH-FREE",
    )
    every { orgUnitRepo.findById("wh-free") } returns warehouse
    every { factoryOperationRepo.isWarehouseReferenced("wh-free") } returns false
    justRun { orgUnitRepo.delete("wh-free") }

    deleteUseCase.execute("wh-free", actor)
    verify(exactly = 1) { orgUnitRepo.delete("wh-free") }
  }
}
