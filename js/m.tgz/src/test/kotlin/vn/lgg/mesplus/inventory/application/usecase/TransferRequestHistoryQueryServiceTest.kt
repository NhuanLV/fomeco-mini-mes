package vn.lgg.mesplus.inventory.application.usecase

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.kotest.matchers.maps.shouldContainExactly
import io.mockk.every
import io.mockk.mockk
import java.math.BigDecimal
import java.time.Instant
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestAssignmentInitialized
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestAssignmentInitialized.AssignmentItem
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestCreated
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestMaterialReceived
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestMaterialReceived.ReceivedItem
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestRejected
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestUpdated
import vn.lgg.mesplus.inventory.domain.model.transferrequest.TransferRequest
import vn.lgg.mesplus.inventory.domain.model.transferrequest.TransferRequestAssignment
import vn.lgg.mesplus.inventory.domain.model.transferrequest.TransferRequestItem
import vn.lgg.mesplus.inventory.domain.model.transferrequest.TransferRequestStatus
import vn.lgg.mesplus.inventory.domain.repository.TransferRequestAssignmentRepository
import vn.lgg.mesplus.inventory.domain.repository.TransferRequestRepository
import vn.lgg.mesplus.inventory.infrastructure.repository.TransferRequestViewRepository
import vn.lgg.mesplus.inventory.presentation.viewmodel.TransferRequestDetailVm
import vn.lgg.mesplus.inventory.presentation.viewmodel.TransferRequestItemVm
import vn.lgg.mesplus.production.infrastructure.repository.TeamAssignmentViewRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.ActorRef

class TransferRequestHistoryQueryServiceTest {
  private val requestRepository = mockk<TransferRequestRepository>()
  private val assignmentRepository = mockk<TransferRequestAssignmentRepository>()
  private val viewRepository = mockk<TransferRequestViewRepository>()
  private val teamAssignmentViewRepository = mockk<TeamAssignmentViewRepository>()
  private val queryService = mockk<TransferRequestQueryService>()
  private val service =
    TransferRequestHistoryQueryService(
      requestRepository,
      assignmentRepository,
      viewRepository,
      teamAssignmentViewRepository,
      queryService,
    )
  private val actor = Actor("actor-1", "Planner", "planner", "", emptyList(), emptySet())
  private val actorRef = ActorRef(actor.id, actor.name)
  private val createdAt = Instant.parse("2026-03-01T00:00:00Z")
  private val rejectedAt = Instant.parse("2026-03-02T00:00:00Z")
  private val updatedAt = Instant.parse("2026-03-03T00:00:00Z")

  @Test
  fun `maps full item summaries and returns oldest event first`() {
    every { queryService.hasFullAccess(actor, any(), any()) } answers { secondArg<String>() == actor.id }
    val request =
      TransferRequest("request-1").apply {
        loadFromHistory(
          listOf(
            TransferRequestCreated(
              transferRequestId = "request-1",
              sourceTeamAssignmentId = "source-1",
              items = listOf(item("5")),
              actor = actorRef,
              occurredAt = createdAt,
            ),
            TransferRequestRejected(
              transferRequestId = "request-1",
              reason = "adjust",
              actor = actorRef,
              occurredAt = rejectedAt,
            ),
            TransferRequestUpdated(
              transferRequestId = "request-1",
              newItems = listOf(item("8")),
              actor = actorRef,
              occurredAt = updatedAt,
            ),
          ),
        )
      }
    val detail = view()
    every { requestRepository.findById("request-1") } returns request
    every { viewRepository.findById("request-1") } returns detail
    every { queryService.getTransferRequestDetail("request-1", actor) } returns detail
    every { assignmentRepository.findAllByTransferRequestId("request-1") } returns emptyList()
    every { teamAssignmentViewRepository.findDetailVm("target-1") } returns null

    val history = service.getHistory("request-1", actor)

    history.map { it.type } shouldContainExactly
      listOf("TransferRequestCreated", "TransferRequestRejected", "TransferRequestRevised")
    history.first().detail.shouldContainExactly(
      mapOf("MAT-1 / RED / M -> target-1" to "5 kg"),
    )
    history.last().detail.shouldContainExactly(
      mapOf("MAT-1 / RED / M -> target-1" to "8 kg"),
    )
  }

  @Test
  fun `limits assignment history to targets visible through request detail`() {
    every { queryService.hasFullAccess(actor, any(), any()) } answers { secondArg<String>() == actor.id }
    val request =
      TransferRequest("request-1").apply {
        loadFromHistory(
          listOf(
            TransferRequestCreated(
              transferRequestId = "request-1",
              sourceTeamAssignmentId = "source-1",
              items = listOf(item("5"), item("9").copy(targetTeamAssignmentId = "target-2")),
              actor = actorRef,
              occurredAt = createdAt,
            ),
          ),
        )
      }
    val visibleDetail = view(createdById = "other")
    every { requestRepository.findById("request-1") } returns request
    every { viewRepository.findById("request-1") } returns visibleDetail
    every { queryService.getTransferRequestDetail("request-1", actor) } returns visibleDetail
    every { assignmentRepository.findAllByTransferRequestId("request-1") } returns
      listOf(assignment("target-1", "5"), assignment("target-2", "9"))
    every { teamAssignmentViewRepository.findDetailVm("target-1") } returns null

    val history = service.getHistory("request-1", actor)
    history.first { it.type == "TransferRequestCreated" }.detail.size shouldBe 1

    history.filter { it.type == "TransferRequestMaterialReceived" }
      .single()
      .detail
      .shouldContainExactly(mapOf("MAT-1 / RED / M -> target-1" to "5"))
  }

  private fun item(quantity: String) =
    TransferRequestItem(
      targetTeamAssignmentId = "target-1",
      article = "MAT-1",
      color = "RED",
      size = "M",
      uom = "kg",
      quantity = BigDecimal(quantity),
    )

  private fun assignment(targetId: String, quantity: String) =
    TransferRequestAssignment("request-1", targetId).apply {
      loadFromHistory(
        listOf(
          TransferRequestAssignmentInitialized(
            "request-1",
            targetId,
            listOf(AssignmentItem("MAT-1", "RED", "M", "kg", BigDecimal(quantity))),
            actorRef,
          ),
          TransferRequestMaterialReceived(
            "request-1",
            targetId,
            listOf(ReceivedItem("MAT-1", "RED", "M", BigDecimal(quantity))),
            actorRef,
          ),
        ),
      )
    }

  private fun view(createdById: String = actor.id) =
    TransferRequestDetailVm(
      id = "request-1",
      sourceTeamAssignmentId = "source-1",
      status = TransferRequestStatus.PENDING_APPROVAL,
      items =
        listOf(
          TransferRequestItemVm(
            targetTeamAssignmentId = "target-1",
            targetTeamName = "Target",
            article = "MAT-1",
            color = "RED",
            size = "M",
            uom = "kg",
            quantity = BigDecimal("8"),
          ),
        ),
      rejectReason = null,
      createdAt = createdAt,
      createdById = createdById,
      createdByName = actor.name,
    )
}
