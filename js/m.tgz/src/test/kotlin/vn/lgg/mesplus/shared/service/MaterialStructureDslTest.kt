package vn.lgg.mesplus.shared.service

import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import java.math.BigDecimal
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.MaterialColorDep
import vn.lgg.mesplus.shared.model.MaterialSizeDep
import vn.lgg.mesplus.shared.model.Size

class MaterialStructureDslTest : StringSpec({
  val firstSize = MaterialSizeDep(Size("M-MAT"), Size("M"), BigDecimal("1.5"))
  val secondSize = MaterialSizeDep(Size("L-MAT"), Size("L"), BigDecimal("1.7"))
  val color = MaterialColorDep(Color("NAVY-MAT"), Color("NAVY"), BigDecimal("2"))

  "builds typed dependencies in declaration order" {
    val dependencies =
      materialDependencies {
        sizes += listOf(firstSize, secondSize)
        colors += color
        destinations += listOf("US", "EU")
      }

    dependencies.sizes shouldContainExactly listOf(firstSize, secondSize)
    dependencies.colors shouldContainExactly listOf(color)
    dependencies.destinations shouldContainExactly listOf("US", "EU")
  }

  "builds a material line and snapshots mutable input collections" {
    val inputSizes = mutableListOf(firstSize)

    val line =
      materialLine("FABRIC") {
        sizes += inputSizes
        colors += color
        destinations += "US"
      }
    inputSizes += secondSize

    line.material shouldBe "FABRIC"
    line.sizeDeps shouldContainExactly listOf(firstSize)
    line.colorDeps shouldContainExactly listOf(color)
    line.destinations shouldContainExactly listOf("US")
  }
})
