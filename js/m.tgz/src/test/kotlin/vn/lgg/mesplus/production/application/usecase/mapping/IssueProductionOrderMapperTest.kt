package vn.lgg.mesplus.production.application.usecase.mapping

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import java.math.BigDecimal
import java.time.LocalDate
import java.util.UUID
import org.junit.jupiter.api.Test
import org.springframework.util.IdGenerator
import vn.lgg.mesplus.order.domain.model.BillOfMaterial
import vn.lgg.mesplus.order.domain.model.BuyerOrderMaterial
import vn.lgg.mesplus.order.domain.model.OperationUsage
import vn.lgg.mesplus.production.application.usecase.command.IssueProductionOrderCommand
import vn.lgg.mesplus.production.application.usecase.command.ProductionOrderMetadataCommandData
import vn.lgg.mesplus.production.application.usecase.command.TeamAssignmentCommandData
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Material
import vn.lgg.mesplus.shared.model.MaterialColorDep
import vn.lgg.mesplus.shared.model.MaterialSizeDep
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

class IssueProductionOrderMapperTest {
  private val idGenerator = mockk<IdGenerator>()
  private val mapper = IssueProductionOrderMapper(idGenerator)
  private val actor = ActorRef("actor-1", "Planner")

  @Test
  fun `keeps issuing actor in team assignment created event`() {
    val assignmentId = UUID.fromString("00000000-0000-0000-0000-000000000001")
    every { idGenerator.generateId() } returns assignmentId
    val allocation = SkuAllocation("po-1", Color("RED"), Size("M"), 10)
    val command =
      IssueProductionOrderCommand(
        buyerOrderId = "buyer-order-1",
        factoryIds = listOf("factory-1"),
        mainCompanyCode = "LGG",
        teamAssignments = listOf(
          TeamAssignmentCommandData(
            teamId = "team-1",
            operation = "SEW-1",
            allocations = listOf(allocation),
            plannedStartDate = LocalDate.of(2026, 1, 1),
            plannedEndDate = LocalDate.of(2026, 1, 10),
          ),
        ),
        metadata = ProductionOrderMetadataCommandData(null, null, null),
      )

    val event = mapper.toTeamAssignments(command, "production-1", actor).single().allEvents.single()

    (event as TeamAssignmentCreated).actor shouldBe actor
  }

  @Test
  fun `filters BOM dependencies by assignment and applies operation consumption fallback`() {
    val materialId = UUID.fromString("00000000-0000-0000-0000-000000000010")
    every { idGenerator.generateId() } returns materialId
    val operation = Operation("SEW-1")
    val assignment =
      TeamAssignment.create(
        id = "assignment-1",
        productionOrderId = "production-1",
        buyerOrderId = "buyer-order-1",
        teamId = "team-1",
        operation = operation,
        allocations = listOf(SkuAllocation("po-1", Color("RED"), Size("M"), 10)),
        plannedStartDate = LocalDate.of(2026, 1, 1),
        plannedEndDate = LocalDate.of(2026, 1, 10),
      )
    val matching =
      BuyerOrderMaterial(
        material = Material("FABRIC", "MAIN", "kg"),
        sizeDeps =
          listOf(
            MaterialSizeDep(Size("M-MAT"), Size("M"), BigDecimal.ZERO),
            MaterialSizeDep(Size("L-MAT"), Size("L"), BigDecimal("3")),
          ),
        colorDeps =
          listOf(
            MaterialColorDep(Color("RED-MAT"), Color("RED")),
            MaterialColorDep(Color("BLUE-MAT"), Color("BLUE")),
          ),
        usedForOperations = listOf(OperationUsage(operation, BigDecimal("1.25"))),
        usedForDestinations = listOf("US"),
      )
    val ignored =
      matching.copy(
        material = Material("ZIPPER", "TRIM", "piece"),
        usedForOperations = listOf(OperationUsage(Operation("CUT-1"), BigDecimal.ONE)),
      )

    val result =
      mapper.toTeamBomLines(
        assignment,
        BillOfMaterial("buyer-order-1", listOf(matching, ignored)),
        actor,
      ).single()

    result.id shouldBe materialId.toString()
    result.teamAssignmentId shouldBe assignment.id
    result.material shouldBe matching.material
    result.sizeDeps.shouldContainExactly(
      MaterialSizeDep(Size("M-MAT"), Size("M"), BigDecimal("1.25")),
    )
    result.colorDeps.shouldContainExactly(
      MaterialColorDep(Color("RED-MAT"), Color("RED")),
    )
    result.destinationCodes shouldContainExactly listOf("US")
    result.lastUpdatedBy shouldBe actor
  }
}
