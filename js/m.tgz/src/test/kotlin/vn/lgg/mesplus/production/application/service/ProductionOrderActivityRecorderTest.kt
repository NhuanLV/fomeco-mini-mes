package vn.lgg.mesplus.production.application.service

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.time.LocalDate
import org.junit.jupiter.api.Test
import org.springframework.util.SimpleIdGenerator
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.production.domain.model.*
import vn.lgg.mesplus.shared.model.*

class ProductionOrderActivityRecorderTest {
  private val saved = slot<ProductionOrderActivity>()
  private val activityLog = mockk<ProductionOrderActivityLog> {
    every { append(capture(saved)) } returns Unit
  }
  private val units = mockk<OrgUnitRepository> {
    every { findById("team") } returns Team("team", "Tổ cắt", "factory", "factory", Operation("Cut"), true)
  }
  private val recorder = ProductionOrderActivityRecorder(activityLog, units, SimpleIdGenerator())
  private val actor = Actor("actor", "Người phát", "planner", "", listOf(MembershipInfo("factory", setOf("planner"))), emptySet())

  @Test
  fun `diff snapshots added removed and updated SKUs without depending on future allocations`() {
    val old = listOf(sku("A", 10), sku("B", 20), sku("D", 40))
    val assignment = TeamAssignment.create("assignment", "order", "bo", "team", Operation("Cut"), old, LocalDate.now(), LocalDate.now())
    val proposed = listOf(sku("A", 15), sku("C", 30), sku("D", 40))
    val diff = recorder.captureAllocationChanges(assignment, proposed, emptyList())
    diff.map { it.color } shouldBe listOf("A", "B", "C")
    diff.map { (it.before?.quantity ?: 0) to (it.after?.quantity ?: 0) } shouldBe listOf(10 to 15, 20 to 0, 0 to 30)
    recorder.recordRevision("order", actor, "  Điều chỉnh  ", diff, false)
    assignment.reviseAllocation(listOf(sku("A", 99)), "Sửa tiếp", actor.ref)
    saved.captured.actor shouldBe actor.ref
    saved.captured.note shouldBe "Điều chỉnh"
    saved.captured.syncStatus shouldBe ProductionOrderActivitySyncStatus.NOT_APPLICABLE
    saved.captured.changes shouldBe diff
    saved.captured.changes.first().before?.quantity shouldBe 10
  }

  @Test
  fun `no-op does not insert a revision`() {
    recorder.recordRevision("order", actor, "", emptyList(), true)
    verify(exactly = 0) { activityLog.append(any()) }
  }

  @Test
  fun `metadata-only allocation edits are included in the immutable diff`() {
    val old = sku("A", 10)
    val assignment = TeamAssignment.create("assignment", "order", "bo", "team", Operation("Cut"), listOf(old), LocalDate.now(), LocalDate.now())
    val notes = mutableListOf("Ghi chú mới")
    val diff = recorder.captureAllocationChanges(assignment, listOf(old.copy(notes = notes)), emptyList())
    notes.clear()
    diff.single().before shouldBe old
    diff.single().after?.notes shouldBe listOf("Ghi chú mới")
  }

  private fun sku(color: String, quantity: Int) = SkuAllocation("po", Color(color), Size("M"), quantity)
}
