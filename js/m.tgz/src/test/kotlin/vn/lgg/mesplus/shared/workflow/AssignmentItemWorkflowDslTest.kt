package vn.lgg.mesplus.shared.workflow

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe

class AssignmentItemWorkflowDslTest : StringSpec({
  "mustBe otherwise keeps check semantics and message" {
    (State.ACTIVE mustBe State.ACTIVE) otherwise "inactive"

    shouldThrow<IllegalStateException> {
      (State.COMPLETED mustBe State.ACTIVE) otherwise "inactive"
    }.message shouldBe "inactive"
  }

  "resolves validates and normalizes each item in input order" {
    val assigned =
      mapOf(
        "A" to Assigned(quantity = 5, available = true),
        "B" to Assigned(quantity = 7, available = true),
      )

    val result =
      (listOf(Requested("A", 99), Requested("B", 99)) resolvedBy {
        assigned.getValue(it.id)
      }) {
        ensure { _, item -> item.available } otherwise { request, _ ->
          "${request.id} is unavailable"
        }
        normalize { request, item -> request.copy(quantity = item.quantity) }
      }

    result shouldContainExactly listOf(Requested("A", 5), Requested("B", 7))
  }

  "uses original input when normalizer is absent and stops at first failed rule" {
    val visited = mutableListOf<String>()

    val error =
      shouldThrow<IllegalStateException> {
        (listOf(Requested("A", 1), Requested("B", 2)) resolvedBy {
          Assigned(quantity = it.quantity, available = it.id != "A")
        }) {
          ensure { request, item ->
            visited += request.id
            item.available
          } otherwise { request, _ -> "${request.id} is unavailable" }
        }
      }

    error.message shouldBe "A is unavailable"
    visited shouldContainExactly listOf("A")
  }
})

private enum class State {
  ACTIVE,
  COMPLETED,
}

private data class Requested(val id: String, val quantity: Int)

private data class Assigned(val quantity: Int, val available: Boolean)
