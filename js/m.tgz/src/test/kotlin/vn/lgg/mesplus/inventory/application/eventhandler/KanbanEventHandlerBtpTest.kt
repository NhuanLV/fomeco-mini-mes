package vn.lgg.mesplus.inventory.application.eventhandler

import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import java.math.BigDecimal
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.application.usecase.RecordMaterialReceivedUseCase
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialReceived
import vn.lgg.mesplus.kanban.domain.model.Kanban
import vn.lgg.mesplus.kanban.domain.model.KanbanItem
import vn.lgg.mesplus.kanban.domain.model.KanbanItemType
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.production.domain.service.BomCalculationService
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size

class KanbanEventHandlerBtpTest {
  @Test
  fun `receiving mixed Kanban only writes NPL to material inventory`() {
    val kanbans = mockk<KanbanRepository>()
    val bom = mockk<BomCalculationService>()
    val materialInventory = mockk<RecordMaterialReceivedUseCase>(relaxed = true)
    val kanban = mockk<Kanban>()
    every { kanbans.findById("kanban-1") } returns kanban
    every { kanban.teamAssignmentId } returns "assignment-1"
    every { kanban.items } returns listOf(
      item("MAT-1", KanbanItemType.MATERIAL),
      item("BTP CUT-1", KanbanItemType.SEMI_FINISHED_PRODUCT),
    )
    every { bom.getUomByArticle("assignment-1") } returns mapOf("MAT-1" to "M")

    KanbanEventHandler(kanbans, bom, materialInventory, mockk()).handleKanbanMaterialReceived(
      KanbanMaterialReceived(
        "kanban-1", "supplier-1",
        listOf(
          KanbanMaterialReceived.ReceivedItem("MAT-1", "RED", "M", "po-1", BigDecimal.ONE),
          KanbanMaterialReceived.ReceivedItem("BTP CUT-1", "RED", "M", "po-1", BigDecimal.ONE),
        ),
        null,
      )
    )

    verify(exactly = 1) {
      materialInventory.execute("assignment-1", match { it.size == 1 && it.single().article == "MAT-1" }, "kanban-1", null)
    }
  }

  @Test
  fun `cancellation restores only the original source issue`() {
    val repository = mockk<vn.lgg.mesplus.inventory.domain.repository.BtpInventoryRepository>(relaxed = true)
    val sku = vn.lgg.mesplus.inventory.domain.model.btp.BtpSku("BTP CUT", "RED", "M")
    val inventory = vn.lgg.mesplus.inventory.domain.model.btp.BtpInventory("source")
    inventory.produce(sku, BigDecimal(300), "report", null)
    inventory.issue(sku, BigDecimal(200), "kanban-1:supplier:po", null)
    inventory.issue(sku, BigDecimal(50), "other:supplier:po", null)
    every { repository.findIssuedByKanban("kanban-1") } returns
      inventory.allEvents.filterIsInstance<vn.lgg.mesplus.inventory.domain.event.btp.BtpKanbanIssued>()
        .filter { it.referenceId.startsWith("kanban-1:") }
    every { repository.lockAndLoad("source") } returns inventory

    KanbanEventHandler(mockk(), mockk(), mockk(), repository).handleKanbanCancelled(
      vn.lgg.mesplus.kanban.domain.event.KanbanCancelled("kanban-1", "Đổi kế hoạch",
        vn.lgg.mesplus.kanban.domain.model.KanbanStatus.APPROVED, null))

    org.junit.jupiter.api.Assertions.assertEquals(BigDecimal(250), inventory.balance(sku))
    verify(exactly = 1) { repository.save(inventory) }
  }

  private fun item(article: String, type: KanbanItemType) = KanbanItem(
    article, Color("RED"), Size("M"), "po-1", type, BigDecimal.ONE, "supplier-1", ""
  )
}
