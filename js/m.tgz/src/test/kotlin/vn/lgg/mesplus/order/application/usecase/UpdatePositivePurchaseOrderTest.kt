package vn.lgg.mesplus.order.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderAdjustmentRequired
import vn.lgg.mesplus.order.domain.model.BuyerOrderStatus
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.SkuQuantity

class UpdatePositivePurchaseOrderTest {
  private val boRepo = mockk<BuyerOrderRepository>(relaxed = true)
  private val poRepo = mockk<PurchaseOrderRepository>(relaxed = true)
  private val allocations = mockk<AllocationQueryService>()
  private val publisher = mockk<DomainEventPublisher>(relaxed = true)
  private val actor = Actor("planner", "Planner", "planner", "", emptyList(), emptySet())
  private val useCase = UpdatePositivePurchaseOrderUseCase(boRepo, poRepo, allocations, publisher)
  private val bo = BuyerOrder("bo-1", "BO-1", "STYLE", "1", Instant.EPOCH,
    status = BuyerOrderStatus.COMPLETED, totalQuantity = 200, completedQuantity = 80)
  private val positive = PurchaseOrder("positive", null, "POS", "US", LocalDate.of(2026, 9, 1),
    listOf(SkuQuantity(Color("Red"), Size("S"), 100)), bo.id,
    PurchaseOrderType.POSITIVE, actor.ref, Instant.EPOCH)
  private val regular = PurchaseOrder("regular", "wfx-1", "REG", "US", positive.deliveryDate,
    listOf(SkuQuantity(Color("Blue"), Size("S"), 100)), bo.id)

  private fun arrange() {
    every { boRepo.lockById(bo.id) } returns bo
    every { poRepo.findByBuyerOrderId(bo.id) } returns listOf(regular, positive)
    every { allocations.needsAdjustment(bo.id, any()) } returns false
  }

  private fun command(vararg items: Pair<String, String>) = UpdatePositivePurchaseOrderCommand(
    items.map { (color, qty) -> PositiveSkuQuantityCommand(Color(color), Size("S"), BigDecimal(qty)) },
  )

  @Test
  fun `saves reduction despite conflict and accepts another BO color without changing PO metadata`() {
    arrange()
    every { allocations.needsAdjustment(bo.id, any()) } returnsMany listOf(false, true)

    useCase.execute(bo.id, positive.id, command("Red" to "60", "Blue" to "5"), actor)

    verify { poRepo.updateSkuQuantities(positive.id, listOf(
      SkuQuantity(Color("Red"), Size("S"), 60), SkuQuantity(Color("Blue"), Size("S"), 5),
    )) }
    verify(exactly = 0) { poRepo.save(any()) }
    verify { publisher.publish(match<BuyerOrderAdjustmentRequired> { it.actor == actor.ref }) }
    bo.totalQuantity shouldBe 165
    bo.completedQuantity shouldBe 80
    bo.status shouldBe BuyerOrderStatus.PROCESSING
    positive.createdAt shouldBe Instant.EPOCH
  }

  @Test
  fun `rejects regular PO foreign PO and invalid quantities`() {
    arrange()
    shouldThrow<IllegalArgumentException> { useCase.execute(bo.id, regular.id, command("Blue" to "1"), actor) }
    shouldThrow<NoSuchElementException> { useCase.execute(bo.id, "foreign", command("Red" to "1"), actor) }
    for (invalid in listOf(
      command("Red" to "0"), command("Red" to "-1"), command("Red" to "1.5"),
      command("Green" to "1"), command("Red" to "2147483648"), command("Red" to "1", "Red" to "2"),
    )) {
      shouldThrow<IllegalArgumentException> { useCase.execute(bo.id, positive.id, invalid, actor) }
    }
    verify(exactly = 0) { poRepo.updateSkuQuantities(any(), any()) }
  }

  @Test
  fun `omits zero SKU and does not repeat notification for existing conflict`() {
    arrange()
    every { allocations.needsAdjustment(bo.id, any()) } returns true

    useCase.execute(bo.id, positive.id, command("Red" to "0", "Blue" to "20"), actor)

    verify { poRepo.updateSkuQuantities(positive.id, listOf(SkuQuantity(Color("Blue"), Size("S"), 20))) }
    verify(exactly = 0) { publisher.publish(any<BuyerOrderAdjustmentRequired>()) }
    bo.totalQuantity shouldBe 120
  }
}
