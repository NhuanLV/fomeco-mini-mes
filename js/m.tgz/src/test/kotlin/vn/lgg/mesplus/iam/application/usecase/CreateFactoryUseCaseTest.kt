package vn.lgg.mesplus.iam.application.usecase

import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import java.util.UUID
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.util.IdGenerator
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

class CreateFactoryUseCaseTest {
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val permissionService = mockk<PermissionService>()
  private val idGenerator = mockk<IdGenerator>()
  private val actor = Actor("actor-1", "Admin", "admin", "", emptyList(), emptySet())
  private val useCase =
    CreateFactoryUseCase(orgUnitRepository, permissionService, idGenerator)

  @BeforeEach
  fun setUp() {
    every { orgUnitRepository.findById("company-1") } returns
      Company("company-1", "Company", "corporation-1", "", code = "COMP-1")
    justRun { permissionService.requirePermission(actor, listOf(Permission.MANAGE_ORG), any()) }
  }

  @Test
  fun `creates factory without operation selection`() {
    every { orgUnitRepository.existsByCode("FACTORY-1") } returns false
    every { idGenerator.generateId() } returns UUID.fromString("11111111-1111-1111-1111-111111111111")
    justRun { orgUnitRepository.save(any()) }

    useCase.execute(command(), actor)
  }

  private fun command() = CreateFactoryCommand("Factory", "FACTORY-1", "", "company-1", true)
}
