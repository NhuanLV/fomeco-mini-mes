package vn.lgg.mesplus.inventory.domain.model.returnrequest

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import java.math.BigDecimal
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestRejected
import vn.lgg.mesplus.inventory.domain.event.returnrequest.ReturnRequestUpdated
import vn.lgg.mesplus.shared.model.ActorRef

class ReturnRequestTest {
  private val actor = ActorRef("actor-1", "Planner")

  @Test
  fun `create validates items in empty duplicate then quantity order`() {
    shouldThrow<IllegalArgumentException> {
      ReturnRequest.create("request-1", "source-1", emptyList(), actor)
    }.message shouldBe "Danh sách vật tư không được để trống"

    shouldThrow<IllegalArgumentException> {
      ReturnRequest.create(
        "request-1",
        "source-1",
        listOf(item("MAT-1", "1"), item("MAT-1", "0")),
        actor,
      )
    }.message shouldBe "Danh sách vật tư không hợp lệ (trùng mã)"

    shouldThrow<IllegalArgumentException> {
      ReturnRequest.create("request-1", "source-1", listOf(item("MAT-1", "0")), actor)
    }.message shouldBe "Số lượng phải lớn hơn 0"
  }

  @Test
  fun `reject update and approve preserve event payload and state transitions`() {
    val request =
      ReturnRequest.create(
        "request-1",
        "source-1",
        listOf(item("MAT-1", "1")),
        actor,
      )
    request.status shouldBe ReturnRequestStatus.PENDING_APPROVAL

    shouldThrow<IllegalArgumentException> {
      request.reject("", actor)
    }.message shouldBe "Vui lòng nhập lý do từ chối"

    request.reject("adjust", actor)
    request.status shouldBe ReturnRequestStatus.REJECTED
    request.changes.filterIsInstance<ReturnRequestRejected>().single().reason shouldBe "adjust"

    val replacement = item("MAT-2", "3")
    request.update(listOf(replacement), actor)
    request.status shouldBe ReturnRequestStatus.PENDING_APPROVAL
    request.items.shouldContainExactly(replacement)
    request.changes.filterIsInstance<ReturnRequestUpdated>()
      .single()
      .newItems
      .shouldContainExactly(replacement)

    request.approve(actor)
    request.status shouldBe ReturnRequestStatus.APPROVED
  }

  @Test
  fun `actions enforce current state with existing messages`() {
    val request =
      ReturnRequest.create("request-1", "source-1", listOf(item("MAT-1", "1")), actor)
    request.approve(actor)

    shouldThrow<IllegalStateException> {
      request.reject("late", actor)
    }.message shouldBe "Chỉ có thể từ chối yêu cầu ở trạng thái PENDING_APPROVAL"

    shouldThrow<IllegalStateException> {
      request.update(listOf(item("MAT-2", "2")), actor)
    }.message shouldBe "Chỉ có thể cập nhật yêu cầu đã bị từ chối"
  }

  private fun item(article: String, quantity: String) =
    ReturnRequestItem(
      article = article,
      color = "RED",
      size = "M",
      uom = "kg",
      quantity = BigDecimal(quantity),
      receiverId = "warehouse-1",
    )
}
