package vn.lgg.mesplus.inventory.domain.event.material

import io.kotest.matchers.shouldBe
import java.time.Instant
import org.junit.jupiter.api.Test
import tools.jackson.databind.json.JsonMapper
import vn.lgg.mesplus.app.config.JacksonConfig
import vn.lgg.mesplus.shared.DomainEvent

class MaterialInventoryEventJsonTest {
  @Test
  fun `renamed material events preserve stored event names`() {
    val builder = JsonMapper.builder()
    JacksonConfig().jsonCustomizer().customize(builder)
    val mapper = builder.build()
    val occurredAt = Instant.parse("2026-10-06T00:00:00Z")
    val events = listOf(
      "InventoryMaterialReceived" to MaterialInventoryReceived(
        "assignment", emptyList(), "reference", occurredAt, null,
      ),
      "InventoryMaterialIssued" to MaterialInventoryIssued(
        "assignment", emptyList(), "reference", occurredAt, null,
      ),
    )

    events.forEach { (storedName, event) ->
      val historicalJson = """{"eventName":"$storedName","teamAssignmentId":"assignment","items":[],"referenceId":"reference","occurredAt":"2026-10-06T00:00:00Z","actor":null}"""
      mapper.readValue(historicalJson, DomainEvent::class.java) shouldBe event
      val json = mapper.writeValueAsString(event)
      mapper.readTree(json).get("eventName").stringValue() shouldBe storedName
      mapper.readValue(json, DomainEvent::class.java) shouldBe event
    }
  }
}
