package vn.lgg.mesplus.order.application.usecase

import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.model.BoMaterialStateUpdate
import vn.lgg.mesplus.order.domain.repository.BoMaterialStateRepository
import vn.lgg.mesplus.production.domain.repository.TeamMaterialRepository
import vn.lgg.mesplus.shared.model.Actor

class UpdateBoMaterialStatesUseCaseTest {
  private val boMaterialStateRepository = mockk<BoMaterialStateRepository>()
  private val teamMaterialRepository = mockk<TeamMaterialRepository>()
  private val useCase = UpdateBoMaterialStatesUseCase(boMaterialStateRepository, teamMaterialRepository)

  @Test
  fun `delegates updates to boMaterialStateRepository and teamMaterialRepository`() {
    val boId = "bo-123"
    val actor = Actor("user-1", "Nguyen Van A", "user1", "", emptyList(), emptySet())
    val updates = listOf(
      BoMaterialStateUpdate(lineId = "fabric", alternativeName = "Vai lua", isRequired = false),
      BoMaterialStateUpdate(lineId = "thread", alternativeName = "Chi may", isRequired = true),
    )
    val command = UpdateBoMaterialStatesCommand(updates = updates)

    justRun { boMaterialStateRepository.updateMaterialStates(boId, updates) }
    justRun { teamMaterialRepository.updateMaterialStatesByBoId(boId, updates, actor) }

    useCase.execute(boId, command, actor)

    verify(exactly = 1) { boMaterialStateRepository.updateMaterialStates(boId, updates) }
    verify(exactly = 1) { teamMaterialRepository.updateMaterialStatesByBoId(boId, updates, actor) }
  }
}
