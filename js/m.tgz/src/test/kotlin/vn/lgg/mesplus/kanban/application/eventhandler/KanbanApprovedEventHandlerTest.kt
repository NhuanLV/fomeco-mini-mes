package vn.lgg.mesplus.kanban.application.eventhandler

import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.application.usecase.InitKanbanAssignmentsUseCase
import vn.lgg.mesplus.kanban.domain.event.KanbanApproved
import vn.lgg.mesplus.kanban.domain.model.Kanban
import vn.lgg.mesplus.kanban.domain.model.KanbanStatus
import vn.lgg.mesplus.kanban.domain.repository.KanbanRepository
import vn.lgg.mesplus.shared.model.ActorRef

class KanbanApprovedEventHandlerTest {
  @Test
  fun `passes approving actor when initializing assignments`() {
    val actor = ActorRef("actor-1", "Planner")
    val kanban = mockk<Kanban>()
    val repository = mockk<KanbanRepository>()
    val initAssignments = mockk<InitKanbanAssignmentsUseCase>()
    every { kanban.status } returns KanbanStatus.APPROVED
    every { repository.findById("kanban-1") } returns kanban
    justRun { initAssignments.execute("kanban-1", actor) }

    KanbanApprovedEventHandler(initAssignments, repository)
      .handle(KanbanApproved("kanban-1", actor))

    verify(exactly = 1) { initAssignments.execute("kanban-1", actor) }
  }
}
