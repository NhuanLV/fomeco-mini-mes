package vn.lgg.mesplus.production.infrastructure.repository

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import java.sql.DriverManager
import java.time.Instant
import java.time.LocalDate
import java.util.*
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable
import tools.jackson.databind.json.JsonMapper
import tools.jackson.databind.jsontype.NamedType
import vn.lgg.mesplus.production.application.service.ProductionOrderActivity
import vn.lgg.mesplus.production.application.service.ProductionOrderActivitySyncStatus
import vn.lgg.mesplus.production.application.service.ProductionOrderActivityType
import vn.lgg.mesplus.production.application.service.ProductionOrderAllocationChange
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.infrastructure.repository.exposed.ProductionOrderActivityTable
import vn.lgg.mesplus.production.presentation.viewmodel.ProductionOrderHistory
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

/** Disposable schema in the development database; public data is untouched. */
@EnabledIfEnvironmentVariable(named = "MES_HISTORY_DB_TEST", matches = "true")
class ProductionOrderActivityLogDbTest {
    private val schema = "history_test_${UUID.randomUUID().toString().replace("-", "")}"
    private val url = System.getenv("MES_CANCEL_TEST_JDBC_URL") ?: "jdbc:postgresql://localhost:5433/mesplus"
    private val user = System.getenv("MES_CANCEL_TEST_DB_USER") ?: "sa"
    private val password = System.getenv("MES_CANCEL_TEST_DB_PASSWORD") ?: "1234"
    private val mapper = JsonMapper.builder().addModule(tools.jackson.module.kotlin.KotlinModule.Builder().build())
        .registerSubtypes(NamedType(TeamAssignmentCreated::class.java, "TeamAssignmentCreated")).build()
    private val activityTable = ProductionOrderActivityTable(mapper)
    private val activityLog = PgProductionOrderActivityLog(activityTable)
    private lateinit var database: Database
    private val orderId = UUID.randomUUID().toString()
    private val actor = ActorRef(UUID.randomUUID().toString(), "Người phát cũ")
    private val time = Instant.parse("2026-10-01T08:00:00Z")

    @BeforeEach
    fun setup() {
        sql("CREATE SCHEMA $schema", useSchema = false)
        database = Database.connect(
            "$url?currentSchema=$schema",
            driver = "org.postgresql.Driver",
            user = user,
            password = password
        )
        sql(
            """CREATE TABLE production_orders (id UUID PRIMARY KEY, created_at TIMESTAMP NOT NULL);
      CREATE TABLE team_assignment_events (id BIGSERIAL PRIMARY KEY, assignment_id UUID NOT NULL, occurred_at TIMESTAMPTZ NOT NULL, payload JSONB NOT NULL);
      INSERT INTO production_orders VALUES ('$orderId', '2026-10-01 07:00:00');"""
        )
        migration("V3_24__add_production_order_activity_log.sql")
        migration("V3_27__production_order_cancellation.sql")
    }

    @AfterEach
    fun cleanup() {
        sql("DROP SCHEMA $schema CASCADE", useSchema = false)
    }

    @Test
    fun `backfill uses one deterministic created event per order and never infers sync`() {
        event(time.plusSeconds(60), ActorRef(actor.id, "Later"))
        event(time, actor)
        sql("INSERT INTO team_assignment_events (assignment_id, occurred_at, payload) VALUES ('${UUID.randomUUID()}', '2026-09-01Z', '{\"eventName\":\"TeamAssignmentAllocationRevised\",\"productionOrderId\":\"$orderId\"}');")
        migration("V3_25__backfill_production_order_create_activity.sql")
        migration("V3_25__backfill_production_order_create_activity.sql")
        val activities = transaction(database) { activityLog.findByProductionOrderId(orderId) }
        activities.size shouldBe 1
        activities.single().actor shouldBe actor
        activities.single().occurredAt shouldBe time
        activities.single().sourceEventId shouldBe 2L
        activities.single().syncStatus shouldBe null
        val response = mapper.readTree(mapper.writeValueAsString(ProductionOrderHistory.from(activities.single())))
        response.has("actorRoles") shouldBe false
        response.has("syncStatus") shouldBe false
    }

    @Test
    fun `backfill missing source uses createdAt and preserves existing CREATE activity`() {
        migration("V3_25__backfill_production_order_create_activity.sql")
        val missing = transaction(database) { activityLog.findByProductionOrderId(orderId).single() }
        missing.actor shouldBe null
        missing.sourceEventId shouldBe null
        missing.occurredAt shouldBe Instant.parse("2026-10-01T07:00:00Z")
        event(time, actor)
        migration("V3_25__backfill_production_order_create_activity.sql")
        transaction(database) { activityLog.findByProductionOrderId(orderId).single() } shouldBe missing
    }

    @Test
    fun `roundtrip retains all snapshots and transaction rollback leaves no activity`() {
        val before = SkuAllocation(
            UUID.randomUUID().toString(),
            Color("Đỏ"),
            Size("M"),
            10,
            LocalDate.of(2026, 10, 20),
            notes = listOf("note")
        )
        val change = ProductionOrderAllocationChange(
            UUID.randomUUID().toString(),
            "CUT-1",
            "team",
            "Tổ cắt",
            before.purchaseOrderId,
            "PO-1",
            "Đỏ",
            "M",
            before,
            before.copy(quantity = 20)
        )
        val activity = ProductionOrderActivity(
            UUID.randomUUID().toString(),
            orderId,
            ProductionOrderActivityType.REVISE,
            actor,
            time,
            "Điều chỉnh",
            listOf(change),
            ProductionOrderActivitySyncStatus.SUCCESS,
            "OK",
            time
        )
        transaction(database) { activityLog.append(activity) }
        transaction(database) { activityLog.findByProductionOrderId(orderId).single() } shouldBe activity
        shouldThrow<IllegalStateException> {
            transaction(database) {
                activityLog.append(activity.copy(id = UUID.randomUUID().toString()))
                error("Rollback")
            }
        }
        transaction(database) { activityLog.findByProductionOrderId(orderId).size } shouldBe 1
    }

    @Test
    fun `CREATE uniqueness protects both live inserts and rerun backfill`() {
        val created = ProductionOrderActivity(
            UUID.randomUUID().toString(),
            orderId,
            ProductionOrderActivityType.CREATE,
            actor,
            time,
            null,
            emptyList(),
            ProductionOrderActivitySyncStatus.SUCCESS
        )
        transaction(database) { activityLog.append(created) }
        shouldThrow<Exception> {
            transaction(database) {
                activityLog.append(
                    created.copy(
                        id = UUID.randomUUID().toString()
                    )
                )
            }
        }
        migration("V3_25__backfill_production_order_create_activity.sql")
        transaction(database) { activityLog.findByProductionOrderId(orderId).single() } shouldBe created
    }

    private fun event(at: Instant, eventActor: ActorRef) {
        val assignment = UUID.randomUUID().toString()
        val event = TeamAssignmentCreated(
            assignment,
            orderId,
            UUID.randomUUID().toString(),
            UUID.randomUUID().toString(),
            Operation("CUT-1"),
            emptyList(),
            LocalDate.now(),
            LocalDate.now(),
            at,
            eventActor,
            at
        )
        DriverManager.getConnection("$url?currentSchema=$schema", user, password).use { connection ->
            connection.prepareStatement("INSERT INTO team_assignment_events(assignment_id, occurred_at, payload) VALUES (?::uuid, ?::timestamptz, ?::jsonb)")
                .use {
                    it.setString(1, assignment); it.setString(2, at.toString()); it.setString(
                    3,
                    mapper.writeValueAsString(event)
                ); it.executeUpdate()
                }
        }
    }

    private fun migration(file: String) = sql(requireNotNull(javaClass.getResource("/db/migration/$file")).readText())
    private fun sql(statement: String, useSchema: Boolean = true) {
        DriverManager.getConnection(if (useSchema) "$url?currentSchema=$schema" else url, user, password)
            .use { connection ->
                connection.createStatement().use { it.execute(statement) }
            }
    }
}
