package vn.lgg.mesplus

import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import org.junit.jupiter.api.Test

class TestStackTest {
  @Test
  fun `runs JUnit with Kotest assertions`() {
    21 * 2 shouldBe 42
  }
}

class KotestStackTest :
  FunSpec({
    test("runs Kotest with MockK") {
      val dependency = mockk<Dependency>()
      every { dependency.value() } returns 42

      dependency.value() shouldBe 42
    }
  })

private fun interface Dependency {
  fun value(): Int
}
