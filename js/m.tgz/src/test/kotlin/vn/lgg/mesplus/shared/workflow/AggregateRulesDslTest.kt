package vn.lgg.mesplus.shared.workflow

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe

class AggregateRulesDslTest : StringSpec({
  "checks collection rules in declaration order with require semantics" {
    shouldThrow<IllegalArgumentException> {
      emptyList<Item>() checkedBy {
        notEmpty otherwise "empty"
        every { it.quantity > 0 } otherwise "non-positive"
      }
    }.message shouldBe "empty"

    shouldThrow<IllegalArgumentException> {
      listOf(Item("A", 1), Item("A", 0)) checkedBy {
        notEmpty otherwise "empty"
        uniqueBy { it.id } otherwise "duplicate"
        every { it.quantity > 0 } otherwise "non-positive"
      }
    }.message shouldBe "duplicate"
  }

  "supports conditional requirements and allowed state sets" {
    (false requiredWhen false) otherwise "not required"

    shouldThrow<IllegalArgumentException> {
      (false requiredWhen true) otherwise "required"
    }.message shouldBe "required"

    (AggregateState.PENDING mustBeOneOf
      setOf(AggregateState.PENDING, AggregateState.REJECTED)) otherwise "invalid"
    shouldThrow<IllegalStateException> {
      (AggregateState.APPROVED mustBeOneOf
        setOf(AggregateState.PENDING, AggregateState.REJECTED)) otherwise "invalid"
    }.message shouldBe "invalid"
  }

  "moves typed state and replaces collection contents in place" {
    val holder = StateHolder(AggregateState.PENDING)
    val items = mutableListOf(Item("A", 1))

    holder::state movesTo AggregateState.APPROVED
    items replacedBy listOf(Item("B", 2), Item("C", 3))

    holder.state shouldBe AggregateState.APPROVED
    items.shouldContainExactly(Item("B", 2), Item("C", 3))
  }
})

private data class Item(val id: String, val quantity: Int)

private enum class AggregateState {
  PENDING,
  REJECTED,
  APPROVED,
}

private data class StateHolder(var state: AggregateState)
