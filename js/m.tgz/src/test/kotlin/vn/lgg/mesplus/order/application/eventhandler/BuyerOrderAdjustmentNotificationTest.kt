package vn.lgg.mesplus.order.application.eventhandler

import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.model.BuyerOrderAdjustmentRequired
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.Activity
import vn.lgg.mesplus.shared.Notifier
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.PermissionService

class BuyerOrderAdjustmentNotificationTest {
  private val assignmentRepository = mockk<TeamAssignmentRepository>()
  private val permissionService = mockk<PermissionService>()
  private val notifier = mockk<Notifier>(relaxed = true)
  private val creator =
    BuyerOrderAdjustmentNotificationCreator(assignmentRepository, permissionService, notifier)

  @Test
  fun `groups recipients across every team into one buyer order notification`() {
    every { assignmentRepository.findByBuyerOrderId("bo-1") } returns
      listOf(assignment("ta-1", "team-1"), assignment("ta-2", "team-2"))
    every { permissionService.lookupAccountIds(Permission.ISSUE_PRODUCTION_ORDER, "team-1") } returns
      listOf("planner-1", "planner-shared")
    every { permissionService.lookupAccountIds(Permission.ISSUE_PRODUCTION_ORDER, "team-2") } returns
      listOf("planner-shared", "planner-2")
    val recipients = slot<Collection<String>>()
    val activity = slot<Activity>()

    creator.create(
      BuyerOrderAdjustmentRequired("bo-1", "BO001", actor = null)
    )

    verify(exactly = 1) { notifier.notify(capture(recipients), capture(activity)) }
    recipients.captured.shouldContainExactly("planner-1", "planner-shared", "planner-2")
    activity.captured.title shouldBe "Đơn hàng cần điều chỉnh"
    activity.captured.body shouldBe "đã thay đổi BO BO001, cần điều chỉnh"
    activity.captured.target.resourceType shouldBe ResourceType.BUYER_ORDER
    activity.captured.target.resourceId shouldBe "bo-1"
  }

  private fun assignment(id: String, teamId: String) =
    TeamAssignment.create(
      id = id,
      productionOrderId = "lsx-$id",
      buyerOrderId = "bo-1",
      teamId = teamId,
      operation = Operation("Cut"),
      allocations = listOf(SkuAllocation("po-1", Color("Red"), Size("S"), 1)),
      plannedStartDate = LocalDate.of(2026, 1, 1),
      plannedEndDate = LocalDate.of(2026, 1, 10),
    )
}
