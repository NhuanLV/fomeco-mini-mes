package vn.lgg.mesplus.order.infrastructure.wfx.client

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.sun.net.httpserver.HttpServer
import io.kotest.matchers.shouldBe
import java.net.InetSocketAddress
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import org.junit.jupiter.api.Test
import org.springframework.core.env.StandardEnvironment
import org.springframework.web.client.RestClient
import tools.jackson.databind.json.JsonMapper
import vn.lgg.mesplus.app.config.property.WfxProperties
import vn.lgg.mesplus.order.infrastructure.wfx.FppoResolver
import vn.lgg.mesplus.order.infrastructure.wfx.WfxSyncException
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.CreateFppoRequest
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.GdnArticleData
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.GdnHeaderData
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.GrnHeaderData
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.ReleaseFppoItemDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.WfxFppoItemDto
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.gdnRequest
import vn.lgg.mesplus.order.infrastructure.wfx.client.request.grnRequest
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.WfxSyncResponse
import vn.lgg.mesplus.shared.model.Operation
import org.junit.jupiter.api.assertThrows
import vn.lgg.mesplus.order.infrastructure.wfx.WfxSyncFailure

class WfxClientTest {
  @Test
  fun `last order checks all matching FPPOS and never treats invalid responses as empty`() {
    var response = """{"Status":"Success","ResponseData":[]}"""
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      val body = response.toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()
    try {
      val client = buildClient(server.address.port)
      client.checkFppoCancellation("BO", "MAIN") shouldBe "Không còn FPPO phù hợp"
      fun row(status: String?, company: String = "MAIN", bo: String = "BO") =
        """{"FPPONum":"123","FPONum":"FPO-1","DeliveryOrderCode":"$bo","MainFactoryCode":"$company"${status?.let { ",\"FPPOStatus\":\"$it\"" } ?: ""}}"""
      response = """{"Status":"Success","ResponseData":[${row("Cancelled")},${row("Completed", "OTHER")},${row("Completed", bo = "OTHER")}] }"""
      client.checkFppoCancellation("BO", "MAIN") shouldBe "Đã kiểm tra WFX: tất cả FPPO đã Cancelled"
      buildMockClient(server.address.port, "wfx-error").checkFppoCancellation("BO", "MAIN") shouldBe
        "Đã kiểm tra WFX: tất cả FPPO đã Cancelled"
      response = """{"Status":"Success","ResponseData":[${row("Cancelled")},${row("Completed")},${row("Completed")},${row(null)}]}"""
      val error = assertThrows<IllegalStateException> { client.checkFppoCancellation("BO", "MAIN") }
      error.message shouldBe "Vui lòng hủy các LCĐ trên WFX trước: FPO FPO-1 — FPPO 123 (Completed); FPO FPO-1 — FPPO 123 (Thiếu trạng thái)"
      for (invalid in listOf(
        "", "{}", "null", "[]", """{"Status":"Success"}""",
        """{"Status":"Fail","ErrorMsg":"WFX unavailable","ResponseData":[]}""",
        """{"Status":"Success","ResponseData":null}""",
        """{"Status":"Success","ErrorMsg":{"message":"error"},"ResponseData":[]}""",
        """{"Status":"Success","ResponseData":[{}]}""",
        """{"Status":"Success","ResponseData":[{"ErrorMsg":[{"WFXErrMsg":"nested failure"}]}]}""",
      )) {
        response = invalid
        assertThrows<WfxSyncException> { client.checkFppoCancellation("BO", "MAIN") }
      }
    } finally { server.stop(0) }
  }

  @Test
  fun `release fpo sends configured account and preserves WFX failure response`() {
    val requests = mutableListOf<RequestSnapshot>()
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      requests += exchange.toSnapshot()
      val body = """{"ResponseID":0,"ResponseData":"400","ErrorMsg":"Already released","Status":"Fail"}""".toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(400, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()
    try {
      val response = buildClient(server.address.port, "http://localhost:${server.address.port}/api")
        .releaseFpo("1495-24")
      response.status shouldBe "Fail"
      response.errorMessage shouldBe "Already released"
      requests.single().path shouldBe "/api/WFXAPIFPO/FPOReleaseToFactoryOrProductionSaveData"
      val query = requests.single().rawQuery.orEmpty()
      query.contains("APIKey=api-key") shouldBe true
      query.contains("SecretKey=secret-key") shouldBe true
      val body = jacksonObjectMapper().readTree(requests.single().body)
      body["WFXAPIFPOData"][0]["Name"].asText() shouldBe "fpo-user"
      body["WFXAPIFPOData"][0]["Password"].asText() shouldBe "fpo-secret"
      body["WFXAPIFPOData"][0]["CompanyID"].asText() shouldBe "fpo-company"
      body["WFXAPIFPOData"][0]["FPOReleaseToFactoryOrProductionData"][0]["FPONum"].asText() shouldBe "1495-24"
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `release fppo returns both successful and failed items from batch`() {
    val requests = mutableListOf<RequestSnapshot>()
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      requests += exchange.toSnapshot()
      val body = """{"Status":"Success","ErrorMsg":"","ResponseData":[{"SuccessMsg":[{"FPONum":"1495-24","ProcessName":"CUT-1","FPPONum":"8265","WFXSuccessMsg":"Success"}],"ErrorMsg":[{"FPONum":"1495-24","ProcessName":"SEW-1","FPPONum":"8266","WFXErrMsg":"Already released"}]}]}""".toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()
    try {
      val response = buildClient(server.address.port)
        .releaseFppo(listOf(ReleaseFppoItemDto("1495-24", "CUT-1", "8265"), ReleaseFppoItemDto("1495-24", "SEW-1", "8266")))
      response.responseData.single().successMessages.single().fppoNum shouldBe "8265"
      response.responseData.single().errorMessages.single().wfxErrorMessage shouldBe "Already released"
      requests.single().path shouldBe "/WFXAPIFPPO/FPPOReleaseForProduction"
      val body = jacksonObjectMapper().readTree(requests.single().body)
      body["WFXAPIFPPOReleaseForProductionData"][0]["FPPOReleaseForProductionData"].size() shouldBe 2
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `chunked reads keep successful results and continue after HTTP and decoding errors`() {
    val from = LocalDate.now().minusMonths(6)
    val reads: List<(WfxClient) -> List<String>> = listOf(
      { it.getPurchaseOrders(from).map { row -> row.deliveryOcNo } },
      { it.getAllColors(from).map { row -> row.colorId } },
      { it.getAllSizes(from).map { row -> row.sizeId } },
      { it.getSuppliers(from).map { name -> name } },
      { it.getArticles(from, "Trims").map { row -> row.articleId } },
    )
    for (read in reads) {
      var requests = 0
      val server = HttpServer.create(InetSocketAddress(0), 0)
      server.createContext("/") { exchange ->
        val id = (++requests).toString()
        val body = when (requests) {
          2 -> "unavailable"
          3 -> "invalid json"
          else -> """
            {"status":"Success","responseData":[{
              "delivery_OC_No":"$id","summary_OC_No":"BO","customer_Name":"Customer",
              "style_Name":"Style","season":"Season","latest_DPONO":"PO",
              "buyer_Delivery_Date":"01-Jan-2026","destination":"VN","buyer_Division_Dept":"Brand",
              "revisionCode":"1","revisionDate":"01-Jan-2026-00:00:00:000","colorSizeBreakupList":[],
              "ColorID":"$id","ColorCode":"RED","ColorName":"Red",
              "SizeID":"$id","SizeCode":"M","SizeName":"Medium",
              "SupplierCompanyName":"$id","ArticleID":"$id","ArticleCode":"ART",
              "ArticleName":"Article","StoringUOM":"PCS"
            }]}
          """.trimIndent()
        }.toByteArray()
        exchange.responseHeaders.add("Content-Type", "application/json")
        exchange.sendResponseHeaders(if (requests == 2) 500 else 200, body.size.toLong())
        exchange.responseBody.use { it.write(body) }
      }
      server.start()
      try {
        read(buildClient(server.address.port)) shouldBe listOf("1", "4")
        requests shouldBe 4
      } finally {
        server.stop(0)
      }
    }
  }

  @Test
  fun `create fppo sends delivery-wise header and accepts nested success`() {
    val requests = mutableListOf<RequestSnapshot>()
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      requests += exchange.toSnapshot()
      val body =
        """{"ResponseID":1,"ResponseData":[{"ErrorMsg":[],"SuccessMsg":[{"WFXSuccessMsg":"Created"}]}],"ErrorMsg":"","Status":"Success"}"""
          .toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val response = buildClient(server.address.port).createFppo(fppoRequest())

      response.responseData.orEmpty().single().successMessages.single().wfxSuccessMessage shouldBe "Created"
      requests.single().method shouldBe "POST"
      requests.single().path shouldBe "/WFXAPIFPPO/SaveData"
      requests.single().headers["Apikey"] shouldBe "api-key"
      requests.single().headers["Secretkey"] shouldBe "secret-key"
      requests.single().headers["Createfppodeliverywise"] shouldBe "1"
      requests.single().headers["Content-type"] shouldBe "application/json"
      requests.single().body.contains("\"WFXAPIFPPOData\"") shouldBe true
      requests.single().body.contains("\"DeliveryOCNum\":\"PO-WFX-1\"") shouldBe true
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `create fppo preserves nested WFX business errors`() {
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      val body =
        """{"ResponseID":1,"ResponseData":[{"ErrorMsg":[{"WFXErrMsg":"  Error in procedure, line: 544  "},{"WFXErrMsg":"Second error"}],"SuccessMsg":[]}],"ErrorMsg":"","Status":"Success"}"""
          .toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val error = assertThrows<WfxSyncException> {
        buildClient(server.address.port).createFppo(fppoRequest())
      }

      error.message shouldBe
        "WFX từ chối tạo phiếu: Error in procedure, line: 544\nSecond error"
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `create fppo rejects root WFX business error`() {
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      val body =
        """{"ResponseID":0,"ResponseData":null,"ErrorMsg":"Object reference not set","Status":"Fail"}"""
          .toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(404, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val error = assertThrows<WfxSyncException> {
        buildClient(server.address.port).createFppo(fppoRequest())
      }

      error.message shouldBe "WFX từ chối tạo phiếu: Object reference not set"
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `maps WFX fail response to business sync exception`() {
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      val body = """{"ResponseType":"Fail","ErrorMsg":"Invalid FPPO"}""".toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val error =
        assertThrows<WfxSyncException> {
          buildClient(server.address.port).createGdn(gdnRequest {})
        }

      error.failure shouldBe WfxSyncFailure.BUSINESS
      error.message shouldBe "WFX từ chối tạo phiếu: Invalid FPPO"
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `maps RestClient errors to infrastructure sync exception`() {
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      exchange.sendResponseHeaders(500, -1)
      exchange.close()
    }
    server.start()

    try {
      val error =
        assertThrows<WfxSyncException> {
          buildClient(server.address.port).createGdn(gdnRequest {})
        }

      error.failure shouldBe WfxSyncFailure.INFRASTRUCTURE
      error.message?.startsWith("Lỗi hạ tầng khi kết nối WFX:") shouldBe true
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `maps WFX error response with HTTP 404 to business sync exception`() {
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      val body =
        """{"ResponseID":0,"ResponseData":null,"ErrorMsg":"Object reference not set","Status":"Fail"}"""
          .toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(404, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val error =
        assertThrows<WfxSyncException> {
          buildClient(server.address.port).createGdn(gdnRequest {})
        }

      error.failure shouldBe WfxSyncFailure.BUSINESS
      error.message shouldBe "WFX từ chối tạo phiếu: Object reference not set"
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `accepts GRN pass response with status 200 and extracts message`() {
    val response =
      jacksonObjectMapper().readValue(
        """{"ResponseType":"Pass","Data":"","Message":"Success. (GRN Doc No: GRN-LGGCUT3-2026-23, Doc No: BH00511)","Status":"200"}""",
        WfxSyncResponse::class.java,
      )

    response.isSuccess() shouldBe true
    response.messageForDisplay() shouldBe
      "Success. (GRN Doc No: GRN-LGGCUT3-2026-23, Doc No: BH00511)"
    response.formatSuccessMessage("GRN") shouldBe
      "GRN Doc No: GRN-LGGCUT3-2026-23, Doc No: BH00511"
  }

  @Test
  fun `accepts GDN success response with Status field and formats display message`() {
    val json = """
      {
        "ResponseID": 1,
        "ResponseData": "200",
        "ErrorMsg": "",
        "Status": "Success. (GDN Doc No: GDN-LGGMAT-2026-48, Doc No: KB-019fdad8-923f-74ec-af95-057fa7213729-677178b8-1)"
      }
    """.trimIndent()
    val response = jacksonObjectMapper().readValue(json, WfxSyncResponse::class.java)

    response.isSuccess() shouldBe true
    response.formatSuccessMessage("GDN") shouldBe
      "GDN Doc No: GDN-LGGMAT-2026-48, Doc No: KB-019fdad8-923f-74ec-af95-057fa7213729-677178b8-1"
  }

  @Test
  fun `color and size requests include modified date range`() {
    val queries = mutableListOf<Map<String, String>>()
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      queries +=
        exchange.requestURI.rawQuery
          .split("&")
          .associate {
            val (key, value) = it.split("=", limit = 2)
            key to URLDecoder.decode(value, StandardCharsets.UTF_8)
          }
      val body = """{"responseData":[]}""".toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val properties =
        WfxProperties(
          baseUrl = "http://localhost:${server.address.port}",
          apiKey = "api-key",
          secretKey = "secret-key",
          companyName = "company",
          companyCode = "company-code",
          fpoName = "fpo-user",
          fpoPassword = "fpo-secret",
          fpoCompanyId = "fpo-company",
        )
      val client = WfxClient(RestClient.builder(), properties, JsonMapper.builder().build())
      val modifiedFrom = LocalDate.now().minusDays(10)

      client.getAllColors(modifiedFrom)
      client.getAllSizes(modifiedFrom)

      val formatter = DateTimeFormatter.ofPattern("M/d/yyyy")
      val expectedDates =
        mapOf(
          "ModifiedFrom" to modifiedFrom.format(formatter),
          "ModifiedTo" to LocalDate.now().plusDays(1).format(formatter),
        )
      queries.map { it.filterKeys(expectedDates::containsKey) } shouldBe
        listOf(expectedDates, expectedDates)
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `getAllColors and getAllSizes handle missing or null code and name fields`() {
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/ColorCard/GetColorCardsJSONData") { exchange ->
      val body =
        """
        {
          "responseData": [
            {"ColorID": "1", "ColorName": "Green"},
            {"ColorID": "2", "ColorCode": "RED", "ColorName": "Red"}
          ]
        }
        """.trimIndent().toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.createContext("/WFXSizeWidth/GetSizeWidthJSONData") { exchange ->
      val body =
        """
        {
          "responseData": [
            {"SizeID": "1", "SizeName": "Large"},
            {"SizeID": "2", "SizeCode": "M", "SizeName": "Medium"}
          ]
        }
        """.trimIndent().toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val client = buildClient(server.address.port)
      val colors = client.getAllColors()
      colors.size shouldBe 2
      colors[0].colorId shouldBe "1"
      colors[0].colorCode shouldBe null
      colors[0].colorName shouldBe "Green"
      colors[1].colorId shouldBe "2"
      colors[1].colorCode shouldBe "RED"

      val sizes = client.getAllSizes()
      sizes.size shouldBe 2
      sizes[0].sizeId shouldBe "1"
      sizes[0].sizeCode shouldBe null
      sizes[0].sizeName shouldBe "Large"
      sizes[1].sizeId shouldBe "2"
      sizes[1].sizeCode shouldBe "M"
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `get articles sends category and maps article master fields`() {
    val queries = mutableListOf<Map<String, String>>()
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      queries +=
        exchange.requestURI.rawQuery
          .split("&")
          .associate {
            val (key, value) = it.split("=", limit = 2)
            key to URLDecoder.decode(value, StandardCharsets.UTF_8)
          }
      val body =
        """
        {
          "responseData":[{
            "ArticleID":"544007161",
            "Category":"Trims",
            "MaterialType":"Trim",
            "ArticleCode":"SWT-0001529",
            "ArticleName":"check-String-.",
            "StoringUOM":"MTR",
            "BaseColorList":[],
            "BaseSizeList":[]
          }]
        }
        """.trimIndent().toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val client = buildClient(server.address.port)
      val modifiedFrom = LocalDate.now().minusDays(10)

      val articles = client.getArticles(modifiedFrom, "Trims")

      articles.single().articleId shouldBe "544007161"
      articles.single().articleCode shouldBe "SWT-0001529"
      articles.single().articleName shouldBe "check-String-."
      articles.single().storingUom shouldBe "MTR"
      queries.single()["Category"] shouldBe "Trims"
      queries.single()["ModifiedFrom"] shouldBe modifiedFrom.format(DateTimeFormatter.ofPattern("M/d/yyyy"))
      queries.single()["ModifiedTo"] shouldBe
        LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("M/d/yyyy"))
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `get articles skips chunks when WFX returns no response body`() {
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      exchange.sendResponseHeaders(204, -1)
      exchange.close()
    }
    server.start()

    try {
      buildClient(server.address.port)
        .getArticles(LocalDate.now().minusDays(10), "Trims") shouldBe emptyList()
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `get suppliers maps supplier company names`() {
    val requests = mutableListOf<RequestSnapshot>()
    val queries = mutableListOf<Map<String, String>>()
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      requests += exchange.toSnapshot()
      queries +=
        exchange.requestURI.rawQuery
          .split("&")
          .associate {
            val (key, value) = it.split("=", limit = 2)
            key to URLDecoder.decode(value, StandardCharsets.UTF_8)
          }
      val body =
        """{"responseData":[{"SupplierCompanyName":"Supplier A"},{"SupplierCompanyName":"Supplier B"}],"status":"Success"}"""
          .toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val from = LocalDate.now().minusDays(10)
      val to = LocalDate.now()
      val suppliers = buildClient(server.address.port).getSuppliers(from, to)

      suppliers.map { it } shouldBe listOf("Supplier A", "Supplier B")
      requests.single().path shouldBe "/WFXPartyMaster/GetSupplierJSONData"
      requests.single().body shouldBe ""
      queries.single()["Category"] shouldBe "Services"
      queries.single()["LastChangedOnFrom"] shouldBe from.format(DateTimeFormatter.ofPattern("M/d/yyyy"))
      queries.single()["LastChangedOnTo"] shouldBe
        to.format(DateTimeFormatter.ofPattern("M/d/yyyy"))
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `splitIntoChunks splits long range into consecutive 2-month chunks`() {
    val from = LocalDate.of(2025, 1, 1)
    val to = LocalDate.of(2025, 5, 15)
    val chunks = WfxClient.splitIntoChunks(from, to, monthsPerChunk = 2)

    chunks shouldBe listOf(
      DateRange(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 2, 28)),
      DateRange(LocalDate.of(2025, 3, 1), LocalDate.of(2025, 4, 30)),
      DateRange(LocalDate.of(2025, 5, 1), LocalDate.of(2025, 5, 15)),
    )
  }

  @Test
  fun `get suppliers skips chunks with WFX error response`() {
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      val body =
        """
        {"responseID":0.0,"responseData":null,"errorMsg":"Json Data not found","status":"Fail","statusCode":400}
        """
          .trimIndent()
          .toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      buildClient(server.address.port)
        .getSuppliers(LocalDate.now().minusDays(10)) shouldBe emptyList()
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `get suppliers skips chunks when WFX marks a populated response as failed`() {
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      val body =
        """
        {"responseData":[{"SupplierCompanyName":"Supplier A"}],"errorMsg":"Sync failed","status":"Fail","statusCode":400}
        """
          .trimIndent()
          .toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      buildClient(server.address.port)
        .getSuppliers(LocalDate.now().minusDays(10)) shouldBe emptyList()
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `get fppo details parses WFX response data and uses get body with auth headers`() {
    val requests = mutableListOf<RequestSnapshot>()
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      requests += exchange.toSnapshot()
      val body =
        """
        {"ResponseID":1,"ResponseData":[{"DeliveryOrderCode":"BO-1","ProcessCode":"CUT-1","FPPONum":"6840","DispatchSiteName":"CUT SITE","ReceivingSiteName":"SEW SITE"}],"ErrorMsg":"","Status":"Success"}
        """
          .trimIndent()
          .toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val client = buildClient(server.address.port)

      val response = client.getFppoDetails("BO-1")

      response.single().fppoNo shouldBe "6840"
      response.single().processCode shouldBe "CUT-1"
      requests.single().method shouldBe "GET"
      requests.single().path shouldBe "/WFXAPIFPPO/GetDetail"
      requests.single().headers["Apikey"] shouldBe "api-key"
      requests.single().headers["Secretkey"] shouldBe "secret-key"
      requests.single().body.contains("\"WFXAPIFPPOData\"") shouldBe true
      requests.single().body.contains("\"DeliveryOrderCode\":\"BO-1\"") shouldBe true
      requests.single().body.contains("\"ProcessCode\":\"\"") shouldBe true
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `get fppo details retains API base path`() {
    val requests = mutableListOf<RequestSnapshot>()
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      requests += exchange.toSnapshot()
      val body = """{"Status":"Success","ResponseData":[]}""".toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      buildClient(server.address.port, "http://localhost:${server.address.port}/api")
        .getFppoDetails("BO-1")

      requests.single().path shouldBe "/api/WFXAPIFPPO/GetDetail"
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `create gdn and grn hit expected endpoints`() {
    val requests = mutableListOf<RequestSnapshot>()
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      requests += exchange.toSnapshot()
      val body =
        """
        {"ResponseID":"request-1","ResponseData":"GDN Doc No: GDN-1, Doc No: KB-1","ErrorMsg":"","Status":"Success"}
        """
          .trimIndent()
          .toByteArray()
      exchange.responseHeaders.add("Content-Type", "application/json")
      exchange.sendResponseHeaders(200, body.size.toLong())
      exchange.responseBody.use { it.write(body) }
    }
    server.start()

    try {
      val client = buildClient(server.address.port)

      val gdnResponse = client.createGdn(
        gdnRequest {
          header(
            GdnHeaderData(
              name = "admin",
              password = "secret",
              companyId = "LGG",
              toFppoNo = "6840",
              docNo = "KB-1",
              docDate = "2026/07/28",
              dispatchedSite = "CUT SITE",
              location = "KHO NPL 1 (VP)",
            ),
          )
          article(
            GdnArticleData(
              articleCode = "ART-1",
              colorCode = "RED",
              colorName = "Red",
              sizeCode = "M",
              uom = "PCS",
              dispatchedQty = "12",
            ),
          )
        },
      )
      gdnResponse.isSuccess() shouldBe true
      gdnResponse.messageForDisplay() shouldBe "GDN Doc No: GDN-1, Doc No: KB-1"
      val mapper = JsonMapper.builder().build()
      client.createGrn(
        grnRequest(mapper) {
        },
      )

      requests.map { it.path } shouldBe
        listOf("/WFXAPIFPPOGDN/SaveData", "/CtrlWFXAPIWFXFPPOGRN/APIFPPOGRNPostData")
      requests[0].body.contains("\"DispatchedQty\":\"12\"") shouldBe true
      requests[0].body.contains("\"MaterialType\":\"ALL\"") shouldBe true
      requests[0].body.contains("\"WFXAPIFPPOGDNData\":[{\"Name\"") shouldBe true
      requests[0].body.contains("\"ArticleData\":[{\"ArticleCode\"") shouldBe true
      requests[0].body.contains("\"Location\":\"KHO NPL 1 (VP)\"") shouldBe true
      requests[1].body.contains("\"GRNData\":\"{\\\"DataSourceList\\\"") shouldBe true
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `dev mock keeps FPO and FPPO writes off WFX`() {
    val requests = mutableListOf<RequestSnapshot>()
    val server = HttpServer.create(InetSocketAddress(0), 0)
    server.createContext("/") { exchange ->
      requests += exchange.toSnapshot()
      exchange.sendResponseHeaders(500, -1)
      exchange.close()
    }
    server.start()

    try {
      val client = buildMockClient(server.address.port)

      client.createFppo(fppoRequest()).status shouldBe "Success"
      client.checkFppoCancellation("BO", "MAIN") shouldBe "Đã kiểm tra WFX: tất cả FPPO đã Cancelled"
      client.releaseFpo("FPO-MOCK").status shouldBe "Success"
      client.releaseFppo(listOf(ReleaseFppoItemDto("FPO-MOCK", "CUT", "FPPO-MOCK")))
        .responseData.single().successMessages.single().fppoNum shouldBe "FPPO-MOCK"
      requests shouldBe emptyList()
    } finally {
      server.stop(0)
    }
  }

  @Test
  fun `dev mock resolves sewing fppo without calling WFX`() {
    val result = FppoResolver(buildMockClient(1)).resolve("BO-1", Operation("SEW-1"))

    result.fppoNo shouldBe "MOCK-FPPO"
  }

  @Test
  fun `dev mock can simulate a GDN failure via wfx-error profile`() {
    val client = buildMockClient(1, "wfx-error")

    val ex = assertThrows<WfxSyncException> {
      client.createGdn(
        gdnRequest {
          header(
            GdnHeaderData("admin", "secret", "LGG", "6840", "KB-1", "2026/07/28", "CUT"),
          )
        },
      )
    }
    ex.message shouldBe "WFX từ chối tạo phiếu: WFX Mock Error: GDN creation failed due to warehouse inventory shortage"
  }

  @Test
  fun `dev mock can simulate a GRN failure via wfx-error profile`() {
    val client = buildMockClient(1, "wfx-error")

    val ex = assertThrows<WfxSyncException> {
      client.createGrn(
        grnRequest(JsonMapper.builder().build()) {
          header(
            GrnHeaderData(
              fppoNo = "FPPO-1",
              docNo = "DOC-1",
              docDate = "2026/07/28",
              siteName = "SITE-1",
              location = "KHO",
            ),
          )
        },
      )
    }
    ex.message shouldBe "WFX từ chối tạo phiếu: WFX Mock Error: GRN creation failed (Object reference not set to an instance of an object)"
  }

  private fun buildClient(
    port: Int,
    transactionBaseUrl: String = "http://localhost:$port",
  ): WfxClient {
    val properties =
      WfxProperties(
        baseUrl = "http://localhost:$port",
        transactionBaseUrl = transactionBaseUrl,
        apiKey = "api-key",
        secretKey = "secret-key",
        companyName = "company",
        companyCode = "company-code",
        fpoName = "fpo-user",
        fpoPassword = "fpo-secret",
        fpoCompanyId = "fpo-company",
      )
    return WfxClient(RestClient.builder(), properties, JsonMapper.builder().build())
  }

  private fun buildMockClient(
    port: Int,
    vararg activeProfiles: String,
  ): WfxClientMock {
    val properties =
      WfxProperties(
        baseUrl = "http://localhost:$port",
        transactionBaseUrl = "http://localhost:$port",
        apiKey = "api-key",
        secretKey = "secret-key",
        companyName = "company",
        companyCode = "company-code",
        fpoName = "fpo-user",
        fpoPassword = "fpo-secret",
        fpoCompanyId = "fpo-company",
      )
    val env = StandardEnvironment().apply {
      if (activeProfiles.isNotEmpty()) {
        setActiveProfiles(*activeProfiles)
      }
    }
    return WfxClientMock(
      RestClient.builder(),
      properties,
      env,
      JsonMapper.builder().build(),
    )
  }

  private fun fppoRequest() =
    CreateFppoRequest(
      listOf(
        WfxFppoItemDto(
          deliveryOrderCode = "BO-WFX-1",
          deliveryOcNum = "PO-WFX-1",
          destination = "France",
          buyerDeliveryDate = "8/8/2026",
          executionFactoryCode = "LGGBG",
          processCode = "CUT-1",
          colorCode = "05",
          colorName = "Gray",
          sizeCode = "001US",
          qty = "456",
          planStartDate = "8/15/2026",
          planEndDate = "8/20/2026",
          mainFactoryCode = "LGGBG",
          mappedProcessCode = "CUT-1",
          wipDispatchSite = "LGGCUT",
          wipReceivingSite = "LGGWS",
        ),
      ),
    )

  private fun com.sun.net.httpserver.HttpExchange.toSnapshot(): RequestSnapshot {
    val body = requestBody.readAllBytes().toString(StandardCharsets.UTF_8)
    val headers =
      requestHeaders.entries.associate { (key, values) -> key to values.joinToString(",") }
    return RequestSnapshot(requestMethod, requestURI.path, headers, body, requestURI.rawQuery)
  }

  private data class RequestSnapshot(
    val method: String,
    val path: String,
    val headers: Map<String, String>,
    val body: String,
    val rawQuery: String? = null,
  )
}
