package vn.lgg.mesplus.production.domain.model

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.collections.shouldContainExactlyInAnyOrder
import io.kotest.matchers.shouldBe
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.TeamAssignmentAllocationRevised
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

class TeamAssignmentAllocationRevisionTest {
  private val actor = ActorRef("actor-1", "Planner")

  @Test
  fun `changed revision requires reason and records it`() {
    val assignment = assignment()

    shouldThrow<IllegalArgumentException> {
      assignment.reviseAllocation(listOf(allocation("Blue", "M", 10)), " ", actor)
    }

    assignment.reviseAllocation(listOf(allocation("Blue", "M", 10)), "Đổi kế hoạch", actor)

    val event = assignment.changes.single() as TeamAssignmentAllocationRevised
    event.reason shouldBe "Đổi kế hoạch"
    event.actor shouldBe actor
  }

  @Test
  fun `no-op revision creates no event and needs no reason`() {
    val assignment = assignment()

    assignment.reviseAllocation(listOf(allocation("Red", "S", 10)), "", actor)

    assignment.changes shouldBe emptyList()
  }

  @Test
  fun `historical scope keeps exact color size pairs`() {
    val assignment =
      assignment(
        extraEvents =
          listOf(
            TeamAssignmentAllocationRevised(
              assignmentId = "ta-1",
              reason = "Đổi mẫu",
              allocations = listOf(allocation("Blue", "M", 10)),
              actor = actor,
            ),
          ),
      )

    assignment.historicalColorSizePairs.shouldContainExactlyInAnyOrder(
      Color("Red") to Size("S"),
      Color("Blue") to Size("M"),
    )
  }

  @Test
  fun `allows empty allocation only when effective production is zero`() {
    val emptyAllowed = assignment()
    emptyAllowed.reviseAllocation(emptyList(), "Bỏ tổ", actor)
    emptyAllowed.allocations shouldBe emptyList()

    val reported =
      assignment(
        extraEvents =
          listOf(
            ProgressReported(
              assignmentId = "ta-1",
              items = listOf(ReportItem("po-1", Color("Red"), Size("S"), 1)),
              actor = actor,
              occurredAt = Instant.parse("2026-01-01T00:00:00Z"),
            ),
          ),
      )

    shouldThrow<IllegalArgumentException> {
      reported.reviseAllocation(emptyList(), "Bỏ tổ", actor)
    }
  }

  @Test
  fun `empty assignment rejects progress reports`() {
    val assignment = assignment()
    assignment.reviseAllocation(emptyList(), "Bỏ tổ", actor)

    shouldThrow<IllegalStateException> {
      assignment.reportProgress(
        ReportType.OUTPUT,
        listOf(ReportItem("po-1", Color("Red"), Size("S"), 1)),
        actor,
      )
    }
  }

  @Test
  fun `rejects allocation below effective production for the assignment color and size`() {
    val reported =
      assignment(
        extraEvents =
          listOf(
            ProgressReported(
              assignmentId = "ta-1",
              items = listOf(ReportItem("po-1", Color("Red"), Size("S"), 10)),
              actor = actor,
              occurredAt = Instant.parse("2026-01-01T00:00:00Z"),
            ),
          ),
      )

    shouldThrow<IllegalArgumentException> {
      reported.reviseAllocation(listOf(allocation("Red", "S", 6)), "Giảm phân bổ", actor)
    }
  }

  @Test
  fun `allows reallocating effective production between purchase orders in the same assignment`() {
    val reported =
      assignment(
        extraEvents =
          listOf(
            ProgressReported(
              assignmentId = "ta-1",
              items = listOf(ReportItem("po-1", Color("Red"), Size("S"), 10)),
              actor = actor,
              occurredAt = Instant.parse("2026-01-01T00:00:00Z"),
            ),
          ),
      )

    reported.reviseAllocation(
      listOf(
        allocation("Red", "S", 6),
        allocation("Red", "S", 4, purchaseOrderId = "po-2"),
      ),
      "Đổi PO",
      actor,
    )

    reported.allocations.shouldContainExactlyInAnyOrder(
      allocation("Red", "S", 6),
      allocation("Red", "S", 4, purchaseOrderId = "po-2"),
    )
  }

  private fun assignment(extraEvents: List<DomainEvent> = emptyList()) =
    TeamAssignment("ta-1").apply {
      loadFromHistory(
        listOf(
          TeamAssignmentCreated(
            assignmentId = "ta-1",
            productionOrderId = "lsx-1",
            buyerOrderId = "bo-1",
            teamId = "team-1",
            operation = Operation("Sew"),
            allocations = listOf(allocation("Red", "S", 10)),
            plannedStartDate = LocalDate.of(2025, 12, 1),
            plannedEndDate = LocalDate.of(2025, 12, 10),
            assignedAt = Instant.parse("2025-12-01T00:00:00Z"),
            actor = actor,
          ),
        ) + extraEvents,
      )
    }

  private fun allocation(
    color: String,
    size: String,
    quantity: Int,
    purchaseOrderId: String = "po-1",
  ) = SkuAllocation(purchaseOrderId, Color(color), Size(size), quantity)
}
