package vn.lgg.mesplus.kanban.application.usecase

import io.kotest.matchers.shouldBe
import io.mockk.slot
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import io.mockk.Runs
import io.mockk.every
import io.mockk.just
import io.mockk.mockk
import io.mockk.verify
import java.math.BigDecimal
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.domain.event.KanbanAssignmentInitialized.AssignmentItem
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialIssued.IssuedItem
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialPrepared.PreparedItem
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialReceived
import vn.lgg.mesplus.kanban.domain.model.KanbanAssignment
import vn.lgg.mesplus.kanban.domain.repository.KanbanAssignmentRepository
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.ActorRef

class ReceiveMaterialUseCaseTest {
  private val kanbanRepository = mockk<vn.lgg.mesplus.kanban.domain.repository.KanbanRepository> {
    every { lockAndLoad(any()) } returns mockk(relaxed = true)
  }
  private val repository = mockk<KanbanAssignmentRepository>()
  private val eventPublisher = mockk<DomainEventPublisher>()
  private val gdnSyncService = mockk<KanbanGdnSyncService>()
  private val actor = ActorRef("actor-1", "Actor")

  @Test
  fun `saves and publishes events successfully`() {
    val assignment = assignment()
    every { repository.findById("kanban-1", "supplier-1") } returns assignment
    every { repository.save(assignment) } just Runs
    every { eventPublisher.publish(any<List<DomainEvent>>()) } just Runs
    every { gdnSyncService.positiveBtpItems(any()) } answers { firstArg<KanbanMaterialReceived>().items }

    buildUseCase().execute(command())

    verify(exactly = 1) { repository.save(assignment) }
    verify(exactly = 1) { eventPublisher.publish(assignment.changes) }
  }

  @Test
  fun `stages GDN without receiving material for regular orders`() {
    val assignment = assignment()
    every { repository.findById("kanban-1", "supplier-1") } returns assignment
    every { gdnSyncService.positiveBtpItems(any()) } returns emptyList()
    every { gdnSyncService.stageReceive(any()) } just Runs

    buildUseCase().execute(command())

    verify(exactly = 1) { gdnSyncService.stageReceive(any()) }
    verify(exactly = 0) { repository.save(any()) }
    verify(exactly = 0) { eventPublisher.publish(any<List<DomainEvent>>()) }
  }

  @Test
  fun `mixed receive commits positive BTP and stages only material and regular BTP`() {
    val items = listOf(
      KanbanMaterialReceived.ReceivedItem("MAT-1", "RED", "M", null, BigDecimal.TEN),
      KanbanMaterialReceived.ReceivedItem("BTP CUT-1", "RED", "M", null, BigDecimal.TEN, PurchaseOrderType.REGULAR),
      KanbanMaterialReceived.ReceivedItem("BTP CUT-1", "RED", "M", null, BigDecimal.ONE, PurchaseOrderType.POSITIVE),
    )
    val assignment = KanbanAssignment.init("kanban-1", "supplier-1", items.map {
      AssignmentItem(it.article, it.color, it.size, it.poId, it.qty, it.purchaseOrderType)
    }, actor).apply {
      prepare(items.map { PreparedItem(it.article, it.color, it.size, it.poId, it.qty, "", it.purchaseOrderType) }, actor)
      issue(items.map { IssuedItem(it.article, it.color, it.size, it.poId, it.qty, "", it.purchaseOrderType) }, actor)
    }.let { source ->
      KanbanAssignment("kanban-1", "supplier-1").apply { loadFromHistory(source.allEvents) }
    }
    every { repository.findById("kanban-1", "supplier-1") } returns assignment
    every { repository.save(assignment) } just Runs
    every { eventPublisher.publish(any<List<DomainEvent>>()) } just Runs
    every { gdnSyncService.positiveBtpItems(any()) } answers {
      firstArg<KanbanMaterialReceived>().items.filter { it.purchaseOrderType == PurchaseOrderType.POSITIVE }
    }
    val staged = slot<KanbanMaterialReceived>()
    every { gdnSyncService.stageReceive(capture(staged)) } just Runs
    val receipt = mockk<RecordBtpKanbanReceiptUseCase>(relaxed = true)
    ReceiveMaterialUseCase(repository, eventPublisher, gdnSyncService, receipt, kanbanRepository)
      .execute(command().copy(items = items))
    val committed = assignment.changes.single() as KanbanMaterialReceived
    committed.items.map { it.purchaseOrderType } shouldBe listOf(PurchaseOrderType.POSITIVE)
    staged.captured.items.map { it.purchaseOrderType } shouldBe listOf(null, PurchaseOrderType.REGULAR)
    committed.occurredAt shouldBe staged.captured.occurredAt
    assignment.allItemsDone() shouldBe false
    verify(exactly = 1) { receipt.execute(committed) }
  }

  private fun buildUseCase(): ReceiveMaterialUseCase {
    return ReceiveMaterialUseCase(repository, eventPublisher, gdnSyncService, mockk(relaxed = true), kanbanRepository)
  }

  private fun command() =
    ReceiveMaterialCommand(
      kanbanId = "kanban-1",
      supplierUnitId = "supplier-1",
      items =
        listOf(
          KanbanMaterialReceived.ReceivedItem(
            article = "MAT-1",
            color = "RED",
            size = "M",
            poId = null,
            qty = BigDecimal("999"),
          )
        ),
      actor = actor,
    )

  private fun assignment() =
    KanbanAssignment.init(
      kanbanId = "kanban-1",
      supplierUnitId = "supplier-1",
      items = listOf(AssignmentItem("MAT-1", "RED", "M", null, BigDecimal("10"))),
      actor = actor,
    ).apply {
      prepare(
        listOf(
        PreparedItem(
            "MAT-1",
            "RED",
            "M",
            null,
            BigDecimal("1.23456"),
            "",
          )
        ),
        actor,
      )
      issue(
        listOf(
        IssuedItem(
            "MAT-1",
            "RED",
            "M",
            null,
            BigDecimal("1"),
            "",
          )
        ),
        actor,
      )
    }
}
