package vn.lgg.mesplus.production.domain.model

import io.kotest.matchers.collections.shouldContainExactlyInAnyOrder
import io.kotest.matchers.shouldBe
import java.math.BigDecimal
import java.time.Instant
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Material
import vn.lgg.mesplus.shared.model.MaterialColorDep
import vn.lgg.mesplus.shared.model.MaterialSizeDep
import vn.lgg.mesplus.shared.model.Size

class TeamMaterialDependencyMergeTest {
  @Test
  fun `adds missing dependencies without replacing overrides`() {
    val originalActor = ActorRef("actor-1", "Costing")
    val planner = ActorRef("actor-2", "Planner")
    val overriddenSize =
      MaterialSizeDep(Size("MAT-S"), Size("S"), consumption = BigDecimal("1.5"))
    val material =
      TeamMaterial(
        id = "line-1",
        teamAssignmentId = "ta-1",
        material = Material("Fabric", "Main", "M"),
        sizeDeps = listOf(overriddenSize),
        colorDeps =
          listOf(
            MaterialColorDep(Color("Custom red"), Color("Red"), BigDecimal("2.5"))
          ),
        lastUpdatedAt = Instant.parse("2026-01-01T00:00:00Z"),
        lastUpdatedBy = originalActor,
      )

    val changed =
      material.mergeMissingDependencies(
        defaultSizeDeps =
          listOf(
            MaterialSizeDep(Size("Default red"), Size("S"), BigDecimal.ONE),
            MaterialSizeDep(Size("MAT-M"), Size("M"), BigDecimal("2")),
          ),
        defaultColorDeps =
          listOf(
            MaterialColorDep(Color("Default red"), Color("Red"), BigDecimal.ONE),
            MaterialColorDep(Color("Blue"), Color("Blue"), BigDecimal("3")),
          ),
        updatedBy = planner,
      )

    changed shouldBe true
    material.sizeDeps.shouldContainExactlyInAnyOrder(
      overriddenSize,
      MaterialSizeDep(Size("MAT-M"), Size("M"), BigDecimal("2")),
    )
    material.colorDeps.shouldContainExactlyInAnyOrder(
      MaterialColorDep(Color("Custom red"), Color("Red"), BigDecimal("2.5")),
      MaterialColorDep(Color("Blue"), Color("Blue"), BigDecimal("3")),
    )
    material.lastUpdatedBy shouldBe planner
  }

  @Test
  fun `override updates existing and adds new color dependencies`() {
    val actor = ActorRef("actor-1", "Tech")
    val material =
      TeamMaterial(
        id = "line-1",
        teamAssignmentId = "ta-1",
        material = Material("Fabric", "Main", "M"),
        sizeDeps = emptyList(),
        colorDeps = listOf(MaterialColorDep(Color("Red"), Color("Red"), BigDecimal("1.0"))),
        lastUpdatedAt = Instant.parse("2026-01-01T00:00:00Z"),
        lastUpdatedBy = actor,
      )

    material.override(
      newSizeDeps = emptyList(),
      newColorDeps = listOf(
        MaterialColorDep(Color("Red"), Color("Red"), BigDecimal("1.5")),
        MaterialColorDep(Color("Blue"), Color("Blue"), BigDecimal("2.0")),
      ),
      updatedBy = actor,
    )

    material.colorDeps.shouldContainExactlyInAnyOrder(
      MaterialColorDep(Color("Red"), Color("Red"), BigDecimal("1.5")),
      MaterialColorDep(Color("Blue"), Color("Blue"), BigDecimal("2.0")),
    )
  }
}
