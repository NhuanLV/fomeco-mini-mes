package vn.lgg.mesplus.dashboard.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.security.access.AccessDeniedException
import vn.lgg.mesplus.dashboard.application.model.DashboardDateRange
import vn.lgg.mesplus.dashboard.application.model.DashboardFilter
import vn.lgg.mesplus.dashboard.application.model.DashboardInventoryScope
import vn.lgg.mesplus.dashboard.application.model.DashboardKanbanScope
import vn.lgg.mesplus.dashboard.application.model.DashboardProgressTab
import vn.lgg.mesplus.dashboard.application.model.DashboardScope
import vn.lgg.mesplus.dashboard.application.service.DashboardScopeResolver
import vn.lgg.mesplus.dashboard.infrastructure.repository.DashboardPendingActionRepository
import vn.lgg.mesplus.dashboard.infrastructure.repository.DashboardProductionOverview
import vn.lgg.mesplus.dashboard.infrastructure.repository.DashboardProductionRepository
import vn.lgg.mesplus.dashboard.infrastructure.repository.DashboardWfxErrorRepository
import vn.lgg.mesplus.dashboard.presentation.viewmodel.DashboardOverviewVm
import vn.lgg.mesplus.dashboard.presentation.viewmodel.DashboardPendingActionsVm
import vn.lgg.mesplus.dashboard.presentation.viewmodel.DashboardPendingInventoryRequestVm
import vn.lgg.mesplus.dashboard.presentation.viewmodel.DashboardPendingKanbanVm
import vn.lgg.mesplus.dashboard.presentation.viewmodel.DashboardProductionProgressVm
import vn.lgg.mesplus.dashboard.presentation.viewmodel.DashboardVisibilityVm
import vn.lgg.mesplus.dashboard.presentation.viewmodel.DashboardWfxErrorVm
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

class DashboardQueryServiceTest {
  private val productionRepository = mockk<DashboardProductionRepository>()
  private val pendingActionRepository = mockk<DashboardPendingActionRepository>()
  private val wfxErrorRepository = mockk<DashboardWfxErrorRepository>()
  private val permissionService = mockk<PermissionService>()
  private val scopeResolver = mockk<DashboardScopeResolver>()
  private val actor = Actor("actor-1", "Leader", "leader", "", emptyList(), emptySet())
  private val service = DashboardQueryService(
    productionRepository,
    pendingActionRepository,
    wfxErrorRepository,
    permissionService,
    scopeResolver,
  )

  @BeforeEach
  fun setUp() {
    every { permissionService.lookupUnit(actor, any()) } returns emptyList()
  }

  @Test
  fun `wfx errors keep GDN and GRN permission scopes separate`() {
    every { permissionService.lookupUnit(actor, Permission.CREATE_KANBAN) } returns listOf("gdn-team")
    every { permissionService.lookupUnit(actor, Permission.REPORT_PROGRESS) } returns listOf("grn-team")
    val gdnUnits = slot<List<String>>()
    val grnUnits = slot<List<String>>()
    every { wfxErrorRepository.getWfxErrors(capture(gdnUnits), capture(grnUnits)) } returns emptyList()

    service.getWfxErrors(actor)

    gdnUnits.captured shouldBe listOf("gdn-team")
    grnUnits.captured shouldBe listOf("grn-team")
  }

  @Test
  fun `wfx errors are forbidden without a processing permission`() {
    shouldThrow<AccessDeniedException> { service.getWfxErrors(actor) }
  }

  @Test
  fun `pending actions keep Kanban and inventory scopes separate`() {
    every { permissionService.lookupUnit(actor, Permission.CREATE_KANBAN) } returns listOf("receive-team")
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_KANBAN) } returns listOf("eval-team")
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_EXTRA_KANBAN) } returns listOf("extra-eval-team")
    every { permissionService.lookupUnit(actor, Permission.PREPARE_MATERIAL) } returns listOf("prepare-supplier")
    every { permissionService.lookupUnit(actor, Permission.ISSUE_MATERIAL) } returns listOf("issue-supplier")
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_REQUEST) } returns listOf("eval-request")
    every { permissionService.lookupUnit(actor, Permission.RECEIVE_REQUEST) } returns listOf("warehouse")
    val kanbanScope = slot<DashboardKanbanScope>()
    val inventoryScope = slot<DashboardInventoryScope>()
    every {
      pendingActionRepository.getPendingActions(capture(kanbanScope), capture(inventoryScope))
    } returns DashboardPendingActionsVm(emptyList(), emptyList())

    service.getPendingActions(actor)

    kanbanScope.captured shouldBe DashboardKanbanScope(
      evaluateUnitIds = listOf("eval-team"),
      extraEvaluateUnitIds = listOf("extra-eval-team"),
      prepareSupplierUnitIds = listOf("prepare-supplier"),
      issueSupplierUnitIds = listOf("issue-supplier"),
      receiveUnitIds = listOf("receive-team"),
    )
    inventoryScope.captured shouldBe DashboardInventoryScope(
      evaluateUnitIds = listOf("eval-request"),
      receiveUnitIds = listOf("warehouse"),
    )
  }

  @Test
  fun `pending actions are narrowed to the selected team`() {
    val filter = DashboardFilter(
      range = DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")),
      teamId = "team-1",
    )
    val kanbanScope = DashboardKanbanScope(emptyList(), emptyList(), emptyList(), emptyList(), listOf("team-1", "team-2"))
    val inventoryScope = DashboardInventoryScope(emptyList(), emptyList())
    val selectedScope = DashboardScope(emptySet(), setOf("team-1"))
    every { permissionService.lookupUnit(actor, Permission.CREATE_KANBAN) } returns listOf("team-1", "team-2")
    every { scopeResolver.resolve(listOf("team-1", "team-2"), filter) } returns selectedScope
    every {
      pendingActionRepository.getPendingActions(kanbanScope, inventoryScope, selectedScope)
    } returns DashboardPendingActionsVm(emptyList(), emptyList())

    service.getPendingActions(actor, filter) shouldBe DashboardPendingActionsVm(emptyList(), emptyList())
  }

  @Test
  fun `pending actions ignores CREATE_REQUEST and throws 403 when user has no evaluate or receive permission`() {
    every { permissionService.lookupUnit(actor, Permission.CREATE_REQUEST) } returns listOf("team-1")

    shouldThrow<AccessDeniedException> {
      service.getPendingActions(actor)
    }
  }

  @Test
  fun `Overview combines production and only accessible operational counts`() {
    val filter = DashboardFilter(
      DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")),
      teamId = "team-1",
    )
    val kanbanScope = DashboardKanbanScope(emptyList(), emptyList(), emptyList(), emptyList(), listOf("team-1"))
    val inventoryScope = DashboardInventoryScope(emptyList(), emptyList())
    val prodScope = DashboardScope(emptySet(), setOf("team-1"))
    every { permissionService.lookupUnit(actor, Permission.VIEW_PRODUCTION_ORDER) } returns listOf("team-1")
    every { permissionService.lookupUnit(actor, Permission.CREATE_KANBAN) } returns listOf("team-1")
    every { permissionService.lookupUnit(actor, Permission.REPORT_PROGRESS) } returns listOf("team-1")
    every { scopeResolver.resolve(any<Collection<String>>(), filter) } returns prodScope
    every { productionRepository.getOverview(filter, prodScope) } returns
      DashboardProductionOverview(
        inProgressBuyerOrders = 1,
        inProgressProductionOrders = 2,
        allocatedQty = 100,
        inputInPeriodQty = 10,
        cumulativeInputQty = 30,
        outputInPeriodQty = 20,
        cumulativeOutputQty = 40,
        progressPercentage = 40.0,
      )
    every { pendingActionRepository.getPendingActions(kanbanScope, inventoryScope, prodScope) } returns
      DashboardPendingActionsVm(
        kanbans = listOf(pendingKanban()),
        inventoryRequests = listOf(pendingInventoryRequest()),
      )
    every {
      wfxErrorRepository.getWfxErrors(listOf("team-1"), listOf("team-1"), prodScope)
    } returns listOf(wfxError())

    service.getOverview(actor, filter) shouldBe DashboardOverviewVm(
      inProgressBuyerOrders = 1,
      inProgressProductionOrders = 2,
      allocatedQty = 100,
      inputInPeriodQty = 10,
      cumulativeInputQty = 30,
      outputInPeriodQty = 20,
      cumulativeOutputQty = 40,
      progressPercentage = 40.0,
      pendingKanbanCount = 1,
      pendingInventoryRequestCount = 1,
      wfxErrorCount = 1,
    )
  }

  @Test
  fun `getVisibility calculates widget flags based on resolved scope shapes`() {
    every { permissionService.lookupUnit(actor, Permission.VIEW_PRODUCTION_ORDER) } returns listOf("factory-1", "factory-2")
    every { scopeResolver.resolve(listOf("factory-1", "factory-2")) } returns
      DashboardScope(factoryIds = setOf("factory-1", "factory-2"), teamIds = setOf("team-1", "team-2"))
    every { permissionService.lookupUnit(actor, Permission.CREATE_KANBAN) } returns listOf("team-1")

    val visibility = service.getVisibility(actor)

    visibility shouldBe DashboardVisibilityVm(
      productionProgress = true,
      factories = true,
      teams = true,
      buyerOrders = true,
      productionOrders = true,
      teamAssignments = true,
      pendingActions = true,
      wfxErrors = true,
    )
  }

  @Test
  fun `getVisibility uses the selected team as the effective production scope`() {
    val filter = DashboardFilter(
      range = DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")),
      teamId = "team-1",
    )
    every { permissionService.lookupUnit(actor, Permission.VIEW_PRODUCTION_ORDER) } returns
      listOf("factory-1", "team-1", "team-2")
    every { scopeResolver.resolve(listOf("factory-1", "team-1", "team-2"), filter) } returns
      DashboardScope(factoryIds = emptySet(), teamIds = setOf("team-1"))

    service.getVisibility(actor, filter) shouldBe DashboardVisibilityVm(
      productionProgress = true,
      factories = false,
      teams = false,
      buyerOrders = false,
      productionOrders = false,
      teamAssignments = true,
      pendingActions = false,
      wfxErrors = false,
    )
  }

  @Test
  fun `wfx errors are narrowed to the selected team`() {
    val filter = DashboardFilter(
      range = DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")),
      teamId = "team-1",
    )
    val selectedScope = DashboardScope(emptySet(), setOf("team-1"))
    every { permissionService.lookupUnit(actor, Permission.CREATE_KANBAN) } returns listOf("team-1", "team-2")
    every { permissionService.lookupUnit(actor, Permission.REPORT_PROGRESS) } returns listOf("team-1", "team-2")
    every { scopeResolver.resolve(listOf("team-1", "team-2"), filter) } returns selectedScope
    every {
      wfxErrorRepository.getWfxErrors(listOf("team-1", "team-2"), listOf("team-1", "team-2"), selectedScope)
    } returns emptyList()

    service.getWfxErrors(actor, filter) shouldBe emptyList()
  }

  @Test
  fun `getFactoryProgress throws 403 when user has fewer than 2 factories`() {
    val filter = DashboardFilter(DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")))
    every { permissionService.lookupUnit(actor, Permission.VIEW_PRODUCTION_ORDER) } returns listOf("factory-1")
    every { scopeResolver.resolve(listOf("factory-1")) } returns
      DashboardScope(factoryIds = setOf("factory-1"), teamIds = emptySet())

    shouldThrow<AccessDeniedException> {
      service.getFactoryProgress(actor, filter)
    }
  }

  @Test
  fun `getBuyerOrderProgress throws 403 when user has only team scope`() {
    val filter = DashboardFilter(DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")))
    every { permissionService.lookupUnit(actor, Permission.REPORT_PROGRESS) } returns listOf("team-1")
    every { scopeResolver.resolve(listOf("team-1")) } returns
      DashboardScope(factoryIds = emptySet(), teamIds = setOf("team-1"))

    shouldThrow<AccessDeniedException> {
      service.getBuyerOrderProgress(actor, filter)
    }
  }

  @Test
  fun `getProductionProgress throws 403 when user has no production scope`() {
    val filter = DashboardFilter(DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")))
    every { permissionService.lookupUnit(actor, any()) } returns emptyList()

    shouldThrow<AccessDeniedException> {
      service.getProductionProgress(actor, filter)
    }
  }

  @Test
  fun `getProductionProgress is forbidden when a warehouse is selected`() {
    val filter = DashboardFilter(
      DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")),
      warehouseId = "warehouse-1",
    )

    shouldThrow<AccessDeniedException> {
      service.getProductionProgress(actor, filter)
    }
  }

  @Test
  fun `getProductionProgress throws 403 when tab is LSX and actor has only team scope`() {
    val filter = DashboardFilter(
      range = DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")),
    )
    every { permissionService.lookupUnit(actor, Permission.REPORT_PROGRESS) } returns listOf("team-1")
    every { scopeResolver.resolve(listOf("team-1")) } returns
      DashboardScope(factoryIds = emptySet(), teamIds = setOf("team-1"))

    shouldThrow<AccessDeniedException> {
      service.getProductionProgress(actor, filter, DashboardProgressTab.LSX)
    }
  }

  @Test
  fun `getProductionProgress defaults to LSX when user has factory scope`() {
    val filter = DashboardFilter(
      range = DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")),
    )
    val prodScope = DashboardScope(factoryIds = setOf("factory-1"), teamIds = emptySet())
    every { permissionService.lookupUnit(actor, Permission.VIEW_PRODUCTION_ORDER) } returns listOf("factory-1")
    every { scopeResolver.resolve(listOf("factory-1")) } returns prodScope
    every { scopeResolver.resolve(listOf("factory-1"), filter) } returns prodScope
    val tabSlot = slot<DashboardProgressTab>()
    every {
      productionRepository.getProductionProgress(filter, prodScope, capture(tabSlot))
    } returns DashboardProductionProgressVm("2026-04-10", "2026-04-12", 0.0, emptyList())

    service.getProductionProgress(actor, filter)

    tabSlot.captured shouldBe DashboardProgressTab.LSX
  }

  @Test
  fun `getProductionProgress defaults to LCD when user has only team scope`() {
    val filter = DashboardFilter(
      range = DashboardDateRange(LocalDate.parse("2026-04-10"), LocalDate.parse("2026-04-12")),
    )
    val prodScope = DashboardScope(factoryIds = emptySet(), teamIds = setOf("team-1"))
    every { permissionService.lookupUnit(actor, Permission.REPORT_PROGRESS) } returns listOf("team-1")
    every { scopeResolver.resolve(listOf("team-1")) } returns prodScope
    every { scopeResolver.resolve(listOf("team-1"), filter) } returns prodScope
    val tabSlot = slot<DashboardProgressTab>()
    every {
      productionRepository.getProductionProgress(filter, prodScope, capture(tabSlot))
    } returns DashboardProductionProgressVm("2026-04-10", "2026-04-12", 0.0, emptyList())

    service.getProductionProgress(actor, filter)

    tabSlot.captured shouldBe DashboardProgressTab.LCD
  }

  private fun pendingKanban() = DashboardPendingKanbanVm(
    id = "kanban-1",
    kanbanCode = "KB-1",
    productionOrderCode = "LSX-1",
    companyName = "Company 1",
    factoryName = "Factory 1",
    teamId = "team-1",
    teamName = "Team 1",
    teamAssignmentId = "assignment-1",
    pendingReceiveCount = 0,
    requiredQty = BigDecimal.TEN,
    status = "APPROVED",
    createdAt = Instant.EPOCH,
  )

  private fun pendingInventoryRequest() = DashboardPendingInventoryRequestVm(
    "request-1", "RQ-1", "RETURN", "APPROVED", "assignment-1", "Team 1", "Warehouse", Instant.EPOCH,
  )

  private fun wfxError() = DashboardWfxErrorVm(
    id = "error-1",
    documentType = "GRN",
    documentId = "assignment-1",
    documentCode = "LSX-1",
    occurredAt = Instant.EPOCH,
    message = null,
    status = "FAILED",
  )
}
