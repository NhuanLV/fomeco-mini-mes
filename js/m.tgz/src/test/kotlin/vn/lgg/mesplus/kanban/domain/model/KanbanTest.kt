package vn.lgg.mesplus.kanban.domain.model

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import java.math.BigDecimal
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.kanban.domain.event.KanbanCreated
import vn.lgg.mesplus.kanban.domain.event.KanbanRevised
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size

class KanbanTest {
  private val actor = ActorRef("actor-1", "Planner")

  @Test
  fun `cancellation is permanent preserves quantities and requires a reason`() {
    val kanban = Kanban.create("kanban-1", "assignment-1", emptyList(),
      listOf(item("MAT-1", "200")), "extra", actor)
    shouldThrow<IllegalArgumentException> { kanban.cancel("  ", actor) }
    kanban.cancel(" Đổi kế hoạch ", actor)
    val restored = Kanban("kanban-1").apply { loadFromHistory(kanban.allEvents) }
    restored.status shouldBe KanbanStatus.CANCELLED
    restored.items.single().requiredQty shouldBe BigDecimal("200.0000")
    shouldThrow<IllegalStateException> { restored.approve(actor) }
    shouldThrow<IllegalStateException> { restored.revised(restored.items, actor) }
    shouldThrow<IllegalStateException> { restored.complete(actor) }
    shouldThrow<IllegalStateException> { restored.cancel("again", actor) }
  }

  @Test
  fun `extra cancellation permissions follow current approval round`() {
    val kanban = Kanban.create("kanban-1", "assignment-1", emptyList(),
      listOf(item("MAT-1", "1")), "extra", actor)
    kanban.cancellationPermissions() shouldBe listOf(vn.lgg.mesplus.shared.model.Permission.EVALUATE_KANBAN)
    kanban.approve(actor)
    kanban.cancellationPermissions() shouldBe listOf(vn.lgg.mesplus.shared.model.Permission.EVALUATE_KANBAN,
      vn.lgg.mesplus.shared.model.Permission.EVALUATE_EXTRA_KANBAN)
    kanban.reject("again", actor)
    kanban.cancellationPermissions() shouldBe listOf(vn.lgg.mesplus.shared.model.Permission.EVALUATE_KANBAN)
    kanban.revised(kanban.items, actor)
    kanban.approve(actor)
    kanban.approveExtra(actor)
    kanban.cancellationPermissions() shouldBe listOf(vn.lgg.mesplus.shared.model.Permission.EVALUATE_EXTRA_KANBAN)
  }

  @Test
  fun `standard create rounds quantities and approve moves directly to approved`() {
    val kanban =
      Kanban.create(
        id = "kanban-1",
        teamAssignmentId = "assignment-1",
        plan = listOf(PlanItem("po-1", Color("RED"), Size("M"), 10)),
        items = listOf(item("MAT-1", "1.23456")),
        reason = "",
        actor = actor,
      )

    kanban.status shouldBe KanbanStatus.PENDING_EVALUATION
    kanban.changes.filterIsInstance<KanbanCreated>()
      .single()
      .items
      .single()
      .requiredQty shouldBe BigDecimal("1.2346")

    val reloaded = Kanban("kanban-1").apply { loadFromHistory(kanban.changes) }
    reloaded.approve(actor)

    reloaded.status shouldBe KanbanStatus.APPROVED
  }

  @Test
  fun `extra create requires reason and follows extra approval path`() {
    shouldThrow<IllegalArgumentException> {
      Kanban.create(
        "kanban-1",
        "assignment-1",
        emptyList(),
        listOf(item("MAT-1", "1")),
        "",
        actor,
      )
    }.message shouldBe "Vui lòng nhập lý do báo Kanban ngoài định mức"

    val kanban =
      Kanban.create(
        "kanban-1",
        "assignment-1",
        emptyList(),
        listOf(item("MAT-1", "1")),
        "extra",
        actor,
      )

    val reloaded = Kanban("kanban-1").apply { loadFromHistory(kanban.changes) }
    reloaded.approve(actor)
    reloaded.status shouldBe KanbanStatus.PENDING_EXTRA_EVALUATION
    reloaded.approveExtra(actor)
    reloaded.status shouldBe KanbanStatus.APPROVED
  }

  @Test
  fun `create validates item collection in current order`() {
    shouldThrow<IllegalArgumentException> {
      Kanban.create(
        "kanban-1",
        "assignment-1",
        listOf(PlanItem("po-1", Color("RED"), Size("M"), 10)),
        emptyList(),
        "",
        actor,
      )
    }.message shouldBe "Kanban phải có ít nhất 1 vật tư/BTP"

    shouldThrow<IllegalArgumentException> {
      Kanban.create(
        "kanban-1",
        "assignment-1",
        listOf(PlanItem("po-1", Color("RED"), Size("M"), 10)),
        listOf(item("MAT-1", "1"), item("MAT-1", "0")),
        "",
        actor,
      )
    }.message shouldBe "Số lượng yêu cầu phải lớn hơn 0"
  }

  @Test
  fun `reject and revise preserve keys round changes and return to evaluation`() {
    val kanban =
      Kanban.create(
        "kanban-1",
        "assignment-1",
        listOf(PlanItem("po-1", Color("RED"), Size("M"), 10)),
        listOf(item("MAT-1", "1")),
        "",
        actor,
      )
    kanban.reject("adjust", actor)

    shouldThrow<IllegalArgumentException> {
      kanban.revised(listOf(item("MAT-2", "2")), actor)
    }.message shouldBe "Revise không được thêm hoặc xóa item"

    kanban.revised(listOf(item("MAT-1", "2.34567")), actor)

    kanban.status shouldBe KanbanStatus.PENDING_EVALUATION
    kanban.items.single().requiredQty shouldBe BigDecimal("2.3457")
    kanban.changes.filterIsInstance<KanbanRevised>()
      .single()
      .changedItems
      .single()
      .requiredQty shouldBe BigDecimal("2.3457")
  }

  private fun item(article: String, quantity: String) =
    KanbanItem(
      article = article,
      color = Color("RED"),
      size = Size("M"),
      purchaseOrderId = null,
      type = KanbanItemType.MATERIAL,
      requiredQty = BigDecimal(quantity),
      supplierUnitId = "supplier-1",
      creatorNote = "",
    )
}
