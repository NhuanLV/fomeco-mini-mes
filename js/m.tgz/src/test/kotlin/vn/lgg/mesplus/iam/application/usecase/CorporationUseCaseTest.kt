package vn.lgg.mesplus.iam.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.string.shouldContain
import io.mockk.every
import io.mockk.mockk
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.Corporation
import vn.lgg.mesplus.iam.domain.model.CorporationClassification
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.service.PermissionService

class CorporationUseCaseTest {
  private val orgUnitRepo = mockk<OrgUnitRepository>(relaxed = true)
  private val permissionService = mockk<PermissionService>(relaxed = true)

  private val actor =
    Actor(
      id = "admin-1",
      name = "Admin",
      _username = "admin",
      _password = "",
      memberships = emptyList(),
      permissions = emptySet(),
    )

  @Test
  fun `cannot update default system root corporation`() {
    val useCase = UpdateCorporationUseCase(orgUnitRepo, permissionService)
    val command =
      UpdateCorporationCommand(
        name = "New Name",
        code = "NEW_CODE",
        classification = CorporationClassification.INHOUSE,
      )

    val exception =
      shouldThrow<IllegalStateException> {
        useCase.execute(Corporation.DEFAULT_ID, command, actor)
      }
    exception.message shouldContain "Không thể chỉnh sửa tổng công ty mặc định của hệ thống"
  }

  @Test
  fun `cannot delete default system root corporation`() {
    val useCase = DeleteCorporationUseCase(orgUnitRepo, permissionService)

    val exception =
      shouldThrow<IllegalStateException> {
        useCase.execute(Corporation.DEFAULT_ID, actor)
      }
    exception.message shouldContain "Không thể xóa tổng công ty mặc định của hệ thống"
  }

  @Test
  fun `cannot switch outsource corporation to inhouse when child company has wfxSupplierName`() {
    val corpId = "corp-outsource-1"
    val corp =
      Corporation(
        id = corpId,
        name = "Outsource Corp",
        classification = CorporationClassification.OUTSOURCE,
        code = "CORP_OUT",
      )
    val companyWithSupplier =
      Company(
        id = "company-1",
        name = "Sub Company",
        parentId = corpId,
        address = "",
        wfxSupplierName = "SUPPLIER_A",
        code = "COMP_1",
      )

    every { orgUnitRepo.findById(corpId) } returns corp
    every { orgUnitRepo.findSubUnits(corpId) } returns listOf(companyWithSupplier)

    val useCase = UpdateCorporationUseCase(orgUnitRepo, permissionService)
    val command =
      UpdateCorporationCommand(
        name = "Outsource Corp",
        code = "CORP_OUT",
        classification = CorporationClassification.INHOUSE,
      )

    val exception =
      shouldThrow<IllegalStateException> {
        useCase.execute(corpId, command, actor)
      }
    exception.message shouldContain "Không thể đổi sang Inhouse vì vẫn còn công ty con được cấu hình nhà cung cấp WFX"
  }
}
