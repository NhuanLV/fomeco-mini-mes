package vn.lgg.mesplus.order.infrastructure.wfx

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.repository.WfxSupplierRepository
import vn.lgg.mesplus.order.infrastructure.wfx.client.WfxClient

class WfxSupplierSyncTest {
  private val client = mockk<WfxClient>()
  private val repository = mockk<WfxSupplierRepository>()
  private val service = WfxSupplierSyncService(client, repository)

  @Test
  fun `syncs unique nonblank supplier names into the cache and returns a success message`() {
    every { client.getSuppliers() } returns listOf(" Supplier B ", "", "Supplier A", "Supplier B")
    justRun { repository.replaceAll(listOf("Supplier A", "Supplier B")) }

    val result = service.sync()

    result.suppliers shouldContainExactly listOf("Supplier A", "Supplier B")
    result.message shouldBe "Làm mới danh sách nhà cung cấp WFX thành công"

    verify(exactly = 1) { repository.replaceAll(listOf("Supplier A", "Supplier B")) }
  }

  @Test
  fun `keeps the cache when WFX supplier request fails`() {
    every { client.getSuppliers() } throws
      IllegalStateException("Đồng bộ danh sách nhà cung cấp WFX thất bại")

    val error = assertThrows<IllegalStateException> { service.sync() }

    error.message shouldBe "Đồng bộ danh sách nhà cung cấp WFX thất bại"
    verify(exactly = 0) { repository.replaceAll(any()) }
  }
}
