package vn.lgg.mesplus.inventory.domain.model.transferrequest

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import java.math.BigDecimal
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestAssignmentInitialized.AssignmentItem
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestMaterialReceived
import vn.lgg.mesplus.inventory.domain.event.transferrequest.TransferRequestMaterialReceived.ReceivedItem
import vn.lgg.mesplus.shared.model.ActorRef

class TransferRequestAssignmentTest {
  private val actor = ActorRef("actor-1", "Receiver")

  @Test
  fun `receive uses allocated quantities and completes only after every item`() {
    val assignment = assignment()

    assignment.receive(listOf(received("MAT-1", "999")), actor)

    assignment.status shouldBe TransferRequestAssignmentStatus.ACTIVE
    assignment.allItemsDone() shouldBe false
    assignment.changes.filterIsInstance<TransferRequestMaterialReceived>()
      .single()
      .items
      .single()
      .quantity shouldBe BigDecimal("5")

    assignment.receive(listOf(received("MAT-2", "999")), actor)

    assignment.status shouldBe TransferRequestAssignmentStatus.COMPLETED
    assignment.allItemsDone() shouldBe true
  }

  @Test
  fun `receive rejects duplicate and unknown items with current messages`() {
    val assignment = assignment()
    assignment.receive(listOf(received("MAT-1", "1")), actor)

    shouldThrow<IllegalStateException> {
      assignment.receive(listOf(received("MAT-1", "1")), actor)
    }.message shouldBe "Item MAT-1 đã được nhận rồi"

    val fresh = assignment()
    shouldThrow<IllegalStateException> {
      fresh.receive(listOf(received("UNKNOWN", "1")), actor)
    }.message shouldBe "Item không tồn tại trong phân bổ: UNKNOWN, RED, M"
  }

  private fun assignment() =
    TransferRequestAssignment.init(
      transferRequestId = "request-1",
      targetTeamAssignmentId = "target-1",
      items =
        listOf(
          AssignmentItem("MAT-1", "RED", "M", "kg", BigDecimal("5")),
          AssignmentItem("MAT-2", "RED", "M", "kg", BigDecimal("7")),
        ),
      actor = actor,
    )

  private fun received(article: String, quantity: String) =
    ReceivedItem(article, "RED", "M", BigDecimal(quantity))
}
