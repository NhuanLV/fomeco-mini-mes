package vn.lgg.mesplus.inventory.application.usecase

import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import java.math.BigDecimal
import java.time.Instant
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.inventory.domain.model.btp.BtpInventory
import vn.lgg.mesplus.inventory.domain.model.btp.BtpSku
import vn.lgg.mesplus.inventory.domain.repository.BtpInventoryRepository
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

class RecordBtpProducedUseCaseTest {
  @Test
  fun `mixed output shares stock but records positive and regular only once each`() {
    val repository = mockk<BtpInventoryRepository>()
    val inventory = BtpInventory.create("assignment-1")
    every { repository.lockAndLoad("assignment-1") } returns inventory
    justRun { repository.save(inventory) }
    val assignment = mockk<TeamAssignment> {
      every { id } returns "assignment-1"
      every { operation } returns Operation("CUT")
    }
    val useCase = RecordBtpProducedUseCase(repository)
    val reportedAt = Instant.parse("2026-07-01T00:00:00Z")
    val positive = listOf(ReportItem("po-positive", Color("RED"), Size("M"), 5))
    val regular = listOf(
      ReportItem("po-1", Color("RED"), Size("M"), 6),
      ReportItem("po-2", Color("RED"), Size("M"), 4),
    )

    useCase.execute(assignment, positive, reportedAt, null, "POSITIVE")
    useCase.execute(assignment, regular, reportedAt, null)
    useCase.execute(assignment, positive, reportedAt, null, "POSITIVE")
    useCase.execute(assignment, regular, reportedAt, null)

    inventory.balance(BtpSku("BTP CUT", "RED", "M")) shouldBe BigDecimal(15)
    inventory.changes.size shouldBe 2
  }
}
