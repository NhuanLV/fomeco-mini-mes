package vn.lgg.mesplus.production.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.ReportType
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.service.PermissionService

class ReportMutationRulesTest {
  private val reportedAt = Instant.parse("2026-07-15T08:00:00Z")
  private val repository = mockk<TeamAssignmentRepository>()
  private val permissionService = mockk<PermissionService>()
  private val allocationQueryService = mockk<AllocationQueryService>()
  private val eventPublisher = mockk<DomainEventPublisher>(relaxed = true)
  private val actor = Actor("actor-1", "Reporter", "reporter", "", emptyList(), emptySet())

  @Test
  fun `persisted output cannot be updated even without GRN`() {
    arrange(ReportType.OUTPUT)

    shouldThrow<IllegalStateException> {
      updateUseCase().execute("ta-1", command(), actor)
    }.message shouldBe "Không thể chỉnh sửa báo Ra chuyền đã lưu"
    verify(exactly = 0) { repository.save(any()) }
  }

  @Test
  fun `persisted output cannot be deleted even without GRN`() {
    arrange(ReportType.OUTPUT)

    shouldThrow<IllegalStateException> {
      deleteUseCase().execute("ta-1", reportedAt, actor)
    }.message shouldBe "Không thể xóa báo Ra chuyền đã lưu"
    verify(exactly = 0) { repository.save(any()) }
  }

  @Test
  fun `input report can be updated`() {
    arrange(ReportType.INPUT)

    updateUseCase().execute("ta-1", command(), actor)

    verify(exactly = 1) { repository.save(any()) }
  }

  @Test
  fun `input report can be deleted`() {
    arrange(ReportType.INPUT)

    deleteUseCase().execute("ta-1", reportedAt, actor)

    verify(exactly = 1) { repository.save(any()) }
  }

  private fun arrange(type: ReportType) {
    every { repository.findById("ta-1") } returns assignment(type)
    every { repository.save(any()) } answers { firstArg() }
    justRun { permissionService.requirePermission(actor, any(), any()) }
    justRun { allocationQueryService.requireWithinBuyerOrderQuantity("bo-1") }
    justRun { allocationQueryService.requireActive("lsx-1") }
  }

  private fun updateUseCase() =
    UpdateLastReportUseCase(repository, permissionService, allocationQueryService, eventPublisher)

  private fun deleteUseCase() =
    DeleteLastReportUseCase(repository, permissionService, allocationQueryService, eventPublisher)

  private fun assignment(type: ReportType) =
    TeamAssignment("ta-1").apply {
      loadFromHistory(
        listOf(
          TeamAssignmentCreated(
            assignmentId = "ta-1",
            productionOrderId = "lsx-1",
            buyerOrderId = "bo-1",
            teamId = "team-1",
            operation = Operation("CUT"),
            allocations = listOf(SkuAllocation("po-1", Color("RED"), Size("M"), 10)),
            plannedStartDate = LocalDate.of(2026, 1, 1),
            plannedEndDate = LocalDate.of(2026, 1, 10),
            assignedAt = reportedAt.minusSeconds(60),
            actor = actor.ref,
          ),
          ProgressReported(
            assignmentId = "ta-1",
            type = type,
            items = listOf(ReportItem("po-1", Color("RED"), Size("M"), 1)),
            actor = actor.ref,
            occurredAt = reportedAt,
          ),
        ),
      )
    }

  private fun command() =
    ReportCommand(type = ReportType.INPUT, items = listOf(ReportItemCommand("po-1", Color("RED"), Size("M"), 1)))
}
