package vn.lgg.mesplus.production.domain.model

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.PurchaseOrderQuantityAdjusted
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size

class TeamAssignmentQuantityCharacterizationTest {
  private val actor = ActorRef("actor-1", "Planner")

  @Test
  fun `initializes assignment with explicit planned dates without hardcoded fallbacks`() {
    val start = LocalDate.of(2026, 3, 1)
    val end = LocalDate.of(2026, 3, 15)
    val created = TeamAssignment.create(
      id = "ta-new",
      productionOrderId = "lsx-1",
      buyerOrderId = "bo-1",
      teamId = "team-1",
      operation = Operation("Sew"),
      allocations = listOf(allocation("po-1", 10)),
      plannedStartDate = start,
      plannedEndDate = end,
    )

    created.plannedStartDate shouldBe start
    created.plannedEndDate shouldBe end

    val event = created.changes.single() as TeamAssignmentCreated
    event.plannedStartDate shouldBe start
    event.plannedEndDate shouldBe end
  }

  @Test
  fun `aggregates duplicate report keys and removes effective zero totals`() {
    val assignment =
      assignment(
        allocations = listOf(allocation("po-1", 10), allocation("po-2", 10)),
        extraEvents =
          listOf(
            report(ReportType.INPUT, item("po-1", 2), item("po-1", 3)),
            report(ReportType.OUTPUT, item("po-1", 4), item("po-1", 3)),
            adjustment(delta("po-1", -7), delta("po-2", 7)),
          ),
      )

    assignment.rawInputReportedTotals.map { it.quantity }.shouldContainExactly(5)
    assignment.rawOutputReportedTotals.map { it.quantity }.shouldContainExactly(7)
    assignment.outputReportedTotals.shouldContainExactly(item("po-2", 7))
    assignment.reconciliationStatus shouldBe ReconciliationStatus.NORMAL
  }

  @Test
  fun `marks assignment for reconciliation when effective output exceeds allocation`() {
    val assignment = assignment(extraEvents = listOf(report(ReportType.OUTPUT, item("po-1", 11))))

    assignment.reconciliationStatus shouldBe ReconciliationStatus.NEEDS_ADJUSTMENT
  }

  @Test
  fun `derives one display status with reconciliation taking priority`() {
    assignment().displayStatus shouldBe TeamAssignmentDisplayStatus.NOT_STARTED

    assignment(extraEvents = listOf(report(ReportType.INPUT, item("po-1", 1)))).displayStatus shouldBe
      TeamAssignmentDisplayStatus.IN_PROGRESS

    assignment(extraEvents = listOf(report(ReportType.OUTPUT, item("po-1", 10)))).displayStatus shouldBe
      TeamAssignmentDisplayStatus.COMPLETED

    assignment(extraEvents = listOf(report(ReportType.OUTPUT, item("po-1", 11)))).displayStatus shouldBe
      TeamAssignmentDisplayStatus.NEEDS_ADJUSTMENT
  }

  @Test
  fun `rejects unbalanced negative and still over-allocated adjustments`() {
    val unbalanced = assignment(extraEvents = listOf(report(ReportType.OUTPUT, item("po-1", 11))))
    shouldThrow<IllegalArgumentException> {
      unbalanced.adjustPurchaseOrderQuantity("Đối soát", listOf(delta("po-1", -1)), actor)
    }

    val negative =
      assignment(
        allocations = listOf(allocation("po-1", 5), allocation("po-2", 10)),
        extraEvents = listOf(report(ReportType.OUTPUT, item("po-1", 8))),
      )
    shouldThrow<IllegalArgumentException> {
      negative.adjustPurchaseOrderQuantity(
        "Đối soát",
        listOf(delta("po-1", -9), delta("po-2", 9)),
        actor,
      )
    }

    val stillOver =
      assignment(
        allocations = listOf(allocation("po-1", 5), allocation("po-2", 1)),
        extraEvents = listOf(report(ReportType.OUTPUT, item("po-1", 8))),
      )
    shouldThrow<IllegalArgumentException> {
      stillOver.adjustPurchaseOrderQuantity(
        "Đối soát",
        listOf(delta("po-1", -1), delta("po-2", 1)),
        actor,
      )
    }
  }

  @Test
  fun `output cannot exceed input or allocation`() {
    val exceedsInput = assignment(extraEvents = listOf(report(ReportType.INPUT, item("po-1", 2))))
    shouldThrow<IllegalStateException> {
      exceedsInput.reportProgress(ReportType.OUTPUT, listOf(item("po-1", 3)), actor)
    }

    val exceedsAllocation =
      assignment(extraEvents = listOf(report(ReportType.INPUT, item("po-1", 20))))
    shouldThrow<IllegalStateException> {
      exceedsAllocation.reportProgress(ReportType.OUTPUT, listOf(item("po-1", 11)), actor)
    }
  }

  private fun assignment(
    allocations: List<SkuAllocation> = listOf(allocation("po-1", 10)),
    extraEvents: List<DomainEvent> = emptyList(),
  ) =
    TeamAssignment("ta-1").apply {
      loadFromHistory(
        listOf(
          TeamAssignmentCreated(
            assignmentId = "ta-1",
            productionOrderId = "lsx-1",
            buyerOrderId = "bo-1",
            teamId = "team-1",
            operation = Operation("Sew"),
            allocations = allocations,
            plannedStartDate = LocalDate.of(2026, 1, 1),
            plannedEndDate = LocalDate.of(2026, 1, 10),
            assignedAt = Instant.parse("2026-01-01T00:00:00Z"),
            actor = actor,
          )
        ) + extraEvents,
      )
    }

  private fun report(type: ReportType, vararg items: ReportItem) =
    ProgressReported("ta-1", type, items.toList(), actor)

  private fun adjustment(vararg deltas: PurchaseOrderQuantityDelta) =
    PurchaseOrderQuantityAdjusted("ta-1", "Đối soát", deltas.toList(), actor)

  private fun item(purchaseOrderId: String, quantity: Int) =
    ReportItem(purchaseOrderId, Color("Red"), Size("S"), quantity)

  private fun delta(purchaseOrderId: String, quantity: Int) =
    PurchaseOrderQuantityDelta(purchaseOrderId, Color("Red"), Size("S"), quantity)

  private fun allocation(purchaseOrderId: String, quantity: Int) =
    SkuAllocation(purchaseOrderId, Color("Red"), Size("S"), quantity)
}
