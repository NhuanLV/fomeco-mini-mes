package vn.lgg.mesplus.order.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderStatus
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.SkuQuantity

class AddPositivePurchaseOrderTest {
  private val boRepository = mockk<BuyerOrderRepository>()
  private val poRepository = mockk<PurchaseOrderRepository>()
  private val actor = mockk<Actor>()
  private val useCase = AddPositivePurchaseOrderUseCase(boRepository, poRepository)

  private fun existingPo(code: String = "PO-1") = PurchaseOrder(
    "00000000-0000-0000-0000-000000000001", "WFX-1", code, "US", LocalDate.of(2026, 9, 1),
    listOf(SkuQuantity(Color("Red"), Size("S"), 10)), "00000000-0000-0000-0000-000000000010",
  )

  private fun command(code: String = "PO-2", quantity: String = "5") = AddPositivePurchaseOrderCommand(
    code, "US", LocalDate.of(2025, 1, 1),
    listOf(PositiveSkuQuantityCommand(Color("Red"), Size("S"), BigDecimal(quantity))),
  )

  private fun arrange(status: BuyerOrderStatus = BuyerOrderStatus.RELEASED, pos: List<PurchaseOrder> = listOf(existingPo())): BuyerOrder {
    val bo = BuyerOrder("00000000-0000-0000-0000-000000000010", "BO-1", "STYLE", "1", Instant.EPOCH,
      status = status, totalQuantity = 10, completedQuantity = 7)
    every { actor.ref } returns ActorRef("user-1", "Planner")
    every { boRepository.lockById(bo.id) } returns bo
    every { poRepository.findByBuyerOrderId(bo.id) } returns pos
    every { poRepository.save(any()) } returns Unit
    every { boRepository.save(any()) } returns Unit
    return bo
  }

  @Test
  fun `saves positive PO and reopens released BO`() {
    val bo = arrange()
    val saved = slot<PurchaseOrder>()
    every { poRepository.save(capture(saved)) } returns Unit

    useCase.execute(bo.id, command(), actor)

    saved.captured.type shouldBe PurchaseOrderType.POSITIVE
    saved.captured.wfxId shouldBe null
    saved.captured.createdBy shouldBe ActorRef("user-1", "Planner")
    saved.captured.totalQuantity shouldBe 5
    bo.totalQuantity shouldBe 15
    bo.completedQuantity shouldBe 7
    bo.status shouldBe BuyerOrderStatus.PROCESSING
    verify(exactly = 1) { poRepository.save(any()) }
    verify(exactly = 1) { boRepository.save(bo) }
  }

  @Test
  fun `allows an existing display code for a new positive PO`() {
    val bo = arrange(pos = listOf(existingPo("PO-1")))
    val saved = slot<PurchaseOrder>()
    every { poRepository.save(capture(saved)) } returns Unit
    useCase.execute(bo.id, command("PO-1"), actor)
    saved.captured.code shouldBe "PO-1"
    (saved.captured.id != existingPo().id) shouldBe true
    verify(exactly = 1) { poRepository.save(any()) }
  }

  @Test
  fun `rejects decimal and out-of-scope SKU without saving`() {
    val bo = arrange()
    shouldThrow<IllegalArgumentException> { useCase.execute(bo.id, command(quantity = "1.5"), actor) }
    shouldThrow<IllegalArgumentException> {
      useCase.execute(bo.id, command().copy(skuQuantities = listOf(
        PositiveSkuQuantityCommand(Color("Blue"), Size("S"), BigDecimal.ONE),
      )), actor)
    }
    verify(exactly = 0) { poRepository.save(any()) }
  }

  @Test
  fun `throws NoSuchElementException when BO does not exist`() {
    every { boRepository.lockById("invalid-id") } returns null
    shouldThrow<NoSuchElementException> { useCase.execute("invalid-id", command(), actor) }
  }

  @Test
  fun `rejects when BO has no POs or lacks market or size-color baseline`() {
    val bo = arrange(pos = emptyList())
    shouldThrow<IllegalArgumentException> { useCase.execute(bo.id, command(), actor) }
  }

  @Test
  fun `rejects when total quantity is zero`() {
    val bo = arrange()
    shouldThrow<IllegalArgumentException> {
      useCase.execute(bo.id, command().copy(skuQuantities = listOf(
        PositiveSkuQuantityCommand(Color("Red"), Size("S"), BigDecimal.ZERO),
      )), actor)
    }
    verify(exactly = 0) { poRepository.save(any()) }
  }
}
