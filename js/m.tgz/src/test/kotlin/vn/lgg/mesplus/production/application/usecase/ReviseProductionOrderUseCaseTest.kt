package vn.lgg.mesplus.production.application.usecase

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.justRun
import io.mockk.mockk
import io.mockk.verify
import java.time.Instant
import java.time.LocalDate
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.order.domain.model.BuyerOrder
import vn.lgg.mesplus.order.domain.model.BuyerOrderAdjustmentRequired
import vn.lgg.mesplus.order.domain.model.PurchaseOrder
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType
import vn.lgg.mesplus.order.domain.repository.BuyerOrderRepository
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.order.domain.service.AllocationQueryService
import vn.lgg.mesplus.order.infrastructure.wfx.WfxSyncException
import vn.lgg.mesplus.production.application.service.ProductionOrderActivityLog
import vn.lgg.mesplus.production.application.service.ProductionOrderActivityRecorder
import vn.lgg.mesplus.production.application.service.ProductionOrderActivitySyncStatus
import vn.lgg.mesplus.production.application.service.ProductionOrderActivityType
import vn.lgg.mesplus.production.application.service.FppoSyncService
import vn.lgg.mesplus.production.application.usecase.command.ReviseTeamAssignmentAllocationCommand
import vn.lgg.mesplus.production.application.usecase.command.RevisedTeamAssignmentCommandData
import vn.lgg.mesplus.production.domain.event.ProgressReported
import vn.lgg.mesplus.production.domain.event.TeamAssignmentCreated
import vn.lgg.mesplus.production.domain.model.ProductionOrder
import vn.lgg.mesplus.production.domain.model.ProductionOrderStatus
import vn.lgg.mesplus.production.domain.model.ReportItem
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.domain.model.TeamAssignment
import org.springframework.util.SimpleIdGenerator
import vn.lgg.mesplus.production.domain.repository.ProductionOrderRepository
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.shared.DomainEvent
import vn.lgg.mesplus.shared.DomainEventPublisher
import vn.lgg.mesplus.shared.Notifier
import vn.lgg.mesplus.shared.ResourceType
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Size
import vn.lgg.mesplus.shared.model.SkuQuantity
import vn.lgg.mesplus.shared.service.PermissionService

class ReviseProductionOrderUseCaseTest {
  private val buyerOrderRepository = mockk<BuyerOrderRepository>()
  private val purchaseOrderRepository = mockk<PurchaseOrderRepository>()
  private val productionOrderRepository = mockk<ProductionOrderRepository>()
  private val teamAssignmentRepository = mockk<TeamAssignmentRepository>()
  private val permissionService = mockk<PermissionService>()
  private val eventPublisher = mockk<DomainEventPublisher>()
  private val createTeamMaterialUseCase = mockk<CreateTeamMaterialUseCase>()
  private val allocationQueryService = mockk<AllocationQueryService>()
  private val fppoSyncService = mockk<FppoSyncService>()
  private val notifier = mockk<Notifier>()
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val activityLog = mockk<ProductionOrderActivityLog>()
  private val activityRecorder = ProductionOrderActivityRecorder(
    activityLog, orgUnitRepository, SimpleIdGenerator(),
  )
  private val actor = Actor("actor-1", "Planner", "planner", "", emptyList(), emptySet())

  private val useCase =
    ReviseProductionOrderUseCase(
      buyerOrderRepository,
      purchaseOrderRepository,
      productionOrderRepository,
      teamAssignmentRepository,
      permissionService,
      eventPublisher,
      createTeamMaterialUseCase,
      allocationQueryService,
      fppoSyncService,
      notifier,
      orgUnitRepository,
      activityRecorder,
    )

  @BeforeEach
  fun setUp() {
    justRun { activityLog.append(any()) }
    every { productionOrderRepository.findById("lsx-1") } returns productionOrder()
    every { productionOrderRepository.lockById(any()) } answers { productionOrderRepository.findById(firstArg()) }
    every { buyerOrderRepository.findById("bo-1") } returns buyerOrder()
    every { buyerOrderRepository.lockById("bo-1") } returns buyerOrder()
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns
      listOf(purchaseOrder("po-1", 100))
    justRun { permissionService.requirePermission(actor, any(), any()) }
    every { teamAssignmentRepository.save(any()) } answers { firstArg() }
    justRun { eventPublisher.publish(any<List<DomainEvent>>()) }
    justRun { createTeamMaterialUseCase.mergeMissingDependencies(any(), actor.ref) }
    every { allocationQueryService.needsAdjustment("bo-1", any()) } returns false
    justRun { fppoSyncService.syncFppo(any(), any(), any(), any()) }
    justRun { notifier.notify(any<Collection<String>>(), any()) }
    every { orgUnitRepository.findById(any()) } answers {
      Team(
        id = firstArg(),
        name = "Team",
        parentId = "factory-1",
        factoryId = "factory-1",
        operation = Operation("Sew"),
        isActive = true,
        code = firstArg(),
      )
    }
  }

  @Test
  fun `requires a full snapshot of every assignment`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()

    shouldThrow<IllegalArgumentException> {
      useCase.execute(command(listOf(revision("ta-cut", 20))), actor)
    }

    verify(exactly = 0) { teamAssignmentRepository.save(any()) }
  }

  @Test
  fun `rejects mismatched sku totals between operations`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()

    shouldThrow<IllegalArgumentException> {
      useCase.execute(
        command(listOf(revision("ta-cut", 20), revision("ta-sew", 21))),
        actor,
      )
    }

    verifyNoMutation()
  }

  @Test
  fun `rejects duplicate sku in an assignment without side effects`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()
    val duplicate =
      RevisedTeamAssignmentCommandData("ta-cut", listOf(allocation(10), allocation(10)))

    shouldThrow<IllegalArgumentException> {
      useCase.execute(command(listOf(duplicate, revision("ta-sew", 20))), actor)
    }

    verifyNoMutation()
  }

  @Test
  fun `rejects allocation below maximum effective production`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns
      assignments(reportedAtSew = 12)

    shouldThrow<IllegalArgumentException> {
      useCase.execute(
        command(listOf(revision("ta-cut", 10), revision("ta-sew", 10))),
        actor,
      )
    }

    verifyNoMutation()
  }

  @Test
  fun `accepts current PO colors and sizes not previously allocated for both PO types`() {
    for (type in PurchaseOrderType.entries) {
      val poId = "po-${type.name}"
      val po = PurchaseOrder(
        poId, null, poId, "US", LocalDate.of(2026, 1, 1),
        listOf(SkuQuantity(Color("Blue"), Size("M"), 20)), "bo-1", type,
      )
      val current = listOf(
        assignment("ta-cut", "Cut", poId = poId),
        assignment("ta-sew", "Sew", poId = poId),
      )
      every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(po)
      every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns current
      val newAllocation = SkuAllocation(poId, Color("Blue"), Size("M"), 20)

      useCase.execute(command(current.map {
        RevisedTeamAssignmentCommandData(it.id, listOf(newAllocation))
      }), actor)

      current.forEach { it.allocations shouldBe listOf(newAllocation) }
    }
  }

  @Test
  fun `rejects allocation above buyer order sku quantity`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()

    shouldThrow<IllegalArgumentException> {
      useCase.execute(
        command(listOf(revision("ta-cut", 101), revision("ta-sew", 101))),
        actor,
      )
    }
  }

  @Test
  fun `rejects allocation for a sku removed from buyer order`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns
      listOf(purchaseOrder("po-1", null))

    shouldThrow<IllegalArgumentException> {
      useCase.execute(
        command(listOf(revision("ta-cut", 9), revision("ta-sew", 9))),
        actor,
      )
    }
  }

  @Test
  fun `rejects an entirely empty production order`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()

    shouldThrow<IllegalArgumentException> {
      useCase.execute(
        command(listOf(emptyRevision("ta-cut"), emptyRevision("ta-sew"))),
        actor,
      )
    }
  }

  @Test
  fun `saves all changed assignments and publishes their events`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()

    useCase.execute(
      command(listOf(revision("ta-cut", 20), revision("ta-sew", 20))),
      actor,
    )

    verify(exactly = 1) { activityLog.append(match {
      it.productionOrderId == "lsx-1" && it.type == ProductionOrderActivityType.REVISE &&
        it.actor == actor.ref && it.syncStatus == ProductionOrderActivitySyncStatus.SUCCESS &&
        it.changes.size == 2 && it.changes.all { change -> change.before?.quantity == 10 && change.after?.quantity == 20 }
    }) }
    verify(exactly = 2) { teamAssignmentRepository.save(any()) }
    verify(exactly = 2) {
      createTeamMaterialUseCase.mergeMissingDependencies(any(), actor.ref)
    }
    verify(exactly = 1) { eventPublisher.publish(match<List<DomainEvent>> { it.size == 2 }) }
    verify(exactly = 1) { buyerOrderRepository.lockById("bo-1") }
    verify(exactly = 1) {
      fppoSyncService.syncFppo("bo-1", "LGG-BG", match { it.size == 2 }, any())
    }
    verify(exactly = 1) {
      notifier.notify(
        listOf("actor-1"),
        match {
          it.actor == null &&
            it.title == "Đồng bộ WFX thành công" &&
            it.body == "Đã đồng bộ FPO/FPPO lên WFX và điều chỉnh lệnh STYLE-1 thành công." &&
            it.target.resourceType == ResourceType.PRODUCTION_ORDER &&
            it.target.resourceId == "lsx-1"
        },
      )
    }
  }

  @Test
  fun `propagates WFX failure without publishing events or notification`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()
    every { fppoSyncService.syncFppo("bo-1", "LGG-BG", any(), any()) } throws
      WfxSyncException.business("Invalid FPPO")

    shouldThrow<WfxSyncException> {
      useCase.execute(
        command(listOf(revision("ta-cut", 20), revision("ta-sew", 20))),
        actor,
      )
    }

    verify(exactly = 0) { teamAssignmentRepository.save(any()) }
    verify(exactly = 0) { eventPublisher.publish(any<List<DomainEvent>>()) }
    verify(exactly = 0) { activityLog.append(any()) }
    verify(exactly = 0) { notifier.notify(any<Collection<String>>(), any()) }
  }

  @Test
  fun `publishes buyer order event only on transition to needs adjustment`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()
    every { allocationQueryService.needsAdjustment("bo-1", any()) } returnsMany
      listOf(false, true)
    justRun { eventPublisher.publish(any<BuyerOrderAdjustmentRequired>()) }

    useCase.execute(
      command(listOf(revision("ta-cut", 20), revision("ta-sew", 20))),
      actor,
    )

    verify(exactly = 1) {
      eventPublisher.publish(
        match<BuyerOrderAdjustmentRequired> {
          it.buyerOrderId == "bo-1" && it.actor == actor.ref
        },
      )
    }
  }

  @Test
  fun `does not save or publish a no-op snapshot`() {
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()

    useCase.execute(
      command(listOf(revision("ta-cut", 10), revision("ta-sew", 10)), reason = ""),
      actor,
    )

    verify(exactly = 0) { teamAssignmentRepository.save(any()) }
    verify(exactly = 0) { eventPublisher.publish(any<List<DomainEvent>>()) }
    verify(exactly = 0) { fppoSyncService.syncFppo(any(), any(), any(), any()) }
    verify(exactly = 0) { activityLog.append(any()) }
    verify(exactly = 0) { notifier.notify(any<Collection<String>>(), any()) }
  }

  @Test
  fun `revises positive LSX allocations without calling fppo sync and with non-wfx notification`() {
    val posPo = purchaseOrder("po-pos", 100, PurchaseOrderType.POSITIVE)
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(posPo)
    val posAssignments = listOf(
      assignment("ta-cut", "Cut", poId = "po-pos"),
      assignment("ta-sew", "Sew", poId = "po-pos"),
    )
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns posAssignments

    val revisions = listOf(
      RevisedTeamAssignmentCommandData("ta-cut", listOf(allocation(20, poId = "po-pos"))),
      RevisedTeamAssignmentCommandData("ta-sew", listOf(allocation(20, poId = "po-pos"))),
    )
    useCase.execute(command(revisions), actor)

    verify(exactly = 2) { teamAssignmentRepository.save(any()) }
    verify(exactly = 0) { fppoSyncService.syncFppo(any(), any(), any(), any()) }
    verify(exactly = 1) {
      notifier.notify(
        listOf("actor-1"),
        match {
          it.title == "Điều chỉnh lệnh thành công" &&
            it.body == "Đã điều chỉnh lệnh STYLE-1 thành công."
        },
      )
    }
  }

  @Test
  fun `rejects adding positive PO allocations to an existing regular LSX`() {
    val regPo = purchaseOrder("po-1", 100, PurchaseOrderType.REGULAR)
    val posPo = purchaseOrder("po-pos", 100, PurchaseOrderType.POSITIVE)
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(regPo, posPo)
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()

    val revisions = listOf(
      RevisedTeamAssignmentCommandData("ta-cut", listOf(allocation(5, poId = "po-1"), allocation(5, poId = "po-pos"))),
      RevisedTeamAssignmentCommandData("ta-sew", listOf(allocation(5, poId = "po-1"), allocation(5, poId = "po-pos"))),
    )

    shouldThrow<IllegalArgumentException> { useCase.execute(command(revisions), actor) }
    verifyNoMutation()
    verify(exactly = 0) { fppoSyncService.syncFppo(any(), any(), any(), any()) }
  }

  @Test
  fun `rejects changing regular LSX to positive even without output`() {
    val regPo = purchaseOrder("po-1", 100, PurchaseOrderType.REGULAR)
    val posPo = purchaseOrder("po-pos", 100, PurchaseOrderType.POSITIVE)
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(regPo, posPo)
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()

    val revisions = listOf(
      RevisedTeamAssignmentCommandData("ta-cut", listOf(allocation(10, poId = "po-pos"))),
      RevisedTeamAssignmentCommandData("ta-sew", listOf(allocation(10, poId = "po-pos"))),
    )

    shouldThrow<IllegalArgumentException> { useCase.execute(command(revisions), actor) }
    verifyNoMutation()
    verify(exactly = 0) { fppoSyncService.syncFppo(any(), any(), any(), any()) }
  }

  @Test
  fun `rejects changing positive LSX to regular even without output`() {
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      purchaseOrder("po-1", 100), purchaseOrder("po-pos", 100, PurchaseOrderType.POSITIVE),
    )
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns listOf(
      assignment("ta-cut", "Cut", poId = "po-pos"), assignment("ta-sew", "Sew", poId = "po-pos"),
    )
    shouldThrow<IllegalArgumentException> {
      useCase.execute(command(listOf(revision("ta-cut", 10), revision("ta-sew", 10))), actor)
    }
    verifyNoMutation()
  }

  @Test
  fun `allows changing to another PO of the same type in the BO`() {
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      purchaseOrder("po-1", 100), purchaseOrder("po-2", 100),
    )
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments()
    useCase.execute(command(listOf("ta-cut", "ta-sew").map {
      RevisedTeamAssignmentCommandData(it, listOf(allocation(10, "po-2")))
    }), actor)
    verify(exactly = 2) { teamAssignmentRepository.save(any()) }
  }

  @Test
  fun `rejects removing all regular allocations from a mixed LSX`() {
    assertMixedRevisionRejected("po-pos")
  }

  @Test
  fun `rejects removing all positive allocations from a mixed LSX`() {
    assertMixedRevisionRejected("po-1")
  }

  @Test
  fun `allows reducing both types while keeping a mixed LSX`() {
    arrangeMixedAssignments()
    useCase.execute(command(listOf("ta-cut", "ta-sew").map {
      RevisedTeamAssignmentCommandData(it, listOf(allocation(5), allocation(5, "po-pos")))
    }), actor)
    verify(exactly = 2) { teamAssignmentRepository.save(any()) }
  }

  private fun assertMixedRevisionRejected(remainingPoId: String) {
    arrangeMixedAssignments()
    shouldThrow<IllegalArgumentException> {
      useCase.execute(command(listOf("ta-cut", "ta-sew").map {
        RevisedTeamAssignmentCommandData(it, listOf(allocation(10, remainingPoId)))
      }), actor)
    }.message shouldBe "LSX hỗn hợp phải còn phân bổ của cả PO thường và PO hàng dương"
    verifyNoMutation()
    verify(exactly = 0) { fppoSyncService.syncFppo(any(), any(), any(), any()) }
  }

  private fun arrangeMixedAssignments() {
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      purchaseOrder("po-1", 100),
      purchaseOrder("po-pos", 100, PurchaseOrderType.POSITIVE),
    )
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments().map { existing ->
      TeamAssignment(existing.id).apply {
        loadFromHistory(existing.allEvents.map {
          (it as TeamAssignmentCreated).copy(allocations = listOf(allocation(10), allocation(10, "po-pos")))
        })
      }
    }
  }

  @Test
  fun `cannot replace produced regular capacity with positive allocations`() {
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      purchaseOrder("po-1", 100, PurchaseOrderType.REGULAR),
      purchaseOrder("po-pos", 100, PurchaseOrderType.POSITIVE),
    )
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns assignments(reportedAtSew = 6)
    shouldThrow<IllegalArgumentException> {
      useCase.execute(command(listOf(
        RevisedTeamAssignmentCommandData("ta-cut", listOf(allocation(5), allocation(5, poId = "po-pos"))),
        RevisedTeamAssignmentCommandData("ta-sew", listOf(allocation(5), allocation(5, poId = "po-pos"))),
      )), actor)
    }
    verify(exactly = 0) { teamAssignmentRepository.save(any()) }
  }

  @Test
  fun `rejects replacing a teams produced regular capacity even when operation totals match`() {
    every { purchaseOrderRepository.findByBuyerOrderId("bo-1") } returns listOf(
      purchaseOrder("po-1", 100), purchaseOrder("po-pos", 100, PurchaseOrderType.POSITIVE),
    )
    fun mixedAssignment(id: String, operation: String, regular: Int, positive: Int) =
      TeamAssignment(id).apply {
        val created = assignment(id, operation).allEvents.first() as TeamAssignmentCreated
        loadFromHistory(listOf(created.copy(allocations = listOf(allocation(regular), allocation(positive, "po-pos")))))
      }
    val cut = mixedAssignment("ta-cut", "Cut", 100, 10)
    val teamA = mixedAssignment("ta-sew", "Sew", 60, 5).apply {
      loadFromHistory(listOf(ProgressReported(assignmentId = id, items = listOf(
        ReportItem("po-1", Color("Red"), Size("S"), 60),
        ReportItem("po-pos", Color("Red"), Size("S"), 5),
      ), actor = actor.ref)))
    }
    val teamB = mixedAssignment("ta-sew-b", "Sew", 40, 5)
    every { teamAssignmentRepository.findByProductionOrderId("lsx-1") } returns listOf(cut, teamA, teamB)
    shouldThrow<IllegalArgumentException> {
      useCase.execute(command(listOf(
        RevisedTeamAssignmentCommandData(cut.id, listOf(allocation(100), allocation(10, "po-pos"))),
        RevisedTeamAssignmentCommandData(teamA.id, listOf(allocation(55), allocation(10, "po-pos"))),
        RevisedTeamAssignmentCommandData(teamB.id, listOf(allocation(45))),
      )), actor)
    }
    verifyNoMutation()
  }

  private fun command(
    revisions: List<RevisedTeamAssignmentCommandData>,
    reason: String = "Cân đối lại",
  ) =
    ReviseTeamAssignmentAllocationCommand(
      buyerOrderId = "bo-1",
      productionOrderId = "lsx-1",
      reason = reason,
      teamAssignments = revisions,
    )

  private fun revision(id: String, quantity: Int) =
    RevisedTeamAssignmentCommandData(id, listOf(allocation(quantity)))

  private fun emptyRevision(id: String) = RevisedTeamAssignmentCommandData(id, emptyList())

  private fun assignments(reportedAtSew: Int = 0) =
    listOf(
      assignment("ta-cut", "Cut"),
      assignment("ta-sew", "Sew", reportedAtSew),
    )

  private fun assignment(id: String, operation: String, reported: Int = 0, poId: String = "po-1") =
    TeamAssignment(id).apply {
      val events =
        mutableListOf<DomainEvent>(
          TeamAssignmentCreated(
            assignmentId = id,
            productionOrderId = "lsx-1",
            buyerOrderId = "bo-1",
            teamId = "team-$id",
            operation = Operation(operation),
            allocations = listOf(allocation(10, poId)),
            plannedStartDate = LocalDate.of(2026, 1, 1),
            plannedEndDate = LocalDate.of(2026, 1, 10),
            assignedAt = Instant.parse("2026-01-01T00:00:00Z"),
            actor = actor.ref,
          ),
        )
      if (reported > 0) {
        events +=
          ProgressReported(
            assignmentId = id,
            items = listOf(ReportItem(poId, Color("Red"), Size("S"), reported)),
            actor = actor.ref,
          )
      }
      loadFromHistory(events)
    }

  private fun allocation(quantity: Int, poId: String = "po-1") =
    SkuAllocation(poId, Color("Red"), Size("S"), quantity)

  private fun buyerOrder() =
    BuyerOrder("bo-1", "WFX-1", "STYLE", "1", Instant.parse("2026-01-01T00:00:00Z"))

  private fun purchaseOrder(
    id: String,
    quantity: Int?,
    type: PurchaseOrderType = PurchaseOrderType.REGULAR,
  ) =
    PurchaseOrder(
      id = id,
      wfxId = "wfx-$id",
      code = id,
      destination = "US",
      deliveryDate = LocalDate.of(2026, 1, 1),
      skuQties =
        quantity?.let { listOf(SkuQuantity(Color("Red"), Size("S"), it)) } ?: emptyList(),
      buyerOrderId = "bo-1",
      type = type,
    )

  private fun productionOrder() =
    ProductionOrder(
      id = "lsx-1",
      buyerOrderId = "bo-1",
      productionCode = "STYLE-1",
      factoryIds = listOf("factory-1"),
      mainCompanyCode = "LGG-BG",
      status = ProductionOrderStatus.COMPLETED,
      routing = listOf("Cut", "Sew"),
    )

  private fun verifyNoMutation() {
    verify(exactly = 0) { teamAssignmentRepository.save(any()) }
    verify(exactly = 0) { eventPublisher.publish(any<List<DomainEvent>>()) }
    verify(exactly = 0) { createTeamMaterialUseCase.mergeMissingDependencies(any(), any()) }
  }
}
