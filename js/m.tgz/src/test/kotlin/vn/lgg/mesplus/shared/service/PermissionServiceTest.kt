package vn.lgg.mesplus.shared.service

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.iam.domain.model.Company
import vn.lgg.mesplus.iam.domain.model.Corporation
import vn.lgg.mesplus.iam.domain.model.Factory
import vn.lgg.mesplus.iam.domain.model.Team
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.iam.domain.repository.RoleRepository
import vn.lgg.mesplus.iam.domain.repository.UnitMembershipRepository
import vn.lgg.mesplus.shared.model.Operation
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.MembershipInfo

class PermissionServiceTest {
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val roleRepository = mockk<RoleRepository>()
  private val membershipRepository = mockk<UnitMembershipRepository>()
  private val service =
    PermissionService(orgUnitRepository, roleRepository, membershipRepository)

  @Test
  fun `looks up distinct accounts with permission on the target unit or an ancestor`() {
    every { orgUnitRepository.findById("team-1") } returns team()
    every { orgUnitRepository.findById("factory-1") } returns factory()
    every { orgUnitRepository.findById("company-1") } returns company()
    every { orgUnitRepository.findById(Corporation.DEFAULT_ID) } returns
      corporation(Corporation.DEFAULT_ID)
    every {
      membershipRepository.findAccountIdsByUnitAndPermission("team-1", Permission.UPDATE_COSTING)
    } returns listOf("team-user")
    every {
      membershipRepository.findAccountIdsByUnitAndPermission(
        "factory-1",
        Permission.UPDATE_COSTING,
      )
    } returns listOf("factory-user", "shared-user")
    every {
      membershipRepository.findAccountIdsByUnitAndPermission(
        "company-1",
        Permission.UPDATE_COSTING,
      )
    } returns listOf("company-user", "shared-user")
    every {
      membershipRepository.findAccountIdsByUnitAndPermission(
        Corporation.DEFAULT_ID,
        Permission.UPDATE_COSTING,
      )
    } returns listOf("corporation-user")

    service.lookupAccountIds(Permission.UPDATE_COSTING, "team-1") shouldContainExactly
      listOf("team-user", "factory-user", "shared-user", "company-user", "corporation-user")
  }

  @Test
  fun `keeps the default corporation membership global across corporation roots`() {
    val actor =
      Actor(
        "actor-1",
        "Admin",
        "_username",
        "_password",
        listOf(MembershipInfo(Corporation.DEFAULT_ID, setOf("admin-role"))),
        emptySet(),
      )
    every {
      roleRepository.hasPermission(setOf("admin-role"), Permission.MANAGE_ORG)
    } returns true

    service.hasPermission(actor, listOf(Permission.MANAGE_ORG), listOf("corporation-2")) shouldBe true
  }

  @Test
  fun `does not grant non-default corporation membership across separate roots`() {
    val actor =
      Actor(
        "actor-1",
        "Manager",
        "_username",
        "_password",
        listOf(MembershipInfo("corporation-2", setOf("manager-role"))),
        emptySet(),
      )
    every {
      roleRepository.hasPermission(setOf("manager-role"), Permission.MANAGE_ORG)
    } returns true
    every { orgUnitRepository.findById("corporation-3") } returns corporation("corporation-3")

    service.hasPermission(actor, listOf(Permission.MANAGE_ORG), listOf("corporation-3")) shouldBe false
  }

  @Test
  fun `includes all roots and sub-units in lookupUnit for default corporation membership`() {
    val actor =
      Actor(
        "actor-1",
        "Admin",
        "_username",
        "_password",
        listOf(MembershipInfo(Corporation.DEFAULT_ID, setOf("admin-role"))),
        emptySet(),
      )
    every {
      roleRepository.hasPermission(setOf("admin-role"), Permission.MANAGE_ORG)
    } returns true
    every { orgUnitRepository.findRootUnits() } returns
      listOf(corporation(Corporation.DEFAULT_ID), corporation("corporation-2"))
    every { orgUnitRepository.findSubUnits(Corporation.DEFAULT_ID) } returns listOf(company("company-1", Corporation.DEFAULT_ID))
    every { orgUnitRepository.findSubUnits("corporation-2") } returns listOf(company("company-2", "corporation-2"))

    service.lookupUnit(actor, Permission.MANAGE_ORG) shouldContainExactly
      listOf(Corporation.DEFAULT_ID, "company-1", "corporation-2", "company-2")
  }

  @Test
  fun `scopes non-default corporation membership to its own tree in lookupUnit`() {
    val actor =
      Actor(
        "actor-1",
        "Manager",
        "_username",
        "_password",
        listOf(MembershipInfo("corporation-2", setOf("manager-role"))),
        emptySet(),
      )
    every {
      roleRepository.hasPermission(setOf("manager-role"), Permission.MANAGE_ORG)
    } returns true
    every { orgUnitRepository.findSubUnits("corporation-2") } returns listOf(company("company-2", "corporation-2"))

    service.lookupUnit(actor, Permission.MANAGE_ORG) shouldContainExactly
      listOf("corporation-2", "company-2")
  }

  @Test
  fun `includes default corporation members when looking up accounts for another root`() {
    every { orgUnitRepository.findById("corporation-2") } returns corporation("corporation-2")
    every {
      membershipRepository.findAccountIdsByUnitAndPermission(
        "corporation-2",
        Permission.UPDATE_COSTING,
      )
    } returns listOf("corporation-2-user")
    every {
      membershipRepository.findAccountIdsByUnitAndPermission(
        Corporation.DEFAULT_ID,
        Permission.UPDATE_COSTING,
      )
    } returns listOf("default-corporation-user")

    service.lookupAccountIds(Permission.UPDATE_COSTING, "corporation-2") shouldContainExactly
      listOf("corporation-2-user", "default-corporation-user")
  }

  private fun team() =
    Team("team-1", "Team", "factory-1", "factory-1", Operation("Sew"), true)

  private fun factory() =
    Factory("factory-1", "Factory", "company-1", "", "company-1", emptyList(), true)

  private fun company(id: String = "company-1", parentId: String = Corporation.DEFAULT_ID) =
    Company(id, "Company $id", parentId, "")

  private fun corporation(id: String) = Corporation(id, "Corporation $id")
}
