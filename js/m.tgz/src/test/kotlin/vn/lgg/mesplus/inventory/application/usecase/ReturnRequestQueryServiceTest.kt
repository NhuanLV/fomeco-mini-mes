package vn.lgg.mesplus.inventory.application.usecase

import io.kotest.matchers.maps.shouldContainExactly
import io.kotest.assertions.throwables.shouldThrow
import org.springframework.web.server.ResponseStatusException
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.inventory.domain.model.returnrequest.ReturnRequestStatus
import vn.lgg.mesplus.inventory.infrastructure.repository.ReturnRequestAssignmentViewRepository
import vn.lgg.mesplus.inventory.infrastructure.repository.ReturnRequestFilter
import vn.lgg.mesplus.inventory.infrastructure.repository.ReturnRequestViewRepository
import vn.lgg.mesplus.inventory.presentation.controller.InventoryFilterRequest
import vn.lgg.mesplus.inventory.presentation.viewmodel.InventoryFilterOptionsVm
import vn.lgg.mesplus.inventory.presentation.viewmodel.ReturnRequestSummaryVm
import vn.lgg.mesplus.production.infrastructure.repository.TeamAssignmentViewRepository
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService

class ReturnRequestQueryServiceTest {
  private val repository = mockk<ReturnRequestViewRepository>()
  private val permissionService = mockk<PermissionService>()
  private val actor = Actor("actor-1", "Planner", "planner", "", emptyList(), emptySet())
  private val teamRepository = mockk<TeamAssignmentViewRepository>()
  private val service =
    ReturnRequestQueryService(
      repository,
      mockk<ReturnRequestAssignmentViewRepository>(),
      teamRepository,
      permissionService,
      mockk<OrgUnitRepository>(),
    )
  private val options = InventoryFilterOptionsVm(listOf("STYLE"), emptyList(), emptyList(), emptyList())

  @BeforeEach
  fun setUp() {
    every { permissionService.lookupUnit(actor, any()) } returns emptyList()
    every { repository.findFilterOptions(any()) } returns options
    every { repository.findFilterOptions(null) } returns options
  }

  @Test
  fun `created and evaluate options keep actor and pending status filters`() {
    val filters = mutableListOf<ReturnRequestFilter?>()
    every { repository.findFilterOptions(captureNullable(filters)) } returns options

    service.getFilterOptions(actor, "created") shouldBe options
    service.getFilterOptions(actor, "evaluate") shouldBe options

    filters[0]?.createdById shouldBe actor.id
    filters[1]?.teamIds shouldBe emptyList()
    filters[1]?.statuses shouldBe listOf(ReturnRequestStatus.PENDING_APPROVAL)
  }

  @Test
  fun `receive options use receiver units and empty scope`() {
    val filter = slot<ReturnRequestFilter?>()
    every { repository.findFilterOptions(captureNullable(filter)) } returns options

    service.getFilterOptions(actor, "receive") shouldBe options
    filter.captured?.receiverIds shouldBe emptyList()

    every { permissionService.lookupUnit(actor, Permission.RECEIVE_REQUEST) } returns
      listOf("warehouse-1")
    service.getFilterOptions(actor, "receive") shouldBe options
    filter.captured?.receiverIds shouldBe listOf("warehouse-1")
  }

  @Test
  fun `unknown options are rejected and missing tab uses creator scope`() {
    shouldThrow<ResponseStatusException> { service.getFilterOptions(actor, "unknown") }
    val filter = slot<ReturnRequestFilter?>()
    every { repository.findFilterOptions(captureNullable(filter)) } returns options
    service.getFilterOptions(actor, null)
    filter.captured?.createdById shouldBe actor.id
    verify(exactly = 0) { repository.findFilterOptions(null) }
  }

  @Test
  fun `counters keep all keys at zero when permissions are absent`() {
    service.getReturnRequestCounters(actor, InventoryFilterRequest()).shouldContainExactly(
      mapOf("created" to 0, "evaluate" to 0, "receive" to 0)
    )

    verify(exactly = 0) { repository.findSummaries(any(), any()) }
  }

  @Test
  fun `created and evaluate counters preserve request filters`() {
    every { permissionService.lookupUnit(actor, Permission.CREATE_REQUEST) } returns listOf("team-1")
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_REQUEST) } returns listOf("team-1")
    val filters = mutableListOf<ReturnRequestFilter>()
    every { repository.findSummaries(capture(filters), Pageable.unpaged()) } returnsMany
      listOf(page(2), page(3))

    service.getReturnRequestCounters(
      actor,
      InventoryFilterRequest(styleName = listOf("STYLE")),
    ).shouldContainExactly(mapOf("created" to 2, "evaluate" to 3, "receive" to 0))

    filters[0].createdById shouldBe actor.id
    filters[0].styleName shouldBe listOf("STYLE")
    filters[1].teamIds shouldBe listOf("team-1")
    filters[1].statuses shouldBe listOf(ReturnRequestStatus.PENDING_APPROVAL)
  }

  @Test
  fun `evaluate list intersects requested teams with permission scope`() {
    val filter = slot<ReturnRequestFilter>()
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_REQUEST) } returns listOf("team-1")
    every { repository.findSummaries(capture(filter), any()) } returns Page.empty()
    service.findEvaluateRequests(actor, InventoryFilterRequest(teamIds = listOf("team-1", "team-2")), Pageable.unpaged())
    filter.captured.teamIds shouldBe listOf("team-1")
    service.findEvaluateRequests(actor, InventoryFilterRequest(teamIds = listOf("team-2")), Pageable.unpaged())
    filter.captured.teamIds shouldBe emptyList()
    every { permissionService.lookupUnit(actor, Permission.EVALUATE_REQUEST) } returns emptyList()
    service.findEvaluateRequests(actor, InventoryFilterRequest(), Pageable.unpaged())
    filter.captured.teamIds shouldBe emptyList()
  }

  @Test
  fun `full access checks the source team and preserves creator access`() {
    every { teamRepository.findDetailVm("source") } returns mockk { every { teamId } returns "team-2" }
    every { permissionService.hasPermission(actor, any(), listOf("team-2")) } returns false
    every { permissionService.lookupUnit(actor, any()) } returns listOf("team-1")
    service.hasFullAccess(actor, "other", "source") shouldBe false
    every { permissionService.hasPermission(actor, any(), listOf("team-2")) } returns true
    service.hasFullAccess(actor, "other", "source") shouldBe true
    service.hasFullAccess(actor, actor.id, "source") shouldBe true
  }

  private fun page(total: Long): Page<ReturnRequestSummaryVm> =
    mockk {
      every { totalElements } returns total
    }
}
