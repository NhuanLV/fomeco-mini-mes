package vn.lgg.mesplus.order.infrastructure.wfx

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.infrastructure.wfx.client.WfxClient
import vn.lgg.mesplus.order.infrastructure.wfx.client.response.FppoDetailDto
import vn.lgg.mesplus.shared.model.Operation

class FppoResolverTest {
  private val wfxClient = mockk<WfxClient>()
  private val resolver = FppoResolver(wfxClient)

  @Test
  fun `returns unique fppo matched by operation`() {
    every { wfxClient.getFppoDetails("BO-1") } returns
      listOf(
        fppo("CUT", "100"),
        fppo("SEW", "200"),
      )

    val result = resolver.resolve("BO-1", Operation("CUT-1"))

    result.fppoNo shouldBe "100"
  }

  @Test
  fun `fails when no fppo matches operation`() {
    every { wfxClient.getFppoDetails("BO-1") } returns listOf(fppo("SEW", "200"))

    val error =
      shouldThrow<IllegalArgumentException> { resolver.resolve("BO-1", Operation("CUT-1")) }

    error.message shouldBe "Không tìm thấy FPPO cho BO BO-1 và công đoạn CUT-1"
  }

  @Test
  fun `fails when more than one fppo matches operation`() {
    every { wfxClient.getFppoDetails("BO-1") } returns
      listOf(
        fppo("CUT", "100"),
        fppo("CUT-2", "101"),
      )

    val error =
      shouldThrow<IllegalArgumentException> { resolver.resolve("BO-1", Operation("CUT-1")) }

    error.message shouldBe "Có nhiều FPPO (100, 101) cho BO BO-1 và công đoạn CUT-1"
  }

  @Test
  fun `returns a unique fppo when WFX repeats it for multiple sizes`() {
    every { wfxClient.getFppoDetails("BO-1") } returns
      listOf(
        fppo("CUT-1", "100"),
        fppo("CUT-1", "100"),
      )

    val result = resolver.resolve("BO-1", Operation("CUT-1"))

    result.fppoNo shouldBe "100"
  }

  @Test
  fun `fails when another operation in same LSX has multiple fppos`() {
    every { wfxClient.getFppoDetails("BO-1") } returns
      listOf(
        fppo("CUT", "100"),
        fppo("CUT-2", "101"),
        fppo("SEW", "200"),
      )

    val error =
      shouldThrow<IllegalArgumentException> { resolver.resolve("BO-1", Operation("SEW-1")) }

    error.message shouldBe "Có nhiều FPPO (100, 101) cho BO BO-1 và công đoạn CUT"
  }

  private fun fppo(processCode: String, fppoNo: String) =
    FppoDetailDto(
      deliveryOrderCode = "BO-1",
      processCode = processCode,
      fppoNo = fppoNo,
      dispatchSiteName = "DISPATCH",
      receivingSiteName = "RECEIVE",
    )
}
