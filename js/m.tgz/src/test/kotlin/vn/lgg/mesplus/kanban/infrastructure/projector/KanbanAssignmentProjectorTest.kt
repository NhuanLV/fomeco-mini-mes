package vn.lgg.mesplus.kanban.infrastructure.projector

import io.mockk.every
import io.mockk.mockkStatic
import io.mockk.unmockkStatic
import java.math.BigDecimal
import java.util.UUID
import org.jetbrains.exposed.v1.core.statements.UpdateStatement
import org.jetbrains.exposed.v1.jdbc.update
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import tools.jackson.module.kotlin.jacksonObjectMapper
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialIssued
import vn.lgg.mesplus.kanban.domain.event.KanbanMaterialPrepared
import vn.lgg.mesplus.kanban.infrastructure.repository.exposed.KanbanItemPartViewTable
import vn.lgg.mesplus.kanban.infrastructure.repository.exposed.KanbanViewTable
import vn.lgg.mesplus.order.domain.model.PurchaseOrderType

class KanbanAssignmentProjectorTest {
  @Test
  fun `prepare and issue persist different notes on the two BTP parts`() {
    val viewTable = KanbanViewTable(jacksonObjectMapper())
    val partTable = KanbanItemPartViewTable(viewTable)
    val projector = KanbanAssignmentProjector(viewTable, partTable)
    val notes = mutableListOf<String?>()
    val kanbanId = UUID.randomUUID().toString()
    val types = listOf(PurchaseOrderType.REGULAR, PurchaseOrderType.POSITIVE)

    mockkStatic("org.jetbrains.exposed.v1.jdbc.QueriesKt")
    try {
      every { partTable.update(any(), any(), any()) } answers {
        val statement = UpdateStatement(partTable, null)
        arg<KanbanItemPartViewTable.(UpdateStatement) -> Unit>(3)(partTable, statement)
        notes += statement.firstDataSet.toMap()[partTable.supplierNote] as String?
        1
      }
      every { viewTable.update(any(), any(), any()) } returns 1
      projector.onAssignmentEvent(KanbanMaterialPrepared(
        kanbanId, "supplier", types.map { type ->
          KanbanMaterialPrepared.PreparedItem("BTP CUT-1", "Red", "M", null,
            BigDecimal.TEN, "prepare $type", type)
        }, null,
      ))
      projector.onAssignmentEvent(KanbanMaterialIssued(
        kanbanId, "supplier", types.map { type ->
          KanbanMaterialIssued.IssuedItem("BTP CUT-1", "Red", "M", null,
            BigDecimal.TEN, "issue $type", type)
        }, null,
      ))
      assertEquals(listOf("prepare REGULAR", "prepare POSITIVE", "issue REGULAR", "issue POSITIVE"), notes)
    } finally {
      unmockkStatic("org.jetbrains.exposed.v1.jdbc.QueriesKt")
    }
  }
}
