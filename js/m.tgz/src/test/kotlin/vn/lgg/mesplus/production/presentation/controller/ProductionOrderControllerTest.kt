package vn.lgg.mesplus.production.presentation.controller

import io.kotest.assertions.throwables.shouldThrow
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test
import org.springframework.security.access.AccessDeniedException
import vn.lgg.mesplus.iam.domain.repository.OrgUnitRepository
import vn.lgg.mesplus.iam.domain.repository.RoleRepository
import vn.lgg.mesplus.iam.domain.repository.UnitMembershipRepository
import vn.lgg.mesplus.production.application.service.AllocationTemplateService
import vn.lgg.mesplus.production.application.service.ProductionOrderActivityLog
import vn.lgg.mesplus.production.application.service.ProductionOrderExportData
import vn.lgg.mesplus.production.application.usecase.IssueProductionOrderUseCase
import vn.lgg.mesplus.production.application.usecase.ReviseProductionOrderUseCase
import vn.lgg.mesplus.production.infrastructure.repository.ProductionOrderViewRepository
import vn.lgg.mesplus.production.infrastructure.service.PoiProductionOrderExportService
import vn.lgg.mesplus.production.presentation.viewmodel.ProductionOrderVm
import vn.lgg.mesplus.production.presentation.viewmodel.TeamAssignmentVm
import vn.lgg.mesplus.shared.model.Actor
import vn.lgg.mesplus.shared.model.MembershipInfo
import vn.lgg.mesplus.shared.model.Permission
import vn.lgg.mesplus.shared.service.PermissionService
import vn.lgg.mesplus.production.application.usecase.CancelProductionOrderUseCase

class ProductionOrderControllerTest {
  private val productionOrderRepository = mockk<ProductionOrderViewRepository>()
  private val orgUnitRepository = mockk<OrgUnitRepository>()
  private val roleRepository = mockk<RoleRepository>()
  private val permissionService = PermissionService(
    orgUnitRepository,
    roleRepository,
    mockk<UnitMembershipRepository>(),
  )
  private val exportService = mockk<PoiProductionOrderExportService>()
  private val activityLog = mockk<ProductionOrderActivityLog>()
  private val controller = ProductionOrderController(
    mockk<IssueProductionOrderUseCase>(),
    mockk<ReviseProductionOrderUseCase>(),
    productionOrderRepository,
    orgUnitRepository,
    permissionService,
    mockk<AllocationTemplateService>(),
    exportService,
    activityLog,
    mockk<CancelProductionOrderUseCase>(),
  )

  @Test
  fun `team leader can view production order containing their assignment`() {
    val actor = Actor(
      "actor-1",
      "Team leader",
      "username",
      "password",
      listOf(MembershipInfo("team-1", setOf("team-leader"))),
      emptySet(),
    )
    val productionOrder = mockk<ProductionOrderVm> {
      every { factories } returns listOf(mockk { every { id } returns "factory-1" })
      every { teamAssignments } returns listOf(mockk<TeamAssignmentVm> { every { teamId } returns "team-1" })
    }
    every { productionOrderRepository.findVm("po-1") } returns productionOrder
    every { roleRepository.hasPermission(setOf("team-leader"), any()) } returns false
    every { roleRepository.hasPermission(setOf("team-leader"), Permission.REPORT_PROGRESS) } returns true
    every { orgUnitRepository.findById("factory-1") } returns null

    controller.getProductionOrderDetail("po-1", actor) shouldBe productionOrder
    every { activityLog.findByProductionOrderId("po-1") } returns emptyList()
    controller.getProductionOrderHistory("po-1", actor) shouldBe emptyList()
  }

  @Test
  fun `team leader cannot view production order without their assignment`() {
    val actor = Actor(
      "actor-1",
      "Team leader",
      "username",
      "password",
      listOf(MembershipInfo("team-1", setOf("team-leader"))),
      emptySet(),
    )
    val productionOrder = mockk<ProductionOrderVm> {
      every { factories } returns listOf(mockk { every { id } returns "factory-1" })
      every { teamAssignments } returns listOf(mockk<TeamAssignmentVm> { every { teamId } returns "team-2" })
    }
    every { productionOrderRepository.findVm("po-2") } returns productionOrder
    every { roleRepository.hasPermission(setOf("team-leader"), any()) } returns false
    every { roleRepository.hasPermission(setOf("team-leader"), Permission.REPORT_PROGRESS) } returns true
    every { orgUnitRepository.findById(any()) } returns null

    shouldThrow<AccessDeniedException> {
      controller.getProductionOrderDetail("po-2", actor)
    }
  }

  @Test
  fun `history denies actors without production order access before reading records`() {
    val actor = Actor("actor", "User", "user", "", emptyList(), emptySet())
    every { productionOrderRepository.findVm("po-1") } returns mockk {
      every { factories } returns emptyList()
      every { teamAssignments } returns emptyList()
    }
    shouldThrow<AccessDeniedException> { controller.getProductionOrderHistory("po-1", actor) }
    verify(exactly = 0) { activityLog.findByProductionOrderId(any()) }
  }

  @Test
  fun `export requires production order permission before generating a workbook`() {
    val actor = Actor("actor-1", "User", "username", "password", emptyList(), emptySet())
    val data = ProductionOrderExportData(
      factoryIds = listOf("factory-1"), allSizes = emptyList(), noteColumnCount = 1,
      rows = emptyList(),
    )
    shouldThrow<AccessDeniedException> { controller.exportProductionOrder(data, actor) }
    verify(exactly = 0) { exportService.exportToExcel(any()) }
  }
}
