package vn.lgg.mesplus.production.infrastructure.repository.mapping

import io.kotest.matchers.shouldBe
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.production.domain.model.SkuAllocation
import vn.lgg.mesplus.production.presentation.viewmodel.PoSummaryVm
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Size

class ProductionOrderHelperTest {
  @Test
  fun `flags only production orders whose own sku total exceeds the buyer order`() {
    val buyerOrderAllocations = listOf(
      allocation("po-1", 100),
      allocation("po-2", 50),
    )

    hasOverAllocatedSku(listOf(allocation("po-1", 60)), buyerOrderAllocations) shouldBe false
    hasOverAllocatedSku(listOf(allocation("po-1", 101)), buyerOrderAllocations) shouldBe true
    hasOverAllocatedSku(listOf(allocation("po-2", 51)), buyerOrderAllocations) shouldBe true
  }

  @Test
  fun `recognizes SEW operations including numbered variants`() {
    isSewingOperation("SEW") shouldBe true
    isSewingOperation("SEW-1") shouldBe true
    isSewingOperation("SEW-2") shouldBe true
    isSewingOperation("MAY-2") shouldBe false
    isSewingOperation("CUT-1") shouldBe false
  }

  @Test
  fun `summarizes production order quantity and delivery date range across purchase orders`() {
    val summary =
      summarizeProductionOrderList(
        listOf(
          poSummary(quantity = 120, deliveryDate = "2026-08-20"),
          poSummary(quantity = 80, deliveryDate = "2026-08-25"),
        ),
      )

    summary.totalQuantity shouldBe 200
    summary.earliestDeliveryDate shouldBe "2026-08-20"
    summary.latestDeliveryDate shouldBe "2026-08-25"
  }

  private fun allocation(purchaseOrderId: String, quantity: Int) =
    SkuAllocation(purchaseOrderId, Color("Red"), Size("S"), quantity)

  private fun poSummary(quantity: Int, deliveryDate: String) =
    PoSummaryVm(
      poId = "po-$quantity",
      poCode = "PO-$quantity",
      destination = null,
      deliveryDate = deliveryDate,
      totalQuantity = quantity,
      completedQuantity = 0,
      progressPercentage = 0.0,
    )
}
