package vn.lgg.mesplus.production.domain.service

import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.shouldBe
import io.mockk.mockk
import java.math.BigDecimal
import java.time.Instant
import org.junit.jupiter.api.Test
import vn.lgg.mesplus.order.domain.repository.PurchaseOrderRepository
import vn.lgg.mesplus.production.domain.model.TeamMaterial
import vn.lgg.mesplus.production.domain.repository.TeamAssignmentRepository
import vn.lgg.mesplus.production.domain.repository.TeamMaterialRepository
import vn.lgg.mesplus.shared.model.ActorRef
import vn.lgg.mesplus.shared.model.Color
import vn.lgg.mesplus.shared.model.Material
import vn.lgg.mesplus.shared.model.MaterialColorDep
import vn.lgg.mesplus.shared.model.MaterialSizeDep
import vn.lgg.mesplus.shared.model.Size

class BomCalculationServiceTest {
  private val service =
    BomCalculationService(
      mockk<TeamAssignmentRepository>(),
      mockk<TeamMaterialRepository>(),
      mockk<PurchaseOrderRepository>(),
    )

  @Test
  fun `maps team material to material line dependencies in source order`() {
    val sizes =
      listOf(
        MaterialSizeDep(Size("M-MAT"), Size("M"), BigDecimal("1.5")),
        MaterialSizeDep(Size("L-MAT"), Size("L"), BigDecimal("1.7")),
      )
    val colors =
      listOf(MaterialColorDep(Color("NAVY-MAT"), Color("NAVY"), BigDecimal("2")))

    val result =
      service.toMaterialLines(
        listOf(
          TeamMaterial(
            id = "material-1",
            teamAssignmentId = "assignment-1",
            material = Material("FABRIC", "Fabric", "M"),
            sizeDeps = sizes,
            colorDeps = colors,
            lastUpdatedAt = Instant.EPOCH,
            lastUpdatedBy = ActorRef("account-1", "Account"),
            destinationCodes = listOf("US"),
          )
        )
      ).single()

    result.material shouldBe "FABRIC"
    result.sizeDeps.shouldContainExactly(sizes)
    result.colorDeps.shouldContainExactly(colors)
    result.destinations shouldContainExactly listOf("US")
  }
}
