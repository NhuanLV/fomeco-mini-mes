# Quy tắc viết Gherkin hiệu quả

Gherkin nên được xem là **tài liệu sống mô tả hành vi nghiệp vụ**, đồng thời là công cụ giúp
Business, Developer và Tester xây dựng cách hiểu chung. Nó không nên chỉ là một tập lệnh tự động hóa
được viết bằng ngôn ngữ tự nhiên. ([cucumber.io](https://cucumber.io/docs/bdd/better-gherkin))

## 1. Mô tả hành vi, không mô tả cách triển khai

Scenario nên trả lời:

- Hệ thống phải làm **gì**?
- Người dùng hoặc nghiệp vụ nhận được giá trị **gì**?

Không nên mô tả chi tiết người dùng nhấn nút nào, nhập vào trường nào hoặc truy cập URL nào. Những
chi tiết đó thuộc về automation code hoặc step definition. Một phép kiểm tra hữu ích là: *Câu
Gherkin này có phải thay đổi khi giao diện thay đổi nhưng nghiệp vụ không đổi không?* Nếu có, câu đó
đang phụ thuộc quá nhiều vào implementation.
([cucumber.io](https://cucumber.io/docs/bdd/better-gherkin))

**Không nên**

```gherkin
Scenario: Đăng nhập thành công
  Given người dùng mở trang "/login"
  When người dùng nhập "an@example.com" vào ô "Email"
  And người dùng nhập "secret123" vào ô "Password"
  And người dùng nhấn nút "Đăng nhập"
  Then trang "/dashboard" được hiển thị
```

**Nên**

```gherkin
Scenario: Khách hàng đăng nhập thành công
  Given An là một khách hàng đã đăng ký
  When An đăng nhập bằng thông tin hợp lệ
  Then An có thể truy cập tài khoản của mình
```

---

## 2. Ưu tiên phong cách khai báo thay vì mệnh lệnh

Gherkin dạng khai báo — declarative — mô tả ý định và kết quả nghiệp vụ. Gherkin dạng mệnh lệnh —
imperative — mô tả tuần tự thao tác.

Phong cách khai báo thường:

- Ngắn hơn.
- Dễ đọc hơn.
- Ít phụ thuộc giao diện.
- Ít bị hỏng khi implementation thay đổi.
- Phù hợp hơn với vai trò tài liệu sống.
  ([cucumber.io](https://cucumber.io/docs/bdd/better-gherkin))

**Không nên**

```gherkin
Scenario: Khách hàng miễn phí chỉ đọc được bài viết miễn phí
  Given tôi đang ở trang đăng nhập
  When tôi nhập email "free@example.com"
  And tôi nhập mật khẩu "password123"
  And tôi nhấn nút "Submit"
  Then tôi thấy bài viết "Tin miễn phí số 1"
  And tôi không thấy bài viết "Phân tích chuyên sâu số 1"
```

**Nên**

```gherkin
Scenario: Khách hàng miễn phí chỉ đọc được nội dung miễn phí
  Given Mai đang sử dụng gói miễn phí
  When Mai đăng nhập bằng thông tin hợp lệ
  Then Mai chỉ có thể đọc nội dung dành cho gói miễn phí
```

---

## 3. Sử dụng ngôn ngữ nghiệp vụ

Scenario nên sử dụng danh từ và động từ trong domain, chẳng hạn:

- Đơn hàng được xác nhận.
- Khoản vay được phê duyệt.
- Tài khoản bị khóa.
- Hóa đơn quá hạn.

Tránh để feature file bị chi phối bởi những thuật ngữ giao diện chung chung như button, textbox,
URL, CSS selector hoặc màn hình. Ngôn ngữ UI mô tả cách sử dụng chương trình, nhưng thường không cho
biết vấn đề nghiệp vụ mà chương trình giải quyết.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Không nên**

```gherkin
Scenario: Xác nhận đơn hàng
  When người dùng nhấn nút có id "confirm-order"
  Then modal có class "success-dialog" được hiển thị
```

**Nên**

```gherkin
Scenario: Xác nhận đơn hàng hợp lệ
  When nhân viên xác nhận đơn hàng
  Then đơn hàng chuyển sang trạng thái đã xác nhận
```

---

## 4. Viết scenario bằng ví dụ cụ thể

Scenario không nên quá trừu tượng hoặc mơ hồ. Dữ liệu đầu vào và kết quả phải đủ cụ thể để các bên
có thể thống nhất cách hệ thống sẽ hành xử.

Một business rule trừu tượng có thể được ghi trong phần mô tả của `Feature` hoặc `Rule`; các
scenario bên dưới phải biến quy tắc đó thành ví dụ cụ thể.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Không nên**

```gherkin
Scenario: Rút tiền
  Given tài khoản có một số tiền
  When khách hàng rút một khoản tiền
  Then số dư bị giảm tương ứng
```

Không rõ số dư ban đầu, số tiền rút và kết quả chính xác.

**Nên**

```gherkin
Scenario: Rút tiền trong phạm vi số dư
  Given tài khoản của Lan có số dư 1.000.000 đồng
  When Lan rút 300.000 đồng
  Then số dư tài khoản của Lan là 700.000 đồng
```

---

## 5. Mỗi scenario nên tập trung vào một hành vi hoặc một business rule

Scenario có quá nhiều mục tiêu sẽ khó đọc, khó đặt tên và khó xác định nguyên nhân khi thất bại.

Dấu hiệu thường gặp:

- Scenario có nhiều hành động không liên quan.
- Tên scenario liệt kê cả một hành trình dài.
- Người đọc phải đoán scenario thực sự kiểm tra điều gì.
- Scenario kiểm tra nhiều quy tắc độc lập cùng lúc.
  ([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Không nên**

```gherkin
Scenario: Đăng ký, đăng nhập, đổi mật khẩu và xem số dư
  Given Minh chưa có tài khoản
  When Minh đăng ký tài khoản
  And Minh đăng nhập
  And Minh đổi mật khẩu
  And Minh mở tài khoản thanh toán
  Then Minh thấy số dư là 0 đồng
```

**Nên**

```gherkin
Scenario: Tài khoản thanh toán mới có số dư bằng không
  Given Minh vừa mở một tài khoản thanh toán
  When Minh kiểm tra số dư
  Then số dư tài khoản là 0 đồng
```

Các hành vi đăng ký, đăng nhập và đổi mật khẩu nên nằm trong các scenario riêng.

---

## 6. Loại bỏ chi tiết phụ không ảnh hưởng đến business rule

Chi tiết phụ — incidental details — là dữ liệu cần cho automation nhưng không cần thiết để hiểu hành
vi nghiệp vụ.

Quá nhiều chi tiết phụ làm người đọc không biết scenario đang kiểm tra mật khẩu, đăng nhập hay số dư
tài khoản. Các giá trị kỹ thuật cần thiết có thể được đặt trong fixture, factory, hook hoặc step
definition. ([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Không nên**

```gherkin
Scenario: Kiểm tra số dư
  Given Nam đăng ký bằng email "nam@example.com"
  And mật khẩu của Nam là "Password@123"
  And xác nhận mật khẩu là "Password@123"
  And Nam đã nhấp vào liên kết xác thực email
  And Nam đăng nhập
  When Nam kiểm tra số dư tài khoản
  Then số dư là 500.000 đồng
```

**Nên**

```gherkin
Scenario: Hiển thị số dư hiện tại
  Given Nam có một tài khoản với số dư 500.000 đồng
  When Nam kiểm tra số dư
  Then hệ thống hiển thị 500.000 đồng
```

---

## 7. Đặt tên scenario theo kết quả hoặc tình huống đáng chú ý

Tên scenario nên thể hiện điểm khác biệt hoặc bản chất của ví dụ. Không nên dùng tên chung chung như
`Test login`, cũng không nên biến tên thành bản tóm tắt toàn bộ chuỗi thao tác.

Một cách đặt tên hữu ích là hoàn thành câu: **“Đây là trường hợp mà…”**.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Không nên**

```gherkin
Scenario: Đăng nhập, mở trang tài khoản, xem số dư và đăng xuất
```

**Nên**

```gherkin
Scenario: Khách hàng nhìn thấy số dư dương
```

Hoặc:

```gherkin
Scenario: Tài khoản bị khóa sau năm lần đăng nhập thất bại
```

---

## 8. Phân biệt rõ vai trò của Given, When và Then

Cấu trúc nên thể hiện một câu chuyện nhân quả rõ ràng:

- `Given`: bối cảnh và trạng thái ban đầu.
- `When`: sự kiện hoặc hành động chính.
- `Then`: kết quả quan sát được.

Mặc dù Cucumber xử lý các keyword tương tự nhau về mặt kỹ thuật, việc dùng đúng vai trò giúp
scenario dễ hiểu hơn.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Không nên**

```gherkin
Scenario: Thanh toán đơn hàng
  Given khách hàng thanh toán đơn hàng
  When đơn hàng có trạng thái đã thanh toán
  Then khách hàng có một đơn hàng chưa thanh toán
```

**Nên**

```gherkin
Scenario: Thanh toán đơn hàng thành công
  Given khách hàng có một đơn hàng chưa thanh toán
  When khách hàng thanh toán đơn hàng
  Then đơn hàng có trạng thái đã thanh toán
```

---

## 9. Hạn chế nhiều When trong cùng một scenario

Thông thường, một scenario nên có một sự kiện chính:

```gherkin
When ...
And ...
```

Các câu `And` sau `When` chỉ nên bổ sung các phần của cùng một hành động hoặc cùng một chuỗi sự kiện
gắn kết chặt chẽ. Nếu chúng đại diện cho những hành vi độc lập, scenario nên được tách ra.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Không nên**

```gherkin
Scenario: Quản lý tài khoản
  Given Hoa có một tài khoản
  When Hoa thay đổi địa chỉ
  And Hoa đặt lại mật khẩu
  And Hoa đóng tài khoản
  Then tài khoản không còn hoạt động
```

**Nên**

```gherkin
Scenario: Khách hàng đóng tài khoản
  Given Hoa có một tài khoản đang hoạt động
  When Hoa đóng tài khoản
  Then tài khoản của Hoa không còn hoạt động
```

Việc đổi địa chỉ và đặt lại mật khẩu nên có scenario riêng.

---

## 10. Chỉ dùng nhiều Then khi các kết quả thuộc cùng một hành vi

Nhiều kết quả có thể hợp lý khi chúng là các phần không thể tách rời của cùng một giao dịch.

Ví dụ, rút tiền thành công đòi hỏi đồng thời:

- Máy ATM trả tiền.
- Tài khoản bị trừ tiền.

Ngược lại, nếu các kết quả thể hiện các business rule độc lập và có thể triển khai riêng, nên tách
chúng thành các scenario riêng.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Có thể chấp nhận**

```gherkin
Scenario: Rút tiền thành công
  Given tài khoản của An có số dư 2.000.000 đồng
  And máy ATM có đủ tiền
  When An rút 500.000 đồng
  Then máy ATM trả cho An 500.000 đồng
  And số dư tài khoản của An còn 1.500.000 đồng
```

Hai kết quả cùng tạo thành tính toàn vẹn của giao dịch rút tiền.

**Nên tách khi kết quả độc lập**

```gherkin
Scenario: Hàng hoàn trả được nhập lại kho
  When cửa hàng chấp nhận một sản phẩm hoàn trả
  Then số lượng tồn kho của sản phẩm tăng thêm một
```

```gherkin
Scenario: Khách hàng được hoàn tiền cho sản phẩm trả lại
  When cửa hàng chấp nhận một sản phẩm hoàn trả
  Then khách hàng được hoàn lại số tiền đã thanh toán
```

---

## 11. Sử dụng persona hoặc vai trò cụ thể thay cho “tôi”

Từ “tôi” có thể làm mất bối cảnh khi hệ thống có nhiều loại người dùng. Nên sử dụng tên persona hoặc
vai trò nghiệp vụ để làm rõ ai đang thực hiện hành động và quyền hạn của họ.

Persona chỉ nên mang những thuộc tính có ý nghĩa với scenario; không cần thêm tuổi, giới tính hoặc
đặc điểm khác nếu chúng không ảnh hưởng đến hành vi.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Không nên**

```gherkin
Scenario: Phê duyệt đơn nghỉ phép
  Given tôi đã đăng nhập
  When tôi phê duyệt đơn nghỉ phép
  Then đơn được phê duyệt
```

Không rõ “tôi” là nhân viên, quản lý hay quản trị viên.

**Nên**

```gherkin
Scenario: Quản lý phê duyệt đơn nghỉ phép
  Given Quang là quản lý trực tiếp của Mai
  And Mai có một đơn nghỉ phép đang chờ duyệt
  When Quang phê duyệt đơn nghỉ phép
  Then đơn nghỉ phép của Mai có trạng thái đã phê duyệt
```

---

## 12. Dùng phần mô tả Feature để ghi business rule hữu ích

Phần narrative của `Feature` không nên bị bỏ trống hoặc được điền bằng một user story sáo rỗng không
cung cấp thêm thông tin.

Phần này nên giải thích:

- Mục tiêu nghiệp vụ.
- Business rule.
- Phạm vi.
- Các giả định quan trọng.
- Câu hỏi hoặc điểm chưa được thống nhất.

Các scenario bên dưới sẽ cung cấp ví dụ cụ thể cho những quy tắc đó.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Không nên**

```gherkin
Feature: Kiểm tra số dư

  As a user
  I want to check my balance
  So that I know my balance
```

**Nên**

```gherkin
Feature: Hiển thị số dư tài khoản

  Khách hàng cần biết số tiền hiện có trước khi thực hiện giao dịch.

  Quy tắc:
  - Số dư hiển thị phải bao gồm tất cả giao dịch đã ghi sổ.
  - Giao dịch đang chờ xử lý không làm thay đổi số dư ghi sổ.
  - Số dư khả dụng phải trừ các khoản tiền đang bị tạm giữ.
```

Hoặc dùng keyword `Rule`:

```gherkin
Feature: Hiển thị số dư tài khoản

  Rule: Giao dịch đang chờ xử lý không làm thay đổi số dư ghi sổ

    Scenario: Thẻ ghi nợ có giao dịch đang chờ xử lý
      Given tài khoản của Lan có số dư ghi sổ 2.000.000 đồng
      And có một giao dịch 300.000 đồng đang chờ xử lý
      When Lan kiểm tra số dư ghi sổ
      Then hệ thống hiển thị 2.000.000 đồng
```

---

## 13. Viết Gherkin trước khi triển khai

Gherkin nên được viết trong quá trình khám phá yêu cầu, trước khi hoặc cùng lúc với việc phát triển
phần mềm. Nếu feature file chỉ được viết sau khi code hoàn thành, nó dễ trở thành tài liệu mô tả
implementation hiện tại thay vì công cụ làm rõ hành vi mong muốn.

Việc xây dựng ví dụ trước giúp phát hiện sớm:

- Yêu cầu mơ hồ.
- Các cách hiểu khác nhau.
- Trường hợp biên.
- Quy tắc còn thiếu.
- Những giả định chưa được kiểm chứng.
  ([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Quy trình không nên**

```text
Developer hoàn thành chức năng
→ Tester quan sát giao diện
→ Tester chuyển thao tác trên giao diện thành Gherkin
```

**Quy trình nên**

```text
Business + Developer + Tester thảo luận business rule
→ Viết các ví dụ Gherkin
→ Xác nhận cách hiểu chung
→ Triển khai và tự động hóa
```

**Ví dụ được xây dựng trước implementation**

```gherkin
Rule: Không cho phép thanh toán vượt hạn mức tín dụng

  Scenario: Giao dịch làm vượt hạn mức
    Given thẻ của Mai còn hạn mức khả dụng 1.000.000 đồng
    When Mai thanh toán 1.200.000 đồng
    Then giao dịch bị từ chối
    And hạn mức khả dụng vẫn là 1.000.000 đồng
```

---

## 14. Xây dựng scenario thông qua cộng tác đa vai trò

Feature file không nên do riêng Business, Developer hoặc Tester viết trong cô lập.

Mỗi vai trò cung cấp một góc nhìn khác nhau:

- Business làm rõ giá trị và quy tắc.
- Developer nhận diện ràng buộc kỹ thuật và điểm chưa rõ.
- Tester tìm trường hợp biên, ngoại lệ và tiêu chí có thể kiểm chứng.

Việc viết riêng lẻ thường dẫn đến scenario không thực tế, không thể kiểm thử hoặc không còn phản ánh
đúng ý định ban đầu sau khi được chỉnh sửa để tự động hóa.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Scenario ban đầu còn mơ hồ**

```gherkin
Scenario: Khách hàng được giảm giá
  Given khách hàng đủ điều kiện
  When khách hàng mua sản phẩm
  Then khách hàng được giảm giá
```

**Scenario sau khi các vai trò cùng làm rõ**

```gherkin
Scenario: Thành viên vàng được giảm giá cho đơn hàng đủ điều kiện
  Given Lan là thành viên vàng
  And giỏ hàng của Lan có tổng giá trị 2.000.000 đồng
  When Lan xác nhận đơn hàng
  Then đơn hàng được giảm 10%
  And tổng tiền phải thanh toán là 1.800.000 đồng
```

---

## 15. Dùng Scenario Outline có chọn lọc

`Scenario Outline` phù hợp khi cần minh họa cùng một business rule bằng nhiều bộ dữ liệu. Tuy nhiên,
nó dễ bị lạm dụng để tạo ra số lượng lớn test case, đặc biệt nguy hiểm khi mỗi ví dụ phải chạy qua
giao diện chậm và dễ vỡ.

Nên dùng khi:

- Các dòng dữ liệu minh họa cùng một quy tắc.
- Mỗi dòng có ý nghĩa nghiệp vụ rõ ràng.
- Scenario chạy nhanh.
- Hệ thống có thể được kiểm thử dưới tầng UI.

Không nên dùng nó như một cách nhập toàn bộ ma trận kiểm thử vào tài liệu nghiệp vụ.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Không nên**

```gherkin
Scenario Outline: Kiểm tra mọi tổ hợp dữ liệu đăng ký
  Given người dùng mở trang đăng ký
  When người dùng nhập "<email>", "<password>", "<phone>", "<address>"
  And người dùng nhấn nút "Submit"
  Then hệ thống hiển thị "<message>"

  Examples:
    | email | password | phone | address | message |
    # Hàng trăm tổ hợp kỹ thuật
```

**Nên**

```gherkin
Scenario Outline: Phân loại phí giao hàng theo giá trị đơn
  Given giỏ hàng có giá trị <order_value> đồng
  When khách hàng yêu cầu giao hàng tiêu chuẩn
  Then phí giao hàng là <shipping_fee> đồng

  Examples:
    | order_value | shipping_fee |
    |      300000 |        30000 |
    |      499999 |        30000 |
    |      500000 |            0 |
```

Các dòng thể hiện rõ ranh giới của quy tắc miễn phí giao hàng.

---

## 16. Giữ scenario ngắn nhưng không được mơ hồ

Scenario quá dài thường chứa:

- Nhiều hành vi.
- Nhiều chi tiết UI.
- Quá nhiều thiết lập.
- Một hành trình end-to-end thay vì một ví dụ nghiệp vụ.

Tuy nhiên, rút gọn không có nghĩa là viết chung chung. Mục tiêu là giữ lại **chi tiết có ý nghĩa
nghiệp vụ** và loại bỏ **chi tiết triển khai**.
([cucumber.io](https://cucumber.io/docs/bdd/better-gherkin))

**Quá chi tiết**

```gherkin
Scenario: Áp dụng mã giảm giá
  Given khách hàng mở trình duyệt
  And khách hàng truy cập trang chủ
  And khách hàng tìm kiếm sản phẩm
  And khách hàng mở trang chi tiết sản phẩm
  And khách hàng nhấn "Thêm vào giỏ"
  And khách hàng mở biểu tượng giỏ hàng
  When khách hàng nhập "SUMMER10" vào ô mã giảm giá
  And khách hàng nhấn "Áp dụng"
  Then dòng tổng tiền được cập nhật
```

**Quá mơ hồ**

```gherkin
Scenario: Giảm giá
  Given có một đơn hàng
  When áp dụng giảm giá
  Then kết quả phải đúng
```

**Cân bằng**

```gherkin
Scenario: Áp dụng mã giảm giá hợp lệ
  Given giỏ hàng của Lan có tổng giá trị 1.000.000 đồng
  And mã "SUMMER10" giảm 10% vẫn còn hiệu lực
  When Lan áp dụng mã "SUMMER10"
  Then tổng tiền của giỏ hàng là 900.000 đồng
```

---

## 17. Duy trì Gherkin như tài liệu sống

Không phải scenario nào cũng có giá trị vĩnh viễn. Scenario đã trở nên hiển nhiên, trùng lặp hoặc
không còn phản ánh nghiệp vụ hiện tại nên được:

- Viết lại để thể hiện trường hợp có giá trị hơn.
- Hợp nhất với scenario khác.
- Xóa khi hành vi đã được bao phủ phù hợp ở nơi khác.

Không nên giữ scenario chỉ vì nó đã từng được viết. Tuy nhiên, trước khi xóa cần bảo đảm business
rule không bị mất khỏi tài liệu và hệ thống kiểm thử.
([thinkcode.se](https://www.thinkcode.se/blog/2016/06/22/cucumber-antipatterns))

**Scenario có thể trở nên ít giá trị**

```gherkin
Scenario: Tài khoản mới có số dư bằng không
  Given khách hàng vừa mở tài khoản
  When khách hàng kiểm tra số dư
  Then số dư là 0 đồng
```

Có thể được thay bằng một trường hợp biên giàu thông tin hơn:

```gherkin
Scenario: Tiền gửi ban đầu chỉ được tính sau khi ghi sổ
  Given khách hàng vừa mở tài khoản với khoản gửi ban đầu 1.000.000 đồng
  And khoản tiền gửi chưa được ghi sổ
  When khách hàng kiểm tra số dư ghi sổ
  Then số dư ghi sổ là 0 đồng
```

---

# Checklist rà soát feature file

Trước khi chấp nhận một scenario, có thể kiểm tra:

| Câu hỏi                                                            | Kỳ vọng           |
|--------------------------------------------------------------------|-------------------|
| Scenario có mô tả giá trị hoặc hành vi nghiệp vụ không?            | Có                |
| Scenario có phụ thuộc vào button, URL hoặc CSS selector không?     | Không hoặc rất ít |
| Dữ liệu có đủ cụ thể để xác định kết quả không?                    | Có                |
| Scenario có một mục tiêu chính rõ ràng không?                      | Có                |
| Tên scenario có thể hiện điểm đáng chú ý của ví dụ không?          | Có                |
| `Given` có mô tả bối cảnh không?                                   | Có                |
| `When` có thể hiện sự kiện chính không?                            | Có                |
| `Then` có phải kết quả quan sát được không?                        | Có                |
| Có chi tiết nào chỉ phục vụ automation không?                      | Không             |
| Business, Developer và Tester có cùng hiểu scenario không?         | Có                |
| Scenario vẫn đúng nếu UI thay đổi nhưng nghiệp vụ không đổi không? | Có                |
| Scenario có đóng góp giá trị cho tài liệu sống không?              | Có                |

## Mẫu tham khảo

```gherkin
Feature: <Năng lực nghiệp vụ>

  <Mục tiêu, phạm vi và các business rule quan trọng>

  Rule: <Một business rule>

    Scenario: <Tên thể hiện trường hợp hoặc kết quả đáng chú ý>
      Given <bối cảnh nghiệp vụ cụ thể>
      And <điều kiện ban đầu liên quan>
      When <một sự kiện hoặc hành động chính>
      Then <kết quả nghiệp vụ quan sát được>
      And <kết quả liên quan không thể tách rời>
```
