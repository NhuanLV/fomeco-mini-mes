# Triage Labels

5 vai trò triage chuẩn ánh xạ nhãn thực tế hệ thống.

| Nhãn trong mattpocock/skills | Nhãn trong tracker | Ý nghĩa                                                                           |
| ---------------------------- | ------------------ | --------------------------------------------------------------------------------- |
| `needs-triage`               | `needs-triage`     | Đánh giá/phân loại issue                                                          |
| `needs-info`                 | `needs-info`       | Chờ người báo cáo cung cấp thêm thông tin                                         |
| `ready-for-agent`            | `ready-for-agent`  | Đủ thông tin, agent tự động xử lý (không cần người hướng dẫn)                      |
| `ready-for-human`            | `ready-for-human`  | Cần lập trình viên thực hiện                                                      |
| `wontfix`                    | `wontfix`          | Không xử lý                                                                       |

Skill dùng vai trò nào, đối chiếu bảng lấy nhãn tương ứng. Sửa cột bên phải để đổi nhãn sử dụng.
