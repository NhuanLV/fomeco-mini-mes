# Domain Docs

Hướng dẫn skill kỹ thuật tiêu thụ tài liệu nghiệp vụ dự án.

## Trước khi tìm hiểu codebase, hãy đọc các tài liệu sau

- **`CONTEXT-MAP.md`**: Thư mục gốc. Mô tả luồng nghiệp vụ tổng quát + sơ đồ module.
- **`CONTEXT.md`**: Từng module. Đọc để hiểu chi tiết logic tương ứng.
- **`docs/adr/`**: Quyết định kiến trúc liên quan trực tiếp phần code sửa đổi. Đa ngữ cảnh: check thêm `src/<context>/docs/adr/` hoặc `webapp/docs/adr/`.

Tài liệu chưa tồn tại -> bỏ qua im lặng. Không báo lỗi, không tự ý tạo trước. `/domain-modeling` tạo lười khi giải quyết thuật ngữ/quyết định.

## Cấu trúc thư mục (File structure)

Dự án dạng đa ngữ cảnh (multi-context) được nhận diện bằng sự hiện diện của tệp tin `CONTEXT-MAP.md` ở thư mục gốc:

```
/
├── CONTEXT-MAP.md                     ← Luồng nghiệp vụ tổng quát & sơ đồ module
├── docs/adr/                          ← Các quyết định kiến trúc toàn hệ thống
├── src/
│   └── <backend-module>/
│       ├── CONTEXT.md                 ← Nghiệp vụ chi tiết của backend module
│       └── docs/adr/                  ← Quyết định kiến trúc của backend module
└── webapp/
    ├── CONTEXT.md                     ← Nghiệp vụ chi tiết của frontend (webapp)
    └── docs/adr/                      ← Quyết định kiến trúc của frontend (webapp)
```

## Sử dụng từ vựng trong bảng thuật ngữ (Glossary)

Tên khái niệm nghiệp vụ (tiêu đề issue, proposal, lỗi, tên hàm/test) dùng đúng từ trong `CONTEXT.md` / `CONTEXT-MAP.md`. Tránh từ đồng nghĩa bảng thuật ngữ không dùng. Khái niệm chưa có -> Gap (ghi nhận `/domain-modeling`).

## Cảnh báo xung đột ADR

Thay đổi xung đột ADR hiện tại -> Nêu rõ xung đột, không âm thầm ghi đè:

> _Xung đột với ADR-0007 (event-sourced orders) — nhưng đề xuất xem xét lại vì lý do..._
