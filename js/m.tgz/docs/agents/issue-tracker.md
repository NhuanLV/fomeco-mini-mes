# Issue tracker: Local Markdown

Issue, PRD lưu dạng markdown trong `.scratch/`.

## Quy ước (Conventions)

- Tính năng/nhiệm vụ: `.scratch/<feature-slug>/`
- PRD: `.scratch/<feature-slug>/PRD.md`
- Issue chi tiết: `.scratch/<feature-slug>/issues/<NN>-<slug>.md`, số bắt đầu `01`
- Triage state: dòng `Status:` đầu file issue (xem [triage-labels.md](file:///home/ducnm/Code/lgg/mes-plus/docs/agents/triage-labels.md))
- Comments/lịch sử: thêm vào cuối file dưới `## Comments`

## Khi một skill yêu cầu "publish to the issue tracker"

Tạo file mới trong `.scratch/<feature-slug>/` (tự tạo thư mục nếu thiếu).

## Khi một skill yêu cầu "fetch the relevant ticket"

Đọc file tại đường dẫn được tham chiếu.
