import { defineConfig, devices } from '@playwright/test'

const isCI = !!process.env['CI']

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: isCI,
  retries: isCI ? 2 : 0,
  ...(isCI ? { workers: 1 } : {}),
  reporter: 'list',

  use: {
    baseURL: 'http://localhost:5173',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },

  projects: [
    {
      name: 'firefox',
      use: {
        ...devices['Desktop Firefox'],
        channel: 'firefox',
        launchOptions: {
          executablePath: process.env['FIREFOX_BIN'] || '/usr/bin/firefox',
        },
      },
    },
  ],

  webServer: {
    command: 'pnpm frontend:dev',
    url: 'http://localhost:5173',
    reuseExistingServer: !isCI,
  },
})
