# AGENTS.md

Behavioral guidelines to reduce common LLM coding mistakes. Merge with project-specific instructions as needed.

**Tradeoff:** Bias toward caution over speed. Trivial tasks: use judgment.

## 1. Think Before Coding

**Don't assume. Don't hide confusion. Surface tradeoffs.**

Before implement:

- State assumptions explicitly. If unsure, ask.
- Multiple interpretations: present them, do not pick silently.
- Propose simpler approach. Push back when warranted.
- Unclear: stop. Name confusion, ask.

## 2. Simplicity First

**Minimum code that solves problem. Nothing speculative.**

- No features beyond ask.
- No abstractions for single-use code.
- No requested flexibility/configurability: do not add.
- No error handling for impossible scenarios.
- Write 50 lines instead of 200.

Ask: "Would senior engineer say this is overcomplicated?" If yes, simplify.

## 3. Surgical Changes

**Touch only what you must. Clean up only your own mess.**

When edit existing code:

- Do not "improve" adjacent code, comments, formatting.
- Do not refactor unbroken things.
- Match existing style.
- Unrelated dead code: mention, do not delete.

When changes create orphans:

- Remove unused imports/variables/functions caused by YOUR changes.
- Do not remove pre-existing dead code unless asked.

Test: Every changed line traces directly to user request.

## 4. Goal-Driven Execution

**Define success criteria. Loop until verified.**

Transform tasks to goals:

- "Add validation" → "Write tests for invalid inputs, make them pass"
- "Fix bug" → "Write reproduction test, make it pass"
- "Refactor X" → "Ensure tests pass before and after"

Multi-step tasks plan:

```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

Strong success criteria enable independent loop. Weak criteria ("make it work") need constant clarification.

---

**Guidelines work if:** fewer unnecessary diff changes, fewer overcomplicated rewrites, questions come before implementation.

---

## Agent skills

### Issue tracker

Issue và PRD quản lý bằng markdown trong `.scratch/`. Xem chi tiết tại [issue-tracker.md](file:///home/ducnm/Code/lgg/mes-plus/docs/agents/issue-tracker.md).

### Triage labels

Triage roles ánh xạ tới status labels trong local issue. Xem chi tiết tại [triage-labels.md](file:///home/ducnm/Code/lgg/mes-plus/docs/agents/triage-labels.md).

### Domain docs

Cấu trúc multi-context. `CONTEXT-MAP.md` ở root mô tả luồng nghiệp vụ tổng quát, liên kết tới `CONTEXT.md` chi tiết từng module. Xem chi tiết tại [domain.md](file:///home/ducnm/Code/lgg/mes-plus/docs/agents/domain.md).
