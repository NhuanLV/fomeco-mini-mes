import { execSync } from 'node:child_process'
import { writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))

const DEFAULT_URL = 'http://localhost:8081/v3/api-docs'

const OUTPUT_PATH = resolve(__dirname, '../openapi.json')

console.log(`📥 Downloading OpenAPI spec from: ${DEFAULT_URL}`)

try {
  const response = await fetch(DEFAULT_URL)
  if (!response.ok) {
    console.error(
      `⚠️ Failed to download OpenAPI spec (HTTP ${response.status} ${response.statusText}), use current openapi.json`,
    )
  } else {
    const json = await response.json()
    writeFileSync(OUTPUT_PATH, JSON.stringify(json, null, 2) + '\n', 'utf-8')
    execSync(`pnpm oxfmt "${OUTPUT_PATH}"`, { stdio: 'inherit' })
    console.log(`✅ Saved OpenAPI spec to: ${OUTPUT_PATH}`)
  }
} catch {
  console.error(`⚠️ Failed to download OpenAPI spec, use current openapi.json`)
}

console.log('⚙️  Running openapi-ts to generate client...')
try {
  execSync('pnpm openapi-ts', { stdio: 'inherit', cwd: resolve(__dirname, '..') })
  console.log('✅ Client generation complete.')
} catch {
  console.error('❌ openapi-ts failed.')
  process.exit(1)
}
