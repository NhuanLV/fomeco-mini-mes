export default {
  '*': 'oxfmt --no-error-on-unmatched-pattern',
  '*.{js,ts,mts,tsx,vue}': 'oxlint --fix',
  '*.{ts,mts,tsx,vue}': () => 'vue-tsc -b',
}
