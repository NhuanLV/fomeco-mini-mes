import com.github.gradle.node.pnpm.task.PnpmTask

plugins {
  kotlin("jvm") version "2.4.20"
  kotlin("plugin.spring") version "2.4.20"
  kotlin("plugin.jpa") version "2.4.20"
  id("org.springframework.boot") version "4.0.1"
  id("io.spring.dependency-management") version "1.1.7"
  id("com.github.node-gradle.node") version "7.1.0"
  id("com.google.cloud.tools.jib") version "3.5.4"
}

dependencyManagement {
  imports { mavenBom("com.fasterxml.jackson:jackson-bom:2.21.7") }
}

group = "vn.lgg"

version = "0.0.1-SNAPSHOT"

description = "Mes+ system "

java { toolchain { languageVersion = JavaLanguageVersion.of(25) } }

kotlin {
  compilerOptions {
    freeCompilerArgs.addAll("-Xjsr305=strict", "-Xannotation-default-target=param-property")
  }
}

configurations { compileOnly { extendsFrom(configurations.annotationProcessor.get()) } }

repositories { mavenCentral() }

dependencies {
  // web
  implementation("org.springframework.boot:spring-boot-starter-webmvc")
  implementation("org.springframework.boot:spring-boot-starter-restclient")
  implementation("org.springframework.boot:spring-boot-starter-session-jdbc")
  implementation("org.springdoc:springdoc-openapi-starter-webmvc-api:3.0.3")
  // security
  implementation("org.springframework.boot:spring-boot-starter-security")
  // sql
  implementation("org.springframework.boot:spring-boot-starter-data-jdbc")
  implementation("org.springframework.boot:spring-boot-starter-flyway")
  implementation("org.springframework.boot:spring-boot-starter-jdbc")
  implementation("org.flywaydb:flyway-database-postgresql")
  implementation(platform("org.jetbrains.exposed:exposed-bom:1.0.0"))
  implementation("org.jetbrains.exposed:exposed-core")
  implementation("org.jetbrains.exposed:exposed-jdbc")
  implementation("org.jetbrains.exposed:exposed-dao")
  implementation("org.jetbrains.exposed:exposed-json")
  implementation("org.jetbrains.exposed:exposed-java-time")
  implementation("org.jetbrains.exposed:exposed-spring-boot4-starter")
  implementation("org.jetbrains.exposed:spring7-transaction")
  implementation("org.jetbrains.exposed:exposed-migration-jdbc")
  // io
  implementation("org.springframework.boot:spring-boot-starter-cache")
  implementation("org.springframework.boot:spring-boot-starter-quartz")
  implementation("org.springframework.boot:spring-boot-starter-validation")
  implementation(platform("org.apache.tika:tika-bom:3.2.3"))
  implementation("org.apache.tika:tika-core")
  implementation("org.apache.tika:tika-detectors")
  implementation("com.fasterxml.uuid:java-uuid-generator:5.2.0")
  implementation("org.reflections:reflections:0.10.2")
  implementation("io.github.classgraph:classgraph:4.8.184")
  implementation("io.hypersistence:hypersistence-tsid:2.1.4")
  implementation("org.apache.poi:poi-ooxml:5.4.0")
  // kotlin
  implementation(kotlin("reflect"))
  implementation("tools.jackson.module:jackson-module-kotlin")
  implementation("com.fasterxml.jackson.module:jackson-module-kotlin")
  implementation("io.github.oshai:kotlin-logging-jvm:7.0.3")
  // dev tools
  annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
  developmentOnly("org.springframework.boot:spring-boot-docker-compose")
  // runtime
  runtimeOnly("org.postgresql:postgresql")
  // test
  testImplementation("org.junit.jupiter:junit-jupiter")
  testImplementation("io.kotest:kotest-runner-junit5:6.2.2")
  testImplementation("io.kotest:kotest-assertions-core:6.2.2")
  testImplementation("io.mockk:mockk:1.14.11")
  testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

allOpen {
  annotation("jakarta.persistence.Entity")
  annotation("jakarta.persistence.MappedSuperclass")
  annotation("jakarta.persistence.Embeddable")
}

val genOpenApiClient =
  tasks.register<PnpmTask>("genOpenApiClient") {
    group = "frontend"
    description = "Generate API client from OpenAPI spec"
    args = listOf("run", "openapi:gen")
    dependsOn(tasks.pnpmInstall)
    inputs.files(fileTree("webapp"), file("openapi-ts.config.ts"), file("openapi.json"))
  }

val buildWebapp =
  tasks.register<PnpmTask>("buildWebapp") {
    group = "frontend"
    description = "Build frontend"

    args = listOf("run", "frontend:build")
    dependsOn(tasks.pnpmInstall, genOpenApiClient)
  }

jib {
  from { image = "eclipse-temurin:25-jre-alpine" }
  to {
    image = "ghcr.io/bkclab/mes-plus"
    tags = setOf("latest", version.toString())
  }
  container {
    jvmFlags = listOf("-Xms256m", "-Xmx512m")
    ports = listOf("8081")
  }
}

tasks.processResources {
  val isHeadful =
    findProperty("isHeadful") == "true" ||
      gradle.startParameter.taskNames.any { it.contains("jib") || it.contains("bootJar") }

  if (isHeadful) {
    println("Headless mode is disabled, building frontend...")
    dependsOn(buildWebapp)
    from("${project.projectDir}/webapp/dist") {
      into("static")
    }
  } else {
    println("Headless mode is enabled, skipping frontend build...")
  }
}
tasks.named("jib") { dependsOn(buildWebapp) }
tasks.jibDockerBuild { dependsOn(buildWebapp) }

tasks.bootRun { jvmArgs = listOf("-Duser.timezone=Asia/Ho_Chi_Minh") }

tasks.test { useJUnitPlatform() }
