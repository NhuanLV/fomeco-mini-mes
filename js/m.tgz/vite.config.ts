/// <reference types="vitest/config" />
import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import VueRouter from 'vue-router/vite'
import tailwindcss from '@tailwindcss/vite'
import vueDevTools from 'vite-plugin-vue-devtools'
import ui from '@nuxt/ui/vite'

export default defineConfig({
  root: 'webapp',
  plugins: [
    VueRouter({ root: 'webapp' }),
    vue(),
    ui({
      colorMode: false,
      ui: {
        colors: {
          primary: 'emerald',
        },
        badge: {
          defaultVariants: {
            variant: 'soft',
          },
        },
        alert: {
          defaultVariants: {
            variant: 'subtle',
          },
        },
      },
    }),
    tailwindcss(),
    vueDevTools(),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./webapp/src', import.meta.url)),
    },
  },
  build: {
    emptyOutDir: true,
  },
  server: {
    allowedHosts: ['localhost', 'app.mducbg.dev'],
    proxy: {
      '/api': {
        target: 'http://localhost:8081',
        changeOrigin: true,
      },
    },
  },
  test: {
    globals: true,
    environment: 'happy-dom',
    exclude: ['**/node_modules/**', '**/dist/**', '**/e2e/**'],
    root: fileURLToPath(new URL('./', import.meta.url)),
    setupFiles: ['./webapp/src/test/setup.ts'],
  },
})
