# Sơ đồ Nghiệp vụ Tổng quát (CONTEXT-MAP)

Mô tả luồng nghiệp vụ tổng quát và quan hệ giữa các module trong MES Plus.

## Tổng quan luồng nghiệp vụ (Business Flow)

Quy trình hoạt động:

1. **Đồng bộ**: Phòng kế hoạch đồng bộ đơn hàng (BuyerOrder - BO) từ WFX.
2. **Lập lệnh**: BO chia thành nhiều Lệnh sản xuất (ProductionOrder - LSX). Mỗi LSX chia cho nhiều tổ theo công đoạn (TeamAssignment - cắt, may, thêu, in...).
   LSX được hủy vĩnh viễn sau khi hủy hết Kanban: PO thường chờ WFX xác nhận trước khi commit hủy,
   thuần dương hủy trực tiếp. Chỉ CANCELLED mới trả allocation; LSX/LCĐ giữ dữ liệu để xem lịch sử.
3. **Định mức tổ**: Phòng kỹ thuật hiệu chỉnh định mức vật tư riêng cho từng tổ (TeamMaterial).
4. **Cấp phát**: Tổ trưởng xin cấp phát (Kanban) theo đợt dựa trên định mức tổ.
5. **Tiến độ**: Tổ trưởng cập nhật sản lượng/tiến độ hàng ngày.
6. **Xử lý tồn dư**: Hoàn thành công đoạn, tổ trưởng trả lại NPL thừa cho kho (ReturnRequest) hoặc điều chuyển tổ khác (TransferRequest).

Sơ đồ luồng dữ liệu:

```mermaid
graph TD
    subgraph IAM ["1. IAM (Identity & Access Management)"]
        OrgUnit["Cơ cấu tổ chức nhiều gốc<br>(Corporation, Company, Factory, Team, Warehouse)"]
        Permissions["Phân quyền người dùng<br>(Thủ kho, Tổ trưởng...)"]
    end

    subgraph Order ["2. Quản lý Đơn hàng (Order)"]
        WFX["Đồng bộ đơn hàng từ WFX"] --> BO["Đơn hàng (BuyerOrder)"]
        BO --> PO["Đơn mua hàng (PurchaseOrder)"]
        Style["Mã hàng & BOM & Quy trình mẫu"]
    end

    subgraph Production ["3. Lệnh Sản Xuất & Tiến độ (Production)"]
        LSX["Lệnh sản xuất (ProductionOrder)"]
        TeamAssign["Phân công tổ (TeamAssignment)"]
        TeamMaterial["Định mức nguyên phụ liệu tổ (TeamMaterial)"]
        Progress["Báo cáo tiến độ (Report)"]
    end

    subgraph Kanban ["4. Yêu cầu Vật tư (Kanban)"]
        Request["Yêu cầu cấp phát (Kanban)"]
        Approve["Phê duyệt yêu cầu"]
        Fulfill["Xuất kho cấp phát (KanbanAssignment)"]
    end

    subgraph Inventory ["5. Quản lý Tồn kho Tổ (Inventory)"]
        Inv["Tồn kho tổ (Inventory)"]
        Return["Trả lại NPL thừa (ReturnRequest)"]
        Transfer["Điều chuyển NPL (TransferRequest)"]
    end

    %% Mối quan hệ và luồng dữ liệu
    Style -->|BOM & Routing mẫu| LSX
    PO -->|Phân bổ SKU| TeamAssign
    TeamAssign -->|Khởi tạo| TeamMaterial

    TeamMaterial -->|Tính định mức tiêu hao| Request
    Request -->|Phê duyệt thành công| Fulfill
    Fulfill -->|Thực nhận vật tư| Inv

    Progress -->|Trừ tồn kho tiêu hao| Inv
    Inv -->|Lượng dư thừa| Return
    Inv -->|Lượng dư thừa| Transfer

    OrgUnit -->|Xác thực tổ/kho| TeamAssign
    OrgUnit -->|Xác thực bên cấp phát| Fulfill
    Permissions -->|Kiểm tra quyền hạn| Approve
```

---

## Bản đồ phân vùng nghiệp vụ (Context Map)

Dự án dạng đa ngữ cảnh (multi-context), chia làm các module:

| Module / Context | Thư mục chứa mã nguồn                                                                                                    | Tệp tin nghiệp vụ                                                                                                                    | Trách nhiệm chính                                                                                              |
| :--------------- | :----------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------- |
| **IAM**          | [iam](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/iam)                                           | [CONTEXT.md](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/iam/CONTEXT.md)                                     | Quản lý tài khoản, phân quyền, cơ cấu tổ chức nhiều gốc, mapping công đoạn và kho WFX theo Xí nghiệp.          |
| **Order**        | [order](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/order)                                       | [CONTEXT.md](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/order/CONTEXT.md)                                   | Đồng bộ đơn hàng và supplier master từ WFX, quản lý Style, BOM, Routing mẫu.                                   |
| **Production**   | [production](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/production)                             | [CONTEXT.md](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/production/CONTEXT.md)                              | Lập LSX, phân công tổ, quản lý định mức NPL tổ, báo cáo sản lượng.                                             |
| **Kanban**       | [kanban](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/kanban)                                     | [CONTEXT.md](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/kanban/CONTEXT.md)                                  | Tạo/duyệt yêu cầu cấp phát NPL/BTP từ tổ, theo dõi xuất kho/bàn giao.                                          |
| **Inventory**    | [inventory](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/inventory)                               | [CONTEXT.md](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/inventory/CONTEXT.md)                               | Quản lý tồn kho chuyền/tổ, quy trình trả lại/điều chuyển vật tư thừa.                                          |
| **Notification** | [notification](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/notification)                         | [CONTEXT.md](file:///home/ducnm/Code/lgg/mes-plus/src/main/kotlin/vn/lgg/mesplus/notification/CONTEXT.md)                            | Lưu và chuyển thông báo từ các module nghiệp vụ tới người nhận.                                                |
| **Dashboard**    | [dashboard](file:///Users/macbookair/Documents/Huster/Source-Code/Lab/mes-plus/src/main/kotlin/vn/lgg/mesplus/dashboard) | [CONTEXT.md](file:///Users/macbookair/Documents/Huster/Source-Code/Lab/mes-plus/src/main/kotlin/vn/lgg/mesplus/dashboard/CONTEXT.md) | Tổng quan sức khỏe vận hành, giám sát tiến độ đa tầng, biểu đồ vào/ra chuyền và trung tâm tác nghiệp tồn đọng. |

---

## Các mối liên kết liên ngữ cảnh chính (Cross-Context Interactions)

1. **Production ➔ Kanban**: Phiếu Kanban dùng `BomCalculationService` của Production kiểm tra lượng yêu cầu so với định mức tổ.
2. **Kanban ➔ Inventory**: NPL nhận qua `KanbanMaterialReceived` tăng sổ NPL; BTP giảm sổ chung của tổ nguồn khi xuất; tổ nhận tăng ngay cho PO dương, sau GDN thành công cho PO thường. Loại PO chỉ tách nghiệp vụ, không chia tồn.
3. **Production ➔ Inventory**: OUTPUT hợp lệ tăng sổ BTP riêng của tổ sản xuất; rule tiêu hao NPL hiện có giữ nguyên.
4. **Inventory ➔ Kanban**: Kanban đọc sổ BTP của đúng tổ nguồn cho `SL tồn` BTP; các chỉ số NPL vẫn đọc sổ NPL.
5. **Order ➔ Production (BO revision)**: WFX sync chỉ cập nhật BO/PO. Danh sách LSX hiển thị dấu `!` đỏ cạnh mã LSX khi có ít nhất một TeamAssignment `NEEDS_ADJUSTMENT`; dấu tự mất khi không còn. Click dấu mở LSX detail, highlight/filter các TeamAssignment đó. Phòng kế hoạch tự revision allocation rồi xử lý; không tự động sửa Production.
   PO dương được user sửa quantity trên MES bằng quyền tạo PO; phát hiện xung đột và điều chỉnh dùng chung luồng này. Revision LSX cũ được thêm màu/cỡ hiện có trong PO dù chưa từng thuộc lệnh, cho cả PO thường/dương.
   Khi phát LSX mới, Production kiểm tra BOM của BO; màu/cỡ `Unknown` chặn phát LSX trước khi gọi WFX.
6. **PurchaseOrderQuantityAdjustment**: Không phát side effect sang Inventory hoặc Kanban, không cập nhật TeamMaterial; chỉ đổi quantity theo PO của sản lượng đã làm.
7. **Kanban ➔ WFX**: Xác nhận nhận tạo các GDN `PENDING` trước rồi worker bất đồng bộ gọi WFX; NPL tổng và BTP thường được tách thành hai attempt độc lập; BTP dương ghi nhận ngay, không gửi WFX. NPL vẫn gửi GDN ở LSX thuần dương. Chỉ attempt `SUCCESS` mới phát `KanbanMaterialReceived` cho đúng snapshot của loại đó và tăng tồn kho; attempt `FAILED` không đổi trạng thái nhận và được retry bằng cùng `DocNo`. NPL snapshot từ `wfx_articles.code`, BTP snapshot bằng cách ghép `buyer_orders.article_code` với hậu tố `ouputitem` (`outputItemSuffix`) của công đoạn nguồn trong Routing; `DispatchedSite` lấy từ Warehouse trong mapping công đoạn theo Xí nghiệp (NPL: `Kho xuất NPL` của xí nghiệp hiện tại, BTP: `Kho nhập BTP` của xí nghiệp nguồn thực hiện công đoạn trước trong Routing).
8. **Production ➔ WFX**: Báo `OUTPUT` hỗn hợp lưu phần dương ngay; phần thường tạo `ReportGrn.PENDING` cùng snapshot riêng trước, rồi gọi WFX bất đồng bộ; GRN `SUCCESS` ghi nhận phần thường và side effect tương ứng. Lịch sử báo hai dòng theo loại; INPUT không tạo GRN. `PENDING`/`FAILED` khóa mọi OUTPUT mới; `FAILED` giữ snapshot để thử lại/sửa/hủy mà không đổi phần dương, `CANCELLED` mở khóa lần báo tiếp theo. Công đoạn trung gian ghép `buyer_orders.article_code` với `outputItemSuffix`; công đoạn cuối dùng trực tiếp `buyer_orders.article_code`. `SiteName` lấy từ Kho nhập BTP và `DestinationCountryName` tra qua `wfx_countries`.
9. **Production ➔ Notification**: Listener của `ProductionOrderIssued` tạo một thông báo cho mỗi `TeamAssignment`; người nhận là tài khoản thuộc Team được giao và có quyền `REPORT_PROGRESS` tại Team đó.
10. **Order/WFX ➔ IAM**: Danh sách `SupplierCompanyName` từ WFX được cache ở `wfx_suppliers`; IAM dùng cache này để cấu hình `wfxSupplierName` cho Company outsource. `factory_operations` giữ mapping công đoạn và kho theo Xí nghiệp `(factoryId, operationCode)` cho các luồng tích hợp tiếp theo. `operationCode` bất biến sau khi tạo; tên công đoạn, liên kết kho và trạng thái được phép sửa; mapping không được xóa.
