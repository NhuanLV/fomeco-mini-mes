import { expect, test } from '@playwright/test'

test.describe('App E2E', () => {
  test('has title', async ({ page }) => {
    await page.goto('/')
    await expect(page).toHaveTitle(/LGG MES\+/)
  })
})
